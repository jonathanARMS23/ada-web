# Changelog — AI-Dev-Assistant

Format : [Keep a Changelog](https://keepachangelog.com/) — Semantic Versioning

## [7.0.1] — 2026-05-31

### Fixed — P1 Stabilité production

- `bank.js` : `_hnswVocabSet` (Set) — lookups O(1) au lieu de O(n) `includes()` sur vocab croissant
- `bank.js` : `RETRIEVE_CAP=500` — borne le scan de candidats dans `retrieve()`, empêche HNSW rebuild O(n²) sur banks > 500 trajectoires
- `bank.js` : écriture HNSW atomique (tmp + `renameSync`) — élimine les corruptions sur crash
- `run.js` : timeout 2s sur `bank.retrieve()` dans le bloc ACW — les phases ne sont plus bloquées si SQLite est lent, log warning + skip injection
- `session-end.js` : retry backoff exponentiel (tentative 1: 200ms, 2: 800ms) sur `bank.store()` auto-banking — log persistant si toutes tentatives échouent
- `daemon.js` : `_gracefulShutdown()` drain tous les timers + 2s grâce avant `process.exit(0)` — plus de workers zombies à l'arrêt
- `daemon.js` : `loadSchedule()` valide whitelist workers (doit exister sur disque) + intervalle [1min, 7j] — protège contre l'injection de workers arbitraires

---

## [7.0.0] — 2026-05-31

### Added — Sprint Ruflo : Intelligence Retrieval + Agents + Daemon

**SmartRetrieval ACW v2 (coordinator/run.js + coordinator/embeddings.js)**
- Pipeline complet : `expandQuery(query, {maxVariants:3})` → `searchBM25` × 3 variantes → `reciprocalRankFusion(rankedLists, k=60, {recency:true})` → `maximalMarginalRelevance(candidates, queryTokens, {lambda:0.6, topK:5})`
- Remplace le TF-IDF mono-requête de l'ACW : les 5 trajectoires injectées avant spawn agent sont désormais sélectionnées par pertinence sémantique ET diversité (MMR évite les répétitions)
- `bank.retrieve()` passe à `limit: 10` (was 5) pour donner plus de candidats au pipeline de re-ranking

**HNSW Persistant (coordinator/bank.js)**
- `bank-hnsw.json` : graphe HNSW sérialisé entre sessions avec vocab partagé
- `_hnswInsert(traj)` : insertion automatique à chaque `bank.store()` — zéro maintenance manuelle
- `hnswSearch(query, k=5)` : API publique retournant `{id, dist, similarity}[]` pour recherche vecteur directe
- Vocab partagé `_hnswVocab` / `_hnswVocabSet` — dimensions stables entre inserts, rebuild limité si > 500 nœuds

**Auto-Banking Session-End (hooks/session-end.js)**
- Trigger : hook `Stop` Claude Code (chaque fin de réponse)
- Scanne `coordinator/runs/` pour le run actif (`status='running'`, `activePhase≠null`)
- Banke les phases `completed` non encore enregistrées, max 3/cycle, via `bank.store()`
- Enregistre les phases bankées dans `state.bankedPhases` pour éviter les doublons
- Zéro perte de trajectoires même si `run.js done` n'est jamais appelé

**Daemon Worker Scheduler (workers/daemon.js)**
- Scheduler Node.js léger en arrière-plan (PID file `logs/daemon.pid`)
- Schedule par défaut : ultralearn/6h · consolidate/2h · audit/24h · cve-scan/72h
- Config custom via `~/.ada.json` → `daemon.schedule` (format "6h", "30m", ou ms)
- `delayUntilNext()` : calcule le délai depuis le dernier run pour reprendre proprement après redémarrage
- Alignement minuit pour le worker `audit`
- Protection double-start par PID file + `process.kill(pid, 0)`
- Log rotation quotidienne, archives 7 jours max

**Catalogue agents étendu — 131 agents (was 59)**
- 72 agents Ruflo intégrés dans `.claude/agents/`
- Catégories : coordinator · memory/DB · benchmark · sona · github · ml · security · dev · infra
- `ada agents list [--category <cat>]` : catalogue avec groupes et comptage
- `ada agents search <query>` : grep nom/titre/description
- `README-ruflo-agents.md` : catalogue complet avec descriptions

**15 nouveaux profils de routing**
- swarm-coordinator (agents: agent-adaptive-coordinator · agent-queen-coordinator · agent-hierarchical-coordinator)
- benchmark (agent-benchmark-suite · agent-performance-benchmarker · agent-performance-optimizer)
- sona-optimizer (agent-sona-learning-optimizer · agentdb-learning · agent-memory-coordinator)
- sparc-coder (agent-coder · agent-implementer-sparc-coder · agent-tdd-london-swarm)
- github-ops (agent-github-pr-manager · agent-ops-cicd-github · agent-release-manager)
- consensus (agent-byzantine-coordinator · agent-raft-manager · agent-consensus-coordinator)
- ml-agent (agent-neural-network · agent-data-ml-model · agent-trading-predictor)
- goal-planner (agent-goal-planner · agent-code-goal-planner · agent-planner)
- memory-swarm (agent-swarm-memory-manager · agentdb-vector-search · agentdb-advanced)
- pair-dev (pair-programming · agent-coder · agent-code-review-swarm)
- graph-analysis (agent-pagerank-analyzer · agent-matrix-optimizer · agent-performance-analyzer)
- meta-agent (skill-builder · agent-researcher · agent-arch-system-design)
- security-neural (agent-security-manager · agent-safla-neural · agent-v3-security-architect)
- release-ops (agent-release-manager · agent-release-swarm · agent-repo-architect)
- fintech (agent-agentic-payments · agent-payments · agent-trading-predictor)

**5 nouvelles commandes CLI (bin/ada.js)**
- `ada daemon start|stop|status|run <worker>` — contrôle du scheduler background
- `ada memory search <query> [--phase <id>]` — SmartRetrieval complet (expandQuery→BM25→RRF→MMR)
- `ada memory hnsw <query>` — recherche HNSW vectorielle directe
- `ada memory stats` — compte trajectoires + présence bank-hnsw.json
- `ada agents list [--category <cat>]` — catalogue agents ADA + Ruflo
- `ada agents search <query>` — grep multicritère

---

## [6.0.0] — 2026-05-23

### Added

**Sprint S15 — Intelligence adaptative**
- F2 Adaptive Context Window : HNSW k-NN `bank.retrieve()`, top-5 trajectoires injectées en YAML dans le prompt avant spawn
- F4 Smart Retry Diagnostic : trajectoires d'échec de la phase injectées dans le prompt de retry via `bank.getRecent()`
- F10 Budget Guard : circuit-breaker budgétaire dans `coordinator/budget-guard.js` — seuils `warn`, `stop`, `downgrade_tier` par run/session/day ; log trim 90 jours
- F12 Predictive Estimator : `coordinator/predictive-estimator.js` — tableau pré-run avec coût estimé, durée médiane et taux de succès historique par phase

**Sprint S16 — Cache et multi-provider**
- F1 Prompt Cache Optimizer : `coordinator/prompt-cache-optimizer.js` — `cache_control: {type:"ephemeral"}` sur blocs stables, tracking savings ($2.70/1M tokens économisés), deep-clone avant downgrade pour éviter la corruption cache
- F5 Multi-Provider Gateway : `coordinator/provider-gateway.js` — fallback Anthropic → OpenAI → DeepSeek → Ollama, circuit breaker (3 échecs → open, 5 min → half-open), options `preferCheap` et `maxCostUsd`

**Sprint S17 — Collaboration et observabilité**
- F3 PR Autopilot : `coordinator/pr-autopilot.js` — création PR GitHub automatique via `GITHUB_TOKEN`, `buildPRBody` markdown, monitoring CI check-runs
- F6 Team Sync : `coordinator/team-sync.js` — sync git-based des priors Thompson, merge `alpha_merged = alpha_local + alpha_remote - 1`, déduplication lessons
- F7 Observability Dashboard : SVG pure charts dans l'UI — win-rates Thompson, timeline coûts 14 jours, alertes budget ; API `GET /api/stats/observe`

**Sprint S18 — Éditeur, fédération et marketplace**
- F8 Pipeline Composer : `coordinator/pipeline-composer.js` — éditeur visuel DAG HTML5 drag-and-drop, détection cycles DFS, SVG bézier arrows
- F13 Federation mTLS : `coordinator/federation.js` — échange P2P de trajectoires, `requestCert: true`, bind `127.0.0.1` par défaut, `generateCerts` via openssl, query cap 1 KB avant `bank.retrieve()`
- F14 Skill Marketplace : `coordinator/skill-registry.js` — installation SHA256-verified, jail path traversal `realpathSync`, cache TTL 1 h, `isSafeFilename`
- Nouveau tag OpenAPI `stats` — routes `/api/stats/observe`, `/api/stats/budget`, `/api/stats/cost`

### Fixed

- `bank.getRecent(limit)` manquant dans les exports — F6 Team Sync était silencieusement cassée
- Deep-clone pipeline avant `downgrade_tier` dans F1 — corruption du cache de prompt
- `recordCost` rejette `Infinity` et `NaN` — prévention DoS permanent sur le budget
- Symlink jail `realpathSync` dans plugin loader — vecteur RCE locale
- MCP command path traversal bloqué (`/usr/local/bin/node` validation)
- `Atomics.wait` remplacé par tentative unique non-bloquante dans `router.js`
- Mutex async sur PATCH `~/.ada.json` — race condition profil
- Proxy auth étendue aux routes GET

### Security — Sprint S14

- `safeCompare` constant-time dans `proxy.ts` — length oracle corrigé
- IPv6 bracket bypass (`[::1]`) corrigé dans le SSRF guard webhook (ADR-002)
- `req.json()` guard sur `profile-types` — crash sur body vide
- `isProfileError` ajouté dans la memory route — fuite d'erreur interne
- Pipelines `.max(50)` phases — prévention pipeline bombing
- MCP registry : limite 50 variables d'environnement, 4096 chars chacune
- `tmpName` validation dans `plugins.js` — path traversal dans les noms temporaires

---

## [5.1.0] — 2026-05-13

### Added
- Registre MCP (`coordinator/mcp-registry.json`) séparé de `settings.json` — toggle enable/disable sans suppression
- Catalogue MCP intégré : 15 serveurs préconfigurés (filesystem, github, postgres, fetch, brave-search, sqlite, memory, puppeteer, slack, git, sequential-thinking, aws-kb, everything, linear, notion)
- Synchronisation automatique MCP au démarrage (`ada start` → sync registry → settings.json)
- `ada schedule list/add/remove/toggle` — pipelines planifiés avec validation cron 5 champs
- `ada profile push <url>` / `ada profile pull <url>` — sync profil via git
- `ada run <pipeline> --retry` — relancer les phases échouées uniquement
- Audit log NDJSON append-only (`coordinator/audit.log`) — trace toutes les opérations pipeline
- Cost tracking par phase : flags `--tokens` et `--cost`, cumul `run.totalTokens` / `run.totalCost`
- Webhooks HTTP/HTTPS fire-and-forget (`~/.ada.json → webhook`) : événements `run.complete`, `run.fail`, `session.end`
- 6 nouveaux pipelines : `saas-bootstrap`, `bug-fix`, `perf-audit`, `security-audit`, `api-design`, `data-migration`
- Agent hot-reload : polling mtime toutes les 2s + sentinel `.last-modified`
- Capture git state (`commitHash`, `branch`) dans l'init du run
- ADA UI v2 : pages `/connectors`, `/audit`, `/pipelines`, `/schedules` + section webhook dans `/settings`
- Dashboard widget coût (`CostWidget`) dans `/dashboard`
- API routes : `/api/mcp/registry`, `/api/stats/audit`, `/api/stats/cost`, `/api/pipelines`, `/api/schedules`, `/api/settings/webhook`, `/api/runs/[id]/retry`

### Fixed
- `cmdRetry` ne réinitialisait pas les phases skipped (corrigé → reset uniquement `status === 'failed'`)
- `profile push` hardcodait la branche `main` (corrigé → détection dynamique)
- `profile push` forçait `--force` sur re-push (corrigé → `--force` uniquement pour nouveau repo)
- Webhooks : fuite de file descriptor (corrigé → timeout 5s + `req.destroy()`)
- Ecriture atomique manquante dans `bank.js` (corrigé → `writeFileSync` + `renameSync`)
- Race condition dans `watchAgents` (corrigé → capture `now` en début d'intervalle)
- `process.exit(1)` dans try blocks `run.js` (corrigé → `throw new Error` pour déclencher `finally`/`releaseLock`)
- `profile=null` dans les queries TanStack : `enabled: !!profile` sur tous les hooks profil-dépendants
- Comparaison HMAC non timing-safe (corrigé → `crypto.timingSafeEqual()`)
- Injection YAML via newlines dans `writeAgentFrontmatter` (corrigé → strip `\r\n`)
- Clé `pipelinesFile` dupliquée dans `ada-paths.ts` (supprimée)
- `McpCatalogItem` importé côté client depuis une route serveur (déplacé vers `ada-fs.ts`)
- Audit log : une ligne JSON corrompue cassait toutes les entrées (corrigé → `flatMap` per-line try/catch)

---

## [1.0.0] — 2026-05-10

### Added
- Thompson Sampling routing avec Marsaglia-Tsang (Beta(α,β) priors par phase:agent)
- DAG pipelines déclaratifs (7 pipelines : feature, review, db-migrate, test, hotfix, migration, mobile)
- Tier cost model sur toutes les phases (Haiku/Sonnet/Opus)
- ReasoningBank STORE→RETRIEVE→DISTILL→CONSOLIDATE avec index phase→ids
- Système de plugins (~/.claude/plugins/) avec hook.js et worker.js
- 10 suites de tests (node:test, zéro dépendance)
- Scan CVE automatique post-install (npm audit v1/v2 + pip-audit/safety)
- Lock atomique O_EXCL anti-TOCTOU sur la state machine des runs
- Auto-decay Thompson Sampling toutes les 30 réponses
- Workers : audit (OWASP), testgaps, metrics, cve-scan, ultralearn
- Agents spécialisés : graphql, realtime, k8s, observability + 4 nouveaux domaines
