# Contributing — AI Dev Assistant

## Structure du projet

```
coordinator/   — Orchestration : run.js, router.js, bank.js, pipelines.json, embeddings.js
coordinator/budget-guard.js             — Circuit-breaker budgétaire (F10)
coordinator/predictive-estimator.js     — Estimation pré-run coût/durée/succès (F12)
coordinator/context-advisor.js          — Adaptive Context Window HNSW k-NN (F2)
coordinator/prompt-cache-optimizer.js   — Cache Anthropic ephemeral blocs stables (F1)
coordinator/provider-gateway.js         — Multi-provider Anthropic/OpenAI/DeepSeek/Ollama (F5)
coordinator/team-sync.js                — Sync git-based des priors Thompson (F6)
coordinator/pr-autopilot.js             — Autopilot PR GitHub + monitoring CI (F3)
coordinator/pipeline-composer.js        — Éditeur visuel DAG HTML5 (F8)
coordinator/federation.js               — Échange mTLS P2P de trajectoires (F13)
coordinator/skill-registry.js           — Marketplace SHA256-verified (F14)
coordinator/embeddings.js               — SmartRetrieval : expandQuery, BM25, RRF, MMR, HNSW
hooks/         — Hooks Claude Code : pre-bash.js, post-bash.js
workers/       — Processus background : ultralearn.js, dashboard.js
workers/daemon.js                       — Scheduler background workers (P1: graceful shutdown, validation)
bin/           — CLI utilitaires : plugins.js, doctor.js
agents/        — CLAUDE.md par agent spécialisé
tests/         — Tests node:test : run-all.js + *.test.js
docs/adr/      — Architecture Decision Records (ADR-001 → ADR-012)
```

## Nouveaux modules v7.0.0

### SmartRetrieval — Pipeline de re-ranking

`coordinator/embeddings.js` expose 4 fonctions utilisées dans `run.js` ACW :

| Fonction | Rôle |
|----------|------|
| `expandQuery(query, {maxVariants})` | Génère 3 variantes BM25 depuis la requête originale |
| `searchBM25(query, docs, {limit})` | BM25 scoring sur un corpus de documents |
| `reciprocalRankFusion(lists, k, {recency, tsMap})` | Fusionne plusieurs listes ranked (k=60), boost recency optionnel |
| `maximalMarginalRelevance(candidates, queryTokens, {lambda, topK})` | Sélection diverse : λ=0.6 équilibre pertinence/diversité |

Pipeline complet dans `run.js:523` (fonction `smartSearch`) :
```
bank.retrieve(query, {limit:10})
  → successOnly filter
  → expandQuery → searchBM25 × 3 variantes
  → reciprocalRankFusion(k=60, recency=true)
  → maximalMarginalRelevance(λ=0.6, topK=5)
  → phase.acwContext injection
```

### HNSW Bank

`coordinator/bank.js` maintient un graphe HNSW persistant en parallèle de SQLite :

- **Fichier** : `coordinator/bank-hnsw.json`
- **Vocab** : `_hnswVocab[]` (array ordonné) + `_hnswVocabSet` (Set pour O(1))
- **Insert** : `_hnswInsert(traj)` appelé à chaque `store()`, debounce 5s pour `_persistHNSW()`
- **Search** : `bank.hnswSearch(query, k=5)` → `{id, dist, similarity}[]`
- **Limite** : skip rebuild vocab si > 500 nœuds (dimension drift acceptable)

### Daemon Scheduler

`workers/daemon.js` est le scheduler background :

```
workers/
  daemon.js         — scheduler principal
  ultralearn.js     — apprentissage profond 6h
  consolidate.js    — consolidation bank 2h
  audit.js          — audit sécurité 24h (aligné minuit)
  cve-scan.js       — scan CVE 72h
  [+ 8 autres]
```

Config `~/.ada.json` :
```json
{
  "daemon": {
    "schedule": {
      "ultralearn": "4h",
      "consolidate": "1h",
      "audit": "24h"
    }
  }
}
```

Règles de validation schedule :
- Worker doit exister dans `workers/` ou `DEFAULT_SCHEDULE`
- Intervalle : min 1 minute, max 7 jours
- Formats acceptés : `"6h"`, `"30m"`, `"90s"`, `"2d"`, ou nombre en ms

### Agents Ruflo

Les agents Ruflo sont dans `.claude/agents/` en format `.md`. Structure d'un agent :

```markdown
---
name: agent-nom
description: Description courte
---
# Agent Nom
[contenu du rôle]
```

Règle de priorité : si un dossier `agents/nom/CLAUDE.md` ET un fichier `agents/nom.md` existent pour le même agent, le dossier a la priorité (agent ADA natif > agent Ruflo).

Catégories Ruflo disponibles : `coordinator` · `memory` · `benchmark` · `sona` · `github` · `ml` · `security` · `dev` · `infra`

### CLI — Nouvelles commandes

Toutes les commandes sont dans `bin/ada.js` :

| Commande | Module délégué | Description |
|----------|---------------|-------------|
| `ada daemon <cmd>` | `workers/daemon.js` | Contrôle scheduler background |
| `ada memory search <q>` | `coordinator/bank.js` + `embeddings.js` | SmartRetrieval |
| `ada memory hnsw <q>` | `coordinator/bank.js` | Recherche vectorielle HNSW |
| `ada memory stats` | `coordinator/bank.js` | Stats trajectoires |
| `ada agents list` | `.claude/agents/` | Catalogue agents |
| `ada agents search <q>` | `.claude/agents/` | Grep agents |
| `ada bank hnsw <q>` | `coordinator/bank.js` | Alias hnswSearch |

## Ajouter un pipeline

1. Éditer `coordinator/pipelines.json`
2. Ajouter une entrée dans l'objet `pipelines` :
   ```json
   "my-pipeline": {
     "phases": [
       { "id": "schema", "agent": "db", "depends": [], "tier": 1, "stopOnFailure": true },
       { "id": "backend", "agent": "nestjs", "depends": ["schema"], "tier": 2, "stopOnFailure": true }
     ]
   }
   ```
3. Règles DAG : pas de cycles (détection DFS au démarrage), `depends[]` référencent des IDs existants
4. `tier` : 1 = Haiku, 2 = Sonnet, 3 = Sonnet max

## Créer un plugin

Structure dans `~/.claude/plugins/<nom>/` :

```
manifest.json   — { "name", "version", "hooks": ["pre-bash"|"post-bash"], "triggers": [...] }
hook.js         — exports.run = (ctx) => { ... }   // sync, timeout 1s, bloquant
worker.js       — exports.run = (ctx) => { ... }   // async, fire-and-forget
```

- `hook.js` : deadline 1s enforced — ne pas faire d'I/O lent
- `worker.js` : spawné en processus détaché — ne pas attendre de retour
- Pas de dépendances npm : le plugin doit fonctionner avec les modules Node.js natifs

## Ajouter un agent

1. Créer `agents/<nom>/CLAUDE.md` (ou `agents/<nom>.md` pour les agents sans répertoire)
2. Format obligatoire :
   ```markdown
   ---
   name: <nom>
   description: <rôle en une ligne>
   ---
   # <Nom> Agent
   ## Rôle
   ## Stack
   ## Patterns obligatoires
   ## Output attendu
   ```
3. Mettre à jour la table de routing dans `agents/orchestrator/CLAUDE.md`
4. Si nouvel agent dans un profil, mettre à jour la table dans `~/.claude-pro/CLAUDE.md`

## Commandes de développement

```bash
npm test              # Tests node:test (tous les fichiers *.test.js)
npm run test:coverage # Tests avec rapport de coverage
npm run lint          # node --check sur tous les .js du projet
npm run type-check    # TypeScript strict (si fichiers .ts présents)
npm run doctor        # Health check complet du système
npm run dashboard     # Démarrer le dashboard HTTP (port 7821)
npm run reindex       # Réindexer le ReasoningBank
```

## Règles

- **Zéro dépendance runtime externe** : uniquement les modules `node:*` built-in
- **CommonJS** (`require`/`module.exports`) — pas d'ESM dans ce projet (`"type": "commonjs"`)
- **node:test** pour les tests — pas de Jest, pas de Vitest
- Conventional commits : `feat:`, `fix:`, `chore:`, `docs:`, `test:`
- Jamais de secrets dans le code — utiliser les variables d'environnement
