# Agents adaptés depuis Ruflo (Claude Flow V3)

Source : `/Users/jonathanarms/Documents/ARMS/projects/ruflo/.agents/skills/`
Date d'adaptation : 2026-05-31
Total adapté : 60 agents

---

## Catégorie : coordinator (12 agents)

| Fichier | Description |
|---------|-------------|
| `agent-adaptive-coordinator.md` | Coordinateur topologie dynamique avec auto-organisation swarm |
| `agent-queen-coordinator.md` | Orchestrateur souverain hiérarchique hive mind |
| `agent-hierarchical-coordinator.md` | Coordinateur swarm hiérarchique queen→workers |
| `agent-collective-intelligence-coordinator.md` | Nexus neural pour processus cognitifs distribués |
| `agent-consensus-coordinator.md` | Protocoles de consensus distribués avec BFT |
| `agent-mesh-coordinator.md` | Réseau mesh peer-to-peer sans autorité centrale |
| `agent-raft-manager.md` | Algorithme Raft : leader election et log replication |
| `agent-byzantine-coordinator.md` | Consensus tolérant aux fautes byzantines (PBFT) |
| `agent-quorum-manager.md` | Ajustement dynamique de quorum et vote pondéré |
| `agent-gossip-coordinator.md` | Protocoles gossip pour consensus éventuellement cohérent |
| `agent-sparc-coordinator.md` | Orchestrateur de la méthodologie SPARC |
| `agent-orchestrator-task.md` | Coordination centrale de décomposition et synthèse de tâches |

---

## Catégorie : performance/benchmark (5 agents)

| Fichier | Description |
|---------|-------------|
| `agent-benchmark-suite.md` | Suite complète benchmarking avec détection de régressions |
| `agent-performance-benchmarker.md` | Benchmarkeur pour protocoles distribués |
| `agent-performance-optimizer.md` | Optimiseur via algorithmes sublinéaires |
| `agent-performance-monitor.md` | Moniteur métriques temps réel avec alertes SLA |
| `agent-topology-optimizer.md` | Reconfiguration dynamique de topologie swarm |

---

## Catégorie : memory (7 agents)

| Fichier | Description |
|---------|-------------|
| `agent-swarm-memory-manager.md` | Gestionnaire mémoire distribuée du hive mind |
| `agent-memory-coordinator.md` | Coordinateur mémoire persistante cross-sessions |
| `agent-v3-memory-specialist.md` | Unification 6+ systèmes mémoire vers AgentDB |
| `agentdb-learning.md` | 9 algorithmes RL via plugins AgentDB |
| `agentdb-vector-search.md` | Recherche vectorielle HNSW 150x-12500x plus rapide |
| `agentdb-advanced.md` | Fonctionnalités avancées AgentDB (QUIC sync, multi-base) |
| `agentdb-memory-patterns.md` | Patterns de mémoire persistante pour agents AI |

---

## Catégorie : security (3 agents)

| Fichier | Description |
|---------|-------------|
| `agent-security-manager.md` | Sécurité cryptographique pour systèmes distribués |
| `agent-safla-neural.md` | SAFLA : auto-amélioration avec mémoire persistante |
| `agent-v3-security-architect.md` | Refonte sécurité V3 : CVE-1/2/3 et secure-by-default |

---

## Catégorie : sona/learning (3 agents)

| Fichier | Description |
|---------|-------------|
| `agent-sona-learning-optimizer.md` | Auto-optimisation SONA avec LoRA et EWC++ |
| `neural-training.md` | Entraînement patterns SONA, MoE et EWC++ |
| `reasoningbank-intelligence.md` | Apprentissage adaptatif ReasoningBank |

---

## Catégorie : dev/coder (8 agents)

| Fichier | Description |
|---------|-------------|
| `agent-coder.md` | Spécialiste implémentation code clean et efficace |
| `agent-implementer-sparc-coder.md` | SPARC coder avec TDD Red→Green→Refactor |
| `agent-tdd-london-swarm.md` | TDD London School mock-driven dans swarms |
| `pair-programming.md` | Pair programming AI multi-modes avec quality scoring |
| `agent-code-review-swarm.md` | Review multi-agents parallèles par domaine |
| `agent-analyze-code-quality.md` | Analyse qualité code et technical debt |
| `agent-dev-backend-api.md` | Développeur backend API avec auto-apprentissage |
| `agent-docs-api-openapi.md` | Documentation OpenAPI 3.0 et SDK generation |

---

## Catégorie : github-ops (7 agents)

| Fichier | Description |
|---------|-------------|
| `agent-github-pr-manager.md` | Gestion cycle de vie complet des PRs |
| `agent-ops-cicd-github.md` | Ingénieur CI/CD GitHub Actions |
| `agent-release-manager.md` | Release manager automatisé multi-packages |
| `agent-release-swarm.md` | Orchestration releases complexes par swarm |
| `github-automation.md` | Automatisation GitHub complète (PRs, issues, CI) |
| `github-code-review.md` | Code review GitHub avec coordination swarm |
| `github-multi-repo.md` | Coordination multi-dépôts synchronisés |
| `github-project-management.md` | Gestion projet GitHub agile avec swarm |
| `agent-workflow-automation.md` | Workflows GitHub Actions intelligents |
| `agent-repo-architect.md` | Architecture et optimisation de dépôts |

---

## Catégorie : consensus/distributed (3 agents)

| Fichier | Description |
|---------|-------------|
| `agent-crdt-synchronizer.md` | CRDTs pour cohérence éventuelle sans coordination |
| `hive-mind.md` | Consensus BFT et coordination distribuée |
| `hive-mind-advanced.md` | Hive Mind avancé avec queens multi-niveaux |

---

## Catégorie : ml/ai (4 agents)

| Fichier | Description |
|---------|-------------|
| `agent-neural-network.md` | Entraînement et déploiement réseaux de neurones distribués |
| `agent-data-ml-model.md` | Développement modèles ML end-to-end |
| `agent-trading-predictor.md` | Prédiction financière via avantages computationnels |
| `embeddings.md` | Embeddings HNSW avec support hyperbolique |

---

## Catégorie : planner/goal (4 agents)

| Fichier | Description |
|---------|-------------|
| `agent-goal-planner.md` | GOAP avec A* search pour plans optimaux |
| `agent-code-goal-planner.md` | GOAP centré développement avec SPARC |
| `agent-planner.md` | Planification stratégique et orchestration |
| `agent-orchestrator-task.md` | Orchestration centrale de tâches |

---

## Catégorie : graph/analysis (3 agents)

| Fichier | Description |
|---------|-------------|
| `agent-pagerank-analyzer.md` | PageRank et analyse de graphes via sublinéaire |
| `agent-matrix-optimizer.md` | Analyse et optimisation matricielle |
| `agent-load-balancer.md` | Distribution de charge avec work-stealing |

---

## Catégorie : meta/infra (4 agents)

| Fichier | Description |
|---------|-------------|
| `skill-builder.md` | Créateur de Skills Claude Code |
| `agent-researcher.md` | Recherche et synthèse d'informations |
| `agent-arch-system-design.md` | Conception systèmes et patterns architecturaux |
| `agent-resource-allocator.md` | Allocation adaptative de ressources |

---

## Catégorie : fintech (2 agents)

| Fichier | Description |
|---------|-------------|
| `agent-agentic-payments.md` | Paiements autonomes multi-agents avec Ed25519 |
| `agent-payments.md` | Systèmes de crédits et facturation cloud |

---

## Catégorie : quality/validation (3 agents)

| Fichier | Description |
|---------|-------------|
| `verification-quality.md` | Truth scoring 0.95 avec rollback automatique |
| `agent-production-validator.md` | Validation pre-production et deployment readiness |
| `agent-v3-queen-coordinator.md` | Queen V3 pour orchestration 15 agents simultanés |

---

## Catégorie : v3-specialists (2 agents)

| Fichier | Description |
|---------|-------------|
| `agent-v3-performance-engineer.md` | Ingénieur performance V3 (Flash Attention, 150x search) |
| `agent-v3-integration-architect.md` | Architecte intégration agentic-flow@alpha V3 |

---

## Agents Ruflo restants (non adaptés — 72 sur 132)

Ces agents ont été jugés moins prioritaires ou redondants avec des agents ADA existants :
`agent-app-store`, `agent-architecture`, `agent-authentication`, `agent-automation-smart-agent`,
`agent-base-template-generator`, `agent-challenges`, `agent-code-analyzer`, `agent-coordination`,
`agent-coordinator-swarm-init`, `agent-github-modes`, `agent-issue-tracker`, `agent-migration-plan`,
`agent-multi-repo-swarm`, `agent-performance-analyzer`, `agent-pr-manager`, `agent-project-board-sync`,
`agent-pseudocode`, `agent-refinement`, `agent-reviewer`, `agent-sandbox`, `agent-scout-explorer`,
`agent-spec-mobile-react-native`, `agent-specification`, `agent-swarm`, `agent-swarm-issue`,
`agent-swarm-pr`, `agent-sync-coordinator`, `agent-test-long-runner`, `agent-tester`,
`agent-topology-optimizer`, `agent-user-tools`, `agent-worker-specialist`, `agentdb-optimization`,
`agentic-jujutsu`, `claims`, `flow-nexus-neural`, `flow-nexus-platform`, `flow-nexus-swarm`,
`github-release-management`, `github-workflow-automation`, `hooks-automation`, `memory-management`,
`reasoningbank-agentdb`, `security-audit`, `sparc-methodology`, `stream-chain`,
`swarm-advanced`, `swarm-orchestration`, `v3-cli-modernization`, `v3-core-implementation`,
`v3-ddd-architecture`, `v3-integration-deep`, `v3-mcp-optimization`, `v3-memory-unification`,
`v3-performance-optimization`, `v3-security-overhaul`, `v3-swarm-coordination`,
et les agents V3 restants.
