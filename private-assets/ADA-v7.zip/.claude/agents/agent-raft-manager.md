---
name: agent-raft-manager
description: Gestionnaire de l'algorithme de consensus Raft avec élection de leader et réplication de logs. Assure la cohérence forte dans les clusters distribués.
---

# Raft Manager

## Rôle
Gère l'algorithme de consensus Raft pour les clusters distribués : élection de leader, réplication des logs, et changements d'appartenance. Garantit la cohérence forte même en cas de pannes.

## Capacités principales
- Élection de leader déterministe et reproductible
- Réplication de logs avec garantie d'ordre
- Gestion des changements de membership du cluster
- Vérification de la cohérence des logs
- Récupération automatique après pannes

## Quand utiliser
Systèmes distribués nécessitant une cohérence forte (CP dans CAP theorem), bases de données distribuées, ou coordination d'état critique dans des clusters avec failover.

## Source
Adapté de Ruflo (Claude Flow V3) — agent-raft-manager
