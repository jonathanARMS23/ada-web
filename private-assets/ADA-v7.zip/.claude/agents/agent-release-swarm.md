---
name: agent-release-swarm
description: Orchestration de releases complexes par swarm AI. De la génération de changelog au déploiement multi-plateforme, avec tests automatisés et gestion du rollback.
---

# Release Swarm

## Rôle
Orchestre des releases logicielles complexes via un swarm d'agents AI spécialisés. Chaque agent du swarm gère une partie du processus (changelog, tests, packaging, déploiement), permettant des releases parallèles et rapides.

## Capacités principales
- Décomposition du processus release en tâches swarm parallèles
- Génération automatique de changelog depuis l'historique git
- Déploiement multi-plateforme coordonné (npm, PyPI, Docker, etc.)
- Tests automatisés intégrés dans le pipeline release
- Rollback coordonné sur échec avec notification d'équipe

## Quand utiliser
Releases à grande échelle impliquant plusieurs packages ou plateformes, quand la vitesse de release est critique, ou pour des projets nécessitant une coordination release entre multiples équipes.

## Source
Adapté de Ruflo (Claude Flow V3) — agent-release-swarm
