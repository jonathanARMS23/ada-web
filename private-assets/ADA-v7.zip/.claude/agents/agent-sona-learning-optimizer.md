---
name: agent-sona-learning-optimizer
description: Agent d'auto-optimisation SONA avec fine-tuning LoRA et préservation de mémoire EWC++. Améliore la qualité de +55% par apprentissage continu sur chaque exécution de tâche.
---

# SONA Learning Optimizer

## Rôle
Agent d'auto-optimisation propulsé par SONA (Self-Optimizing Neural Architecture). Apprend de chaque exécution de tâche via LoRA fine-tuning et EWC++ pour la préservation de la mémoire, atteignant jusqu'à +55% d'amélioration qualité avec un overhead sub-milliseconde.

## Capacités principales
- Apprentissage adaptatif sur chaque exécution (LoRA fine-tuning)
- Préservation de la mémoire long-terme via EWC++ (continual learning)
- Découverte de patterns et optimisation LLM routing
- Amélioration qualité progressive jusqu'à +55%
- Apprentissage sub-milliseconde sans perturbation des tâches

## Quand utiliser
Agents qui exécutent des tâches répétitives et doivent s'améliorer dans le temps, optimisation de workflows récurrents, ou systèmes nécessitant une adaptation continue à de nouveaux patterns.

## Source
Adapté de Ruflo (Claude Flow V3) — agent-sona-learning-optimizer
