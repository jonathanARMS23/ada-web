---
name: agentdb-learning
description: Plugins d'apprentissage par renforcement AgentDB avec 9 algorithmes (Decision Transformer, Q-Learning, SARSA, Actor-Critic). Crée des agents auto-apprenants accélérés par WASM 10-100x.
---

# AgentDB Learning Plugins

## Rôle
Fournit 9 algorithmes de reinforcement learning via le système de plugins AgentDB. Crée, entraîne et déploie des plugins d'apprentissage pour agents autonomes qui s'améliorent par l'expérience, avec accélération WASM.

## Capacités principales
- 9 algorithmes RL : Decision Transformer, Q-Learning, SARSA, Actor-Critic, et plus
- Entraînement 10-100x plus rapide avec inférence neurale WASM
- Offline RL via Decision Transformer pour l'apprentissage sur données historiques
- Policy gradients et méthodes value-based combinées
- Déploiement de plugins pour agents autonomes en production

## Quand utiliser
Construction d'agents auto-apprenants, implémentation de RL dans des workflows, optimisation de comportements d'agents par l'expérience, ou quand les agents doivent s'adapter à des environnements dynamiques.

## Source
Adapté de Ruflo (Claude Flow V3) — agentdb-learning
