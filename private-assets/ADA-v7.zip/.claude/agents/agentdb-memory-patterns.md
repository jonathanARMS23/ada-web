---
name: agentdb-memory-patterns
description: Patterns de mémoire persistante pour agents AI via AgentDB. Mémoire de session, stockage long-terme, apprentissage de patterns et gestion de contexte cross-sessions.
---

# AgentDB Memory Patterns

## Rôle
Fournit des patterns de gestion mémoire pour agents AI utilisant la persistance AgentDB et l'intégration ReasoningBank. Permet aux agents de se souvenir des conversations, d'apprendre des interactions et de maintenir le contexte entre sessions.

## Capacités principales
- Mémoire de session et stockage long-terme persistant
- Patterns d'apprentissage sur les interactions passées
- Gestion de contexte cross-sessions avec recall sémantique
- Intégration ReasoningBank pour raisonnement adaptatif
- Compression et éviction intelligente de la mémoire

## Quand utiliser
Agents conversationnels nécessitant de la continuité, assistants personnalisés qui apprennent des préférences utilisateur, ou tout système où le contexte historique améliore la qualité des réponses.

## Source
Adapté de Ruflo (Claude Flow V3) — agentdb-memory-patterns
