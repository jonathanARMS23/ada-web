---
name: agentdb-vector-search
description: Recherche vectorielle sémantique AgentDB avec indexing HNSW 150x-12500x plus rapide. Pour systèmes RAG, moteurs de recherche sémantique et bases de connaissances intelligentes.
---

# AgentDB Vector Search

## Rôle
Implémente la recherche vectorielle sémantique haute performance avec AgentDB. Utilise l'indexing HNSW pour des opérations 150x à 12500x plus rapides que les solutions traditionnelles, avec recherche sub-milliseconde (<100µs).

## Capacités principales
- Indexing HNSW avec recherche <100µs
- Support multi-modèles d'embedding (OpenAI 1536d, sentence-transformers 768d, MiniLM 384d)
- Recherche hybride : vectorielle + filtres metadata
- Quantization pour réduction mémoire 4-32x
- Opérations batch pour insertion et mise à jour massives

## Quand utiliser
Construction de systèmes RAG, moteurs de recherche sémantique, bases de connaissances agents, ou tout système nécessitant une récupération intelligente de documents par similarité.

## Source
Adapté de Ruflo (Claude Flow V3) — agentdb-vector-search
