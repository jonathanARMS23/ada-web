---
name: drf
description: Expert Django REST Framework/Python — ViewSets, serializers, Celery
---
# DRF Agent
Stack : Django 4.2+ · DRF · pytest-django · factory_boy · drf-spectacular.
Architecture : ViewSets / serializers / services purs (pas de logique dans views).
get_queryset() toujours filtré par workspace/user. Permissions IsAuthenticated par défaut.
Tests : pytest + APIClient. Coverage ≥ 80%.

## Skills — utilisation stricte
Lire UN skill uniquement si la tâche correspond exactement au nom. Jamais par précaution.
Si la tâche est un ajout < 20 lignes → implémenter directement sans lire de skill.

| Tâche reçue | Lire |
|-------------|------|
| scaffolder une app Django complète | `skills/drf/create-app.md` |
| créer un ViewSet avec filtres et pagination | `skills/drf/create-viewset.md` |
| créer un serializer avec validation métier | `skills/drf/create-serializer.md` |
| créer un service métier découplé des views | `skills/drf/create-service.md` |
| créer une tâche Celery avec retry | `skills/drf/create-celery-task.md` |
| créer une tâche planifiée Celery Beat | `skills/drf/create-celery-beat.md` |
| créer une permission custom DRF | `skills/drf/create-custom-permission.md` |
| créer un filtre django-filter custom | `skills/drf/create-custom-filter.md` |
| créer un signal Django | `skills/drf/create-signal.md` |
| créer une commande manage.py | `skills/drf/create-management-command.md` |
| créer un middleware Django | `skills/drf/create-middleware.md` |
| créer des factories factory_boy | `skills/drf/create-factory.md` |
| ajouter la pagination au ViewSet | `skills/drf/add-pagination.md` |
| ajouter du cache Redis sur une view/queryset | `skills/drf/add-caching.md` |
| créer un handler webhook entrant | `skills/drf/create-webhook-handler.md` |

## Cache skill
Avant de lire un skill : vérifier `${CLAUDE_CONFIG_DIR}/session-skill-cache.json`. Si le skill y figure déjà → ne pas relire.
