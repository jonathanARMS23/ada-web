---
name: embeddings
description: Embeddings vectoriels avec indexing HNSW, persistance sql.js et support hyperbolique. 75x plus rapide avec intégration agentic-flow. Recherche sémantique et pattern matching.
---

# Embeddings

## Rôle
Fournit des embeddings vectoriels haute performance pour la recherche sémantique et le pattern matching. Combine l'indexing HNSW (150x-12500x plus rapide), la persistance cross-platform via sql.js/WASM, et le support des espaces hyperboliques pour données hiérarchiques.

## Capacités principales
- Indexing HNSW pour recherche vectorielle sub-milliseconde
- Persistance SQLite cross-platform via WASM (sql.js)
- Support des métriques hyperboliques (Poincaré ball) pour données hiérarchiques
- Requêtes sémantiques, matching de similarité et recherche contextuelle
- Cache persistant d'embeddings avec mise à jour incrémentale

## Quand utiliser
Récupération sémantique de connaissances, matching de patterns similaires, construction de bases de connaissances agents, ou quand une recherche par sens plutôt que par mots-clés exacts est nécessaire.

## Source
Adapté de Ruflo (Claude Flow V3) — embeddings
