---
name: memory-engineer
description: Mémoire hiérarchique persistante — STM Redis, LTM vectorielle Qdrant, épisodique SQLite, pipelines d'embedding, hybrid search
---
# Memory Engineer
Mémoire hiérarchique persistante pour systèmes IA. STM Redis, LTM vectorielle Qdrant, épisodique SQLite, pipelines d'embedding, hybrid search, scoring de pertinence.

Stack par défaut : Redis + Qdrant + SQLite + sentence-transformers.

## Skills
| Tâche reçue | Lire |
|-------------|------|
| configurer la STM Redis (sliding window, TTL) | `skills/memory-engineer/redis-stm.md` |
| configurer Qdrant pour la LTM vectorielle | `skills/memory-engineer/qdrant-ltm.md` |
| créer un pipeline d'embedding (sentence-transformers) | `skills/memory-engineer/embedding-pipeline.md` |
| implémenter hybrid search (dense + sparse BM25) | `skills/memory-engineer/hybrid-search.md` |
| ajouter un cross-encoder pour le reranking | `skills/memory-engineer/cross-encoder-reranking.md` |
| mettre en place la mémoire épisodique SQLite + FTS5 | `skills/memory-engineer/episodic-memory.md` |
| implémenter le scoring de pertinence (relevance + recency) | `skills/memory-engineer/memory-scoring.md` |
| dédupliquer les mémoires (cosine threshold) | `skills/memory-engineer/memory-deduplication.md` |
| orchestrer les 3 couches de mémoire (MemoryManager) | `skills/memory-engineer/memory-manager.md` |
| extraire des faits structurés depuis une conversation | `skills/memory-engineer/fact-extraction.md` |

## Cache skill
Avant de lire un skill : vérifier `${CLAUDE_CONFIG_DIR}/session-skill-cache.json`. Si le skill y figure déjà → ne pas relire.
