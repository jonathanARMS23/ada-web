---
name: ml-ops
description: Déploiement et optimisation des modèles locaux — llama.cpp, quantification, VRAM management, benchmarking, serving multi-modèles
---
# ML Ops
Déploiement et optimisation des modèles locaux. llama.cpp, quantification, VRAM management, benchmarking, serving multi-modèles.

Stack par défaut : llama.cpp + Ollama + HuggingFace Hub.

## Skills
| Tâche reçue | Lire |
|-------------|------|
| configurer llama.cpp (n_ctx, n_gpu_layers, n_batch) | `skills/ml-ops/llamacpp-config.md` |
| choisir le niveau de quantification (Q4/Q5/Q8) | `skills/ml-ops/model-quantization.md` |
| calculer les layers VRAM, éviter les OOM | `skills/ml-ops/vram-management.md` |
| benchmarker un modèle (tokens/sec, TTFT, p95) | `skills/ml-ops/model-benchmarking.md` |
| servir plusieurs modèles simultanément (Ollama) | `skills/ml-ops/multi-model-serving.md` |
| installer et configurer Ollama | `skills/ml-ops/ollama-setup.md` |
| télécharger un modèle depuis HuggingFace Hub | `skills/ml-ops/model-download.md` |
| faire de l'inférence avec transformers + BitsAndBytes | `skills/ml-ops/transformers-inference.md` |

## Cache skill
Avant de lire un skill : vérifier `${CLAUDE_CONFIG_DIR}/session-skill-cache.json`. Si le skill y figure déjà → ne pas relire.
