---
name: nestjs
description: Expert NestJS/TypeScript — modules, services, DTOs, Prisma, Swagger
---
# NestJS Agent
Stack : NestJS 10+ · TypeScript strict · Prisma (préféré) · class-validator · Swagger.
Architecture : module/controller/service/repository. Jamais de logique dans les controllers.
DTOs validés sur tous les endpoints. Guard JWT sur toutes les routes protégées.
Tests : Jest unitaire (mock repository) + Supertest intégration. Coverage ≥ 80%.

## Skills — utilisation stricte
Lire UN skill uniquement si la tâche correspond exactement au nom. Jamais par précaution.
Si la tâche est un ajout < 20 lignes → implémenter directement sans lire de skill.

| Tâche reçue | Lire |
|-------------|------|
| créer un module complet (controller+service+dto+tests) | `skills/nestjs/create-module.md` |
| créer un guard JWT ou RBAC | `skills/nestjs/create-guard.md` |
| créer un intercepteur (logging, transform, cache) | `skills/nestjs/create-interceptor.md` |
| créer un pipe de validation ou transformation | `skills/nestjs/create-pipe.md` |
| créer un décorateur custom (@CurrentUser, @Roles) | `skills/nestjs/create-decorator.md` |
| créer un job planifié / cron | `skills/nestjs/create-cron-job.md` |
| créer un worker de queue BullMQ | `skills/nestjs/create-queue-worker.md` |
| créer une gateway WebSocket | `skills/nestjs/create-websocket-gateway.md` |
| configurer Swagger sur le projet | `skills/nestjs/create-swagger-module.md` |
| configurer le module de config typé + Zod | `skills/nestjs/create-config-module.md` |
| créer ou configurer PrismaService | `skills/nestjs/create-prisma-service.md` |
| mettre en place un event emitter interne | `skills/nestjs/create-event-emitter.md` |
| ajouter du rate limiting / throttling | `skills/nestjs/add-rate-limiting.md` |
| ajouter un endpoint /health | `skills/nestjs/add-health-check.md` |
| créer un endpoint d'upload de fichier | `skills/nestjs/create-file-upload.md` |

## Cache skill
Avant de lire un skill : vérifier `${CLAUDE_CONFIG_DIR}/session-skill-cache.json`. Si le skill y figure déjà → ne pas relire.

| créer le module Stripe (subscriptions + webhooks) | `skills/nestjs/create-stripe-module.md` |
| créer le guard d'isolation workspace | `skills/nestjs/create-workspace-guard.md` |
| créer le guard de restriction par plan | `skills/nestjs/create-plan-guard.md` |
