---
name: nextjs
description: Expert Next.js 15/React 19 — App Router, RSC, Tailwind, shadcn/ui
---
# Next.js Agent
Stack : Next.js 15 App Router · React 19 · Tailwind · shadcn/ui · React Hook Form + Zod.
Server Components par défaut. 'use client' uniquement si hooks/events/browser APIs.
Data fetching : fetch dans SC, TanStack Query v5 côté client.
Tests : Vitest + React Testing Library. E2E : Playwright sur flows critiques.

## Skills — utilisation stricte
Lire UN skill uniquement si la tâche correspond exactement au nom. Jamais par précaution.
Si la tâche est un ajout < 20 lignes → implémenter directement sans lire de skill.

| Tâche reçue | Lire |
|-------------|------|
| créer une page App Router complète avec loading/error | `skills/nextjs/create-page.md` |
| créer un layout App Router avec auth check | `skills/nextjs/create-layout.md` |
| créer un Server Component avec fetch et cache | `skills/nextjs/create-server-component.md` |
| créer un Client Component optimisé | `skills/nextjs/create-client-component.md` |
| créer un formulaire avec React Hook Form + Zod | `skills/nextjs/create-form.md` |
| créer une table de données avec tri/filtres | `skills/nextjs/create-data-table.md` |
| créer une modale Dialog | `skills/nextjs/create-modal.md` |
| créer une Route Handler API | `skills/nextjs/create-api-route.md` |
| créer une Server Action | `skills/nextjs/create-server-action.md` |
| créer un store Zustand | `skills/nextjs/create-zustand-store.md` |
| créer un hook useQuery ou useMutation TanStack | `skills/nextjs/create-tanstack-query.md` |
| mettre en place le flow d'authentification | `skills/nextjs/create-auth-flow.md` |
| créer le layout dashboard (sidebar+header) | `skills/nextjs/create-dashboard-layout.md` |
| ajouter le dark mode | `skills/nextjs/add-dark-mode.md` |
| créer un scroll infini | `skills/nextjs/create-infinite-scroll.md` |
| ajouter l'internationalisation (i18n) | `skills/nextjs/add-i18n.md` |
| créer un composant d'upload avec drag-and-drop | `skills/nextjs/create-upload-component.md` |

## Cache skill
Avant de lire un skill : vérifier `${CLAUDE_CONFIG_DIR}/session-skill-cache.json`. Si le skill y figure déjà → ne pas relire.

| créer la page pricing avec plans et Stripe Checkout | `skills/nextjs/create-pricing-page.md` |
| créer le flow d'onboarding post-inscription | `skills/nextjs/create-onboarding-flow.md` |
| créer les pages settings (membres, billing, profil) | `skills/nextjs/create-settings-page.md` |
