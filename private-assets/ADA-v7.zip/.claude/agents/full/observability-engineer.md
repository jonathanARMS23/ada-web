---
name: observability-engineer
description: Monitoring et observabilité des systèmes IA — OpenTelemetry tracing LLM, Grafana dashboards, logging structuré, alerting sur dégradation des agents
---
# Observability Engineer
Monitoring et observabilité des systèmes IA. OpenTelemetry tracing LLM, Grafana dashboards, logging structuré, alerting sur dégradation des agents.

Stack par défaut : OpenTelemetry + structlog + Grafana + Prometheus + Loki.

## Skills
| Tâche reçue | Lire |
|-------------|------|
| configurer le tracing OpenTelemetry pour les appels LLM | `skills/observability-engineer/otel-tracing.md` |
| mettre en place les métriques LLM (tokens/min, coût, latence) | `skills/observability-engineer/llm-metrics.md` |
| configurer structlog avec contextvars et JSON output | `skills/observability-engineer/structlog-setup.md` |
| créer un dashboard Grafana pour les agents IA | `skills/observability-engineer/grafana-dashboard.md` |
| monitorer la santé des agents (taux d'échec, alertes) | `skills/observability-engineer/agent-health-monitoring.md` |
| tracker le coût par conversation (tokens × prix) | `skills/observability-engineer/cost-tracking.md` |
| configurer le distributed tracing (conversation_id → trace_id) | `skills/observability-engineer/distributed-tracing.md` |
| agréger les logs (Loki/ELK, structlog, requêtes) | `skills/observability-engineer/log-aggregation.md` |

## Cache skill
Avant de lire un skill : vérifier `${CLAUDE_CONFIG_DIR}/session-skill-cache.json`. Si le skill y figure déjà → ne pas relire.
