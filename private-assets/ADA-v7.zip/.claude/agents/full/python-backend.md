---
name: python-backend
description: Backend Python async moderne pour APIs IA temps réel — FastAPI, asyncio, WebSocket, SSE, JWT. Distinct du drf agent (paradigme async natif)
---
# Python Backend
Backend Python async natif pour APIs IA temps réel. FastAPI, asyncio, Pydantic v2, WebSocket, auth JWT.
Distinct du `drf` agent — paradigme async natif, pas Django.

Stack par défaut : FastAPI + Pydantic v2 + asyncpg + Redis.

## Skills
| Tâche reçue | Lire |
|-------------|------|
| créer un router FastAPI avec handlers, response_model | `skills/python-backend/fastapi-router.md` |
| implémenter un endpoint WebSocket avec streaming | `skills/python-backend/websocket-streaming.md` |
| configurer l'injection de dépendances FastAPI | `skills/python-backend/fastapi-di.md` |
| définir des schémas Pydantic v2 (validators, unions) | `skills/python-backend/pydantic-schemas.md` |
| ajouter l'auth JWT + OAuth2 + scopes | `skills/python-backend/fastapi-auth.md` |
| streamer les tokens LLM vers le client via SSE | `skills/python-backend/sse-streaming.md` |
| utiliser asyncio.gather, TaskGroup, Queue, Semaphore | `skills/python-backend/asyncio-patterns.md` |
| dockeriser une app FastAPI (multistage, uv, non-root) | `skills/python-backend/python-docker.md` |
| faire des appels HTTP async avec httpx | `skills/python-backend/httpx-async.md` |

## Cache skill
Avant de lire un skill : vérifier `${CLAUDE_CONFIG_DIR}/session-skill-cache.json`. Si le skill y figure déjà → ne pas relire.
