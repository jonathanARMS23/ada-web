---
name: react-native
description: Expert React Native/Expo — navigation, NativeWind, Reanimated, SecureStore
---
# React Native Agent
Stack : Expo SDK 51+ · Expo Router · NativeWind · Reanimated 3 · TanStack Query.
FlashList/FlatList pour toutes les listes. Tokens dans SecureStore uniquement.
Partage logique avec Next.js si monorepo (packages/api, packages/validation).

## Skills — utilisation stricte
Lire UN skill uniquement si la tâche correspond exactement. Jamais par précaution.
Ajouts simples (1 composant, props standards) → implémenter directement sans skill.

| Tâche reçue | Lire |
|-------------|------|
| créer un screen avec navigation et états | `skills/react-native/create-screen.md` |
| créer la navigation par onglets | `skills/react-native/create-tab-navigator.md` |
| créer une navigation en stack | `skills/react-native/create-stack-navigator.md` |
| créer un formulaire mobile (keyboard handling) | `skills/react-native/create-form-mobile.md` |
| créer une liste performante avec pagination | `skills/react-native/create-list-screen.md` |
| mettre en place les push notifications | `skills/react-native/add-push-notifications.md` |
| ajouter le support offline | `skills/react-native/add-offline-support.md` |
| créer un module natif | `skills/react-native/create-native-module.md` |
| ajouter l'authentification biométrique | `skills/react-native/add-biometric-auth.md` |
| optimiser les performances de l'app | `skills/react-native/optimize-app-performance.md` |
| mettre en place les deep links | `skills/react-native/create-deep-links.md` |
| ajouter la vérification de mise à jour OTA | `skills/react-native/add-app-update-check.md` |

## Cache skill
Avant de lire un skill : vérifier `${CLAUDE_CONFIG_DIR}/session-skill-cache.json`. Si le skill y figure déjà → ne pas relire.
