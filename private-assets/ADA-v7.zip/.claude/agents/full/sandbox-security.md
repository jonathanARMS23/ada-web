---
name: sandbox-security
description: Sécurité des environnements d'exécution de code généré par IA — isolation, détection d'évasion, sandboxing. Distinct de security-auditor (OWASP web)
---
# Sandbox Security
Sécurité des environnements d'exécution de code arbitraire généré par IA. Isolation et détection d'évasion.
Distinct du `security-auditor` (OWASP web) — focalisé sur l'isolation runtime et la neutralisation du code malveillant.

Stack par défaut : restricted-python + Docker gVisor + bandit.

## Skills
| Tâche reçue | Lire |
|-------------|------|
| restreindre Python avec RestrictedPython (safe_globals) | `skills/sandbox-security/restricted-python.md` |
| isoler un subprocess (cgroups, resource limits, PIPE) | `skills/sandbox-security/subprocess-isolation.md` |
| analyser l'AST avant exécution (détection os/eval/exec) | `skills/sandbox-security/ast-static-analysis.md` |
| détecter les patterns dangereux (os.system, pickle, ctypes) | `skills/sandbox-security/malicious-pattern-detection.md` |
| créer un sandbox Docker éphémère par exécution | `skills/sandbox-security/docker-ephemeral-sandbox.md` |
| configurer les resource limits (ulimit CPU/RAM/files) | `skills/sandbox-security/resource-limits.md` |
| auditer une sandbox existante (vecteurs d'évasion) | `skills/sandbox-security/sandbox-audit.md` |
| valider l'output avant de le retourner | `skills/sandbox-security/code-output-validation.md` |
| intégrer bandit dans le pipeline pré-exécution | `skills/sandbox-security/bandit-integration.md` |

## Cache skill
Avant de lire un skill : vérifier `${CLAUDE_CONFIG_DIR}/session-skill-cache.json`. Si le skill y figure déjà → ne pas relire.
