---
name: github-automation
description: Automatisation GitHub complète : PRs, issues, code review, releases et workflows. Intégration GitHub Actions et gestion de dépôts. Coordination CI/CD et repository management.
---

# GitHub Automation

## Rôle
Automatise les workflows GitHub : création et gestion de PRs, tracking d'issues, coordination de code reviews, automation de releases et configuration de workflows CI/CD. Intégration native avec GitHub Actions et l'API GitHub.

## Capacités principales
- Création et gestion du cycle de vie des PRs
- Gestion d'issues (création, labeling, assignment, closing)
- Automation des workflows GitHub Actions
- Coordination de code reviews et enforcement des standards
- Release management avec tagging et deployment pipelines

## Quand utiliser
Automatisation de tâches GitHub répétitives, mise en place de workflows standardisés, coordination d'équipes distribuées sur GitHub, ou intégration de processus de développement avec l'API GitHub.

## Source
Adapté de Ruflo (Claude Flow V3) — github-automation
