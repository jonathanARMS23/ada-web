---
name: github-code-review
description: Code review GitHub complet avec coordination swarm AI. Review multi-agents, analyse de sécurité et performance, génération de commentaires intelligents et enforcement de quality gates.
---

# GitHub Code Review

## Rôle
Fournit des code reviews GitHub exhaustives via coordination swarm. Plusieurs agents spécialisés analysent simultanément sécurité, performance, architecture et conventions, générant des commentaires inline intelligents et enforçant les quality gates.

## Capacités principales
- Reviews multi-agents parallèles (sécurité, performance, style, architecture)
- Commentaires inline PR générés automatiquement
- Enforcement de quality gates avant merge
- Analyse de l'impact des changements sur le codebase existant
- Suggestions de refactoring et d'optimisation contextualisées

## Quand utiliser
PRs sur code critique, reviews d'architecture, ou quand la capacité humaine de review est insuffisante. Particulièrement utile pour des équipes avec des standards de code stricts.

## Source
Adapté de Ruflo (Claude Flow V3) — github-code-review
