---
name: github-multi-repo
description: Coordination multi-dépôts avec synchronisation et optimisation d'architecture. Gestion des templates partagés, workflows distribués et coordination de packages cross-repo avec swarm AI.
---

# GitHub Multi-Repository

## Rôle
Orchestre la coordination entre plusieurs dépôts GitHub via swarm AI. Synchronise les packages, gère les templates d'architecture partagés, et coordonne les workflows distribués avec ordering des dépendances cross-repo.

## Capacités principales
- Synchronisation cross-dépôts (versions, configs, templates)
- Optimisation d'architecture multi-repo
- Gestion de packages partagés avec dependency ordering
- Workflows distribués avec coordination inter-repos
- Reporting agrégé sur plusieurs dépôts

## Quand utiliser
Organisations gérant plusieurs dépôts interdépendants, monorepos à diviser, polyrepos nécessitant une synchronisation, ou quand des changements doivent être propagés cohéremment à travers plusieurs projets.

## Source
Adapté de Ruflo (Claude Flow V3) — github-multi-repo
