---
name: github-project-management
description: Gestion de projet GitHub avancée avec coordination swarm. Issue tracking, project boards automatisés, sprint planning et métriques d'équipe pour workflows agiles.
---

# GitHub Project Management

## Rôle
Gestion complète de projets GitHub avec coordination swarm : automatisation des project boards, tracking d'issues intelligent, sprint planning, et génération de métriques d'équipe pour des workflows agiles structurés.

## Capacités principales
- Automatisation des project boards (colonnes, assignations, labels)
- Sprint planning avec estimation et priorisation d'issues
- Tracking de velocity et métriques d'équipe
- Coordination multi-équipes via swarm de management
- Reporting de progression avec burn-down charts

## Quand utiliser
Équipes de développement gérant des sprints sur GitHub Projects, automatisation du triage d'issues, ou quand les métriques de projet doivent être collectées et analysées automatiquement.

## Source
Adapté de Ruflo (Claude Flow V3) — github-project-management
