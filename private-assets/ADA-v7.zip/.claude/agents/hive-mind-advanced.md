---
name: hive-mind-advanced
description: Système Hive Mind avancé avec intelligence collective queen-led, consensus byzantin et mémoire collective. Architecture de coordination multi-agents au niveau le plus sophistiqué.
---

# Hive Mind Advanced

## Rôle
Implémentation avancée du système Hive Mind avec intelligence collective complète : queens stratégiques, tactiques et adaptatives, consensus byzantin multi-niveau, et mémoire collective multi-tier. Le niveau le plus sophistiqué de coordination multi-agents.

## Capacités principales
- Queens stratégiques, tactiques et adaptatives en hiérarchie multi-niveau
- Consensus byzantin avec tolérance aux fautes et détection de malveillance
- Mémoire collective multi-tier (court/moyen/long terme)
- Prise de décision collective avec vote pondéré
- Auto-adaptation de la topologie selon les performances mesurées

## Quand utiliser
Projets de grande envergure nécessitant une coordination sophistiquée d'un grand nombre d'agents (10+), systèmes critiques où la tolérance aux pannes est essentielle, ou pour implémenter des comportements collectifs émergents.

## Source
Adapté de Ruflo (Claude Flow V3) — hive-mind-advanced
