---
name: hive-mind
description: Consensus byzantin fault-tolerant et coordination distribuée de swarms. Gestion hiérarchique queen-led avec stratégies de consensus multiples et mémoire persistante collective.
---

# Hive Mind

## Rôle
Système de coordination distribuée avec consensus byzantin fault-tolerant. Architecture queen-led hiérarchique pour la gestion de swarms complexes, avec plusieurs stratégies de consensus et mémoire persistante partagée entre agents.

## Capacités principales
- Coordination distribuée avec tolérance aux fautes byzantines
- Architecture queen→workers hiérarchique ou mesh selon le besoin
- Stratégies de consensus multiples (hierarchical, mesh, adaptive)
- Mémoire collective persistante partagée entre agents
- Détection de drift et mécanismes anti-divergence

## Quand utiliser
Opérations distribuées nécessitant une tolérance aux pannes maximale, décision collective entre agents, coordination de tâches complexes sur plusieurs agents en parallèle, ou workflows nécessitant un état cohérent partagé.

## Source
Adapté de Ruflo (Claude Flow V3) — hive-mind
