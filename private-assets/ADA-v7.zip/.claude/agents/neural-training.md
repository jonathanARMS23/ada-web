---
name: neural-training
description: Entraînement de patterns neuraux avec SONA, MoE (Mixture of Experts) et EWC++ pour consolidation de connaissances. Apprentissage adaptatif, routing LLM et transfer de connaissances.
---

# Neural Training

## Rôle
Entraîne et optimise des patterns neuraux via SONA (Self-Optimizing Neural Architecture), Mixture of Experts pour le routing LLM, et EWC++ pour la préservation des connaissances existantes lors de l'apprentissage de nouvelles.

## Capacités principales
- Entraînement SONA pour auto-optimisation continue
- Mixture of Experts pour routing LLM intelligent selon la tâche
- EWC++ pour apprentissage continu sans oubli catastrophique
- Transfer learning et adaptation de domaine
- Consolidation et distillation de connaissances

## Quand utiliser
Optimisation du routage entre modèles LLM, adaptation de modèles à des domaines spécialisés, systèmes d'apprentissage continu, ou construction de pipelines ML nécessitant la préservation des connaissances antérieures.

## Source
Adapté de Ruflo (Claude Flow V3) — neural-training
