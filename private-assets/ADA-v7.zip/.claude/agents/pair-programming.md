---
name: pair-programming
description: Pair programming AI avec modes multiples (driver/navigator/switch/TDD/debug/mentor). Vérification temps réel, scoring de qualité, génération automatique de tests et sessions persistantes.
---

# Pair Programming

## Rôle
Fournit une collaboration pair programming AI professionnelle avec gestion intelligente des rôles. Supporte les modes driver/navigator/switch, le TDD, le debugging, le refactoring et le mentoring. Monitore la qualité en continu avec rollback automatique sur régression.

## Capacités principales
- Modes multiples : Driver, Navigator, Switch, TDD, Review, Mentor, Debug
- Vérification temps réel avec quality scoring (0.0-1.0) et rollback sur échec
- Génération automatique de tests et suivi de la couverture
- Code review intégré : sécurité, performance, bonnes pratiques
- Sessions persistantes avec auto-sauvegarde et reprise

## Quand utiliser
Sessions de développement interactives nécessitant un feedback continu, apprentissage de nouvelles technologies avec guidance, debugging complexe bénéficiant d'une seconde perspective, ou implementation de features critiques nécessitant une double vérification.

## Source
Adapté de Ruflo (Claude Flow V3) — pair-programming
