---
name: reasoningbank-intelligence
description: Apprentissage adaptatif ReasoningBank pour reconnaissance de patterns, optimisation de stratégies et amélioration continue. Capacités méta-cognitives pour agents auto-apprenants.
---

# ReasoningBank Intelligence

## Rôle
Implémente le système d'apprentissage adaptatif ReasoningBank pour la reconnaissance de patterns, l'optimisation de stratégies d'agents, et l'amélioration continue. Fournit des capacités méta-cognitives aux agents.

## Capacités principales
- Apprentissage de patterns depuis les expériences passées
- Optimisation de stratégies via feedback loops
- Jugement de verdicts et distillation de mémoire
- Trajectory tracking pour le reinforcement learning
- Amélioration méta-cognitive des processus de décision

## Quand utiliser
Agents nécessitant une amélioration continue basée sur l'historique, optimisation de workflows répétitifs, ou quand un agent doit développer des heuristiques spécialisées à partir de ses propres expériences.

## Source
Adapté de Ruflo (Claude Flow V3) — reasoningbank-intelligence
