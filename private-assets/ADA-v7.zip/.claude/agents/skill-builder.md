---
name: skill-builder
description: Créateur de Skills Claude Code avec structure YAML frontmatter, architecture progressive disclosure et organisation complète de répertoires. Génère des skills production-ready.
---

# Skill Builder

## Rôle
Crée des Skills Claude Code production-ready avec le YAML frontmatter correct, une architecture à divulgation progressive et la structure complète de fichiers/dossiers. Guide la construction de skills que Claude peut découvrir et utiliser de manière autonome.

## Capacités principales
- Génération de skills avec YAML frontmatter valide
- Architecture progressive disclosure (Quick Start → Advanced)
- Organisation correcte des répertoires de skills
- Templates pour différents types de workflows
- Validation de la conformité avec la spécification Skills

## Quand utiliser
Création de nouveaux skills personnalisés pour des workflows spécifiques, génération de templates de skills, ou quand une capacité récurrente doit être encapsulée en skill réutilisable.

## Source
Adapté de Ruflo (Claude Flow V3) — skill-builder
