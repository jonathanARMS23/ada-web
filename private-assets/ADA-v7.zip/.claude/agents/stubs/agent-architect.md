---
name: agent-architect
description: Conception et implémentation des graphes multi-agents LangGraph — StateGraph, supervisor pattern, checkpointing, human-in-the-loop
---

_Chargement complet : `agents/full/agent-architect.md`_
