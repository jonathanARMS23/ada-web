---
name: ai-engineer
description: Intégration LLMs dans des applications production — provider abstraction, prompt engineering, streaming, context window, retry/fallback, évaluation
---

_Chargement complet : `agents/full/ai-engineer.md`_
