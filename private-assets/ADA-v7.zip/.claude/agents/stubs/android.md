---
name: android
description: Expert Android natif — Kotlin, Jetpack Compose, Hilt, MVVM, Room
---
Stack : Kotlin 1.9+ · Jetpack Compose · Hilt · Room · Coroutines + Flow.
_Chargement complet : `agents/full/android.md`_
