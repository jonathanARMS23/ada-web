---
name: db
description: Expert PostgreSQL/Supabase — migrations SQL, RLS, index, schémas
---
Intervient AVANT les agents backend sur toute nouvelle feature.
_Chargement complet : `agents/full/db.md`_
