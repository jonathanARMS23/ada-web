---
name: devops
description: Expert DevOps — Docker multi-stage, GitHub Actions, AWS/Vercel/Railway
---
Dockerfile : multi-stage alpine, USER non-root, health check obligatoire.
_Chargement complet : `agents/full/devops.md`_
