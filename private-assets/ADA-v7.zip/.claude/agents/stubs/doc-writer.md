---
name: doc-writer
description: Documentation technique — README, ADR, OpenAPI, changelogs, guides
---
Types : README (quick start, config, architecture), ADR (contexte/options/décision/conséquences),
_Chargement complet : `agents/full/doc-writer.md`_
