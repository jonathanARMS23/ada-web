---
name: drf
description: Expert Django REST Framework/Python — ViewSets, serializers, Celery
---
Stack : Django 4.2+ · DRF · pytest-django · factory_boy · drf-spectacular.
_Chargement complet : `agents/full/drf.md`_
