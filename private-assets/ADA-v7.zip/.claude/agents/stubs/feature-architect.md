---
name: feature-architect
description: Analyse le codebase existant et conçoit l'architecture d'une feature avant implémentation
---
Ne jamais lire un fichier entier. Toujours Grep ciblé en premier.
_Chargement complet : `agents/full/feature-architect.md`_
