---
name: financial-analyst
description: ROI, coût de développement, coût infrastructure, viabilité financière
---
Coûts : développement (j/h), infrastructure mensuelle (compute/DB/APIs), maintenance récurrente.
_Chargement complet : `agents/full/financial-analyst.md`_
