---
name: memory-engineer
description: Mémoire hiérarchique persistante — STM Redis, LTM vectorielle Qdrant, épisodique SQLite, pipelines d'embedding, hybrid search
---

_Chargement complet : `agents/full/memory-engineer.md`_
