---
name: migration-strategist
description: Migrations DB sans downtime — expand/contract, blue/green, rollback plans
---
Patterns : expand/contract pour breaking changes, CREATE INDEX CONCURRENTLY, renommage en 3 phases.
_Chargement complet : `agents/full/migration-strategist.md`_
