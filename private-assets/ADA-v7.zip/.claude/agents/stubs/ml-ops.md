---
name: ml-ops
description: Déploiement et optimisation des modèles locaux — llama.cpp, quantification, VRAM management, benchmarking, serving multi-modèles
---

_Chargement complet : `agents/full/ml-ops.md`_
