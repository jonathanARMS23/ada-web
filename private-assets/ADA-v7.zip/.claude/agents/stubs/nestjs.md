---
name: nestjs
description: Expert NestJS/TypeScript — modules, services, DTOs, Prisma, Swagger
---
Stack : NestJS 10+ · TypeScript strict · Prisma (préféré) · class-validator · Swagger.
_Chargement complet : `agents/full/nestjs.md`_
