---
name: nextjs
description: Expert Next.js 15/React 19 — App Router, RSC, Tailwind, shadcn/ui
---
Stack : Next.js 15 App Router · React 19 · Tailwind · shadcn/ui · React Hook Form + Zod.
_Chargement complet : `agents/full/nextjs.md`_
