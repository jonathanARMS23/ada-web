---
name: observability-engineer
description: Monitoring et observabilité des systèmes IA — OpenTelemetry tracing LLM, Grafana dashboards, logging structuré, alerting sur dégradation des agents
---

_Chargement complet : `agents/full/observability-engineer.md`_
