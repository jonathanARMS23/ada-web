---
name: onboarding-agent
description: Analyse un projet inconnu et produit un brief complet pour démarrer rapidement
---
Explorer avec des commandes légères, pas des lectures de fichiers complets.
_Chargement complet : `agents/full/onboarding-agent.md`_
