---
name: perception-engineer
description: Pipelines de perception multimodale temps réel — STT faster-whisper + VAD, vision LLaVA + CLIP, TTS Piper, latence end-to-end < 800ms
---

_Chargement complet : `agents/full/perception-engineer.md`_
