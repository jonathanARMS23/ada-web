---
name: performance-analyst
description: Détecte les bottlenecks — N+1, index manquants, bundle, re-renders
---
Backend : requêtes N+1, index manquants, EXPLAIN ANALYZE, payloads surdimensionnés.
_Chargement complet : `agents/full/performance-analyst.md`_
