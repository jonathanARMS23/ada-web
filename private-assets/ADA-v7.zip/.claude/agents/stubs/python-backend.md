---
name: python-backend
description: Backend Python async moderne pour APIs IA temps réel — FastAPI, asyncio, WebSocket, SSE, JWT. Distinct du drf agent (paradigme async natif)
---

_Chargement complet : `agents/full/python-backend.md`_
