---
name: react-native
description: Expert React Native/Expo — navigation, NativeWind, Reanimated, SecureStore
---
Stack : Expo SDK 51+ · Expo Router · NativeWind · Reanimated 3 · TanStack Query.
_Chargement complet : `agents/full/react-native.md`_
