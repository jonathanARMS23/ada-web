---
name: sandbox-security
description: Sécurité des environnements d'exécution de code généré par IA — isolation, détection d'évasion, sandboxing. Distinct de security-auditor (OWASP web)
---

_Chargement complet : `agents/full/sandbox-security.md`_
