---
name: swift
description: Expert iOS natif — SwiftUI, Swift 5.9+, MVVM, async/await, Keychain
---
Stack : SwiftUI · Swift 5.9+ · async/await · @MainActor · SwiftData ou CoreData.
_Chargement complet : `agents/full/swift.md`_
