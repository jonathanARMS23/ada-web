---
name: ux-designer
description: User flows, wireframes textuels et specs d'interaction avant le frontend
---
Intervient AVANT l'agent nextjs. Produire : user flow, wireframes textuels ASCII, états UI,
_Chargement complet : `agents/full/ux-designer.md`_
