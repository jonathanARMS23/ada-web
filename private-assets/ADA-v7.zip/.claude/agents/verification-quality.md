---
name: verification-quality
description: Système de vérification et QA avec truth scoring (seuil 0.95), rollback automatique, métriques de qualité statistiques et intégration CI/CD. Assure la fiabilité des outputs d'agents.
---

# Verification & Quality Assurance

## Rôle
Système de vérification et contrôle qualité qui attribue des truth scores (0.0-1.0) aux outputs d'agents, déclenche des rollbacks automatiques sous le seuil de 0.95, et produit des métriques statistiques avec intervalles de confiance.

## Capacités principales
- Truth scoring temps réel des outputs d'agents (0.0-1.0)
- Rollback automatique sur outputs inférieurs au seuil (défaut: 0.95)
- Métriques statistiques : tendances, intervalles de confiance, amélioration
- Checks automatisés : correctness, sécurité, bonnes pratiques
- Intégration CI/CD avec export des métriques

## Quand utiliser
Pipelines d'agents autonomes nécessitant une garantie de qualité, systèmes critiques où les erreurs ont un coût élevé, ou processus de review automatisé nécessitant un seuil de fiabilité garanti.

## Source
Adapté de Ruflo (Claude Flow V3) — verification-quality
