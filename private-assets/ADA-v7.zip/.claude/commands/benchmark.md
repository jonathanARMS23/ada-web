# /benchmark — Benchmark A/B : ADA vs Claude Code nu

Exécute une ou plusieurs tâches de la suite benchmark **deux fois** (mode ADA complet vs mode Claude Code nu), capture les métriques réelles (coût/itérations/qualité/latence) et produit un rapport comparatif. Sert à prouver/chiffrer la thèse coût d'ADA.

## Usage
```
/benchmark [taskId | all] [--arms ada,naked] [--report-only] [--reset]
```

## Exemples
```
/benchmark                      # toutes les tâches, les 2 bras, puis rapport
/benchmark db-migration         # une seule tâche, les 2 bras
/benchmark all --report-only    # affiche juste le rapport courant
/benchmark --reset              # réinitialise les résultats
```

---

## Instructions pour l'orchestrateur

Arguments : **$ARGUMENTS**

> Prérequis : Ollama doit tourner (`brew services list | grep ollama` → `started`) pour le LLM-judge et les embeddings. Sinon le score qualité sera absent.

### Étape 0 — Cas rapides

- Si `--reset` → `node coordinator/benchmark.js reset` puis STOP.
- Si `--report-only` → `node coordinator/benchmark.js report` puis STOP.
- Sinon, lister les tâches : `node coordinator/benchmark.js tasks`. Si un taskId est donné, ne traiter que celui-ci ; sinon traiter **toutes** les tâches.
- Bras à exécuter : `ada` et `naked` par défaut (override via `--arms`).

### Étape 1 — Pour CHAQUE tâche, exécuter les 2 bras

Récupère le `prompt`, le `profile` et la `rubric` de la tâche depuis `benchmarks/tasks.json`.

#### Bras `ada` (traitement ADA complet)
1. `node coordinator/benchmark.js start <taskId> ada`
2. Exécute la tâche **via le pipeline ADA** : détecte le profil (champ `profile` de la tâche), délègue à l'agent recommandé par le router (`node coordinator/router.js recommend <phase>` pour l'agent + le tier/modèle), avec injection mémoire ACW. Compte le **nombre d'itérations** (tours d'agent + corrections) jusqu'à un résultat satisfaisant.
3. Écris le livrable final de l'agent dans `/tmp/bench-<taskId>-ada.txt`.
4. `node coordinator/benchmark.js finish <taskId> ada --iterations <N> --output-file /tmp/bench-<taskId>-ada.txt`

#### Bras `naked` (Claude Code nu)
1. `node coordinator/benchmark.js start <taskId> naked`
2. Exécute la **même tâche** avec **un seul agent générique**, **sans** coordinator, **sans** routing, **sans** injection mémoire/ACW (simulation Claude Code vanilla). Compte les itérations.
3. Écris le livrable dans `/tmp/bench-<taskId>-naked.txt`.
4. `node coordinator/benchmark.js finish <taskId> naked --iterations <N> --output-file /tmp/bench-<taskId>-naked.txt`

> Équité : les deux bras reçoivent le **même prompt** et sont jugés sur la **même rubrique**. Le `finish` calcule automatiquement les tokens/coût (delta transcript), la latence, et lance le LLM-judge sur le livrable.

### Étape 2 — Rapport
```bash
node coordinator/benchmark.js report
```

### Étape 3 — Synthèse

Présente le tableau du rapport et conclus explicitement sur la **thèse coût d'ADA** :
- ✅ validée si **qualité↑ + itérations↓** (même si tokens↑ par l'injection mémoire)
- ❌ infirmée si ADA ne fait pas mieux en qualité/itérations malgré le surcoût

Sois honnête : si l'échantillon est petit (1 run/bras), signale que le résultat est indicatif, pas statistiquement significatif. Recommande d'étendre `benchmarks/tasks.json` et de répéter les runs pour une mesure fiable.
