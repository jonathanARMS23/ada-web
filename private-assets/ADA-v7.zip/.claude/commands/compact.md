# /compact — Compresser le contexte (auto ou manuel)

Déclenché automatiquement au 7ème échange ou manuellement.

## Usage
```
/compact          # compression manuelle
/compact --status # volume de contexte estimé
```

---

## Instructions

### Produire le bloc de continuation

```markdown
## Contexte compressé — [date heure]

**Projet :** ${AI_DEV_PROJECT}
**Profil actif :** [profil du dernier échange]
**Échanges cette session :** 7

**Accompli :**
- [liste courte — max 5 items]

**Décisions :**
- [liste courte — max 3 items]

**Fichiers modifiés :**
- [liste]

**Prochaine étape :** [1 phrase précise]

**Blockers :** [si présents, sinon omettre]
```

### Afficher les instructions

```
🔄 Compact effectué.

1. Tape /clear (commande native Claude Code)
2. Comme premier message, colle :

---
[bloc contexte compressé ci-dessus]
---

Cela repart avec ~95% de tokens économisés sur l'historique.
```

### Sauvegarder dans la mémoire projet

```bash
TIMESTAMP=$(date +%Y-%m-%d_%H%M)
DIR="${CLAUDE_CONFIG_DIR}/.claude/memory/projects/${AI_DEV_PROJECT:-workspace}/archive"
mkdir -p "$DIR"
# Le contenu du bloc compact est appendé automatiquement
```

### Réinitialiser le cache de session

```bash
# Vider le cache des skills lus et l'état de session
node "${CLAUDE_CONFIG_DIR}/hooks/reset-session-cache.js"
```

Ce reset est obligatoire après chaque /compact. Le cache skill et le compteur d'échanges du stop-hook sont invalidés — la prochaine session repart à zéro.
