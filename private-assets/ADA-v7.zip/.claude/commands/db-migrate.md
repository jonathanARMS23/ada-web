# /db-migrate — Génère et applique une migration SQL

Délègue à l'agent DB pour créer une migration propre, puis l'applique.

## Usage
```
/db-migrate <description> [--dry-run] [--rollback]
```

## Exemples
```
/db-migrate "add invoices table with line items"
/db-migrate "add status column to users" --dry-run
/db-migrate --rollback    # rollback de la dernière migration
```

---

## Instructions pour l'orchestrateur

Description : **$ARGUMENTS**

### Étape 1 — Si --rollback

```bash
# Identifier la dernière migration
ls -t migrations/*.sql | head -1

# Chercher le fichier rollback correspondant
ls migrations/rollback/$(basename <last_migration>)
```

Délègue à l'agent **db** :
```
Rollback de la migration : [nom du fichier]
Contenu : [contenu du fichier rollback]
Appliquer le rollback sur la DB.
```

### Étape 2 — Génération de la migration

Délègue à l'agent **db** :

```
Génère une migration SQL complète pour : $ARGUMENTS

Conventions obligatoires :
- begin/commit atomique
- uuid PK avec gen_random_uuid()
- created_at timestamptz not null default now()
- updated_at avec trigger set_updated_at()
- soft delete (deleted_at) si table métier
- workspace_id si table multi-tenant
- Index sur FK + colonnes filtrées
- RLS Supabase (service_role full + authenticated read par workspace)
- Fichier rollback correspondant

Produire :
1. up_migration.sql
2. down_migration.sql (rollback)
```

### Étape 3 — Dry-run si demandé

Si `--dry-run` dans $ARGUMENTS :
- Afficher le SQL généré
- Ne pas exécuter
- STOP

### Étape 4 — Appliquer la migration

**Via Supabase MCP :**
```
Outil : supabase/execute_sql
SQL : [contenu de la migration]
```

**Ou via Bash (si connexion directe) :**
```bash
psql $DATABASE_URL -f migrations/<timestamp>_<slug>.sql
```

### Étape 5 — Vérifier l'application

```bash
# Vérifier que les tables/colonnes existent
psql $DATABASE_URL -c "\dt"
psql $DATABASE_URL -c "\d <table_name>"
```

### Étape 6 — Sauvegarder

```bash
TIMESTAMP=$(date +%Y%m%d%H%M%S)
SLUG=$(echo "$ARGUMENTS" | tr ' ' '_' | tr '[:upper:]' '[:lower:]' | cut -c1-40)
mkdir -p migrations migrations/rollback

cp up_migration.sql   "migrations/${TIMESTAMP}_${SLUG}.sql"
cp down_migration.sql "migrations/rollback/${TIMESTAMP}_${SLUG}_rollback.sql"
```

### Étape 7 — Résumé

```markdown
## Migration — [description]

**Status  : ✅ Appliquée / 🔍 Dry-run / ❌ Échec**
**Fichier : migrations/<timestamp>_<slug>.sql**
**Rollback: migrations/rollback/<timestamp>_<slug>_rollback.sql**

### Objets créés/modifiés
- Tables : [liste]
- Index  : [liste]
- Triggers : [liste]
- Policies RLS : [liste]

### Rollback
Pour annuler : /db-migrate --rollback
```
