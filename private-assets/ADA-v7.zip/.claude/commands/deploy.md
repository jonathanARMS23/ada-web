# /deploy — Build, push et déploiement

Orchestre le déploiement complet : build Docker, push registry, déclenchement pipeline.

## Usage
```
/deploy <env> [--service <nom>] [--skip-tests] [--dry-run]
```

## Environnements valides
- `staging` — déploiement sur staging (auto)
- `production` — déploiement production (confirmation manuelle requise)

## Exemples
```
/deploy staging
/deploy staging --service api
/deploy production --dry-run
/deploy production
```

---

## Instructions pour l'orchestrateur

Environnement cible : **$ARGUMENTS**

### Garde-fous immédiats

Avant toute action, vérifier :

```bash
# 1. Branche courante
git rev-parse --abbrev-ref HEAD

# 2. Statut du working directory
git status --porcelain
```

**Règles bloquantes :**
- Si fichiers non commités (`git status` non vide) → STOP, demander de commiter d'abord
- Si déploiement `production` demandé depuis une branche autre que `main` → STOP
- Si déploiement `staging` demandé depuis une branche autre que `staging` → avertir mais continuer

### Étape 1 — Vérification des tests (sauf --skip-tests)

```bash
# Vérifier que les tests passent localement avant de builder
npm run test 2>&1 | tail -20
# ou pour DRF :
# pytest --tb=short -q 2>&1 | tail -20
```

Si les tests échouent → STOP sauf si `--skip-tests` explicitement passé.

### Étape 2 — Déléguer le build à l'agent devops

Délègue à l'agent **devops** :

```
Environnement : [staging|production]
Service : [nom du service ou "all"]
SHA courant : [git rev-parse --short HEAD]
Dry-run : [oui/non]

Actions à effectuer :
1. Builder l'image Docker multi-stage
   docker build --target runner -t ghcr.io/<owner>/<repo>:<sha> .

2. Tagger l'image avec l'environnement
   docker tag ghcr.io/<owner>/<repo>:<sha> ghcr.io/<owner>/<repo>:<env>

3. Pousser vers ghcr.io
   docker push ghcr.io/<owner>/<repo>:<sha>
   docker push ghcr.io/<owner>/<repo>:<env>

4. Déclencher le workflow GitHub Actions via GitHub MCP
   - Utiliser le MCP github pour déclencher workflow_dispatch
   - Workflow : deploy-<env>.yml
   - Inputs : { sha: "<sha>", service: "<service>" }

Si dry-run : simuler sans exécuter les push/dispatch
```

### Étape 3 — Confirmation pour production

Si l'environnement est `production` et que ce n'est pas un dry-run :

**Interrompre et demander confirmation explicite :**
```
⚠️  DÉPLOIEMENT PRODUCTION
Image : ghcr.io/<owner>/<repo>:<sha>
SHA   : <sha>
Branch: main

Confirmes-tu le déploiement en production ? (répondre "oui, déployer en production")
```

**Attendre** la confirmation avant de continuer.

### Étape 4 — Sauvegarde de l'état

Après un déploiement réussi :

```bash
# Sauvegarder le SHA déployé pour /revert-staging
echo "<sha>|$(date +%Y-%m-%dT%H:%M:%S)|<env>" >> .claude/archives/deploy-history.txt
```

### Étape 5 — Résumé

```markdown
## Deploy — [env]

**Status : ✅ Succès / ❌ Échec / 🔍 Dry-run**
**Image   : ghcr.io/<owner>/<repo>:<sha>**
**SHA     : <sha>**
**Branch  : <branch>**
**Durée   : ~Xs**

### Actions effectuées
- [x] Tests vérifiés
- [x] Image buildée
- [x] Image pushée sur ghcr.io
- [x] Workflow GitHub Actions déclenché

### Prochaines étapes
- Vérifier les logs du workflow : https://github.com/<owner>/<repo>/actions
- Tester sur [env] : https://<env>.votre-domaine.com
```
