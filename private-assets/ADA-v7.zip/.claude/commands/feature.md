# /feature — Scaffolde une feature complète

Scaffolde une feature complète via la state machine coordinator.
Pipeline : `schema → specs → backend → frontend → coverage → review`

## Usage
```
/feature <nom-de-la-feature> [--backend nestjs|drf] [--api-only] [--no-deploy]
```

## Exemples
```
/feature user-authentication
/feature invoice-management --backend drf
/feature dashboard-analytics --api-only
/feature payment-flow --backend nestjs --no-deploy
```

---

## Instructions pour l'orchestrateur

Tu reçois : **$ARGUMENTS**

### Étape 0 — Analyse et initialisation

**1. Parser les arguments :**
- Nom de la feature : premier argument
- `--backend drf|nestjs` : backend cible (défaut: nestjs)
- `--api-only` : pas de frontend
- `--no-deploy` : pas de phase deploy

**2. Si le périmètre est ambigu, poser MAX 3 questions :**
- Quel backend ? (si pas spécifié et projet DRF détecté)
- Frontend nécessaire ?
- Auth requise dans cette feature ?

**3. Initialiser le run (obligatoire) :**
```bash
node ${CLAUDE_CONFIG_DIR}/coordinator/run.js init feature "<nom>" [flags]
```
→ Récupérer le `runId` et le garder pour toutes les étapes suivantes.

---

### Étapes 1+2 — Schéma DB + Specs TDD (PARALLÈLE)

Ces deux étapes sont **indépendantes** — les lancer en parallèle via deux Task simultanés.
Le tester n'a pas besoin de la migration pour écrire les specs.
Le DB n'a pas besoin des specs pour créer les tables.

### Étape 1 — Schéma DB [phase: schema] [agent: db]

```bash
node ${CLAUDE_CONFIG_DIR}/coordinator/run.js start <runId> schema
```

Déléguer à l'agent **db** :
```
Feature: <nom>
Crée le schéma complet :
- Migration SQL (begin/commit, rollback)
- Colonnes : uuid PK, workspace_id, timestamps, soft delete si pertinent
- Index sur FK + colonnes filtrées/triées
- RLS Supabase : policy service_role + workspace_isolation
- Migration de rollback
Conventions : snake_case, tables plurielles
```

Si la migration est produite :
```bash
node run.js done <runId> schema "<résumé : tables créées, colonnes principales>"
```

Si échec :
```bash
node run.js fail <runId> schema "<erreur>" --retry   # max 1 retry
```
**STOP si schema échoue après retry — remonter l'erreur au développeur.**

---

### Étape 2 — Specs TDD [phase: specs] [agent: tester]

```bash
node ${CLAUDE_CONFIG_DIR}/coordinator/run.js start <runId> specs
```

Déléguer à l'agent **tester** :
```
Feature: <nom>
Schéma DB : <résumé migration étape 1>
Écris les specs TDD complètes — PAS d'implémentation :
- Comportements attendus (happy path + edge cases + erreurs)
- Fichiers de test (unitaires + intégration + E2E)
- Format : describe/it avec noms métier ("devrait retourner 404 si inexistant")
Backend: <nestjs|drf>
```

```bash
node run.js done <runId> specs "<résumé : N specs, fichiers concernés>"
```

**STOP si specs échouent — specs TDD sont prérequis à l'implémentation.**

**Attendre la completion des DEUX Tasks (schema + specs) avant de passer à l'étape 3.**

Fusionner les outputs :
- Specs du tester → à transmettre au backend
- Migration DB → à transmettre au backend

---

### Étape 3 — Backend [phase: backend] [agent: nestjs | drf]

```bash
node ${CLAUDE_CONFIG_DIR}/coordinator/run.js start <runId> backend
```

Déléguer à l'agent **nestjs** (ou **drf**) :
```
Feature: <nom>
Migration DB : <résumé étape 1>
Specs TDD à faire passer : <liste étape 2>
Implémente :
- [NestJS] Module + controller + service + repository + DTOs + Swagger
- [DRF] Views + serializers + services + urls + admin
- Tests doivent passer (ne pas en créer de nouveaux — utiliser ceux de l'étape 2)
- Pas de any TypeScript / pas de bare except Python
Endpoints créés à documenter dans le résumé.
```

```bash
node run.js done <runId> backend "<résumé : endpoints créés, modules>"
# ou si 2 tentatives max :
node run.js fail <runId> backend "<erreur>" --retry
```

---

### Étape 4 — Frontend [phase: frontend] [agent: nextjs] — sauf si --api-only

```bash
node ${CLAUDE_CONFIG_DIR}/coordinator/run.js start <runId> frontend
```
*(Si `--api-only` passé, cette phase est déjà skippée dans le state — passer directement à coverage.)*

Déléguer à l'agent **nextjs** :
```
Feature: <nom>
Endpoints disponibles : <liste étape 3>
Implémente :
- Pages App Router (Server Components par défaut)
- Formulaires : React Hook Form + Zod
- Style : Tailwind + shadcn/ui
- Intégration API typée
```

```bash
node run.js done <runId> frontend "<résumé : pages créées>"
# ou si échec (non critique, pipeline continue) :
node run.js fail <runId> frontend "<erreur>"
```

---

### Étape 5 — Coverage [phase: coverage] [agent: tester]

```bash
node ${CLAUDE_CONFIG_DIR}/coordinator/run.js start <runId> coverage
```

Déléguer à l'agent **tester** :
```
Feature: <nom>
Code implémenté. Lance les tests et vérifie :
- Les specs de l'étape 2 passent (toutes)
- Coverage services ≥ 80%
- Lister les cas non couverts avec priorité
```

```bash
node run.js done <runId> coverage "coverage: XX% — N tests passés, N échoués"
```

*(Non critique — si coverage < 80%, signaler mais continuer)*

---

### Étape 6 — Code review [phase: review] [agent: reviewer]

```bash
node ${CLAUDE_CONFIG_DIR}/coordinator/run.js start <runId> review
```

Déléguer à l'agent **reviewer** :
```
Feature: <nom>
Review le code produit (migration + backend + frontend) :
- Sécurité : injections, auth, secrets, RLS, CORS
- Performance : N+1, index manquants, bundle
- Architecture : couplage, logique dans controllers, any TypeScript
Format de rapport : critiques bloquantes ❌ / recommandations ⚠️ / suggestions 💡
```

```bash
node run.js done <runId> review "verdict: ✅|⚠️|❌ — <résumé>"
```

**Si verdict ❌ (sécurité bloquante) :**
```bash
node run.js fail <runId> review "sécurité: <description>"
# STOP — corriger les critiques bloquantes, relancer /review avant push-staging
```

---

### Étape 7 — Résumé final obligatoire

```bash
node ${CLAUDE_CONFIG_DIR}/coordinator/run.js status <runId>
```

Produire :

```markdown
## Feature: <nom> — Résumé ✅

**Run:** <runId>
**Durée totale:** <X minutes>
**Backend:** nestjs|drf

### Agents sollicités
- [x] db — schema (<durée>)
- [x] tester — specs (<durée>)
- [x] nestjs|drf — backend (<durée>)
- [x] nextjs — frontend (<durée>) | [skipped: --api-only]
- [x] tester — coverage (<coverage %>)
- [x] reviewer — verdict ✅|⚠️|❌

### Fichiers créés
**DB:** migrations/YYYY-MM-DD_<feature>.sql
**Backend:** src/modules/<feature>/<feature>.{module,controller,service,repository}.ts
**Frontend:** app/<feature>/page.tsx, components/features/<feature>/
**Tests:** src/modules/<feature>/__tests__/

### Décisions d'architecture
- <liste>

### Dettes techniques (si applicables)
- <liste ou "Aucune">

### Prochaines étapes
- [ ] `/push-staging` → merge vers staging
- [ ] Smoke test sur staging
- [ ] `/review --focus security` avant main
```
