# /fetch-sprint — Charge le contexte du sprint courant

Récupère les tâches du sprint actif depuis Linear (ou GitHub Projects),
met à jour stories.md et context.md, et injecte le contexte en L1.

## Usage
```
/fetch-sprint [--project <nom>] [--team <id>]
```

## Exemples
```
/fetch-sprint
/fetch-sprint --project my-saas
/fetch-sprint --project api-service --team backend
```

---

## Instructions pour l'orchestrateur

Projet : **$ARGUMENTS** (défaut : projet courant depuis context.md)

### Étape 1 — Récupérer les tâches via Linear MCP

```
Outil : linear/get_issues
Filtres :
  - state: "In Progress" | "Todo"
  - assignee: current user
  - limit: 20

Outil : linear/get_cycle (sprint courant)
```

Si Linear MCP non disponible, fallback sur GitHub MCP :
```
Outil : github/list_issues
Filtres :
  - assignee: @me
  - state: open
  - labels: "in-sprint"
```

### Étape 2 — Formater les stories

Transformer les issues en format stories.md :

```markdown
# Sprint [N] — [dates]

**Vélocité cible :** XX pts
**Vélocité actuelle :** XX pts

## En cours
| ID     | Story                        | Pts | Agent      | Status    |
|--------|------------------------------|-----|------------|-----------|
| T-XX   | [titre]                      | X   | [agent]    | 🟡 En cours |

## À faire
| ID     | Story                        | Pts | Agent      | Priority  |
|--------|------------------------------|-----|------------|-----------|
| T-XX   | [titre]                      | X   | [agent]    | 🔴 High   |

## Bloqué
| ID     | Story                        | Blocker                    |
|--------|------------------------------|----------------------------|
| T-XX   | [titre]                      | [description du blocker]   |
```

### Étape 3 — Sauvegarder

```bash
cat > .claude/memory/stories.md << STORIES
[contenu généré]
STORIES
echo "✅ stories.md mis à jour"
```

### Étape 4 — Mettre à jour context.md

Mettre à jour la section "Sprint courant" de `.claude/memory/context.md`
avec le résumé du sprint (nombre de tâches, vélocité, blockers).

### Étape 5 — Résumé

```markdown
## Sprint chargé ✅

**Sprint : [N]**
**Tâches en cours : N**
**Tâches à faire : N**
**Bloquées : N**
**Vélocité : XX / XX pts**

stories.md et context.md mis à jour.
Contexte injecté pour la session.
```
