# /push-staging — Merge feature vers staging

Crée une PR de la branche courante vers staging et la merge après vérifications.
Utilise le GitHub MCP pour toutes les opérations Git distantes.

## Usage
```
/push-staging [--title <titre>] [--skip-review]
```

## Exemples
```
/push-staging
/push-staging --title "feat: add invoice management"
/push-staging --skip-review
```

---

## Instructions pour l'orchestrateur

### Étape 1 — État initial

```bash
git rev-parse --abbrev-ref HEAD   # branche courante
git status --porcelain            # fichiers non commités
git log staging..HEAD --oneline   # commits à merger
```

**Règles bloquantes :**
- Si branche courante = `main` ou `staging` → STOP ("Ne jamais push-staging depuis main/staging")
- Si fichiers non commités → STOP ("Commiter d'abord")
- Si aucun commit d'avance sur staging → STOP ("Rien à merger")

### Étape 2 — Review automatique (sauf --skip-review)

Délègue à l'agent **reviewer** :

```
Review rapide avant merge vers staging.
Diff : [git diff staging...HEAD]
Focus : sécurité et critiques bloquantes uniquement.
Si bloquant ❌ : lister les points et stopper le push-staging.
Si OK ✅ ou réserves ⚠️ : continuer.
```

Si le reviewer retourne ❌ → STOP et afficher les bloquants.

### Étape 3 — Push de la branche

```bash
git push origin HEAD
```

### Étape 4 — Créer la PR via GitHub MCP

Utilise le **GitHub MCP** pour créer la PR :

```
Outil : github/create_pull_request
Paramètres :
  - base: "staging"
  - head: "<branche-courante>"
  - title: "<titre passé en argument ou généré depuis les commits>"
  - body: |
      ## Changements
      [liste des commits : git log staging..HEAD --oneline]

      ## Type
      - [ ] Feature
      - [ ] Fix
      - [ ] Refactor
      - [ ] Chore

      ## Tests
      - [ ] Tests unitaires ajoutés/mis à jour
      - [ ] Tests d'intégration OK
      - [ ] Review effectuée

      ## Notes
      Mergé via /push-staging — [date]
  - draft: false
```

### Étape 5 — Auto-merge de la PR

Après création de la PR :

```
Outil : github/merge_pull_request
Paramètres :
  - merge_method: "squash"
  - commit_title: "<titre de la PR>"
```

### Étape 6 — Sauvegarder l'état pour /revert-staging

```bash
SHA=$(git rev-parse HEAD)
BRANCH=$(git rev-parse --abbrev-ref HEAD)
TIMESTAMP=$(date +%Y-%m-%dT%H:%M:%S)
echo "$SHA|$BRANCH|$TIMESTAMP" > .claude/staging-last-merge.txt
```

### Étape 7 — Résumé

```markdown
## Push staging — ✅ Succès

**Branche   : <branch> → staging**
**PR        : #<number> — <title>**
**SHA       : <sha>**
**Commits   : N**
**Review    : ✅ / ⚠️ (réserves documentées)**

### Prochaines étapes
- Vérifier le déploiement staging : /deploy staging
- Tests de validation : /test --env staging
- Merger vers main quand validé
```
