# /reset — Réinitialiser le contexte

## Usage
```
/reset            # résumé + instructions pour /clear
/reset --soft     # garde les 3 dernières décisions
/reset --now      # reset immédiat sans résumé
```

## Quand l'utiliser
- Après une feature complète
- Sur demande après un auto-compact
- Changement total de contexte (nouveau projet, nouveau sujet)

---

## Instructions

### /reset (défaut) — résumé avant reset

Produire le même bloc compact que /compact, puis :

```
⚡ Reset prêt.

1. Tape /clear
2. Reprends avec : "Projet <nom> — [prochaine étape]"

Ou si tu continues sur le même sujet, colle le bloc contexte compressé.
```

### /reset --soft

Garder uniquement :
- Dernière décision d'architecture
- Prochain step immédiat
- Blocker actif si présent

```
⚡ Reset soft — contexte minimal conservé :
[3 lignes max]
Continue ta tâche.
```

### /reset --now

Pas de résumé. Juste :
```
⚡ Contexte vidé.
Tape /clear pour confirmer, puis commence un nouveau prompt propre.
```
