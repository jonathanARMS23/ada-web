# /revert-staging — Rollback du dernier merge vers staging

Annule le dernier merge vers staging en utilisant l'état sauvegardé par /push-staging.
Utilise le GitHub MCP pour les opérations Git distantes.

## Usage
```
/revert-staging [--confirm]
```

## Exemples
```
/revert-staging          # affiche ce qui va être revert, demande confirmation
/revert-staging --confirm  # revert direct sans demande
```

---

## Instructions pour l'orchestrateur

### Étape 1 — Lire l'état sauvegardé

```bash
cat .claude/staging-last-merge.txt
```

**Format attendu :** `<sha>|<branch>|<timestamp>`

Si le fichier n'existe pas → STOP : "Aucun merge staging trouvé. Lance /push-staging d'abord."

### Étape 2 — Afficher ce qui va être revert

```bash
LAST_SHA=$(cut -d'|' -f1 .claude/staging-last-merge.txt)
LAST_BRANCH=$(cut -d'|' -f2 .claude/staging-last-merge.txt)
LAST_DATE=$(cut -d'|' -f3 .claude/staging-last-merge.txt)

# Commits qui seront annulés
git log $LAST_SHA..staging --oneline
# Fichiers impactés
git diff $LAST_SHA..staging --stat
```

Afficher le résumé :
```
⚠️  REVERT STAGING
Dernier merge : <branch> → staging (<date>)
SHA           : <sha>
Commits à annuler : N
Fichiers impactés : M
```

### Étape 3 — Demander confirmation (sauf --confirm)

Si `--confirm` n'est pas passé dans $ARGUMENTS :

**Interrompre et demander :**
```
Confirmes-tu le revert de staging vers <sha> ? (répondre "oui, revert staging")
```

**Attendre** la réponse avant de continuer.

### Étape 4 — Effectuer le revert via GitHub MCP

Option A — **Revert par commit** (propre, recommandé) :

```
Outil : github/create_pull_request
Paramètres :
  - base: "staging"
  - head: "<nouvelle-branche-revert>"
  - title: "revert: undo <last_branch> merge"
  - body: "Revert automatique du merge <sha> via /revert-staging"

Puis git revert --no-commit <sha>..HEAD sur la branche de revert
Puis merger la PR
```

Option B — **Reset hard** (plus radical, si option A impossible) :

```bash
git checkout staging
git reset --hard $LAST_SHA
git push --force-with-lease origin staging
```

Préférer toujours **option A** — l'historique reste propre.

### Étape 5 — Nettoyer l'état

```bash
# Archiver l'état revert avant de nettoyer
TIMESTAMP=$(date +%Y-%m-%dT%H:%M:%S)
echo "REVERTED|$LAST_SHA|$LAST_BRANCH|$TIMESTAMP" >> .claude/archives/revert-history.txt

# Supprimer le last-merge pour éviter un double-revert accidentel
rm .claude/staging-last-merge.txt
```

### Étape 6 — Résumé

```markdown
## Revert staging — ✅ Succès

**SHA revert : <sha>**
**Branche annulée : <branch>**
**Staging restauré à : <sha_avant_merge>**
**Méthode : revert commit (historique préservé)**

### Prochaines étapes
- Vérifier staging : https://staging.votre-domaine.com
- Diagnostiquer le problème sur la branche <branch>
- Relancer /push-staging quand corrigé
```
