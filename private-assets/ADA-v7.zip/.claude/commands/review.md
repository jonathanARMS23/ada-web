# /review — Code review du diff courant

Lance une analyse complète du code modifié depuis la dernière branche de référence.

## Usage
```
/review [--branch <base>] [--focus security|perf|arch] [--staged]
```

## Exemples
```
/review
/review --branch dev
/review --focus security
/review --staged
```

---

## Instructions pour l'orchestrateur

### Étape 1 — Collecter le diff

Exécute selon les options passées ($ARGUMENTS) :

```bash
# Par défaut : diff avec la branche dev
git diff dev...HEAD --stat
git diff dev...HEAD

# Si --staged : uniquement les fichiers en attente de commit
# git diff --cached

# Si --branch <base> : utiliser la branche spécifiée
# git diff <base>...HEAD
```

Si le diff est vide, signaler : "Aucune modification détectée par rapport à la branche de référence."

### Étape 2 — Classifier les fichiers modifiés

Groupe les fichiers par domaine :
- **DB** : `migrations/`, `*.sql`, `prisma/schema.prisma`, `*/models.py`
- **Backend** : `src/modules/`, `apps/`, `*.service.ts`, `*.controller.ts`, `views.py`, `serializers.py`
- **Frontend** : `app/`, `components/`, `pages/`, `*.tsx`, `*.jsx`
- **Tests** : `*.spec.ts`, `*.test.ts`, `test_*.py`, `e2e/`
- **Infra** : `Dockerfile`, `docker-compose*`, `.github/workflows/`, `*.yml`

### Étape 3 — Déléguer au reviewer

Délègue à l'agent **reviewer** avec ce prompt :

```
Voici le diff complet à analyser :

[diff complet]

Fichiers modifiés par domaine :
- DB : [liste]
- Backend : [liste]
- Frontend : [liste]
- Tests : [liste]
- Infra : [liste]

Option focus : [security|perf|arch|all selon $ARGUMENTS]

Produis le rapport complet avec :
1. Verdict global (✅ / ⚠️ / ❌)
2. Critiques bloquantes (sécurité en priorité)
3. Recommandations (perf, architecture)
4. Suggestions mineures
5. Checklist finale
```

### Étape 4 — Actions selon le verdict

**Si verdict ❌ (bloquant) :**
- Lister précisément les fichiers et lignes à corriger
- Proposer de relancer `/review` après correction

**Si verdict ⚠️ (réserves) :**
- Lister les points à traiter avant merge main (pas bloquant pour staging)
- Créer les tâches de suivi avec le format :
  ```
  TODO: [description] — [fichier:ligne]
  ```

**Si verdict ✅ :**
- Confirmer que le code est prêt pour merge
- Rappeler le flow : `feature → dev → staging → main`

### Étape 5 — Résumé

```markdown
## Review — [branch courante] → [branche cible]

**Verdict : ✅/⚠️/❌**
**Fichiers analysés : N**
**Lignes modifiées : +X -Y**

### Bloquants : N
[liste]

### Recommandations : N
[liste]

### Prêt pour merge : oui/non
```
