# /saas-audit — Audit sécurité ciblé SaaS

Vérifie les vulnérabilités spécifiques aux SaaS multi-tenant.

## Usage
```
/saas-audit [--focus auth|billing|api|all]
```

---

## Instructions pour l'orchestrateur

**Agent security-auditor**

### Focus auth
```
Lire skills/security-auditor/audit-authentication.md
Lire skills/security-auditor/audit-authorization.md
Lire skills/security-auditor/audit-rls-supabase.md

Vérifier :
1. JWT : algorithme, expiry, refresh rotation
2. Isolation workspace : tester cross-workspace IDOR
   → Créer user A + user B dans workspaces différents
   → Vérifier que B ne peut pas accéder aux ressources de A
3. RLS : toutes les tables ont une policy workspace_id
4. Invitations : token à usage unique, expiré après 7 jours
```

### Focus billing
```
Vérifier :
1. Signature Stripe webhook validée (pas de bypass possible)
2. Idempotence : le même event Stripe ne peut pas être traité 2x
3. PlanGuard sur toutes les routes premium
4. Un workspace ne peut pas downgrade sans perdre les données en excès
5. Pas d'accès aux invoices d'un autre workspace
```

### Focus api
```
Lire skills/security-auditor/audit-api-security.md
Lire skills/security-auditor/audit-injection.md

Vérifier :
1. Rate limiting sur /auth/login (max 5/min), /webhooks (max 100/min)
2. CORS : origins whitelistées
3. Headers Helmet configurés
4. Pas de stack trace dans les erreurs 500
5. Toutes les routes protégées ont un guard
```

### Rapport
```markdown
## Audit SaaS — $PROJECT_NAME

### Auth
[résultats]

### Multi-tenant
[résultats — inclure les tests IDOR]

### Billing
[résultats]

### API
[résultats]

### Score global : ✅ Prêt | ⚠️ Corrections nécessaires | ❌ Bloquant
```
