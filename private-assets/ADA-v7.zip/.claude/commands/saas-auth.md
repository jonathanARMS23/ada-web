# /saas-auth — Ajouter l'auth + multi-tenant à un projet existant

## Usage
```
/saas-auth [--provider supabase|custom] [--social google,github]
```

---

## Instructions pour l'orchestrateur

Détecter le projet courant via `package.json` ou `AI_DEV_PROJECT`.

### Étape 1 — DB (PARALLÈLE avec étape 2)

**Task A → agent db**
```
Lire skills/db/create-saas-schema.md

Crée les migrations :
- workspaces, users, workspace_members, invitations
- RLS selon --provider
- Index + triggers
```

### Étape 2 — Backend (PARALLÈLE avec étape 1)

**Task B → agent nestjs**
```
Provider : $PROVIDER

Lire skills/nestjs/create-workspace-guard.md

Crée :
- AuthModule avec stratégie $PROVIDER
- WorkspaceModule (CRUD + invite membres)
- WorkspaceGuard + WorkspaceMemberGuard
- Middleware d'injection workspaceId depuis JWT
```

**Attendre les deux.**

### Étape 3 — Frontend

**Agent nextjs**
```
Lire skills/nextjs/create-auth-flow.md
Lire skills/nextjs/create-onboarding-flow.md

Crée :
- Pages /login, /register
- Flow onboarding (workspace → invite → dashboard)
- Middleware Next.js de protection des routes
- useAuth hook
```

### Étape 4 — Résumé
```
Auth $PROVIDER installée ✅
- Migrations DB : workspaces + members + invitations
- Guards : WorkspaceGuard + WorkspaceMemberGuard
- Frontend : login/register/onboarding
```
