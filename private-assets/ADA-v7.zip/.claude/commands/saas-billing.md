# /saas-billing — Ajouter Stripe Subscriptions à un projet existant

## Usage
```
/saas-billing [--plans free,starter,pro] [--trial 14]
```

## Prérequis
- Auth installée (/saas-auth ou /saas-init déjà fait)
- STRIPE_SECRET_KEY dans .env

---

## Instructions pour l'orchestrateur

### Étape 1 — DB + Backend (PARALLÈLE)

**Task A → agent db**
```
Lire skills/db/create-billing-tables.md
Crée migrations subscriptions + invoices + plan_limits
Plans : $PLANS
```

**Task B → agent nestjs**
```
Lire skills/nestjs/create-stripe-module.md
Lire skills/nestjs/create-plan-guard.md

Crée :
- StripeModule (service + webhook controller)
- SubscriptionService (activate/update/cancel)
- PlanGuard + @RequiresPlan decorator
- Route POST /billing/checkout
- Route POST /billing/portal
- Route POST /webhooks/stripe (raw body !)
```

**Attendre les deux.**

### Étape 2 — Frontend

**Agent nextjs**
```
Lire skills/nextjs/create-pricing-page.md
Lire skills/nextjs/create-settings-page.md (section billing)

Crée :
- Page /pricing avec cards par plan
- Toggle mensuel / annuel
- Intégration Stripe Checkout
- Page /settings/billing (plan actuel + portail)
```

### Étape 3 — Security review

**Agent security-auditor**
```
Audit du module billing :
- Validation signature webhook Stripe
- Pas d'accès aux données d'autres workspaces
- Raw body middleware en place
- Idempotence des webhooks
```

### Étape 4 — Résumé
```
Billing Stripe installé ✅
- Plans : $PLANS
- Webhook handler sécurisé
- Frontend : /pricing + /settings/billing
- PlanGuard disponible pour les features premium
```
