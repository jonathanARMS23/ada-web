# /saas-deploy — CI/CD + monitoring pour un projet SaaS

## Usage
```
/saas-deploy [--target railway|vercel|aws] [--env staging,prod]
```

---

## Instructions pour l'orchestrateur

**Agent devops**

```
Cible : $TARGET | Envs : $ENVS

Lire skills/devops/create-github-actions-ci.md
Lire skills/devops/create-github-actions-deploy.md
Lire skills/devops/create-monitoring-stack.md

Crée :
1. .github/workflows/ci.yml
   - Job test : NestJS (Jest) + Next.js (Vitest)
   - Job lint : ESLint + TypeScript check
   - Job build : vérification build OK

2. .github/workflows/deploy.yml selon $TARGET :
   railway → deploy via Railway CLI
   vercel  → deploy web via Vercel + API séparée
   aws     → push ECR + ECS task update

3. Monitoring :
   - Sentry apps/api + apps/web
   - /health endpoint (DB + Redis)
   - Alertes Slack sur échec deploy

4. Backup PostgreSQL quotidien (si $TARGET=railway ou aws)
```

**Agent security-auditor** (après devops)
```
Audit pré-lancement :
- Secrets dans .env (pas dans le code)
- Headers sécurité (Helmet configuré)
- Rate limiting sur /auth et /webhooks
- CORS restrictif
- RLS activé sur toutes les tables
Checklist : audit-authentication + audit-api-security
```

**Agent doc-writer** (en parallèle)
```
Lire skills/doc-writer/write-readme.md
Lire skills/doc-writer/write-runbook.md

Crée :
- README.md complet (quick start < 5 min)
- docs/runbook.md (deploy + incidents courants)
- CHANGELOG.md v0.1.0
```

### Résumé final
```
Deploy configuré ✅
- CI : test + lint + build sur chaque PR
- CD : staging auto, prod manuel
- Monitoring : Sentry + /health + alertes
- Docs : README + runbook + CHANGELOG
Prêt pour le lancement.
```
