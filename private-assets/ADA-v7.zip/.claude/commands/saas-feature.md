# /saas-feature — Ajouter une feature métier à un projet SaaS

Wrapper de /feature avec contexte SaaS injecté automatiquement.
Garantit que chaque feature respecte le multi-tenant, les guards, et les plans.

## Usage
```
/saas-feature <nom-feature> [--plan-gate free|starter|pro] [--api-only]
```

## Exemples
```
/saas-feature invoice-management
/saas-feature analytics-dashboard --plan-gate starter
/saas-feature export-csv --plan-gate pro --api-only
```

---

## Instructions pour l'orchestrateur

Récupérer le contexte SaaS du projet (depuis CLAUDE.md projet ou mémoire).

### Contexte injecté automatiquement dans chaque agent

**Règles SaaS obligatoires :**
```
MULTI-TENANT :
- Toutes les tables → workspace_id NOT NULL REFERENCES workspaces(id)
- get_queryset / findMany → WHERE workspace_id = request.workspaceId
- Jamais de workspace_id depuis le body client

GUARDS (si --plan-gate défini) :
- @UseGuards(JwtAuthGuard, WorkspaceGuard, PlanGuard)
- @RequiresPlan('$PLAN_GATE')

TRACKING USAGE (si feature limitée par plan) :
- Incrémenter usage_events après chaque opération billable

TESTS :
- Toujours tester l'isolation workspace (user B ne voit pas les données de user A)
```

### Puis exécuter le flow standard /feature avec ce contexte

Reprendre les étapes 1+2 parallèles (tester + db) → 3 (nestjs) → 4 (nextjs) → 5 (review).

### Checklist spécifique SaaS ajoutée à la review finale
```
□ workspace_id filtré dans toutes les queries
□ Guard de plan appliqué si --plan-gate
□ Test d'isolation workspace présent
□ Pas d'IDs séquentiels exposés
□ RLS cohérent avec la nouvelle table
```
