# /saas-init — Bootstrap un nouveau projet SaaS NestJS + Next.js

Crée la structure complète d'un SaaS from scratch en orchestrant tous les agents dans le bon ordre.

## Usage
```
/saas-init <nom-du-projet> [--mode minimal|core|full] [--billing stripe|none] [--auth supabase|custom]
```

## Exemples
```
/saas-init my-saas
/saas-init invoicing-app --mode core --billing stripe
/saas-init api-service --mode minimal
```

---

## Instructions pour l'orchestrateur

### Étape 0 — Interview (si arguments insuffisants)

Si `$ARGUMENTS` ne contient pas `--mode`, poser ces 3 questions max :

```
1. Mode de déploiement :
   [A] minimal  — API + Auth + DB (valider avant d'investir)
   [B] core     — + Dashboard + Settings (bêta-testeurs)
   [C] full     — + Billing Stripe + CI/CD (lancement public)

2. Authentification :
   [A] Supabase Auth + RLS (recommandé — intégration native)
   [B] JWT custom NestJS Guards

3. Billing (si mode core ou full) :
   [A] Stripe Subscriptions (plans free/starter/pro)
   [B] Pas de billing pour l'instant
```

Construire le profil SaaS :
```
PROJECT_NAME = <nom>
MODE = minimal|core|full
AUTH = supabase|custom
BILLING = stripe|none
STACK = NestJS + Next.js 15 + PostgreSQL (défaut)
```

---

### Étape 1 — Architecture (agent: technical-architect)

```
Projet SaaS : $PROJECT_NAME
Mode : $MODE | Auth : $AUTH | Billing : $BILLING
Stack : NestJS 10 + Next.js 15 + PostgreSQL + Prisma + Redis

Produis :
1. Structure monorepo :
   apps/api/     → NestJS
   apps/web/     → Next.js
   packages/shared/ → types + validations partagés

2. Décisions d'architecture (ADR format court) :
   - Auth : $AUTH avec justification
   - Multi-tenant : workspace_id row-level
   - Deploy cible : Railway (API) + Vercel (Web)

3. .env.example complet avec toutes les variables nécessaires
4. CLAUDE.md projet (stack + conventions + règles spécifiques)
```

---

### Étape 2 — Schéma DB + Docker (PARALLÈLE)

**Task A → agent db**
```
Projet : $PROJECT_NAME | Mode : $MODE | Auth : $AUTH

Lire skills/db/create-saas-schema.md

Crée la migration 001_saas_foundation.sql :
- Tables : workspaces, users, workspace_members, invitations
- RLS Supabase si AUTH=supabase
- Index sur FK et colonnes filtrées
- Triggers updated_at
- Migration de rollback

Si BILLING=stripe → lire skills/db/create-billing-tables.md
Ajouter migration 002_billing.sql (subscriptions, invoices, plan_limits)
```

**Task B → agent devops**
```
Projet : $PROJECT_NAME

Lire skills/devops/create-docker-compose.md
Lire skills/devops/create-env-management.md

Crée :
1. docker-compose.yml (PostgreSQL 15 + Redis 7 + health checks)
2. .env.example documenté avec toutes les variables
3. Makefile avec commandes : make dev, make db-migrate, make test
```

**Attendre les deux avant de continuer.**

---

### Étape 3 — Backend NestJS (agent: nestjs)

```
Projet : $PROJECT_NAME | Auth : $AUTH | Billing : $BILLING

Lire skills/nestjs/create-config-module.md
Lire skills/nestjs/create-prisma-service.md

Scaffolde l'API NestJS complète :

apps/api/src/
  app.module.ts          # Module racine avec tous les imports
  main.ts                # Bootstrap avec Helmet, CORS, validation pipe
  config/                # ConfigModule + schéma Zod de validation
  prisma/                # PrismaService
  auth/                  # Module auth complet
  workspaces/            # CRUD workspace + membres
  health/                # /health endpoint

Auth module selon $AUTH :
- supabase : validation du JWT Supabase + extraction workspaceId
- custom : JWT NestJS avec refresh tokens

Lire skills/nestjs/create-workspace-guard.md
Ajouter WorkspaceGuard + WorkspaceMemberGuard

Si BILLING=stripe :
  Lire skills/nestjs/create-stripe-module.md
  Ajouter StripeModule avec webhooks
  Lire skills/nestjs/create-plan-guard.md
  Ajouter PlanGuard
```

---

### Étape 4 — Frontend Next.js (agent: nextjs) — sauf si mode minimal

```
Projet : $PROJECT_NAME | Auth : $AUTH | Billing : $BILLING

Lire skills/nextjs/create-auth-flow.md
Lire skills/nextjs/create-dashboard-layout.md
Lire skills/nextjs/create-onboarding-flow.md

Scaffolde le frontend Next.js 15 App Router :

apps/web/
  app/
    (marketing)/        # pages publiques
      page.tsx          # Landing page minimaliste
      pricing/          # Si BILLING=stripe → lire create-pricing-page.md
    (auth)/
      login/page.tsx
      register/page.tsx
    (onboarding)/
      onboarding/       # Flow onboarding post-inscription
    (dashboard)/
      layout.tsx        # Layout avec sidebar + header
      dashboard/        # Page principale
      settings/         # Si mode core/full → lire create-settings-page.md
  components/
    ui/                 # shadcn/ui components
    layout/             # Sidebar, Header, Breadcrumbs
  lib/
    auth.ts             # Configuration auth
    api.ts              # Client API typé
    utils.ts
  middleware.ts         # Protection des routes
```

---

### Étape 5 — CI/CD (agent: devops) — mode full uniquement

```
Projet : $PROJECT_NAME

Lire skills/devops/create-github-actions-ci.md
Lire skills/devops/create-github-actions-deploy.md
Lire skills/devops/create-monitoring-stack.md

Crée :
1. .github/workflows/ci.yml (test + lint + typecheck)
2. .github/workflows/deploy.yml (staging auto + prod manuel)
3. Sentry setup (API + Web)
4. /health endpoint avec checks DB + Redis
```

---

### Étape 6 — Résumé final obligatoire

```markdown
## SaaS initialisé : $PROJECT_NAME ✅

**Stack :** NestJS 10 + Next.js 15 + PostgreSQL + Prisma + Redis
**Mode :** $MODE | **Auth :** $AUTH | **Billing :** $BILLING

### Structure créée
apps/
  api/   — NestJS (port 3001)
  web/   — Next.js (port 3000)
packages/shared/ — Types partagés

### DB migrations
- 001_saas_foundation.sql — workspaces, users, members
[- 002_billing.sql — subscriptions, invoices]

### Modules API
- AuthModule    — $AUTH
- WorkspaceModule — CRUD + membres
- HealthModule  — /health
[- StripeModule  — billing + webhooks]

### Pages Web
- / (landing), /login, /register, /onboarding
- /dashboard, /settings
[- /pricing]

### Pour démarrer
\`\`\`bash
cp apps/api/.env.example apps/api/.env
cp apps/web/.env.example apps/web/.env
docker compose up -d
cd apps/api && npx prisma migrate dev
npm run dev  # démarre API + Web en parallèle
\`\`\`

### Prochaines étapes
- [ ] Configurer les variables d'env ($AUTH + $BILLING)
- [ ] Tester le flow auth complet
- [ ] /saas-feature <première-feature-métier>
```
