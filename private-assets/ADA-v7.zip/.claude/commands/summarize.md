# /summarize — Résume la session et écrit en mémoire longue durée

Résume la session courante de façon structurée et stocke dans les archives
pour alimenter le contexte des prochaines sessions.

## Usage
```
/summarize [--level session|week|month]
```

---

## Instructions pour l'orchestrateur

Niveau : **$ARGUMENTS** (défaut : session)

### Étape 1 — Collecter le contexte de la session

```bash
# Fichiers modifiés dans la session
git diff --stat HEAD~$(git log --oneline | head -20 | wc -l) HEAD 2>/dev/null || git status

# Commits de la session
git log --oneline --since="today" 2>/dev/null | head -20

# Contexte courant
cat .claude/memory/context.md
```

### Étape 2 — Générer le résumé structuré

Sur la base de l'historique de conversation et des fichiers modifiés,
produis un résumé structuré de la session (300 mots max) :

```markdown
# Session — [DATE] [PROJET]

## Décisions d'architecture
- [Choix pris avec justification courte]
- ...

## Code produit
- [Module/fichier créé/modifié — description courte]
- ...

## Bugs rencontrés et fixes
- [Problème] → [Solution]
- ...

## Patterns identifiés
- [Pattern réutilisable découvert ou appliqué]
- ...

## Blockers actifs
- [Ce qui n'est pas résolu]
- ...

## Prochaines étapes
- [ ] [Action concrète suivante]
- ...
```

### Étape 3 — Sauvegarder le résumé

```bash
DATE=$(date +%Y-%m-%d)
TIME=$(date +%H%M)
mkdir -p .claude/archives/summaries

# Résumé de session
cat > ".claude/archives/summaries/${DATE}_${TIME}.md" << SUMMARY
[résumé généré]
SUMMARY

echo "✅ Session sauvegardée : .claude/archives/summaries/${DATE}_${TIME}.md"

# Marquer la session comme sauvegardée — désactive les rappels du stop-hook
node "${CLAUDE_CONFIG_DIR}/hooks/mark-summarized.js"
```

### Étape 4 — Si --level week : agréger les sessions de la semaine

```bash
# Lister les sessions de la semaine courante
WEEK_START=$(date -d "last monday" +%Y-%m-%d 2>/dev/null || date -v-Mon +%Y-%m-%d)
ls .claude/archives/summaries/${WEEK_START}*.md 2>/dev/null
```

Générer un résumé hebdomadaire condensé (~400 mots) depuis les sessions listées :
```bash
cat > ".claude/archives/summaries/week_$(date +%Y-W%V).md" << WEEKLY
# Semaine [N] — [dates]
[résumé agrégé]
WEEKLY
```

### Étape 5 — Mettre à jour context.md

Mettre à jour `.claude/memory/context.md` avec :
- Les décisions de la session (append dans la section "Dernières décisions")
- Les blockers actifs mis à jour
- La date de dernière mise à jour

### Étape 6 — Résumé

```markdown
## Résumé de session sauvegardé ✅

**Fichier : .claude/archives/summaries/[fichier]**
**Décisions : N**
**Patterns  : N**
**Blockers  : N**

Context.md mis à jour.
Prochaine session : lancer /fetch-sprint pour recharger le contexte.
```
