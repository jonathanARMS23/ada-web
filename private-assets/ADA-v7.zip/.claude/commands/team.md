# /team — Changer de profil d'agents

Recharge les agents du profil demandé sans réinstaller le système complet.

## Usage
```
/team <profil>
/team list
```

## Profils disponibles
| Profil | Agents |
|--------|--------|
| `fullstack` | nestjs · nextjs · db |
| `fullstack-drf` | drf · nextjs · db |
| `frontend` | nextjs · ux-designer · reviewer |
| `backend-nestjs` | nestjs · db · tester |
| `backend-drf` | drf · db · tester |
| `mobile-rn` | react-native · api-designer · reviewer |
| `mobile-native` | android · swift · api-designer |
| `devops` | devops · security-auditor · reviewer |
| `review` | reviewer · security-auditor · performance-analyst |
| `strategy` | feature-architect · devils-advocate · api-designer |
| `design` | ux-designer · technical-architect · data-modeler |
| `data` | data-modeler · db · migration-strategist |
| `onboarding` | onboarding-agent · feature-architect · technical-architect |

---

## Instructions pour l'orchestrateur

### Si $ARGUMENTS = "list"
Afficher le tableau des profils ci-dessus et le profil actuellement actif.

### Sinon — changer de profil

**Étape 1 — Valider le profil demandé**
Vérifier que `$ARGUMENTS` correspond à un profil du tableau.
Si invalide → afficher la liste et stopper.

**Étape 2 — Recharger les agents**
```bash
PROFILE="$ARGUMENTS"
CONFIG_DIR="${CLAUDE_CONFIG_DIR:-$HOME/.claude}"

# Lire les agents du profil
PROFILE_AGENTS=$(python3 -c "
import json
with open('$CONFIG_DIR/teams/profiles.json') as f:
    data = json.load(f)
profile = data['team_profiles'].get('$PROFILE', {})
agents = ['orchestrator'] + profile.get('agents', [])
print(' '.join(set(agents)))
")

# Remplacer agents/ par la bonne version (full ou stub)
for agent in $(ls $CONFIG_DIR/agents/full/ | sed 's/.md//'); do
  in_profile=false
  for pa in $PROFILE_AGENTS; do
    [ "$agent" = "$pa" ] && in_profile=true && break
  done
  if [ "$in_profile" = true ]; then
    cp "$CONFIG_DIR/agents/full/$agent.md" "$CONFIG_DIR/agents/$agent.md"
  else
    cp "$CONFIG_DIR/agents/stubs/$agent.md" "$CONFIG_DIR/agents/$agent.md"
  fi
done

echo "Profil '$PROFILE' activé — agents rechargés"
```

**Étape 3 — Confirmer**
```markdown
## Profil activé : $ARGUMENTS

**Agents complets :** [liste]
**Agents en stub :** [nombre] agents secondaires en veille

Redémarre Claude Code pour que les changements prennent effet.
```
