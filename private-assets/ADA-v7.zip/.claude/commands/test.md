# /test — Lance les tests avec rapport de coverage

Exécute les tests selon le scope demandé et produit un rapport de coverage.

## Usage
```
/test [--scope unit|integration|e2e|all] [--watch] [--coverage] [--fix]
```

## Exemples
```
/test
/test --scope unit
/test --scope e2e
/test --coverage
/test --fix       # demande au tester de corriger les tests qui échouent
```

---

## Instructions pour l'orchestrateur

Scope demandé : **$ARGUMENTS**

### Étape 1 — Détecter le stack de test

```bash
# Détecter NestJS/TS vs DRF/Python
ls package.json 2>/dev/null && echo "nodejs"
ls requirements.txt pyproject.toml 2>/dev/null && echo "python"
```

### Étape 2 — Exécuter les tests

**Pour NodeJS (NestJS/Next.js) :**
```bash
# Unit
npm run test -- --passWithNoTests 2>&1

# Integration
npm run test:integration 2>&1

# E2E
npm run test:e2e 2>&1

# Coverage
npm run test:cov 2>&1
```

**Pour Python (DRF) :**
```bash
# Tous
pytest --tb=short -q 2>&1

# Coverage
pytest --cov=. --cov-report=term-missing --cov-fail-under=80 2>&1
```

### Étape 3 — Analyser les résultats

Extraire depuis la sortie :
- Nombre de tests : passés / échoués / skippés
- Coverage global et par fichier
- Tests qui échouent avec message d'erreur

### Étape 4 — Si tests échouent et --fix est passé

Délègue à l'agent **tester** :

```
Les tests suivants échouent :
[liste des tests en erreur avec messages]

Fichiers concernés :
[liste des fichiers]

Diagnostique la cause et propose les corrections.
Ne pas modifier les specs — corriger l'implémentation ou le test si le test est incorrect.
```

### Étape 5 — Résumé

```markdown
## Tests — [scope]

**Stack : NodeJS / Python**
**Total  : N tests**
**✅ Passés  : N**
**❌ Échoués : N**
**⏭  Skippés : N**

### Coverage global : XX%
| Fichier | Statements | Branches | Functions | Lines |
|---------|-----------|----------|-----------|-------|
| ...     | XX%       | XX%      | XX%       | XX%   |

### Tests échoués
[liste avec messages]

### Recommandations
[si coverage < 80% : fichiers à couvrir en priorité]
```
