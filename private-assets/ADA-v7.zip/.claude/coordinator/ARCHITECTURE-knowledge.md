# Contrat canonique de la connaissance ADA (ADR-knowledge)

> Évaluation A2 (2026-06-13) : le « double graphe » soupçonné est en réalité **un seul
> moteur de graphe** + un rendu gratuit. Ce document fige le contrat pour éviter qu'un
> 3e système divergent soit ajouté.

## Source de vérité unique : le ReasoningBank

`bank.db` (SQLite) est **la** source de vérité de la connaissance agent (trajectoires +
embeddings + insights distillés). Tout ce qui alimente les agents passe par là.

- `bank-state.json` = **snapshot JSON** de rétro-compat (lecteurs : graph-builder fallback,
  team-sync, metrics). Dérivé de `bank.db`, jamais source. Ne pas y écrire directement.

## Un seul moteur de graphe : Graphify

- `graph-memory.js` (classe `KnowledgeGraph` : BFS/PageRank) + `graph-builder.js`
  construisent **le** graphe de connaissance (nœuds agent/phase/pipeline, arêtes
  WIN_RATE / PRÉCÈDE / CO_OCCURRENCE) depuis `bank.db` (préféré) ou le snapshot (fallback).
- Consommé par `bank.applyGraphBoost` (retrieve par défaut) et exposé via control-server.
- ⚠️ Le « graphe Obsidian » N'EST PAS une computation ADA : l'app Obsidian rend sa vue
  graphe gratuitement depuis les liens markdown `[[...]]` écrits par `topic-wiki.js`.
  Ne PAS réimplémenter un graphe pour Obsidian.
- `embeddings.js` HNSW = index **vectoriel** (ANN), pas un knowledge graph. Rôles distincts.

## Obsidian = projection humaine + signal de maturité (jamais source agent)

`_obsidian/` est la couche **lecture humaine** (sessions, topics, wiki, daily). Générée par
`session-end.js` (notes) et `workers/topic-wiki.js` (pages topics). Les agents ne lisent
jamais Obsidian.

## Le pont unique Obsidian → bank : la promotion sélective

`topic-wiki.js` → `promoteRichTopics` → `bank.upsertTopicInsight` : quand un topic est mûr
(≥5 sessions + cohérence ≥0.4), il devient un insight retrievable dans le bank. C'est le
**seul** flux autorisé d'Obsidian vers la connaissance agent. Unidirectionnel.

## Conventions : cohérence garantie au store (P0-1/P0-3)

Les conventions projet (phase `convention`) suivent un contrat de cohérence appliqué dès
l'écriture (`storeConvention`) :

- **Portée** (`scope:global` | `scope:domain`) : global = règle transverse, injectée
  inconditionnellement on-topic ; domain = gatée sur la pertinence-contenu. Défaut global.
- **Supersession** : un quasi-doublon (Jaccard-sujet ≥ 0.5) déclenche un last-write-wins —
  l'ancienne est marquée `archived = true` (exclue du recall, conservée pour audit).
- **Contradiction** : polarités opposées sur un sujet partagé → WARNING (arbitrage humain),
  jamais d'archivage/blocage auto.

Une convention `archived` n'est **jamais** injectée (filtré à tous les points de sortie du
recall). Détail : `docs/architecture-memoire.md`.

## Recall observable, jamais silencieux (P1-2)

`buildRecallBlockAsync` est la voie de recall par défaut. Si Ollama est indisponible, le
repli TF-IDF est **signalé** (stderr + `lastRecallDegraded`), jamais silencieux.
`bankHealth()` (`ada bank health`) expose l'état réel (ollama, coverage, lastRecall*).

## Règle pour les évolutions futures

Avant d'ajouter un index/graphe/synthèse : vérifier qu'il ne duplique pas Graphify ou
distill. La connaissance agent vit dans `bank.db`. Obsidian en est une projection, pas une
source parallèle.
