#!/usr/bin/env node
/**
 * coordinator/ada-bridge.js — Multi-profile coordination (Federation Lite)
 *
 * Permet à plusieurs profils ADA de se passer des runs et partager
 * des trajectoires via un répertoire partagé configurable.
 *
 * Usage :
 *   node ada-bridge.js send <runId> [--to <profile>]    Exporte un run vers un autre profil
 *   node ada-bridge.js receive [--from <profile>]       Importe les runs en attente
 *   node ada-bridge.js list                             Liste les profils ADA disponibles
 *   node ada-bridge.js share-lessons <profile>          Partage les micro-lessons cross-profil
 *   node ada-bridge.js status                           État de la coordination
 */

const { readFileSync, writeFileSync, existsSync, mkdirSync, readdirSync } = require('fs')
const { join, resolve, sep } = require('path')
const os = require('os')

const HOME       = os.homedir()
const CONFIG_DIR = process.env.CLAUDE_CONFIG_DIR || join(HOME, '.claude')
const BRIDGE_DIR = process.env.ADA_BRIDGE_DIR    || join(HOME, '.ada-bridge')

const SAFE_PROFILE_RE = /^[a-z0-9][a-z0-9-]{0,30}$/

function validateProfile(name) {
  if (!SAFE_PROFILE_RE.test(name)) {
    process.stderr.write(`[ada-bridge] Invalid profile name: "${name}"\n`)
    process.exit(1)
  }
}

// ── Découverte des profils installés ─────────────────────────────────────────

function findProfiles() {
  try {
    return readdirSync(HOME, { withFileTypes: true })
      .filter(e => e.isDirectory() && e.name.startsWith('.claude-'))
      .map(e => ({
        name: e.name.slice('.claude-'.length),
        path: join(HOME, e.name),
        coordDir: join(HOME, e.name, 'coordinator'),
      }))
      .filter(p => existsSync(p.coordDir))
  } catch { return [] }
}

// ── Bridge directory (inbox/outbox partagé) ───────────────────────────────────

function ensureDir(p) { if (!existsSync(p)) mkdirSync(p, { recursive: true }) }

function getBridgeInbox(profile) {
  const inboxPath = join(BRIDGE_DIR, profile, 'inbox')
  const resolved = resolve(inboxPath)
  if (!resolved.startsWith(BRIDGE_DIR + sep)) {
    process.stderr.write('[ada-bridge] Path escape detected\n')
    process.exit(1)
  }
  return inboxPath
}

// ── Détecter le nom du profil courant depuis CONFIG_DIR ─────────────────────

function currentProfileName() {
  const base = CONFIG_DIR.split('/').pop() // ex: '.claude-pro' → 'pro'
  if (base && base.startsWith('.claude-')) return base.slice('.claude-'.length)
  return 'default'
}

// ── Commandes ────────────────────────────────────────────────────────────────

function cmdList() {
  const profiles = findProfiles()
  console.log(`\nProfils ADA disponibles (${profiles.length}) :`)
  for (const p of profiles) {
    const hasRuns = existsSync(join(p.path, 'runs'))
    const runCount = hasRuns ? readdirSync(join(p.path, 'runs')).length : 0
    console.log(`  ~/.${p.name.padEnd(15)} ${runCount} runs`)
  }
  if (!profiles.length) console.log('  Aucun profil trouvé (installer via install.sh)')
}

function cmdSend(args) {
  const [runId, ...rest] = args
  const toIdx = rest.indexOf('--to')
  const targetProfile = toIdx >= 0 ? rest[toIdx + 1] : null

  if (!runId) { console.error('Usage: ada-bridge.js send <runId> [--to <profile>]'); process.exit(1) }
  if (targetProfile) validateProfile(targetProfile)

  const runDir = join(CONFIG_DIR, 'runs', runId)
  if (!existsSync(runDir)) { console.error(`Run ${runId} introuvable`); process.exit(1) }

  const stateFile = join(runDir, 'state.json')
  if (!existsSync(stateFile)) { console.error(`state.json introuvable pour run ${runId}`); process.exit(1) }

  const targets = targetProfile
    ? [{ name: targetProfile }]
    : findProfiles().filter(p => p.path !== CONFIG_DIR)

  if (!targets.length) {
    console.log('Aucun profil cible trouvé')
    return
  }

  for (const target of targets) {
    const inbox = getBridgeInbox(target.name)
    ensureDir(inbox)
    const dest = join(inbox, `${runId}.json`)
    const state = JSON.parse(readFileSync(stateFile, 'utf8'))
    state._bridgedFrom = CONFIG_DIR
    state._bridgedAt   = new Date().toISOString()
    writeFileSync(dest, JSON.stringify(state, null, 2))
    console.log(`Run ${runId} envoye -> ~/.claude-${target.name}/bridge`)
  }
}

function cmdReceive(args) {
  const fromIdx = args.indexOf('--from')
  const fromProfile = fromIdx >= 0 ? args[fromIdx + 1] : null

  const myProfile = currentProfileName()
  const inbox = getBridgeInbox(myProfile)
  if (!existsSync(inbox)) { console.log('Inbox vide — aucun run en attente'); return }

  const files = readdirSync(inbox).filter(f => f.endsWith('.json'))
  if (!files.length) { console.log('Inbox vide'); return }

  const SAFE_RUN_ID_RE = /^[a-z0-9][a-z0-9-]{2,59}$/
  for (const file of files) {
    let state
    try { state = JSON.parse(readFileSync(join(inbox, file), 'utf8')) }
    catch { console.error(`Fichier inbox illisible : ${file}`); continue }
    if (!SAFE_RUN_ID_RE.test(state?.id)) {
      console.error(`Run ignoré — id invalide dans ${file}: "${state?.id}"`)
      continue
    }
    // Valider que phases est un objet plat (pas null/array) avec statuts connus
    if (state.phases !== undefined) {
      const VALID_STATUSES = new Set(['pending', 'running', 'done', 'failed', 'skipped', 'retrying'])
      const SAFE_PHASE_RE = /^[a-zA-Z0-9][a-zA-Z0-9_-]{0,63}$/
      let phasesOk = typeof state.phases === 'object' && !Array.isArray(state.phases) && state.phases !== null
      if (phasesOk) {
        for (const [phaseId, phase] of Object.entries(state.phases)) {
          if (!SAFE_PHASE_RE.test(phaseId) || typeof phase !== 'object' || phase === null || Array.isArray(phase)) { phasesOk = false; break }
          if (phase.status && !VALID_STATUSES.has(phase.status)) { phasesOk = false; break }
        }
      }
      if (!phasesOk) { console.error(`Run ignoré — phases invalides dans ${file}`); continue }
    }
    if (fromProfile && !state._bridgedFrom?.includes(fromProfile)) continue

    // Validate status before writing
    const VALID_RUN_STATUSES = new Set(['pending', 'running', 'done', 'failed', 'partial'])
    if (state.status !== undefined && !VALID_RUN_STATUSES.has(state.status)) {
      console.error(`Run ignoré — status invalide: "${state.status}"`)
      continue
    }
    // Strip bridge metadata — these are transport fields, not run state
    const { _bridgedFrom, _bridgedAt, ...cleanState } = state
    const destDir = join(CONFIG_DIR, 'runs', cleanState.id)
    ensureDir(destDir)
    writeFileSync(join(destDir, 'state.json'), JSON.stringify(cleanState, null, 2))
    console.log(`Run ${cleanState.id} importe depuis ${_bridgedFrom}`)
  }
}

function cmdShareLessons(args) {
  const [targetProfile] = args
  if (!targetProfile) { console.error('Usage: ada-bridge.js share-lessons <profile>'); process.exit(1) }
  validateProfile(targetProfile)

  const src = join(CONFIG_DIR, 'coordinator', 'lessons.json')
  if (!existsSync(src)) { console.log('Aucune leçon à partager'); return }

  const targetCoord = join(HOME, `.claude-${targetProfile}`, 'coordinator')
  if (!existsSync(targetCoord)) { console.error(`Profil ~/.claude-${targetProfile} introuvable`); process.exit(1) }

  const dest = join(targetCoord, 'lessons.json')

  // Merge : union des leçons par (phase+lesson)
  let srcRaw
  try { srcRaw = JSON.parse(readFileSync(src, 'utf8')) } catch { console.error('Fichier lessons.json source corrompu'); return }
  if (!Array.isArray(srcRaw)) { console.error('lessons.json source invalide (attendu tableau)'); return }

  const SAFE_LESSON_RE = /^[\w\s.,;:!?()\-]{1,500}$/s
  const SAFE_PHASE_RE  = /^[a-zA-Z0-9][a-zA-Z0-9_-]{0,63}$/
  const srcLessons = srcRaw.filter(l =>
    l !== null && typeof l === 'object' &&
    typeof l.phase === 'string' && SAFE_PHASE_RE.test(l.phase) &&
    typeof l.lesson === 'string' && l.lesson.length >= 3 && l.lesson.length <= 500
  )
  let dstLessons = existsSync(dest) ? JSON.parse(readFileSync(dest, 'utf8')) : []
  if (!Array.isArray(dstLessons)) dstLessons = []

  const seen = new Set(dstLessons.map(l => `${l.phase}:${l.lesson}`))
  const newLessons = srcLessons.filter(l => !seen.has(`${l.phase}:${l.lesson}`))

  const merged = [...dstLessons, ...newLessons].slice(-500)
  writeFileSync(dest, JSON.stringify(merged, null, 2))
  console.log(`${newLessons.length} nouvelles leçons partagées -> ~/.claude-${targetProfile}`)
}

function cmdStatus() {
  const profiles = findProfiles()
  const bridgeExists = existsSync(BRIDGE_DIR)
  const myProfile = currentProfileName()
  console.log(`\nADA Bridge Status`)
  console.log(`  Bridge dir  : ${BRIDGE_DIR} ${bridgeExists ? '(actif)' : '(inactif)'}`)
  console.log(`  Profil actif: ${CONFIG_DIR} (${myProfile})`)
  console.log(`  Profils découverts : ${profiles.length}`)

  for (const p of profiles) {
    const inbox = getBridgeInbox(p.name)
    const pending = existsSync(inbox) ? readdirSync(inbox).length : 0
    console.log(`    ~/.claude-${p.name} : ${pending} run(s) en inbox`)
  }
}

module.exports = { findProfiles, cmdSend, cmdReceive, cmdShareLessons }

const [,, cmd, ...args] = process.argv
switch (cmd) {
  case 'list':          cmdList();              break
  case 'send':          cmdSend(args);          break
  case 'receive':       cmdReceive(args);       break
  case 'share-lessons': cmdShareLessons(args);  break
  case 'status':        cmdStatus();            break
  default:
    console.log('\nADA Bridge — Multi-profile coordination\n')
    console.log('  list                            Profils ADA disponibles')
    console.log('  send <runId> [--to <profile>]   Exporter un run')
    console.log('  receive [--from <profile>]      Importer les runs en attente')
    console.log('  share-lessons <profile>         Partager les micro-lessons')
    console.log('  status                          Etat de la coordination')
}
