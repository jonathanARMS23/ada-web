#!/usr/bin/env node
/**
 * coordinator/ada-defence.js — AIDefence : injection detection + PII redaction
 * Zero dependency. CJS.
 */

'use strict'

const { appendFileSync, mkdirSync, existsSync } = require('fs')
const { join } = require('path')
const os = require('os')

// ── Config ────────────────────────────────────────────────────────────────────

const CONFIG_DIR   = process.env.CLAUDE_CONFIG_DIR || join(process.env.HOME ?? os.homedir(), '.claude')
const COORD_DIR    = join(CONFIG_DIR, 'coordinator')
const SECURITY_LOG = join(COORD_DIR, 'security.log')

// ── ADASecurityError ──────────────────────────────────────────────────────────

class ADASecurityError extends Error {
  /**
   * @param {string} message
   * @param {'INJECTION'|'PII'|'SECRET'} type
   * @param {string} context
   */
  constructor(message, type, context) {
    super(message)
    this.name = 'ADASecurityError'
    this.type = type
    this.context = context
  }
}

// ── Injection patterns ────────────────────────────────────────────────────────

const INJECTION_PATTERNS = [
  // Classic ignore instructions
  /ignore\s+(?:all\s+|previous\s+|prior\s+)*(instructions?|context|rules?)/i,
  // System prompt override attempts
  /system\s*:\s*(you\s+are|act\s+as|pretend|roleplay)/i,
  // Special tokens used in LLM context injection
  /\[INST\]/i,
  /<<SYS>>/i,
  /<\|im_start\|>/i,
  // Forget instructions
  /forget\s+(everything|all|your|prior)/i,
  // New role/persona/instructions injection
  /new\s+(role|persona|instructions?|task)\s*:/i,
  // DAN / jailbreak patterns
  /\b(DAN|jailbreak|unrestricted\s+mode)\b/i,
  // Disregard instructions
  /disregard\s+(?:all\s+|your\s+|previous\s+)*instructions/i,
]

// Patterns supplémentaires appliqués sur les inputs externes uniquement (pas sur les summaries internes)
const EXTERNAL_ONLY_PATTERNS = [
  // Fake CLAUDE.md simulation — ne doit pas matcher les summaries d'agents qui quotent l'architecture
  /^\s*#\s+AI\s+Dev\s+Assistant\b/im,
]

// ── PII patterns ──────────────────────────────────────────────────────────────

/**
 * Each entry: { type, pattern, redact? }
 * redact: optional function for post-match validation (e.g. Luhn check)
 */
const PII_PATTERNS = [
  // Specific token patterns FIRST — before generic SECRET/PHONE patterns
  {
    type: 'AWS_KEY',
    pattern: /AKIA[0-9A-Z]{16}/g,
  },
  {
    type: 'GITHUB_TOKEN',
    pattern: /gh[pousr]_[A-Za-z0-9]{36,}/g,
  },
  {
    type: 'EMAIL',
    pattern: /[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/g,
  },
  // Luhn-validated credit card BEFORE phone patterns to avoid partial digit collisions
  {
    type: 'CREDIT_CARD',
    pattern: /\b(?:\d[ \-]?){13,16}\b/g,
    validate: (match) => luhnCheck(match.replace(/[ \-]/g, '')),
  },
  {
    type: 'SSN_FR',
    pattern: /\b[12]\s*\d{2}\s*\d{2}\s*\d{2}\s*\d{3}\s*\d{3}\s*\d{2}\b/g,
  },
  {
    type: 'PHONE_FR',
    pattern: /(?:(?:\+|00)33|0)\s*[1-9](?:[\s.\-]*\d{2}){4}/g,
  },
  {
    type: 'PHONE_US',
    pattern: /\b\d{3}[.\-]?\d{3}[.\-]?\d{4}\b/g,
  },
  // Generic secret pattern LAST — catches what specific patterns above missed.
  // Negative lookahead excludes already-redacted [REDACTED:*] placeholders.
  {
    type: 'SECRET',
    pattern: /(?:password|passwd|token|secret|api[_\-]?key|auth[_\-]?key)\s*[=:]\s*(?!\[REDACTED:)\S+/gi,
  },
]

// ── Luhn algorithm ────────────────────────────────────────────────────────────

/**
 * Validates a credit card number string using the Luhn algorithm.
 * @param {string} digits — digits only, no spaces/dashes
 * @returns {boolean}
 */
function luhnCheck(digits) {
  if (!/^\d{13,16}$/.test(digits)) return false
  let sum = 0
  let shouldDouble = false
  for (let i = digits.length - 1; i >= 0; i--) {
    let d = parseInt(digits[i], 10)
    if (shouldDouble) {
      d *= 2
      if (d > 9) d -= 9
    }
    sum += d
    shouldDouble = !shouldDouble
  }
  return sum % 10 === 0
}

// ── Core functions ────────────────────────────────────────────────────────────

/**
 * Throws ADASecurityError if a prompt injection pattern is detected.
 * @param {string} text
 * @param {string} [context]
 * @param {{ internal?: boolean }} [opts]  internal:true = summaries d'agents, skip patterns externes
 * @throws {ADASecurityError}
 */
function assertSafe(text, context = 'input', opts = {}) {
  if (typeof text !== 'string') return
  const patterns = opts.internal
    ? INJECTION_PATTERNS
    : [...INJECTION_PATTERNS, ...EXTERNAL_ONLY_PATTERNS]
  for (const pattern of patterns) {
    if (pattern.test(text)) {
      // Reset lastIndex for global regexes (safety)
      if (pattern.global) pattern.lastIndex = 0
      const msg = `AIDefence: prompt injection détectée dans [${context}]`
      auditSecurityEvent('INJECTION', context, { pattern: pattern.toString().slice(0, 80) })
      throw new ADASecurityError(msg, 'INJECTION', context)
    }
  }
}

/**
 * Redacts PII from text, replacing matches with [REDACTED:TYPE].
 * @param {string} text
 * @returns {string}
 */
function redactPII(text) {
  if (typeof text !== 'string') return text
  let result = text

  for (const { type, pattern, validate } of PII_PATTERNS) {
    // Clone pattern to avoid lastIndex state issues across calls
    const re = new RegExp(pattern.source, pattern.flags)
    result = result.replace(re, (match) => {
      // If a validate function exists, only redact if it passes
      if (validate && !validate(match)) return match
      auditSecurityEvent('PII_REDACTED', 'redactPII', { type, sample: match.slice(0, 8) + '***' })
      return `[REDACTED:${type}]`
    })
  }

  return result
}

/**
 * Runs assertSafe then redactPII. Returns the sanitized text.
 * Re-throws ADASecurityError for INJECTION — other errors are swallowed gracefully.
 * @param {string} text
 * @param {string} [context]
 * @returns {string}
 * @throws {ADASecurityError} on injection
 */
function sanitize(text, context = 'input') {
  assertSafe(text, context)
  return redactPII(text)
}

/**
 * Appends a NDJSON security event to coordinator/security.log.
 * Fire-and-forget — never throws.
 * @param {'INJECTION'|'PII_REDACTED'|string} type
 * @param {string} context
 * @param {Record<string, unknown>} [detail]
 */
function auditSecurityEvent(type, context, detail = {}) {
  try {
    if (!existsSync(COORD_DIR)) mkdirSync(COORD_DIR, { recursive: true })
    const entry = JSON.stringify({
      ts:      new Date().toISOString(),
      type,
      context,
      detail,
    }) + '\n'
    appendFileSync(SECURITY_LOG, entry, 'utf8')
  } catch {
    // Never throw from audit — logging is best-effort
  }
}

// ── Exports ───────────────────────────────────────────────────────────────────

module.exports = {
  assertSafe,
  redactPII,
  sanitize,
  auditSecurityEvent,
  ADASecurityError,
}
