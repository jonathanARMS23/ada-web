#!/usr/bin/env node
'use strict'
/**
 * coordinator/agent-audit.js — Audit de discoverabilité des descriptions d'agents
 *
 * Inspiré de ruflo ADR-112 (scripts/audit-tool-descriptions.mjs) : un bon routing
 * agent/tâche dépend de descriptions distinctes et actionnables. Scanne le
 * frontmatter YAML (`name`, `description`) de chaque agent sous `.claude/agents/*.md`
 * et signale :
 *   - description absente ou < MIN_DESCRIPTION_LENGTH caractères
 *   - descriptions dupliquées ou quasi-dupliquées (similarité Jaccard sur tokens > 0.85)
 *   - description qui ne signale pas QUAND l'utiliser (absence de mot-clé technique
 *     discriminant ou de marqueur contextuel — heuristique volontairement simple)
 *
 * Baseline monotone-décroissante (agent-audit-baseline.json) : le nombre total
 * d'issues ne peut jamais augmenter en mode --check. Générée automatiquement au
 * premier run.
 *
 * Zéro dépendance npm — parsing YAML minimal maison (regex `key: value`), suffisant
 * pour le frontmatter à plat utilisé par tous les agents (pas de blocs multi-lignes).
 *
 * Usage :
 *   node agent-audit.js              # rapport humain sur .claude/agents/*.md
 *   node agent-audit.js --json       # rapport JSON
 *   node agent-audit.js --check      # exit 1 si régression vs baseline (CI gate)
 */

const { readFileSync, readdirSync, writeFileSync, existsSync, mkdirSync } = require('fs')
const { join, dirname } = require('path')

const CONFIG_DIR    = process.env.CLAUDE_CONFIG_DIR || join(process.env.HOME ?? '', '.claude')
const COORD_DIR     = join(CONFIG_DIR, 'coordinator')
const AGENTS_DIR    = join(CONFIG_DIR, 'agents')
const BASELINE_FILE = join(COORD_DIR, 'agent-audit-baseline.json')

const MIN_DESCRIPTION_LENGTH = 60
const DUPLICATE_THRESHOLD    = 0.85

// Fichiers non-agents à ignorer par convention de nommage (README, notes…).
// Générique : n'importe quel *.md sans frontmatter valide est simplement ignoré
// (pas compté en issue) SAUF s'il ressemble à une définition d'agent (a un nom
// de fichier "normal") — voir parseAgentFile().
const SKIP_FILENAME_PATTERN = /^readme/i

// Mots-clés techniques/domaine considérés comme "discriminants" — une description
// qui en cite au moins un dit implicitement QUAND l'utiliser (le domaine suffit à
// router). Liste volontairement large mais plate — pas de NLP.
const DISCRIMINATING_KEYWORDS = [
  'nestjs', 'next.js', 'nextjs', 'react', 'django', 'drf', 'python', 'fastapi', 'node',
  'typescript', 'postgresql', 'postgres', 'supabase', 'sql', 'mysql', 'mongodb', 'redis',
  'graphql', 'prisma', 'docker', 'kubernetes', 'k8s', 'aws', 'vercel', 'railway', 'ci/cd',
  'github actions', 'terraform', 'ios', 'swift', 'swiftui', 'android', 'kotlin', 'jetpack',
  'expo', 'react native', 'websocket', 'sse', 'grpc', 'llm', 'openai', 'anthropic', 'claude',
  'langgraph', 'ollama', 'whisper', 'rag', 'embedding', 'vector', 'ml ', 'machine learning',
  'sécurité', 'owasp', 'audit', 'pentest', 'performance', 'benchmark', 'architecture',
  'microservice', 'ux', 'ui', 'wireframe', 'design', 'migration', 'base de données', 'devops',
  'monitoring', 'observabilité', 'otel', 'grafana', 'prometheus', 'test', 'tdd', 'jest',
  'pytest', 'playwright', 'consensus', 'byzantin', 'swarm', 'raft', 'gossip', 'crdt',
  'sparc', 'github', 'release', 'openapi', 'api', 'blockchain', 'trading', 'neural',
  'orchestrat', 'coordinat', 'goal', 'planif', 'quorum', 'mesh',
]

// Marqueur contextuel explicite ("quand l'utiliser" écrit en toutes lettres).
const CONTEXT_MARKER_RE = /\bquand\b|\blorsque\b|\bpour\s+(les|des|la|le)\b|use when|when to use/i

// ── Parsing frontmatter minimal ───────────────────────────────────────────────

/**
 * Extrait les champs `key: value` du frontmatter YAML à plat (--- ... ---).
 * @param {string} raw contenu complet du fichier
 * @returns {Record<string,string>|null} null si aucun frontmatter détecté
 */
function parseFrontmatter(raw) {
  if (typeof raw !== 'string' || !raw.startsWith('---')) return null
  const end = raw.indexOf('\n---', 3)
  if (end === -1) return null

  const block = raw.slice(3, end).replace(/^\n/, '')
  const fields = {}
  let currentKey = null

  for (const line of block.split('\n')) {
    const m = line.match(/^([a-zA-Z0-9_-]+):\s*(.*)$/)
    if (m) {
      currentKey = m[1]
      fields[currentKey] = m[2].trim()
    } else if (currentKey && /^\s+\S/.test(line)) {
      // Continuation d'une valeur repliée sur plusieurs lignes (rare dans ce corpus).
      fields[currentKey] = `${fields[currentKey]} ${line.trim()}`.trim()
    }
  }
  return fields
}

/**
 * Parse un fichier agent complet : { name, description, hasFrontmatter }.
 * @param {string} filePath
 * @returns {{ name: string|null, description: string, hasFrontmatter: boolean }}
 */
function parseAgentFile(filePath) {
  const raw = readFileSync(filePath, 'utf8')
  const fm = parseFrontmatter(raw)
  if (!fm) return { name: null, description: '', hasFrontmatter: false }
  return {
    name: fm.name || null,
    description: fm.description || '',
    hasFrontmatter: true,
  }
}

// ── Normalisation / similarité ────────────────────────────────────────────────

/**
 * Tokenise une description : minuscule, accents retirés, ponctuation supprimée.
 * @param {string} text
 * @returns {string[]}
 */
function normalizeTokens(text) {
  return String(text || '')
    .toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter(Boolean)
}

/**
 * Similarité de Jaccard entre deux ensembles de tokens.
 * @param {string[]} aTokens
 * @param {string[]} bTokens
 * @returns {number} ∈ [0,1]
 */
function jaccard(aTokens, bTokens) {
  const a = new Set(aTokens)
  const b = new Set(bTokens)
  if (!a.size && !b.size) return 1
  let inter = 0
  for (const t of a) if (b.has(t)) inter++
  const union = new Set([...a, ...b]).size
  return union === 0 ? 0 : inter / union
}

/**
 * Une description signale-t-elle QUAND l'utiliser ? Heuristique simple :
 * marqueur contextuel explicite OU présence d'au moins un mot-clé discriminant.
 * @param {string} description
 * @returns {boolean}
 */
function hasWhenToUseSignal(description) {
  const desc = String(description || '').toLowerCase()
  if (!desc) return false
  if (CONTEXT_MARKER_RE.test(desc)) return true
  return DISCRIMINATING_KEYWORDS.some(k => desc.includes(k))
}

// ── Audit ──────────────────────────────────────────────────────────────────────

/**
 * Liste les fichiers *.md à auditer dans un répertoire d'agents (non récursif).
 * @param {string} agentsDir
 * @returns {string[]} noms de fichiers
 */
function listAgentFiles(agentsDir) {
  if (!existsSync(agentsDir)) return []
  return readdirSync(agentsDir, { withFileTypes: true })
    .filter(e => e.isFile() && e.name.endsWith('.md'))
    .map(e => e.name)
    .sort()
}

/**
 * Audite l'ensemble des agents d'un répertoire.
 * @param {string} agentsDir
 * @returns {{ scannedAt: string, totalAgents: number, issues: Array<object>, countsByType: Record<string,number> }}
 */
function runAudit(agentsDir = AGENTS_DIR) {
  const files = listAgentFiles(agentsDir)
  const entries = []

  for (const file of files) {
    if (SKIP_FILENAME_PATTERN.test(file)) continue
    const filePath = join(agentsDir, file)
    const parsed = parseAgentFile(filePath)
    if (!parsed.hasFrontmatter) continue // pas un agent (doc, note…) — pas une issue
    entries.push({ file, name: parsed.name || file, description: parsed.description })
  }

  const issues = []

  // 1) Description absente ou trop courte.
  for (const e of entries) {
    const len = e.description.length
    if (len < MIN_DESCRIPTION_LENGTH) {
      issues.push({
        type: 'short-description',
        agent: e.name,
        file: e.file,
        detail: len === 0
          ? 'description absente'
          : `description trop courte (${len} < ${MIN_DESCRIPTION_LENGTH} caractères)`,
      })
    }
  }

  // 2) Ne signale pas quand l'utiliser.
  for (const e of entries) {
    if (e.description && !hasWhenToUseSignal(e.description)) {
      issues.push({
        type: 'no-when-to-use',
        agent: e.name,
        file: e.file,
        detail: `aucun marqueur contextuel ni mot-clé discriminant dans: "${e.description.slice(0, 100)}"`,
      })
    }
  }

  // 3) Duplicatas / quasi-duplicatas (comparaison par paire — O(n²), n~100 : trivial).
  const withDesc = entries.filter(e => e.description)
  const tokensByEntry = withDesc.map(e => ({ e, tokens: normalizeTokens(e.description) }))
  const duplicatePairs = []
  for (let i = 0; i < tokensByEntry.length; i++) {
    for (let j = i + 1; j < tokensByEntry.length; j++) {
      const sim = jaccard(tokensByEntry[i].tokens, tokensByEntry[j].tokens)
      if (sim > DUPLICATE_THRESHOLD) {
        duplicatePairs.push({
          a: tokensByEntry[i].e.name,
          b: tokensByEntry[j].e.name,
          similarity: Math.round(sim * 100) / 100,
        })
      }
    }
  }
  for (const pair of duplicatePairs) {
    issues.push({
      type: 'duplicate-description',
      agent: pair.a,
      file: null,
      detail: `quasi-duplicat de '${pair.b}' (similarité ${pair.similarity})`,
    })
  }

  const countsByType = {}
  for (const issue of issues) {
    countsByType[issue.type] = (countsByType[issue.type] || 0) + 1
  }

  return {
    scannedAt: new Date().toISOString(),
    totalAgents: entries.length,
    issues,
    countsByType,
    totalIssues: issues.length,
  }
}

// ── Baseline monotone-décroissante ────────────────────────────────────────────

function loadBaseline(baselineFile = BASELINE_FILE) {
  if (!existsSync(baselineFile)) return null
  try {
    return JSON.parse(readFileSync(baselineFile, 'utf8'))
  } catch {
    return null
  }
}

function saveBaseline(maxIssues, baselineFile = BASELINE_FILE, extra = {}) {
  const dir = dirname(baselineFile)
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true })
  writeFileSync(
    baselineFile,
    JSON.stringify({ maxIssues, updatedAt: new Date().toISOString(), ...extra }, null, 2) + '\n',
    'utf8'
  )
}

/**
 * Compare le nombre d'issues courant à la baseline et met à jour le fichier si
 * amélioration. Ne peut jamais laisser passer une régression.
 * @param {number} currentIssues
 * @param {string} [baselineFile]
 * @returns {{ status: 'created'|'regression'|'improved'|'stable', maxIssues: number, previous: number|null }}
 */
function checkBaseline(currentIssues, baselineFile = BASELINE_FILE) {
  const baseline = loadBaseline(baselineFile)

  if (!baseline || typeof baseline.maxIssues !== 'number') {
    saveBaseline(currentIssues, baselineFile)
    return { status: 'created', maxIssues: currentIssues, previous: null }
  }

  if (currentIssues > baseline.maxIssues) {
    return { status: 'regression', maxIssues: baseline.maxIssues, previous: baseline.maxIssues }
  }

  if (currentIssues < baseline.maxIssues) {
    saveBaseline(currentIssues, baselineFile)
    return { status: 'improved', maxIssues: currentIssues, previous: baseline.maxIssues }
  }

  return { status: 'stable', maxIssues: baseline.maxIssues, previous: baseline.maxIssues }
}

module.exports = {
  parseFrontmatter,
  parseAgentFile,
  normalizeTokens,
  jaccard,
  hasWhenToUseSignal,
  listAgentFiles,
  runAudit,
  loadBaseline,
  saveBaseline,
  checkBaseline,
  MIN_DESCRIPTION_LENGTH,
  DUPLICATE_THRESHOLD,
}

// ── CLI ───────────────────────────────────────────────────────────────────────

if (require.main === module) {
  const args = process.argv.slice(2)
  const jsonMode  = args.includes('--json')
  const checkMode = args.includes('--check')

  const report = runAudit(AGENTS_DIR)

  if (jsonMode) {
    console.log(JSON.stringify(report, null, 2))
  } else {
    console.log('Agent description discoverability audit')
    console.log('========================================')
    console.log(`Agents scannés :          ${report.totalAgents}`)
    console.log(`Issues totales :          ${report.totalIssues}`)
    for (const [type, count] of Object.entries(report.countsByType)) {
      console.log(`  ${type}: ${count}`)
    }
    if (report.issues.length) {
      console.log('\nTop offenders :')
      for (const issue of report.issues.slice(0, 20)) {
        console.log(`  [${issue.type}] ${issue.agent} — ${issue.detail}`)
      }
      if (report.issues.length > 20) {
        console.log(`  … et ${report.issues.length - 20} de plus`)
      }
    }
  }

  if (checkMode) {
    const result = checkBaseline(report.totalIssues)
    if (result.status === 'regression') {
      console.error(`\nFAIL — ${report.totalIssues} issues dépasse la baseline (${result.maxIssues})`)
      console.error(`  Régression : ${report.totalIssues - result.maxIssues} nouvelle(s) violation(s)`)
      process.exit(1)
    }
    if (result.status === 'improved') {
      console.log(`\nProgress — baseline abaissée de ${result.previous} à ${result.maxIssues}`)
    } else if (result.status === 'created') {
      console.log(`\nBaseline créée : maxIssues=${result.maxIssues}`)
    } else {
      console.log(`\nOK — stable à ${result.maxIssues} issues`)
    }
  }
}
