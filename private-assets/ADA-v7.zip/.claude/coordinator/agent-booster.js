#!/usr/bin/env node
'use strict'
/**
 * coordinator/agent-booster.js — Tier 0 : transformations déterministes sans LLM
 *
 * Usage CLI :
 *   node agent-booster.js detect "var x = 1"        → JSON { rule, confidence }
 *   node agent-booster.js apply <file> <rule>        → résultat transformé
 *   node agent-booster.js list                       → toutes les règles disponibles
 */

const { readFileSync } = require('fs')

// ── Règles de transformation ───────────────────────────────────────────────────

const RULES = {
  'var-to-const': {
    description: 'Remplace var par const/let (heuristique réassignation)',
    detect: code => /\bvar\s+\w/.test(code),
    apply: code => {
      // Détecter les variables réassignées : var x = ...; ... x = ...
      // On ne peut pas faire ça avec un regex simple → on utilise une heuristique :
      // si le nom de la variable apparaît à gauche d'un = (sans var/const/let) → let, sinon const
      return code.replace(/\bvar\s+(\w+)\s*=/g, (match, name) => {
        // Pattern de réassignation : `name =` sans mot-clé devant
        const reassignPattern = new RegExp(`(?<![a-zA-Z0-9_$])${name}\\s*=(?!=)`, 'g')
        // Compter les occurrences hors la déclaration elle-même
        const allMatches = [...code.matchAll(reassignPattern)]
        // S'il y a plus d'une occurrence → la variable est réassignée → let
        return allMatches.length > 1 ? `let ${name} =` : `const ${name} =`
      })
    },
  },

  'remove-console': {
    description: 'Supprime les console.log/debug/warn',
    detect: code => /console\.(log|debug|warn)\(/.test(code),
    apply: code => code.replace(/^\s*console\.(log|debug|warn)\([^)]*\);?\n?/gm, ''),
  },

  'add-strict': {
    description: "Ajoute 'use strict' si absent",
    detect: code => !code.includes("'use strict'") && !code.includes('"use strict"'),
    apply: code => `'use strict'\n${code}`,
  },

  'normalize-quotes': {
    description: 'Normalise double quotes → single quotes (hors template literals)',
    detect: code => /"[^"]*"/.test(code) && !code.includes('`'),
    apply: code => code.replace(/"([^"\\]*)"/g, "'$1'"),
  },

  'trim-trailing-whitespace': {
    description: 'Supprime les espaces en fin de ligne',
    detect: code => /[ \t]+$/m.test(code),
    apply: code => code.split('\n').map(l => l.trimEnd()).join('\n'),
  },

  'add-semicolons': {
    description: 'Ajoute les points-virgules manquants sur les statements simples',
    detect: code => /^\s*(const|let|var|return|throw)\s+[^{;]+$/m.test(code),
    apply: code => code.replace(/^(\s*(?:const|let|var|return|throw)\s+[^{;\n]+)$/gm, '$1;'),
  },
}

// ── canBoost ───────────────────────────────────────────────────────────────────

/**
 * Détermine si une tâche peut être gérée par le Tier 0 sans LLM.
 * @param {{ type: string, content: string }} task
 * @returns {{ boosted: boolean, rule?: string, confidence: number }}
 */
function canBoost(task) {
  const { content } = task
  if (!content || typeof content !== 'string') {
    return { boosted: false, confidence: 0 }
  }

  const applicable = Object.entries(RULES)
    .filter(([, rule]) => rule.detect(content))
    .map(([name]) => name)

  if (!applicable.length) {
    return { boosted: false, confidence: 0 }
  }

  // Confidence basé sur : nombre de règles applicables + taille du code
  // Plus le code est court et les règles nombreuses → plus on est confiant
  const ruleScore    = Math.min(applicable.length / Object.keys(RULES).length, 1)
  const sizeScore    = Math.max(0, 1 - content.length / 2000)  // pénalise les grands fichiers
  const confidence   = ruleScore * 0.6 + sizeScore * 0.4

  // Priorité : prendre la première règle applicable (ordre de définition)
  const topRule = applicable[0]

  return {
    boosted:    confidence > 0.8 || (applicable.length >= 2 && confidence > 0.5),
    rule:       topRule,
    confidence: parseFloat(confidence.toFixed(3)),
    allRules:   applicable,
  }
}

/**
 * Applique une règle nommée sur un code source.
 * @param {string} code
 * @param {string} ruleName
 * @returns {string}
 */
function applyRule(code, ruleName) {
  const rule = RULES[ruleName]
  if (!rule) throw new Error(`Règle inconnue : ${ruleName}`)
  return rule.apply(code)
}

/**
 * Détecte les règles applicables sur un code source.
 * @param {string} code
 * @returns {Array<{ name: string, description: string }>}
 */
function detectRules(code) {
  return Object.entries(RULES)
    .filter(([, rule]) => rule.detect(code))
    .map(([name, rule]) => ({ name, description: rule.description }))
}

// ── CLI ────────────────────────────────────────────────────────────────────────

if (require.main === module) {
  const [,, cmd, ...args] = process.argv

  const C = {
    reset: '\x1b[0m', bold: '\x1b[1m',
    green: '\x1b[32m', red: '\x1b[31m', yellow: '\x1b[33m',
    cyan: '\x1b[36m', gray: '\x1b[90m',
  }

  switch (cmd) {
    case 'detect': {
      const code = args.join(' ')
      if (!code) { console.error('Usage: agent-booster.js detect "<code>"'); process.exit(1) }
      const applicable = detectRules(code)
      if (!applicable.length) {
        console.log(JSON.stringify({ applicable: [], message: 'Aucune règle applicable' }))
      } else {
        console.log(JSON.stringify({ applicable }, null, 2))
      }
      break
    }

    case 'apply': {
      const [filePath, ruleName] = args
      if (!filePath || !ruleName) {
        console.error('Usage: agent-booster.js apply <file> <rule>')
        process.exit(1)
      }
      try {
        const code = readFileSync(filePath, 'utf8')
        const result = applyRule(code, ruleName)
        process.stdout.write(result)
      } catch (err) {
        console.error(err.message)
        process.exit(1)
      }
      break
    }

    case 'list': {
      console.log(`\n${C.bold}Agent Booster Tier 0 — Règles disponibles${C.reset}\n`)
      for (const [name, rule] of Object.entries(RULES)) {
        console.log(`  ${C.cyan}${name.padEnd(28)}${C.reset} ${rule.description}`)
      }
      console.log('')
      break
    }

    default: {
      console.log(`\n${C.bold}coordinator/agent-booster.js — Tier 0${C.reset}\n`)
      console.log('  detect "<code>"        Affiche les règles applicables')
      console.log('  apply  <file> <rule>   Applique une règle sur un fichier')
      console.log('  list                   Liste toutes les règles avec description')
      console.log('')
    }
  }
}

// ── Exports ────────────────────────────────────────────────────────────────────

module.exports = { canBoost, applyRule, detectRules, RULES }
