/**
 * coordinator/bank-hnsw.js — index ANN persistant (HNSW) + cache TF-IDF du ReasoningBank.
 *
 * Extrait de bank.js (axe C3 — découpe du god-object). Ce module DÉTIENT en propre
 * l'état module-level de l'index ANN (graphe HNSW + vocabulaire) et du cache TF-IDF.
 * C'est volontaire : ces variables ne sont mutées QUE par les fonctions ci-dessous,
 * donc les héberger ici préserve le singleton (un seul graphe HNSW, un seul cache en
 * mémoire pour tout le runtime) sans état partagé qui fuirait vers bank.js.
 *
 * Aucune injection nécessaire : les constantes (chemins, modèle) sont dérivées
 * exactement comme dans bank.js → même fichier de persistance = même singleton disque.
 */

const { readFileSync, writeFileSync, existsSync } = require('fs')
const { join } = require('path')
const os = require('os')
const { buildIndex, HNSW, tokenize: embedTokenize } = require(join(__dirname, 'embeddings.js'))

const CONFIG_DIR = process.env.CLAUDE_CONFIG_DIR || join(process.env.HOME ?? os.homedir(), '.claude')
const COORD_DIR  = join(CONFIG_DIR, 'coordinator')
const HNSW_FILE  = join(COORD_DIR, 'bank-hnsw.json')

// ── HNSW persistent graph ─────────────────────────────────────────────────────
// Shared vocabulary is stored alongside the graph so vector dimensions stay stable.
let _hnsw      = null   // HNSW instance
let _hnswVocab = []     // string[] — ordered list for stable vector dimensions
let _hnswVocabSet = new Set()  // O(1) membership check (mirrors _hnswVocab)
let _hnswTimer = null   // debounce handle for lazy persistence

// ── TF-IDF index cache ────────────────────────────────────────────────────────
let _indexCache = null
let _indexCacheKey = -1

/** Load HNSW from bank-hnsw.json (if present) or create a fresh instance. */
function _getOrLoadHNSW() {
  if (_hnsw) return _hnsw
  if (existsSync(HNSW_FILE)) {
    try {
      const data = JSON.parse(readFileSync(HNSW_FILE, 'utf8'))
      _hnsw        = HNSW.deserialize(data.graph)
      _hnswVocab   = data.vocab || []
      _hnswVocabSet = new Set(_hnswVocab)
      return _hnsw
    } catch (e) {
      require('./logger').warn('bank', 'HNSW load failed — rebuilding empty index (past trajectories lost from ANN)', { file: HNSW_FILE, error: e?.message })
    }
  }
  _hnsw        = new HNSW(8, 50)
  _hnswVocab   = []
  _hnswVocabSet = new Set()
  return _hnsw
}

/** Build a TF-IDF term-frequency dense vector using the shared vocab. */
function _toHNSWVector(tokens) {
  if (!_hnswVocab.length) return null
  const freq = {}
  for (const tok of tokens) freq[tok] = (freq[tok] || 0) + 1
  return _hnswVocab.map(v => (freq[v] || 0) / (tokens.length || 1))
}

/** Insert trajectory into the persistent HNSW graph. */
function _hnswInsert(traj) {
  try {
    const hnsw = _getOrLoadHNSW()
    const tokens = embedTokenize(`${traj.phase} ${traj.agent} ${traj.task || ''} ${traj.summary}`)
    // Grow vocabulary with any new tokens (must add before vectorising)
    let vocabGrew = false
    for (const tok of tokens) {
      if (!_hnswVocabSet.has(tok)) { _hnswVocab.push(tok); _hnswVocabSet.add(tok); vocabGrew = true }
    }
    if (vocabGrew) {
      // Rebuild vectors for existing nodes so dimensions stay consistent —
      // only feasible while the graph is small; skip if too large to avoid O(n²).
      if (hnsw.size > 500) return  // dimension drift acceptable beyond threshold
    }
    const vec = _toHNSWVector(tokens)
    if (vec) hnsw.insert(traj.id, vec)
    _scheduleHNSWSave()
  } catch (e) {
    require('./logger').warn('bank', '_hnswInsert failed — trajectory not indexed in ANN', { id: traj?.id, error: e?.message })
  }
}

/** Persist HNSW graph with a 5s debounce to avoid write storms. */
function _scheduleHNSWSave() {
  if (_hnswTimer) clearTimeout(_hnswTimer)
  _hnswTimer = setTimeout(_persistHNSW, 5000)
}

function _persistHNSW() {
  _hnswTimer = null
  if (!_hnsw || !_hnsw.size) return
  try {
    const tmp = HNSW_FILE + '.tmp'
    writeFileSync(tmp, JSON.stringify({ graph: _hnsw.serialize(), vocab: _hnswVocab }), 'utf8')
    const { renameSync } = require('fs')
    renameSync(tmp, HNSW_FILE)
  } catch (e) {
    require('./logger').warn('bank', '_persistHNSW write failed — HNSW not saved, will be lost on restart', { file: HNSW_FILE, error: e?.message })
  }
}

function getCachedIndex(docs, _legacyKey) {
  // P6 — clé dérivée du POOL (taille + ids de bord), pas du compteur global _storeCount.
  // Corrige : (a) collision entre pools différents (retrieve cap 500 vs retrieveAsync) qui
  // partageaient _storeCount → index erroné servi ; (b) rebuild IDF inutile à chaque store
  // quand le pool interrogé n'a pas changé.
  const key = `${docs.length}:${docs[0]?.id || ''}:${docs[docs.length - 1]?.id || ''}`
  if (_indexCache !== null && _indexCacheKey === key) return _indexCache
  _indexCache = buildIndex(docs)
  _indexCacheKey = key
  return _indexCache
}

module.exports = {
  HNSW_FILE,
  _getOrLoadHNSW,
  _toHNSWVector,
  _hnswInsert,
  _scheduleHNSWSave,
  _persistHNSW,
  getCachedIndex,
}
