/**
 * coordinator/bank-ranking.js — scoring & ranking du ReasoningBank.
 *
 * Extrait de bank.js (axe C3 — découpe du god-object). Regroupe :
 *   scoreTrajectory · judgeTrajectory · computeTrajectoryImportance ·
 *   scoreTrajectoryForStream · applyGraphBoost · smartRetrieve · cosineSimilarity
 *
 * Choix de design — injection de dépendances (DI) plutôt que require croisé :
 * ces fonctions lisent des helpers et des constantes détenus par bank.js
 * (getDB, tokenize, daysSince, loadAllTrajectories, MAX_TRAJECTORIES, CONFIG_DIR,
 * CANDIDATE_PHASE, CONVENTION_BOOST). Pour éviter tout import circulaire
 * (bank ↔ bank-ranking), bank.js appelle `init(deps)` UNE fois au chargement et
 * récupère les fonctions liées. Le singleton DB reste intact : la DI passe la
 * MÊME référence `getDB` que bank.js utilise partout ailleurs.
 */

const { join } = require('path')

/** Similarité cosinus — sans dépendance, exposée directement. */
function cosineSimilarity(a, b) {
  if (!a || !b || a.length !== b.length) return 0
  let dot = 0, normA = 0, normB = 0
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i]; normA += a[i] * a[i]; normB += b[i] * b[i]
  }
  return dot / (Math.sqrt(normA) * Math.sqrt(normB) + 1e-10)
}

/**
 * @typedef {object} RankingDeps
 * @property {Function} getDB
 * @property {Function} tokenize
 * @property {Function} daysSince
 * @property {Function} loadAllTrajectories
 * @property {Function} embedTokenize
 * @property {number}   MAX_TRAJECTORIES
 * @property {string}   CONFIG_DIR
 * @property {string}   CANDIDATE_PHASE
 * @property {number}   CONVENTION_BOOST
 * @property {string}   __dirname   répertoire de bank.js (pour pipelines.json)
 */

/**
 * Lie les fonctions de ranking à leurs dépendances bank.js.
 * @param {RankingDeps} deps
 */
function init(deps) {
  const {
    getDB, tokenize, daysSince, loadAllTrajectories, embedTokenize,
    CONFIG_DIR, CANDIDATE_PHASE, CONVENTION_BOOST, bankDir,
  } = deps

  /**
   * P0-2 — Pertinence CONTENU pure : similarité requête↔contenu UNIQUEMENT.
   * Aucune contribution de récence/verdict/phase/agent. C'est le seul signal sur
   * lequel on SEUILLE l'injection (voir _assembleRecallBlock). Le bruit
   * récence/verdict ne doit jamais faire franchir le seuil à une entrée hors-sujet.
   *
   * @returns {number} ∈ [0, ~6] selon la branche (embedding > tfidf > overlap)
   */
  function contentRelevance(traj, queryTokens, queryEmbedding = null, tfidfScore = null) {
    if (queryEmbedding && traj.embedding) {
      return cosineSimilarity(queryEmbedding, traj.embedding) * 6
    }
    if (tfidfScore !== null) {
      return tfidfScore * 0.7
    }
    let s = 0
    const trajTokens = new Set([...(traj.tags || []), ...tokenize(traj.summary || '')])
    for (const qt of (queryTokens || [])) if (trajTokens.has(qt)) s += 1
    return s
  }

  function scoreTrajectory(traj, queryTokens, phaseFilter, agentFilter, queryEmbedding = null, tfidfScore = null) {
    let score = 0

    // A1-auto — ISOLATION INJECTION : les candidats de convention (file séparée,
    // non encore validés) ne doivent JAMAIS remonter via retrieve/recall, quel que
    // soit le query. On les exclut du scoring SAUF si on filtre explicitement sur
    // leur phase (ex: listing CLI via db.getByPhase, qui ne passe pas par ici de toute
    // façon — ce garde-fou couvre tout appel retrieve/buildRecallBlock).
    if (traj.phase === CANDIDATE_PHASE && phaseFilter !== CANDIDATE_PHASE) return 0

    if (phaseFilter && traj.phase === phaseFilter) score += 4
    if (agentFilter && traj.agent === agentFilter) score += 3

    // P0-2 — composante CONTENU (extraite, réutilisable). On la stampe sur la traj
    // (champ non-énumérable lu par _assembleRecallBlock) pour seuiller l'injection
    // sur le contenu seul, sans que récence/verdict puissent maquiller un hors-sujet.
    const content = contentRelevance(traj, queryTokens, queryEmbedding, tfidfScore)
    score += content
    try {
      Object.defineProperty(traj, '_content', { value: content, configurable: true, enumerable: false, writable: true })
    } catch {}

    const age = daysSince(traj.ts)
    score += Math.max(0, 2 - age / 15)

    if (traj.verdict === 'success') score += 0.5

    // A3 — Boost convention : les conventions projet (tag `convention`) sont des
    // règles prioritaires. On ne booste QUE si la convention matche RÉELLEMENT la
    // requête sur le CONTENU (embedding/TF-IDF/overlap de tokens) — pas via le bonus
    // de récence/verdict universel ci-dessus, qui rendrait toute convention récente
    // boostée même hors-sujet. N'affecte ni les non-conventions ni les conventions
    // sans lien avec la requête.
    if (Array.isArray(traj.tags) && traj.tags.includes('convention')) {
      let contentMatch = false
      if (queryEmbedding && traj.embedding) {
        contentMatch = cosineSimilarity(queryEmbedding, traj.embedding) > 0.1
      } else if (tfidfScore !== null) {
        contentMatch = tfidfScore > 0
      } else if (queryTokens && queryTokens.length) {
        const trajTokens = new Set([...(traj.tags || []), ...tokenize(traj.summary)])
        contentMatch = queryTokens.some(qt => trajTokens.has(qt))
      }
      if (contentMatch) score += CONVENTION_BOOST
    }

    // Les insights de topic (promotion Obsidian→bank) sont du contexte SUPPLÉMENTAIRE :
    // ils cèdent face à une trajectoire spécifique de pertinence comparable, mais
    // restent récupérables quand rien de plus précis ne matche.
    if (traj.phase === 'topic') score *= 0.7

    return score
  }

  /**
   * LLM-as-judge (version déterministe) — évalue la qualité d'une trajectoire.
   * Score heuristique basé sur 4 critères.
   * @param {{ verdict?: string, summary?: string, duration?: number|null, usage_count?: number, ts?: string }} traj
   * @returns {{ score: number, signals: string[], keep: boolean }}  score ∈ [0, 1]
   */
  function judgeTrajectory(traj) {
    const signals = []
    let score = 0.5  // base

    // Critère 1 : verdict (success = +0.3, partial = 0, failure = -0.2)
    if (traj.verdict === 'success') { score += 0.3; signals.push('success') }
    else if (traj.verdict === 'failure') { score -= 0.2; signals.push('failure') }

    // Critère 2 : richesse du summary (> 100 chars = +0.1)
    if ((traj.summary || '').length > 100) { score += 0.1; signals.push('rich-summary') }

    // Critère 3 : durée raisonnable (< 60000 ms = +0.05, outlier > 300000 = -0.1)
    if (traj.duration > 0 && traj.duration < 60000) { score += 0.05; signals.push('fast') }
    else if (traj.duration > 300000) { score -= 0.1; signals.push('slow') }

    // Critère 4 : usage_count > 0 = trajectoire référencée (+0.05)
    if ((traj.usage_count || 0) > 0) { score += 0.05; signals.push('referenced') }

    const finalScore = Math.max(0, Math.min(1, score))
    return { score: finalScore, signals, keep: finalScore >= 0.5 }
  }

  /**
   * Importance d'une trajectoire = f(usage_count, tier, verdict, recency)
   * Retourne un score ∈ [0, 1] — 1 = très important (à protéger)
   *
   * @param {{ usage_count?: number, tier?: string, verdict?: string, ts?: string }} traj
   * @returns {number} importance ∈ [0, 1]
   */
  function computeTrajectoryImportance(traj) {
    const usageScore   = Math.min(1, (traj.usage_count || 0) / 10)  // saturé à 10 usages
    const tierScore    = traj.tier === 'long' ? 0.5 : 0             // LTM = déjà promu
    const verdictScore = traj.verdict === 'success' ? 0.3 : 0
    const recencyDays  = traj.ts
      ? (Date.now() - new Date(traj.ts).getTime()) / 86_400_000
      : 0
    const recencyScore = Math.exp(-recencyDays / 30) * 0.2          // half-life 30j

    return Math.min(1, usageScore + tierScore + verdictScore + recencyScore)
  }

  /**
   * Calcule le score d'une trajectoire pour la version streaming.
   * Délègue à scoreTrajectory (TF-IDF uniquement — Ollama non disponible en sync stream).
   * @param {import('./bank.js').Trajectory} traj
   * @param {string} query
   * @param {{ phase?: string, agent?: string }} opts
   * @returns {number}
   */
  function scoreTrajectoryForStream(traj, query, opts) {
    const queryTokens = tokenize(query)
    const phaseFilter = opts.phase || null
    const agentFilter = opts.agent || null
    return scoreTrajectory(traj, queryTokens, phaseFilter, agentFilter, null, null)
  }

  /**
   * Graph boost (Graphify) — multiplie le score de chaque trajectoire par
   * (1 + scoreAgentPhase × 0.3) puis re-trie. Dégradation gracieuse si graphe absent.
   * Utilisé par smartRetrieve ET par le retrieve/retrieveAsync par défaut.
   * @param {Array<object>} results  trajectoires portant un champ de score
   * @param {string} [scoreField='score']  nom du champ ('score' ou '_score')
   * @returns {Array<object>} results (muté + re-trié)
   */
  function applyGraphBoost(results, scoreField = 'score') {
    if (!results || !results.length) return results
    try {
      const { loadOrBuild } = require('./graph-builder.js')
      const graphPath = join(CONFIG_DIR, 'coordinator', 'graph-state.json')
      const bankPath  = join(CONFIG_DIR, 'coordinator', 'bank-state.json')
      const pipPath   = join(bankDir, 'pipelines.json')
      const graph = loadOrBuild({ graphPath, bankStatePath: bankPath, pipelinesPath: pipPath, maxAgeMs: 3_600_000 })
      if (graph && graph.nodes.size > 0) {
        for (const traj of results) {
          const boost = graph.scoreAgentPhase(traj.agent, traj.phase)
          traj[scoreField] = (traj[scoreField] || 0) * (1 + boost * 0.3)
          if (boost > 0) traj._graphBoost = parseFloat(boost.toFixed(3))
        }
        results.sort((a, b) => (b[scoreField] || 0) - (a[scoreField] || 0))
      }
    } catch (e) {
      require('./logger').warn('bank', 'applyGraphBoost failed — returning without boost', { error: e?.message })
    }
    return results
  }

  /**
   * smartRetrieve — pipeline SmartRetrieval 4 étapes.
   * query → expandQuery → [score par variante] → RRF → MMR → top-N
   *
   * @param {string} query
   * @param {{ phase?: string, agent?: string, limit?: number, lambda?: number }} [opts]
   * @returns {import('./bank.js').Trajectory[]}
   */
  function smartRetrieve(query, opts = {}) {
    const limit = opts.limit ?? 5
    const { expandQuery, reciprocalRankFusion, maximalMarginalRelevance } = require('./embeddings.js')

    // Étape 1 — Query expansion
    const queries = expandQuery(query, { phase: opts.phase, maxVariants: 3 })

    // Étape 2 — Multi-ranking
    const trajectories = loadAllTrajectories(opts.phase || null)
    if (trajectories.length === 0) return []

    const rankedLists = queries.map(q => {
      const qTokens  = tokenize(q)
      const phaseFilter = opts.phase || null
      const agentFilter = opts.agent || null
      return trajectories
        .map(traj => ({
          id:     traj.id,
          score:  scoreTrajectory(traj, qTokens, phaseFilter, agentFilter, null, null),
          tokens: embedTokenize(`${traj.phase} ${traj.agent} ${traj.summary || ''}`),
        }))
        .filter(r => r.score > 0)
        .sort((a, b) => b.score - a.score)
    })

    // Étape 3 — RRF avec recency boost
    const tsMap = new Map(trajectories.map(t => [t.id, t.ts]))
    const fused = reciprocalRankFusion(rankedLists, 60, {
      recency:  opts.recency ?? true,
      halfLife: opts.halfLife ?? 30,
      tsMap,
    })
    if (fused.length === 0) return []

    // Étape 4 — MMR
    const candidateIds = new Set(fused.slice(0, limit * 3).map(r => r.id))
    const candidates = trajectories
      .filter(t => candidateIds.has(t.id))
      .map(t => {
        const rrfEntry = fused.find(f => f.id === t.id)
        return {
          ...t,
          score:  rrfEntry?.rrfScore || 0,
          tokens: embedTokenize(`${t.phase} ${t.agent} ${t.summary || ''}`),
        }
      })

    const queryTokens = embedTokenize(query)
    const reranked = maximalMarginalRelevance(candidates, queryTokens, {
      lambda: opts.lambda ?? 0.6,
      topK:   limit,
    })

    let results = reranked.map(({ mmrScore: _mmr, tokens: _tok, ...traj }) => traj)

    // Étape 5 — Graph boost (Graphify)
    applyGraphBoost(results, 'score')

    for (const traj of results) {
      try { getDB().incrementUsage(traj.id) } catch (e) {
        require('./logger').warn('bank', 'incrementUsage failed — usage_count will be incorrect for LTM promotion', { id: traj?.id, error: e?.message })
      }
    }
    return results
  }

  return {
    scoreTrajectory,
    contentRelevance,   // P0-2 — pertinence contenu pure (seuillage injection)
    judgeTrajectory,
    computeTrajectoryImportance,
    scoreTrajectoryForStream,
    applyGraphBoost,
    smartRetrieve,
  }
}

module.exports = { init, cosineSimilarity }
