#!/usr/bin/env node
/**
 * coordinator/bank.js — ReasoningBank : mémoire par trajectoires structurées
 *
 * Pipeline STORE→RETRIEVE→JUDGE→DISTILL→CONSOLIDATE
 * Stockage : SQLite via node:sqlite (Node.js 22+), zéro dépendance externe.
 *
 * Commandes :
 *   node bank.js store     <phase> <agent> <verdict> "<summary>" [options]
 *   node bank.js retrieve  <query> [--phase <p>] [--agent <a>] [--limit <n>]
 *   node bank.js distill   [--since <days>]
 *   node bank.js consolidate
 *   node bank.js stats
 *   node bank.js list      [--limit <n>] [--phase <p>]
 *
 * Options store :
 *   --run <runId>        Associer au run
 *   --duration <secs>   Durée de la phase
 *   --tags <t1,t2>      Tags additionnels
 *   --project <name>     Nom du projet
 */

/**
 * @typedef {{ id: string, phase: string, agent: string, task?: string, verdict: 'success'|'failure'|'partial', summary: string, duration?: number|null, ts: string, tokens?: number }} Trajectory
 * @typedef {{ trajectories: Trajectory[], insights: Record<string, Insight>|null, consolidatedAt?: string }} BankState
 * @typedef {{ do: string[], dont: string[], distilledAt: string }} Insight
 * @typedef {{ phase?: string, agent?: string, limit?: number, minScore?: number }} RetrieveOpts
 * @typedef {{ trajectory: Trajectory, score: number }} ScoredTrajectory
 */

const { readFileSync, writeFileSync, existsSync, mkdirSync, appendFileSync } = require('fs')
const { join, dirname } = require('path')
const { tokenize: embedTokenize, normalizeToken: _normalizeToken, ACRONYMS_KEEP: _ACRONYMS_KEEP } = require(join(__dirname, 'embeddings.js'))
const os = require('os')

function safeParse(s, fallback) {
  if (!s) return fallback
  try { return JSON.parse(s) } catch { return fallback }
}

const http = require('node:http')

const CONFIG_DIR  = process.env.CLAUDE_CONFIG_DIR || join(process.env.HOME ?? os.homedir(), '.claude')
const COORD_DIR   = join(CONFIG_DIR, 'coordinator')
const BANK_FILE   = join(COORD_DIR, 'bank-state.json')
const INDEX_FILE  = join(COORD_DIR, 'bank-index.json')
const BANK_DB     = join(COORD_DIR, 'bank.db')
const MIGRATE_LOG = join(COORD_DIR, 'logs', 'bank-migration.log')

const MAX_IDS_PER_PHASE = 50
const MAX_TRAJECTORIES  = 5000
const RETRIEVE_CAP      = 500   // hard cap candidats scannés au retrieve (perf : évite O(n) sur 5000)
const ARCHIVE_DAYS      = 90
const EMBED_MODEL       = process.env.EMBED_MODEL || 'nomic-embed-text'
const CONVENTION_BOOST  = 3     // A3 — delta de score ajouté aux conventions matchantes (les fait remonter en tête)
const CONVENTION_PHASE  = 'convention'
const CONVENTION_AGENT  = 'project'
const CONVENTION_TAG    = 'convention'
// A1-auto — file des CANDIDATS de convention : capturés automatiquement mais
// INVISIBLES à l'injection (recall/boost) jusqu'à promotion humaine.
// Phase et tag DISTINCTS de CONVENTION_* → exclus de scoreTrajectory (boost gaté
// sur tag 'convention') et de buildRecallBlock (filtre tag 'convention').
const CANDIDATE_PHASE   = 'convention-candidate'
const CANDIDATE_AGENT   = 'project'
const CANDIDATE_TAG     = 'convention-candidate'
// P0-1 — portée des conventions. global = règle transverse appliquée à TOUTE tâche
// on-topic (RLS, secrets, no-any, commits, uuid/workspace_id) → injectée sans gate
// de contenu. domain = règle spécifique à un domaine → gatée sur la pertinence
// CONTENU réelle (PAS un re-gate lexical de toute la liste — c'est le bug 18fcfa9).
const SCOPE_GLOBAL_TAG  = 'scope:global'
const SCOPE_DOMAIN_TAG  = 'scope:domain'

// Validation OLLAMA_URL — seules les adresses loopback sont autorisées sans ALLOW_REMOTE_OLLAMA
const LOOPBACK_RE = /^(127\.\d+\.\d+\.\d+|::1|localhost)$/i
const OLLAMA_URL  = (() => {
  const raw = process.env.OLLAMA_URL || 'http://localhost:11434'
  try {
    const u = new URL(raw)
    if (!LOOPBACK_RE.test(u.hostname)) {
      process.stderr.write(`[bank] OLLAMA_URL non-loopback détecté : ${u.hostname} — requiert ALLOW_REMOTE_OLLAMA=true\n`)
      if (!process.env.ALLOW_REMOTE_OLLAMA) throw new Error('Remote OLLAMA_URL non autorisé sans ALLOW_REMOTE_OLLAMA=true')
    }
  } catch (e) {
    if (e.message.includes('ALLOW_REMOTE_OLLAMA')) throw e
    // URL malformée → utiliser la valeur par défaut
    return 'http://localhost:11434'
  }
  return raw
})()

// ── Schéma SQLite ─────────────────────────────────────────────────────────────

const SCHEMA_SQL = `
CREATE TABLE IF NOT EXISTS trajectories (
  id          TEXT PRIMARY KEY,
  phase       TEXT NOT NULL,
  agent       TEXT NOT NULL,
  task        TEXT,
  verdict     TEXT NOT NULL CHECK(verdict IN ('success', 'failure', 'partial')),
  summary     TEXT NOT NULL,
  duration_ms INTEGER,
  ts          TEXT NOT NULL,
  tokens      INTEGER,
  embedding   TEXT,
  metadata    TEXT
);

CREATE INDEX IF NOT EXISTS idx_traj_phase         ON trajectories(phase);
CREATE INDEX IF NOT EXISTS idx_traj_phase_verdict ON trajectories(phase, verdict);
CREATE INDEX IF NOT EXISTS idx_traj_ts            ON trajectories(ts DESC);
CREATE INDEX IF NOT EXISTS idx_traj_agent         ON trajectories(agent);

CREATE TABLE IF NOT EXISTS insights (
  phase        TEXT PRIMARY KEY,
  do_list      TEXT NOT NULL DEFAULT '[]',
  dont_list    TEXT NOT NULL DEFAULT '[]',
  distilled_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS meta (
  key   TEXT PRIMARY KEY,
  value TEXT
);
`

// ── Wrapper BankDB ────────────────────────────────────────────────────────────

class BankDB {
  constructor(dbPath) {
    const { DatabaseSync } = require('node:sqlite')
    this.db = new DatabaseSync(dbPath)
    // Concurrence multi-process (plusieurs `ada` en parallèle sur la même base) :
    // WAL autorise lecteurs + 1 écrivain simultanés, busy_timeout retente au lieu
    // d'échouer immédiatement sur SQLITE_BUSY.
    this.db.exec('PRAGMA journal_mode=WAL')
    this.db.exec('PRAGMA busy_timeout=5000')
    this.db.exec(SCHEMA_SQL)
    // Colonnes ajoutées progressivement — ignorées si déjà présentes
    try { this.db.exec(`ALTER TABLE trajectories ADD COLUMN tier TEXT DEFAULT 'short'`) } catch {}
    try { this.db.exec(`ALTER TABLE trajectories ADD COLUMN usage_count INTEGER DEFAULT 0`) } catch {}
  }

  insertTrajectory(traj) {
    // tags, runId, project, distilled → stockés dans metadata
    const metadata = {}
    if (traj.tags)      metadata.tags      = traj.tags
    if (traj.runId)     metadata.runId     = traj.runId
    if (traj.project)   metadata.project   = traj.project
    if (traj.distilled) metadata.distilled = traj.distilled

    const stmt = this.db.prepare(`
      INSERT OR REPLACE INTO trajectories
        (id, phase, agent, task, verdict, summary, duration_ms, ts, tokens, embedding, metadata)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `)
    stmt.run(
      traj.id,
      traj.phase,
      traj.agent,
      traj.task || null,
      traj.verdict,
      traj.summary || '',
      traj.duration || traj.duration_ms || null,
      traj.ts,
      traj.tokens || null,
      traj.embedding ? JSON.stringify(traj.embedding) : null,
      Object.keys(metadata).length ? JSON.stringify(metadata) : null
    )
  }

  /** Hydrate une row SQLite en objet trajectoire compatible avec l'API historique */
  _hydrate(row) {
    if (!row) return null
    const metadata = safeParse(row.metadata, {})
    return {
      id:        row.id,
      ts:        row.ts,
      phase:     row.phase,
      agent:     row.agent,
      verdict:   row.verdict,
      summary:   row.summary,
      duration:  row.duration_ms || null,
      tags:      metadata.tags      || [row.phase, row.agent, row.verdict].filter(Boolean),
      runId:     metadata.runId     || null,
      project:   metadata.project   || null,
      distilled: metadata.distilled || null,
      // P0-3 — drapeau de supersession sémantique (last-write-wins). Une convention
      // archivée reste en base (audit) mais N'EST PLUS retournée au recall.
      archived:  metadata.archived  || false,
      embedding: safeParse(row.embedding, null),
    }
  }

  getByPhase(phase, limit = 50) {
    return this.db.prepare(
      'SELECT * FROM trajectories WHERE phase = ? ORDER BY ts DESC LIMIT ?'
    ).all(phase, limit).map(r => this._hydrate(r))
  }

  getAll(limit = 500) {
    return this.db.prepare(
      'SELECT * FROM trajectories ORDER BY ts DESC LIMIT ?'
    ).all(limit).map(r => this._hydrate(r))
  }

  getAllRaw(limit = 500) {
    return this.db.prepare(
      'SELECT * FROM trajectories ORDER BY ts ASC LIMIT ?'
    ).all(limit)
  }

  getById(id) {
    return this._hydrate(this.db.prepare('SELECT * FROM trajectories WHERE id = ?').get(id))
  }

  count() {
    return this.db.prepare('SELECT COUNT(*) as n FROM trajectories').get().n
  }

  getPhases() {
    return this.db.prepare('SELECT DISTINCT phase FROM trajectories').all().map(r => r.phase)
  }

  deleteById(id) {
    this.db.prepare('DELETE FROM trajectories WHERE id = ?').run(id)
  }

  deleteByIds(ids) {
    if (!ids.length) return
    const placeholders = ids.map(() => '?').join(',')
    this.db.prepare(`DELETE FROM trajectories WHERE id IN (${placeholders})`).run(...ids)
  }

  /** Met à jour le champ metadata (ex: distilled) d'une trajectoire existante */
  updateMetadata(id, patch) {
    const row = this.db.prepare('SELECT metadata FROM trajectories WHERE id = ?').get(id)
    if (!row) return
    const existing = safeParse(row.metadata, {})
    const merged = { ...existing, ...patch }
    this.db.prepare('UPDATE trajectories SET metadata = ? WHERE id = ?').run(JSON.stringify(merged), id)
  }

  upsertInsight(phase, doList, dontList, distilledAt) {
    this.db.prepare(`
      INSERT OR REPLACE INTO insights (phase, do_list, dont_list, distilled_at)
      VALUES (?, ?, ?, ?)
    `).run(phase, JSON.stringify(doList), JSON.stringify(dontList), distilledAt)
  }

  getInsight(phase) {
    const row = this.db.prepare('SELECT * FROM insights WHERE phase = ?').get(phase)
    if (!row) return null
    return {
      do:          JSON.parse(row.do_list),
      dont:        JSON.parse(row.dont_list),
      distilledAt: row.distilled_at,
    }
  }

  getAllInsights() {
    return this.db.prepare('SELECT * FROM insights').all().reduce((acc, row) => {
      acc[row.phase] = {
        do:          JSON.parse(row.do_list),
        dont:        JSON.parse(row.dont_list),
        distilledAt: row.distilled_at,
      }
      return acc
    }, {})
  }

  setMeta(key, value) {
    this.db.prepare('INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)').run(key, JSON.stringify(value))
  }

  getMeta(key, fallback = null) {
    const row = this.db.prepare('SELECT value FROM meta WHERE key = ?').get(key)
    return row ? JSON.parse(row.value) : fallback
  }

  /**
   * Promeut les trajectoires éligibles de 'short' à 'long'.
   * Éligible : verdict='success', usage_count >= 2, âge >= 7 jours.
   * @returns {number} nombre total de trajectoires en tier 'long'
   */
  promoteToLongTerm() {
    this.db.prepare(`
      UPDATE trajectories
      SET tier = 'long'
      WHERE tier = 'short'
        AND verdict = 'success'
        AND usage_count >= 2
        AND julianday('now') - julianday(ts) >= 7
    `).run()
    return this.db.prepare(`SELECT COUNT(*) as n FROM trajectories WHERE tier = 'long'`).get().n
  }

  /**
   * Incrémente usage_count pour une trajectoire donnée.
   * @param {string} id
   */
  incrementUsage(id) {
    this.db.prepare('UPDATE trajectories SET usage_count = usage_count + 1 WHERE id = ?').run(id)
  }

  /**
   * Met à jour l'embedding d'une trajectoire.
   * @param {string} id
   * @param {string} embeddingJson
   */
  updateEmbedding(id, embeddingJson) {
    this.db.prepare('UPDATE trajectories SET embedding = ? WHERE id = ?').run(embeddingJson, id)
  }
}

// ── Singleton DB + migration ──────────────────────────────────────────────────

let _db = null
let _storeCount = 0
// C2 — snapshot JSON (miroir lecture-seule pour metrics/team-sync) tous les N stores.
// 25 (vs 10) : réduit ~2,5× la fréquence du burst sync 220KB (loadBankFromDB + write)
// sur le chemin chaud des workers, sans impact sur SQLite (source de vérité).
const SNAPSHOT_INTERVAL = 25

// ── bank-index.json memory cache ─────────────────────────────────────────────
let _bankIndexCache = null
let _bankIndexDirty = false

// ── Index ANN (HNSW) + cache TF-IDF — extraits dans bank-hnsw.js (axe C3) ──────
// Ce module détient en propre l'état singleton de l'index (graphe HNSW + cache
// TF-IDF en mémoire). On ré-importe ses fonctions ici pour préserver les appels
// internes (_hnswInsert, getCachedIndex, _getOrLoadHNSW, _toHNSWVector).
const {
  _getOrLoadHNSW,
  _toHNSWVector,
  _hnswInsert,
  getCachedIndex,
} = require(join(__dirname, 'bank-hnsw.js'))

function getDB() {
  if (!_db) {
    ensureDir(COORD_DIR)
    _db = new BankDB(BANK_DB)
    migrateIfNeeded(_db)
  }
  return _db
}

/** Réinitialise le singleton (utile pour les tests avec TMP dir). */
function _resetDB() { _db = null }

function migrateIfNeeded(db) {
  if (db.count() > 0) return          // DB déjà peuplée
  if (!existsSync(BANK_FILE)) return  // Rien à migrer

  try {
    const state = JSON.parse(readFileSync(BANK_FILE, 'utf8'))
    const trajs = state.trajectories || []
    if (!trajs.length) return

    for (const t of trajs) db.insertTrajectory(t)

    // Migrer les insights globaux (format ancien byPhase → table insights)
    if (state.insights?.byPhase) {
      for (const [phase, ins] of Object.entries(state.insights.byPhase)) {
        db.upsertInsight(
          phase,
          ins.patterns || [],
          ins.pitfalls || [],
          state.insights.lastDistilledAt || new Date().toISOString()
        )
      }
    }

    // Conserver les meta globaux
    if (state.insights) {
      db.setMeta('globalDo',   state.insights.globalDo   || [])
      db.setMeta('globalDont', state.insights.globalDont || [])
      db.setMeta('lastDistilledAt', state.insights.lastDistilledAt || null)
      db.setMeta('distillPeriod',   state.insights.period || null)
    }

    // Log migration
    ensureDir(dirname(MIGRATE_LOG))
    appendFileSync(
      MIGRATE_LOG,
      `[${new Date().toISOString()}] Migrated ${trajs.length} trajectories from bank-state.json to bank.db\n`,
      'utf8'
    )
  } catch (err) {
    // Migration non-bloquante
    try {
      ensureDir(dirname(MIGRATE_LOG))
      appendFileSync(MIGRATE_LOG, `[${new Date().toISOString()}] Migration error: ${err.message}\n`, 'utf8')
    } catch {}
  }
}

// ── Semantic search via ollama (optionnel — graceful fallback) ────────────────

/**
 * Obtient un embedding via Ollama en utilisant node:http (async, avec timeout).
 * Rejette si Ollama est indisponible ou si la réponse est invalide.
 *
 * @param {string} text   Texte à vectoriser
 * @param {{ timeout?: number, model?: string, url?: string }} [opts]
 * @returns {Promise<number[]>}
 */
// Deux fonctions d'embedding coexistent intentionnellement :
// - embedWithOllama : endpoint /api/embeddings (Ollama < 0.2), rejette sur échec — pour retrieveAsync où l'échec doit être distingué
// - getEmbedding    : endpoint /api/embed     (Ollama 0.2+),  résout null sur échec — pour store() (fire-and-forget, dégradation gracieuse)
function embedWithOllama(text, { timeout = 2000, model = EMBED_MODEL, url = OLLAMA_URL } = {}) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify({ model, prompt: text.slice(0, 512) })
    const timer = setTimeout(() => {
      req.destroy()
      reject(new Error('timeout'))
    }, timeout)

    const urlObj = new URL(`${url}/api/embeddings`)
    const reqOpts = {
      hostname: urlObj.hostname,
      port:     urlObj.port || 80,
      path:     urlObj.pathname,
      method:   'POST',
      headers:  {
        'Content-Type':   'application/json',
        'Content-Length': Buffer.byteLength(body),
      },
    }

    const req = http.request(reqOpts, res => {
      let data = ''
      res.on('data', chunk => {
        data += chunk
        if (data.length > EMBED_MAX_RESPONSE) {
          req.destroy()
          reject(new Error('response too large'))
        }
      })
      res.on('end', () => {
        clearTimeout(timer)
        try {
          const parsed = JSON.parse(data)
          if (Array.isArray(parsed.embedding) && parsed.embedding.length > 0) {
            resolve(parsed.embedding)
          } else {
            reject(new Error('no embedding'))
          }
        } catch {
          reject(new Error('parse error'))
        }
      })
    })

    req.on('error', e => {
      clearTimeout(timer)
      reject(e)
    })

    req.write(body)
    req.end()
  })
}

const EMBED_MAX_RESPONSE = 2 * 1024 * 1024  // 2 MB max — protection contre réponses anormalement grandes

function getEmbedding(text, { timeout = 2000 } = {}) {
  return new Promise(resolve => {
    const body = JSON.stringify({ model: EMBED_MODEL, input: text.slice(0, 512) })
    const urlObj = new URL(`${OLLAMA_URL}/api/embed`)
    const isHttps = urlObj.protocol === 'https:'
    const reqOpts = {
      hostname: urlObj.hostname,
      port:     urlObj.port || (isHttps ? 443 : 80),
      path:     urlObj.pathname,
      method:   'POST',
      headers:  { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) },
    }
    const client = isHttps ? require('https') : http
    const timer = setTimeout(() => { req.destroy(); resolve(null) }, timeout)
    const req = client.request(reqOpts, res => {
      let data = ''
      res.on('data', chunk => {
        data += chunk
        if (data.length > EMBED_MAX_RESPONSE) {
          req.destroy(new Error('Réponse Ollama trop grande'))
          clearTimeout(timer)
          resolve(null)
        }
      })
      res.on('end', () => {
        clearTimeout(timer)
        try { resolve(JSON.parse(data).embeddings?.[0] || null) } catch { resolve(null) }
      })
    })
    req.on('error', () => { clearTimeout(timer); resolve(null) })
    req.write(body)
    req.end()
  })
}

// cosineSimilarity — extrait dans bank-ranking.js (axe C3), ré-importé ici.
const { cosineSimilarity } = require(join(__dirname, 'bank-ranking.js'))

const STOP_WORDS = new Set(['le','la','les','un','de','du','des','en','et','est','à','au','avec','pour','sur','par','que','qui','se','il','elle','ils','elles','je','tu','nous','vous','on','the','a','an','in','of','is','to','for','by','and','or','not','be','was','has','have','it','at','this','that','from','but','are','with','as','was'])

// ── Couleurs ──────────────────────────────────────────────────────────────────

const C = {
  reset: '\x1b[0m', bold: '\x1b[1m',
  green: '\x1b[32m', red: '\x1b[31m', yellow: '\x1b[33m',
  cyan: '\x1b[36m', gray: '\x1b[90m', blue: '\x1b[34m', magenta: '\x1b[35m'
}
const ok   = msg => console.log(`${C.green}✓${C.reset} ${msg}`)
const fail = msg => console.log(`${C.red}✗${C.reset} ${msg}`)
const info = msg => console.log(`${C.cyan}→${C.reset} ${msg}`)
const warn = msg => console.log(`${C.yellow}⚠${C.reset}  ${msg}`)

// ── I/O ───────────────────────────────────────────────────────────────────────

function ensureDir(p) { if (!existsSync(p)) mkdirSync(p, { recursive: true }) }
function ts() { return new Date().toISOString() }

// Compatibilité lecture bank-state.json (lecture seule, pour les tests CLI distill/consolidate)
function loadBankFromJSON() {
  if (!existsSync(BANK_FILE)) {
    return { version: 1, trajectories: [], insights: null, updatedAt: ts() }
  }
  try {
    return JSON.parse(readFileSync(BANK_FILE, 'utf8'))
  } catch {
    return { version: 1, trajectories: [], insights: null, updatedAt: ts() }
  }
}

/**
 * Construit un objet bank compatible avec l'ancien format depuis SQLite.
 * Utilisé par les fonctions CLI (distill, consolidate, stats, list, retrieve).
 */
function loadBankFromDB() {
  const db = getDB()
  const trajectories = db.getAll(MAX_TRAJECTORIES)

  // Reconstruire insights depuis la table insights + meta
  const byPhase = {}
  const allInsights = db.getAllInsights()
  for (const [phase, ins] of Object.entries(allInsights)) {
    byPhase[phase] = { patterns: ins.do, pitfalls: ins.dont, distilledAt: ins.distilledAt }
  }

  const lastDistilledAt = db.getMeta('lastDistilledAt', null)
  const globalDo        = db.getMeta('globalDo', [])
  const globalDont      = db.getMeta('globalDont', [])

  const insights = lastDistilledAt
    ? { lastDistilledAt, byPhase, globalDo, globalDont }
    : null

  return { version: 2, trajectories, insights, updatedAt: ts() }
}

/**
 * Persiste le bank dans SQLite (remplace saveBank JSON).
 * Toutes les trajectoires sont upsertées (INSERT OR REPLACE).
 */
function saveBankToDB(bank) {
  const db = getDB()
  for (const t of bank.trajectories) db.insertTrajectory(t)

  if (bank.insights) {
    const { byPhase, globalDo, globalDont, lastDistilledAt, period } = bank.insights
    if (byPhase) {
      for (const [phase, ins] of Object.entries(byPhase)) {
        db.upsertInsight(
          phase,
          ins.patterns || [],
          ins.pitfalls || [],
          lastDistilledAt || ts()
        )
      }
    }
    if (globalDo)         db.setMeta('globalDo', globalDo)
    if (globalDont)       db.setMeta('globalDont', globalDont)
    if (lastDistilledAt)  db.setMeta('lastDistilledAt', lastDistilledAt)
    if (period)           db.setMeta('distillPeriod', period)
  }

  // Mettre à jour bank-state.json pour rétro-compatibilité (lecture seule par des outils externes)
  _syncJSONSnapshot(bank)
}


/** Écrit un snapshot JSON depuis SQLite (rétro-compatibilité). */
function _syncJSONSnapshot(bank) {
  try {
    ensureDir(dirname(BANK_FILE))
    const snapshot = {
      version:      2,
      trajectories: bank.trajectories,
      insights:     bank.insights,
      updatedAt:    ts(),
    }
    const bankTmp = BANK_FILE + '.tmp'
    writeFileSync(bankTmp, JSON.stringify(snapshot, null, 2), 'utf8')
    require('fs').renameSync(bankTmp, BANK_FILE)
  } catch (e) {
    require('./logger').warn('bank', '_syncJSONSnapshot write failed — metrics and team-sync will have stale data', { file: BANK_FILE, error: e?.message })
  }
}

// ── Utilitaires ───────────────────────────────────────────────────────────────

function makeId() {
  const d = new Date()
  const ymd = `${d.getFullYear()}${String(d.getMonth()+1).padStart(2,'0')}${String(d.getDate()).padStart(2,'0')}`
  const rand = require('crypto').randomBytes(3).toString('hex')
  return `traj-${ymd}-${rand}`
}

let _detectedProject = null
function detectProject() {
  if (_detectedProject !== null) return _detectedProject
  try {
    const cwd = process.cwd()
    const pkg = join(cwd, 'package.json')
    if (existsSync(pkg)) {
      const { name } = JSON.parse(readFileSync(pkg, 'utf8'))
      if (name) {
        _detectedProject = name.replace(/[^a-z0-9-]/gi, '-').toLowerCase()
        return _detectedProject
      }
    }
    const py = join(cwd, 'pyproject.toml')
    if (existsSync(py)) {
      const m = readFileSync(py, 'utf8').match(/^name\s*=\s*"([^"]+)"/m)
      if (m) {
        _detectedProject = m[1].replace(/[^a-z0-9-]/gi, '-').toLowerCase()
        return _detectedProject
      }
    }
    _detectedProject = require('path').basename(cwd).replace(/[^a-z0-9-]/gi, '-').toLowerCase() || 'workspace'
    return _detectedProject
  } catch {
    _detectedProject = 'workspace'
    return _detectedProject
  }
}

function tokenize(text) {
  // P1-1 : aligné sur embeddings.tokenize — acronymes techniques préservés
  // (ts/db/ci/ui/rls…) + normalisation canonique (ts→typescript, auth→…) pour
  // que l'overlap de _assembleRecallBlock et scoreTrajectory voient les mêmes
  // tokens unifiés que l'index TF-IDF.
  return text.toLowerCase()
    .replace(/[^a-z0-9\s-]/g, ' ')
    .split(/\s+/)
    .filter(w => (w.length > 2 || _ACRONYMS_KEEP.has(w)) && !STOP_WORDS.has(w))
    .map(_normalizeToken)
}

function autoTags(phase, agent, summary, verdict) {
  const tags = new Set()
  if (phase)   tags.add(phase)
  if (agent)   tags.add(agent)
  if (verdict) tags.add(verdict)
  tokenize(summary || '').slice(0, 8).forEach(t => tags.add(t))
  return [...tags].slice(0, 15)
}

function daysSince(isoTs) {
  return (Date.now() - new Date(isoTs).getTime()) / 86_400_000
}

// ── A3 — Conventions ────────────────────────────────────────────────────────

/** Normalise un texte de convention pour comparaison anti-doublon (casse + accents + ponctuation + espaces). */
function _normalizeConv(text) {
  return String(text || '')
    .toLowerCase()
    .normalize('NFD').replace(/[̀-ͯ]/g, '') // dé-accentue (é→e)
    .replace(/[.,;:!?]/g, '')                          // ponctuation neutre
    .replace(/\s+/g, ' ')
    .trim()
}

// P0-1 — marqueurs déterministes de portée GLOBALE (règles transverses, projet
// entier). Pas de LLM : heuristique lexicale sur le TEXTE DE LA CONVENTION (pas sur
// la requête → pas de regate lexical type 18fcfa9). Tout ce qui ne matche pas = domaine.
const GLOBAL_SCOPE_RE = /\b(rls|supabase|secret|secrets|\.env|any\s+ts|any\b|typescript|uuid|workspace_id|workspace|timestamps?|tenant|multi-tenant|tdd|conventional\s+commits?|commit|sécurit|securit|injection|sanitiz|jamais|toujours|obligatoire|interdit|never|always|must)\b/i

/**
 * P0-1 — Classifie la portée d'une convention. PURE, déterministe.
 * @param {string} text
 * @returns {'global'|'domain'}
 */
function classifyConventionScope(text) {
  return GLOBAL_SCOPE_RE.test(String(text || '')) ? 'global' : 'domain'
}

// ── P0-3 — Dédup / supersession sémantique des conventions ────────────────────
// Bug audité : _normalizeConv ne capte QUE les doublons au texte normalisé
// identique. Deux conventions sémantiquement quasi-identiques ("Jamais de any en
// TS" vs "Pas de any en TypeScript") ou contradictoires ("jamais any" vs "utilise
// any si le build bloque") étaient stockées TOUTES LES DEUX et injectées côte à
// côte → l'agent recevait des règles redondantes ou contradictoires.
//
// Métrique : on tokenise via embeddings.tokenize (P1-1 — même normalisation
// canonique ts→typescript / acronymes que l'index), PUIS on retire les marqueurs
// de POLARITÉ (jamais/utilise/toujours/never/use…) pour isoler le SUJET de la
// règle. Sans ce retrait, "jamais any" vs "pas de any" ne partage pas "jamais"≠"pas"
// et le Jaccard s'effondre à 0.5 alors que c'est la MÊME règle. Le sujet ("any
// typescript") est identique → 1.0. La polarité est jugée séparément (contradiction).
// Déterministe, synchrone, zéro dépendance ; stable sur de courtes phrases-règles
// (le TF-IDF cosine a un IDF instable sur un corpus de quelques conventions).
//
// Deux mesures complémentaires sur les tokens-SUJET :
//   - Jaccard      = |A∩B| / |A∪B|        → dédup (pénalise les écarts de longueur)
//   - Overlap coef = |A∩B| / min(|A|,|B|) → contradiction (robuste à la longueur :
//     "jamais any" vs "utilise any si build bloque" partage 'any' = 1/2 = 0.5)
//
// Seuils (calibrés sur les phrases-règles réelles du CLAUDE.md, voir matrice de
// validation dans bank-recall.test.js → P0-3) :
//   DEDUP_TAU      = 0.5 → Jaccard-sujet ≥0.5 ⇒ même règle reformulée → supersede
//                          (last-write-wins). En-dessous, conventions distinctes
//                          (RLS 0.25, uuid…) → toutes actives.
//   CONTRA_OVL_TAU = 0.5 → overlap-sujet ≥0.5 + polarités OPPOSÉES ⇒ contradiction
//                          → WARNING (arbitrage humain), sans archiver ni bloquer.
const DEDUP_TAU      = 0.5
const CONTRA_OVL_TAU = 0.5

// Marqueurs de polarité (FR + EN). NEG = prohibition/interdiction, POS = autorisation/usage.
const _NEG_POLARITY_RE = /\b(jamais|interdit|interdis|ne\s+\w+\s+pas|n'utilise|sans|never|don't|do\s+not|avoid|forbidden|prohibited|no\s+\w+)\b/i
const _POS_POLARITY_RE = /\b(utilise|autorise|autorisé|permet|permis|toujours|use|allow|allowed|prefer|enable|peut|may)\b/i
// Tokens de polarité à retirer du SUJET (formes déjà normalisées/stemmées par P1-1).
const _POLARITY_TOKENS = new Set([
  'jamais', 'interdit', 'interdis', 'never', 'avoid', 'forbidden', 'prohibited', 'sans',
  'utilise', 'utilis', 'autorise', 'autorisé', 'permet', 'permis', 'toujours', 'use',
  'allow', 'allowed', 'prefer', 'enable', 'peut', 'may', 'pas', 'don', 'do', 'not', 'no',
])

/** @returns {'neg'|'pos'|'neutral'} polarité lexicale d'une convention. */
function _polarity(text) {
  const s = String(text || '')
  const neg = _NEG_POLARITY_RE.test(s)
  const pos = _POS_POLARITY_RE.test(s)
  if (neg && !pos) return 'neg'
  if (pos && !neg) return 'pos'
  return 'neutral' // ambigu (les deux) ou aucun → pas de contradiction décidable
}

/** Tokens-SUJET (P1-1 normalisés, polarité retirée). @returns {Set<string>} */
function _subjectTokens(text) {
  return new Set(embedTokenize(String(text || '')).filter(t => !_POLARITY_TOKENS.has(t)))
}

/**
 * Similarités de contenu entre deux conventions (sur tokens-SUJET).
 * @param {string} a @param {string} b
 * @returns {{ jaccard: number, overlap: number }} chacun ∈ [0,1]
 */
function _convSimilarity(a, b) {
  const ta = _subjectTokens(a)
  const tb = _subjectTokens(b)
  if (!ta.size || !tb.size) return { jaccard: 0, overlap: 0 }
  let inter = 0
  for (const t of ta) if (tb.has(t)) inter++
  const union = ta.size + tb.size - inter
  return {
    jaccard: union === 0 ? 0 : inter / union,
    overlap: inter / Math.min(ta.size, tb.size),
  }
}

/**
 * A3 — Stocke une convention projet comme trajectoire normale (sans changer le schéma).
 * phase='convention', agent='project', verdict='success', tag `convention`.
 * P0-1 : tag de portée ajouté (scope:global | scope:domain). Idempotent : skip si
 * une convention au summary identique (normalisé) existe déjà.
 *
 * @param {string} text          texte de la convention
 * @param {{ tags?: string[], project?: string, scope?: 'global'|'domain' }} [opts]
 * @returns {{ id: string|null, skipped: boolean }}
 */
function storeConvention(text, opts = {}) {
  const summary = String(text || '').trim()
  if (!summary) return { id: null, skipped: true }

  const db = getDB()
  const target = _normalizeConv(summary)
  const existing = db.getByPhase(CONVENTION_PHASE, MAX_TRAJECTORIES)
    .filter(t => !t.archived) // P0-3 — ne compare qu'aux conventions actives

  // (1) Doublon EXACT au texte normalisé → idempotent, aucun side-effect (pas
  //     d'archivage). Garantit que re-seeder les mêmes conventions est un no-op.
  for (const t of existing) {
    if (_normalizeConv(t.summary) === target) return { id: t.id, skipped: true }
  }

  // (2) P0-3 — quasi-doublon / contradiction sémantique vs les conventions actives.
  const warnings = []
  let superseded = null
  const newPol = _polarity(summary)
  for (const t of existing) {
    const { jaccard, overlap } = _convSimilarity(summary, t.summary)
    const oldPol = _polarity(t.summary)
    const oppositePolarity = (newPol === 'neg' && oldPol === 'pos') || (newPol === 'pos' && oldPol === 'neg')
    if (jaccard >= DEDUP_TAU && !oppositePolarity) {
      // Quasi-doublon (même sujet, polarité compatible) : règle reformulée. On
      // retient la collision la plus proche pour la superséder (last-write-wins).
      if (!superseded || jaccard > superseded.sim) superseded = { t, sim: jaccard }
    } else if (overlap >= CONTRA_OVL_TAU && oppositePolarity) {
      // Sujet partagé + polarités OPPOSÉES ⇒ vraie contradiction. On NE supersède
      // PAS automatiquement (risque d'écraser une règle valide à cause d'une saisie
      // mal polarisée) : on signale pour arbitrage humain.
      warnings.push({ conflictId: t.id, existing: t.summary, overlap: Number(overlap.toFixed(3)), polarity: `${oldPol}↔${newPol}` })
    }
  }

  // P0-3 — contradiction : on N'ARCHIVE PAS et on NE BLOQUE PAS. On signale pour
  // arbitrage humain (stderr + champ `warnings` retourné, consommable au seed/promote).
  for (const w of warnings) {
    process.stderr.write(
      `[bank] ⚠ convention CONTRADICTOIRE (arbitrage humain requis) — nouvelle="${summary}" ` +
      `vs existante="${w.existing}" (overlap=${w.overlap}, polarité=${w.polarity})\n`
    )
  }

  // P0-1 — tag de portée (override explicite via opts.scope, sinon classifieur).
  const scope = opts.scope || classifyConventionScope(summary)
  const scopeTag = scope === 'global' ? SCOPE_GLOBAL_TAG : SCOPE_DOMAIN_TAG
  const tags = [...new Set([CONVENTION_TAG, scopeTag, ...(opts.tags || [])])]
  const id = module.exports.store(
    CONVENTION_PHASE, CONVENTION_AGENT, 'success', summary,
    { tags, project: opts.project }
  )

  // P0-3 — last-write-wins : archive l'ancienne convention quasi-doublon APRÈS avoir
  // stocké la nouvelle (jamais de fenêtre sans règle active). archived=true → exclue
  // du recall mais conservée en base (audit / réversibilité).
  if (superseded) {
    try { db.updateMetadata(superseded.t.id, { archived: true }) } catch {}
  }

  return {
    id,
    skipped: false,
    superseded: superseded ? superseded.t.id : null,
    warnings: warnings.length ? warnings : undefined,
  }
}

/**
 * A1-auto — Stocke un CANDIDAT de convention dans la file séparée (invisible à l'injection).
 * phase=CANDIDATE_PHASE, agent='project', verdict='partial', tag CANDIDATE_TAG.
 * Le tag CANDIDATE_TAG ('convention-candidate') ≠ CONVENTION_TAG ('convention') et la phase
 * ≠ CONVENTION_PHASE → donc EXCLU du boost (scoreTrajectory gate sur tag 'convention') et de
 * buildRecallBlock (filtre tag 'convention'). Aucune injection sans promotion humaine.
 *
 * Idempotent : skip si un candidat OU une convention active au même texte normalisé existe.
 *
 * @param {string} text          texte de la convention candidate
 * @param {{ tags?: string[], project?: string }} [opts]
 * @returns {{ id: string|null, skipped: boolean }}
 */
function storeCandidate(text, opts = {}) {
  const summary = String(text || '').trim()
  if (!summary) return { id: null, skipped: true }

  const db = getDB()
  const target = _normalizeConv(summary)

  // Skip si déjà candidat
  for (const t of db.getByPhase(CANDIDATE_PHASE, MAX_TRAJECTORIES)) {
    if (_normalizeConv(t.summary) === target) return { id: t.id, skipped: true }
  }
  // Skip si déjà promu en convention active (ne pas re-proposer ce qui est validé).
  // P0-3 — une convention archivée (supersédée) ne bloque PAS : elle a été
  // remplacée, on peut donc re-proposer une variante.
  for (const t of db.getByPhase(CONVENTION_PHASE, MAX_TRAJECTORIES)) {
    if (!t.archived && _normalizeConv(t.summary) === target) return { id: t.id, skipped: true }
  }

  const tags = [...new Set([CANDIDATE_TAG, ...(opts.tags || [])])]
  const id = module.exports.store(
    CANDIDATE_PHASE, CANDIDATE_AGENT, 'partial', summary,
    { tags, project: opts.project }
  )
  return { id, skipped: false }
}

// A1-auto — marqueurs déterministes de phrase-règle (FR + EN). Pas de LLM.
const RULE_MARKER_RE = /\b(toujours|jamais|doit|ne\s+\w+\s+pas|convention|règle|always|never|must|don't|n'utilise|utilise toujours|interdit|obligatoire|RLS)\b/i

/**
 * A1-auto — Extracteur heuristique PUR (testable, déterministe, sans LLM).
 * Reçoit un array de blocs de texte, retourne un array de phrases-candidates dédupliquées.
 *
 * @param {string[]} texts
 * @returns {string[]}
 */
function extractConventionCandidates(texts) {
  const out = []
  const seen = new Set()
  for (const block of (Array.isArray(texts) ? texts : [texts])) {
    const lines = String(block || '').split(/\r?\n|(?<=[.;])\s+/)
    for (let raw of lines) {
      // Nettoie les préfixes de puce / numérotation markdown
      let line = raw.replace(/^\s*[-*+]\s+/, '').replace(/^\s*\d+[.)]\s+/, '').trim()
      if (!line) continue
      if (line.length < 15 || line.length > 300) continue   // filtre longueur
      if (!RULE_MARKER_RE.test(line)) continue               // doit matcher un marqueur de règle
      // Bruit : URLs, lignes de code pures, puces vides
      if (/https?:\/\//i.test(line)) continue
      if (/^[`{}();<>[\]=]/.test(line)) continue              // début de ligne de code
      if (/^\W+$/.test(line)) continue                        // ponctuation seule
      const k = _normalizeConv(line)
      if (!k || seen.has(k)) continue
      seen.add(k)
      out.push(line)
    }
  }
  return out
}

/** Extrait les puces markdown `- ` d'une section (ou de tout le texte si sectionTitle absent). */
function _extractBullets(md, sectionTitle = null) {
  if (!md) return []
  let body = md
  if (sectionTitle) {
    const lines = md.split('\n')
    // Match par préfixe : "## Règles stack" matche "## Règles stack (défaut : ...)"
    const want = sectionTitle.trim().toLowerCase()
    const start = lines.findIndex(l => l.trim().toLowerCase().startsWith(want))
    if (start === -1) return []
    // Section = jusqu'au prochain heading de niveau <= celui de la section
    const headingLevel = (sectionTitle.match(/^#+/) || ['##'])[0].length
    const collected = []
    for (let i = start + 1; i < lines.length; i++) {
      const h = lines[i].match(/^(#+)\s/)
      if (h && h[1].length <= headingLevel) break
      collected.push(lines[i])
    }
    body = collected.join('\n')
  }
  return body.split('\n')
    .map(l => l.trim())
    .filter(l => /^[-*]\s+/.test(l))
    .map(l => l.replace(/^[-*]\s+/, '').trim())
    .filter(Boolean)
}

// ── Index par phase (rétro-compatibilité) ─────────────────────────────────────

/**
 * loadIndex : lit bank-index.json OU construit un index depuis SQLite.
 * Conservé pour compatibilité avec les intégrations existantes.
 */
function loadIndex() {
  // Essayer le fichier JSON d'abord
  try {
    if (existsSync(INDEX_FILE)) return JSON.parse(readFileSync(INDEX_FILE, 'utf8'))
  } catch (e) {
    require('./logger').warn('bank', 'bank-index.json corrupt — will rebuild from DB', { error: e?.message })
  }

  // Fallback : construire depuis SQLite
  try {
    const db = getDB()
    const phases = db.getPhases()
    const index = {}
    for (const phase of phases) {
      index[phase] = db.getByPhase(phase, MAX_IDS_PER_PHASE).map(t => t.id)
    }
    return index
  } catch (e) {
    require('./logger').warn('bank', 'loadIndex SQLite failed — returning empty index', { error: e?.message })
    return {}
  }
}

/**
 * updateIndex : maintenu pour compatibilité mais SQLite est la source de vérité.
 * Met à jour bank-index.json via un cache mémoire avec flush périodique.
 */
function updateIndex(phase, trajectoryId) {
  try {
    if (_bankIndexCache === null) {
      _bankIndexCache = existsSync(INDEX_FILE)
        ? safeParse(readFileSync(INDEX_FILE, 'utf8'), {})
        : {}
    }
    if (!Array.isArray(_bankIndexCache[phase])) _bankIndexCache[phase] = []
    _bankIndexCache[phase].push(trajectoryId)
    if (_bankIndexCache[phase].length > MAX_IDS_PER_PHASE) {
      _bankIndexCache[phase] = _bankIndexCache[phase].slice(-MAX_IDS_PER_PHASE)
    }
    _bankIndexDirty = true
    _storeCount++
    if (_storeCount % SNAPSHOT_INTERVAL === 0) _flushIndex()
  } catch (e) {
    require('./logger').warn('bank', 'updateIndex failed — index may be stale', { error: e?.message })
  }
}

function _flushIndex() {
  if (!_bankIndexDirty || !_bankIndexCache) return
  try {
    ensureDir(dirname(INDEX_FILE))
    const idxTmp = INDEX_FILE + '.tmp'
    writeFileSync(idxTmp, JSON.stringify(_bankIndexCache, null, 2), 'utf8')
    require('fs').renameSync(idxTmp, INDEX_FILE)
    _bankIndexDirty = false
  } catch (e) {
    require('./logger').warn('bank', '_flushIndex persist failed — index not saved to disk', { error: e?.message })
  }
}

// ── STORE ─────────────────────────────────────────────────────────────────────

async function cmdStore(args) {
  const { isValidVerdict, isValidPhase, isValidAgent } = require('./safe-executor.js')

  const flags = {}
  const positional = []

  for (let i = 0; i < args.length; i++) {
    if (args[i].startsWith('--')) {
      const key = args[i].slice(2)
      flags[key] = args[i + 1] || true
      i++
    } else {
      positional.push(args[i])
    }
  }

  const [phase, agent, verdict, ...summaryParts] = positional
  let summary = summaryParts.join(' ')

  if (!phase || !agent || !verdict) {
    console.error('Usage: bank.js store <phase> <agent> <verdict> "<summary>"')
    process.exit(1)
  }

  if (!isValidPhase(phase))     { console.error('Phase invalide');   process.exit(1) }
  if (!isValidAgent(agent))     { console.error('Agent invalide');   process.exit(1) }
  if (!isValidVerdict(verdict)) { console.error('Verdict invalide'); process.exit(1) }

  summary = summary.slice(0, 2000)

  const extraTags = flags.tags ? flags.tags.split(',').map(t => t.trim()) : []
  const tags = [...new Set([...autoTags(phase, agent, summary, verdict), ...extraTags])]

  const traj = {
    id:       makeId(),
    ts:       ts(),
    project:  flags.project || process.env.AI_DEV_PROJECT || detectProject(),
    runId:    flags.run || null,
    phase,
    agent,
    verdict,
    summary:  summary || '',
    duration: flags.duration ? parseInt(flags.duration, 10) : null,
    tags,
    distilled: null,
  }

  const embeddingText = [phase, agent, verdict, summary].filter(Boolean).join(' ')
  traj.embedding = await getEmbedding(embeddingText)

  getDB().insertTrajectory(traj)
  updateIndex(phase, traj.id)
  if (_storeCount % SNAPSHOT_INTERVAL === 0) _syncJSONSnapshot(loadBankFromDB())

  ok(`Trajectoire stockée : ${traj.id}${traj.embedding ? ' [+embedding]' : ''}`)
  console.log(`  Phase   : ${phase}  Agent: ${agent}  Verdict: ${verdict}`)
  if (summary) console.log(`  Résumé  : ${summary.slice(0, 80)}`)
}

// ── EMBED — Ajoute embeddings aux trajectoires existantes ─────────────────────

async function cmdEmbed() {
  const db = getDB()
  const rows = db.getAllRaw(MAX_TRAJECTORIES)
  let count = 0, skipped = 0

  for (const row of rows) {
    if (row.embedding) { skipped++; continue }
    const text = [row.phase, row.agent, row.verdict, row.summary].filter(Boolean).join(' ')
    const emb  = await getEmbedding(text)
    if (emb) {
      db.updateEmbedding(row.id, JSON.stringify(emb))
      count++
    } else break
  }

  if (count > 0) {
    ok(`${count} embeddings ajoutés (${skipped} déjà présents)`)
  } else if (skipped === rows.length) {
    ok(`Tous les embeddings sont déjà présents (${skipped})`)
  } else {
    warn(`Ollama indisponible ou modèle '${EMBED_MODEL}' non chargé`)
    console.log(`  → Lancer : ollama pull ${EMBED_MODEL}`)
    console.log(`  → Puis : node bank.js embed`)
  }
}

// ── RETRIEVE ──────────────────────────────────────────────────────────────────
// scoreTrajectory et le scoring/ranking sont extraits dans bank-ranking.js (axe C3).
// Voir le bloc d'initialisation `ranking.init(...)` plus bas (après loadAllTrajectories).

async function cmdRetrieve(args) {
  const flags = {}
  const queryParts = []

  for (let i = 0; i < args.length; i++) {
    if (args[i].startsWith('--')) {
      const key  = args[i].slice(2)
      const next = args[i + 1]
      // Flag booléen si suivi de rien ou d'un autre flag (ex: --smart)
      if (next === undefined || next.startsWith('--')) {
        flags[key] = true
      } else {
        flags[key] = next; i++
      }
    } else {
      queryParts.push(args[i])
    }
  }

  const query = queryParts.join(' ')
  const limit = parseInt(flags.limit || '5', 10)
  const phaseFilter = flags.phase || null
  const agentFilter = flags.agent || null

  if (!query && !phaseFilter && !agentFilter) {
    console.error('Usage: bank.js retrieve <query> [--phase p] [--agent a] [--limit n] [--smart]')
    process.exit(1)
  }

  // Pipeline avancé opt-in (--smart) : query expansion + RRF + MMR + graph boost.
  // Auparavant smartRetrieve n'avait aucun appelant (code mort) — désormais atteignable et testable.
  if (flags.smart) {
    const results = smartRetrieve(query, { phase: phaseFilter, agent: agentFilter, limit })
    if (!results.length) { warn('Aucune trajectoire pertinente trouvée (smart)'); return }
    console.log(`\n${C.bold}SmartRetrieve — ${query || `phase:${phaseFilter}`}${C.reset}\n`)
    for (const traj of results) {
      const age = Math.round(daysSince(traj.ts))
      const vc  = traj.verdict === 'success' ? C.green : traj.verdict === 'failure' ? C.red : C.yellow
      const gb  = traj._graphBoost ? ` ${C.cyan}graph+${traj._graphBoost}${C.reset}` : ''
      console.log(`${C.bold}${traj.id}${C.reset}  ${vc}${traj.verdict}${C.reset}  score:${(traj.score || 0).toFixed(2)}${gb}  ${C.gray}${age}j${C.reset}`)
      console.log(`  Phase: ${traj.phase}  Agent: ${traj.agent}`)
      console.log(`  ${String(traj.summary || '').slice(0, 120)}`)
      console.log('')
    }
    return
  }

  const db = getDB()
  const allTrajs = phaseFilter ? db.getByPhase(phaseFilter, MAX_TRAJECTORIES) : db.getAll(MAX_TRAJECTORIES)

  if (!allTrajs.length) {
    info('ReasoningBank vide — aucune trajectoire stockée')
    return
  }

  const queryEmbedding = query ? await getEmbedding(query) : null
  const semanticMode   = !!queryEmbedding
  if (semanticMode) process.stderr.write('[bank] retrieve sémantique (ollama)\n')

  const queryTokens = tokenize(query)
  const scored = allTrajs
    .map(t => ({ traj: t, score: scoreTrajectory(t, queryTokens, phaseFilter, agentFilter, queryEmbedding) }))
    .filter(x => x.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)

  if (!scored.length) {
    warn('Aucune trajectoire pertinente trouvée')
    return
  }

  console.log(`\n${C.bold}Trajectoires pertinentes — ${query || `phase:${phaseFilter}`}${C.reset}\n`)

  for (const { traj, score } of scored) {
    const age = Math.round(daysSince(traj.ts))
    const verdictColor = traj.verdict === 'success' ? C.green : traj.verdict === 'failure' ? C.red : C.yellow
    const ageStr = age === 0 ? 'aujourd\'hui' : `${age}j`
    console.log(`${C.bold}${traj.id}${C.reset}  ${verdictColor}${traj.verdict}${C.reset}  score:${score.toFixed(1)}  ${C.gray}${ageStr}${C.reset}`)
    console.log(`  Phase: ${traj.phase}  Agent: ${traj.agent}  Projet: ${traj.project}`)
    console.log(`  ${traj.summary.slice(0, 120)}`)
    if (traj.distilled) {
      if (traj.distilled.do)   console.log(`  ${C.green}✓ DO: ${traj.distilled.do}${C.reset}`)
      if (traj.distilled.dont) console.log(`  ${C.red}✗ DON'T: ${traj.distilled.dont}${C.reset}`)
    }
    console.log('')
  }

  // Insights de phase
  const phaseKey = phaseFilter || scored[0]?.traj.phase
  const phaseInsight = phaseKey ? db.getInsight(phaseKey) : null
  if (phaseInsight) {
    console.log(`${C.bold}Insights — ${phaseKey}${C.reset}`)
    if (phaseInsight.do?.length)   console.log(`  ${C.green}DO: ${phaseInsight.do.slice(0, 3).join(', ')}${C.reset}`)
    if (phaseInsight.dont?.length) console.log(`  ${C.red}Pièges: ${phaseInsight.dont.slice(0, 2).join(', ')}${C.reset}`)
    console.log('')
  }
}

// ── JUDGE ─────────────────────────────────────────────────────────────────────
// judgeTrajectory est extrait dans bank-ranking.js (axe C3).

// ── DISTILL ───────────────────────────────────────────────────────────────────

function cmdDistill(args) {
  const flags = {}
  for (let i = 0; i < args.length; i++) {
    if (args[i].startsWith('--')) { flags[args[i].slice(2)] = args[i+1] || true; i++ }
  }
  const sincedays = parseInt(flags.since || '30', 10)

  const db = getDB()
  const allTrajs = db.getAll(MAX_TRAJECTORIES)
  const recent = allTrajs.filter(t => daysSince(t.ts) <= sincedays)

  if (!recent.length) {
    warn(`Aucune trajectoire dans les ${sincedays} derniers jours`)
    return
  }

  // Group by phase
  const byPhase = {}
  for (const t of recent) {
    if (!byPhase[t.phase]) byPhase[t.phase] = { success: [], failure: [] }
    if (t.verdict === 'success') byPhase[t.phase].success.push(t)
    else byPhase[t.phase].failure.push(t)
  }

  const insights = {
    lastDistilledAt: ts(),
    period: `${sincedays}d`,
    trajectoryCount: recent.length,
    byPhase: {},
    globalDo: [],
    globalDont: [],
  }

  for (const [phase, { success, failure }] of Object.entries(byPhase)) {
    const total = success.length + failure.length
    const successRate = total > 0 ? success.length / total : 0

    const agentWins = {}
    for (const t of success) agentWins[t.agent] = (agentWins[t.agent] || 0) + 1
    const topAgent = Object.entries(agentWins).sort((a, b) => b[1] - a[1])[0]?.[0] || null

    const successTokens = {}
    for (const t of success) {
      for (const tok of tokenize(t.summary)) {
        successTokens[tok] = (successTokens[tok] || 0) + 1
      }
    }
    const patterns = Object.entries(successTokens)
      .filter(([,n]) => n >= 2)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([t]) => t)

    const failureTokens = {}
    for (const t of failure) {
      for (const tok of tokenize(t.summary)) {
        failureTokens[tok] = (failureTokens[tok] || 0) + 1
      }
    }
    const pitfalls = Object.entries(failureTokens)
      .filter(([,n]) => n >= 1)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([t]) => t)

    insights.byPhase[phase] = { successRate, topAgent, total, patterns, pitfalls }

    // Sauvegarder l'insight dans la table insights
    db.upsertInsight(phase, patterns, pitfalls, insights.lastDistilledAt)

    // Distill DO/DON'T dans les trajectoires récentes
    for (const t of success.slice(-5)) {
      const doRule = patterns.length ? `Réutiliser le pattern : ${patterns[0]}` : null
      if (doRule && !t.distilled) {
        db.updateMetadata(t.id, { distilled: { do: doRule, dont: null } })
      }
    }
    for (const t of failure.slice(-3)) {
      const dontRule = pitfalls.length ? `Éviter : ${pitfalls[0]}` : null
      if (dontRule && !t.distilled) {
        db.updateMetadata(t.id, { distilled: { do: null, dont: dontRule } })
      }
    }
  }

  // Judge report — évaluation heuristique de chaque trajectoire distillée
  try {
    const judgeLines = []
    for (const t of recent) {
      const { score, signals } = judgeTrajectory(t)
      judgeLines.push(`[${t.ts}] phase:${t.phase} agent:${t.agent} verdict=${t.verdict} judgeScore=${score.toFixed(3)} signals=[${signals.join(',')}]`)
    }
    if (judgeLines.length > 0) {
      const project = recent[0]?.project || 'workspace'
      const reportDir = join(CONFIG_DIR, 'memory', 'projects', project)
      ensureDir(reportDir)
      const reportPath = join(reportDir, 'judge-report.md')
      appendFileSync(reportPath, judgeLines.join('\n') + '\n', 'utf8')
    }
  } catch {}

  // Global DO/DON'T
  const allSuccessTokens = {}
  const allFailureTokens = {}
  for (const t of recent) {
    const target = t.verdict === 'success' ? allSuccessTokens : allFailureTokens
    for (const tok of tokenize(t.summary)) target[tok] = (target[tok] || 0) + 1
  }

  insights.globalDo = Object.entries(allSuccessTokens)
    .filter(([,n]) => n >= 3).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([t]) => t)

  insights.globalDont = Object.entries(allFailureTokens)
    .filter(([,n]) => n >= 2).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([t]) => t)

  db.setMeta('globalDo', insights.globalDo)
  db.setMeta('globalDont', insights.globalDont)
  db.setMeta('lastDistilledAt', insights.lastDistilledAt)
  db.setMeta('distillPeriod', insights.period)

  // Snapshot JSON pour rétro-compatibilité
  _syncJSONSnapshot({ trajectories: allTrajs, insights })

  ok(`Distillation terminée — ${recent.length} trajectoires analysées`)
  console.log(`\n${C.bold}Insights par phase :${C.reset}\n`)
  for (const [phase, ins] of Object.entries(insights.byPhase)) {
    const rateStr = `${Math.round(ins.successRate * 100)}%`
    const colorRate = ins.successRate >= 0.7 ? C.green : ins.successRate >= 0.4 ? C.yellow : C.red
    console.log(`  ${C.bold}${phase}${C.reset}  ${colorRate}${rateStr}${C.reset}  agent:${ins.topAgent || '—'}  n=${ins.total}`)
    if (ins.patterns.length) console.log(`    ${C.green}DO: ${ins.patterns.join(', ')}${C.reset}`)
    if (ins.pitfalls.length) console.log(`    ${C.red}DONT: ${ins.pitfalls.join(', ')}${C.reset}`)
  }
  if (insights.globalDo.length)   console.log(`\n${C.green}Global DO: ${insights.globalDo.join(', ')}${C.reset}`)
  if (insights.globalDont.length) console.log(`${C.red}Global DONT: ${insights.globalDont.join(', ')}${C.reset}`)
  console.log('')
}

// ── EWC — Importance des trajectoires ────────────────────────────────────────
// computeTrajectoryImportance est extrait dans bank-ranking.js (axe C3).

// ── CONSOLIDATE ───────────────────────────────────────────────────────────────

function cmdConsolidate() {
  const db = getDB()
  const allTrajs = db.getAll(MAX_TRAJECTORIES)
  const before = allTrajs.length

  const cutoff = Date.now() - ARCHIVE_DAYS * 86_400_000
  const active   = []
  const toDelete = []

  for (const t of allTrajs) {
    const { keep } = judgeTrajectory(t)
    if (new Date(t.ts).getTime() < cutoff && !keep) {
      toDelete.push(t.id)
    } else {
      active.push(t)
    }
  }

  function jaccardSets(a, b) {
    const sa = new Set(a), sb = new Set(b)
    let inter = 0
    for (const x of sa) if (sb.has(x)) inter++
    const union = sa.size + sb.size - inter
    return union === 0 ? 0 : inter / union
  }

  // O(n×k) bucketed deduplication — compare only within same (phase, agent) bucket
  const _buckets = new Map()
  for (const t of active) {
    const key = `${t.phase ?? ''}:${t.agent ?? ''}`
    if (!_buckets.has(key)) _buckets.set(key, [])
    _buckets.get(key).push(t)
  }

  const deduped = []
  const dupIds  = []
  for (const bucket of _buckets.values()) {
    const bucketDeduped = []
    for (const t of bucket) {
      const isDuplicate = bucketDeduped.some(
        existing => jaccardSets(existing.tags ?? [], t.tags ?? []) > 0.85
      )
      if (isDuplicate) dupIds.push(t.id)
      else bucketDeduped.push(t)
    }
    deduped.push(...bucketDeduped)
  }

  // Trim si > MAX — les trajectoires importantes (EWC) survivent au nettoyage
  const trimmed = deduped.sort((a, b) => new Date(a.ts) - new Date(b.ts))
  const overflowIds = []
  if (trimmed.length > MAX_TRAJECTORIES) {
    const surplus = trimmed.length - MAX_TRAJECTORIES
    // Trier les candidats à suppression par importance ASC (les moins importants d'abord)
    // Les trajectoires avec importance > 0.7 sont protégées même en surplus
    const candidates = trimmed
      .map(t => ({ t, importance: computeTrajectoryImportance(t) }))
      .filter(({ importance }) => importance <= 0.7)  // non protégées
      .sort((a, b) => a.importance - b.importance)    // moins importantes d'abord

    const toEvict = candidates.slice(0, surplus)
    overflowIds.push(...toEvict.map(({ t }) => t.id))
  }

  const allToDelete = [...toDelete, ...dupIds, ...overflowIds]
  if (allToDelete.length) db.deleteByIds(allToDelete)

  const after = db.count()
  _syncJSONSnapshot(loadBankFromDB())

  const removed = before - after
  ok(`Consolidation terminée`)
  console.log(`  Avant : ${before} trajectoires`)
  console.log(`  Après : ${after} trajectoires`)
  console.log(`  Supprimées/archivées : ${removed}`)
}

// ── STATS ─────────────────────────────────────────────────────────────────────

function cmdStats() {
  const db = getDB()
  const longTermCount = db.promoteToLongTerm()
  const trajs = db.getAll(MAX_TRAJECTORIES)

  if (!trajs.length) {
    info('ReasoningBank vide')
    return
  }

  const lastDistilledAt = db.getMeta('lastDistilledAt', null)

  console.log(`\n${C.bold}ReasoningBank — Statistiques${C.reset}\n`)
  console.log(`  Total trajectoires : ${trajs.length}/${MAX_TRAJECTORIES}`)
  console.log(`  Long-term (promus) : ${longTermCount}`)
  console.log(`  Dernière distillation : ${lastDistilledAt?.slice(0, 10) || 'jamais'}`)

  const byPhase = {}
  for (const t of trajs) {
    if (!byPhase[t.phase]) byPhase[t.phase] = { total: 0, success: 0, agents: {} }
    byPhase[t.phase].total++
    if (t.verdict === 'success') byPhase[t.phase].success++
    byPhase[t.phase].agents[t.agent] = (byPhase[t.phase].agents[t.agent] || 0) + 1
  }

  console.log(`\n${C.bold}Par phase :${C.reset}\n`)
  for (const [phase, data] of Object.entries(byPhase).sort((a, b) => b[1].total - a[1].total)) {
    const rate = data.total > 0 ? Math.round(data.success / data.total * 100) : 0
    const colorRate = rate >= 70 ? C.green : rate >= 40 ? C.yellow : C.red
    const topAgent = Object.entries(data.agents).sort((a, b) => b[1] - a[1])[0]
    const bar = '█'.repeat(Math.round(rate / 10)) + '░'.repeat(10 - Math.round(rate / 10))
    console.log(`  ${C.bold}${phase.padEnd(12)}${C.reset} ${colorRate}${bar} ${String(rate).padStart(3)}%${C.reset}  n=${data.total}  agent=${topAgent?.[0] || '—'}`)
  }

  const recent7 = trajs.filter(t => daysSince(t.ts) <= 7)
  if (recent7.length) {
    console.log(`\n${C.bold}Activité 7 derniers jours :${C.reset} ${recent7.length} trajectoires`)
    const successRecent = recent7.filter(t => t.verdict === 'success').length
    console.log(`  Succès : ${successRecent}/${recent7.length} (${Math.round(successRecent/recent7.length*100)}%)`)
  }

  const globalDo   = db.getMeta('globalDo', [])
  const globalDont = db.getMeta('globalDont', [])
  if (globalDo.length || globalDont.length) {
    console.log(`\n${C.bold}Insights globaux :${C.reset}`)
    if (globalDo.length)   console.log(`  ${C.green}DO: ${globalDo.slice(0,5).join(', ')}${C.reset}`)
    if (globalDont.length) console.log(`  ${C.red}DONT: ${globalDont.slice(0,3).join(', ')}${C.reset}`)
  }
  console.log('')
}

// ── LIST ──────────────────────────────────────────────────────────────────────

function cmdList(args) {
  const flags = {}
  for (let i = 0; i < args.length; i++) {
    if (args[i].startsWith('--')) { flags[args[i].slice(2)] = args[i+1] || true; i++ }
  }
  const limit = parseInt(flags.limit || '20', 10)
  const phaseFilter = flags.phase || null

  const db = getDB()
  const trajs = phaseFilter
    ? db.getByPhase(phaseFilter, limit)
    : db.getAll(limit)

  if (!trajs.length) { info('Aucune trajectoire'); return }

  console.log(`\n${C.bold}Trajectoires récentes${phaseFilter ? ` — ${phaseFilter}` : ''}${C.reset}\n`)
  for (const t of trajs) {
    const age = Math.round(daysSince(t.ts))
    const ageStr = age === 0 ? 'auj.' : `${age}j`
    const verdictColor = t.verdict === 'success' ? C.green : t.verdict === 'failure' ? C.red : C.yellow
    console.log(`  ${C.gray}${ageStr.padStart(4)}${C.reset}  ${verdictColor}${t.verdict.padEnd(8)}${C.reset}  ${t.phase.padEnd(10)}  ${t.agent.padEnd(10)}  ${t.summary.slice(0,60)}`)
  }
  console.log('')
}

// ── REINDEX ───────────────────────────────────────────────────────────────────

function cmdReindex() {
  const db = getDB()
  const phases = db.getPhases()
  const index = {}
  for (const phase of phases) {
    const trajs = db.getByPhase(phase, 50)
    index[phase] = trajs.map(t => t.id)
  }
  const reindexTmp = INDEX_FILE + '.tmp'
  writeFileSync(reindexTmp, JSON.stringify(index, null, 2), 'utf8')
  require('fs').renameSync(reindexTmp, INDEX_FILE)
  // Invalider le cache mémoire pour forcer un rechargement depuis le fichier reconstruit
  _bankIndexCache = null
  _bankIndexDirty = false
  console.log(`✓ Index reconstruit : ${phases.length} phases, ${Object.values(index).flat().length} trajectoires`)
}

// ── A1 — SEED CONVENTIONS ──────────────────────────────────────────────────

/**
 * A1 — Auto-peuple le bank depuis les conventions projet.
 * Sources :
 *   1. CLAUDE.md du projet → puces de la section `## Règles stack`
 *   2. $CLAUDE_CONFIG_DIR/conventions.md (optionnel) → toutes les puces `- `
 * Idempotent (storeConvention déduplique sur summary normalisé).
 */
function cmdSeedConventions() {
  const cwd = process.cwd()
  const sources = []

  const claudeMd = join(cwd, 'CLAUDE.md')
  if (existsSync(claudeMd)) {
    try {
      const md = readFileSync(claudeMd, 'utf8')
      sources.push(..._extractBullets(md, '## Règles stack'))
    } catch (e) {
      warn(`Lecture CLAUDE.md échouée : ${e.message}`)
    }
  } else {
    warn(`CLAUDE.md introuvable dans ${cwd}`)
  }

  const convFile = join(CONFIG_DIR, 'conventions.md')
  if (existsSync(convFile)) {
    try {
      sources.push(..._extractBullets(readFileSync(convFile, 'utf8')))
    } catch (e) {
      warn(`Lecture conventions.md échouée : ${e.message}`)
    }
  }

  // Dédup local (mêmes puces dans plusieurs sources)
  const seen = new Set()
  const conventions = sources.filter(c => {
    const k = _normalizeConv(c)
    if (seen.has(k)) return false
    seen.add(k)
    return true
  })

  let added = 0, present = 0
  for (const c of conventions) {
    const { skipped } = storeConvention(c)
    if (skipped) present++; else added++
  }
  if (added > 0) try { _syncJSONSnapshot(loadBankFromDB()) } catch {}

  ok(`seed-conventions terminé`)
  console.log(`  Sources analysées : ${conventions.length} conventions`)
  console.log(`  ${C.green}Ajoutées : ${added}${C.reset}   ${C.gray}Déjà présentes : ${present}${C.reset}`)
}

// ── A1-auto — Conventions (capture + promotion) ───────────────────────────────

/** Exécute `git` et retourne stdout (ou null si pas un repo / git absent). */
function _git(args) {
  try {
    const { execFileSync } = require('child_process')
    return execFileSync('git', args, { cwd: process.cwd(), encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] })
  } catch {
    return null
  }
}

/**
 * A1-auto — Rassemble les sources déterministes de candidats depuis git :
 *   1. messages de commits (sujet + corps)
 *   2. lignes ajoutées (`+`) aux fichiers *.md dans ces commits
 * @param {string} since  git-ref (`<ref>..HEAD`) ou date (`--since`)
 * @returns {string[]|null}  blocs de texte, ou null si pas un repo git
 */
function _gitConventionSources(since) {
  // Détecte si on est dans un repo git
  if (_git(['rev-parse', '--is-inside-work-tree']) === null) return null

  const isRef = /^[^\s]+\.\.|^[0-9a-f]{7,40}$/i.test(since) || /HEAD|@/.test(since)
  const blocks = []

  // 1. Messages de commit
  const logArgs = isRef
    ? ['log', `${since}..HEAD`, '--pretty=format:%s%n%b']
    : ['log', `--since=${since}`, '--pretty=format:%s%n%b']
  const log = _git(logArgs)
  if (log) blocks.push(log)

  // 2. Lignes ajoutées aux *.md
  const diffArgs = isRef
    ? ['diff', `${since}..HEAD`, '--', '*.md']
    : ['log', `--since=${since}`, '-p', '--', '*.md']
  const diff = _git(diffArgs)
  if (diff) {
    const added = diff.split('\n')
      .filter(l => l.startsWith('+') && !l.startsWith('+++'))
      .map(l => l.slice(1))
      .join('\n')
    if (added.trim()) blocks.push(added)
  }
  return blocks
}

function cmdConventions(args) {
  const sub = args[0]
  const rest = args.slice(1)

  const flags = {}
  const positional = []
  for (let i = 0; i < rest.length; i++) {
    if (rest[i].startsWith('--')) {
      const key = rest[i].slice(2)
      const next = rest[i + 1]
      if (next === undefined || next.startsWith('--')) { flags[key] = true }
      else { flags[key] = next; i++ }
    } else positional.push(rest[i])
  }

  const db = getDB()

  switch (sub) {
    case 'extract': {
      const since = (typeof flags.since === 'string' && flags.since) || '7 days ago'
      const sources = _gitConventionSources(since)
      if (sources === null) {
        warn('Pas un dépôt git — extraction ignorée')
        return
      }
      const candidates = extractConventionCandidates(sources)
      let added = 0, known = 0
      for (const c of candidates) {
        const { skipped } = storeCandidate(c)
        if (skipped) known++; else added++
      }
      if (added > 0) try { _syncJSONSnapshot(loadBankFromDB()) } catch {}
      ok(`conventions extract terminé (--since "${since}")`)
      console.log(`  ${C.green}Candidats ajoutés : ${added}${C.reset}   ${C.gray}Déjà connus : ${known}${C.reset}`)
      break
    }

    case 'candidates': {
      const cands = db.getByPhase(CANDIDATE_PHASE, MAX_TRAJECTORIES)
      if (!cands.length) { info('Aucun candidat en attente'); return }
      console.log(`\n${C.bold}Candidats de convention en attente (${cands.length})${C.reset}\n`)
      for (const t of cands) {
        const short = t.id.replace(/^traj-/, '')
        console.log(`  ${C.yellow}${short}${C.reset}  ${String(t.summary || '').trim()}`)
      }
      console.log(`\n  ${C.gray}promote <id> pour valider · reject <id> pour supprimer${C.reset}\n`)
      break
    }

    case 'promote': {
      const id = positional[0]
      if (!id) { console.error('Usage: bank.js conventions promote <id>'); process.exit(1) }
      const full = id.startsWith('traj-') ? id : `traj-${id}`
      const cand = db.getById(full)
      if (!cand || cand.phase !== CANDIDATE_PHASE) {
        fail(`Candidat introuvable : ${id}`)
        process.exit(1)
      }
      const { id: convId, skipped } = storeConvention(cand.summary, { project: cand.project })
      db.deleteById(full)
      try { _syncJSONSnapshot(loadBankFromDB()) } catch {}
      if (skipped) ok(`Déjà une convention active (candidat supprimé) : ${convId}`)
      else ok(`Promu en convention active : ${convId}`)
      console.log(`  ${String(cand.summary || '').trim()}`)
      break
    }

    case 'reject': {
      const id = positional[0]
      if (!id) { console.error('Usage: bank.js conventions reject <id>'); process.exit(1) }
      const full = id.startsWith('traj-') ? id : `traj-${id}`
      const cand = db.getById(full)
      if (!cand || cand.phase !== CANDIDATE_PHASE) {
        fail(`Candidat introuvable : ${id}`)
        process.exit(1)
      }
      db.deleteById(full)
      try { _syncJSONSnapshot(loadBankFromDB()) } catch {}
      ok(`Candidat rejeté : ${id}`)
      break
    }

    default:
      console.log(`\n${C.bold}bank.js conventions <sub>${C.reset}\n`)
      console.log('  extract [--since <git-ref|date>]   Capturer des candidats depuis git (commits + *.md). Défaut : 7 days ago')
      console.log('  candidates                          Lister les candidats en attente (invisibles à l\'injection)')
      console.log('  promote <id>                        Promouvoir un candidat → convention active')
      console.log('  reject <id>                         Supprimer un candidat')
      console.log('')
  }
}

// ── A2 — RECALL (bloc injectable) ─────────────────────────────────────────────

// Gate d'injection à DEUX ÉTAGES (coordinator/injection-gate.js). Agit EN AMONT sur
// la PERTINENCE : filtre/module la liste de candidats AVANT _assembleRecallBlock, sans
// jamais toucher au format à puces (contrat vérifié par bank-recall/conventions).
const { gateRecall } = require(join(__dirname, 'injection-gate.js'))
// Policy flywheel (coordinator/flywheel-policy.js) — paramètres de gate/recall
// policy-configurables. Sans active-policy.json → DÉFAUTS = valeurs historiques :
// AUCUN changement de comportement par défaut. Lecture fail-safe (fallback défauts).
const { loadPolicy: _loadPolicy } = require(join(__dirname, 'flywheel-policy.js'))

/**
 * Applique le gate d'injection sur une liste de candidats déjà rankés (post-retrieve /
 * _recallConventions, avec `_content` stampé par scoreTrajectory).
 *
 * Contrat d'intégration :
 *  - Flag de rollback `ADA_INJECTION_GATE=off` → BYPASS total : retourne la liste
 *    d'entrée telle quelle → comportement strictement identique à avant.
 *  - level NONE → [] (aucun candidat → _assembleRecallBlock renvoie '' : rien injecté).
 *  - level HINT/FULL → `decision.kept` (conventions ride-along + candidats confirmés).
 *    Le gate ne fait que RETIRER des candidats ; _assembleRecallBlock conserve ensuite
 *    son filtrage/formatage établi (scope domaine, cap leçons, ordre) → format intact.
 *
 * Le gate consomme le score amont (`_content`) — étage 1 — et le confirme par un
 * chevauchement de TOKENS CONCRETS — étage 2. `isConvention`/`contentScore` par défaut
 * (tag 'convention' / `c._content`) correspondent exactement aux conventions du bank.
 *
 * Les seuils du gate (étage 1 `scoreThreshold`, étage 2 `minSharedTokens`) sont
 * policy-configurables via flywheel (défauts = valeurs historiques). `gateParams`
 * permet un override explicite (flywheel eval sur une policy hypothétique) sans
 * écrire active-policy.json ; sinon on lit la policy active (fail-safe).
 *
 * @param {string} query
 * @param {Array<object>} candidates
 * @param {{ scoreThreshold?: number, minSharedTokens?: number }} [gateParams]
 * @returns {Array<object>} sous-ensemble à passer à _assembleRecallBlock
 */
function _applyInjectionGate(query, candidates, gateParams) {
  if (process.env.ADA_INJECTION_GATE === 'off') return candidates
  const list = Array.isArray(candidates) ? candidates : []
  if (!list.length) return list
  let ctx
  if (gateParams && typeof gateParams === 'object') {
    ctx = { scoreThreshold: gateParams.scoreThreshold, minSharedTokens: gateParams.minSharedTokens }
  } else {
    const pol = _loadPolicy()
    ctx = { scoreThreshold: pol.gateScoreThreshold, minSharedTokens: pol.gateMinSharedTokens }
  }
  const decision = gateRecall(query, list, ctx)
  return decision.level === 'NONE' ? [] : decision.kept
}


/**
 * A2 (pur) — Assemble le bloc markdown depuis une liste de résultats déjà
 * récupérés (sync OU async). Aucune I/O : testable et partagé entre
 * buildRecallBlock (sync, TF-IDF) et buildRecallBlockAsync (Ollama).
 *
 * Filtre de pertinence CONTENU. retrieve() laisse passer toute entrée dont le
 * score > 0 (le bonus de récence universel suffit). Règles d'injection :
 *  1. Garde-fou hors-sujet : si AUCUNE entrée ne partage de vocabulaire avec la
 *     tâche, la requête est hors-sujet → bloc vide (pas de bruit).
 *  2. Dès que la tâche est on-topic (≥1 match lexical), on injecte TOUTES les
 *     conventions récupérées — y compris sans chevauchement lexical. Une convention
 *     est une règle PROJET à portée globale (ex. « RLS Supabase ») qui s'applique
 *     quel que soit le vocabulaire du prompt ; la gater sur le lexique produit une
 *     liste incomplète → le modèle, ancré dessus, abandonne la règle (anchoring
 *     négatif mesuré au bench-v2 : RLS perdu sur un prompt de schéma).
 *  3. Les LEÇONS (non-conventions) restent gatées sur le chevauchement lexical.
 *
 * @param {Array<object>} results  trajectoires récupérées
 * @param {string} query
 * @returns {string}
 */
function _assembleRecallBlock(results, query, opts = {}) {
  if (!results || !results.length) return ''

  // P0-3 — garde-fou défensif : exclut toute trajectoire archivée (convention
  // supersédée) quel que soit le chemin d'arrivée (retrieve général, fusion…).
  results = results.filter(t => !t.archived)
  if (!results.length) return ''

  const LESSON_LIMIT = opts.lessonLimit || 4   // P0-2 — cap dédié aux leçons (ne rogne plus les conventions)

  const qTokens = new Set(tokenize(query))
  const overlaps = (t) => {
    const trajTokens = new Set([...(t.tags || []), ...tokenize(t.summary || '')])
    for (const qt of qTokens) if (trajTokens.has(qt)) return true
    return false
  }
  // P0-2 — pertinence CONTENU (stampée par scoreTrajectory). Fallback overlap si
  // _content absent (résultat construit hors scoring, ex: tests purs).
  const contentOf = (t) => (typeof t._content === 'number') ? t._content : (overlaps(t) ? 1 : 0)
  const isConv = t => Array.isArray(t.tags) && t.tags.includes(CONVENTION_TAG)

  let relevant
  if (qTokens.size === 0) {
    relevant = results
  } else {
    if (!results.some(overlaps)) return ''          // (1) hors-sujet → vide
    relevant = results.filter(t => isConv(t) || overlaps(t))  // (2)+(3)
  }
  if (!relevant.length) return ''

  // P0-1 — portée des conventions :
  //  - GLOBAL (ou sans tag de portée → défaut global, rétro-compat) : injectée
  //    inconditionnellement dès que le bloc est on-topic. PAS de gate de contenu
  //    → on ne réintroduit PAS le bug 18fcfa9 (anchoring par liste amputée).
  //  - DOMAIN : gatée sur la pertinence CONTENU réelle (content > 0). Une règle
  //    de domaine hors-sujet n'est pas injectée (réduit le bruit).
  const isDomain = t => Array.isArray(t.tags) && t.tags.includes(SCOPE_DOMAIN_TAG)
  const conventions = relevant.filter(isConv).filter(t => !isDomain(t) || contentOf(t) > 0)

  // P0-2 — LEÇONS : seuillées STRICTEMENT sur le contenu (content > 0), triées par
  // contenu décroissant (récence/verdict ne servent plus à les faire entrer), puis
  // cappées par LESSON_LIMIT. Ce cap est SÉPARÉ des conventions : une convention
  // n'est jamais évincée par le volume de leçons.
  const lessons = relevant
    .filter(t => !isConv(t) && contentOf(t) > 0)
    .sort((a, b) => contentOf(b) - contentOf(a))
    .slice(0, LESSON_LIMIT)

  const lines = ['[CONNAISSANCE PROJET — ReasoningBank]']
  if (conventions.length) {
    lines.push('Conventions:')
    for (const t of conventions) lines.push(`- ${String(t.summary || '').trim()}`)
  }
  if (lessons.length) {
    lines.push('Leçons pertinentes:')
    for (const t of lessons) lines.push(`- ${String(t.summary || '').trim()}`)
  }
  return lines.join('\n')
}

/**
 * P0-2 — Récupère TOUTES les conventions (phase=convention), scorées sur le
 * contenu, JAMAIS tronquées par le `limit` du retrieve général. Garantit qu'une
 * convention pertinente n'est pas évincée par le volume de leçons/trajectoires.
 * Le seuillage par portée (global vs domaine) est appliqué en P0-1.
 *
 * @param {string} query
 * @returns {Array<object>} conventions avec `_content` stampé
 */
function _recallConventions(query) {
  try {
    const db = getDB()
    // P0-3 — exclut les conventions supersédées (archived) : ne jamais injecter
    // une règle qu'une version plus récente a remplacée (anti-contradiction).
    const convs = db.getByPhase(CONVENTION_PHASE, MAX_TRAJECTORIES).filter(c => !c.archived)
    if (!convs.length) return []
    const queryTokens = tokenize(query)
    // Score chaque convention (stampe _content). Pas de tfidf/embedding ici : le
    // contenu est l'overlap de tokens — suffisant pour le seuillage de portée.
    for (const c of convs) scoreTrajectory(c, queryTokens, null, null, null, null)
    return convs
  } catch {
    return []
  }
}

/**
 * A2 — Bloc injectable, voie SYNCHRONE (TF-IDF). Conservée pour les appelants
 * sync et la rétro-compatibilité. NE tente PAS Ollama.
 *
 * @param {string} query
 * @param {{ limit?: number }} [opts]
 * @returns {string} bloc markdown (ou '' si aucune connaissance pertinente)
 */
function buildRecallBlock(query, opts = {}) {
  // k policy-configurable (défaut 6). `opts.limit` explicite prime toujours.
  const limit = opts.limit || _loadPolicy().recallK || 6
  let results = []
  try {
    results = module.exports.retrieve(query, { limit }) || []
  } catch {
    results = []
  }
  // P0-2 — fusionne les conventions complètes (non tronquées) avec les résultats
  // généraux. Dédup par id (une convention déjà dans results n'est pas dupliquée).
  const seen = new Set(results.map(r => r.id))
  const convs = _recallConventions(query).filter(c => !seen.has(c.id))
  // Gate d'injection (étage 2) EN AMONT du bloc : filtre les candidats hors-sujet /
  // non confirmés avant formatage. `ADA_INJECTION_GATE=off` → bypass (identique à avant).
  // `opts.gateParams` : override explicite des seuils du gate (flywheel eval).
  const gated = _applyInjectionGate(query, [...convs, ...results], opts.gateParams)
  return _assembleRecallBlock(gated, query)
}

/**
 * A2 (P1-2) — Bloc injectable, voie ASYNCHRONE. Tente la récupération sémantique
 * via Ollama (retrieveAsync) ; si Ollama est indisponible, retombe sur TF-IDF
 * MAIS émet un signal observable (jamais un fallback silencieux) :
 *   - stderr : `[bank] recall DÉGRADÉ (TF-IDF, Ollama indisponible)`
 *   - meta DB `lastRecallDegraded` = ISO ts, consultable via health().
 * C'est la voie utilisée par `bank.js recall` (CLI) → injection orchestrateur.
 *
 * @param {string} query
 * @param {{ limit?: number }} [opts]
 * @returns {Promise<{ block: string, degraded: boolean }>}
 */
async function buildRecallBlockAsync(query, opts = {}) {
  const limit = opts.limit || _loadPolicy().recallK || 6

  // Sonde Ollama avant le retrieve pour distinguer sémantique vs dégradé.
  let ollamaUp = false
  try {
    await embedWithOllama(query || 'ping', { timeout: 2000 })
    ollamaUp = true
  } catch {
    ollamaUp = false
  }

  let results = []
  try {
    results = (await module.exports.retrieveAsync(query, { limit })) || []
  } catch {
    // dernier recours : voie sync TF-IDF
    try { results = module.exports.retrieve(query, { limit }) || [] } catch { results = [] }
  }

  const degraded = !ollamaUp
  if (degraded) {
    process.stderr.write('[bank] recall DÉGRADÉ (TF-IDF, Ollama indisponible) — qualité sémantique réduite\n')
    try { getDB().setMeta('lastRecallDegraded', ts()) } catch {}
  } else {
    try { getDB().setMeta('lastRecallSemantic', ts()) } catch {}
  }

  // P0-2 — conventions complètes (non tronquées) fusionnées avec les résultats généraux.
  const seen = new Set(results.map(r => r.id))
  const convs = _recallConventions(query).filter(c => !seen.has(c.id))
  // Gate d'injection (étage 2) — même sémantique que la voie sync. Bypass si flag off.
  const gated = _applyInjectionGate(query, [...convs, ...results], opts.gateParams)
  return { block: _assembleRecallBlock(gated, query), degraded }
}

/**
 * P1-2 — Santé observable de la couche mémoire. Pas de fallback silencieux :
 * l'orchestrateur (et les tests) peuvent lire l'état réel.
 *   - ollama       : Ollama up/down (sonde réelle, timeout 2s)
 *   - embedModel   : modèle d'embedding configuré
 *   - trajectories : total stocké
 *   - withEmbedding: # trajectoires portant un embedding dense
 *   - coverage     : ratio withEmbedding/trajectories ∈ [0,1]
 *   - lastRecallDegraded / lastRecallSemantic : derniers timestamps observés
 * @returns {Promise<object>}
 */
async function bankHealth() {
  let ollama = false
  try { await embedWithOllama('ping', { timeout: 2000 }); ollama = true } catch { ollama = false }

  const db = getDB()
  let total = 0, withEmbedding = 0
  try {
    total = db.count()
    withEmbedding = db.db.prepare(
      "SELECT COUNT(*) AS n FROM trajectories WHERE embedding IS NOT NULL AND embedding != ''"
    ).get().n
  } catch {}

  return {
    ollama,
    embedModel: EMBED_MODEL,
    trajectories: total,
    withEmbedding,
    coverage: total > 0 ? Math.round((withEmbedding / total) * 1000) / 1000 : 0,
    lastRecallDegraded: db.getMeta('lastRecallDegraded', null),
    lastRecallSemantic: db.getMeta('lastRecallSemantic', null),
  }
}

async function cmdRecall(args) {
  const flags = {}
  const queryParts = []
  for (let i = 0; i < args.length; i++) {
    if (args[i].startsWith('--')) {
      const key = args[i].slice(2)
      const next = args[i + 1]
      if (next === undefined || next.startsWith('--')) { flags[key] = true }
      else { flags[key] = next; i++ }
    } else queryParts.push(args[i])
  }
  const query = queryParts.join(' ')
  if (!query) { console.error('Usage: bank.js recall <query> [--limit n]'); process.exit(1) }

  const limit = parseInt(flags.limit || '6', 10)
  // P1-2 — voie async : tente Ollama, signale le mode dégradé sur stderr (jamais silencieux).
  const { block } = await buildRecallBlockAsync(query, { limit })
  if (block) process.stdout.write(block + '\n')
  // Sinon : aucune ligne, exit 0 — l'orchestrateur n'injecte rien.
}

async function cmdHealth() {
  const h = await bankHealth()
  process.stdout.write(JSON.stringify(h, null, 2) + '\n')
}

// ── Graphify CLI ──────────────────────────────────────────────────────────────

function cmdGraphBuild() {
  try {
    const { buildFull, saveGraph } = require('./graph-builder.js')
    const graphPath = join(CONFIG_DIR, 'coordinator', 'graph-state.json')
    console.log(`${C.bold}Graphify — Reconstruction du graphe de connaissance${C.reset}`)
    const g = buildFull()
    saveGraph(g, graphPath)

    // Résumé par type
    const byNodeType = {}, byEdgeType = {}
    for (const n of g.nodes.values()) byNodeType[n.type] = (byNodeType[n.type] ?? 0) + 1
    for (const e of g.edges.values()) byEdgeType[e.type] = (byEdgeType[e.type] ?? 0) + 1

    console.log(`\n  ${C.green}✓${C.reset} Nœuds  : ${g.nodes.size}`)
    console.log(`  ${C.green}✓${C.reset} Arêtes : ${g.edges.size}`)
    console.log(`\n  ${C.bold}Nœuds par type :${C.reset}`)
    for (const [t, n] of Object.entries(byNodeType)) console.log(`    ${t.padEnd(12)} ${n}`)
    console.log(`\n  ${C.bold}Arêtes par type :${C.reset}`)
    for (const [t, n] of Object.entries(byEdgeType)) console.log(`    ${t.padEnd(16)} ${n}`)
    console.log(`\n  Sauvegardé → ${graphPath}\n`)
  } catch (e) {
    console.error(`${C.red}Erreur graph-build :${C.reset} ${e.message}`)
    process.exit(1)
  }
}

function cmdGraphStats(args) {
  try {
    const { loadGraph } = require('./graph-builder.js')
    const graphPath  = join(CONFIG_DIR, 'coordinator', 'graph-state.json')
    const withPR     = args.includes('--pagerank')
    const topN       = parseInt(args[args.indexOf('--top') + 1] || '10', 10) || 10

    let g = loadGraph(graphPath)
    if (!g) {
      console.log(`${C.yellow}Aucun graphe trouvé. Lancer : node coordinator/bank.js graph-build${C.reset}`)
      process.exit(1)
    }

    console.log(`\n${C.bold}Graphify — Stats du graphe${C.reset}`)
    console.log(`  Nœuds  : ${g.nodes.size}`)
    console.log(`  Arêtes : ${g.edges.size}`)

    // Top WIN_RATE
    const winEdges = [...g.edges.values()]
      .filter(e => e.type === 'WIN_RATE')
      .sort((a, b) => b.weight - a.weight)
      .slice(0, topN)

    if (winEdges.length > 0) {
      console.log(`\n  ${C.bold}Top WIN_RATE (agent → phase) :${C.reset}`)
      for (const e of winEdges) {
        const agent = e.from.replace('agent:', '')
        const phase = e.to.replace('phase:', '')
        const score = g.scoreAgentPhase(agent, phase)
        console.log(`    ${agent.padEnd(20)} → ${phase.padEnd(20)} w=${e.weight.toFixed(1)}  score=${score.toFixed(3)}`)
      }
    }

    if (withPR) {
      const pr = g.pageRank({ iterations: 20, damping: 0.85 })
      const sorted = [...pr.entries()].sort((a, b) => b[1] - a[1]).slice(0, topN)
      console.log(`\n  ${C.bold}Top PageRank :${C.reset}`)
      for (const [id, score] of sorted) {
        console.log(`    ${id.padEnd(35)} ${score.toFixed(4)}`)
      }
    }
    console.log('')
  } catch (e) {
    console.error(`${C.red}Erreur graph-stats :${C.reset} ${e.message}`)
    process.exit(1)
  }
}

// ── RETRIEVE STREAM ───────────────────────────────────────────────────────────

const { EventEmitter } = require('node:events')

/**
 * Charge toutes les trajectoires depuis SQLite (ou corpus vide si DB absente).
 * @param {string|null} phase
 * @returns {import('./bank.js').Trajectory[]}
 */
function loadAllTrajectories(phase) {
  try {
    const db = getDB()
    const all = phase
      ? db.getByPhase(phase, MAX_TRAJECTORIES)
      : db.getAll(MAX_TRAJECTORIES)
    // P0-3 — point d'étranglement : exclut les conventions supersédées (archived).
    // C'est la source unique de smartRetrieve (→ run.js ACW → prompt agent) et de
    // tout appelant futur ; ni le recall ni l'injection ACW ne doivent voir une
    // règle qu'une version plus récente a remplacée (anti-contradiction).
    return all.filter(t => !t.archived)
  } catch {
    return []
  }
}

// ── Wiring du scoring/ranking (extrait dans bank-ranking.js — axe C3) ─────────
// DI plutôt que require croisé : on lie les fonctions de ranking aux helpers et
// constantes détenus par bank.js (getDB, tokenize, daysSince, loadAllTrajectories,
// CONFIG_DIR, CANDIDATE_PHASE, CONVENTION_BOOST). getDB transmis ici est la MÊME
// référence utilisée partout → le singleton DB reste intact. loadAllTrajectories
// est une fonction déclarée (hoisted) au-dessus, donc disponible à l'appel.
const ranking = require(join(__dirname, 'bank-ranking.js'))
const {
  scoreTrajectory,
  contentRelevance,
  judgeTrajectory,
  computeTrajectoryImportance,
  scoreTrajectoryForStream,
  applyGraphBoost,
  smartRetrieve,
} = ranking.init({
  getDB,
  tokenize,
  daysSince,
  loadAllTrajectories,
  embedTokenize,
  CONFIG_DIR,
  CANDIDATE_PHASE,
  CONVENTION_BOOST,
  bankDir: __dirname,
})

/**
 * retrieveStream — version streaming de retrieve()
 * @param {string} query
 * @param {{ limit?: number, phase?: string, agent?: string, batchSize?: number }} [opts]
 * @param {number} [opts.limit=5]
 * @param {number} [opts.batchSize=10]
 * @returns {EventEmitter} — émet 'data' (trajectory+score), 'end' (totalScored), 'error'
 *
 * Exemple :
 *   const stream = retrieveStream('nestjs error handling')
 *   stream.on('data', r => console.log(r.phase, r.score))
 *   stream.on('end',  total => console.log(`${total} trajectoires scorées`))
 */
function retrieveStream(query, opts = {}) {
  const emitter = new EventEmitter()
  // Prevent unhandled 'error' exceptions if no listener is registered
  emitter.on('error', () => {})
  const batchSize = opts.batchSize ?? 10

  setImmediate(() => {
    try {
      if (emitter.listenerCount('data') === 0 && emitter.listenerCount('end') === 0) {
        emitter.emit('error', new Error('retrieveStream: aucun listener enregistré avant l\'exécution'))
        return
      }

      const trajectories = loadAllTrajectories(opts.phase || null)
      let scored = 0

      function processBatch(start) {
        const batch = trajectories.slice(start, start + batchSize)
        if (batch.length === 0) {
          emitter.emit('end', scored)
          return
        }

        for (const traj of batch) {
          const score = scoreTrajectoryForStream(traj, query, opts)
          if (score > 0) {
            emitter.emit('data', { ...traj, score })
            scored++
          }
        }

        setImmediate(() => processBatch(start + batchSize))
      }

      processBatch(0)
    } catch (err) {
      emitter.emit('error', err)
    }
  })

  return emitter
}

/**
 * collectStream — consomme un stream et retourne une Promise<results[]>
 * Utile pour les contextes qui ne supportent pas les EventEmitters directement.
 * @param {EventEmitter} stream
 * @param {number} [limit=5]
 * @returns {Promise<Array<import('./bank.js').Trajectory & { score: number }>>}
 */
function collectStream(stream, limit = 5) {
  return new Promise((resolve, reject) => {
    const results = []
    stream.on('data', r => {
      results.push(r)
      // Tri dynamique pour garder les N meilleurs — évite une mémoire infinie
      results.sort((a, b) => b.score - a.score)
      if (results.length > limit * 2) results.splice(limit * 2)
    })
    stream.on('end', () => resolve(results.slice(0, limit)))
    stream.on('error', reject)
  })
}

// ── SmartRetrieve — pipeline 4 étapes ────────────────────────────────────────
// applyGraphBoost et smartRetrieve sont extraits dans bank-ranking.js (axe C3) —
// liés via ranking.init(...) plus haut.

// ── Module API (pour intégration run.js, ultralearn.js) ──────────────────────

module.exports = {
  /**
   * Retourne les N trajectoires les plus récentes (sans scoring).
   * Utilisé par team-sync pour le push des trajectoires aux coéquipiers.
   * P0-3 — exclut les conventions supersédées (archived) : ne jamais propager
   * à l'équipe une règle qu'une version plus récente a remplacée localement.
   * @param {number} [limit=100]
   * @returns {import('./bank').Trajectory[]}
   */
  getRecent(limit = 100) {
    const db = getDB()
    return db.getAll(Math.min(limit, MAX_TRAJECTORIES)).filter(t => !t.archived)
  },
  /**
   * @param {string} phase
   * @param {string} agent
   * @param {'success'|'failure'|'partial'} verdict
   * @param {string} summary
   * @param {{ tags?: string[], project?: string, runId?: string, duration?: number }} [opts]
   * @returns {string} id de la trajectoire stockée
   */
  store(phase, agent, verdict, summary, opts = {}) {
    const { isValidVerdict, isValidPhase, isValidAgent } = require('./safe-executor.js')
    if (!isValidPhase(phase))     { throw new Error('Phase invalide: ' + phase) }
    if (!isValidAgent(agent))     { throw new Error('Agent invalide: ' + agent) }
    if (!isValidVerdict(verdict)) { throw new Error('Verdict invalide: ' + verdict) }

    // AIDefence — sanitise le summary avant persistence
    try {
      const { sanitize } = require('./ada-defence.js')
      summary = sanitize(summary, `bank.store:${phase}:${agent}`)
    } catch (e) {
      if (e && e.type === 'INJECTION') throw e  // re-throw injection
      // autres erreurs → graceful (module absent)
    }

    summary = (summary || '').slice(0, 2000)
    const tags = [...new Set([...autoTags(phase, agent, summary, verdict), ...(opts.tags || [])])]
    const traj = {
      id:       makeId(),
      ts:       ts(),
      project:  opts.project || process.env.AI_DEV_PROJECT || detectProject(),
      runId:    opts.runId || null,
      phase, agent, verdict, summary,
      duration: opts.duration || null,
      tags,
      distilled: null,
      embedding: null,
    }
    const db = getDB()
    db.insertTrajectory(traj)
    _hnswInsert(traj)
    updateIndex(phase, traj.id)
    if (_storeCount % SNAPSHOT_INTERVAL === 0) _syncJSONSnapshot(loadBankFromDB())

    // Fire-and-forget : tenter d'enrichir avec un embedding Ollama async
    const embText = [phase, agent, verdict, summary].filter(Boolean).join(' ')
    embedWithOllama(embText, { timeout: 2000 }).then(vec => {
      try {
        db.db.prepare('UPDATE trajectories SET embedding = ? WHERE id = ?')
          .run(JSON.stringify(vec), traj.id)
      } catch (e) {
        require('./logger').warn('bank', 'embedding update failed — ANN search quality degraded for this trajectory', { id: traj?.id, error: e?.message })
      }
    }).catch(() => {
      // Ollama absent → pas d'embedding, dégradation gracieuse
    })

    // Mirror vers typed-memory pour le routing sémantique
    try {
      const tm = require('./typed-memory.js')
      const memType = /comment|how|pattern|étape|template|procédure/i.test(summary) ? 'procedural' : 'episodic'
      tm.store(memType, `${phase}:${agent}:${verdict}`, summary, { phase, agent, verdict, runId: opts?.runId })
    } catch (e) {
      if (e?.code !== 'MODULE_NOT_FOUND') {
        require('./logger').warn('bank', 'typed-memory mirror failed — semantic routing will have incomplete data', { phase, agent, error: e?.message })
      }
    }

    return traj.id
  },

  /**
   * Promotion sélective Obsidian→bank : crée/met à jour un insight de topic.
   * Idempotent par id déterministe (`topic-<slug>`, INSERT OR REPLACE).
   * Embedding synchrone pour que l'insight soit retrievable immédiatement (worker court).
   * @param {string} slug        slug du topic (ex: 'auth-security')
   * @param {string} topicName   nom lisible (ex: 'Auth/Security')
   * @param {string} summary     contenu distillé (structure + savoir bank)
   * @param {{ tags?: string[], distilled?: {do?:string,dont?:string}, project?: string }} [opts]
   * @returns {Promise<string>} id de l'insight
   */
  async upsertTopicInsight(slug, topicName, summary, opts = {}) {
    const id   = `topic-${slug}`
    const tags = [...new Set(['topic', slug, ...(opts.tags || [])])]
    let embedding = null
    try { embedding = await getEmbedding([topicName, summary].filter(Boolean).join(' ')) } catch { embedding = null }
    const traj = {
      id,
      ts:        ts(),
      project:   opts.project || process.env.AI_DEV_PROJECT || 'workspace',
      runId:     `topic:${slug}`,
      phase:     'topic',
      agent:     'wiki',
      verdict:   'success',
      summary:   (summary || '').slice(0, 2000),
      duration:  null,
      tags,
      distilled: opts.distilled || null,
      embedding,
    }
    getDB().insertTrajectory(traj)   // INSERT OR REPLACE par id → idempotent
    return id
  },

  /**
   * @param {string} query
   * @param {RetrieveOpts & { tier?: 'short'|'long' }} [opts]
   * @returns {Trajectory[]}
   */
  retrieve(query, opts = {}) {
    const db = getDB()
    const queryTokens  = tokenize(query)
    const phaseFilter  = opts.phase || null
    const agentFilter  = opts.agent || null
    const tierFilter   = opts.tier  || null
    const limit        = opts.limit || 5

    let candidates = phaseFilter
      ? db.getByPhase(phaseFilter, RETRIEVE_CAP)
      : db.getAll(RETRIEVE_CAP)

    // P0-3 — exclut les conventions supersédées (archived). Le RPC bank.retrieve
    // (control-handlers) relaie ce retour tel quel à l'API/UI : ne JAMAIS exposer
    // une règle qu'une version plus récente a remplacée (anti-contradiction + fuite).
    candidates = candidates.filter(t => !t.archived)

    // Filtrage par tier si spécifié
    if (tierFilter) {
      candidates = candidates.filter(t => (t.tier || 'short') === tierFilter)
    }

    if (!candidates.length) return []

    // P2 — Pas de rebuild HNSW inline ici : à RETRIEVE_CAP=500, le ranking TF-IDF/BM25
    // est O(n) rapide, alors que reconstruire un graphe HNSW (vecteurs token-freq lossy)
    // PAR REQUÊTE était superlinéaire ET dégradait la pertinence via une pré-sélection lossy.
    // Le vrai ANN sublinéaire reste disponible via la recherche vectorielle (embeddings)
    // dans retrieveAsync. Ici on score directement le pool cappé.
    const pool = candidates

    // Fallback TF-IDF natif (ollama indisponible)
    const docs = pool.map(t => ({
      id:   t.id,
      text: `${t.phase} ${t.agent} ${t.task || ''} ${t.summary}`
    }))
    const idx = getCachedIndex(docs, _storeCount)
    const tfidfResults = idx.search(query, limit)
    const tfidfMap = new Map(tfidfResults.map(r => [r.id, r.score]))

    // Inclure les candidats sans score TF-IDF (score 0) pour les filtres phase/agent
    const scored = pool
      .map(t => {
        const tfidfScore = tfidfMap.has(t.id) ? tfidfMap.get(t.id) : null
        const score = scoreTrajectory(t, queryTokens, phaseFilter, agentFilter, null, tfidfScore)
        return { traj: t, score, content: t._content || 0 }  // P0-2 — capter le contenu pur
      })
      .filter(x => x.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, limit)

    let results = scored.map(x => ({ ...x.traj, _score: x.score, _content: x.content }))

    // BM25 re-ranking sur les résultats TF-IDF (si ≥5 candidats)
    if (results.length >= 5) {
      try {
        const { searchBM25 } = require('./embeddings.js')
        const docs = results.map(r => r.summary || '')
        const bm25 = searchBM25(query, docs, { limit: results.length })
        // Fusionne : score final = 0.6 × TF-IDF + 0.4 × BM25_normalized
        const maxBm25 = Math.max(...bm25.map(r => r.score), 1e-10)
        for (const b of bm25) {
          if (results[b.index]) {
            results[b.index]._score = (results[b.index]._score || 0) * 0.6 + (b.score / maxBm25) * 0.4
          }
        }
        results.sort((a, b) => (b._score || 0) - (a._score || 0))
      } catch {}
    }

    // Graph boost (Graphify) — désormais sur le chemin par défaut, plus seulement smartRetrieve
    applyGraphBoost(results, '_score')

    for (const traj of results) db.incrementUsage(traj.id)
    return results.map(({ _score: _s, ...traj }) => traj)
  },

  /**
   * Version async de retrieve — utilise embedWithOllama (node:http) si disponible,
   * sinon fallback sur TF-IDF synchrone.
   * @param {string} query
   * @param {RetrieveOpts} [opts]
   * @returns {Promise<Trajectory[]>}
   */
  async retrieveAsync(query, opts = {}) {
    const db = getDB()
    const queryTokens = tokenize(query)
    const phaseFilter = opts.phase || null
    const agentFilter = opts.agent || null
    const tierFilter  = opts.tier  || null
    const limit       = opts.limit || 5

    // P3 — cap appliqué ici aussi (était MAX_TRAJECTORIES=5000 → scan O(n) sur toute la banque)
    let candidates = phaseFilter
      ? db.getByPhase(phaseFilter, RETRIEVE_CAP)
      : db.getAll(RETRIEVE_CAP)

    // P0-3 — exclut les conventions supersédées (archived), comme retrieve() sync.
    candidates = candidates.filter(t => !t.archived)

    if (tierFilter) {
      candidates = candidates.filter(t => (t.tier || 'short') === tierFilter)
    }

    if (!candidates.length) return []

    // 1. Tenter Ollama embed avec timeout 2s
    let queryVector = null
    try {
      queryVector = await embedWithOllama(query, { timeout: 2000 })
    } catch {
      // fallback silencieux vers TF-IDF
    }

    if (queryVector) {
      // 2. Recherche vectorielle via cosine similarity
      const scored = candidates
        .map(t => ({
          traj:  t,
          score: scoreTrajectory(t, queryTokens, phaseFilter, agentFilter, queryVector),
        }))
        .filter(x => x.score > 0)
        .sort((a, b) => b.score - a.score)
        .slice(0, limit)

      const results = scored.map(x => ({ ...x.traj, _score: x.score }))
      applyGraphBoost(results, '_score')
      for (const traj of results) db.incrementUsage(traj.id)
      return results.map(({ _score: _s, ...t }) => t)
    }

    // 3. Fallback TF-IDF (comportement synchrone existant)
    const docs = candidates.map(t => ({
      id:   t.id,
      text: `${t.phase} ${t.agent} ${t.task || ''} ${t.summary}`,
    }))
    const idx = getCachedIndex(docs, _storeCount)
    const tfidfResults = idx.search(query, limit)
    const tfidfMap = new Map(tfidfResults.map(r => [r.id, r.score]))

    const scored = candidates
      .map(t => {
        const tfidfScore = tfidfMap.has(t.id) ? tfidfMap.get(t.id) : null
        return { traj: t, score: scoreTrajectory(t, queryTokens, phaseFilter, agentFilter, null, tfidfScore) }
      })
      .filter(x => x.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, limit)

    const results = scored.map(x => ({ ...x.traj, _score: x.score }))
    applyGraphBoost(results, '_score')
    for (const traj of results) db.incrementUsage(traj.id)
    return results.map(({ _score: _s, ...t }) => t)
  },

  getInsights() {
    const db = getDB()
    const lastDistilledAt = db.getMeta('lastDistilledAt', null)
    if (!lastDistilledAt) return null
    return {
      lastDistilledAt,
      byPhase:    db.getAllInsights(),
      globalDo:   db.getMeta('globalDo', []),
      globalDont: db.getMeta('globalDont', []),
    }
  },

  // Streaming
  retrieveStream,
  collectStream,

  // SmartRetrieval
  smartRetrieve,

  // A1/A2/A3 — Conventions
  storeConvention,
  buildRecallBlock,
  buildRecallBlockAsync,   // P1-2 — voie sémantique (Ollama) + signal dégradé
  _assembleRecallBlock,    // P1-2 — assembleur pur (tests de non-régression)
  health: bankHealth,      // P1-2 — santé observable (ollama up/down, coverage)
  contentRelevance,        // P0-2 — pertinence contenu pure (tests)
  classifyConventionScope, // P0-1 — classifieur de portée (tests)

  // A1-auto — Capture + promotion de candidats de convention
  storeCandidate,
  extractConventionCandidates,

  /**
   * ANN search via the persistent HNSW graph.
   * @param {string} query
   * @param {number} [k=5]
   * @returns {{ id: string, distance: number }[]}
   */
  hnswSearch(query, k = 5) {
    try {
      const hnsw = _getOrLoadHNSW()
      if (!hnsw.size) return []
      const tokens = embedTokenize(query)
      const vec = _toHNSWVector(tokens)
      if (!vec) return []
      return hnsw.search(vec, k)
    } catch { return [] }
  },

  // Exposer pour les tests et intégrations
  loadIndex,
  updateIndex,
  reindex: cmdReindex,
  _resetDB,       // utilitaire pour les tests
  // P0-3 — helper de test : marque une trajectoire comme archived (supersédée),
  // pour vérifier la non-fuite au retrieve/RPC sans dépendre d'Ollama (dédup sémantique).
  _markArchived: (id, archived = true) => { getDB().updateMetadata(id, { archived }) },
  embedWithOllama, // exposée pour tests et intégrations externes
  computeTrajectoryImportance, // EWC — importance des trajectoires
  judgeTrajectory, // LLM-as-judge déterministe
  syncSnapshot: () => _syncJSONSnapshot(loadBankFromDB()), // force sync pour les tests
}

// ── Dispatch CLI ──────────────────────────────────────────────────────────────

if (require.main === module) {
  const [,, cmd, ...rest] = process.argv

  switch (cmd) {
    case 'store':       cmdStore(rest).catch(e => { process.stderr.write(e.message + '\n'); process.exit(1) });       break
    case 'retrieve':    cmdRetrieve(rest).catch(e => { process.stderr.write(e.message + '\n'); process.exit(1) });    break
    case 'distill':     cmdDistill(rest);     break
    case 'consolidate': cmdConsolidate();     break
    case 'embed':       cmdEmbed().catch(e => { process.stderr.write(e.message + '\n'); process.exit(1) });           break
    case 'stats':       cmdStats();           break
    case 'list':        cmdList(rest);        break
    case 'reindex':     cmdReindex();         break
    case 'seed-conventions': cmdSeedConventions(); break
    case 'conventions': cmdConventions(rest); break
    case 'recall':      cmdRecall(rest).catch(e => { process.stderr.write(e.message + '\n'); process.exit(1) }); break
    case 'health':      cmdHealth().catch(e => { process.stderr.write(e.message + '\n'); process.exit(1) }); break
    case 'graph-build': cmdGraphBuild();      break
    case 'graph-stats': cmdGraphStats(rest);  break
    default:
      console.log(`\n${C.bold}coordinator/bank.js — ReasoningBank${C.reset}\n`)
      console.log('  store     <phase> <agent> <verdict> "<summary>"   Stocker une trajectoire')
      console.log('  retrieve  <query> [--phase p] [--agent a]         Retrouver des trajectoires')
      console.log('  embed                                              Ajouter embeddings (ollama)')
      console.log('  distill   [--since <days>]                        Distiller les insights')
      console.log('  consolidate                                        Dédupliquer & archiver')
      console.log('  stats                                              Dashboard complet')
      console.log('  list      [--limit n] [--phase p]                 Lister les trajectoires')
      console.log('  reindex                                            Reconstruire bank-index.json depuis SQLite')
      console.log('  seed-conventions                                   Peupler le bank depuis CLAUDE.md (Règles stack) + $CLAUDE_CONFIG_DIR/conventions.md')
      console.log('  conventions <extract|candidates|promote|reject>    Capture auto (git) → file candidats invisible → promotion humaine')
      console.log('  recall    <query> [--limit n]                     Bloc connaissance projet prêt à injecter (conventions en tête)')
      console.log('  health                                             État de la couche mémoire (ollama up/down, coverage embeddings)')
      console.log('  graph-build                                        Construire/rebuilder le graphe de connaissance')
      console.log('  graph-stats [--pagerank] [--top N]                Inspecter le graphe (nœuds, arêtes, PageRank)')
      console.log('')
  }
}
