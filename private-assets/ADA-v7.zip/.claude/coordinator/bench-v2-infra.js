#!/usr/bin/env node
'use strict'
/**
 * coordinator/bench-v2-infra.js — Scorer « infra » du benchmark v2 (ADR-021, Action 3).
 *
 * POURQUOI un module séparé (au lieu d'ajouter des fonctions dans bench-v2.js) :
 * revue adversariale G8 — le corpus de tâches était 100% SQL (12/12), en violation
 * du principe #6 de l'ADR (« ≥3 domaines distincts »). Ce module isole le SCORING
 * infra (build Docker réel + inspection réelle de l'image), sur le même modèle que
 * `scoreSqlDeliverable` dans bench-v2.js : DB/ressource JETABLE créée → apply →
 * assertions → nettoyage systématique en `finally`. AUCUNE dépendance vers
 * bench-v2.js (évite un require circulaire — c'est bench-v2.js qui require CE
 * module et ré-exporte ses fonctions, pas l'inverse).
 *
 * Ce que ce scorer vérifie par EXÉCUTION RÉELLE (jamais du texte parsé dans le
 * Dockerfile) :
 *   - le Dockerfile livré construit réellement une image (`docker build`) ;
 *   - `docker inspect` : l'image tourne sous un USER non-root ;
 *   - `docker run ... id -u` : l'uid EFFECTIF au runtime est non-root (couvre le
 *     cas d'un USER déclaré qui mappe quand même sur uid 0) ;
 *   - `docker inspect` : un HEALTHCHECK est bien défini sur l'image finale ;
 *   - `docker inspect .Size` : la taille de l'image finale reste sous un seuil
 *     raisonnable (MAX_IMAGE_SIZE_BYTES, voir justification ci-dessous) ;
 *   - `docker create` + `docker export` + `tar` : AUCUNE trace du fichier `.env`
 *     de test (ni son nom, ni son contenu secret) dans le filesystem RÉEL de
 *     l'image construite — pas une simple absence de `COPY .env` dans le texte du
 *     Dockerfile (un `COPY . .` sans `.dockerignore` copierait quand même le
 *     secret ; seule l'inspection du filesystem réel le détecte).
 *
 * Contexte de build FIXE (fixture minimaliste, cf. ADR-021 Action 3 — « pas besoin
 * d'une vraie app ») : un `package.json` sans aucune dépendance externe (le build
 * ne dépend donc PAS du réseau npm, seule l'image de base Docker doit être
 * accessible), un `server.js` factice, et un `.env` qui NE DOIT JAMAIS apparaître
 * dans l'image finale (secret canari détecté par contenu, pas seulement par nom
 * de fichier — un renommage ne suffit pas à passer le test).
 *
 * Simplification documentée (au lieu de deviner en silence, cf. mandat) : on ne
 * vérifie PAS que le serveur démarre réellement et répond sur /health — seulement
 * que l'image est construite et respecte les propriétés statiques/structurelles
 * (USER, HEALTHCHECK déclaré, taille, absence de secret) et qu'un process peut
 * tourner sous un uid non-root. Un vrai test end-to-end (démarrer le conteneur,
 * curl /health) ajouterait de la fragilité (port, délai de démarrage) pour un
 * gain marginal par rapport à ce que HEALTHCHECK/USER/inspection couvrent déjà.
 *
 * CLI (debug uniquement, le harnais principal est bench-v2.js) :
 *   node bench-v2-infra.js check-docker
 */

const { readFileSync, writeFileSync, existsSync, mkdtempSync, rmSync } = require('fs')
const { join } = require('path')
const os = require('os')
const { spawnSync } = require('child_process')

// ── Seuil de taille d'image (justifié par mesure réelle, pas arbitraire) ──────
// Mesuré le 2026-08-06 sur cette machine (docker inspect --format '{{.Size}}') :
//   node:20-alpine (base seule)        ≈  49 Mo
//   image finale multi-stage (fixture) ≈  49 Mo (app fixture ~0 octet additionnel)
//   node:20-slim   (base seule)        ≈  71 Mo
//   distroless nodejs20-debian12       ≈  44 Mo
//   node:20 (Debian complet, PAS alpine/slim) ≈ 389 Mo
// Seuil fixé à 150 Mo : large marge au-dessus des bases minimalistes légitimes
// (alpine/slim/distroless + petite app), mais rejette sans ambiguïté l'usage
// d'une base non-slimmée en stage final (erreur la plus commune et la plus
// coûteuse en pratique).
const MAX_IMAGE_SIZE_BYTES = 150 * 1024 * 1024

// ── Contexte de build fixe (fixture minimaliste) ──────────────────────────────
// Zéro dépendance externe : le build ne requiert QUE l'image Docker de base
// (pas d'accès au registre npm), pour un scoring rapide et non-flaky.
const FIXTURE_PACKAGE_JSON = JSON.stringify({
  name: 'benchv2-fixture-app',
  version: '1.0.0',
  private: true,
  scripts: {
    build: 'mkdir -p dist && cp server.js dist/server.js',
    start: 'node dist/server.js',
  },
}, null, 2) + '\n'

const FIXTURE_SERVER_JS = `const http = require('http');
const PORT = process.env.PORT || 3000;
http.createServer((req, res) => {
  if (req.url === '/health') { res.writeHead(200); res.end('ok'); return; }
  res.writeHead(200); res.end('hello');
}).listen(PORT, () => console.log('listening on', PORT));
`

// Marqueur de contenu recherché dans le filesystem exporté de l'image : un
// canari suffisamment spécifique pour ne jamais matcher un faux positif.
const SECRET_MARKER = 'benchv2-super-secret-token-do-not-leak'
const FIXTURE_ENV_SECRET = `SECRET_KEY=${SECRET_MARKER}\nDB_PASSWORD=hunter2\n`

/** Détecte si le démon Docker est joignable. IMPUR. Sur le modèle de postgresAvailable(). */
function dockerAvailable() {
  try {
    const r = spawnSync('docker', ['version', '--format', '{{.Server.Version}}'], { encoding: 'utf8', timeout: 8000 })
    return r.status === 0 && !!(r.stdout || '').trim()
  } catch { return false }
}

/**
 * Extrait les blocs ```dockerfile / ```docker d'un texte livrable. PURE.
 * Même convention que extractSqlBlocks (bench-v2.js) : langage EXPLICITE requis
 * (insensible à la casse) — un bloc ``` sans langage n'est jamais traité comme
 * un Dockerfile implicite, pour ne pas deviner silencieusement.
 * Retourne string[] (chaque bloc, trimé), dans l'ordre d'apparition.
 */
function extractDockerBlocks(text) {
  if (!text || typeof text !== 'string') return []
  const blocks = []
  const re = /```([a-zA-Z0-9_-]*)\n([\s\S]*?)```/g
  let m
  while ((m = re.exec(text)) !== null) {
    const lang = (m[1] || '').toLowerCase()
    if (lang === 'dockerfile' || lang === 'docker') {
      const body = m[2].trim()
      if (body) blocks.push(body)
    }
  }
  return blocks
}

/** Calcule le score (% de checks OK). PURE. Même formule que computeAssertionScore. */
function computeCheckScore(results) {
  const total = results.length
  if (!total) return { score: 0, passed: 0, total: 0 }
  const passed = results.filter(r => r.ok).length
  return { score: Math.round((passed / total) * 100), passed, total }
}

/** Sanitize un fragment pour usage dans un tag d'image Docker. PURE. */
function safeTagPart(s, maxLen) {
  return String(s ?? '').toLowerCase().replace(/[^a-z0-9_.-]/g, '-').replace(/^[.-]+/, '').slice(0, maxLen) || 'x'
}

/**
 * Écrit le contexte de build (fixture + Dockerfile livrable) dans un répertoire
 * jetable et lance `docker build`. IMPUR. Retourne le résultat brut de spawnSync.
 */
function runDockerBuild(buildDir, dockerfileContent, imageTag) {
  writeFileSync(join(buildDir, 'Dockerfile'), dockerfileContent + '\n')
  writeFileSync(join(buildDir, 'package.json'), FIXTURE_PACKAGE_JSON)
  writeFileSync(join(buildDir, 'server.js'), FIXTURE_SERVER_JS)
  writeFileSync(join(buildDir, '.env'), FIXTURE_ENV_SECRET)
  // Pas de --no-cache : le cache de build Docker est invalidé par Docker lui-même
  // dès que le contenu (Dockerfile ou contexte) change — le réutiliser accélère
  // significativement les runs répétés (calibration, tests) sans risque de
  // correction (les checks portent sur l'image FINALE réellement produite).
  return spawnSync('docker', ['build', '--rm', '-t', imageTag, buildDir], { encoding: 'utf8', timeout: 180000 })
}

/**
 * Vérifie l'ABSENCE du secret de test dans le filesystem RÉEL d'une image
 * construite : `docker create` (pas besoin de démarrer le process) + `docker
 * export` + inspection du tarball (liste des noms ET grep du contenu). IMPUR.
 * Retourne { ok, detail, cleanupOk } — le conteneur créé est TOUJOURS supprimé
 * avant de retourner (cleanup local, indépendant du finally de l'appelant).
 */
function checkNoSecretLeak(imageTag, workDir) {
  const create = spawnSync('docker', ['create', imageTag], { encoding: 'utf8', timeout: 15000 })
  if (create.status !== 0) {
    return { ok: null, detail: `docker create échoué: ${(create.stderr || '').trim().slice(0, 200)}` }
  }
  const containerId = (create.stdout || '').trim()
  const tarPath = join(workDir, 'rootfs.tar')
  try {
    const exported = spawnSync('docker', ['export', '-o', tarPath, containerId], { encoding: 'utf8', timeout: 30000 })
    if (exported.status !== 0 || !existsSync(tarPath)) {
      return { ok: null, detail: `docker export échoué: ${(exported.stderr || '').trim().slice(0, 200)}` }
    }
    const listing = spawnSync('tar', ['-tf', tarPath], { encoding: 'utf8', timeout: 20000, maxBuffer: 64 * 1024 * 1024 })
    const files = (listing.stdout || '').split('\n')
    const envFilePresent = files.some(f => /(^|\/)\.env$/.test(f.replace(/^\.\//, '')))

    // `tar -xOf` extrait TOUT le contenu des fichiers réguliers vers stdout —
    // détecte le secret même s'il a été renommé ou déplacé dans l'image.
    const extractProc = spawnSync('sh', ['-c', `tar -xOf ${JSON.stringify(tarPath)} 2>/dev/null | grep -a -c ${JSON.stringify(SECRET_MARKER)}`],
      { encoding: 'utf8', timeout: 30000, maxBuffer: 256 * 1024 * 1024 })
    const grepCount = parseInt((extractProc.stdout || '').trim(), 10) || 0

    const leaked = envFilePresent || grepCount > 0
    const detail = leaked
      ? (envFilePresent ? '.env présent dans le filesystem de l\'image' : `contenu du secret trouvé (${grepCount} occurrence(s)) dans le filesystem de l'image`)
      : 'absent'
    return { ok: !leaked, detail }
  } finally {
    spawnSync('docker', ['rm', '-f', containerId], { encoding: 'utf8', timeout: 15000 })
  }
}

/**
 * Scorer infra « Dockerfile multi-stage » : construit réellement l'image livrée
 * et vérifie ses propriétés par INSPECTION RÉELLE. IMPUR (docker). Signature
 * alignée sur scoreSqlDeliverable(task, deliverableText, randSuffix) de
 * bench-v2.js : le suffixe aléatoire est passé en argument (pas de Math.random
 * ici — testabilité).
 * Retourne { score:0..100|null, detail }.
 */
function scoreDockerDeliverable(task, deliverableText, randSuffix) {
  if (!dockerAvailable()) {
    return { score: null, detail: 'docker-indisponible' }
  }
  const blocks = extractDockerBlocks(deliverableText)
  if (!blocks.length) {
    return { score: 0, detail: 'aucun bloc ```dockerfile dans le livrable' }
  }
  // Un seul Dockerfile a un sens (une seule séquence FROM/stages) : le premier
  // bloc est utilisé, les suivants sont IGNORÉS et signalés (pas de fusion
  // silencieuse — cf. mandat « documente plutôt que deviner »).
  const dockerfileContent = blocks[0]
  const extraBlocksNote = blocks.length > 1
    ? `${blocks.length - 1} bloc(s) dockerfile additionnel(s) ignoré(s) (seul le premier est scoré)`
    : null

  const checks = (task.assets && task.assets.dockerChecks) || []
  if (!checks.length) {
    return { score: null, detail: 'aucune vérification définie pour la tâche' }
  }

  const safeBase = safeTagPart(task.id, 30)
  const safeSuffix = safeTagPart(randSuffix, 12)
  const imageTag = `benchv2-${safeBase}-${safeSuffix}`.slice(0, 100)

  const buildDir = mkdtempSync(join(os.tmpdir(), 'benchv2-docker-build-'))
  const workDir = mkdtempSync(join(os.tmpdir(), 'benchv2-docker-work-'))
  try {
    const build = runDockerBuild(buildDir, dockerfileContent, imageTag)
    const buildOk = build.status === 0
    const buildError = buildOk ? null : (build.stderr || '').trim().slice(0, 500)

    const results = []
    results.push({
      name: 'image construite avec succès',
      ok: buildOk,
      expect: 'exit 0',
      got: buildOk ? '0' : String(build.status ?? 'erreur'),
    })

    if (buildOk) {
      // USER déclaré non-root (config de l'image).
      const userInspect = spawnSync('docker', ['inspect', '--format', '{{.Config.User}}', imageTag], { encoding: 'utf8', timeout: 15000 })
      const userVal = (userInspect.stdout || '').trim()
      const isNonRootDeclared = userVal !== '' && userVal !== 'root' && userVal !== '0' && userVal !== '0:0'
      results.push({
        name: 'USER non-root déclaré',
        ok: isNonRootDeclared,
        expect: 'non vide et != root/0',
        got: userVal || '(vide → root implicite)',
      })

      // uid EFFECTIF au runtime (couvre un USER déclaré qui mapperait quand
      // même sur uid 0 — la déclaration seule ne suffit pas).
      const idRun = spawnSync('docker', ['run', '--rm', imageTag, 'sh', '-c', 'id -u'], { encoding: 'utf8', timeout: 20000 })
      const uidVal = (idRun.stdout || '').trim()
      const isNonRootRuntime = idRun.status === 0 && uidVal !== '' && uidVal !== '0'
      results.push({
        name: 'uid effectif non-root au runtime',
        ok: isNonRootRuntime,
        expect: '!= 0',
        got: idRun.status === 0 ? uidVal : `__error__:${(idRun.stderr || '').trim().slice(0, 160)}`,
      })

      // HEALTHCHECK présent.
      const hcInspect = spawnSync('docker', ['inspect', '--format', '{{json .Config.Healthcheck}}', imageTag], { encoding: 'utf8', timeout: 15000 })
      const hcRaw = (hcInspect.stdout || '').trim()
      const hasHealthcheck = !!hcRaw && hcRaw !== 'null'
      results.push({
        name: 'HEALTHCHECK présent',
        ok: hasHealthcheck,
        expect: 'non null',
        got: hcRaw || 'null',
      })

      // Taille de l'image finale sous le seuil.
      const sizeInspect = spawnSync('docker', ['inspect', '--format', '{{.Size}}', imageTag], { encoding: 'utf8', timeout: 15000 })
      const sizeBytes = parseInt((sizeInspect.stdout || '').trim(), 10)
      const sizeOk = Number.isFinite(sizeBytes) && sizeBytes > 0 && sizeBytes <= MAX_IMAGE_SIZE_BYTES
      results.push({
        name: 'taille image sous le seuil',
        ok: sizeOk,
        expect: `<= ${MAX_IMAGE_SIZE_BYTES} octets`,
        got: Number.isFinite(sizeBytes) ? `${sizeBytes} octets` : 'inconnue',
      })

      // Absence du secret .env dans le filesystem RÉEL de l'image.
      const leakCheck = checkNoSecretLeak(imageTag, workDir)
      results.push({
        name: 'aucun secret .env dans l\'image finale',
        ok: leakCheck.ok === true,
        expect: 'absent',
        got: leakCheck.ok === null ? `__error__:${leakCheck.detail}` : leakCheck.detail,
      })
    }

    const { score, passed, total } = computeCheckScore(results)
    const detail = {
      passed, total,
      buildError,
      note: extraBlocksNote,
      assertions: results.map(r => ({ name: r.name, ok: r.ok, expect: r.expect, got: r.got })),
    }
    return { score, detail }
  } catch (e) {
    return { score: null, detail: `exception scorer docker: ${e.message}` }
  } finally {
    // Nettoyage GARANTI, même si le build a échoué : jamais d'image/conteneur
    // orphelin (cf. mandat). `docker rmi` sur un tag inexistant est un no-op
    // (erreur ignorée) : `imageTag` n'existe pas si le build a échoué avant
    // d'exporter l'image.
    spawnSync('docker', ['rmi', '-f', imageTag], { encoding: 'utf8', timeout: 20000 })
    try { rmSync(buildDir, { recursive: true, force: true }) } catch { /* best-effort */ }
    try { rmSync(workDir, { recursive: true, force: true }) } catch { /* best-effort */ }
  }
}

// ── CLI (debug) ────────────────────────────────────────────────────────────────
function main(argv) {
  const cmd = argv[2]
  if (cmd === 'check-docker') {
    console.log(dockerAvailable() ? 'docker disponible' : 'docker INDISPONIBLE')
    return
  }
  console.log('bench-v2-infra — commandes : check-docker')
  console.log('(scorer principal appelé depuis bench-v2.js, pas directement en CLI)')
}

module.exports = {
  MAX_IMAGE_SIZE_BYTES,
  FIXTURE_PACKAGE_JSON, FIXTURE_SERVER_JS, FIXTURE_ENV_SECRET, SECRET_MARKER,
  dockerAvailable, extractDockerBlocks, computeCheckScore, safeTagPart,
  scoreDockerDeliverable,
  // Exportés pour tests ciblés (mock-friendly) :
  runDockerBuild, checkNoSecretLeak,
}

if (require.main === module) main(process.argv)
