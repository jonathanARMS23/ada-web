#!/usr/bin/env node
'use strict'
/**
 * coordinator/bench-v2-ts.js — Scorer TypeScript (exécution réelle Node), module
 * SÉPARÉ importé par bench-v2.js.
 *
 * POURQUOI CE FICHIER (ADR-021, finding G8 / Action 3) : le corpus bench-v2 était
 * 100% SQL (12/12 tâches) — un seul registre de tâches, contraire au principe #6
 * du protocole (« ≥3 domaines distincts »). Ce module ajoute un scorer pour un
 * DEUXIÈME domaine (TypeScript pur, logique métier + validation class-validator),
 * sans toucher au scorer SQL existant ni alourdir bench-v2.js.
 *
 * PRINCIPE : même esprit que scoreSqlDeliverable — exécution RÉELLE (pas de grep/
 * heuristique textuelle), assertions nommées avec expect/got, score = %age
 * d'assertions qui passent.
 *
 * ARCHITECTURE — CHOIX DOCUMENTÉS (pas de bootstrap NestJS complet, par design) :
 *
 *   1. Isolation d'exécution : un vrai projet Nest (DI container, main.ts,
 *      modules) serait lent à bootstrapper à chaque scoring et introduirait des
 *      dépendances runtime (DB, HTTP) que la tâche n'a pas besoin de tester. Le
 *      livrable est donc un fichier TypeScript ISOLÉ (fonction + classe DTO),
 *      compilé et exécuté seul dans un répertoire jetable — déterministe et
 *      rapide (~1-2s par scoring, comparable au scorer SQL).
 *
 *   2. Runtime `class-validator`/`reflect-metadata`/`typescript` : `.claude/`
 *      n'a PAS ces paquets installés (seul `typescript` y figure, en
 *      devDependency, pour le type-check du coordinateur lui-même — pas pour
 *      exécuter du code généré). Plutôt que d'ajouter une dépendance dupliquée
 *      à .claude/package.json (class-validator + reflect-metadata) uniquement
 *      pour ce scorer, on RÉUTILISE le node_modules du projet NestJS du dépôt
 *      (`ada-api-nest/`), qui les fournit déjà comme dépendances de production
 *      réelles — c'est très exactement le stack (NestJS + class-validator) que
 *      la tâche est censée exercer. Un `node_modules` est symlinké dans le
 *      répertoire jetable de compilation (voir RUNTIME_NODE_MODULES).
 *      Vérifié manuellement : `tsc` NE RÉSOUT PAS les types via la variable
 *      d'environnement NODE_PATH (contrairement à `node` au runtime) — seul un
 *      `node_modules` réel (ou symlinké) à côté du tsconfig fonctionne pour la
 *      résolution de types ET pour l'exécution. D'où le symlink plutôt qu'un
 *      NODE_PATH, qui aurait été plus simple mais ne marche pas pour tsc.
 *      Conséquence assumée : ce scorer suppose `ada-api-nest/node_modules`
 *      installé (`npm install` dans ce sous-projet) — sinon `typescriptAvailable()`
 *      renvoie false et le scorer SKIP explicitement (jamais un score silencieux).
 *
 *   3. Gate de compilation stricte AVANT exécution : `tsc -p tsconfig.json` avec
 *      `noEmitOnError:true` — une seule invocation fait à la fois le rôle de
 *      « tsc --noEmit d'abord » (erreur de type → aucun .js émis, score 0, erreur
 *      RÉELLE du compilateur capturée) et l'émission du JS exécutable en cas de
 *      succès. Simplification assumée par rapport à « tsc --noEmit puis tsc » :
 *      un seul process tsc, même garantie (jamais de JS émis si erreur de type).
 *
 *   4. Assertions comportementales : exécutées via un VRAI harnais `node:test`
 *      généré à la volée (pas une simulation) — chaque assertion de
 *      `task.assets.assertions` devient un `test()` réel. Le résultat structuré
 *      (name/expect/got/ok, même format que le scorer SQL) est calculé PAR le
 *      harnais lui-même (pas en parsant la sortie TAP de node:test — ADR-021 a
 *      déjà documenté un bug de parsing TAP fragile sur error-context.js, on ne
 *      répète pas ce piège) : un marqueur JSON unique (`__BENCH_TS_RESULTS__`)
 *      est écrit sur stdout dans un handler `process.on('exit', …)`, garanti
 *      d'être atteint après l'exécution de tous les tests synchrones.
 *
 * Format d'une assertion (task.assets.assertions[i]), analogue à l'assertion SQL :
 *   {
 *     name: string,                       // nom, apparaît dans detail.assertions
 *     type: 'value' | 'throws',           // 'value' (défaut) : compare le résultat
 *                                          // à `expect` (deepEqual JSON) ; 'throws' :
 *                                          // attend une exception (optionnellement
 *                                          // typée via throwsInstanceOf)
 *     expr: string,                       // expression JS évaluée avec `mod` (le
 *                                          // module compilé) et `validateSync`
 *                                          // (class-validator) en scope, ex:
 *                                          // "mod.computeInvoiceTotal([...])"
 *     expect?: any,                       // valeur attendue (type 'value')
 *     throwsInstanceOf?: string,          // ex: 'RangeError' (type 'throws')
 *   }
 *
 * CLI/tests : exporte scoreTsDeliverable, extractTsBlocks, typescriptAvailable,
 * buildHarnessSource (pure, testable sans tsc) pour le futur harnais de
 * calibration et les tests unitaires.
 */

const { readFileSync, writeFileSync, mkdirSync, rmSync, existsSync, symlinkSync } = require('fs')
const { join } = require('path')
const os = require('os')
const { spawnSync } = require('child_process')

const COORD_DIR  = __dirname
const CLAUDE_DIR = join(COORD_DIR, '..')
const REPO_DIR   = join(CLAUDE_DIR, '..')

const TSC_BIN = join(CLAUDE_DIR, 'node_modules', '.bin', 'tsc')
// Voir commentaire d'architecture point 2 ci-dessus : runtime réutilisé du
// projet NestJS du dépôt (typescript + class-validator + reflect-metadata déjà
// présents comme dépendances réelles), plutôt qu'une dépendance dupliquée dans
// .claude/package.json ou un vrai bootstrap Nest (lent, hors-scope pour ce test
// de logique métier pure).
const RUNTIME_NODE_MODULES = join(REPO_DIR, 'ada-api-nest', 'node_modules')

// ── Extraction (PURE) ────────────────────────────────────────────────────────

/**
 * Extrait les blocs ```typescript / ```ts d'un texte livrable. PURE.
 * Même forme qu'extractSqlBlocks (bench-v2.js) : langage insensible à la casse,
 * ignore les autres langages, ignore les blocs sans langage déclaré.
 * @returns {string[]}
 */
function extractTsBlocks(text) {
  if (!text || typeof text !== 'string') return []
  const blocks = []
  const re = /```([a-zA-Z0-9_-]*)\n([\s\S]*?)```/g
  let m
  while ((m = re.exec(text)) !== null) {
    const lang = (m[1] || '').toLowerCase()
    if (lang === 'typescript' || lang === 'ts') {
      const body = m[2].trim()
      if (body) blocks.push(body)
    }
  }
  return blocks
}

/** Score (% assertions OK) à partir des résultats d'assertions. PURE. */
function computeScore(results) {
  const total = results.length
  if (!total) return { score: 0, passed: 0, total: 0 }
  const passed = results.filter(r => r.ok).length
  return { score: Math.round((passed / total) * 100), passed, total }
}

// ── Disponibilité de l'environnement (IMPUR) ─────────────────────────────────

/**
 * Détecte si tsc + le runtime class-validator/reflect-metadata sont disponibles.
 * IMPUR (fs + spawn). Jamais de score silencieux si false : le scorer renvoie
 * un SKIP explicite (score:null), comme postgresAvailable() pour le scorer SQL.
 */
function typescriptAvailable() {
  try {
    if (!existsSync(TSC_BIN)) return false
    if (!existsSync(join(RUNTIME_NODE_MODULES, 'class-validator'))) return false
    if (!existsSync(join(RUNTIME_NODE_MODULES, 'reflect-metadata'))) return false
    const r = spawnSync(TSC_BIN, ['--version'], { encoding: 'utf8', timeout: 8000 })
    return r.status === 0
  } catch { return false }
}

// ── Génération du tsconfig éphémère (PURE, constante) ────────────────────────
// noEmitOnError:true — voir point 3 du commentaire d'architecture en tête de
// fichier : une seule invocation tsc joue le rôle de la gate de compilation ET
// de l'émission. strict:true — cohérent avec la convention projet « pas de any ».
const TSCONFIG_JSON = JSON.stringify({
  compilerOptions: {
    target: 'ES2020',
    module: 'CommonJS',
    moduleResolution: 'node',
    experimentalDecorators: true,
    emitDecoratorMetadata: true,
    strict: true,
    esModuleInterop: true,
    skipLibCheck: true,
    resolveJsonModule: true,
    noEmitOnError: true,
    outDir: 'dist',
  },
  include: ['deliverable.ts'],
}, null, 2)

// ── Harnais node:test (PURE — génère du texte, n'exécute rien) ───────────────

/**
 * Construit le source JS du harnais `node:test` qui exécute les assertions
 * comportementales contre le module compilé. PURE (génère une string, ne touche
 * ni au disque ni au réseau).
 *
 * Chaque assertion devient un VRAI `test()` node:test (échoue réellement si
 * `record.ok` est faux) ET pousse son résultat structuré {name,expect,got,ok}
 * dans un tableau RESULTS, imprimé en JSON derrière un marqueur unique sur
 * stdout à la sortie du process (process.on('exit')) — pas de parsing de la
 * sortie TAP de node:test (piège déjà rencontré sur error-context.js).
 *
 * @param {Array<object>} assertions
 * @param {string} distFile chemin ABSOLU du module compilé (dist/deliverable.js)
 * @returns {string}
 */
function buildHarnessSource(assertions, distFile) {
  const lines = []
  lines.push("'use strict'")
  lines.push("require('reflect-metadata')")
  lines.push("const test = require('node:test')")
  lines.push("const { validateSync } = require('class-validator')")
  lines.push(`const mod = require(${JSON.stringify(distFile)})`)
  lines.push('const RESULTS = []')
  lines.push('function deepEqual(a, b) { return JSON.stringify(a) === JSON.stringify(b) }')

  for (const a of assertions) {
    const name = String(a.name || 'assertion')
    const nameLit = JSON.stringify(name)
    const expectLit = JSON.stringify(a.expect === undefined ? null : a.expect)
    const isThrows = a.type === 'throws'
    const throwsType = a.throwsInstanceOf ? JSON.stringify(a.throwsInstanceOf) : null

    lines.push(`test(${nameLit}, () => {`)
    lines.push(`  const record = { name: ${nameLit}, expect: ${expectLit}, got: null, ok: false }`)
    lines.push('  try {')
    // L'expression de l'assertion est exécutée dans une IIFE recevant mod/validateSync
    // en paramètres (pas de closure implicite, pas d'accès au scope du harnais).
    lines.push(`    const __value = (function (mod, validateSync) { return (${a.expr}) })(mod, validateSync)`)
    if (isThrows) {
      lines.push("    record.ok = false")
      lines.push("    record.got = 'no-throw:' + JSON.stringify(__value)")
    } else {
      lines.push('    record.got = __value')
      lines.push('    record.ok = deepEqual(__value, record.expect)')
    }
    lines.push('  } catch (e) {')
    if (isThrows) {
      lines.push(`    record.ok = ${throwsType ? `e.constructor.name === ${throwsType}` : 'true'}`)
      lines.push("    record.got = 'threw:' + e.constructor.name + ':' + e.message")
    } else {
      lines.push("    record.ok = false")
      lines.push("    record.got = 'threw:' + e.constructor.name + ':' + e.message")
    }
    lines.push('  }')
    lines.push('  RESULTS.push(record)')
    lines.push(`  if (!record.ok) throw new Error(${nameLit} + ': expected ' + JSON.stringify(record.expect) + ' got ' + JSON.stringify(record.got))`)
    lines.push('})')
  }

  lines.push("process.on('exit', () => {")
  lines.push("  process.stdout.write('\\n__BENCH_TS_RESULTS__' + JSON.stringify(RESULTS) + '\\n')")
  lines.push('})')
  return lines.join('\n')
}

const RESULTS_MARKER = '__BENCH_TS_RESULTS__'

// ── Scorer principal (IMPUR : fs + tsc + node) ───────────────────────────────

/**
 * Scorer TypeScript : compile le(s) bloc(s) ```typescript du livrable, exécute
 * les assertions comportementales via un vrai harnais node:test. IMPUR
 * (fs/tsc/node). Le suffixe aléatoire est passé en argument (testabilité — pas
 * de Math.random ici), même contrat que scoreSqlDeliverable.
 *
 * @param {object} task            tâche (assets.assertions requis)
 * @param {string} deliverableText texte brut du livrable (contient des blocs ```typescript)
 * @param {string} randSuffix      suffixe pour le répertoire jetable
 * @returns {{score:number|null, detail:any}}
 */
function scoreTsDeliverable(task, deliverableText, randSuffix) {
  if (!typescriptAvailable()) {
    return { score: null, detail: 'typescript-indisponible (tsc introuvable ou ada-api-nest/node_modules sans class-validator/reflect-metadata — lance `npm install` dans ada-api-nest/)' }
  }
  const blocks = extractTsBlocks(deliverableText)
  if (!blocks.length) {
    return { score: 0, detail: 'aucun bloc ```typescript dans le livrable' }
  }
  const assertions = (task.assets && task.assets.assertions) || []
  if (!assertions.length) {
    return { score: null, detail: 'aucune assertion définie pour la tâche' }
  }

  const safeBase = String(task.id).toLowerCase().replace(/[^a-z0-9_]/g, '_').slice(0, 30)
  const safeSuffix = String(randSuffix).toLowerCase().replace(/[^a-z0-9_]/g, '').slice(0, 12) || 'x'
  const dir = join(os.tmpdir(), `benchv2ts-${safeBase}-${safeSuffix}`)

  try {
    mkdirSync(dir, { recursive: true })
    try {
      // node_modules symlinké — voir point 2 du commentaire d'architecture.
      symlinkSync(RUNTIME_NODE_MODULES, join(dir, 'node_modules'), 'dir')

      writeFileSync(join(dir, 'deliverable.ts'), blocks.join('\n\n') + '\n')
      writeFileSync(join(dir, 'tsconfig.json'), TSCONFIG_JSON)

      // Gate de compilation stricte + émission (noEmitOnError:true, point 3).
      const compiled = spawnSync(TSC_BIN, ['-p', 'tsconfig.json'], { cwd: dir, encoding: 'utf8', timeout: 30000 })
      if (compiled.status !== 0) {
        return { score: 0, detail: { compileError: (compiled.stdout || compiled.stderr || '').trim().slice(0, 2000) } }
      }

      const distFile = join(dir, 'dist', 'deliverable.js')
      if (!existsSync(distFile)) {
        return { score: 0, detail: { compileError: 'tsc a réussi (exit 0) mais dist/deliverable.js est absent — structure de livrable inattendue (aucune valeur exportée ?)' } }
      }

      const harnessPath = join(dir, 'harness.test.js')
      writeFileSync(harnessPath, buildHarnessSource(assertions, distFile))

      // Le harnais `require('node:test')` directement (PAS de flag `--test`) :
      // `test()` s'exécute quel que soit le mode d'invocation, --test n'est
      // nécessaire que pour la découverte automatique de fichiers. Ce choix
      // n'est PAS cosmétique : ce scorer peut lui-même être appelé depuis un
      // fichier de test tournant sous `node --test` (ex. bench-v2-ts.test.js
      // via tests/run-all.js) — Node propage alors `NODE_TEST_CONTEXT` aux
      // process enfants, et un enfant lancé avec `--test` détecte l'appel
      // imbriqué et l'ignore silencieusement (« run() is being called
      // recursively », aucun test exécuté, marqueur jamais écrit → faux score
      // 0 systématique dès que le scorer tourne sous un test). On retire donc
      // explicitement `NODE_TEST_CONTEXT` de l'environnement de l'enfant, en
      // plus de ne jamais passer `--test` : le harnais se comporte alors comme
      // un process node de premier niveau, peu importe le contexte appelant.
      // Vérifié manuellement (POC dédié) : sans ce retrait, un appel imbriqué
      // silencieux comme un appel de premier niveau produisent un stdout
      // différent (flux binaire du reporter v8 vs TAP humain) — seul le
      // retrait de la variable garantit un comportement IDENTIQUE dans les
      // deux contextes.
      const childEnv = { ...process.env }
      delete childEnv.NODE_TEST_CONTEXT
      const ran = spawnSync(process.execPath, [harnessPath], { cwd: dir, encoding: 'utf8', timeout: 30000, env: childEnv })
      const stdout = ran.stdout || ''
      const idx = stdout.indexOf(RESULTS_MARKER)
      if (idx === -1) {
        return { score: 0, detail: { harnessError: (stdout + '\n' + (ran.stderr || '')).trim().slice(0, 2000) } }
      }
      let results
      try {
        results = JSON.parse(stdout.slice(idx + RESULTS_MARKER.length).split('\n')[0])
      } catch (e) {
        return { score: 0, detail: { harnessError: `parse résultats échoué: ${e.message}` } }
      }
      const { score, passed, total } = computeScore(results)
      return { score, detail: { passed, total, assertions: results } }
    } finally {
      rmSync(dir, { recursive: true, force: true })
    }
  } catch (e) {
    return { score: null, detail: `exception scorer TS: ${e.message}` }
  }
}

module.exports = {
  extractTsBlocks,
  computeScore,
  typescriptAvailable,
  buildHarnessSource,
  scoreTsDeliverable,
  RESULTS_MARKER,
  TSC_BIN,
  RUNTIME_NODE_MODULES,
}
