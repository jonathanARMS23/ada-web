#!/usr/bin/env node
'use strict'
/**
 * coordinator/bench-v2.js — Benchmark v2 : framework d'ablation par catégorie.
 *
 * Isolé du benchmark v1 (coordinator/benchmark.js). Compare 4 BRAS d'ablation
 * sur des tâches taguées par CATÉGORIE, avec un scoring PROBANT (exécution réelle
 * Postgres pour le SQL, F1 réel pour la récupération — pas du grep), puis un report
 * qui calcule les deltas d'ablation pour attribuer le ROI à chaque feature d'ADA.
 *
 * Les 4 bras :
 *   A naked             : agent générique, sonnet, 0 mémoire
 *   B ada-memoire       : A + injection conventions (recall)
 *   C ada-solo-route    : B + agent spécialisé + tier routing
 *   D ada-full-pipeline : C + décomposition multi-agents
 * Deltas : B−A = valeur mémoire | C−B = valeur routing/spécialisation | D−C = ROI décomposition.
 *
 * L'orchestrateur (Claude) exécute les bras via `plan`, puis appelle `score`.
 * Ce module NE spawn PAS d'agents : il fournit le HARNAIS + les scorers.
 *
 * CLI :
 *   node bench-v2.js plan   --categories <c1,c2> [--tasks t1,t2] [--arms A,B,C,D]
 *   node bench-v2.js menu   [--categories ...] [--tasks ...] [--arms ...]
 *   node bench-v2.js score  <taskId> <arm> --category <cat> --output-file <f> [--model <id>] [--run-id <id>]
 *                           [--tokens-input <n> --tokens-output <n> --tokens-cache-read <n> --tokens-cache-write <n>]
 *                           [--cost-usd <n>] [--wall-clock-ms <n>] [--agent-calls <n>]
 *   node bench-v2.js report [--category <cat>] [--arms A,B] [--no-deltas]
 *   node bench-v2.js reset
 *
 * TÉLÉMÉTRIE D'EFFICIENCE (G6, ADR-021 principe #9 ; ADR-023 étape 1, BLOQUANTE) :
 * les flags --tokens-* / --cost-usd / --wall-clock-ms / --agent-calls sont la
 * façon STANDARD de fournir cette mesure lors d'un run manuel — exactement comme
 * `run.js done --tokens --cost` pour le run.js principal (mandaté par CLAUDE.md).
 * bench-v2.js NE SPAWN PAS d'agents (ADR-021 finding F7) : il ne peut donc PAS
 * capturer ces métriques automatiquement, seulement les PERSISTER si l'appelant
 * (l'orchestrateur qui a exécuté le trial) les fournit. Flag absent → champ `null`
 * (non mesuré), jamais `0` (mesuré à zéro) — même convention que `model` ci-dessous.
 *
 * PROVENANCE (ADR-021 I3) : chaque `score` enregistre runId + scorerSha + tasksSha
 * (+ model), et le vocabulaire des bras n'est PAS figé à A-D — un bras `NATIVE`
 * ou `PIPELINE` est enregistré ET agrégé, plus jamais effacé en silence du rapport.
 * `report` REFUSE (erreur, exit 1) de calculer un delta sur un plan déséquilibré,
 * une cellule ambiguë (plusieurs scores pour un même couple tâche/bras) ou des
 * scorerSha mélangés.
 */

const { readFileSync, writeFileSync, existsSync, mkdirSync, renameSync } = require('fs')
const { join, dirname } = require('path')
const os = require('os')
const { createHash } = require('crypto')
const { spawnSync } = require('child_process')

// v2 est isolé et self-contained dans le repo : on résout les chemins relativement
// au module (__dirname == .../.claude/coordinator) pour éviter le piège de dérive
// repo↔runtime (CLAUDE_CONFIG_DIR pointe parfois sur une copie runtime).
const CLAUDE_DIR   = join(__dirname, '..')          // .../.claude
const COORD_DIR    = __dirname                       // .../.claude/coordinator
const BENCH_V2_DIR = join(CLAUDE_DIR, 'benchmarks', 'v2')
const TASKS_FILE   = join(BENCH_V2_DIR, 'tasks-v2.json')
// Seam de test : un test d'intégration du CLI `score` doit pouvoir vérifier la
// provenance ÉCRITE sans polluer le fichier de résultats réel (mesures publiées,
// citées dans les ADR). Non documenté dans l'usage : usage interne/tests.
const RESULTS_FILE = process.env.BENCH_V2_RESULTS_FILE || join(BENCH_V2_DIR, 'results-v2.json')

const C = { reset: '\x1b[0m', bold: '\x1b[1m', green: '\x1b[32m', red: '\x1b[31m', yellow: '\x1b[33m', cyan: '\x1b[36m', gray: '\x1b[90m' }

// ── Les 4 bras d'ablation (constantes) ───────────────────────────────────────
const ARMS = ['A', 'B', 'C', 'D']

const ARM_META = {
  A: { key: 'naked',             label: 'naked',             injectConventions: false, decompose: false },
  B: { key: 'ada-memoire',       label: 'ada-mémoire',       injectConventions: true,  decompose: false },
  C: { key: 'ada-solo-route',    label: 'ada-solo-route',    injectConventions: true,  decompose: false },
  D: { key: 'ada-full-pipeline', label: 'ada-full-pipeline', injectConventions: true,  decompose: true  },
}

// Profil de tâche → agent spécialisé (bras C/D). Défaut 'general-purpose'.
const PROFILE_AGENT = {
  data:    'data-modeler',
  sql:     'data-modeler',
  review:  'reviewer',
  backend: 'nestjs',
  drf:     'drf',
  frontend:'nextjs',
  devops:  'devops',
  docker:  'devops',
}

// Tier routing (bras C/D) : dérive le modèle du tier rendu par le task-classifier
// (tier 1→haiku, 2→sonnet, 3→opus) via router.recommendModel. Les bras A/B
// restent sur sonnet (baseline constante : on isole la valeur mémoire de B−A).
const { TIER_MODELS } = require('./models.js')
const DEFAULT_MODEL = TIER_MODELS[2]

/**
 * Routage tier→modèle pour un prompt (bras C/D). Déterministe (regex + lookup). PURE-ish.
 *
 * B5 — garde tier 0 : le classifieur peut renvoyer `mode:'codemod', tier:0`
 * (transformation déterministe, ZÉRO appel LLM). Or TIER_MODELS[0] n'existe pas et
 * router.recommendModel retombe SILENCIEUSEMENT sur le tier 2 → le bras C/D se
 * voyait facturer Sonnet pour une tâche censée coûter $0, sans aucune trace. Le
 * harnais bench exécute toujours un agent (il ne sait pas appliquer un codemod) :
 * on replie donc EXPLICITEMENT sur le tier 2 — exactement comme ada.js quand un
 * override bypasse le codemod (`r.mode === 'codemod' ? 2 : r.tier`, ada.js
 * --pipeline/--solo) — et on EXPOSE le bypass (`codemodBypassed`) pour que le coût
 * du bras soit attribuable au lieu d'être avalé.
 *
 * @param {string} prompt
 * @returns {{ tier: number, model: string, codemodBypassed: boolean }}
 */
function routedTier(prompt) {
  try {
    const { classifyTask } = require('./task-classifier')
    const { recommendModel } = require('./router')
    const r = classifyTask(String(prompt || '')) || {}
    const codemodBypassed = r.mode === 'codemod' || r.tier === 0
    // Aucun tier valide (0/undefined/NaN) → tier 2 explicite, jamais de fallback muet.
    const tier = codemodBypassed || !(r.tier >= 1 && r.tier <= 3) ? 2 : r.tier
    return { tier, model: recommendModel(tier), codemodBypassed }
  } catch {
    return { tier: 2, model: DEFAULT_MODEL, codemodBypassed: false }
  }
}

/** Modèle routé par tier pour un prompt (bras C/D). PURE-ish. */
function routedModel(prompt) {
  return routedTier(prompt).model
}

// ── Registre des catégories ───────────────────────────────────────────────────
// status: 'wired'   → scorer câblé (exécution réelle)
//         'planned' → visible au menu, mais score() renvoie un skip explicite.
const CATEGORY_REGISTRY = {
  'correction-reelle': {
    status: 'wired',
    label: 'Correction réelle (SQL exécuté sur Postgres)',
    scorer: 'sql',
  },
  'precision-recuperation': {
    status: 'wired',
    label: 'Précision de récupération (F1 recall conventions)',
    scorer: 'recall',
  },
  'qualite': {
    status: 'planned',
    label: 'Qualité (LLM-judge)',
    scorer: null,
  },
  'exec-time': {
    status: 'planned',
    label: 'Temps d\'exécution',
    scorer: null,
  },
  'conventions-tacites': {
    status: 'wired',
    label: 'Conventions tacites (savoir projet non prompté, SQL exécuté)',
    scorer: 'sql',
  },
  'correction-reelle-ts': {
    status: 'wired',
    label: 'Correction réelle TypeScript (compilé + exécuté via node:test, ADR-021 Action 3)',
    scorer: 'ts',
  },
  'correction-reelle-docker': {
    status: 'wired',
    label: 'Correction réelle infra (Docker build + inspection réelle de l\'image, ADR-021 Action 3, finding G8)',
    scorer: 'docker',
  },
  'above-threshold': {
    status: 'wired',
    label: 'Above-threshold (tâches XXL multi-exigences, SQL exécuté + assertions comportementales)',
    scorer: 'sql',
  },
  'token-efficiency': {
    status: 'planned',
    label: 'Efficacité tokens (coût/$)',
    scorer: null,
  },
  'valeur-multi-tours': {
    status: 'planned',
    label: 'Valeur multi-tours (mémoire conversationnelle)',
    scorer: null,
  },
  'roi-decomposition-routing': {
    status: 'planned',
    label: 'ROI décomposition vs routing (méta)',
    scorer: null,
  },
}

// ── IO ───────────────────────────────────────────────────────────────────────
function readJSON(p, fallback) { try { return JSON.parse(readFileSync(p, 'utf8')) } catch { return fallback } }
function writeJSON(p, obj) {
  mkdirSync(dirname(p), { recursive: true })
  const tmp = p + '.tmp'; writeFileSync(tmp, JSON.stringify(obj, null, 2)); renameSync(tmp, p)
}
function ts() { return new Date().toISOString() }

// ── Provenance des mesures (ADR-021 I3) ──────────────────────────────────────
// Un score sans provenance est inexploitable : deux entrées du même couple
// (tâche, bras) obtenues AVANT et APRÈS un fix de scorer sont indistinguables, et
// un rapport qui les moyenne mélange un artefact d'instrument avec une mesure
// valide (c'est arrivé : `at-orders-fulfillment-schema`/NATIVE vaut 73 ET 100).
// Chaque enregistrement porte donc : runId, scorerSha, tasksSha, model.

/** Hash de contenu (sha256 tronqué à 16 hex) d'un fichier. IMPUR (fs). */
function contentSha(path) {
  try { return 'sha256:' + createHash('sha256').update(readFileSync(path)).digest('hex').slice(0, 16) }
  catch { return null }
}

/**
 * Identité de l'INSTRUMENT pour un fichier (scorer ou catalogue de tâches). IMPUR (git + fs).
 *
 * Choix documenté (deux régimes, préfixe explicite dans la valeur) :
 *   - fichier SANS modification non commitée → `git:<sha du dernier commit l'ayant touché>`
 *     (`git log -1 --format=%H -- <path>`) : lisible, rattachable à l'historique.
 *   - fichier modifié dans le worktree, non suivi, hors repo, ou git indisponible
 *     → `sha256:<hash du contenu>` : le sha de commit mentirait sur ce qui a
 *       réellement tourné. Le préfixe rend le régime auto-descriptif, donc une
 *       comparaison entre un `git:` et un `sha256:` est traitée comme un
 *       changement d'instrument (et refusée par buildReport), ce qui est correct.
 */
function provenanceSha(path) {
  try {
    const st = spawnSync('git', ['-C', CLAUDE_DIR, 'status', '--porcelain', '--', path], { encoding: 'utf8', timeout: 8000 })
    if (st.status === 0 && !(st.stdout || '').trim()) {
      const log = spawnSync('git', ['-C', CLAUDE_DIR, 'log', '-1', '--format=%H', '--', path], { encoding: 'utf8', timeout: 8000 })
      const sha = (log.stdout || '').trim()
      if (log.status === 0 && /^[0-9a-f]{40}$/.test(sha)) return 'git:' + sha
    }
  } catch { /* git absent → repli sur le hash de contenu */ }
  return contentSha(path)
}

/**
 * Identifiant unique d'une invocation du CLI. IMPUR (horloge + aléatoire) :
 * appelé UNIQUEMENT depuis le code CLI (comme ts() et le suffixe de DB jetable),
 * jamais depuis les fonctions pures — la reproductibilité des scorers est
 * préservée. Format : `<YYYYMMDDTHHMMSS>-<6 chars>`.
 */
function newRunId() {
  const stamp = new Date().toISOString().replace(/[-:]/g, '').replace(/\.\d+Z$/, '')
  return `${stamp}-${Math.random().toString(36).slice(2, 8)}`
}

/**
 * Normalise/valide une étiquette de bras. PURE.
 * Accepte TOUTE étiquette (pas seulement A-D) : `NATIVE`, `PIPELINE`, `B2`… Le
 * vocabulaire des bras n'est PAS figé — ce qui était figé (`ARMS = A..D`) faisait
 * disparaître silencieusement du rapport toute expérience hors ablation.
 * Rejette en revanche une étiquette vide ou syntaxiquement absurde (erreur claire).
 */
function normalizeArm(arm) {
  const s = String(arm ?? '').trim().toUpperCase()
  if (!/^[A-Z0-9][A-Z0-9_-]{0,31}$/.test(s)) {
    throw new Error(`étiquette de bras invalide: ${JSON.stringify(arm)} (attendu: [A-Z0-9][A-Z0-9_-]{0,31})`)
  }
  return s
}

function loadTasks() { return (readJSON(TASKS_FILE, { tasks: [] }).tasks) || [] }
function getTask(id) { return loadTasks().find(t => t.id === id) || null }
function loadResults() { return readJSON(RESULTS_FILE, { results: [] }).results || [] }
function saveResults(results) { writeJSON(RESULTS_FILE, { version: 2, results }) }

function deliverablePath(taskId, arm) { return `/tmp/benchv2-${taskId}-${arm}.txt` }

// ── Contexte de requête simulé (F3, ADR-021) ─────────────────────────────────
// Les stubs `auth.*` NE SONT PLUS STATIQUES. Ils lisent le contexte de requête
// depuis des GUC de session, exactement comme le vrai Supabase :
//   - `request.jwt.claims`         → jsonb complet lu par auth.jwt()
//   - `request.jwt.claim.sub/role` → GUC legacy (ancien mécanisme Supabase)
//   - `app.workspace_id` & co.     → GUC applicatif posé par le backend
// C'est ce qui permet à une assertion de s'exécuter SOUS LE RÔLE RÉEL
// (`SET ROLE authenticated`) avec une identité simulée, au lieu d'être évaluée
// en superuser propriétaire — régime où RLS est bypassé et où tout passe.
//
// Ces stubs sont RÉAPPLIQUÉS après le livrable : un livrable qui redéfinit
// auth.jwt() en `'{}'::jsonb` (portabilité Postgres nu) ne doit pas pouvoir
// neutraliser le contexte simulé du harnais — dans le vrai Supabase, auth.jwt()
// est fourni par la plateforme et une migration ne le redéfinit pas.
const SUPABASE_AUTH_STUB_SQL = `
CREATE SCHEMA IF NOT EXISTS auth;
GRANT USAGE ON SCHEMA auth TO PUBLIC;
CREATE OR REPLACE FUNCTION auth.jwt() RETURNS jsonb LANGUAGE sql STABLE AS $fn$
  SELECT coalesce(nullif(current_setting('request.jwt.claims', true), '')::jsonb, '{}'::jsonb)
$fn$;
CREATE OR REPLACE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql STABLE AS $fn$
  SELECT nullif(coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    auth.jwt() ->> 'sub'
  ), '')::uuid
$fn$;
CREATE OR REPLACE FUNCTION auth.role() RETURNS text LANGUAGE sql STABLE AS $fn$
  SELECT nullif(coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    auth.jwt() ->> 'role'
  ), '')
$fn$;
CREATE OR REPLACE FUNCTION auth.email() RETURNS text LANGUAGE sql STABLE AS $fn$
  SELECT nullif(auth.jwt() ->> 'email', '')
$fn$;
`

// Scaffold Supabase appliqué à la DB jetable AVANT le livrable.
// Le stack du projet est Supabase : un SQL fidèle (RLS par rôle service_role/
// authenticated, auth.uid(), moddatetime, table workspace_members) échouerait
// sur un Postgres vanilla — ce n'est PAS un défaut du livrable mais du scorer.
// On recrée donc l'environnement attendu pour scorer les conventions équitablement.
//
// Fidélité des PRIVILÈGES (F3) : dans un vrai projet Supabase, les tables créées
// dans `public` sont accessibles à anon/authenticated/service_role par DEFAULT
// PRIVILEGES posées au bootstrap de la plateforme (c'est précisément pourquoi RLS
// y est obligatoire). Sans ces default privileges, tout livrable qui omet un GRANT
// explicite échouerait sous `SET ROLE authenticated` pour une raison d'ENVIRONNEMENT
// et non de qualité — on reproduit donc l'environnement réel, ce qui fait porter la
// mesure sur les policies/triggers et non sur un GRANT que Supabase pose lui-même.
//
// Harnais `bench.*` : act_as() (identité simulée) + seed() (INSERT introspecté,
// agnostique au schéma exact du livrable → ne pénalise pas une colonne NOT NULL
// additionnelle légitime, cf. ADR-021 §1 « solutions correctes stylistiquement
// différentes »).
const SUPABASE_SCAFFOLD_SQL = `
DO $$ BEGIN CREATE ROLE anon NOLOGIN;          EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE ROLE authenticated NOLOGIN; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE ROLE service_role NOLOGIN;  EXCEPTION WHEN duplicate_object THEN NULL; END $$;
-- 'postgres' : rôle superuser/propriétaire réel de toute instance Supabase (owner par
-- défaut des migrations). Absent ici → un livrable idiomatique Supabase qui référence
-- explicitement ce rôle (ex. ALTER FUNCTION ... OWNER TO postgres) échoue pour une
-- raison d'INSTRUMENT, pas de contenu — même principe déjà appliqué à anon/authenticated/
-- service_role ci-dessus et aux tables-souches FK (buildStubSql). Découvert en scorant un
-- livrable réel (trial NR3, ADR-021 T1) qui l'utilisait ; corrigé après revue adversariale
-- (G1) ayant montré l'incohérence avec le principe déjà établi (ADR-019 : ne pas pénaliser
-- le SQL fidèle au stack Supabase en scorant sur du Postgres vanilla).
DO $$ BEGIN CREATE ROLE postgres SUPERUSER;    EXCEPTION WHEN duplicate_object THEN NULL; END $$;
` + SUPABASE_AUTH_STUB_SQL + `
-- moddatetime : stub du trigger d'extension contrib (met à jour la colonne passée en TG_ARGV).
CREATE OR REPLACE FUNCTION moddatetime() RETURNS trigger LANGUAGE plpgsql AS $func$
BEGIN RETURN NEW; END $func$;
CREATE TABLE IF NOT EXISTS workspace_members (workspace_id uuid, user_id uuid);

-- Environnement de privilèges fidèle à Supabase (voir commentaire ci-dessus).
GRANT USAGE ON SCHEMA public TO anon, authenticated, service_role;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES    TO anon, authenticated, service_role;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO anon, authenticated, service_role;
GRANT ALL ON ALL TABLES IN SCHEMA public TO anon, authenticated, service_role;

-- ── Harnais d'assertion sous rôle réel ──────────────────────────────────────
CREATE SCHEMA IF NOT EXISTS bench;
GRANT USAGE ON SCHEMA bench TO PUBLIC;
CREATE SEQUENCE IF NOT EXISTS bench.seq;
GRANT USAGE, SELECT ON SEQUENCE bench.seq TO PUBLIC;

-- act_as : pose l'identité simulée sur TOUS les canaux légitimes à la fois
-- (GUC applicatif + claims JWT), afin de ne favoriser aucun mécanisme d'autz :
-- un livrable lisant current_setting('app.workspace_id') et un livrable lisant
-- auth.jwt() -> 'app_metadata' ->> 'workspace_id' sont tous deux servis.
-- NB: user_metadata reste VIDE par défaut — c'est un claim modifiable par le
-- client, jamais une source d'autorisation valide. extra_claims permet à une
-- assertion d'injecter un claim adversarial (ex: user_metadata usurpé) pour
-- tester la falsifiabilité : bench.act_as(ws, uid, 'authenticated',
--   '{"user_metadata":{"workspace_id":"<autre-ws>"}}'::jsonb).
CREATE OR REPLACE FUNCTION bench.act_as(
  ws uuid,
  uid uuid DEFAULT '00000000-0000-4000-8000-000000000001'::uuid,
  rol text DEFAULT 'authenticated',
  extra_claims jsonb DEFAULT '{}'::jsonb
) RETURNS void LANGUAGE plpgsql AS $fn$
DECLARE claims jsonb;
BEGIN
  claims := jsonb_build_object(
    'sub', uid::text, 'role', rol, 'aud', rol, 'iss', 'supabase',
    'email', 'bench@example.test',
    'workspace_id', ws::text, 'tenant_id', ws::text,
    'app_metadata', jsonb_build_object('workspace_id', ws::text, 'tenant_id', ws::text, 'role', rol),
    'user_metadata', '{}'::jsonb
  ) || coalesce(extra_claims, '{}'::jsonb);
  PERFORM set_config('app.workspace_id',        ws::text, false);
  PERFORM set_config('app.current_workspace_id', ws::text, false);
  PERFORM set_config('app.tenant_id',            ws::text, false);
  PERFORM set_config('app.current_tenant_id',    ws::text, false);
  PERFORM set_config('request.jwt.claim.sub',  uid::text, false);
  PERFORM set_config('request.jwt.claim.role', rol,       false);
  PERFORM set_config('request.jwt.claims',     claims::text, false);
  -- Pattern RLS via table de membres (workspace_members), aussi idiomatique
  -- Supabase que le claim JWT ci-dessus (évite un refresh JWT à chaque
  -- changement d'appartenance) — trouvé en G3 (ADR-021) : un livrable qui lit
  -- workspace_id IN (SELECT workspace_id FROM workspace_members WHERE
  -- user_id = auth.uid()) échouait sur une table vide, indistinguable d'une
  -- vraie policy cassée. Idempotent (pas de contrainte unique sur la table
  -- scaffold ci-dessus) : on vérifie l'absence avant d'insérer.
  IF NOT EXISTS (
    SELECT 1 FROM workspace_members WHERE workspace_id = ws AND user_id = uid
  ) THEN
    INSERT INTO workspace_members (workspace_id, user_id) VALUES (ws, uid);
  END IF;
END $fn$;

-- dummy_value : littéral SQL plausible pour une colonne NOT NULL sans défaut.
CREATE OR REPLACE FUNCTION bench.dummy_value(tid oid, tmod int DEFAULT -1)
RETURNS text LANGUAGE plpgsql AS $fn$
DECLARE tn text := format_type(tid, tmod); base text := format_type(tid, NULL);
        tt char; lbl text; maxlen int;
BEGIN
  SELECT typtype INTO tt FROM pg_type WHERE oid = tid;
  IF tt = 'e' THEN
    SELECT quote_literal(e.enumlabel) INTO lbl FROM pg_enum e
      WHERE e.enumtypid = tid ORDER BY e.enumsortorder LIMIT 1;
    RETURN coalesce(lbl || '::' || tn, 'NULL');
  END IF;
  IF base LIKE '%[]' THEN RETURN quote_literal('{}') || '::' || tn; END IF;
  IF base = 'uuid' THEN RETURN 'gen_random_uuid()'; END IF;
  IF base IN ('smallint','integer','bigint') THEN RETURN nextval('bench.seq')::text; END IF;
  IF base LIKE 'numeric%' OR base IN ('real','double precision','money') THEN RETURN '1'; END IF;
  IF base = 'boolean' THEN RETURN 'false'; END IF;
  IF base LIKE 'timestamp%' THEN RETURN 'now()'; END IF;
  IF base = 'date' THEN RETURN 'current_date'; END IF;
  IF base LIKE 'time%' THEN RETURN 'now()::' || tn; END IF;
  IF base = 'interval' THEN RETURN quote_literal('0') || '::interval'; END IF;
  IF base IN ('json','jsonb') THEN RETURN quote_literal('{}') || '::' || base; END IF;
  IF base IN ('inet','cidr') THEN RETURN quote_literal('127.0.0.1') || '::' || base; END IF;
  IF base IN ('text','citext','name','character varying','character') THEN
    maxlen := CASE WHEN tmod > 4 THEN tmod - 4 ELSE 40 END;
    RETURN quote_literal(left('bench-' || nextval('bench.seq')::text, maxlen)) || '::' || tn;
  END IF;
  RETURN 'NULL';
END $fn$;

-- seed : INSERT introspecté dans la table cible. SECURITY INVOKER → soumis au RLS
-- du rôle courant (c'est le point : la mutation doit passer sous authenticated).
-- overrides fixe les colonnes signifiantes (workspace_id, email, document_id…),
-- les autres NOT NULL sans défaut sont remplies automatiquement.
CREATE OR REPLACE FUNCTION bench.seed(tbl text, overrides jsonb DEFAULT '{}'::jsonb)
RETURNS uuid LANGUAGE plpgsql AS $fn$
DECLARE rel regclass := tbl::regclass; cols text := ''; vals text := '';
        r record; v text; ret uuid; has_id boolean := false;
BEGIN
  FOR r IN
    SELECT a.attname::text AS name, a.atttypid AS tid, a.atttypmod AS tmod,
           a.attnotnull AS notnull, (d.adbin IS NOT NULL) AS has_default
    FROM pg_attribute a
    LEFT JOIN pg_attrdef d ON d.adrelid = a.attrelid AND d.adnum = a.attnum
    WHERE a.attrelid = rel AND a.attnum > 0 AND NOT a.attisdropped
      AND a.attgenerated = '' AND a.attidentity = ''
    ORDER BY a.attnum
  LOOP
    IF r.name = 'id' THEN has_id := true; END IF;
    IF overrides ? r.name THEN
      v := quote_literal(overrides ->> r.name) || '::' || format_type(r.tid, r.tmod);
    ELSIF r.has_default OR NOT r.notnull THEN
      CONTINUE;
    ELSE
      v := bench.dummy_value(r.tid, r.tmod);
    END IF;
    cols := cols || CASE WHEN cols = '' THEN '' ELSE ', ' END || quote_ident(r.name);
    vals := vals || CASE WHEN vals = '' THEN '' ELSE ', ' END || v;
  END LOOP;
  IF cols = '' THEN
    EXECUTE format('INSERT INTO %s DEFAULT VALUES RETURNING id', rel) INTO ret;
    RETURN ret;
  END IF;
  IF has_id THEN
    EXECUTE format('INSERT INTO %s (%s) VALUES (%s) RETURNING id', rel, cols, vals) INTO ret;
  ELSE
    EXECUTE format('INSERT INTO %s (%s) VALUES (%s)', rel, cols, vals);
  END IF;
  RETURN ret;
END $fn$;
`

// ── Identités déterministes des assertions (reproductibilité) ────────────────
// Placeholders substitués dans le SQL des assertions ET dans le préambule d'auth.
// Fixes (pas de Math.random) → un même livrable produit toujours le même score.
const BENCH_IDS = {
  $WS1: '11111111-1111-4111-8111-111111111111',
  $WS2: '22222222-2222-4222-8222-222222222222',
  $U1:  'aaaaaaa1-1111-4111-8111-aaaaaaaaaaa1',
  $U2:  'bbbbbbb2-2222-4222-8222-bbbbbbbbbbb2',
  // Identifiants de LIGNE déterministes : permettent de scoper une assertion sur
  // une ligne précise même après sa suppression (audit d'un DELETE).
  $C1:  'ccccccc1-1111-4111-8111-ccccccccccc1',
  $C2:  'ccccccc2-2222-4222-8222-ccccccccccc2',
}

/** Substitue les placeholders d'identité ($WS1, $WS2, $U1, $U2). PURE. */
function resolveBenchPlaceholders(sql) {
  let out = String(sql ?? '')
  for (const k of Object.keys(BENCH_IDS).sort((a, b) => b.length - a.length)) {
    out = out.split(k).join(BENCH_IDS[k])
  }
  return out
}

// Rôles sous lesquels une assertion peut être exécutée. `owner` (défaut, champ
// `role` absent) = le propriétaire/superuser — régime historique qui BYPASS RLS.
const ASSERTION_ROLES = new Set(['authenticated', 'anon', 'service_role', 'owner'])

/**
 * Construit le préambule SQL qui place l'assertion sous son rôle réel avec une
 * identité simulée. PURE (peut contenir des placeholders, résolus ensuite).
 *
 * Champs d'assertion reconnus :
 *   role   : 'authenticated' | 'anon' | 'service_role' | 'owner'  (défaut: owner)
 *   as     : workspace de l'identité simulée (défaut '$WS1')
 *   userId : sujet JWT simulé (défaut '$U1')
 *   claims : objet de claims additionnels fusionnés (test adversarial de claim)
 *
 * Retourne '' pour le régime owner (aucun changement de rôle → compatibilité
 * totale avec les assertions structurelles existantes).
 */
function buildAuthPreamble(assertion) {
  const a = assertion || {}
  const role = a.role || 'owner'
  if (!ASSERTION_ROLES.has(role)) {
    throw new Error(`rôle d'assertion invalide: ${role}`)
  }
  if (role === 'owner') return ''
  // `as`/`userId` sont interpolés dans du SQL : on n'accepte QUE un placeholder
  // connu ou un uuid littéral. Une coquille échoue ici, jamais silencieusement
  // dans psql (et aucune valeur de tâche ne peut détourner le préambule).
  const ident = (v, field) => {
    const s = String(v)
    const ok = Object.prototype.hasOwnProperty.call(BENCH_IDS, s)
      || /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(s)
    if (!ok) throw new Error(`${field} d'assertion invalide (placeholder connu ou uuid attendu): ${s}`)
    return s
  }
  const ws = ident(a.as || '$WS1', 'as')
  const uid = ident(a.userId || '$U1', 'userId')
  const extra = JSON.stringify(a.claims && typeof a.claims === 'object' ? a.claims : {}).replace(/'/g, "''")
  return `DO $bench$ BEGIN PERFORM bench.act_as('${ws}'::uuid, '${uid}'::uuid, '${role}', '${extra}'::jsonb); END $bench$;\n`
    + `SET ROLE ${role};\n`
}

/** SQL final d'une assertion : préambule d'auth + SQL, placeholders résolus. PURE. */
function buildAssertionSql(assertion) {
  return resolveBenchPlaceholders(buildAuthPreamble(assertion) + String((assertion && assertion.sql) || ''))
}

// ── Génération du plan (PURE) ────────────────────────────────────────────────
/**
 * Construit le plan ordonné des runs pour un ensemble de tâches × bras × catégorie.
 * PURE : prend les tâches en argument (testable sans IO).
 *   tasks  : [{ id, profile, categories, ... }]
 *   opts   : { categories?:string[], taskIds?:string[], arms?:string[] }
 * Retourne [{ taskId, category, arm, agentType, model, injectConventions, decompose, outputFile }]
 */
function buildPlan(tasks, opts = {}) {
  const arms = (opts.arms && opts.arms.length) ? opts.arms.filter(a => ARMS.includes(a)) : ARMS
  const wantCats = opts.categories && opts.categories.length ? new Set(opts.categories) : null
  const wantTasks = opts.taskIds && opts.taskIds.length ? new Set(opts.taskIds) : null

  const plan = []
  for (const t of tasks) {
    if (wantTasks && !wantTasks.has(t.id)) continue
    const cats = (t.categories || []).filter(c => !wantCats || wantCats.has(c))
    for (const category of cats) {
      for (const arm of arms) {
        plan.push(planRun(t, category, arm))
      }
    }
  }
  return plan
}

/** Construit une ligne de plan pour (tâche, catégorie, bras). PURE. */
function planRun(task, category, arm) {
  const meta = ARM_META[arm]
  // Bras A/B : agent générique. Bras C/D : agent dérivé du profil.
  const specialized = arm === 'C' || arm === 'D'
  const agentType = specialized
    ? (PROFILE_AGENT[task.profile] || PROFILE_AGENT[task.stack] || 'general-purpose')
    : 'general-purpose'
  // Bras A/B : sonnet constant (baseline). Bras C/D : modèle routé par tier.
  const routed = specialized ? routedTier(task.prompt) : { tier: 2, model: DEFAULT_MODEL, codemodBypassed: false }
  return {
    taskId: task.id,
    category,
    arm,
    armLabel: meta.label,
    agentType,
    model: routed.model,
    tier: routed.tier,
    // B5 — tâche classée tier 0 (codemod, $0) mais exécutée par un agent payant :
    // rendu explicite pour que le coût du bras reste attribuable.
    codemodBypassed: routed.codemodBypassed,
    injectConventions: meta.injectConventions,
    decompose: meta.decompose,
    outputFile: deliverablePath(task.id, arm),
  }
}

// ── Scorer SQL « correction-reelle » ─────────────────────────────────────────

/**
 * Extrait les blocs ```sql d'un texte livrable. PURE.
 * - Reconnaît ```sql … ``` (insensible à la casse, langage optionnel == sql).
 * - Ignore les blocs d'autres langages (```js, ```python, ```).
 * Retourne string[] (chaque bloc, trimé).
 */
function extractSqlBlocks(text) {
  if (!text || typeof text !== 'string') return []
  const blocks = []
  const re = /```([a-zA-Z0-9_-]*)\n([\s\S]*?)```/g
  let m
  while ((m = re.exec(text)) !== null) {
    const lang = (m[1] || '').toLowerCase()
    if (lang === 'sql' || lang === 'postgres' || lang === 'postgresql' || lang === 'psql') {
      const body = m[2].trim()
      if (body) blocks.push(body)
    }
  }
  return blocks
}

/** Clé canonique d'une table : schéma absent ⇒ `public` (= search_path par défaut). PURE. */
function qualifiedTableKey(schema, table) {
  const s = (schema ? String(schema) : 'public').toLowerCase()
  return `${s}.${String(table).toLowerCase()}`
}

/**
 * Extrait les tables référencées par une clause REFERENCES dans le SQL. PURE.
 * Sert à pré-créer des tables-souches afin qu'une FK vers une table externe
 * (workspaces, users…) ne fasse pas échouer l'apply dans une DB jetable vide —
 * on mesure les conventions du livrable, pas son auto-suffisance.
 * Exclut les tables créées par le livrable lui-même (comparaison sur la table
 * canonique : schéma implicite ⇒ `public`, donc `public.customers` créé ≡
 * `customers` référencé et inversement).
 * Retourne string[] (uniques) :
 *   - `"users"`      pour une référence non qualifiée ou qualifiée `public.` ;
 *   - `"auth.users"` pour une référence portant un schéma EXPLICITE ≠ public
 *     (convention Supabase `auth.users`) — le stub doit alors être qualifié,
 *     sinon il atterrit dans `public` et la FK échoue.
 */
function extractReferencedTables(sql) {
  if (!sql || typeof sql !== 'string') return []
  const created = new Set()
  const reCreate = /create\s+table\s+(?:if\s+not\s+exists\s+)?(?:["'`]?([a-z_][a-z0-9_]*)["'`]?\s*\.\s*)?["'`]?([a-z_][a-z0-9_]*)["'`]?/gi
  let cm
  while ((cm = reCreate.exec(sql)) !== null) created.add(qualifiedTableKey(cm[1], cm[2]))
  const refs = new Map() // clé canonique → représentation à stubber
  const reRef = /references\s+(?:["'`]?([a-z_][a-z0-9_]*)["'`]?\s*\.\s*)?["'`]?([a-z_][a-z0-9_]*)["'`]?/gi
  let rm
  while ((rm = reRef.exec(sql)) !== null) {
    const schema = rm[1] ? rm[1].toLowerCase() : null
    const table = rm[2].toLowerCase()
    const key = qualifiedTableKey(schema, table)
    if (created.has(key)) continue
    // Schéma explicite ≠ public → on conserve la qualification pour le stub.
    refs.set(key, schema && schema !== 'public' ? `${schema}.${table}` : table)
  }
  return [...refs.values()]
}

/**
 * Génère le SQL des tables-souches pour une liste d'entrées issues de
 * extractReferencedTables. PURE.
 * Une entrée qualifiée `<schema>.<table>` (schéma ≠ public) produit d'abord un
 * `CREATE SCHEMA IF NOT EXISTS <schema>;` puis un CREATE TABLE qualifié ; une
 * entrée nue produit le CREATE TABLE non qualifié (schéma par défaut).
 *
 * Chaque stub est aussi PEUPLÉ avec les identités déterministes des assertions
 * (BENCH_IDS : $WS1/$WS2/$U1/$U2) — sinon le stub neutralise l'`apply` (la table
 * existe) mais casse silencieusement toute assertion `role:'authenticated'` qui
 * INSERT/UPDATE sous une de ces identités : la FK vers la table-souche (vide)
 * échoue au moment de l'assertion, pas de l'apply, ce qui ressemble à un défaut
 * du livrable alors que c'est un trou de l'instrument. Sans risque de collision :
 * ids fixes, table jetable détruite en fin de scoring.
 */
function buildStubSql(tables) {
  const list = (tables || []).map(t => String(t)).filter(Boolean)
  const schemas = []
  for (const t of list) {
    const m = /^([a-z_][a-z0-9_]*)\.[a-z_][a-z0-9_]*$/i.exec(t)
    if (m) {
      const s = m[1].toLowerCase()
      if (s !== 'public' && !schemas.includes(s)) schemas.push(s)
    }
  }
  const lines = schemas.map(s => `CREATE SCHEMA IF NOT EXISTS ${s};`)
  const seedIds = Object.values(BENCH_IDS)
  for (const t of list) {
    lines.push(`CREATE TABLE IF NOT EXISTS ${t} (id uuid PRIMARY KEY DEFAULT gen_random_uuid());`)
    for (const id of seedIds) {
      lines.push(`INSERT INTO ${t} (id) VALUES ('${id}') ON CONFLICT (id) DO NOTHING;`)
    }
  }
  return lines.join('\n')
}

// Tags de complétion psql émis sur stdout AVANT le résultat de données. Quand une
// assertion comportementale exécute un bloc `DO $$ ... $$;` suivi d'un `SELECT`,
// psql sort `DO` (puis éventuellement `INSERT 0 1`, etc.) sur des lignes propres,
// AVANT la cellule scalaire du SELECT final. Sans filtrage, parsePsqlScalar
// renverrait `DO` au lieu du scalaire attendu → faux négatif sur toute assertion
// à effet de bord. On filtre ces tags pour isoler la donnée. Les valeurs de données
// scorées (1, uuid, NO, t, bigint, YES, comptes…) ne matchent JAMAIS ces motifs.
const PSQL_TAG_RE = /^(DO|BEGIN|COMMIT|ROLLBACK|SET|RESET|SAVEPOINT|RELEASE|TRUNCATE TABLE|LISTEN|UNLISTEN|NOTIFY)$/i
const PSQL_TAG_PREFIX_RE = /^(INSERT|UPDATE|DELETE|SELECT|COPY|MERGE|CREATE|ALTER|DROP|GRANT|REVOKE|COMMENT|MOVE|FETCH|DECLARE|CLOSE)\b/i

/**
 * Parse la valeur scalaire renvoyée par `psql -t -A` (tuples only, unaligned).
 * Retourne la 1re cellule de DONNÉES non vide trimée, ou '' si aucune. PURE.
 * Ignore les tags de complétion de commande (DO, INSERT 0 1, …) qui précèdent
 * parfois le résultat dans un batch multi-instructions (DO $$..$$; SELECT …).
 */
function parsePsqlScalar(stdout) {
  if (!stdout) return ''
  const lines = String(stdout).split('\n').map(l => l.trim()).filter(l => l.length > 0)
  const data = lines.filter(l => !PSQL_TAG_RE.test(l) && !PSQL_TAG_PREFIX_RE.test(l))
  return data.length ? data[0] : (lines.length ? lines[0] : '')
}

/**
 * Évalue une assertion à partir de la valeur scalaire observée. PURE.
 * OK si la valeur observée (trimée, lowercase) == expect (trimée, lowercase).
 * Retourne { name, ok, expect, got }.
 */
function evalAssertion(assertion, gotScalar) {
  const expect = String(assertion.expect ?? '').trim().toLowerCase()
  const got = String(gotScalar ?? '').trim().toLowerCase()
  return { name: assertion.name, ok: got === expect, expect: assertion.expect, got: gotScalar }
}

/**
 * Calcule le score (% assertions OK) à partir des résultats d'assertions. PURE.
 * Retourne { score:0..100, passed, total }.
 */
function computeAssertionScore(results) {
  const total = results.length
  if (!total) return { score: 0, passed: 0, total: 0 }
  const passed = results.filter(r => r.ok).length
  return { score: Math.round((passed / total) * 100), passed, total }
}

/** Détecte si Postgres est joignable (psql + connexion à `postgres`). */
function postgresAvailable() {
  try {
    const r = spawnSync('psql', ['postgres', '-tAc', 'SELECT 1'], { encoding: 'utf8', timeout: 8000 })
    return r.status === 0 && parsePsqlScalar(r.stdout) === '1'
  } catch { return false }
}

/**
 * Scorer SQL : applique le SQL livrable sur une DB jetable et exécute les assertions.
 * IMPUR (psql). Le suffixe aléatoire est passé en argument (testabilité : pas de
 * Math.random ici). Retourne { score:0..100|null, detail }.
 */
function scoreSqlDeliverable(task, deliverableText, randSuffix) {
  if (!postgresAvailable()) {
    return { score: null, detail: 'postgres-indisponible' }
  }
  const blocks = extractSqlBlocks(deliverableText)
  if (!blocks.length) {
    return { score: 0, detail: 'aucun bloc ```sql dans le livrable' }
  }
  const assertions = (task.assets && task.assets.assertions) || []
  if (!assertions.length) {
    return { score: null, detail: 'aucune assertion définie pour la tâche' }
  }

  const safeBase = String(task.id).toLowerCase().replace(/[^a-z0-9_]/g, '_').slice(0, 30)
  const safeSuffix = String(randSuffix).toLowerCase().replace(/[^a-z0-9_]/g, '').slice(0, 12) || 'x'
  const dbName = `benchv2_${safeBase}_${safeSuffix}`.slice(0, 60)

  const sqlFile = join(os.tmpdir(), `benchv2-${dbName}.sql`)
  let applyErr = null
  let scaffoldErr = null
  try {
    // 1) Crée la DB jetable.
    const created = spawnSync('psql', ['postgres', '-tAc', `CREATE DATABASE ${dbName}`], { encoding: 'utf8', timeout: 15000 })
    if (created.status !== 0) {
      return { score: null, detail: `création DB échouée: ${(created.stderr || '').trim().slice(0, 200)}` }
    }
    try {
      // 1a) Scaffold Supabase. Best-effort MAIS jamais silencieux : le scaffold
      //     porte maintenant le harnais d'auth (bench.act_as/seed, stubs auth.*) —
      //     s'il échoue, toutes les assertions sous rôle réel échoueraient pour une
      //     raison d'INSTRUMENT. On expose donc l'erreur dans le détail du score.
      const scaffolded = spawnSync('psql', ['-v', 'ON_ERROR_STOP=1', '-d', dbName, '-c', SUPABASE_SCAFFOLD_SQL], { encoding: 'utf8', timeout: 20000 })
      if (scaffolded.status !== 0) scaffoldErr = (scaffolded.stderr || '').trim().slice(0, 300)
      // 1b) Pré-crée des tables-souches pour toute FK externe (sinon apply échoue
      //     dans la DB vide). On neutralise l'auto-suffisance pour isoler les conventions.
      const deliverableSql = blocks.join('\n;\n')
      const stubTables = extractReferencedTables(deliverableSql)
      if (stubTables.length) {
        const stubSql = buildStubSql(stubTables)
        spawnSync('psql', ['-d', dbName, '-c', stubSql], { encoding: 'utf8', timeout: 15000 })
      }
      // 2) Applique le SQL du livrable.
      writeFileSync(sqlFile, deliverableSql + '\n')
      const applied = spawnSync('psql', ['-v', 'ON_ERROR_STOP=1', '-d', dbName, '-f', sqlFile], { encoding: 'utf8', timeout: 30000 })
      if (applied.status !== 0) {
        applyErr = (applied.stderr || '').trim().slice(0, 300)
      }

      // 2b) Réapplique les stubs auth.* : un livrable qui redéfinit auth.jwt() en
      //     `'{}'::jsonb` (portabilité Postgres nu) neutraliserait sinon le contexte
      //     de requête simulé et ferait échouer ses PROPRES policies pour une raison
      //     d'instrument. Dans le vrai Supabase, auth.jwt() est fourni par la
      //     plateforme et une migration ne le redéfinit pas.
      spawnSync('psql', ['-d', dbName, '-c', SUPABASE_AUTH_STUB_SQL], { encoding: 'utf8', timeout: 15000 })

      // 3) Exécute les assertions (même si le SQL a partiellement échoué, on mesure).
      //    Chaque assertion peut déclarer `role: 'authenticated'` → elle s'exécute
      //    sous le rôle applicatif réel avec une identité simulée (cf. buildAuthPreamble),
      //    et non plus en propriétaire/superuser qui BYPASS le RLS.
      const results = []
      for (const a of assertions) {
        let sql
        try { sql = buildAssertionSql(a) } catch (e) {
          results.push(evalAssertion(a, `__error__:${e.message}`)); continue
        }
        const r = spawnSync('psql', ['-tA', '-d', dbName, '-c', sql], { encoding: 'utf8', timeout: 20000 })
        const got = r.status === 0 ? parsePsqlScalar(r.stdout) : `__error__:${(r.stderr || '').trim().slice(0, 120)}`
        results.push({ ...evalAssertion(a, got), role: a.role || 'owner' })
      }
      const { score, passed, total } = computeAssertionScore(results)
      const detail = {
        passed, total,
        applyError: applyErr || null,
        scaffoldError: scaffoldErr || null,
        assertions: results.map(r => ({ name: r.name, role: r.role || 'owner', ok: r.ok, expect: r.expect, got: r.got })),
      }
      return { score, detail }
    } finally {
      // 4) DROP DATABASE toujours.
      spawnSync('psql', ['postgres', '-tAc', `DROP DATABASE IF EXISTS ${dbName}`], { encoding: 'utf8', timeout: 15000 })
    }
  } catch (e) {
    return { score: null, detail: `exception scorer SQL: ${e.message}` }
  } finally {
    try { if (existsSync(sqlFile)) require('fs').unlinkSync(sqlFile) } catch {}
  }
}

// ── Scorer « precision-recuperation » ────────────────────────────────────────

/** Normalise une clé (lowercase, sans accents, espaces compactés). PURE. */
function normKey(s) {
  return String(s || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9 ]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
}

/**
 * Précision / rappel / F1 d'une récupération. PURE.
 *   retrievedKeys     : clés effectivement récupérées
 *   groundTruthKeys   : clés attendues (devraient être récupérées)
 *   allDistractorKeys : clés qui NE devraient PAS être récupérées (bruit)
 * Une clé récupérée compte comme :
 *   - vrai positif  si elle matche une clé ground-truth,
 *   - faux positif  sinon (qu'elle soit un distracteur connu ou hors-liste).
 * allDistractorKeys sert au diagnostic (non requis pour la formule mais conservé).
 * Retourne { precision, recall, f1, tp, fp, fn }.
 */
function recallPrecision(retrievedKeys, groundTruthKeys, allDistractorKeys = []) {
  const retrieved = [...new Set((retrievedKeys || []).map(normKey).filter(Boolean))]
  const truth = [...new Set((groundTruthKeys || []).map(normKey).filter(Boolean))]
  const truthSet = new Set(truth)

  // Un élément retrouvé matche la vérité si l'une est sous-chaîne de l'autre
  // (tolérance aux libellés ; ex: "uuid" ⊂ "uuid pk timestamps").
  const matchesTruth = (r) => truth.some(g => g === r || g.includes(r) || r.includes(g))
  const truthCovered = (g) => retrieved.some(r => r === g || r.includes(g) || g.includes(r))

  let tp = 0, fp = 0
  for (const r of retrieved) {
    if (matchesTruth(r)) tp++; else fp++
  }
  let fn = 0
  for (const g of truth) {
    if (!truthCovered(g)) fn++
  }

  const precision = (tp + fp) === 0 ? 0 : tp / (tp + fp)
  const recall = (tp + fn) === 0 ? 0 : tp / (tp + fn)
  const f1 = (precision + recall) === 0 ? 0 : (2 * precision * recall) / (precision + recall)
  return {
    precision: round3(precision),
    recall: round3(recall),
    f1: round3(f1),
    tp, fp, fn,
  }
}
function round3(n) { return Math.round(n * 1000) / 1000 }
/** Arrondi générique à N décimales. PURE. Utilisé par la télémétrie d'efficience (G6). */
function roundN(n, decimals) { const f = Math.pow(10, decimals); return Math.round(n * f) / f }

/**
 * Extrait les clés/conventions du bloc retourné par `ada bank recall`. PURE.
 * Format observé :
 *   [CONNAISSANCE PROJET — ReasoningBank]
 *   Conventions:
 *   - <texte convention 1>
 *   - <texte convention 2>
 * Retourne string[] (une entrée par bullet, texte trimé).
 */
function parseRecallConventions(recallOutput) {
  if (!recallOutput) return []
  const out = []
  for (const raw of String(recallOutput).split('\n')) {
    const line = raw.trim()
    const m = line.match(/^-\s+(.*\S)\s*$/)
    if (m) out.push(m[1].trim())
  }
  return out
}

/** Scorer recall : appelle bank.recall, calcule F1 vs groundTruth. IMPUR. */
function scoreRecallDeliverable(task) {
  const truth = (task.assets && task.assets.groundTruthConventions) || []
  if (!truth.length) return { score: null, detail: 'aucune groundTruthConventions définie' }

  const r = spawnSync('node', [join(COORD_DIR, 'bank.js'), 'recall', task.prompt], { encoding: 'utf8', timeout: 30000 })
  if (r.status !== 0 && !r.stdout) {
    return { score: null, detail: `bank recall indisponible: ${(r.stderr || '').trim().slice(0, 160)}` }
  }
  const conventions = parseRecallConventions(r.stdout)
  // Chaque convention récupérée est éclatée en clés candidates (le texte entier
  // sert de clé ; le matching sous-chaîne de recallPrecision fait le reste).
  const retrievedKeys = conventions
  const m = recallPrecision(retrievedKeys, truth, [])
  return {
    score: Math.round(m.f1 * 100),
    detail: { ...m, retrieved: conventions, truth },
  }
}

// ── Dispatch scorer par catégorie ────────────────────────────────────────────
/**
 * Lance le scorer de la catégorie. Pour les catégories 'planned', renvoie un
 * skip EXPLICITE (jamais un score silencieux).
 * randSuffix : suffixe DB (CLI seulement) pour le scorer SQL.
 */
function runScorer(category, task, deliverableText, randSuffix) {
  const reg = CATEGORY_REGISTRY[category]
  if (!reg) return { score: null, detail: `catégorie inconnue: ${category}` }
  if (reg.status === 'planned') {
    return { score: null, detail: 'catégorie planifiée, non encore câblée' }
  }
  if (reg.scorer === 'sql') return scoreSqlDeliverable(task, deliverableText, randSuffix)
  if (reg.scorer === 'recall') return scoreRecallDeliverable(task)
  // 'ts' : chargé PARESSEUSEMENT (module séparé bench-v2-ts.js, ADR-021 Action 3)
  // — évite tout require circulaire (bench-v2-ts.js ne requiert jamais ce fichier).
  if (reg.scorer === 'ts') return require('./bench-v2-ts.js').scoreTsDeliverable(task, deliverableText, randSuffix)
  // 'docker' : chargé PARESSEUSEMENT (module séparé bench-v2-infra.js, ADR-021
  // Action 3, finding G8) — même raison : bench-v2-infra.js ne requiert jamais
  // ce fichier, aucune circularité.
  if (reg.scorer === 'docker') return require('./bench-v2-infra.js').scoreDockerDeliverable(task, deliverableText, randSuffix)
  return { score: null, detail: `scorer non implémenté: ${reg.scorer}` }
}

// ── Report : matrice catégorie × bras + deltas (PURE) ─────────────────────────

// Deltas d'ablation historiques (alias stables dans la sortie : dBA/dCB/dDC).
const LEGACY_DELTAS = [['B', 'A', 'dBA'], ['C', 'B', 'dCB'], ['D', 'C', 'dDC']]

/**
 * Périmètre des bras d'un rapport. PURE.
 * Sans `requested`, prend TOUTES les étiquettes présentes dans les résultats
 * (bras d'ablation A-D d'abord dans l'ordre canonique, puis les autres triées) —
 * plus aucun bras n'est écarté en silence. Avec `requested`, le périmètre est
 * exactement celui demandé (filtrage EXPLICITE, pas silencieux).
 */
function resolveArms(results, requested) {
  const norm = (a) => String(a ?? '').trim().toUpperCase()
  if (requested && requested.length) return [...new Set(requested.map(norm).filter(Boolean))]
  const present = [...new Set((results || []).map(r => norm(r && r.arm)).filter(Boolean))]
  const legacy = ARMS.filter(a => present.includes(a))
  const extra = present.filter(a => !ARMS.includes(a)).sort()
  return [...legacy, ...extra]
}

/**
 * Paires de deltas calculées par défaut pour un périmètre de bras. PURE.
 * - Bras d'ablation : les paires HISTORIQUES B−A, C−B, D−C (jamais des paires
 *   inventées comme C−A, qui ne correspondent à aucune hypothèse du protocole).
 * - Autres étiquettes (NATIVE, PIPELINE…) : la paire n'est déduite que si elles
 *   sont EXACTEMENT deux (appariement non ambigu, ex. PIPELINE−NATIVE). À trois ou
 *   plus (NATIVE, NATIVE-T2, NATIVE-T3, PIPELINE…), aucune paire n'est devinée :
 *   il faut la demander (`opts.deltaPairs` / `report --arms`). Deviner produirait
 *   des comparaisons dénuées de sens (« NATIVE-T3 − NATIVE-T2 ») présentées
 *   comme des mesures.
 * - Une comparaison croisée entre familles (ex. NATIVE−D) est toujours explicite.
 * Retourne [[x, y], …] où le delta vaut x − y.
 */
function defaultDeltaPairs(arms) {
  const pairs = LEGACY_DELTAS.filter(([x, y]) => arms.includes(x) && arms.includes(y)).map(([x, y]) => [x, y])
  const extra = arms.filter(a => !ARMS.includes(a))
  if (extra.length === 2) pairs.push([extra[1], extra[0]])
  return pairs
}

/**
 * Vérifie qu'un delta entre deux bras est LÉGITIME. PURE. Lève une erreur claire
 * (jamais un résultat silencieusement partiel — c'est la corruption qu'on corrige) si :
 *   1. une cellule (tâche, bras) porte plusieurs scores DIFFÉRENTS → mesure ambiguë
 *      (typiquement des re-scores empilés avant/après un fix de scorer) ;
 *   2. le plan est DÉSÉQUILIBRÉ entre les deux bras : tâches différentes, ou nombre
 *      de runs différent pour une même tâche → la moyenne comparerait des populations
 *      distinctes et le delta serait un artefact d'échantillonnage ;
 *   3. les entrées comparées portent des `scorerSha` DIFFÉRENTS pour une même tâche
 *      → on comparerait deux instruments, pas deux bras.
 */
function assertComparableArms(cat, x, y, cells) {
  const cx = cells[x] || {}
  const cy = cells[y] || {}
  const where = `[${cat}] delta ${x}−${y} refusé`
  for (const [arm, cell] of [[x, cx], [y, cy]]) {
    for (const [taskId, c] of Object.entries(cell)) {
      const distinct = [...new Set(c.scores)]
      if (distinct.length > 1) {
        throw new Error(`${where} : la cellule (${taskId}, ${arm}) porte ${distinct.length} scores différents (${distinct.join('/')}) — mesure ambiguë. Dédoublonne results-v2.json (garde le run le plus récent) ou restreins le rapport à un runId.`)
      }
    }
  }
  const tx = Object.keys(cx).sort()
  const ty = Object.keys(cy).sort()
  const onlyX = tx.filter(t => !ty.includes(t))
  const onlyY = ty.filter(t => !tx.includes(t))
  if (onlyX.length || onlyY.length) {
    throw new Error(`${where} : plan déséquilibré — tâches seulement en ${x}: [${onlyX.join(', ') || '∅'}], seulement en ${y}: [${onlyY.join(', ') || '∅'}].`)
  }
  for (const t of tx) {
    if (cx[t].scores.length !== cy[t].scores.length) {
      throw new Error(`${where} : plan déséquilibré — la tâche ${t} a ${cx[t].scores.length} run(s) en ${x} contre ${cy[t].scores.length} en ${y}.`)
    }
  }
  for (const t of tx) {
    const shas = [...new Set([...cx[t].shas, ...cy[t].shas])]
    if (shas.length > 1) {
      throw new Error(`${where} : scorerSha mélangés pour la tâche ${t} (${shas.join(' vs ')}) — deux instruments différents, pas deux bras. Re-score les deux bras avec le même scorer.`)
    }
  }
}

/**
 * Agrège les résultats en matrice catégorie × bras + deltas. PURE.
 *
 * Signatures acceptées (rétro-compatibles) :
 *   buildReport(results)
 *   buildReport(results, 'ma-categorie')
 *   buildReport(results, { category?, arms?, deltaPairs?, deltas? })
 *     arms       : périmètre explicite des bras (défaut : tous ceux présents)
 *     deltaPairs : [[x, y], …] paires de deltas à calculer (défaut : cf. defaultDeltaPairs)
 *     deltas     : false → n'en calcule aucun (inspection des moyennes sur un jeu
 *                  connu comme non comparable, sans faire échouer le rapport)
 *
 * Sortie : { [category]: { arms:{[arm]:moy|null}, n:{[arm]:nbTâches}, runs:{[arm]:nbRuns},
 *                          deltas:{'X-Y':v|null}, A,B,C,D, dBA,dCB,dDC } }
 * Les clés A/B/C/D et dBA/dCB/dDC sont conservées comme ALIAS des bras d'ablation.
 * Un delta vaut null si l'une des bornes n'a aucune donnée ; s'il a des données
 * des deux côtés mais que la comparaison est illégitime → ERREUR (voir assertComparableArms).
 */
function buildReport(results, filterCategoryOrOpts, maybeOpts) {
  const opts = (filterCategoryOrOpts && typeof filterCategoryOrOpts === 'object')
    ? filterCategoryOrOpts
    : (maybeOpts || {})
  const filterCategory = typeof filterCategoryOrOpts === 'string'
    ? filterCategoryOrOpts
    : (opts.category || null)

  // superseded:true (ADR-023, « Décisions irréversibles » #2) : une entrée
  // marquée obsolète après coup (artefact de harnais, scorer corrigé, etc.)
  // n'est JAMAIS supprimée de results-v2.json — mais elle ne doit pas non
  // plus polluer une moyenne/rapport. On l'exclut ici, au moment de la
  // lecture, jamais à l'écriture.
  const rows = (results || []).filter(r => !r.superseded).filter(r => !filterCategory || r.category === filterCategory)
  const arms = resolveArms(rows, opts.arms)
  const armSet = new Set(arms)
  const withDeltas = opts.deltas !== false

  // catégorie → bras → tâche → { scores:[], shas:Set }
  const byCat = {}
  for (const r of rows) {
    const arm = String(r && r.arm ? r.arm : '').trim().toUpperCase()
    if (!armSet.has(arm)) continue           // hors périmètre EXPLICITEMENT demandé
    if (typeof r.score !== 'number') continue // skip explicite (score null) : ignoré de la moyenne
    const cells = (byCat[r.category] ||= {})
    const cell = ((cells[arm] ||= {})[r.taskId] ||= { scores: [], shas: new Set() })
    cell.scores.push(r.score)
    cell.shas.add(r.scorerSha || 'unknown')
  }

  // Télémétrie d'efficience (G6, ADR-021 #9 / ADR-023 étape 1) — agrégée
  // INDÉPENDAMMENT du score : un trial peut être skip (score null) et avoir
  // quand même consommé des tokens/$ réels (ex. une revue déléguée qui échoue),
  // on ne veut pas perdre cette mesure. Champs absents (results-v2.json
  // pré-G6, ou run sans flags de télémétrie) → simplement ignorés, jamais
  // traités comme 0 (round1/`scores` ci-dessus applique la même règle au score).
  const telByCat = {}
  for (const r of rows) {
    const arm = String(r && r.arm ? r.arm : '').trim().toUpperCase()
    if (!armSet.has(arm)) continue
    const cells = (telByCat[r.category] ||= {})
    const cell = (cells[arm] ||= { costs: [], tokensTotal: [], wallClocks: [], agentCalls: [] })
    if (typeof r.costUsd === 'number' && Number.isFinite(r.costUsd)) cell.costs.push(r.costUsd)
    if (r.tokens && typeof r.tokens === 'object') {
      const parts = ['input', 'output', 'cacheRead', 'cacheWrite']
        .map(k => r.tokens[k])
        .filter(v => typeof v === 'number' && Number.isFinite(v))
      // Au moins un sous-champ mesuré → on somme ce qui est disponible (un total
      // partiel reste informatif ; ne rien pousser si les 4 sont absents/null).
      if (parts.length) cell.tokensTotal.push(parts.reduce((a, b) => a + b, 0))
    }
    if (typeof r.wallClockMs === 'number' && Number.isFinite(r.wallClockMs)) cell.wallClocks.push(r.wallClockMs)
    if (typeof r.agentCalls === 'number' && Number.isFinite(r.agentCalls)) cell.agentCalls.push(r.agentCalls)
  }
  const avgOf = (list, decimals) => list.length ? roundN(list.reduce((a, b) => a + b, 0) / list.length, decimals) : null

  const round1 = (n) => Math.round(n * 10) / 10
  const out = {}
  // Union des catégories scorées ET télémétrées : une catégorie dont TOUTES
  // les entrées ont un score null (skip) mais portent de la télémétrie (ex.
  // une revue déléguée qui échoue, coûte quand même des $) ne doit pas
  // disparaître silencieusement du rapport — cf. `telByCat` ci-dessus.
  const allCats = new Set([...Object.keys(byCat), ...Object.keys(telByCat)])
  for (const cat of allCats) {
    const cells = byCat[cat] || {}
    const means = {}, nTasks = {}, nRuns = {}
    for (const arm of arms) {
      const scores = Object.values(cells[arm] || {}).flatMap(c => c.scores)
      means[arm] = scores.length ? round1(scores.reduce((a, b) => a + b, 0) / scores.length) : null
      nTasks[arm] = Object.keys(cells[arm] || {}).length
      nRuns[arm] = scores.length
    }
    // Moyennes de télémétrie par bras — présentes pour tous les bras du
    // périmètre (comme means/nTasks/nRuns), nulles/0 si rien n'a été fourni :
    // rétro-compatible avec toute entrée n'ayant aucun champ de télémétrie.
    const telCells = telByCat[cat] || {}
    const telemetry = {}
    for (const arm of arms) {
      const t = telCells[arm] || { costs: [], tokensTotal: [], wallClocks: [], agentCalls: [] }
      telemetry[arm] = {
        avgCostUsd: avgOf(t.costs, 4),
        avgTokensTotal: avgOf(t.tokensTotal, 1),
        avgWallClockMs: avgOf(t.wallClocks, 1),
        avgAgentCalls: avgOf(t.agentCalls, 2),
        nCostUsd: t.costs.length,
        nTokensTotal: t.tokensTotal.length,
        nWallClockMs: t.wallClocks.length,
        nAgentCalls: t.agentCalls.length,
      }
    }
    const deltas = {}
    const pairs = (opts.deltaPairs || defaultDeltaPairs(arms)).map(([x, y]) => [x, y])
    // Bras présents qu'aucune paire ne compare : l'appariement par défaut a été
    // DÉCLINÉ (≥3 étiquettes hors ablation) — signalé, pas deviné.
    const unpaired = arms.filter(a => means[a] !== null && !pairs.some(([x, y]) => x === a || y === a))
    for (const [x, y] of pairs) {
      const key = `${x}-${y}`
      if (!withDeltas || means[x] === null || means[x] === undefined || means[y] === null || means[y] === undefined) {
        deltas[key] = null
        continue
      }
      assertComparableArms(cat, x, y, cells)
      deltas[key] = round1(means[x] - means[y])
    }
    out[cat] = {
      arms: means, n: nTasks, runs: nRuns, deltas, deltaPairs: pairs, armsUnpaired: unpaired,
      telemetry,
      // Alias historiques (bras d'ablation) : conservés pour les consommateurs existants.
      A: means.A ?? null, B: means.B ?? null, C: means.C ?? null, D: means.D ?? null,
      dBA: deltas['B-A'] ?? null,  // valeur mémoire
      dCB: deltas['C-B'] ?? null,  // valeur routing/spécialisation
      dDC: deltas['D-C'] ?? null,  // ROI décomposition
    }
  }
  return out
}

// ── Rendu CLI ────────────────────────────────────────────────────────────────
function printCatalog() {
  const tasks = loadTasks()
  console.log(`${C.bold}Benchmark v2 — catalogue${C.reset}\n`)
  console.log(`${C.bold}Catégories (registre)${C.reset}`)
  for (const [key, reg] of Object.entries(CATEGORY_REGISTRY)) {
    const badge = reg.status === 'wired' ? `${C.green}[câblée]${C.reset}` : `${C.yellow}[planifiée]${C.reset}`
    console.log(`  ${badge} ${C.cyan}${key}${C.reset} — ${reg.label}`)
  }
  console.log(`\n${C.bold}Tâches${C.reset}`)
  for (const t of tasks) {
    console.log(`  ${C.cyan}${t.id}${C.reset} (${t.stack}) — ${t.title}`)
    console.log(`     ${C.gray}catégories: ${(t.categories || []).join(', ')}${C.reset}`)
  }
  console.log(`\n${C.bold}Bras d'ablation${C.reset}`)
  for (const a of ARMS) {
    const m = ARM_META[a]
    console.log(`  ${C.cyan}${a}${C.reset} ${m.label} — inject:${m.injectConventions} decompose:${m.decompose}`)
  }
  console.log(`\n${C.gray}Deltas report : B−A=mémoire · C−B=routing/spécialisation · D−C=ROI décomposition${C.reset}`)
}

function printPlan(plan) {
  if (!plan.length) { console.log(`${C.yellow}Plan vide (vérifie --categories/--tasks).${C.reset}`); return }
  console.log(`${C.bold}Plan v2 — ${plan.length} run(s)${C.reset}`)
  console.log(`${C.gray}L'orchestrateur exécute chaque run et écrit le livrable dans outputFile.${C.reset}\n`)
  for (const p of plan) {
    console.log(`${C.cyan}${p.arm}${C.reset} ${p.armLabel.padEnd(18)} ${C.bold}${p.taskId}${C.reset} [${p.category}]`)
    console.log(`   agent=${p.agentType} model=${p.model} inject=${p.injectConventions} decompose=${p.decompose}`)
    console.log(`   ${C.gray}→ ${p.outputFile}${C.reset}`)
  }
}

function printReport(report) {
  const cats = Object.keys(report)
  if (!cats.length) { console.log(`${C.yellow}Aucun résultat. Lance d'abord des scores.${C.reset}`); return }
  console.log(`${C.bold}Benchmark v2 — matrice catégorie × bras${C.reset}\n`)
  // Colonnes DYNAMIQUES : tout bras présent (A-D, NATIVE, PIPELINE…) et tout delta
  // calculé. Rien n'est masqué parce que l'étiquette n'est pas dans une liste figée.
  const armCols = [], deltaCols = [], deltaLabel = {}
  for (const cat of cats) {
    for (const a of Object.keys(report[cat].arms || {})) if (!armCols.includes(a)) armCols.push(a)
    for (const d of Object.keys(report[cat].deltas || {})) if (!deltaCols.includes(d)) deltaCols.push(d)
    // Libellé du delta construit depuis la PAIRE (pas par remplacement de tiret :
    // une étiquette peut elle-même contenir un tiret, ex. `NATIVE-T2`).
    for (const [x, y] of (report[cat].deltaPairs || [])) deltaLabel[`${x}-${y}`] = `${x}−${y}`
  }
  const lbl = (d) => deltaLabel[d] || d
  const w = (s) => Math.max(7, String(s).length + 1)
  const pad = (v, width) => (v === null || v === undefined ? '·' : String(v)).padStart(width)
  const widths = [...armCols.map(a => w(a)), ...deltaCols.map(d => w(lbl(d)))]
  const head = [
    'catégorie'.padEnd(28),
    ...armCols.map((a, i) => pad(a, widths[i])),
    ...deltaCols.map((d, i) => pad(lbl(d), widths[armCols.length + i])),
  ]
  console.log(C.bold + head.join(' ') + C.reset)
  for (const cat of cats) {
    const r = report[cat]
    console.log([
      cat.padEnd(28),
      ...armCols.map((a, i) => pad(r.arms ? r.arms[a] : null, widths[i])),
      ...deltaCols.map((d, i) => pad(r.deltas ? r.deltas[d] : null, widths[armCols.length + i])),
    ].join(' '))
  }
  console.log(`\n${C.gray}B−A=valeur mémoire · C−B=valeur routing/spécialisation · D−C=ROI décomposition${C.reset}`)
  console.log(`${C.gray}· = aucune donnée (ou delta non calculé). Un delta illégitime (plan déséquilibré / scorerSha mélangés) fait ÉCHOUER le rapport, il n'est jamais rendu partiel.${C.reset}`)
  for (const cat of cats) {
    const un = report[cat].armsUnpaired || []
    if (un.length) {
      console.log(`${C.yellow}[${cat}] bras sans comparaison par défaut : ${un.join(', ')} — l'appariement n'est pas deviné, demande-le (--arms X,Y).${C.reset}`)
    }
  }

  // Télémétrie d'efficience (G6, ADR-021 #9 / ADR-023 étape 1) — section
  // séparée, imprimée UNIQUEMENT si au moins une cellule a une mesure. La
  // matrice ci-dessus reste inchangée en son absence : rétro-compatible avec
  // les entrées results-v2.json antérieures à G6 (aucun champ de télémétrie).
  const telRows = []
  for (const cat of cats) {
    for (const [arm, v] of Object.entries(report[cat].telemetry || {})) {
      if (v && (v.avgCostUsd !== null || v.avgTokensTotal !== null || v.avgWallClockMs !== null || v.avgAgentCalls !== null)) {
        telRows.push({ cat, arm, v })
      }
    }
  }
  if (telRows.length) {
    console.log(`\n${C.bold}Télémétrie d'efficience — moyennes par bras (G6)${C.reset}`)
    for (const { cat, arm, v } of telRows) {
      console.log(
        `  ${C.cyan}${cat}${C.reset} ${arm.padEnd(10)} `
        + `coût=${v.avgCostUsd !== null ? '$' + v.avgCostUsd : '·'} `
        + `tokens=${v.avgTokensTotal ?? '·'} `
        + `wallClockMs=${v.avgWallClockMs ?? '·'} `
        + `agentCalls=${v.avgAgentCalls ?? '·'}`
      )
    }
    console.log(`${C.gray}Moyennes calculées uniquement sur les trials où la métrique a été fournie (--tokens-*/--cost-usd/--wall-clock-ms/--agent-calls). · = non mesuré.${C.reset}`)
  }
}

// ── Parse d'arguments ─────────────────────────────────────────────────────────
function parseFlags(argv) {
  const flags = {}
  const positional = []
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i]
    if (a.startsWith('--')) {
      const key = a.slice(2)
      const next = argv[i + 1]
      if (next === undefined || next.startsWith('--')) { flags[key] = true }
      else { flags[key] = next; i++ }
    } else positional.push(a)
  }
  return { flags, positional }
}
function csv(v) { return typeof v === 'string' ? v.split(',').map(s => s.trim()).filter(Boolean) : [] }

/**
 * Parse un flag numérique optionnel de télémétrie d'efficience (G6, ADR-021 #9).
 * PURE. Flag absent → `null` (non mesuré — jamais 0, cf. convention `model`).
 * Flag présent mais non numérique (booléen `true` faute de valeur suivante,
 * chaîne vide, ou non convertible en nombre fini) → erreur explicite : on ne
 * coerce jamais silencieusement une valeur invalide en 0/NaN dans results-v2.json.
 */
function parseNumericFlag(flags, key) {
  const v = flags[key]
  if (v === undefined) return null
  if (v === true || typeof v !== 'string' || v.trim() === '' || !Number.isFinite(Number(v))) {
    throw new Error(`--${key} attend une valeur numérique, reçu: ${JSON.stringify(v === true ? '(aucune valeur)' : v)}`)
  }
  return Number(v)
}

// ── Menu interactif (TTY) ──────────────────────────────────────────────────────
function interactiveMenu() {
  const readline = require('readline')
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
  const ask = (q) => new Promise(res => rl.question(q, res))
  const tasks = loadTasks()
  ;(async () => {
    console.log(`${C.bold}Benchmark v2 — menu interactif${C.reset}\n`)
    const cats = Object.keys(CATEGORY_REGISTRY)
    cats.forEach((c, i) => {
      const reg = CATEGORY_REGISTRY[c]
      const badge = reg.status === 'wired' ? `${C.green}câblée${C.reset}` : `${C.yellow}planifiée${C.reset}`
      console.log(`  ${i + 1}. ${c} [${badge}]`)
    })
    const cAns = await ask('\nCatégories (numéros séparés par ,, vide = toutes câblées): ')
    const chosenCats = cAns.trim()
      ? cAns.split(',').map(s => cats[parseInt(s.trim(), 10) - 1]).filter(Boolean)
      : cats.filter(c => CATEGORY_REGISTRY[c].status === 'wired')

    console.log('\nTâches:')
    tasks.forEach((t, i) => console.log(`  ${i + 1}. ${t.id} — ${t.title}`))
    const tAns = await ask('Tâches (numéros, vide = toutes): ')
    const chosenTasks = tAns.trim()
      ? tAns.split(',').map(s => tasks[parseInt(s.trim(), 10) - 1]?.id).filter(Boolean)
      : null

    const aAns = await ask(`Bras (${ARMS.join(',')}, vide = tous): `)
    const chosenArms = aAns.trim() ? aAns.split(',').map(s => s.trim().toUpperCase()).filter(a => ARMS.includes(a)) : ARMS

    rl.close()
    const plan = buildPlan(tasks, { categories: chosenCats, taskIds: chosenTasks, arms: chosenArms })
    console.log('')
    printPlan(plan)
  })()
}

// ── CLI ────────────────────────────────────────────────────────────────────────
// runId : UNE seule valeur par process (mémoïsée paresseusement — un simple
// `require()` du module par un test n'invoque ni l'horloge ni l'aléatoire).
let _runId = null
function currentRunId() { return (_runId ||= newRunId()) }

function main(argv) {
  const cmd = argv[2]
  const { flags, positional } = parseFlags(argv.slice(3))

  switch (cmd) {
    case 'plan': {
      const plan = buildPlan(loadTasks(), {
        categories: csv(flags.categories),
        taskIds: csv(flags.tasks),
        arms: csv(flags.arms).map(s => s.toUpperCase()),
      })
      if (flags.json) console.log(JSON.stringify(plan, null, 2))
      else printPlan(plan)
      break
    }
    case 'menu': {
      const hasFlags = flags.categories || flags.tasks || flags.arms
      if (hasFlags || !process.stdin.isTTY) {
        if (hasFlags) {
          const plan = buildPlan(loadTasks(), {
            categories: csv(flags.categories),
            taskIds: csv(flags.tasks),
            arms: csv(flags.arms).map(s => s.toUpperCase()),
          })
          printPlan(plan)
        } else {
          printCatalog()
        }
      } else {
        interactiveMenu()
      }
      break
    }
    case 'score': {
      const [taskId, arm] = positional
      const category = flags.category
      const outputFile = flags['output-file']
      if (!taskId || !arm || !category) {
        console.error('usage: score <taskId> <arm> --category <cat> --output-file <f> [--model <id>] [--run-id <id>]')
        console.error('                          [--tokens-input <n> --tokens-output <n> --tokens-cache-read <n> --tokens-cache-write <n>]')
        console.error('                          [--cost-usd <n>] [--wall-clock-ms <n>] [--agent-calls <n>]')
        process.exit(1)
      }
      const task = getTask(taskId)
      if (!task) { console.error(`tâche inconnue: ${taskId}`); process.exit(1) }

      // Le vocabulaire des bras n'est PAS figé à A-D : `NATIVE`, `PIPELINE`, etc.
      // sont enregistrés normalement (avant, un tel bras était écrit puis effacé
      // du rapport en silence). Seule une étiquette absurde est rejetée, avec erreur.
      let normalizedArm
      try { normalizedArm = normalizeArm(arm) } catch (e) { console.error(e.message); process.exit(1) }

      // Télémétrie d'efficience (G6, ADR-021 #9 / ADR-023 étape 1) — flags
      // optionnels, validés AVANT tout travail coûteux (apply Postgres/docker
      // build) : une coquille de flag ne doit pas gaspiller un scoring réel.
      let tokensInput, tokensOutput, tokensCacheRead, tokensCacheWrite, costUsd, wallClockMs, agentCalls
      try {
        tokensInput = parseNumericFlag(flags, 'tokens-input')
        tokensOutput = parseNumericFlag(flags, 'tokens-output')
        tokensCacheRead = parseNumericFlag(flags, 'tokens-cache-read')
        tokensCacheWrite = parseNumericFlag(flags, 'tokens-cache-write')
        costUsd = parseNumericFlag(flags, 'cost-usd')
        wallClockMs = parseNumericFlag(flags, 'wall-clock-ms')
        agentCalls = parseNumericFlag(flags, 'agent-calls')
      } catch (e) { console.error(e.message); process.exit(1) }
      // tokens : objet groupé seulement si AU MOINS un sous-champ est fourni,
      // sinon `null` — distingue « aucune télémétrie de tokens fournie » de
      // « tokens mesurés mais tous nuls », comme le reste du fichier le fait
      // déjà pour `model`.
      const hasTokens = tokensInput !== null || tokensOutput !== null || tokensCacheRead !== null || tokensCacheWrite !== null
      const tokens = hasTokens
        ? { input: tokensInput, output: tokensOutput, cacheRead: tokensCacheRead, cacheWrite: tokensCacheWrite }
        : null

      let deliverableText = ''
      const f = outputFile || deliverablePath(taskId, arm)
      if (existsSync(f)) deliverableText = readFileSync(f, 'utf8')
      else if (CATEGORY_REGISTRY[category]?.scorer === 'sql' || CATEGORY_REGISTRY[category]?.scorer === 'ts' || CATEGORY_REGISTRY[category]?.scorer === 'docker') {
        console.error(`livrable introuvable: ${f}`); process.exit(1)
      }

      // Suffixe aléatoire généré ICI (CLI), pas dans la fonction pure.
      const randSuffix = Math.random().toString(36).slice(2, 10)
      const { score, detail } = runScorer(category, task, deliverableText, randSuffix)

      const results = loadResults()
      // Provenance (ADR-021 I3) : runId unique par invocation + identité de
      // l'instrument (scorer + catalogue de tâches) + modèle éventuel du run.
      const entry = {
        taskId, category, arm: normalizedArm, score, detail, ts: ts(),
        runId: typeof flags['run-id'] === 'string' ? flags['run-id'] : currentRunId(),
        scorerSha: provenanceSha(__filename),
        tasksSha: provenanceSha(TASKS_FILE),
        model: typeof flags.model === 'string' ? flags.model : null,
        // Télémétrie d'efficience (G6, ADR-021 #9 / ADR-023 étape 1) : null si
        // non fournie via les flags --tokens-*/--cost-usd/--wall-clock-ms/--agent-calls
        // (bench-v2.js ne spawn pas d'agents — ADR-021 F7 — donc ne peut pas la
        // mesurer lui-même ; il ne fait que la PERSISTER si l'appelant la fournit).
        tokens,
        costUsd,
        wallClockMs,
        agentCalls,
      }
      results.push(entry)
      saveResults(results)

      const badge = score === null ? `${C.yellow}SKIP${C.reset}` : `${C.green}${score}${C.reset}`
      console.log(`${badge} ${taskId} [${category}] bras ${normalizedArm}`)
      console.log(`  ${C.gray}runId=${entry.runId} scorer=${entry.scorerSha} tasks=${entry.tasksSha} model=${entry.model ?? '·'}${C.reset}`)
      const tokFmt = entry.tokens
        ? `in=${entry.tokens.input ?? '·'}/out=${entry.tokens.output ?? '·'}/cacheR=${entry.tokens.cacheRead ?? '·'}/cacheW=${entry.tokens.cacheWrite ?? '·'}`
        : '·'
      console.log(`  ${C.gray}tokens=${tokFmt} costUsd=${entry.costUsd ?? '·'} wallClockMs=${entry.wallClockMs ?? '·'} agentCalls=${entry.agentCalls ?? '·'}${C.reset}`)
      console.log(typeof detail === 'string' ? `  ${detail}` : `  ${JSON.stringify(detail)}`)
      break
    }
    case 'report': {
      let report
      try {
        report = buildReport(loadResults(), {
          category: flags.category || null,
          arms: csv(flags.arms).map(s => s.toUpperCase()),
          deltas: !flags['no-deltas'],
        })
      } catch (e) {
        // Un delta illégitime FAIT ÉCHOUER le rapport : mieux vaut pas de chiffre
        // qu'un chiffre qui mélange deux instruments ou deux populations.
        console.error(`${C.red}Rapport refusé — ${e.message}${C.reset}`)
        console.error(`${C.gray}Options : --arms <liste> pour restreindre le périmètre · --no-deltas pour n'afficher que les moyennes.${C.reset}`)
        process.exit(1)
      }
      if (flags.json) console.log(JSON.stringify(report, null, 2))
      else printReport(report)
      break
    }
    case 'reset': {
      saveResults([])
      console.log(`${C.green}results-v2.json vidé.${C.reset}`)
      break
    }
    case 'menu-catalog':
    case 'catalog':
      printCatalog()
      break
    default:
      console.log(`bench-v2 — commandes : plan | menu | score | report | reset | catalog`)
      console.log(`  node bench-v2.js plan --categories correction-reelle`)
      console.log(`  node bench-v2.js score <taskId> <arm> --category <cat> --output-file <f> [--model <id>] [--run-id <id>]`)
      console.log(`                          [--tokens-input <n> --tokens-output <n> --tokens-cache-read <n> --tokens-cache-write <n>]`)
      console.log(`                          [--cost-usd <n>] [--wall-clock-ms <n>] [--agent-calls <n>]`)
      console.log(`    ${C.gray}télémétrie d'efficience (G6, ADR-021 #9) — façon standard de la fournir lors d'un run manuel,`)
      console.log(`    analogue à \`run.js done --tokens --cost\` ; absent = null (non mesuré), jamais 0.${C.reset}`)
      console.log(`  node bench-v2.js report [--category <cat>] [--arms A,B] [--no-deltas]`)
  }
}

// ── Exports (tests) ───────────────────────────────────────────────────────────
module.exports = {
  ARMS, ARM_META, PROFILE_AGENT, CATEGORY_REGISTRY,
  buildPlan, planRun, deliverablePath, routedModel, routedTier,
  extractSqlBlocks, extractReferencedTables, buildStubSql, parsePsqlScalar, evalAssertion, computeAssertionScore,
  // Exporté pour mutation-test.js (ADR-021 F6) : le mutation testing doit piloter
  // le VRAI scorer en process, sans passer par la CLI `score` qui écrirait dans
  // results-v2.json à chaque mutant (des centaines d'entrées parasites).
  scoreSqlDeliverable, runScorer, postgresAvailable,
  BENCH_IDS, ASSERTION_ROLES, resolveBenchPlaceholders, buildAuthPreamble, buildAssertionSql,
  SUPABASE_SCAFFOLD_SQL, SUPABASE_AUTH_STUB_SQL,
  // Impur (psql) — exporté pour permettre à un harnais de calibration (ADR-021 §1)
  // de scorer des fixtures sans passer par le CLI ni polluer results-v2.json.
  scoreSqlDeliverable, postgresAvailable,
  normKey, recallPrecision, parseRecallConventions,
  buildReport, resolveArms, defaultDeltaPairs, assertComparableArms, LEGACY_DELTAS,
  // Provenance (ADR-021 I3). normalizeArm est PURE ; contentSha/provenanceSha/newRunId
  // sont impurs (fs/git/horloge) et n'ont d'usage que côté CLI.
  normalizeArm, contentSha, provenanceSha, newRunId,
  // Télémétrie d'efficience (G6, ADR-021 #9 / ADR-023 étape 1). parseNumericFlag
  // et roundN sont PURES — exportées pour tester le parsing/l'arrondi sans
  // passer par un spawn du CLI.
  parseNumericFlag, roundN, parseFlags,
}

if (require.main === module) main(process.argv)
