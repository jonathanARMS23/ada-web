#!/usr/bin/env node
'use strict'
/**
 * coordinator/benchmark.js — Benchmark A/B/C : ADA vs équipe naïve vs Claude Code nu
 *
 * Framework + capture de métriques réelles. L'EXÉCUTION de chaque bras est
 * déclenchée à l'extérieur (orchestrateur/humain) ; le harness encadre la mesure :
 *   start  → snapshot (ts + tokens transcript)
 *   finish → delta tokens, latence, itérations, qualité (LLM-judge Ollama) → résultat
 *   report → comparaison ADA vs baseline (naive par défaut) sur toutes les dimensions
 *
 * Le BON témoin n'est PAS Claude Code nu mais une « équipe d'agents naïve »
 * (fan-out d'agents generalist, sans routing/mémoire/spécialisation). L'avantage
 * réel d'ADA porte sur le SAVOIR TACITE projet (conventions absentes du prompt) :
 * mesuré via la dimension Conventions (tacitConventions par tâche).
 *
 * Dimensions : coût (tokens/$), itérations, qualité (0-100), conventions (0-100),
 *              latence, + routing (ADA).
 *
 * CLI :
 *   node benchmark.js tasks
 *   node benchmark.js start  <taskId> <ada|naive|naked>
 *   node benchmark.js finish <taskId> <ada|naive|naked> [--iterations N] [--quality S] [--output-file f]
 *   node benchmark.js report [--baseline naive|naked]
 *   node benchmark.js reset
 */

const { readFileSync, writeFileSync, existsSync, mkdirSync, renameSync } = require('fs')
const { join, dirname } = require('path')
const os = require('os')
const http = require('node:http')

const CONFIG_DIR   = process.env.CLAUDE_CONFIG_DIR || join(process.env.HOME ?? os.homedir(), '.claude')
const COORD_DIR    = join(CONFIG_DIR, 'coordinator')
const BENCH_DIR    = join(CONFIG_DIR, 'benchmarks')
const TASKS_FILE   = join(BENCH_DIR, 'tasks.json')
const RESULTS_FILE = join(BENCH_DIR, 'results.json')
const PENDING_FILE = join(BENCH_DIR, '.pending.json')

const JUDGE_MODEL  = process.env.ADA_JUDGE_MODEL || 'qwen2'
const OLLAMA_URL   = process.env.OLLAMA_URL || 'http://localhost:11434'

const C = { reset: '\x1b[0m', bold: '\x1b[1m', green: '\x1b[32m', red: '\x1b[31m', yellow: '\x1b[33m', cyan: '\x1b[36m', gray: '\x1b[90m' }

function readJSON(p, fallback) { try { return JSON.parse(readFileSync(p, 'utf8')) } catch { return fallback } }
function writeJSON(p, obj) {
  mkdirSync(dirname(p), { recursive: true })
  const tmp = p + '.tmp'; writeFileSync(tmp, JSON.stringify(obj, null, 2)); renameSync(tmp, p)
}
function ts() { return new Date().toISOString() }

function loadTasks() { return (readJSON(TASKS_FILE, { tasks: [] }).tasks) || [] }
function getTask(id) { return loadTasks().find(t => t.id === id) || null }

// ── Localisation du transcript le plus récent (centralisée) ───────────────────
/**
 * Trouve, sous CONFIG_DIR/projects/<sous-dossier>, le *.jsonl le plus récemment
 * modifié. Retourne { dir, file } ou null. `dir` est le dossier qui contient TOUS
 * les transcripts du projet (principal + sous-agents/sidechains) — c'est lui que
 * `sumUsageWindow` doit scanner pour capter la délégation.
 */
function locateLatestTranscript() {
  try {
    const fs = require('fs')
    const projDir = join(CONFIG_DIR, 'projects')
    if (!existsSync(projDir)) return null
    let latestFile = null, latestDir = null, latestM = 0
    for (const d of fs.readdirSync(projDir)) {
      const sub = join(projDir, d)
      try {
        for (const f of fs.readdirSync(sub)) {
          if (!f.endsWith('.jsonl')) continue
          const fp = join(sub, f); const m = fs.statSync(fp).mtimeMs
          if (m > latestM) { latestM = m; latestFile = fp; latestDir = sub }
        }
      } catch {}
    }
    return latestFile ? { dir: latestDir, file: latestFile } : null
  } catch { return null }
}

// ── Snapshot tokens depuis le transcript actif (token-telemetry) ──────────────
function snapshotTokens() {
  try {
    const tt = require(join(COORD_DIR, 'token-telemetry.js'))
    const loc = locateLatestTranscript()
    if (!loc) return null
    const u = tt.readTranscript(loc.file)
    if (!u) return null
    return { totalTokens: u.totalInput + u.output, realCostUsd: u.realCostUsd }
  } catch { return null }
}

// ── LLM-judge via Ollama (local, gratuit) ─────────────────────────────────────
function judgeQuality(task, output) {
  return new Promise(resolve => {
    if (!output) return resolve(null)
    const rubric = (task.rubric || []).map((r, i) => `${i + 1}. ${r}`).join('\n')
    const prompt = `Tu es un évaluateur de code senior. Note la RÉPONSE de 0 à 100 selon la grille.\n` +
      `TÂCHE: ${task.prompt}\n\nGRILLE:\n${rubric}\n\nRÉPONSE À ÉVALUER:\n${String(output).slice(0, 2800)}\n\n` +
      `Réponds UNIQUEMENT par un JSON court: {"score": <0-100>, "raison": "<1 phrase>"}`
    // num_predict borné : le judge ne sort qu'un petit JSON → génération rapide même sur CPU.
    const body = JSON.stringify({ model: JUDGE_MODEL, prompt, stream: false, format: 'json', options: { temperature: 0, num_predict: 160 } })
    const u = new URL(OLLAMA_URL)
    const req = http.request({ hostname: u.hostname, port: u.port, path: '/api/generate', method: 'POST', headers: { 'Content-Type': 'application/json' }, timeout: 180000 }, res => {
      let data = ''; res.on('data', c => data += c); res.on('end', () => {
        try { const j = JSON.parse(data); const r = JSON.parse(j.response); resolve({ score: Math.max(0, Math.min(100, Number(r.score) || 0)), raison: r.raison || '' }) }
        catch { resolve(null) }
      })
    })
    req.on('error', () => resolve(null)); req.on('timeout', () => { req.destroy(); resolve(null) })
    req.write(body); req.end()
  })
}

// ── Vérificateur déterministe (checks regex) — rapide, fiable, objectif ────────
function benchConfig() { return readJSON(TASKS_FILE, {}) }

/**
 * Évalue un output contre les checks déterministes d'une tâche.
 * Score = % de checks REQUIS satisfaits. Rapide (regex), reproductible, sans LLM.
 *
 * EN PLUS (Axe D) : si la tâche déclare `tacitConventions` (conventions NON
 * mentionnées dans le prompt — le bon agent les connaît via la mémoire, le naïf
 * non), calcule `conventionScore` = % de ces conventions dont le pattern matche.
 * `conventionScore` reste null si la tâche n'en a pas (rétro-compat strict).
 *
 * @returns {{ score: number, conventionScore: number|null, passed: string[],
 *             failed: string[], conventionsPassed: string[],
 *             conventionsFailed: string[], pass: boolean }|null}
 */
function verifyOutput(task, output) {
  const checks = (task && task.checks) || []
  const conventions = (task && task.tacitConventions) || []
  if (!checks.length && !conventions.length) return null
  const text = String(output || '')
  const passed = [], failed = []
  let reqTotal = 0, reqPassed = 0
  for (const ch of checks) {
    let ok
    try { ok = new RegExp(ch.pattern, 'i').test(text) } catch { ok = false }
    if (ch.mustNotMatch) ok = !ok
    if (ch.required) { reqTotal++; if (ok) reqPassed++ }
    ;(ok ? passed : failed).push(ch.name)
  }
  const score = reqTotal ? Math.round((100 * reqPassed) / reqTotal) : 100

  // Conventions tacites : dimension séparée, indépendante du score fonctionnel.
  const conventionsPassed = [], conventionsFailed = []
  for (const cv of conventions) {
    let ok
    try { ok = new RegExp(cv.pattern, 'i').test(text) } catch { ok = false }
    ;(ok ? conventionsPassed : conventionsFailed).push(cv.name)
  }
  const conventionScore = conventions.length
    ? Math.round((100 * conventionsPassed.length) / conventions.length)
    : null

  const threshold = benchConfig().passThreshold ?? 80
  return { score, conventionScore, passed, failed, conventionsPassed, conventionsFailed, pass: score >= threshold }
}

// ── start / finish ─────────────────────────────────────────────────────────────
function cmdStart(taskId, arm) {
  const task = getTask(taskId)
  if (!task) { console.error(`Tâche inconnue: ${taskId}`); process.exit(1) }
  if (!['ada', 'naked', 'naive'].includes(arm)) { console.error(`arm doit être 'ada', 'naive' ou 'naked'`); process.exit(1) }
  const pending = readJSON(PENDING_FILE, {})
  pending[`${taskId}:${arm}`] = { taskId, arm, startTs: ts(), startSnapshot: snapshotTokens() }
  writeJSON(PENDING_FILE, pending)
  const armDesc = {
    ada: 'ADA (pipeline run.js + agents : routing/mémoire/spécialisation)',
    naive: 'équipe d\'agents naïve (fan-out d\'agents generalist, sans routing/mémoire/spécialisation)',
    naked: 'Claude Code nu (agent direct, sans coordinator)',
  }[arm]
  console.log(`${C.cyan}▶${C.reset} Benchmark démarré : ${C.bold}${taskId}${C.reset} [${arm}]`)
  console.log(`  Exécute maintenant la tâche en mode ${armDesc} :`)
  console.log(`  ${C.gray}${task.prompt}${C.reset}`)
  console.log(`  Puis : node benchmark.js finish ${taskId} ${arm} --iterations <N> --output-file <fichier>`)
}

async function cmdFinish(taskId, arm, opts) {
  const task = getTask(taskId)
  if (!task) { console.error(`Tâche inconnue: ${taskId}`); process.exit(1) }
  const pending = readJSON(PENDING_FILE, {})
  const key = `${taskId}:${arm}`
  const p = pending[key]
  if (!p) { console.error(`Aucun start trouvé pour ${key} — lance d'abord: benchmark.js start ${taskId} ${arm}`); process.exit(1) }

  // IMPORTANT : les bras DOIVENT être exécutés SÉRIALISÉS (jamais en parallèle).
  // La mesure de coût se fait par fenêtre temporelle [startTs, finishedAt] sur TOUS
  // les transcripts du projet (principal + sous-agents). Deux bras qui tournent en
  // même temps verraient leurs fenêtres se chevaucher → double-comptage des tokens.
  const finishedAt = ts()
  const endSnapshot = snapshotTokens()
  const latencyMs = new Date(finishedAt) - new Date(p.startTs)
  let tokens = opts.tokens
  let costUsd = null
  if (tokens == null) {
    // Mesure préférée : fenêtre temporelle multi-transcripts (capte la délégation).
    let windowUsage = null
    try {
      const tt = require(join(COORD_DIR, 'token-telemetry.js'))
      const loc = locateLatestTranscript()
      if (loc) windowUsage = tt.sumUsageWindow(loc.dir, p.startTs, finishedAt)
    } catch {}
    if (windowUsage) {
      tokens = windowUsage.totalInput + windowUsage.output
      costUsd = windowUsage.realCostUsd
    } else if (p.startSnapshot && endSnapshot) {
      // Fallback : ancien delta mono-fichier (préserve le comportement existant).
      tokens = Math.max(0, endSnapshot.totalTokens - p.startSnapshot.totalTokens)
      costUsd = Math.max(0, endSnapshot.realCostUsd - p.startSnapshot.realCostUsd)
    }
  }

  let output = opts.output
  if (!output && opts.outputFile && existsSync(opts.outputFile)) output = readFileSync(opts.outputFile, 'utf8')

  let quality = opts.quality
  let judgeReason = ''
  let failedChecks = []
  // Conventions tacites : dimension séparée, toujours calculée depuis l'output
  // (indépendante du fait que la qualité vienne du vérificateur ou du LLM-judge).
  let conventionScore = null
  let conventionsFailed = []
  // Un seul calcul du vérificateur déterministe (fonction pure), réutilisé pour
  // les conventions ET la qualité.
  const verified = output ? verifyOutput(task, output) : null
  if (verified) { conventionScore = verified.conventionScore; conventionsFailed = verified.conventionsFailed || [] }
  if (quality == null && output) {
    // Défaut : vérificateur déterministe (rapide/fiable). qwen2 seulement si --llm-judge.
    if (verified && !opts.llmJudge) {
      quality = verified.score
      failedChecks = verified.failed
      judgeReason = verified.failed.length ? `manque: ${verified.failed.join(', ')}` : 'tous critères requis OK'
    } else {
      const j = await judgeQuality(task, output)
      if (j) { quality = j.score; judgeReason = j.raison }
    }
  }

  // Coût estimé depuis les tokens si non calculé par delta transcript (tarif input Sonnet)
  if (costUsd == null && tokens != null) costUsd = (tokens * 3.00) / 1e6

  const results = readJSON(RESULTS_FILE, { runs: [] })
  results.runs.push({
    taskId, arm, ts: ts(),
    latencyMs,
    tokens: tokens ?? null,
    costUsd: costUsd != null ? Number(costUsd.toFixed(4)) : null,
    iterations: opts.iterations ?? null,
    quality: quality ?? null,
    conventionScore: conventionScore ?? null,
    judgeReason,
    failedChecks,
  })
  writeJSON(RESULTS_FILE, results)
  delete pending[key]; writeJSON(PENDING_FILE, pending)

  console.log(`${C.green}✓${C.reset} Résultat enregistré : ${C.bold}${taskId}${C.reset} [${arm}]`)
  const convStr = conventionScore != null ? `  conventions=${conventionScore}/100` : ''
  console.log(`  tokens=${tokens ?? '?'}  coût=${costUsd != null ? '$' + costUsd.toFixed(4) : '?'}  itérations=${opts.iterations ?? '?'}  qualité=${quality ?? '?'}/100${convStr}  latence=${Math.round(latencyMs / 1000)}s`)
  if (judgeReason) console.log(`  ${C.gray}juge: ${judgeReason}${C.reset}`)
  if (conventionScore != null && conventionsFailed.length) console.log(`  ${C.gray}conventions manquées: ${conventionsFailed.join(', ')}${C.reset}`)
}

// ── report ───────────────────────────────────────────────────────────────────
function avg(arr) { const v = arr.filter(n => typeof n === 'number'); return v.length ? v.reduce((a, b) => a + b, 0) / v.length : null }
function fmtDelta(adaV, baselineV, lowerIsBetter) {
  if (adaV == null || baselineV == null || baselineV === 0) return C.gray + '—' + C.reset
  const pct = ((adaV - baselineV) / Math.abs(baselineV)) * 100
  const good = lowerIsBetter ? pct < 0 : pct > 0
  const col = good ? C.green : C.red
  return `${col}${pct > 0 ? '+' : ''}${pct.toFixed(0)}%${C.reset}`
}

/**
 * Choisit le bras témoin pour la comparaison.
 * Défaut (Axe D) : `naive` (le BON témoin) s'il existe des runs naive ;
 * sinon `naked` (rétro-compat). Un `--baseline` explicite est toujours respecté.
 * @param {Array} results - runs enregistrés
 * @param {string|null} requested - baseline forcée via --baseline
 * @returns {'naive'|'naked'}
 */
function selectBaseline(results, requested) {
  if (requested === 'naive' || requested === 'naked') return requested
  const hasNaive = results.some(r => r.arm === 'naive')
  return hasNaive ? 'naive' : 'naked'
}

function cmdReport(opts = {}) {
  const results = readJSON(RESULTS_FILE, { runs: [] }).runs
  if (!results.length) { console.log('Aucun résultat. Lance des benchmarks : start/finish.'); return }

  const baseline = selectBaseline(results, opts.baseline)
  const baseLabel = baseline === 'naive' ? 'équipe naïve' : 'Claude Code nu'
  const tasks = [...new Set(results.map(r => r.taskId))]
  const nAda = results.filter(r => r.arm === 'ada').length
  const nNaive = results.filter(r => r.arm === 'naive').length
  const nNaked = results.filter(r => r.arm === 'naked').length
  console.log(`\n${C.bold}Benchmark ADA vs ${baseLabel}${C.reset}  (${results.length} runs, ${tasks.length} tâches)`)
  console.log(`${C.gray}runs par bras : ada=${nAda} naive=${nNaive} naked=${nNaked} — baseline=${baseline}${C.reset}\n`)

  const dims = [
    { key: 'quality',         label: 'Qualité /100',     lower: false },
    { key: 'conventionScore', label: 'Conventions /100', lower: false },
    { key: 'iterations',      label: 'Itérations',       lower: true  },
    { key: 'tokens',          label: 'Tokens',           lower: true  },
    { key: 'costUsd',         label: 'Coût $',            lower: true  },
    { key: 'latencyMs',       label: 'Latence ms',       lower: true  },
  ]

  for (const taskId of tasks) {
    const ada = results.filter(r => r.taskId === taskId && r.arm === 'ada')
    const base = results.filter(r => r.taskId === taskId && r.arm === baseline)
    console.log(`${C.bold}${taskId}${C.reset}  ${C.gray}(ada:${ada.length} ${baseline}:${base.length})${C.reset}`)
    for (const d of dims) {
      const a = avg(ada.map(r => r[d.key])), n = avg(base.map(r => r[d.key]))
      // Dimension conventions : n'afficher la ligne que si au moins un bras la mesure.
      if (d.key === 'conventionScore' && a == null && n == null) continue
      const av = a != null ? a.toFixed(d.key === 'costUsd' ? 4 : 0) : '—'
      const nv = n != null ? n.toFixed(d.key === 'costUsd' ? 4 : 0) : '—'
      console.log(`  ${d.label.padEnd(16)} ADA=${String(av).padStart(8)}  ${baseline}=${String(nv).padStart(8)}  Δ=${fmtDelta(a, n, d.lower)}`)
    }
    console.log('')
  }

  // Agrégat global
  const ada = results.filter(r => r.arm === 'ada'), base = results.filter(r => r.arm === baseline)
  console.log(`${C.bold}── Agrégat ──${C.reset}`)
  for (const d of dims) {
    const a = avg(ada.map(r => r[d.key])), n = avg(base.map(r => r[d.key]))
    if (d.key === 'conventionScore' && a == null && n == null) continue
    console.log(`  ${d.label.padEnd(16)} Δ ADA vs ${baseline} : ${fmtDelta(a, n, d.lower)}`)
  }
  console.log(`\n  ${C.gray}Lecture : vert = ADA meilleur. Le BON témoin est l'équipe naïve (--baseline naive).`)
  console.log(`  La thèse d'ADA est validée si Conventions↑ (savoir tacite) à coût comparable.${C.reset}\n`)
}

// ── CLI ──────────────────────────────────────────────────────────────────────
function parseOpts(args) {
  const o = {}
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--iterations') o.iterations = parseInt(args[++i], 10)
    else if (args[i] === '--quality') o.quality = parseInt(args[++i], 10)
    else if (args[i] === '--tokens') o.tokens = parseInt(args[++i], 10)
    else if (args[i] === '--output-file') o.outputFile = args[++i]
    else if (args[i] === '--output') o.output = args[++i]
    else if (args[i] === '--llm-judge') o.llmJudge = true
    else if (args[i] === '--baseline') o.baseline = args[++i]
  }
  return o
}

if (require.main === module) {
  const [,, cmd, ...args] = process.argv
  ;(async () => {
    if (cmd === 'tasks') {
      for (const t of loadTasks()) console.log(`  ${C.bold}${t.id}${C.reset} — ${t.title} ${C.gray}[${t.profile}]${C.reset}`)
    } else if (cmd === 'start') {
      cmdStart(args[0], args[1])
    } else if (cmd === 'finish') {
      await cmdFinish(args[0], args[1], parseOpts(args.slice(2)))
    } else if (cmd === 'verify') {
      const task = getTask(args[0])
      if (!task) { console.error(`Tâche inconnue: ${args[0]}`); process.exit(1) }
      const file = args[1]
      if (!file || !existsSync(file)) { console.error(`Fichier introuvable: ${file}`); process.exit(1) }
      const v = verifyOutput(task, readFileSync(file, 'utf8'))
      console.log(JSON.stringify(v, null, 2))
    } else if (cmd === 'report') {
      cmdReport(parseOpts(args))
    } else if (cmd === 'reset') {
      writeJSON(RESULTS_FILE, { runs: [] }); writeJSON(PENDING_FILE, {})
      console.log('Résultats benchmark réinitialisés.')
    } else {
      console.log('Usage: benchmark.js <tasks|start <id> <ada|naive|naked>|finish <id> <arm> [opts]|report [--baseline naive|naked]|reset>')
    }
  })()
}

module.exports = { loadTasks, getTask, judgeQuality, snapshotTokens, verifyOutput, selectBaseline }
