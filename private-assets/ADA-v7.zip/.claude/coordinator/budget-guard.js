#!/usr/bin/env node
/**
 * coordinator/budget-guard.js — Circuit-breaker de coût LLM
 *
 * Fonctions publiques :
 *   loadBudgetConfig()                          → config
 *   saveBudgetConfig(config)                    → void
 *   checkBudget(runId, phaseCost, cumulCost, config) → { ok, action, message }
 *   recordCost(runId, amount, model)            → void
 *   getDailyCost()                              → number
 *   getSessionCost(sessionId)                   → number
 *
 *   — ADR-023 étape 4 (gouvernance des délégations d'un orchestrateur adaptatif,
 *     hors frontière de phase run.js — cf. option B de l'ADR, « trou de
 *     gouvernance ») :
 *   checkDelegationBudget(runId, delegationCount, cumulCost, config, aggregates?) → { ok, action, message }
 *   recordDelegation(runId, { agent, model, mandateId, cost }?) → void
 *   getDelegationCount(runId)                   → number
 */

'use strict'

const { readFileSync, writeFileSync, existsSync, mkdirSync, renameSync } = require('fs')
const { join } = require('path')
const { homedir } = require('os')

const HOME = homedir()
// Surchargeables via env (tests hermétiques) — même principe que ADA_CONFIG_PATH
// dans control-handlers.js : évite qu'une suite de tests lise/écrive le vrai
// ~/.ada.json ou ~/.ada/logs de la machine qui exécute les tests.
const ADA_JSON            = process.env.ADA_CONFIG_PATH || join(HOME, '.ada.json')
const LOG_DIR             = process.env.ADA_LOG_DIR     || join(HOME, '.ada', 'logs')
const LOG_FILE            = join(LOG_DIR, 'budget-log.json')
const DELEGATION_LOG_FILE = join(LOG_DIR, 'delegation-log.json')

/** @typedef {{ perRun: number, perSession: number, perDay: number, onExceed: 'warn'|'stop'|'downgrade', alertAt: number, maxDelegationsPerRun: number, adaptiveOnExceed: 'stop'|'warn' }} BudgetConfig */
/** @typedef {{ ok: boolean, action: 'continue'|'warn'|'stop'|'downgrade_tier', message: string }} BudgetResult */
/** @typedef {{ runId: string, amount: number, ts: string, model?: string }} BudgetEntry */
/** @typedef {{ runId: string, ts: string, agent?: string|null, model?: string|null, mandateId?: string|null, cost?: number|null }} DelegationEntry */

const DEFAULTS = {
  perRun: 5,
  perSession: 20,
  perDay: 50,
  onExceed: 'warn',
  alertAt: 0.8,
  // ADR-023 étape 4 — plafonds spécifiques au chemin de délégation adaptative.
  // maxDelegationsPerRun=3 : cohérent avec la règle CLAUDE.md « Max 3 agents
  // actifs par session ». adaptiveOnExceed='stop' : l'ADR exige un refus dur
  // pour ce chemin précis (« pas un simple avertissement »), indépendamment de
  // `onExceed` (qui régit les pipelines figés et peut valoir 'warn').
  maxDelegationsPerRun: 3,
  adaptiveOnExceed: 'stop',
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function ensureDir(p) {
  if (!existsSync(p)) mkdirSync(p, { recursive: true })
}

/**
 * Lit un JSON de façon sûre, retourne fallback si absent ou invalide.
 * @template T
 * @param {string} filePath
 * @param {T} fallback
 * @returns {T}
 */
function safeReadJson(filePath, fallback) {
  try {
    if (!existsSync(filePath)) return fallback
    return JSON.parse(readFileSync(filePath, 'utf8'))
  } catch {
    return fallback
  }
}

/**
 * Écriture atomique (tmp → rename) d'un JSON.
 * @param {string} filePath
 * @param {unknown} data
 */
function atomicWriteJson(filePath, data) {
  ensureDir(require('path').dirname(filePath))
  const tmp = filePath + '.tmp'
  writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf8')
  renameSync(tmp, filePath)
}

// ── Config ────────────────────────────────────────────────────────────────────

/**
 * Charge la configuration budget depuis ~/.ada.json > clé `budget`.
 * Fusionne avec les valeurs par défaut.
 * @returns {BudgetConfig}
 */
function loadBudgetConfig() {
  const ada = safeReadJson(ADA_JSON, {})
  const raw = ada.budget || {}
  return {
    perRun:     typeof raw.perRun     === 'number' ? raw.perRun     : DEFAULTS.perRun,
    perSession: typeof raw.perSession === 'number' ? raw.perSession : DEFAULTS.perSession,
    perDay:     typeof raw.perDay     === 'number' ? raw.perDay     : DEFAULTS.perDay,
    onExceed:   ['warn', 'stop', 'downgrade'].includes(raw.onExceed) ? raw.onExceed : DEFAULTS.onExceed,
    alertAt:    typeof raw.alertAt    === 'number' ? raw.alertAt    : DEFAULTS.alertAt,
    // ADR-023 étape 4
    maxDelegationsPerRun: typeof raw.maxDelegationsPerRun === 'number' && raw.maxDelegationsPerRun > 0
      ? raw.maxDelegationsPerRun : DEFAULTS.maxDelegationsPerRun,
    adaptiveOnExceed: ['stop', 'warn'].includes(raw.adaptiveOnExceed) ? raw.adaptiveOnExceed : DEFAULTS.adaptiveOnExceed,
  }
}

/**
 * Persiste la configuration budget dans ~/.ada.json sous la clé `budget`.
 * @param {BudgetConfig} config
 */
function saveBudgetConfig(config) {
  const ada = safeReadJson(ADA_JSON, {})
  ada.budget = config
  atomicWriteJson(ADA_JSON, ada)
}

// ── Check (pur, sans side-effect) ────────────────────────────────────────────

/**
 * Évalue les seuils de budget et retourne l'action à effectuer.
 * Fonction pure — aucun I/O.
 *
 * @param {string}       runId         identifiant du run courant
 * @param {number}       phaseCost     coût de la phase qui vient de se terminer (USD)
 * @param {number}       cumulCost     coût cumulé total du run jusqu'à maintenant (inclut phaseCost)
 * @param {BudgetConfig} config        config budget
 * @param {{ todayCost?: number, sessionCost?: number }} [aggregates]  coûts agrégés (optionnel)
 * @returns {BudgetResult}
 */
function checkBudget(runId, phaseCost, cumulCost, config, aggregates = {}) {
  const { todayCost = 0, sessionCost = 0 } = aggregates

  // Dépassement budget journalier
  if (config.perDay > 0 && todayCost >= config.perDay) {
    const msg = `Budget journalier dépassé ($${todayCost.toFixed(4)} / $${config.perDay})`
    if (config.onExceed === 'stop')      return { ok: false, action: 'stop',          message: msg }
    if (config.onExceed === 'downgrade') return { ok: false, action: 'downgrade_tier', message: msg }
    return { ok: false, action: 'warn', message: msg }
  }

  // Dépassement budget session
  if (config.perSession > 0 && sessionCost >= config.perSession) {
    const msg = `Budget session dépassé ($${sessionCost.toFixed(4)} / $${config.perSession})`
    if (config.onExceed === 'stop')      return { ok: false, action: 'stop',          message: msg }
    if (config.onExceed === 'downgrade') return { ok: false, action: 'downgrade_tier', message: msg }
    return { ok: false, action: 'warn', message: msg }
  }

  const ratioRun = config.perRun > 0 ? cumulCost / config.perRun : 0

  // Dépassement du budget run
  if (cumulCost >= config.perRun) {
    const msg = `Budget run dépassé ($${cumulCost.toFixed(4)} / $${config.perRun})`
    if (config.onExceed === 'stop')      return { ok: false, action: 'stop',          message: msg }
    if (config.onExceed === 'downgrade') return { ok: false, action: 'downgrade_tier', message: msg }
    return { ok: false, action: 'warn', message: msg }
  }

  // Zone d'alerte (ratio >= alertAt, pas encore dépassé)
  if (ratioRun >= config.alertAt) {
    const pct = Math.round(ratioRun * 100)
    const msg = `Budget run à ${pct}% ($${cumulCost.toFixed(4)} / $${config.perRun})`
    return { ok: true, action: 'warn', message: msg }
  }

  return { ok: true, action: 'continue', message: '' }
}

// ── Délégations adaptatives (ADR-023 étape 4) ───────────────────────────────
//
// Contexte : un orchestrateur adaptatif délègue via l'outil Agent en session,
// sans jamais franchir les frontières de phase de run.js où checkBudget/
// recordCost sont appelés (run.js:811-846, :976-978). Sans point d'entrée
// dédié, l'option « décomposition-qualité → adaptatif » de l'ADR-023 hérite
// intégralement du trou de gouvernance de coût de l'option B (ADR-023,
// risque n°2). Ces trois fonctions fournissent ce point d'entrée : à appeler
// par tout appelant qui délègue de façon adaptative (pas seulement run.js),
// AVANT une délégation (checkDelegationBudget) et APRÈS (recordDelegation).

/**
 * Évalue si une délégation adaptative supplémentaire est autorisée.
 * Fonction pure — aucun I/O. Refuse dur (action 'stop' par défaut, jamais un
 * simple 'warn') dès que `delegationCount` atteint `maxDelegationsPerRun` OU
 * que l'un des plafonds $ (perRun/perSession/perDay) est dépassé — et ce quel
 * que soit `config.onExceed` (qui ne régit que les pipelines figés). Seul
 * `config.adaptiveOnExceed` (défaut 'stop') gouverne l'action retournée ici.
 *
 * @param {string}       runId            identifiant du run courant
 * @param {number}       delegationCount  nombre de délégations adaptatives déjà effectuées sur ce run
 * @param {number}       cumulCost        coût cumulé $ du run jusqu'à maintenant (délégations incluses)
 * @param {BudgetConfig} config           config budget (cf. loadBudgetConfig)
 * @param {{ todayCost?: number, sessionCost?: number }} [aggregates]  coûts agrégés (optionnel)
 * @returns {BudgetResult}
 */
function checkDelegationBudget(runId, delegationCount, cumulCost, config, aggregates = {}) {
  const { todayCost = 0, sessionCost = 0 } = aggregates
  // ADR-023 étape 4 : « refus au-delà, pas un simple avertissement ». Le défaut
  // de adaptiveOnExceed est 'stop' ; le seul autre choix supporté ('warn') est
  // un opt-out explicite de l'utilisateur pour CE chemin précis — jamais un
  // héritage silencieux de config.onExceed.
  const action = config.adaptiveOnExceed === 'warn' ? 'warn' : 'stop'

  const maxDelegations = config.maxDelegationsPerRun > 0 ? config.maxDelegationsPerRun : DEFAULTS.maxDelegationsPerRun
  if (delegationCount >= maxDelegations) {
    return {
      ok: false,
      action,
      message: `Plafond de délégations adaptatives atteint (${delegationCount}/${maxDelegations}) — run ${runId}`,
    }
  }

  if (config.perRun > 0 && cumulCost >= config.perRun) {
    return {
      ok: false,
      action,
      message: `Budget $ run dépassé pour délégation adaptative ($${cumulCost.toFixed(4)} / $${config.perRun}) — run ${runId}`,
    }
  }

  if (config.perSession > 0 && sessionCost >= config.perSession) {
    return {
      ok: false,
      action,
      message: `Budget $ session dépassé pour délégation adaptative ($${sessionCost.toFixed(4)} / $${config.perSession}) — run ${runId}`,
    }
  }

  if (config.perDay > 0 && todayCost >= config.perDay) {
    return {
      ok: false,
      action,
      message: `Budget $ journalier dépassé pour délégation adaptative ($${todayCost.toFixed(4)} / $${config.perDay}) — run ${runId}`,
    }
  }

  return { ok: true, action: 'continue', message: '' }
}

/**
 * Enregistre une délégation adaptative de façon atomique dans
 * ~/.ada/logs/delegation-log.json — symétrique à recordCost, mais trace en
 * plus l'auditabilité exigée par l'ADR-023 (risque n°3, « perte
 * d'auditabilité ») : qui a été appelé (`agent`), avec quel modèle (`model`),
 * sous quel mandat (`mandateId`, référence vers review-mandates.json quand
 * applicable). Lecture tolérante : les champs sont optionnels, une entrée qui
 * ne les fournit pas reste valide (rétrocompatibilité).
 *
 * @param {string} runId
 * @param {{ agent?: string, model?: string, mandateId?: string, cost?: number }} [delegation]
 */
function recordDelegation(runId, delegation = {}) {
  const { agent, model, mandateId, cost } = delegation
  ensureDir(LOG_DIR)

  /** @type {DelegationEntry[]} */
  const entries = safeReadJson(DELEGATION_LOG_FILE, [])
  const list = Array.isArray(entries) ? entries : []

  list.push({
    runId,
    ts: new Date().toISOString(),
    agent: agent || null,
    model: model || null,
    mandateId: mandateId || null,
    cost: typeof cost === 'number' && Number.isFinite(cost) ? cost : null,
  })

  // Même politique de trim que budget-log.json (90 jours).
  const cutoff90d = Date.now() - 90 * 24 * 60 * 60 * 1000
  const trimmed = list.filter(e => {
    const t = new Date(e?.ts).getTime()
    return !isNaN(t) && t >= cutoff90d
  })

  atomicWriteJson(DELEGATION_LOG_FILE, trimmed)
}

/**
 * Retourne le nombre de délégations adaptatives déjà enregistrées pour un runId.
 * Tolérant aux entrées anciennes/partielles (ne dépend que de `runId`).
 * @param {string} runId
 * @returns {number}
 */
function getDelegationCount(runId) {
  /** @type {DelegationEntry[]} */
  const entries = safeReadJson(DELEGATION_LOG_FILE, [])
  if (!Array.isArray(entries)) return 0
  return entries.reduce((n, e) => (e && e.runId === runId ? n + 1 : n), 0)
}

// ── Record (I/O atomique) ─────────────────────────────────────────────────────

/**
 * Ajoute une entrée dans ~/.ada/logs/budget-log.json de façon atomique.
 * @param {string} runId
 * @param {number} amount  coût en USD
 * @param {string} [model] modèle utilisé (optionnel)
 */
function recordCost(runId, amount, model) {
  if (typeof amount !== 'number' || !Number.isFinite(amount) || amount < 0) {
    process.stderr.write(`[budget-guard] recordCost: amount invalide ignoré (${amount}) — runId: ${runId}\n`)
    return
  }
  ensureDir(LOG_DIR)

  /** @type {BudgetEntry[]} */
  const entries = safeReadJson(LOG_FILE, [])
  if (!Array.isArray(entries)) {
    // Fichier corrompu — repartir d'une liste vide
    const fresh = [{ runId, amount, ts: new Date().toISOString(), model: model || null }]
    atomicWriteJson(LOG_FILE, fresh)
    return
  }

  entries.push({ runId, amount, ts: new Date().toISOString(), model: model || null })

  // Trim : conserver uniquement les 90 derniers jours pour borner la croissance du fichier
  const cutoff90d = Date.now() - 90 * 24 * 60 * 60 * 1000
  const trimmed = entries.filter(e => {
    const t = new Date(e.ts).getTime()
    return !isNaN(t) && t >= cutoff90d
  })

  atomicWriteJson(LOG_FILE, trimmed)
}

// ── Agrégats ──────────────────────────────────────────────────────────────────

/**
 * Retourne le coût total enregistré depuis le début de la journée UTC.
 * @returns {number}
 */
function getDailyCost() {
  /** @type {BudgetEntry[]} */
  const entries = safeReadJson(LOG_FILE, [])
  if (!Array.isArray(entries)) return 0

  const now     = new Date()
  const dayStart = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate())

  return entries.reduce((sum, e) => {
    if (!e || typeof e.amount !== 'number') return sum
    const entryTs = new Date(e.ts).getTime()
    if (isNaN(entryTs) || entryTs < dayStart) return sum
    return sum + e.amount
  }, 0)
}

/**
 * Retourne le coût cumulé pour un sessionId (assimilé au runId dans ce contexte).
 * @param {string} sessionId
 * @returns {number}
 */
function getSessionCost(sessionId) {
  /** @type {BudgetEntry[]} */
  const entries = safeReadJson(LOG_FILE, [])
  if (!Array.isArray(entries)) return 0

  return entries.reduce((sum, e) => {
    if (!e || typeof e.amount !== 'number') return sum
    if (e.runId !== sessionId) return sum
    return sum + e.amount
  }, 0)
}

// ── Exports ───────────────────────────────────────────────────────────────────

module.exports = {
  loadBudgetConfig,
  saveBudgetConfig,
  checkBudget,
  recordCost,
  getDailyCost,
  getSessionCost,
  // ADR-023 étape 4 — gouvernance des délégations adaptatives
  checkDelegationBudget,
  recordDelegation,
  getDelegationCount,
}
