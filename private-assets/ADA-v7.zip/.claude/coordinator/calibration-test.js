#!/usr/bin/env node
'use strict'
/**
 * coordinator/calibration-test.js — Validation du scorer par fixtures de calibration.
 *
 * POURQUOI (ADR-021, principe #1 « tester le testeur ») : le mutation testing
 * (mutation-test.js) valide que le scorer ne produit pas de FAUX NÉGATIFS sur
 * de la variation stylistique légitime. Il ne valide PAS l'autre moitié du
 * principe #1 : que le scorer détecte réellement un vrai défaut quand il y en
 * a un (FAUX POSITIFS — un scorer qui dirait "100/100" à un livrable cassé).
 * Ce harnais couvre ce deuxième axe avec des fixtures écrites à la main :
 *   - ≥2 solutions correctes mais stylistiquement différentes par tâche →
 *     doivent toutes scorer au maximum.
 *   - ≥1 solution incorrecte par exigence distincte testée par la tâche →
 *     doit faire échouer EXACTEMENT les assertions corrélées à cette exigence,
 *     ni plus, ni moins (comparaison assertion par assertion, pas seulement
 *     le score global).
 *
 * Fixtures : .claude/benchmarks/v2/calibration/<taskId>/{positive-*,negative-*}.txt
 *            + expected.json (contrat attendu par fixture).
 *
 * ARCHITECTURE (même séparation que mutation-test.js) :
 *   - Couche PURE   : normalisation des entrées expected.json, comparaison
 *                     assertion-par-assertion. Testable sans Postgres
 *                     (tests/coordinator/calibration-test.test.js).
 *   - Couche IMPURE : lecture disque + exécution du scorer réel, dispatché par
 *                     catégorie via bench-v2.runScorer (SQL ou TypeScript selon
 *                     la tâche, requis PARESSEUSEMENT — ADR-021 Action 3).
 *
 * CLI :
 *   node calibration-test.js list
 *   node calibration-test.js run <taskId> [--json]
 *   node calibration-test.js run-all [--json]
 */

const { readFileSync, readdirSync, existsSync } = require('fs')
const { join } = require('path')

const COORD_DIR = __dirname
const CLAUDE_DIR = join(COORD_DIR, '..')
const TASKS_FILE = join(CLAUDE_DIR, 'benchmarks', 'v2', 'tasks-v2.json')
const CALIBRATION_DIR = join(CLAUDE_DIR, 'benchmarks', 'v2', 'calibration')

const C = { reset: '\x1b[0m', bold: '\x1b[1m', green: '\x1b[32m', red: '\x1b[31m', yellow: '\x1b[33m', cyan: '\x1b[36m', gray: '\x1b[90m' }

// ─────────────────────────────────────────────────────────────────────────────
// COUCHE PURE
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Normalise une entrée expected.json. PURE.
 * Défauts : expectFail/expectPass en tableau vide si absents. `note` est
 * documentaire, jamais utilisée dans la comparaison.
 * @returns {{expectScore:number|undefined, expectFail:string[], expectPass:string[], note:string|undefined}}
 */
function normalizeExpected(entry) {
  const e = entry || {}
  return {
    expectScore: typeof e.expectScore === 'number' ? e.expectScore : undefined,
    expectFail: Array.isArray(e.expectFail) ? e.expectFail : [],
    expectPass: Array.isArray(e.expectPass) ? e.expectPass : [],
    note: typeof e.note === 'string' ? e.note : undefined,
  }
}

/**
 * Compare le résultat RÉEL d'un scoring (score + détail des assertions) au
 * contrat `expected` d'une fixture. PURE.
 *
 * Vérifie explicitement le principe ADR-021 #1 « pas plus, pas moins » :
 * toute assertion qui échoue SANS figurer dans `expectFail` est un écart
 * (échec non prévu), même si elle n'était pas non plus dans `expectPass`.
 *
 * @param {{score:number|null, detail:any}} result
 * @param {object} expectedEntryRaw entrée brute de expected.json (ou undefined)
 * @returns {{ok:boolean, issues:string[], expected:object}}
 */
function evaluateFixture(result, expectedEntryRaw) {
  const expected = normalizeExpected(expectedEntryRaw)
  const issues = []
  if (!expectedEntryRaw) {
    issues.push('aucune entrée expected.json pour cette fixture — contrat non défini')
    return { ok: false, issues, expected }
  }

  const score = result && typeof result.score === 'number' ? result.score : null
  if (expected.expectScore !== undefined) {
    if (score !== expected.expectScore) {
      issues.push(`score attendu ${expected.expectScore}, obtenu ${score === null ? 'null (' + JSON.stringify(result && result.detail) + ')' : score}`)
    }
  }

  const assertions = (result && result.detail && Array.isArray(result.detail.assertions)) ? result.detail.assertions : []
  const byName = new Map(assertions.map(a => [a.name, a]))

  for (const name of expected.expectFail) {
    const a = byName.get(name)
    if (!a) issues.push(`assertion "${name}" (attendue en ÉCHEC) introuvable dans le détail retourné par le scorer`)
    else if (a.ok) issues.push(`assertion "${name}" attendue en ÉCHEC mais a PASSÉ (expect=${JSON.stringify(a.expect)}, got=${JSON.stringify(a.got)})`)
  }
  for (const name of expected.expectPass) {
    const a = byName.get(name)
    if (!a) issues.push(`assertion "${name}" (attendue en SUCCÈS) introuvable dans le détail retourné par le scorer`)
    else if (!a.ok) issues.push(`assertion "${name}" attendue en SUCCÈS mais a ÉCHOUÉ (expect=${JSON.stringify(a.expect)}, got=${JSON.stringify(a.got)})`)
  }

  // « pas plus, pas moins » : toute assertion qui échoue réellement doit être
  // couverte par expectFail. Sans ça, un scorer qui sur-détecte (casse des
  // assertions non visées par la mutation) passerait la comparaison alors
  // qu'il viole exactement le principe qu'on vérifie.
  if (expected.expectFail.length || expected.expectPass.length) {
    const expectedFailSet = new Set(expected.expectFail)
    for (const a of assertions) {
      if (!a.ok && !expectedFailSet.has(a.name)) {
        issues.push(`assertion "${a.name}" a échoué SANS être attendue en échec (expect=${JSON.stringify(a.expect)}, got=${JSON.stringify(a.got)}) — échec non prévu`)
      }
    }
  }

  return { ok: issues.length === 0, issues, expected }
}

/**
 * Fixtures attendues d'un dossier de tâche à partir de la liste de fichiers. PURE.
 * Exclut `expected.json`. Trie positive-* avant negative-* puis alphabétique.
 * @param {string[]} filenames
 * @returns {string[]}
 */
function listFixtureFiles(filenames) {
  return (filenames || [])
    .filter(f => f.endsWith('.txt'))
    .sort((a, b) => {
      const rank = (f) => (f.startsWith('positive-') ? 0 : f.startsWith('negative-') ? 1 : 2)
      const ra = rank(a), rb = rank(b)
      return ra !== rb ? ra - rb : a.localeCompare(b)
    })
}

// ─────────────────────────────────────────────────────────────────────────────
// COUCHE IMPURE — IO + scorer réel
// ─────────────────────────────────────────────────────────────────────────────

function loadTasks() {
  try { return JSON.parse(readFileSync(TASKS_FILE, 'utf8')).tasks || [] } catch { return [] }
}

/** Charge bench-v2.js PARESSEUSEMENT (mêmes raisons que mutation-test.js). */
function loadBench(benchPath) {
  return require(benchPath || join(COORD_DIR, 'bench-v2.js'))
}

/** Liste les dossiers de tâches calibrées présents sur disque. IMPUR (fs). */
function listCalibratedTaskIds() {
  if (!existsSync(CALIBRATION_DIR)) return []
  return readdirSync(CALIBRATION_DIR, { withFileTypes: true })
    .filter(d => d.isDirectory())
    .map(d => d.name)
    .sort()
}

/** Charge expected.json d'une tâche (objet vide si absent). IMPUR (fs). */
function loadExpectedFile(taskId) {
  const p = join(CALIBRATION_DIR, taskId, 'expected.json')
  try { return JSON.parse(readFileSync(p, 'utf8')) } catch { return {} }
}

/** Liste les fichiers fixture (.txt) présents pour une tâche. IMPUR (fs). */
function loadFixtureFilenames(taskId) {
  const dir = join(CALIBRATION_DIR, taskId)
  if (!existsSync(dir)) return []
  return listFixtureFiles(readdirSync(dir))
}

let dbCounter = 0
function nextSuffix() { return `cal${process.pid}${(dbCounter++).toString(36)}` }

/**
 * Lance la calibration d'une tâche : score chaque fixture avec le VRAI scorer
 * et compare au contrat expected.json. IMPUR (psql via bench-v2).
 * @returns {{taskId, rows: Array<{fixture, ok, issues, score}>, missingExpected: string[]}}
 */
function runCalibration(bench, task, taskId, opts = {}) {
  const expectedAll = loadExpectedFile(taskId)
  const fixtures = loadFixtureFilenames(taskId)
  const rows = []
  // Dispatch par catégorie (bench.runScorer), pas un scorer figé : une tâche
  // 'correction-reelle'/'conventions-tacites'/'above-threshold' passe par le
  // scorer SQL, une tâche 'correction-reelle-ts' par le scorer TypeScript
  // (bench-v2-ts.js, ADR-021 Action 3) — même harnais de calibration pour les
  // deux domaines, pas un script de vérification ad hoc par domaine.
  const category = (task.categories || [])[0]
  for (const fixture of fixtures) {
    const text = readFileSync(join(CALIBRATION_DIR, taskId, fixture), 'utf8')
    const result = bench.runScorer(category, task, text, nextSuffix())
    const evalRes = evaluateFixture(result, expectedAll[fixture])
    const row = { fixture, ok: evalRes.ok, issues: evalRes.issues, score: result && result.score }
    rows.push(row)
    if (opts.onRow) opts.onRow(row)
  }
  // Entrées expected.json qui ne correspondent à AUCUN fichier fixture présent
  // (contrat orphelin — signale un rename/suppression pas répercuté).
  const fixtureSet = new Set(fixtures)
  const orphanExpected = Object.keys(expectedAll).filter(k => !fixtureSet.has(k))
  return { taskId, rows, orphanExpected }
}

// ─────────────────────────────────────────────────────────────────────────────
// CLI
// ─────────────────────────────────────────────────────────────────────────────
function parseFlags(argv) {
  const flags = {}
  const positional = []
  for (const a of argv) {
    if (a.startsWith('--')) flags[a.slice(2)] = true
    else positional.push(a)
  }
  return { flags, positional }
}

function badge(ok) { return ok ? `${C.green}CONFORME${C.reset}` : `${C.red}ÉCART${C.reset}` }

function printCalibration(res) {
  console.log(`\n${C.bold}▶ ${res.taskId}${C.reset}`)
  if (!res.rows.length) {
    console.log(`  ${C.yellow}aucune fixture trouvée${C.reset}`)
    return
  }
  for (const row of res.rows) {
    console.log(`  ${badge(row.ok).padEnd(20)} ${row.fixture.padEnd(40)} score=${row.score}`)
    for (const issue of row.issues) console.log(`      ${C.red}✗ ${issue}${C.reset}`)
  }
  if (res.orphanExpected.length) {
    console.log(`  ${C.yellow}expected.json contient des entrées sans fixture: ${res.orphanExpected.join(', ')}${C.reset}`)
  }
}

function main(argv) {
  const cmd = argv[2]
  const { flags, positional } = parseFlags(argv.slice(3))

  if (cmd === 'list' || !cmd) {
    const ids = listCalibratedTaskIds()
    console.log(`${C.bold}calibration-test — tâches calibrées (${ids.length})${C.reset}\n`)
    for (const id of ids) {
      const fixtures = loadFixtureFilenames(id)
      const pos = fixtures.filter(f => f.startsWith('positive-')).length
      const neg = fixtures.filter(f => f.startsWith('negative-')).length
      console.log(`  ${C.cyan}${id.padEnd(38)}${C.reset} ${pos} positive(s), ${neg} negative(s)`)
    }
    console.log(`\n${C.gray}node calibration-test.js run <taskId> [--json]`)
    console.log(`node calibration-test.js run-all [--json]${C.reset}`)
    return
  }

  const tasks = loadTasks()
  let bench
  try { bench = loadBench(flags.bench) } catch (e) {
    console.error(`${C.red}bench-v2.js inutilisable: ${e.message}${C.reset}`)
    process.exit(1)
  }

  let taskIds = []
  if (cmd === 'run') {
    taskIds = positional
    if (!taskIds.length) { console.error('usage: run <taskId> [<taskId2> ...]'); process.exit(1) }
  } else if (cmd === 'run-all') {
    taskIds = listCalibratedTaskIds()
  } else {
    console.error(`commande inconnue: ${cmd}`); process.exit(1)
  }

  const all = []
  for (const taskId of taskIds) {
    const task = tasks.find(t => t.id === taskId)
    if (!task) { console.error(`${C.red}tâche introuvable dans tasks-v2.json: ${taskId}${C.reset}`); continue }
    const res = runCalibration(bench, task, taskId)
    if (!flags.json) printCalibration(res)
    all.push(res)
  }

  if (flags.json) { console.log(JSON.stringify(all, null, 2)); return }

  const totalRows = all.flatMap(r => r.rows)
  const okCount = totalRows.filter(r => r.ok).length
  const failCount = totalRows.length - okCount
  console.log(`\n${C.bold}Synthèse — ${all.length} tâche(s), ${totalRows.length} fixture(s)${C.reset}`)
  console.log(`  ${C.green}conforme${C.reset}=${okCount}  ${C.red}écart${C.reset}=${failCount}`)
  if (failCount) {
    console.log(`\n${C.red}${C.bold}Le scorer N'EST PAS calibré : ${failCount} fixture(s) en écart.${C.reset}`)
    process.exitCode = 1
  } else if (totalRows.length) {
    console.log(`\n${C.green}${C.bold}Scorer calibré : toutes les fixtures se comportent comme attendu.${C.reset}`)
  } else {
    console.log(`\n${C.yellow}Aucune fixture évaluée.${C.reset}`)
    process.exitCode = 1
  }
}

module.exports = {
  // pure
  normalizeExpected, evaluateFixture, listFixtureFiles,
  // impure
  loadTasks, loadBench, listCalibratedTaskIds, loadExpectedFile, loadFixtureFilenames,
  runCalibration, CALIBRATION_DIR,
}

if (require.main === module) main(process.argv)
