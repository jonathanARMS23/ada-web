#!/usr/bin/env node
'use strict'
/**
 * codemod.js — Tier 0 déterministe ($0, ~1ms) sous le tier 1 (haiku).
 *
 * Transformations mécaniques SÛRES exécutées sans LLM. La valeur mesurée d'ADA
 * est le routing de tier ; un tier $0 pour les transformations purement
 * mécaniques est un gain de coût net (0 token, 0 latence réseau).
 *
 * OPTION DE PARSING RETENUE : (a) lexer maison prudent (tokenisation avec suivi
 * d'état quotes/commentaires/templates/regex), PAS de parser AST.
 * Justification : ADA est zéro-dépendance npm — pas de TypeScript compiler API,
 * pas de Babel. Un lexer suffit car les 3 intents visés n'ont besoin QUE de
 * savoir, pour chaque caractère, s'il est du code réel ou du texte inerte
 * (string / commentaire / template / regex). Toute la sécurité repose sur ce
 * masque + des gardes conservateurs : au moindre doute (pattern ambigu, code
 * inhabituel) → NE PAS transformer et reporter « skipped ». Jamais de
 * transformation risquée silencieuse.
 *
 * INTENTS SÛRS (uniquement) :
 *   - remove-console            retire les statements console.log/debug/info
 *                               STANDALONE (garde console.error/warn)
 *   - var-to-const              var → const (jamais réassignée) sinon → let,
 *                               avec analyse conservatrice de scope
 *   - strip-trailing-whitespace espaces de fin + newline finale unique
 *
 * Les intents à jugement (add-types, add-error-handling, async-await) NE SONT
 * PAS des codemods : ils cassent du code s'ils sont devinés → routés vers un
 * modèle (tier 2/3).
 *
 * CLI :
 *   node codemod.js <intent> <file...> [--dry-run] [--json]
 *
 * API :
 *   applyCodemod(intent, code, opts) →
 *     { intent, ok, changed, output, edits, skipped, reasons }
 */

// ── Masque lexical ────────────────────────────────────────────────────────────
const CODE = 0
const LINE_COMMENT = 1
const BLOCK_COMMENT = 2
const STRING = 3
const TEMPLATE = 4
const REGEX = 5

// Un `/` démarre une regex si le dernier token de code significatif implique
// qu'une VALEUR est attendue (début d'expression), sinon c'est une division.
const REGEX_PREFIX_KW = /(^|[^\w$])(return|typeof|instanceof|in|of|new|delete|void|do|else|yield|await|case|throw)$/
const REGEX_PREFIX_CH = '(,=:[!&|?{};~^%*<>' // + début de fichier

function isRegexStart(lastSig, codeTail) {
  if (lastSig === '') return true
  if (REGEX_PREFIX_CH.includes(lastSig)) return true
  if (REGEX_PREFIX_KW.test(codeTail)) return true
  return false
}

/**
 * Scanne la source et retourne un masque par caractère + un flag `terminated`.
 * `terminated` est faux si la source se termine dans un état non-code
 * (string/template/commentaire/interpolation non fermés) → signal de non-sûreté.
 *
 * @param {string} code
 * @returns {{mask: Uint8Array, terminated: boolean}}
 */
function scanMask(code) {
  const n = code.length
  const mask = new Uint8Array(n) // 0 = CODE par défaut
  let i = 0
  let mode = 'code' // code | line | block | sq | dq | tpl | regex | regexClass
  const interps = [] // profondeur d'accolades des ${} actifs
  let lastSig = ''
  let codeTail = ''

  const pushTail = (c) => { if (!/\s/.test(c)) { lastSig = c; codeTail = (codeTail + c).slice(-24) } }

  while (i < n) {
    const c = code[i]
    const c2 = i + 1 < n ? code[i + 1] : ''

    if (mode === 'code') {
      if (c === '/' && c2 === '/') { mode = 'line'; mask[i] = LINE_COMMENT; mask[i + 1] = LINE_COMMENT; i += 2; continue }
      if (c === '/' && c2 === '*') { mode = 'block'; mask[i] = BLOCK_COMMENT; mask[i + 1] = BLOCK_COMMENT; i += 2; continue }
      if (c === "'") { mode = 'sq'; mask[i] = STRING; i++; continue }
      if (c === '"') { mode = 'dq'; mask[i] = STRING; i++; continue }
      if (c === '`') { mode = 'tpl'; mask[i] = TEMPLATE; i++; continue }
      if (c === '/') {
        if (isRegexStart(lastSig, codeTail)) { mode = 'regex'; mask[i] = REGEX; i++; continue }
        mask[i] = CODE; pushTail('/'); i++; continue
      }
      if (c === '{') { if (interps.length) interps[interps.length - 1]++ }
      else if (c === '}') {
        if (interps.length && interps[interps.length - 1] === 0) {
          interps.pop(); mode = 'tpl'; mask[i] = TEMPLATE; lastSig = '}'; codeTail = ''; i++; continue
        } else if (interps.length) interps[interps.length - 1]--
      }
      mask[i] = CODE; pushTail(c); i++; continue
    }

    if (mode === 'line') {
      mask[i] = LINE_COMMENT
      if (c === '\n') mode = 'code'
      i++; continue
    }

    if (mode === 'block') {
      mask[i] = BLOCK_COMMENT
      if (c === '*' && c2 === '/') { mask[i + 1] = BLOCK_COMMENT; i += 2; mode = 'code'; continue }
      i++; continue
    }

    if (mode === 'sq' || mode === 'dq') {
      mask[i] = STRING
      if (c === '\\') { if (i + 1 < n) mask[i + 1] = STRING; i += 2; continue }
      const q = mode === 'sq' ? "'" : '"'
      if (c === q) { mode = 'code'; pushTail('"') }
      i++; continue
    }

    if (mode === 'tpl') {
      mask[i] = TEMPLATE
      if (c === '\\') { if (i + 1 < n) mask[i + 1] = TEMPLATE; i += 2; continue }
      if (c === '`') { mode = 'code'; pushTail('`'); i++; continue }
      if (c === '$' && c2 === '{') { mask[i + 1] = TEMPLATE; interps.push(0); mode = 'code'; i += 2; continue }
      i++; continue
    }

    if (mode === 'regex') {
      mask[i] = REGEX
      if (c === '\\') { if (i + 1 < n) mask[i + 1] = REGEX; i += 2; continue }
      if (c === '[') { mode = 'regexClass'; i++; continue }
      if (c === '/') { mode = 'code'; pushTail('/'); i++; continue }
      if (c === '\n') { mode = 'code' } // regex non terminée → on abandonne prudemment
      i++; continue
    }

    if (mode === 'regexClass') {
      mask[i] = REGEX
      if (c === '\\') { if (i + 1 < n) mask[i + 1] = REGEX; i += 2; continue }
      if (c === ']') { mode = 'regex'; i++; continue }
      if (c === '\n') { mode = 'code' }
      i++; continue
    }

    i++
  }

  const terminated = mode === 'code' && interps.length === 0
  return { mask, terminated }
}

// ── Utilitaires ────────────────────────────────────────────────────────────────
const isIdentChar = (ch) => ch != null && /[\w$]/.test(ch)

function applyEdits(code, edits) {
  const sorted = [...edits].sort((a, b) => b.start - a.start)
  let out = code
  for (const e of sorted) out = out.slice(0, e.start) + (e.replacement || '') + out.slice(e.end)
  return out
}

// Filtre les edits qui se chevauchent (garde le premier par ordre de départ).
function dropOverlaps(edits) {
  const sorted = [...edits].sort((a, b) => a.start - b.start)
  const kept = []
  let lastEnd = -1
  for (const e of sorted) {
    if (e.start < lastEnd) continue
    kept.push(e); lastEnd = e.end
  }
  return kept
}

function lineStartOffset(code, pos) {
  let i = pos
  while (i > 0 && code[i - 1] !== '\n') i--
  return i
}

function lineEndOffset(code, pos) {
  let i = pos
  while (i < code.length && code[i] !== '\n') i++
  return i
}

// Équilibre des délimiteurs (dans les régions CODE uniquement) : filet de sécurité.
function balance(code) {
  const { mask, terminated } = scanMask(code)
  let p = 0, b = 0, k = 0
  for (let i = 0; i < code.length; i++) {
    if (mask[i] !== CODE) continue
    const c = code[i]
    if (c === '(') p++; else if (c === ')') p--
    else if (c === '{') b++; else if (c === '}') b--
    else if (c === '[') k++; else if (c === ']') k--
  }
  return { terminated, ok: terminated && p === 0 && b === 0 && k === 0 }
}

// ── strip-trailing-whitespace ───────────────────────────────────────────────────
function stripTrailing(code, mask) {
  const n = code.length
  let out = ''
  let edits = 0
  let lineStart = 0

  for (let i = 0; i <= n; i++) {
    if (i === n || code[i] === '\n') {
      const end = i
      let k = end
      while (k > lineStart && (code[k - 1] === ' ' || code[k - 1] === '\t')) k--
      // La whitespace de fin est-elle significative (dans une string/template/regex) ?
      let strip = true
      for (let p = k; p < end; p++) {
        const m = mask[p]
        if (m === STRING || m === TEMPLATE || m === REGEX) { strip = false; break }
      }
      if (strip && k < end) edits++
      out += strip ? code.slice(lineStart, k) : code.slice(lineStart, end)
      if (i < n) out += '\n'
      lineStart = i + 1
    }
  }

  // Normalisation fin de fichier : newline finale unique, pas de lignes vides finales.
  let normalized = out
  if (normalized.replace(/\s/g, '') === '') {
    normalized = ''
  } else {
    normalized = normalized.replace(/\n+$/, '\n')
    if (!normalized.endsWith('\n')) normalized += '\n'
  }

  const changed = normalized !== code
  if (changed && edits === 0) edits = 1
  return { changed, output: normalized, edits, skipped: 0, reasons: [] }
}

// ── remove-console ──────────────────────────────────────────────────────────────
const CONSOLE_RE = /\bconsole\s*\.\s*(log|debug|info)\s*\(/g

function matchParen(code, mask, openIdx) {
  // openIdx pointe sur '(' ; retourne l'index du ')' correspondant, ou -1.
  let depth = 0
  for (let j = openIdx; j < code.length; j++) {
    if (mask[j] !== CODE) continue
    const c = code[j]
    if (c === '(') depth++
    else if (c === ')') { depth--; if (depth === 0) return j }
  }
  return -1
}

function removeConsole(code, mask) {
  const edits = []
  const reasons = []
  let skipped = 0
  CONSOLE_RE.lastIndex = 0
  let m
  while ((m = CONSOLE_RE.exec(code)) !== null) {
    const start = m.index
    if (mask[start] !== CODE) continue // console dans une string / commentaire

    const openParen = m.index + m[0].length - 1
    const closeParen = matchParen(code, mask, openParen)
    if (closeParen === -1) { skipped++; reasons.push('appel console non fermé — skippé'); continue }

    // Fin de statement : après ')', whitespace optionnel puis ';' optionnel.
    let stmtEnd = closeParen + 1
    let q = stmtEnd
    while (q < code.length && (code[q] === ' ' || code[q] === '\t')) q++
    if (code[q] === ';') stmtEnd = q + 1

    // Standalone ? Avant `console` sur sa ligne = whitespace uniquement.
    const firstLineStart = lineStartOffset(code, start)
    const leadingBlank = code.slice(firstLineStart, start).trim() === ''
    // Après stmtEnd sur la dernière ligne = whitespace uniquement (pas de commentaire orphelin).
    const lastLineEnd = lineEndOffset(code, stmtEnd)
    const trailingBlank = code.slice(stmtEnd, lastLineEnd).trim() === ''

    if (leadingBlank && trailingBlank) {
      const dropEnd = lastLineEnd < code.length ? lastLineEnd + 1 : lastLineEnd
      edits.push({ start: firstLineStart, end: dropEnd, replacement: '' })
    } else {
      skipped++
      reasons.push('console non-standalone (arrow body / valeur / inline) — skippé')
    }
  }

  const clean = dropOverlaps(edits)
  const output = applyEdits(code, clean)
  return { changed: output !== code, output, edits: clean.length, skipped, reasons }
}

// ── var-to-const ─────────────────────────────────────────────────────────────────
const VAR_RE = /\bvar\b/g

function firstIdentAfter(code, from) {
  let i = from
  while (i < code.length && /\s/.test(code[i])) i++
  const mres = /^[A-Za-z_$][\w$]*/.exec(code.slice(i))
  if (!mres) return null
  return { name: mres[0], start: i, end: i + mres[0].length }
}

// Toutes les occurrences du mot `name` en région CODE.
function identOccurrences(code, mask, name) {
  const out = []
  const re = new RegExp(`\\b${name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'g')
  let m
  while ((m = re.exec(code)) !== null) {
    if (mask[m.index] === CODE && code[m.index - 1] !== '.') out.push(m.index)
  }
  return out
}

function isReassignedAt(code, name, idx) {
  const after = idx + name.length
  // suffix : name = / name += / name++ ...
  let j = after
  while (j < code.length && (code[j] === ' ' || code[j] === '\t')) j++
  const tail = code.slice(j, j + 3)
  if (/^\+\+/.test(tail) || /^--/.test(tail)) return true
  if (/^(\+=|-=|\*=|\/=|%=|&=|\|=|\^=)/.test(tail)) return true
  if (/^(\*\*=|<<=|>>=|&&=|\|\|=|\?\?=)/.test(tail)) return true
  if (/^>>>=/.test(code.slice(j, j + 4))) return true
  // '=' simple mais pas ==, ===, =>
  if (tail[0] === '=' && tail[1] !== '=' && tail[1] !== '>') return true
  // prefix : ++name / --name
  let p = idx - 1
  while (p >= 0 && (code[p] === ' ' || code[p] === '\t')) p--
  if (p >= 1 && ((code[p - 1] === '+' && code[p] === '+') || (code[p - 1] === '-' && code[p] === '-'))) return true
  return false
}

function varToConst(code, mask) {
  const edits = []
  const reasons = []
  let skipped = 0
  VAR_RE.lastIndex = 0
  let m
  while ((m = VAR_RE.exec(code)) !== null) {
    const varStart = m.index
    if (mask[varStart] !== CODE) continue // "var" dans string/commentaire

    try {
      // for (var ...) → skip conservateur.
      const lineStart = lineStartOffset(code, varStart)
      const before = code.slice(lineStart, varStart)
      if (/\bfor\s*\(\s*$/.test(before)) { skipped++; reasons.push('var dans un for-header — skippé'); continue }

      // Déclarateur : le premier token doit être un identifiant (pas { ou [).
      let after = varStart + 3
      while (after < code.length && /\s/.test(code[after])) after++
      if (code[after] === '{' || code[after] === '[') { skipped++; reasons.push('déclarateur destructuré — skippé'); continue }
      const id = firstIdentAfter(code, varStart + 3)
      if (!id) { skipped++; reasons.push('déclarateur non identifiable — skippé'); continue }
      const name = id.name

      // Déclarateurs multiples (virgule de niveau 0 avant fin de statement) → skip.
      const stmtEnd = (() => {
        let depth = 0
        for (let j = id.end; j < code.length; j++) {
          if (mask[j] !== CODE) continue
          const c = code[j]
          if (c === '(' || c === '[' || c === '{') depth++
          else if (c === ')' || c === ']' || c === '}') depth--
          else if (depth === 0 && (c === ';' || c === '\n')) return j
          else if (depth === 0 && c === ',') return -1 // virgule de niveau 0
        }
        return code.length
      })()
      if (stmtEnd === -1) { skipped++; reasons.push('déclarateurs multiples — skippé'); continue }

      // Occurrences du nom (code uniquement).
      const occ = identOccurrences(code, mask, name)
      const declOcc = occ.find((o) => o === id.start)

      // Utilisée avant déclaration → skip (hoisting/TDZ).
      if (occ.some((o) => o < id.start)) { skipped++; reasons.push(`${name} utilisée avant déclaration — skippé`); continue }

      // Redéclarée → skip.
      const declRe = new RegExp(`\\b(var|let|const)\\s+${name}\\b`, 'g')
      let declCount = 0, dm
      while ((dm = declRe.exec(code)) !== null) { if (mask[dm.index] === CODE) declCount++ }
      if (declCount > 1) { skipped++; reasons.push(`${name} redéclarée — skippé`); continue }

      // Échappement de scope de bloc : bloc englobant → usage après sa fermeture ?
      const enclosing = (() => {
        let depth = 0
        for (let j = varStart - 1; j >= 0; j--) {
          if (mask[j] !== CODE) continue
          const c = code[j]
          if (c === '}') depth++
          else if (c === '{') { if (depth === 0) return j; depth-- }
        }
        return -1
      })()
      if (enclosing !== -1) {
        // trouver le '}' correspondant
        let depth = 0, closeIdx = -1
        for (let j = enclosing; j < code.length; j++) {
          if (mask[j] !== CODE) continue
          if (code[j] === '{') depth++
          else if (code[j] === '}') { depth--; if (depth === 0) { closeIdx = j; break } }
        }
        if (closeIdx !== -1 && occ.some((o) => o > closeIdx)) {
          skipped++; reasons.push(`${name} utilisée hors de son bloc — skippé`); continue
        }
      }

      // const vs let : réassignée quelque part (hors déclaration) ?
      let reassigned = false
      for (const o of occ) {
        if (o === declOcc) continue
        if (isReassignedAt(code, name, o)) { reassigned = true; break }
      }
      // Heuristique destructuring-assignment : `[... name ...] =` / `{... name ...} =`.
      if (!reassigned) {
        const destrRe = new RegExp(`[\\[{][^\\]}\\n]*\\b${name}\\b[^\\]}\\n]*[\\]}]\\s*=[^=]`, 'g')
        let dmm
        while ((dmm = destrRe.exec(code)) !== null) {
          const ls = lineStartOffset(code, dmm.index)
          const lineTxt = code.slice(ls, lineEndOffset(code, dmm.index))
          if (mask[dmm.index] === CODE && !/^\s*(var|let|const)\b/.test(lineTxt)) { reassigned = true; break }
        }
      }

      const keyword = reassigned ? 'let' : 'const'
      edits.push({ start: varStart, end: varStart + 3, replacement: keyword })
    } catch (e) {
      skipped++
      reasons.push(`cas inhabituel — skippé (${e.message})`)
    }
  }

  const output = applyEdits(code, edits)
  return { changed: output !== code, output, edits: edits.length, skipped, reasons }
}

// ── API publique ─────────────────────────────────────────────────────────────────
const TRANSFORMS = {
  'strip-trailing-whitespace': stripTrailing,
  'remove-console': removeConsole,
  'var-to-const': varToConst,
}
const INTENTS = Object.freeze(Object.keys(TRANSFORMS))

function isSupportedIntent(intent) {
  return Object.prototype.hasOwnProperty.call(TRANSFORMS, intent)
}

/**
 * Applique un codemod déterministe à une source.
 * Ne jette jamais : reporte `ok:false` / `skipped` avec une raison.
 * Garantit qu'un transform n'introduit pas de déséquilibre de délimiteurs
 * (sinon il rend la source inchangée).
 *
 * @param {string} intent
 * @param {string} code
 * @param {{}} [opts]
 * @returns {{intent:string, ok:boolean, changed:boolean, output:string, edits:number, skipped:number, reasons:string[]}}
 */
function applyCodemod(intent, code, opts = {}) {
  code = String(code == null ? '' : code)
  if (!isSupportedIntent(intent)) {
    return { intent, ok: false, changed: false, output: code, edits: 0, skipped: 0, reasons: [`intent non supporté "${intent}" — route vers un modèle`] }
  }

  const { mask, terminated } = scanMask(code)
  if (!terminated) {
    return { intent, ok: false, changed: false, output: code, edits: 0, skipped: 1, reasons: ['source avec string/template/commentaire non terminé — skippé par sûreté'] }
  }

  let res
  try {
    res = TRANSFORMS[intent](code, mask)
  } catch (e) {
    return { intent, ok: true, changed: false, output: code, edits: 0, skipped: 1, reasons: [`erreur interne — skippé : ${e.message}`] }
  }

  // Filet de sécurité : ne jamais rendre une source moins équilibrée que l'entrée.
  if (res.changed) {
    const before = balance(code)
    const after = balance(res.output)
    if (before.ok && !after.ok) {
      return { intent, ok: true, changed: false, output: code, edits: 0, skipped: (res.skipped || 0) + 1, reasons: [...(res.reasons || []), 'transform déséquilibrerait les délimiteurs — abandonné'] }
    }
  }

  return { intent, ok: true, changed: res.changed, output: res.output, edits: res.edits, skipped: res.skipped || 0, reasons: res.reasons || [] }
}

module.exports = { applyCodemod, INTENTS, isSupportedIntent, scanMask }

// ── CLI ────────────────────────────────────────────────────────────────────────
function miniDiff(before, after) {
  const a = before.split('\n')
  const b = after.split('\n')
  const out = []
  const max = Math.max(a.length, b.length)
  for (let i = 0; i < max; i++) {
    if (a[i] === b[i]) continue
    if (a[i] !== undefined) out.push(`\x1b[31m- ${a[i]}\x1b[0m`)
    if (b[i] !== undefined) out.push(`\x1b[32m+ ${b[i]}\x1b[0m`)
  }
  return out.join('\n')
}

function runCli(argv) {
  const fs = require('fs')
  const args = argv.slice(2)
  const dryRun = args.includes('--dry-run')
  const json = args.includes('--json')
  const rest = args.filter((a) => !a.startsWith('--'))
  const intent = rest[0]
  const files = rest.slice(1)

  if (!intent || !isSupportedIntent(intent) || files.length === 0) {
    process.stderr.write(
      `Usage : node codemod.js <intent> <file...> [--dry-run] [--json]\n` +
      `Intents : ${INTENTS.join(', ')}\n`)
    process.exit(1)
  }

  const report = { intent, dryRun, changed: 0, skipped: 0, reasons: [], files: [] }

  for (const file of files) {
    let src
    try {
      src = fs.readFileSync(file, 'utf8')
    } catch (e) {
      report.files.push({ file, error: e.message, changed: false, edits: 0, skipped: 0, reasons: [e.message] })
      continue
    }
    const r = applyCodemod(intent, src)
    const entry = { file, changed: r.changed, edits: r.edits, skipped: r.skipped, reasons: r.reasons, ok: r.ok }
    report.files.push(entry)
    if (r.changed) report.changed++
    report.skipped += r.skipped
    for (const rs of r.reasons) report.reasons.push(`${file}: ${rs}`)

    if (r.changed && !dryRun) {
      fs.writeFileSync(file, r.output)
    }
    if (!json) {
      if (r.changed) {
        console.log(`\x1b[1m${file}\x1b[0m — ${r.edits} edit(s)${dryRun ? ' (dry-run)' : ' (écrit)'}`)
        if (dryRun) console.log(miniDiff(src, r.output))
      } else {
        console.log(`\x1b[2m${file}\x1b[0m — inchangé${r.skipped ? ` (${r.skipped} skippé)` : ''}`)
      }
      for (const rs of r.reasons) console.log(`  \x1b[33m⚠\x1b[0m ${rs}`)
    }
  }

  if (json) {
    process.stdout.write(JSON.stringify(report, null, 2) + '\n')
  } else {
    console.log('─'.repeat(50))
    console.log(`  ${report.changed} fichier(s) changé(s), ${report.skipped} site(s) skippé(s)`)
  }
}

if (require.main === module) {
  runCli(process.argv)
}
