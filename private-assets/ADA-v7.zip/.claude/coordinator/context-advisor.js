#!/usr/bin/env node
/**
 * coordinator/context-advisor.js — Adaptive Context Window (ACW)
 *
 * API publique :
 *   buildPhaseContext(phaseId, agent, taskDescription, errorContext?) → Promise<ContextResult>
 *   injectContext(prompt, context) → string
 *
 * ContextResult : {
 *   trajectories: Trajectory[],
 *   lesson: string,
 *   injected: boolean,
 *   summary: string,
 * }
 *
 * Contraintes :
 *   - CJS uniquement (require/module.exports)
 *   - Timeout 2s sur toutes les ops async
 *   - Ne jamais bloquer si bank.js indisponible
 *   - Fallback à contexte vide si erreur
 */

'use strict'

const { existsSync } = require('fs')
const { join }       = require('path')
const { guardInjection } = require('./never-worse.js')

// Garde « jamais pire » sur buildCachedSystemBlock() — voir plus bas. Ratio large :
// le contexte dynamique (ACW) est censé rester petit face aux instructions
// statiques de l'agent ; ce seuil ne mord que si la partie dynamique dérive vers
// une taille disproportionnée (bug), jamais en usage normal.
const CACHED_BLOCK_MAX_RATIO = 20

/**
 * Applique guardInjection(base, dynamic) mais renvoie SEULEMENT la partie
 * dynamique (tronquée ou omise le cas échéant), sans le préfixe `base`.
 * Nécessaire ici : static/dynamic doivent rester deux blocs séparés pour que
 * cache_control ne porte que sur la partie statique (cf. buildCachedSystemBlock).
 * @param {string} base
 * @param {string} dynamic
 * @param {number} maxRatio
 * @returns {string}
 */
function guardedDynamicContent(base, dynamic, maxRatio) {
  if (!dynamic) return ''
  const combined = guardInjection(base, dynamic, { maxRatio })
  if (!base) return combined              // pas de base → rien à retirer
  if (combined === base) return ''        // omis : aucune marge disponible
  const prefix = `${base}\n\n`
  return combined.startsWith(prefix) ? combined.slice(prefix.length) : combined
}

// NOTE: résolu dynamiquement à l'appel (pas à l'init) pour permettre le mock en test
function configDir() {
  return process.env.CLAUDE_CONFIG_DIR || join(process.env.HOME ?? '', '.claude')
}
function bankFile()  { return join(configDir(), 'coordinator', 'bank.js') }
function mlFile()    { return join(configDir(), 'coordinator', 'micro-lessons.js') }

// ── Résultat vide (fallback gracieux) ─────────────────────────────────────────

const EMPTY_CONTEXT = Object.freeze({
  trajectories: [],
  lesson: '',
  injected: false,
  summary: '',
})

// ── Timeout helper ────────────────────────────────────────────────────────────

/**
 * Exécute une Promise avec un timeout strict.
 * @template T
 * @param {Promise<T>} promise
 * @param {number} ms
 * @param {T} fallback
 * @returns {Promise<T>}
 */
function withTimeout(promise, ms, fallback) {
  return new Promise(resolve => {
    const timer = setTimeout(() => resolve(fallback), ms)
    promise.then(
      v => { clearTimeout(timer); resolve(v) },
      () => { clearTimeout(timer); resolve(fallback) },
    )
  })
}

// ── Estimation grossière du nombre de tokens (~4 chars/token) ─────────────────

function estimateTokens(text) {
  return Math.ceil((text || '').length / 4)
}

// ── Chargement défensif de bank.js ────────────────────────────────────────────

function loadBank() {
  const f = bankFile()
  if (!existsSync(f)) return null
  try {
    return require(f)
  } catch {
    return null
  }
}

// ── Chargement défensif de micro-lessons.js ───────────────────────────────────

function loadMicroLessons() {
  const f = mlFile()
  if (!existsSync(f)) return null
  try {
    return require(f)
  } catch {
    return null
  }
}

// ── Résumé condensé des trajectoires (max ~500 tokens) ───────────────────────

/**
 * Résume les trajectoires filtrées en une chaîne concise.
 * @param {object[]} trajectories
 * @param {string}   lesson
 * @param {object|null} errorContext
 * @returns {string}
 */
function buildSummary(trajectories, lesson, errorContext) {
  if (!trajectories.length && !lesson) return ''

  const ids     = trajectories.map(t => t.id).filter(Boolean)
  const total   = trajectories.length
  const success = trajectories.filter(t => t.verdict === 'success').length
  const pct     = total ? Math.round((success / total) * 100) : 0

  const durations = trajectories.map(t => t.duration).filter(n => typeof n === 'number' && n > 0)
  const avgMin    = durations.length
    ? Math.round(durations.reduce((a, b) => a + b, 0) / durations.length / 60)
    : null

  const parts = []
  if (ids.length)  parts.push(`Similar past runs: [${ids.slice(0, 5).join(', ')}]`)
  if (total)       parts.push(`avg success: ${pct}%`)
  if (avgMin !== null) parts.push(`avg duration: ${avgMin}min`)
  if (errorContext?.pattern) parts.push(`failure pattern: ${errorContext.pattern}`)

  const header  = parts.join(' | ')
  const lessonLine = lesson ? `Key lessons: ${lesson}` : ''
  const summary = [header, lessonLine].filter(Boolean).join('\n')

  // Tronquer si trop long (garde <500 tokens estimés)
  const MAX_CHARS = 500 * 4
  return summary.length > MAX_CHARS ? summary.slice(0, MAX_CHARS) + '…' : summary
}

// ── API publique : buildPhaseContext ─────────────────────────────────────────

/**
 * Construit le contexte ACW pour une phase avant spawn de l'agent.
 *
 * @param {string}      phaseId         Identifiant de la phase
 * @param {string}      agent           Nom de l'agent assigné
 * @param {string}      taskDescription Description de la tâche (utilisée pour la recherche k-NN)
 * @param {object|null} [errorContext]  Si fourni → inclure aussi les trajectoires 'failure'
 * @returns {Promise<typeof EMPTY_CONTEXT>}
 */
async function buildPhaseContext(phaseId, agent, taskDescription, errorContext = null) {
  try {
    const bank = loadBank()
    const ml   = loadMicroLessons()

    // ── 1. Récupérer les trajectoires similaires (timeout 2s) ─────────────────
    let rawTrajectories = []
    if (bank && taskDescription) {
      // Préférer retrieveAsync (Ollama + HNSW) avec fallback TF-IDF intégré dans bank.js
      const bankPromise = typeof bank.retrieveAsync === 'function'
        ? bank.retrieveAsync(taskDescription, { limit: 5 })
        : Promise.resolve(bank.retrieve ? bank.retrieve(taskDescription, { limit: 5 }) : [])

      rawTrajectories = await withTimeout(bankPromise, 2000, [])
      if (!Array.isArray(rawTrajectories)) rawTrajectories = []
    }

    // ── 2. Récupérer la micro-lesson de la phase (timeout 2s) ────────────────
    let lesson = ''
    if (ml && typeof ml.inject === 'function') {
      try {
        const mlResult = await withTimeout(
          Promise.resolve(ml.inject(phaseId)),
          2000,
          '',
        )
        lesson = (mlResult || '').trim()
      } catch {
        lesson = ''
      }
    }

    // ── 3. Filtrer les trajectoires ───────────────────────────────────────────
    // Par défaut : garder uniquement 'success'
    // Si errorContext fourni : garder aussi 'failure' (smart-retry)
    const trajectories = rawTrajectories.filter(t => {
      if (t.verdict === 'success') return true
      if (errorContext && t.verdict === 'failure') return true
      return false
    })

    if (!trajectories.length && !lesson) return { ...EMPTY_CONTEXT }

    // ── 4. Résumé condensé ────────────────────────────────────────────────────
    const summary = buildSummary(trajectories, lesson, errorContext)

    return {
      trajectories,
      lesson,
      injected: true,
      summary,
    }
  } catch {
    return { ...EMPTY_CONTEXT }
  }
}

// ── API publique : injectContext ──────────────────────────────────────────────

/**
 * Préfixe le prompt avec un bloc de commentaire YAML contenant le contexte ACW.
 *
 * Format :
 *   # Context from ADA memory (k-NN, relevance: high)
 *   # Similar past runs: [id1, id2] | avg success: 87% | avg duration: 11min
 *   # Key lessons: <lesson text>
 *
 * @param {string} prompt
 * @param {typeof EMPTY_CONTEXT} context
 * @returns {string}
 */
function injectContext(prompt, context) {
  if (!context || !context.injected || !context.summary) return prompt

  const lines = context.summary
    .split('\n')
    .map(l => `# ${l}`)
    .join('\n')

  const block = `# Context from ADA memory (k-NN, relevance: high)\n${lines}`
  return `${block}\n\n${prompt}`
}

// ── buildCachedSystemBlock ────────────────────────────────────────────────────

/**
 * Construit des blocs API Anthropic optimisés pour le prompt cache.
 * La partie statique (instructions agent) reçoit cache_control, la partie
 * dynamique (contexte ACW) est envoyée sans cache pour éviter les miss.
 *
 * Usage : appelants qui font des appels API directs (provider-gateway, ultralearn)
 * et non via le tool Agent de Claude Code.
 *
 * @param {string}              staticInstructions  Système statique (CLAUDE.md agent, règles fixes)
 * @param {typeof EMPTY_CONTEXT} context            Résultat de buildPhaseContext()
 * @returns {Array<{ type: string, text: string, cache_control?: object }>}
 */
function buildCachedSystemBlock(staticInstructions, context) {
  let pco = null
  try { pco = require('./prompt-cache-optimizer') } catch {}

  const rawDynamic = context.injected && context.summary ? context.summary : ''
  // Garde « jamais pire » : le contexte dynamique ne doit jamais dépasser
  // CACHED_BLOCK_MAX_RATIO × la taille des instructions statiques (tokens
  // estimés) — sinon tronqué, ou omis si même tronqué il n'y a aucune marge.
  // Les instructions statiques (cachées) partent, elles, toujours intactes.
  // On garde static/dynamic SÉPARÉS (pas de simple concat) : c'est tout l'intérêt
  // de ce bloc, le cache_control ne doit porter que sur la partie statique.
  const dynamicContent = guardedDynamicContent(staticInstructions, rawDynamic, CACHED_BLOCK_MAX_RATIO)

  if (!pco) {
    const full = [staticInstructions, dynamicContent].filter(Boolean).join('\n\n')
    return [{ type: 'text', text: full }]
  }

  return pco.buildSystemBlock(staticInstructions, dynamicContent)
}

// ── Exports ───────────────────────────────────────────────────────────────────

module.exports = { buildPhaseContext, injectContext, buildCachedSystemBlock }
