#!/usr/bin/env node
'use strict'
/**
 * coordinator/control-handlers.js — Registre des méthodes RPC du Control Server (ADR-016 §2).
 *
 * Extrait de control-server.js (axe C3) : sépare le registre de handlers du transport.
 * `buildMethodRegistry(deps)` construit le catalogue des méthodes in-process
 * (run.* / router.* / bank.* / provider.* / cost.* / metrics.* / budget.* /
 * capabilities.* / health.* + surface CLI P4a/P7/P8).
 *
 * Chaque handler : (params, ctx) => result | Promise<result>
 * `ctx` expose { emit } pour publier des events corrélés.
 *
 * Injection de dépendances (deps) — fournies par control-server.js pour éviter
 * tout import circulaire (control-server importe control-handlers, jamais l'inverse) :
 *   - ERR, PROTOCOL_VERSION : constantes protocole (ADR-016 §1, §8)
 *   - ControlError          : erreur taggée mappée en JSON-RPC error
 *   - resolveProfileDir, profileName : résolution profil / chemins
 *   - runCliHarness, runStartAsync, safeLoadState : harnais run.* CLI (process.exit-free)
 *   - readDaemonPid, readDaemonState : lecture d'état du daemon sans son CLI
 *   - isAlive : test de vivacité d'un PID (process.kill(pid, 0))
 *
 * Zéro dépendance externe (fs / os / path / crypto natifs).
 */

const fs   = require('fs')
const os   = require('os')
const path = require('path')
const { randomUUID } = require('crypto')

/**
 * Construit le registre des méthodes RPC.
 * @param {{
 *   ERR: Record<string, number>,
 *   PROTOCOL_VERSION: string,
 *   ControlError: new (code:number, message:string, data?:unknown) => Error,
 *   resolveProfileDir: () => string,
 *   profileName: (profileDir:string) => string,
 *   runCliHarness: (fn:() => unknown) => { stdout:string, stderr:string, result:unknown },
 *   runStartAsync: (run:any, p:any) => Promise<{ ok:boolean, output:string }>,
 *   safeLoadState: (run:any, runId:string) => unknown,
 *   readDaemonPid: (daemon:any) => number|null,
 *   readDaemonState: (daemon:any) => any,
 *   isAlive: (pid:number|null) => boolean,
 * }} deps
 */
function buildMethodRegistry(deps) {
  const {
    ERR,
    PROTOCOL_VERSION,
    ControlError,
    resolveProfileDir,
    profileName,
    runCliHarness,
    runStartAsync,
    safeLoadState,
    readDaemonPid,
    readDaemonState,
    isAlive,
  } = deps
  // Modules chargés paresseusement pour ne pas plomber le boot si l'un manque.
  const lazy = (mod) => {
    let cached
    return () => (cached ||= require(mod))
  }
  const getRun      = lazy('./run.js')
  const getRouter   = lazy('./router.js')
  const getBank     = lazy('./bank.js')
  const getGatewayM = lazy('./provider-gateway.js')
  const getBudget   = lazy('./budget-guard.js')
  // P4a — surface CLI complète (ADR-016 §6bis D). Modules wrappés in-process.
  const getSkills   = lazy('./skill-registry.js')
  const getTeamSync = lazy('./team-sync.js')
  const getBridge   = lazy('./ada-bridge.js')
  const getFed      = lazy('./federation.js')
  const getDaemon   = lazy('../workers/daemon.js')
  const getPr       = lazy('./pr-autopilot.js')
  // P7 — features de configuration. router.recommendModel résout le modèle d'un tier.
  const getRouterMod = lazy('./router.js')
  // P8 — mémoire riche. graph-builder construit le KnowledgeGraph (nodes/edges).
  const getGraphBuilder = lazy('./graph-builder.js')

  // Gateway singleton (créé à la 1re utilisation)
  let _gateway = null
  const gateway = () => (_gateway ||= getGatewayM().createGateway())

  // ── Helpers P4a ─────────────────────────────────────────────────────────────
  //
  // profils / schedules / providerMode / obsidian sont stockés dans ~/.ada.json
  // (source de vérité du CLI `ada`, cf. bin/ada.js). On le lit en lecture seule ;
  // les mutations passent par writeAdaConfig (marquées MUTATIVE).
  // Surchargeable via ADA_CONFIG_PATH (tests hermétiques) ; sinon ~/.ada.json.
  const adaConfigPath = () => process.env.ADA_CONFIG_PATH || path.join(os.homedir(), '.ada.json')

  function readAdaConfig() {
    try { return JSON.parse(fs.readFileSync(adaConfigPath(), 'utf8')) } catch { return {} }
  }

  /** MUTATIVE — écrit ~/.ada.json (atomic via tmp+rename, comme bin/ada.js). */
  function writeAdaConfig(cfg) {
    const p = adaConfigPath()
    const tmp = p + '.tmp'
    fs.writeFileSync(tmp, JSON.stringify(cfg, null, 2))
    fs.renameSync(tmp, p)
  }

  /**
   * Liste les agents du profil courant (réplique compacte de listAgents de
   * bin/ada.js : .md à la racine + sous-dossiers avec CLAUDE.md). Lecture seule.
   */
  function listAgents() {
    const agentsDir = path.join(resolveProfileDir(), 'agents')
    if (!fs.existsSync(agentsDir)) return []
    const byName = new Map()
    let entries
    try { entries = fs.readdirSync(agentsDir, { withFileTypes: true }) } catch { return [] }
    for (const e of entries) {
      if (e.name.startsWith('.') || e.name === 'README-ruflo-agents.md') continue
      if (e.isFile() && e.name.endsWith('.md')) {
        const name = e.name.replace(/\.md$/, '')
        let title = name, desc = '', source = 'ada'
        try {
          const content = fs.readFileSync(path.join(agentsDir, e.name), 'utf8')
          title = content.match(/^#\s+(.+)$/m)?.[1]?.trim() || name
          desc  = content.match(/##\s+Rôle\s*\n([^\n#]+)/m)?.[1]?.trim().slice(0, 120) || ''
          const isRuflo = /Ruflo|ruflo|Claude Flow|SKILL\.md/.test(content)
          source = isRuflo ? 'ruflo' : 'ada'
        } catch {}
        byName.set(name, { name, title, desc, source })
      } else if (e.isDirectory()) {
        const claudeMd = path.join(agentsDir, e.name, 'CLAUDE.md')
        if (!fs.existsSync(claudeMd)) continue
        let title = e.name
        try { title = fs.readFileSync(claudeMd, 'utf8').match(/^#\s+(.+)$/m)?.[1]?.trim() || e.name } catch {}
        // Le dossier (CLAUDE.md) prime sur un éventuel .md homonyme.
        byName.set(e.name, { name: e.name, title, desc: '', source: 'ada' })
      }
    }
    return [...byName.values()].sort((a, b) => a.name.localeCompare(b.name))
  }

  // ── Helpers P7 (features de configuration) ──────────────────────────────────
  //
  // settings.json (mcpServers), <profileDir>/coordinator/{pipelines,teams}.json,
  // ~/.ada.json (activeProfile, providerMode, budget, obsidian, webhook). Lecture
  // seule sauf fonctions marquées MUTATIVE.

  const coordDir     = () => path.join(resolveProfileDir(), 'coordinator')
  const pipelinesPath = () => path.join(coordDir(), 'pipelines.json')
  const teamsPath     = () => path.join(coordDir(), 'teams.json')
  const settingsPath  = () => path.join(resolveProfileDir(), 'settings.json')

  function readJsonSafe(p, fallback) {
    try { return JSON.parse(fs.readFileSync(p, 'utf8')) } catch { return fallback }
  }

  /** MUTATIVE — écrit un JSON (atomic tmp+rename). */
  function writeJsonAtomic(p, data) {
    fs.mkdirSync(path.dirname(p), { recursive: true })
    const tmp = p + '.tmp'
    fs.writeFileSync(tmp, JSON.stringify(data, null, 2))
    fs.renameSync(tmp, p)
  }

  /** Résout le modèle d'un tier via router.js (fallback gracieux si indisponible). */
  function modelForTier(tier) {
    try { return getRouterMod().recommendModel(tier) } catch { return null }
  }

  /**
   * Normalise pipelines.json (format objet keyé par nom, clés `_*` exclues) vers
   * un tableau { name, description, onFailure, phases:[{...résolu}] }. Lecture seule.
   * Chaque phase résout agent + tier + modèle + dépendances (DAG).
   */
  function readPipelines() {
    const raw = readJsonSafe(pipelinesPath(), null)
    if (!raw || typeof raw !== 'object') return []
    const out = []
    for (const [name, def] of Object.entries(raw)) {
      if (name.startsWith('_')) continue
      const d = (def && typeof def === 'object') ? def : {}
      const phases = Array.isArray(d.phases) ? d.phases.map(ph => {
        const tier = ph.tier ?? 2
        return {
          id: ph.id,
          label: ph.label ?? ph.id,
          agent: ph.agent ?? null,
          agentAlt: ph.agentAlt ?? null,
          domain: ph.domain ?? null,
          tier,
          model: modelForTier(tier),
          required: ph.required ?? true,
          maxRetries: ph.maxRetries ?? 0,
          depends: Array.isArray(ph.depends) ? ph.depends : [],
          stopOnFailure: ph.stopOnFailure ?? false,
          skipIf: Array.isArray(ph.skipIf) ? ph.skipIf : [],
          rollbackPhase: ph.rollbackPhase ?? null,
        }
      }) : []
      out.push({
        name,
        description: typeof d.description === 'string' ? d.description : '',
        onFailure: d.onFailure ?? 'stop',
        phases,
      })
    }
    return out
  }

  function readTeams() {
    const raw = readJsonSafe(teamsPath(), null)
    return Array.isArray(raw) ? raw : []
  }

  const SAFE_NAME_RE      = /^[a-z0-9][a-z0-9-]{0,63}$/
  const SAFE_CONNECTOR_RE = /^[a-z0-9][a-z0-9_-]{0,63}$/
  const SAFE_PROFILE_RE   = /^[a-z0-9][a-z0-9-]{0,30}$/
  const SAFE_UUID_RE      = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/

  /** Lit le frontmatter `--- key: value ---` d'un .md (réplique compacte). */
  function parseFrontmatter(content) {
    const m = content.match(/^---\n([\s\S]*?)\n---/)
    const fm = {}
    if (!m) return fm
    for (const line of m[1].split('\n')) {
      const kv = line.match(/^([a-zA-Z0-9_-]+):\s*(.*)$/)
      if (kv) fm[kv[1]] = kv[2].replace(/^["']|["']$/g, '').trim()
    }
    return fm
  }

  /** Catalogue MCP statique (porté de ada-ui mcp/registry). Lecture seule. */
  const MCP_CATALOG = [
    { id: 'filesystem', name: 'Filesystem', description: 'Accès fichiers local', command: 'npx', args: ['-y', '@modelcontextprotocol/server-filesystem', '/tmp'], env: {}, tags: ['filesystem', 'local'], version: '0.6.2' },
    { id: 'github', name: 'GitHub', description: 'API GitHub — issues, PRs, repos', command: 'npx', args: ['-y', '@modelcontextprotocol/server-github'], env: { GITHUB_TOKEN: '' }, tags: ['github', 'git'], version: '0.6.2' },
    { id: 'postgres', name: 'PostgreSQL', description: 'Accès base PostgreSQL', command: 'npx', args: ['-y', '@modelcontextprotocol/server-postgres', 'postgresql://localhost/mydb'], env: {}, tags: ['database', 'sql'], version: '0.6.2' },
    { id: 'fetch', name: 'Fetch', description: 'Requêtes HTTP depuis les agents', command: 'npx', args: ['-y', '@modelcontextprotocol/server-fetch'], env: {}, tags: ['http', 'web'], version: '0.6.2' },
    { id: 'brave-search', name: 'Brave Search', description: 'Recherche web via Brave', command: 'npx', args: ['-y', '@modelcontextprotocol/server-brave-search'], env: { BRAVE_API_KEY: '' }, tags: ['search', 'web'], version: '0.6.2' },
    { id: 'sqlite', name: 'SQLite', description: 'Accès base SQLite locale', command: 'npx', args: ['-y', '@modelcontextprotocol/server-sqlite', './data.db'], env: {}, tags: ['database', 'sql'], version: '0.6.2' },
    { id: 'memory', name: 'Memory', description: 'Mémoire persistante entre sessions', command: 'npx', args: ['-y', '@modelcontextprotocol/server-memory'], env: {}, tags: ['memory'], version: '0.6.2' },
    { id: 'git', name: 'Git', description: 'Opérations Git sur repos locaux', command: 'npx', args: ['-y', '@modelcontextprotocol/server-git', '--repository', '.'], env: {}, tags: ['git', 'vcs'], version: '0.6.2' },
    { id: 'slack', name: 'Slack', description: 'Messages et canaux Slack', command: 'npx', args: ['-y', '@modelcontextprotocol/server-slack'], env: { SLACK_BOT_TOKEN: '', SLACK_TEAM_ID: '' }, tags: ['slack', 'messaging'], version: '0.6.2' },
    { id: 'sequential-thinking', name: 'Sequential Thinking', description: 'Résolution structurée', command: 'npx', args: ['-y', '@modelcontextprotocol/server-sequential-thinking'], env: {}, tags: ['reasoning', 'ai'], version: '0.6.2' },
    { id: 'linear', name: 'Linear', description: 'Issues et projets Linear', command: 'npx', args: ['-y', 'linear-mcp-server'], env: { LINEAR_API_KEY: '' }, tags: ['linear', 'pm'], version: '1.0.0' },
    { id: 'notion', name: 'Notion', description: 'Pages et bases Notion', command: 'npx', args: ['-y', 'notion-mcp-server'], env: { NOTION_API_KEY: '' }, tags: ['notion', 'knowledge'], version: '1.0.0' },
  ]

  // ── Helpers P8 (mémoire riche : graphe + wiki Obsidian) ──────────────────────
  //
  // memory.graph projette le KnowledgeGraph (graph-builder/graph-memory) vers le
  // format viz 3D { nodes, edges, stats }. obsidian.wiki/note lisent le vault
  // per-profil (~/.claude-<profil>/_obsidian) en lecture seule. Dégradation
  // gracieuse : graphe/vault absent → payload vide annoté (jamais de crash).

  // Slug de note : alphanum + tiret/underscore, suffixe .md, aucun `/`, `\` ni `..`.
  const SAFE_NOTE_RE = /^[A-Za-z0-9_-]+\.md$/

  /** Résout le dossier du vault Obsidian du profil courant. null si désactivé. */
  function resolveVaultDir() {
    const cfg = readAdaConfig()
    const obs = cfg.obsidian || {}
    if (!obs.enabled) return null
    return obs.vaultPath || path.join(resolveProfileDir(), '_obsidian')
  }

  /**
   * Construit le graphe via graph-builder (SQLite/bank-state + pipelines) puis le
   * projette en { nodes:[{id,label,type,weight,...}], edges:[{source,target,weight,type}], stats }.
   * Dégradation : graphe vide → { nodes:[], edges:[], stats:{...0}, empty:true }.
   * @param {{ pagerank?: boolean, top?: number }} [opts]
   */
  function buildMemoryGraph(opts = {}) {
    const { pagerank = false, top = 0 } = opts
    let g
    try {
      g = getGraphBuilder().buildFull({ configDir: coordDir() })
    } catch {
      g = null
    }
    if (!g || g.nodes.size === 0) {
      return {
        nodes: [], edges: [],
        stats: { totalNodes: 0, totalEdges: 0, nodeTypes: {}, edgeTypes: {} },
        pagerank: false,
        empty: true,
      }
    }

    const prScores = pagerank ? g.pageRank() : null

    /** @type {Array<{id:string,label:string,type:string,weight:number,pagerank?:number}>} */
    let nodes = [...g.nodes.values()].map(n => {
      const node = {
        id: n.id,
        label: n.label,
        type: n.type,
        weight: pagerank && prScores ? (prScores.get(n.id) ?? 0) : 1,
      }
      if (pagerank && prScores) node.pagerank = prScores.get(n.id) ?? 0
      return node
    })

    // top=N : conserve les N nœuds les plus importants (par PageRank si calculé,
    // sinon par degré sortant+entrant). Les arêtes sont filtrées en conséquence.
    if (top > 0 && nodes.length > top) {
      const rank = prScores
        ? (id) => prScores.get(id) ?? 0
        : (id) => (g.adj.get(id)?.size ?? 0) + (g.radj.get(id)?.size ?? 0)
      nodes = [...nodes].sort((a, b) => rank(b.id) - rank(a.id)).slice(0, top)
    }

    const kept = new Set(nodes.map(n => n.id))
    const edges = [...g.edges.values()]
      .filter(e => kept.has(e.from) && kept.has(e.to))
      .map(e => ({ source: e.from, target: e.to, type: e.type, weight: e.weight }))

    const nodeTypes = {}
    for (const n of nodes) nodeTypes[n.type] = (nodeTypes[n.type] ?? 0) + 1
    const edgeTypes = {}
    for (const e of edges) edgeTypes[e.type] = (edgeTypes[e.type] ?? 0) + 1

    return {
      nodes,
      edges,
      stats: { totalNodes: nodes.length, totalEdges: edges.length, nodeTypes, edgeTypes },
      pagerank: !!pagerank,
      empty: false,
    }
  }

  // Helpers run.* via le harnais CLI
  function runCmd(name, args) {
    const run = getRun()
    const fn = run[name]
    if (typeof fn !== 'function') throw new ControlError(ERR.INTERNAL, `run.${name} indisponible`)
    return runCliHarness(() => fn(args))
  }

  /** @type {Record<string, (params:any, ctx:any)=>any>} */
  const methods = {
    // ── run.* (mutations via harnais CLI ; lectures via exports propres) ──────
    'run.init': (p) => {
      const args = [p.pipeline, p.feature, ...(p.flags || [])].filter(v => v != null)
      const { stdout } = runCmd('cmdInit', args)
      const m = stdout.match(/RUN_ID:([a-z0-9-]+)/)
      return { runId: m ? m[1] : null, output: stdout.trim() }
    },
    'run.start': async (p) => {
      // cmdStart est async → on l'exécute hors harnais (pas de process.exit attendu
      // sur le chemin nominal) mais on garde l'interception via promesse.
      return await runStartAsync(getRun(), p)
    },
    'run.done': (p) => {
      const args = [p.runId, p.phaseId, p.summary || '']
      if (p.tokens != null) args.push('--tokens', String(p.tokens))
      if (p.cost   != null) args.push('--cost', String(p.cost))
      const { stdout } = runCmd('cmdDone', args)
      return { ok: true, output: stdout.trim() }
    },
    'run.fail': (p) => {
      const args = [p.runId, p.phaseId, p.error || '']
      if (p.retry) args.push('--retry')
      if (p.tokens != null) args.push('--tokens', String(p.tokens))
      if (p.cost   != null) args.push('--cost', String(p.cost))
      const { stdout } = runCmd('cmdFail', args)
      return { ok: true, output: stdout.trim() }
    },
    'run.skip': (p) => {
      const { stdout } = runCmd('cmdSkip', [p.runId, p.phaseId, p.reason || ''])
      return { ok: true, output: stdout.trim() }
    },
    'run.retry': (p) => {
      const { stdout } = runCmd('cmdRetry', [p.runId])
      return { ok: true, output: stdout.trim() }
    },
    'run.rollback': (p) => {
      const args = [p.runId]
      if (p.phaseId) args.push(p.phaseId)
      const { stdout } = runCmd('cmdRollback', args)
      return { ok: true, output: stdout.trim() }
    },
    'run.status': (p) => {
      const run = getRun()
      const state = safeLoadState(run, p.runId)
      return { state }
    },
    'run.next': (p) => {
      const run = getRun()
      const state = safeLoadState(run, p.runId)
      const pipelineDef = run.loadPipeline(state.pipeline)
      const ready = []
      for (const phaseDef of pipelineDef.phases) {
        const ph = state.phases[phaseDef.id]
        if (!ph || ph.status !== 'pending') continue
        const depsOk = (phaseDef.depends || []).every(dep => {
          const dp = state.phases[dep]
          return dp && ['completed', 'skipped'].includes(dp.status)
        })
        if (!depsOk) continue
        const tier = ph.tierOverride ?? phaseDef.tier ?? 2
        ready.push({
          phaseId: phaseDef.id,
          agent:   ph.agent || phaseDef.agent,
          tier,
          required: ph.required,
          model:   run.recommendModel(tier),
        })
      }
      const topo = run.analyzeTopology(state, pipelineDef)
      return { runId: p.runId, topology: topo.topology, ready, parallelizable: topo.parallelizable }
    },
    'run.list': () => {
      const run = getRun()
      const RUNS_DIR = run.RUNS_DIR
      if (!fs.existsSync(RUNS_DIR)) return { runs: [] }
      const runs = fs.readdirSync(RUNS_DIR)
        .filter(d => fs.existsSync(path.join(RUNS_DIR, d, 'state.json')))
        .map(d => {
          try {
            const s = JSON.parse(fs.readFileSync(path.join(RUNS_DIR, d, 'state.json'), 'utf8'))
            return { id: s.id, status: s.status, pipeline: s.pipeline, name: s.args?.name, totalCost: s.totalCost ?? 0 }
          } catch { return null }
        })
        .filter(Boolean)
      return { runs }
    },

    // ── router.* ──────────────────────────────────────────────────────────────
    'router.recommend': (p) => {
      const router = getRouter()
      return router.recommend(p.phaseType, p.opts || {})
    },
    'router.update': (p) => {
      const router = getRouter()
      return router.update(p.phaseType, p.agent, p.outcome, p.opts || {})
    },
    'router.stats': () => {
      const router = getRouter()
      const state = router.loadState()
      return { totalUpdates: state.totalUpdates || 0, lastUpdated: state.lastUpdated || null, priors: state.priors || {} }
    },

    // ── bank.* ──────────────────────────────────────────────────────────────
    'bank.retrieve': (p) => {
      const bank = getBank()
      return { trajectories: bank.retrieve(p.query, p.opts || {}) || [] }
    },
    'bank.store': (p) => {
      const bank = getBank()
      const id = bank.store(p.phase, p.agent, p.verdict, p.summary || '', p.opts || {})
      return { id }
    },
    'bank.stream': (p) => {
      const bank = getBank()
      // collectStream : variante synchrone-collectée du flux (évite de gérer un
      // EventEmitter à travers le RPC). Fallback retrieve si indisponible.
      if (typeof bank.collectStream === 'function') {
        return { chunks: bank.collectStream(p.query, p.opts || {}) }
      }
      return { chunks: bank.retrieve(p.query, p.opts || {}) || [] }
    },

    // ── provider.* ────────────────────────────────────────────────────────────
    'provider.complete': async (p) => {
      const gw = gateway()
      const messages = p.messages || [{ role: 'user', content: p.prompt || '' }]
      return await gw.complete(messages, p.opts || {})
    },
    'provider.embed': async (p) => {
      const gw = gateway()
      const vec = await gw.embed(p.text || '')
      return { embedding: vec, dim: vec.length }
    },

    // ── cost.report ───────────────────────────────────────────────────────────
    'cost.report': (p) => {
      const { aggregateSessions, buildReport } = require('../workers/cost-report.js')
      const sessions = aggregateSessions ? aggregateSessions(p.opts || {}) : []
      return buildReport ? buildReport(sessions) : { sessions }
    },

    // ── metrics.get ─────────────────────────────────────────────────────────
    'metrics.get': () => {
      const m = require('../workers/metrics.js')
      const runs = m.loadRuns ? m.loadRuns() : []
      return {
        runs:   m.computeRunMetrics    ? m.computeRunMetrics(runs)            : null,
        router: m.computeRouterMetrics ? m.computeRouterMetrics(m.loadRouterState?.()) : null,
        bank:   m.computeBankMetrics   ? m.computeBankMetrics(m.loadBankState?.())     : null,
      }
    },

    // ── budget.* ──────────────────────────────────────────────────────────────
    'budget.check': (p) => {
      const budget = getBudget()
      const config = budget.loadBudgetConfig()
      const res = budget.checkBudget(p.runId, p.phaseCost ?? 0, p.cumulCost ?? 0, config, {
        todayCost:   budget.getDailyCost(),
        sessionCost: budget.getSessionCost(p.runId),
      })
      if (res.action === 'stop') throw new ControlError(ERR.BUDGET_EXCEEDED, res.message)
      return res
    },
    'budget.record': (p) => {
      const budget = getBudget()
      budget.recordCost(p.runId, p.amount ?? 0, p.model)
      return { ok: true }
    },
    // ADR-023 étape 4 — gouvernance des délégations d'un orchestrateur adaptatif
    // (hors frontière de phase run.js). Refus dur ('stop') propagé en erreur,
    // symétrique à budget.check/budget.record ci-dessus.
    'budget.checkDelegation': (p) => {
      const budget = getBudget()
      const config = budget.loadBudgetConfig()
      const res = budget.checkDelegationBudget(p.runId, p.delegationCount ?? 0, p.cumulCost ?? 0, config, {
        todayCost:   budget.getDailyCost(),
        sessionCost: budget.getSessionCost(p.runId),
      })
      if (res.action === 'stop') throw new ControlError(ERR.BUDGET_EXCEEDED, res.message)
      return res
    },
    'budget.recordDelegation': (p) => {
      const budget = getBudget()
      budget.recordDelegation(p.runId, { agent: p.agent, model: p.model, mandateId: p.mandateId, cost: p.cost })
      return { ok: true }
    },

    // ── capabilities.list ───────────────────────────────────────────────────
    'capabilities.list': () => ({
      protocolVersion: PROTOCOL_VERSION,
      // Manifeste d'installation (ADR-016 §4) — réutilise les handlers frères
      // synchrones, chacun protégé pour ne jamais faire échouer le manifeste.
      profile: (() => { try { return readAdaConfig().activeProfile ?? null } catch { return null } })(),
      models: (() => {
        try { return { tier1: modelForTier(1), tier2: modelForTier(2), tier3: modelForTier(3) } }
        catch { return null }
      })(),
      pipelines: (() => { try { return methods['pipelines.list']().pipelines ?? [] } catch { return [] } })(),
      agents:    (() => { try { return methods['agents.list']({}).agents ?? [] } catch { return [] } })(),
      teams:     (() => { try { return methods['teams.list']().teams ?? [] } catch { return [] } })(),
      methods: Object.keys(methods),
      // Groupes annoncés (ADR-016 §4 + §6bis D). read = idempotent ;
      // control = effet local borné ; mutative = mute ~/.ada.json ou spawn.
      methodGroups: {
        run: ['run.init', 'run.next', 'run.start', 'run.done', 'run.fail', 'run.skip', 'run.retry', 'run.rollback', 'run.status', 'run.list'],
        router: ['router.recommend', 'router.update', 'router.stats'],
        bank: ['bank.retrieve', 'bank.store', 'bank.stream'],
        provider: ['provider.complete', 'provider.embed'],
        cost: ['cost.report'],
        metrics: ['metrics.get'],
        budget: ['budget.check', 'budget.record', 'budget.checkDelegation', 'budget.recordDelegation'],
        profiles: ['profiles.list', 'profiles.switch', 'profiles.create'],
        agents: ['agents.list', 'agents.search', 'agents.info'],
        skills: ['skills.list', 'skills.search', 'skills.info', 'skills.installed', 'skill.install', 'skill.uninstall'],
        team: ['team.status', 'team.push', 'team.pull'],
        bridge: ['bridge.list', 'bridge.status', 'bridge.send', 'bridge.receive', 'bridge.shareLessons'],
        fed: ['fed.status', 'fed.peers'],
        daemon: ['daemon.status', 'daemon.run'],
        schedules: ['schedules.list', 'schedules.add', 'schedules.remove', 'schedules.toggle'],
        providers: ['providers.status', 'providers.set'],
        obsidian: ['obsidian.status', 'obsidian.wiki', 'obsidian.note'],
        memory: ['memory.graph'],
        pr: ['pr.status'],
        logs: ['logs.tail'],
        // P7 — features de configuration.
        pipelines: ['pipelines.list', 'pipelines.get'],
        mcp: ['mcp.list', 'mcp.registry', 'mcp.add', 'mcp.update', 'mcp.remove'],
        teams: ['teams.list', 'teams.get', 'teams.create', 'teams.update', 'teams.remove'],
        settings: ['settings.get', 'settings.set'],
        capabilities: ['capabilities.list'],
        health: ['health.probe'],
      },
      // Classement par effet pour l'UI (lecture = appel libre ; mutative = derrière Guard).
      mutativeMethods: [
        'skill.install', 'skill.uninstall', 'team.push', 'team.pull',
        'bridge.send', 'bridge.receive', 'bridge.shareLessons', 'daemon.run',
        'schedules.add', 'schedules.remove', 'schedules.toggle', 'providers.set',
        // P7
        'mcp.add', 'mcp.update', 'mcp.remove',
        'profiles.switch', 'profiles.create',
        'teams.create', 'teams.update', 'teams.remove',
        'settings.set',
      ],
      events: ['run.started', 'run.phase.started', 'run.phase.completed', 'run.phase.failed', 'run.completed'],
    }),

    // ── health.probe ──────────────────────────────────────────────────────────
    // P1-2 — inclut la santé de la couche mémoire (bank.health()). Forme normalisée
    // pour le contrat API/UI : { ollama:'up'|'down', recallDegraded, lastRecallDegradedAt }.
    // bank.health() est async (sonde Ollama) ; jamais throw → dégradation gracieuse.
    'health.probe': async () => {
      const base = { status: 'ok', uptimeMs: Math.round(process.uptime() * 1000), pid: process.pid }
      let memory = { ollama: 'down', recallDegraded: true, lastRecallDegradedAt: null }
      try {
        const h = await getBank().health()
        memory = {
          ollama: h.ollama ? 'up' : 'down',
          recallDegraded: !h.ollama,             // recall dégradé (TF-IDF) quand Ollama est down
          lastRecallDegradedAt: h.lastRecallDegraded ?? null,
        }
      } catch {
        // bank indisponible → santé mémoire inconnue, marquée dégradée par défaut.
      }
      return { ...base, memory }
    },

    // ════════════════════════════════════════════════════════════════════════
    // P4a — Surface CLI complète (ADR-016 §6bis D). Convention :
    //   LECTURE         → idempotent, aucun effet de bord.
    //   CONTRÔLE LÉGER  → effet borné/local (toggle config), pas de spawn.
    //   MUTATIF/LONG    → mute ~/.ada.json ou spawn process : marqué [MUTATIF].
    // ════════════════════════════════════════════════════════════════════════

    // ── profiles.* (LECTURE — ~/.ada.json) ─────────────────────────────────────
    'profiles.list': () => {
      const cfg = readAdaConfig()
      const installed = cfg.installedProfiles ?? []
      return {
        active: cfg.activeProfile ?? null,
        profiles: installed.map(name => ({
          name,
          dir: path.join(os.homedir(), '.' + name),
          active: name === cfg.activeProfile,
        })),
      }
    },

    // ── agents.* (LECTURE — <profileDir>/agents) ───────────────────────────────
    'agents.list': (p) => {
      let agents = listAgents()
      if (p.category && typeof p.category === 'string') {
        const c = p.category.toLowerCase()
        agents = agents.filter(a => a.source === c)
      }
      return { agents, total: agents.length }
    },
    'agents.search': (p) => {
      const q = String(p.query || '').toLowerCase()
      const agents = listAgents().filter(a =>
        a.name.toLowerCase().includes(q) ||
        a.title.toLowerCase().includes(q) ||
        a.desc.toLowerCase().includes(q))
      return { agents, total: agents.length, query: p.query || '' }
    },

    // ── skills.* (LECTURE async via skill-registry) ─────────────────────────────
    'skills.list': async () => {
      const sk = getSkills()
      const installed = sk.listInstalled()
      const available = await sk.searchSkills('')
      return { installed, available, counts: { installed: installed.length, available: available.length } }
    },
    'skills.search': async (p) => {
      const sk = getSkills()
      const results = await sk.searchSkills(String(p.query || ''))
      return { results, total: results.length, query: p.query || '' }
    },
    'skills.info': async (p) => {
      const sk = getSkills()
      const info = await sk.getSkillInfo(String(p.name || ''))
      if (!info) throw new ControlError(ERR.INTERNAL, `Skill inconnu : ${p.name}`)
      return { skill: info }
    },
    'skills.installed': () => ({ installed: getSkills().listInstalled() }),
    // [MUTATIF — copie fichiers + priors/lessons. Spawn possible (archive distante).]
    'skill.install': async (p) => {
      const name = String(p.name || '')
      if (!name) throw new ControlError(ERR.INVALID_PARAMS, 'skill.install requiert { name }')
      return await getSkills().installSkill(name)
    },
    // [MUTATIF — supprime le skill + ses lessons.]
    'skill.uninstall': (p) => {
      const name = String(p.name || '')
      if (!name) throw new ControlError(ERR.INVALID_PARAMS, 'skill.uninstall requiert { name }')
      return getSkills().uninstallSkill(name)
    },

    // ── team.* (LECTURE / [MUTATIF git]) ────────────────────────────────────────
    'team.status': () => ({ sync: getTeamSync().getStatus() }),
    // [MUTATIF — git commit+push (network). Ne PAS appeler en test sans remote.]
    'team.push': (p) => {
      const r = getTeamSync().push(p.opts || {})
      return r ?? { ok: true }
    },
    // [MUTATIF — git pull (network) + merge des priors/lessons.]
    'team.pull': (p) => {
      const r = getTeamSync().pull(p.opts || {})
      return r ?? { ok: true }
    },

    // ── bridge.* (LECTURE / [MUTATIF fichiers]) ─────────────────────────────────
    'bridge.list': () => ({ profiles: getBridge().findProfiles() }),
    'bridge.status': () => {
      // Statut = profils détectés + profil courant (lecture seule, pas d'I/O réseau).
      const profiles = getBridge().findProfiles()
      const here = profileName(resolveProfileDir())
      return { current: here, peers: profiles.map(p => p.name), total: profiles.length }
    },
    // [MUTATIF — écrit dans l'outbox/inbox d'un autre profil.]
    'bridge.send': (p) => {
      if (!p.runId || !p.to) throw new ControlError(ERR.INVALID_PARAMS, 'bridge.send requiert { runId, to }')
      const out = runCliHarness(() => getBridge().cmdSend([p.runId, '--to', p.to]))
      return { ok: true, output: out.stdout.trim() }
    },
    // [MUTATIF — consomme l'inbox du profil courant.]
    'bridge.receive': () => {
      const out = runCliHarness(() => getBridge().cmdReceive([]))
      return { ok: true, output: out.stdout.trim() }
    },
    // [MUTATIF — partage les leçons accumulées vers un profil cible.]
    'bridge.shareLessons': (p) => {
      if (!p.to) throw new ControlError(ERR.INVALID_PARAMS, 'bridge.shareLessons requiert { to }')
      const out = runCliHarness(() => getBridge().cmdShareLessons([p.to]))
      return { ok: true, output: out.stdout.trim() }
    },

    // ── fed.* (LECTURE) ─────────────────────────────────────────────────────────
    'fed.status': () => {
      const fed = getFed()
      const cfg = fed.getFederationConfig()
      return {
        enabled: !!cfg.enabled,
        port: cfg.port ?? null,
        topK: cfg.topK ?? null,
        peersConfigured: Array.isArray(cfg.peers) ? cfg.peers.length : 0,
        activePeers: fed.getActivePeers().length,
      }
    },
    'fed.peers': () => {
      const fed = getFed()
      const cfg = fed.getFederationConfig()
      return { configured: cfg.peers || [], active: fed.getActivePeers() }
    },

    // ── daemon.* (LECTURE / [MUTATIF spawn]) ────────────────────────────────────
    'daemon.status': () => {
      const d = getDaemon()
      const alive = isAlive(readDaemonPid(d))
      const state = readDaemonState(d)
      return {
        running: alive,
        pid: alive ? readDaemonPid(d) : null,
        schedule: d.loadSchedule ? d.loadSchedule() : (d.DEFAULT_SCHEDULE || {}),
        workers: state.workers || {},
      }
    },
    // [MUTATIF — exécute un worker en spawn detached. Whitelist daemon interne.]
    'daemon.run': (p) => {
      const worker = String(p.worker || '')
      if (!worker) throw new ControlError(ERR.INVALID_PARAMS, 'daemon.run requiert { worker }')
      // Sécurité (S1) : nom de worker simple uniquement — bloque path traversal / RCE.
      if (!/^[a-zA-Z0-9_\-]+$/.test(worker)) throw new ControlError(ERR.INVALID_PARAMS, `worker invalide: ${worker}`)
      const d = getDaemon()
      if (typeof d.runWorker !== 'function') throw new ControlError(ERR.INTERNAL, 'daemon.runWorker indisponible')
      d.runWorker(worker)
      return { ok: true, worker }
    },

    // ── schedules.* (LECTURE / [MUTATIF ~/.ada.json]) ───────────────────────────
    'schedules.list': () => ({ schedules: readAdaConfig().schedules ?? [] }),
    // [MUTATIF — ajoute une entrée schedule dans ~/.ada.json.]
    'schedules.add': (p) => {
      if (!p.pipeline || !p.cron) throw new ControlError(ERR.INVALID_PARAMS, 'schedules.add requiert { pipeline, cron }')
      const cfg = readAdaConfig()
      if (!Array.isArray(cfg.schedules)) cfg.schedules = []
      const id = randomUUID().slice(0, 8)
      const entry = {
        id, name: p.name || p.pipeline, pipeline: p.pipeline, cron: p.cron,
        enabled: true, createdAt: new Date().toISOString(), lastRun: null,
      }
      cfg.schedules.push(entry)
      writeAdaConfig(cfg)
      return { ok: true, schedule: entry }
    },
    // [MUTATIF — retire une entrée par id.]
    'schedules.remove': (p) => {
      if (!p.id) throw new ControlError(ERR.INVALID_PARAMS, 'schedules.remove requiert { id }')
      const cfg = readAdaConfig()
      const before = (cfg.schedules ?? []).length
      cfg.schedules = (cfg.schedules ?? []).filter(s => s.id !== p.id)
      writeAdaConfig(cfg)
      return { ok: true, removed: before - cfg.schedules.length }
    },
    // [MUTATIF — bascule enabled d'une entrée.]
    'schedules.toggle': (p) => {
      if (!p.id) throw new ControlError(ERR.INVALID_PARAMS, 'schedules.toggle requiert { id }')
      const cfg = readAdaConfig()
      const s = (cfg.schedules ?? []).find(s => s.id === p.id)
      if (!s) throw new ControlError(ERR.INTERNAL, `Schedule inconnu : ${p.id}`)
      s.enabled = !s.enabled
      writeAdaConfig(cfg)
      return { ok: true, schedule: s }
    },

    // ── providers.* (LECTURE / [MUTATIF ~/.ada.json]) ───────────────────────────
    'providers.status': () => {
      const cfg = readAdaConfig()
      const mode = cfg.providerMode ?? 'claude-code'
      const gw = gateway()
      const available = typeof gw.getAvailableProviders === 'function' ? gw.getAvailableProviders() : []
      return {
        mode,
        available,
        all: Object.keys(getGatewayM().PROVIDERS || {}),
        anthropicKeyPresent: !!process.env.ANTHROPIC_API_KEY,
      }
    },
    // [MUTATIF — change providerMode dans ~/.ada.json.]
    'providers.set': (p) => {
      const VALID = ['claude-code', 'api']
      if (!VALID.includes(p.mode)) throw new ControlError(ERR.INVALID_PARAMS, `mode invalide : ${p.mode} (claude-code|api)`)
      const cfg = readAdaConfig()
      cfg.providerMode = p.mode
      writeAdaConfig(cfg)
      return { ok: true, mode: p.mode }
    },

    // ── obsidian.* (LECTURE) ────────────────────────────────────────────────────
    'obsidian.status': () => {
      const cfg = readAdaConfig()
      const obs = cfg.obsidian || {}
      const profileDir = resolveProfileDir()
      const vaultDir = obs.vaultPath || path.join(profileDir, '_obsidian')
      const sessDir = path.join(vaultDir, 'sessions')
      let sessions = 0
      try { if (fs.existsSync(sessDir)) sessions = fs.readdirSync(sessDir).filter(f => f.endsWith('.md')).length } catch {}
      return {
        enabled: !!obs.enabled,
        mode: obs.mode ?? 'per-profile',
        vaultDir,
        initialized: fs.existsSync(vaultDir),
        sessions,
      }
    },

    // ── obsidian.wiki (LECTURE — wiki/index.md + topics/*.md du vault) ───────────
    // Structure/liste des notes wiki : titres, domaines, projets, contenu.
    // Dégradation : Obsidian désactivé / vault absent / pas de wiki → payload vide.
    'obsidian.wiki': () => {
      const empty = { topics: [], totalSessions: 0, generatedAt: '', indexRaw: '', empty: true }
      const vaultDir = resolveVaultDir()
      if (!vaultDir || !fs.existsSync(vaultDir)) return empty

      const indexPath = path.join(vaultDir, 'wiki', 'index.md')
      let indexRaw = '', generatedAt = '', totalSessions = 0
      if (fs.existsSync(indexPath)) {
        try {
          indexRaw = fs.readFileSync(indexPath, 'utf8')
          const fm = parseFrontmatter(indexRaw)
          generatedAt = fm.generated ?? ''
          totalSessions = fm.sessions ? (parseInt(fm.sessions, 10) || 0) : 0
        } catch {}
      }

      const topicsDir = path.join(vaultDir, 'topics')
      const topics = []
      if (fs.existsSync(topicsDir)) {
        let files = []
        try { files = fs.readdirSync(topicsDir).filter(f => SAFE_NOTE_RE.test(f)) } catch {}
        for (const file of files) {
          let content = ''
          try { content = fs.readFileSync(path.join(topicsDir, file), 'utf8') } catch { continue }
          const fm = parseFrontmatter(content)
          // Projets : lignes `- \`nom\`` du corps de la note.
          const projects = []
          const re = /^- `([^`]+)`/gm
          let m
          while ((m = re.exec(content)) !== null) projects.push(m[1])
          topics.push({
            slug: file.replace(/\.md$/, ''),
            topic: fm.topic ?? file.replace(/\.md$/, ''),
            domain: fm.domain ?? 'other',
            sessionCount: fm.sessions ? (parseInt(fm.sessions, 10) || 0) : 0,
            lastUpdated: fm.updated ?? fm.date ?? '',
            projects,
            content,
          })
        }
        topics.sort((a, b) => b.sessionCount - a.sessionCount)
      }

      return { topics, totalSessions, generatedAt, indexRaw, empty: false }
    },

    // ── obsidian.note (LECTURE — { file } anti path-traversal) ───────────────────
    // Lit une note .md depuis <vault>/sessions ou <vault>/topics. Le nom est
    // validé par SAFE_NOTE_RE (aucun `/`, `\`, `..` possible) + vérif resolved.
    'obsidian.note': (p) => {
      const file = String(p.file || '')
      if (!SAFE_NOTE_RE.test(file)) throw new ControlError(ERR.INVALID_PARAMS, 'obsidian.note requiert { file } valide (slug .md, sans / ni ..)')
      const vaultDir = resolveVaultDir()
      if (!vaultDir || !fs.existsSync(vaultDir)) throw new ControlError(ERR.RUN_NOT_FOUND, 'Vault Obsidian introuvable ou désactivé')

      // Cherche dans sessions/ puis topics/ ; vérifie que le chemin reste confiné.
      for (const sub of ['sessions', 'topics']) {
        const dir = path.join(vaultDir, sub)
        const candidate = path.join(dir, file)
        const resolved = path.resolve(candidate)
        if (resolved !== path.resolve(dir, file)) continue // garde-fou redondant
        if (!resolved.startsWith(dir + path.sep)) {
          throw new ControlError(ERR.INVALID_PARAMS, 'Chemin de note hors du vault (rejeté)')
        }
        if (fs.existsSync(candidate)) {
          let content = ''
          try { content = fs.readFileSync(candidate, 'utf8') } catch {
            throw new ControlError(ERR.INTERNAL, 'Lecture de la note impossible')
          }
          return { file, dir: sub, content }
        }
      }
      throw new ControlError(ERR.RUN_NOT_FOUND, `Note introuvable : ${file}`)
    },

    // ── memory.graph (LECTURE — KnowledgeGraph projeté pour la viz 3D) ───────────
    // Wrapper graph-builder/graph-memory → { nodes, edges, stats }. Options :
    // pagerank (calcule l'importance), top (N nœuds majeurs). Dégradation : vide.
    'memory.graph': (p) => {
      const pagerank = p.pagerank === true || p.pagerank === 'true' || p.pagerank === 1
      let top = 0
      if (p.top !== undefined) {
        top = parseInt(p.top, 10)
        if (!Number.isFinite(top) || top < 0) top = 0
        if (top > 1000) top = 1000
      }
      return buildMemoryGraph({ pagerank, top })
    },

    // ── pr.* (LECTURE / [MUTATIF GitHub]) ───────────────────────────────────────
    'pr.status': () => ({ config: getPr().loadPrConfig() }),

    // ── logs.tail (LECTURE — events.ndjson + daemon.log) ────────────────────────
    'logs.tail': (p) => {
      const n = Math.min(Math.max(parseInt(p.lines, 10) || 100, 1), 1000)
      const which = p.source === 'daemon' ? 'daemon' : 'events'
      const file = which === 'daemon'
        ? (getDaemon().LOG_FILE)
        : (process.env.ADA_EVENTS_LOG || path.join(resolveProfileDir(), 'events.ndjson'))
      let lines = []
      try {
        const raw = fs.readFileSync(file, 'utf8').split('\n').filter(Boolean)
        lines = raw.slice(-n)
      } catch {}
      return { source: which, file, lines, count: lines.length }
    },

    // ════════════════════════════════════════════════════════════════════════
    // P7 — Features de configuration (RPC). Lecture seule sauf [MUTATIF].
    //   pipelines.* / mcp.* / profiles.switch+create / teams.* / agents.info /
    //   settings.*  — mutations sur ~/.ada.json / settings.json / FS teams.
    // ════════════════════════════════════════════════════════════════════════

    // ── pipelines.* (LECTURE — coordinator/pipelines.json) ──────────────────────
    'pipelines.list': () => {
      const pipelines = readPipelines()
      return { pipelines, total: pipelines.length }
    },
    'pipelines.get': (p) => {
      const name = String(p.name || '')
      if (!name) throw new ControlError(ERR.INVALID_PARAMS, 'pipelines.get requiert { name }')
      const pipeline = readPipelines().find(pl => pl.name === name)
      if (!pipeline) throw new ControlError(ERR.RUN_NOT_FOUND, `Pipeline introuvable : ${name}`)
      return { pipeline }
    },

    // ── mcp.* (LECTURE / [MUTATIF settings.json mcpServers]) ────────────────────
    'mcp.list': () => {
      const settings = readJsonSafe(settingsPath(), {})
      const servers = (settings && typeof settings.mcpServers === 'object' && settings.mcpServers) || {}
      const connectors = Object.entries(servers).map(([id, cfg]) => {
        const c = (cfg && typeof cfg === 'object') ? cfg : {}
        return {
          id,
          name: id,
          transport: c.url ? 'http' : 'stdio',
          command: c.command ?? null,
          url: c.url ?? null,
          args: Array.isArray(c.args) ? c.args : [],
          // Masque les valeurs des env (jamais de secret en clair).
          env: Object.keys(c.env || {}),
          enabled: c.enabled !== false,
        }
      })
      return { connectors, total: connectors.length }
    },
    'mcp.registry': () => ({ catalog: MCP_CATALOG, total: MCP_CATALOG.length }),
    // [MUTATIF — ajoute une entrée mcpServers dans settings.json.]
    'mcp.add': (p) => {
      const id = String(p.id || p.name || '')
      if (!id || !SAFE_CONNECTOR_RE.test(id)) throw new ControlError(ERR.INVALID_PARAMS, 'mcp.add requiert { id|name } valide (a-z0-9_-)')
      if (!p.command && !p.url) throw new ControlError(ERR.INVALID_PARAMS, 'mcp.add requiert { command } ou { url }')
      const settings = readJsonSafe(settingsPath(), {})
      if (!settings.mcpServers || typeof settings.mcpServers !== 'object') settings.mcpServers = {}
      if (settings.mcpServers[id]) throw new ControlError(ERR.INVALID_PARAMS, `Connecteur déjà présent : ${id}`)
      const entry = {}
      if (p.command) entry.command = String(p.command)
      if (p.url) entry.url = String(p.url)
      if (Array.isArray(p.args)) entry.args = p.args.map(String)
      if (p.env && typeof p.env === 'object') entry.env = p.env
      settings.mcpServers[id] = entry
      writeJsonAtomic(settingsPath(), settings)
      return { ok: true, id, connector: { id, ...entry, env: Object.keys(entry.env || {}) } }
    },
    // [MUTATIF — met à jour une entrée mcpServers.]
    'mcp.update': (p) => {
      const id = String(p.id || '')
      if (!id || !SAFE_CONNECTOR_RE.test(id)) throw new ControlError(ERR.INVALID_PARAMS, 'mcp.update requiert { id } valide')
      const settings = readJsonSafe(settingsPath(), {})
      const servers = (settings && typeof settings.mcpServers === 'object' && settings.mcpServers) || {}
      if (!servers[id]) throw new ControlError(ERR.RUN_NOT_FOUND, `Connecteur introuvable : ${id}`)
      const cur = servers[id]
      if (p.command !== undefined) cur.command = String(p.command)
      if (p.url !== undefined) cur.url = String(p.url)
      if (p.args !== undefined) cur.args = Array.isArray(p.args) ? p.args.map(String) : []
      if (p.env !== undefined && p.env && typeof p.env === 'object') cur.env = p.env
      if (p.enabled !== undefined) cur.enabled = !!p.enabled
      settings.mcpServers = servers
      writeJsonAtomic(settingsPath(), settings)
      return { ok: true, id, connector: { id, ...cur, env: Object.keys(cur.env || {}) } }
    },
    // [MUTATIF — retire une entrée mcpServers.]
    'mcp.remove': (p) => {
      const id = String(p.id || '')
      if (!id || !SAFE_CONNECTOR_RE.test(id)) throw new ControlError(ERR.INVALID_PARAMS, 'mcp.remove requiert { id } valide')
      const settings = readJsonSafe(settingsPath(), {})
      const servers = (settings && typeof settings.mcpServers === 'object' && settings.mcpServers) || {}
      const existed = Object.prototype.hasOwnProperty.call(servers, id)
      delete servers[id]
      settings.mcpServers = servers
      writeJsonAtomic(settingsPath(), settings)
      return { ok: true, removed: existed ? 1 : 0 }
    },

    // ── profiles.switch / profiles.create ([MUTATIF ~/.ada.json]) ───────────────
    // [MUTATIF — change activeProfile dans ~/.ada.json (format claude-<nom>).]
    'profiles.switch': (p) => {
      const name = String(p.profile || '').replace(/^claude-/, '')
      if (!SAFE_PROFILE_RE.test(name)) throw new ControlError(ERR.INVALID_PARAMS, 'profiles.switch requiert { profile } valide (a-z0-9-)')
      const cfg = readAdaConfig()
      const installed = cfg.installedProfiles ?? []
      const fq = 'claude-' + name
      if (installed.length && !installed.includes(fq) && !installed.includes(name)) {
        throw new ControlError(ERR.RUN_NOT_FOUND, `Profil non installé : ${name}`)
      }
      cfg.activeProfile = fq
      writeAdaConfig(cfg)
      return { ok: true, active: fq }
    },
    // [MUTATIF — enregistre un profil dans installedProfiles (~/.ada.json).]
    'profiles.create': (p) => {
      const name = String(p.name || '').replace(/^claude-/, '')
      if (!SAFE_PROFILE_RE.test(name)) throw new ControlError(ERR.INVALID_PARAMS, 'profiles.create requiert { name } valide (a-z0-9-)')
      const cfg = readAdaConfig()
      if (!Array.isArray(cfg.installedProfiles)) cfg.installedProfiles = []
      const fq = 'claude-' + name
      if (cfg.installedProfiles.includes(fq) || cfg.installedProfiles.includes(name)) {
        throw new ControlError(ERR.INVALID_PARAMS, `Profil déjà présent : ${name}`)
      }
      cfg.installedProfiles.push(fq)
      if (p.activate) cfg.activeProfile = fq
      writeAdaConfig(cfg)
      return { ok: true, profile: { name, dir: path.join(os.homedir(), '.' + fq), active: cfg.activeProfile === fq } }
    },

    // ── teams.* (LECTURE / [MUTATIF coordinator/teams.json]) ────────────────────
    'teams.list': () => {
      const teams = readTeams()
      return { teams, total: teams.length }
    },
    'teams.get': (p) => {
      const id = String(p.id || '')
      if (!id) throw new ControlError(ERR.INVALID_PARAMS, 'teams.get requiert { id }')
      const team = readTeams().find(t => t.id === id)
      if (!team) throw new ControlError(ERR.RUN_NOT_FOUND, `Team introuvable : ${id}`)
      return { team }
    },
    // [MUTATIF — ajoute une team dans teams.json.]
    'teams.create': (p) => {
      const name = String(p.name || '')
      if (!name || name.length > 64) throw new ControlError(ERR.INVALID_PARAMS, 'teams.create requiert { name } (<= 64 car.)')
      if (!Array.isArray(p.agents) || p.agents.length === 0) throw new ControlError(ERR.INVALID_PARAMS, 'teams.create requiert { agents:[...] } non vide')
      const teams = readTeams()
      const now = new Date().toISOString()
      const team = {
        id: randomUUID(),
        name,
        agents: p.agents.map(String),
        ...(p.pipeline ? { pipeline: String(p.pipeline) } : {}),
        ...(p.description ? { description: String(p.description) } : {}),
        createdAt: now,
        updatedAt: now,
      }
      teams.push(team)
      writeJsonAtomic(teamsPath(), teams)
      return { ok: true, team }
    },
    // [MUTATIF — met à jour une team.]
    'teams.update': (p) => {
      const id = String(p.id || '')
      if (!SAFE_UUID_RE.test(id)) throw new ControlError(ERR.INVALID_PARAMS, 'teams.update requiert { id } (uuid)')
      const teams = readTeams()
      const idx = teams.findIndex(t => t.id === id)
      if (idx === -1) throw new ControlError(ERR.RUN_NOT_FOUND, `Team introuvable : ${id}`)
      teams[idx] = {
        ...teams[idx],
        ...(p.name        !== undefined ? { name: String(p.name) } : {}),
        ...(p.agents      !== undefined ? { agents: (Array.isArray(p.agents) ? p.agents : []).map(String) } : {}),
        ...(p.pipeline    !== undefined ? { pipeline: String(p.pipeline) } : {}),
        ...(p.description !== undefined ? { description: String(p.description) } : {}),
        id,
        updatedAt: new Date().toISOString(),
      }
      writeJsonAtomic(teamsPath(), teams)
      return { ok: true, team: teams[idx] }
    },
    // [MUTATIF — retire une team.]
    'teams.remove': (p) => {
      const id = String(p.id || '')
      if (!SAFE_UUID_RE.test(id)) throw new ControlError(ERR.INVALID_PARAMS, 'teams.remove requiert { id } (uuid)')
      const teams = readTeams()
      const filtered = teams.filter(t => t.id !== id)
      writeJsonAtomic(teamsPath(), filtered)
      return { ok: true, removed: teams.length - filtered.length }
    },

    // ── agents.info (LECTURE — frontmatter complet + prompt méta) ───────────────
    'agents.info': (p) => {
      const slug = String(p.slug || '')
      if (!SAFE_NAME_RE.test(slug)) throw new ControlError(ERR.INVALID_PARAMS, 'agents.info requiert { slug } valide')
      const agentsDir = path.join(resolveProfileDir(), 'agents')
      let promptPath = path.join(agentsDir, slug + '.md')
      if (!fs.existsSync(promptPath)) {
        const dirPath = path.join(agentsDir, slug, 'CLAUDE.md')
        if (!fs.existsSync(dirPath)) throw new ControlError(ERR.RUN_NOT_FOUND, `Agent introuvable : ${slug}`)
        promptPath = dirPath
      }
      let content = ''
      try { content = fs.readFileSync(promptPath, 'utf8') } catch {}
      const fm = parseFrontmatter(content)
      // Thompson priors (router) pour stats — dégradation gracieuse.
      let stats = { totalRuns: 0, successRate: 0, alpha: 0, beta: 0, pWin: 0 }
      try {
        const router = getRouter()
        const rs = router.loadState()
        const prior = rs.priors && (rs.priors[slug] || Object.entries(rs.priors).find(([k]) => k.endsWith(':' + slug))?.[1])
        if (prior) {
          const total = (prior.successes ?? 0) + (prior.failures ?? 0)
          stats = {
            totalRuns: total,
            successRate: total > 0 ? (prior.successes ?? 0) / total : 0,
            alpha: prior.alpha ?? 0,
            beta: prior.beta ?? 0,
            pWin: (prior.alpha != null && prior.beta != null) ? prior.alpha / (prior.alpha + prior.beta) : 0,
          }
        }
      } catch {}
      const title = content.match(/^#\s+(.+)$/m)?.[1]?.trim() || slug
      const role  = content.match(/##\s+Rôle\s*\n([^\n#]+)/m)?.[1]?.trim() || ''
      return {
        agent: {
          slug,
          name: fm.name ?? title,
          title,
          description: fm.description ?? role,
          role,
          active: fm.active !== 'false',
          skills: fm.skills ? fm.skills.split(',').map(s => s.trim()).filter(Boolean) : [],
          prompt: content,
          stats,
        },
      }
    },

    // ── settings.* (LECTURE / [MUTATIF ~/.ada.json]) ────────────────────────────
    // Vue agrégée de ~/.ada.json : providers, budget, obsidian, webhook. Le secret
    // du webhook n'est jamais renvoyé en clair (présence signalée par hasSecret).
    'settings.get': () => {
      const cfg = readAdaConfig()
      const webhook = cfg.webhook && typeof cfg.webhook === 'object'
        ? { url: cfg.webhook.url ?? null, events: cfg.webhook.events ?? [], hasSecret: !!cfg.webhook.secret }
        : null
      return {
        settings: {
          providerMode: cfg.providerMode ?? 'claude-code',
          budget: cfg.budget ?? null,
          obsidian: cfg.obsidian ?? { enabled: false },
          webhook,
        },
      }
    },
    // [MUTATIF — fusionne providerMode/budget/obsidian/webhook dans ~/.ada.json.]
    'settings.set': (p) => {
      const cfg = readAdaConfig()
      if (p.providerMode !== undefined) {
        if (!['claude-code', 'api'].includes(p.providerMode)) throw new ControlError(ERR.INVALID_PARAMS, `providerMode invalide : ${p.providerMode}`)
        cfg.providerMode = p.providerMode
      }
      if (p.budget !== undefined && p.budget && typeof p.budget === 'object') {
        cfg.budget = { ...(cfg.budget || {}), ...p.budget }
      }
      if (p.obsidian !== undefined && p.obsidian && typeof p.obsidian === 'object') {
        cfg.obsidian = { ...(cfg.obsidian || {}), ...p.obsidian }
      }
      if (p.webhook !== undefined) {
        if (p.webhook === null) {
          delete cfg.webhook
        } else if (typeof p.webhook === 'object') {
          if (!p.webhook.url) throw new ControlError(ERR.INVALID_PARAMS, 'webhook.url requis')
          let parsed
          try { parsed = new URL(String(p.webhook.url)) } catch { throw new ControlError(ERR.INVALID_PARAMS, 'webhook.url invalide') }
          if (!['http:', 'https:'].includes(parsed.protocol)) throw new ControlError(ERR.INVALID_PARAMS, 'webhook.url doit être http/https')
          cfg.webhook = {
            url: String(p.webhook.url),
            events: Array.isArray(p.webhook.events) ? p.webhook.events.map(String) : [],
            ...(p.webhook.secret ? { secret: String(p.webhook.secret) } : (cfg.webhook?.secret ? { secret: cfg.webhook.secret } : {})),
          }
        }
      }
      writeAdaConfig(cfg)
      const webhook = cfg.webhook && typeof cfg.webhook === 'object'
        ? { url: cfg.webhook.url ?? null, events: cfg.webhook.events ?? [], hasSecret: !!cfg.webhook.secret }
        : null
      return {
        ok: true,
        settings: {
          providerMode: cfg.providerMode ?? 'claude-code',
          budget: cfg.budget ?? null,
          obsidian: cfg.obsidian ?? { enabled: false },
          webhook,
        },
      }
    },
  }

  return methods
}

module.exports = { buildMethodRegistry }
