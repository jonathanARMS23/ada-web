#!/usr/bin/env node
'use strict'
/**
 * coordinator/control-server.js — Control Server du plan de contrôle ADA (P0).
 *
 * Réf : ADR-016 (control-plane-protocol) §1 transport/framing/auth, §2 catalogue
 * de méthodes, §3 events, §7 lifecycle, §8 erreurs, §9 sécurité.
 * Réf : ROADMAP-control-plane (P0) — règle « seul le Control Server mute state.json ».
 *
 * Responsabilités :
 *   - Transport : UDS `<profileDir>/control.sock` (perms 0600) ; fallback TCP
 *     127.0.0.1:<port> si ADA_CONTROL_TCP est défini (jamais 0.0.0.0).
 *   - Framing : JSON-RPC 2.0 sur NDJSON (une frame = une ligne JSON + \n).
 *   - Auth : HMAC par frame via ipc-canonical (octets identiques émetteur/vérif).
 *   - Handshake `hello` obligatoire (protocolVersion semver, profile).
 *   - Méthodes in-process (require) : run.* / router.* / bank.* / provider.* /
 *     cost.* / metrics.* / budget.* / capabilities.* / health.*.
 *   - Events normalisés corrélés {runId, workspaceId, conversationId}, émis sur
 *     socket (clients abonnés) + events.ndjson dans le même tick que l'écriture.
 *   - PID file `<profileDir>/control.pid`, SIGTERM gracieux (drain).
 *
 * Zéro dépendance externe (net / crypto / fs natifs).
 */

const net  = require('net')
const fs   = require('fs')
const os   = require('os')
const path = require('path')
const { randomUUID } = require('crypto')

const { sign, verify, attachSignature } = require('./ipc-canonical.js')
const { signEvent: signEventLine, loadIpcSecret } = require('./ipc-emit.js')
const { buildMethodRegistry } = require('./control-handlers.js')

// ── Constantes protocole (ADR-016 §1, §7) ────────────────────────────────────

const PROTOCOL_VERSION = '1.0.0'

// ── Codes d'erreur (ADR-016 §8) ───────────────────────────────────────────────
// JSON-RPC standard (négatifs) + domaine ADA (1000+).
const ERR = {
  PARSE:            -32700,  // JSON invalide
  INVALID_REQUEST:  -32600,  // frame non conforme JSON-RPC
  METHOD_NOT_FOUND: -32601,
  INVALID_PARAMS:   -32602,
  INTERNAL:         -32603,
  // Domaine ADA (ADR-016 §8)
  RUN_NOT_FOUND:    1001,    // RUN_NOT_FOUND — runId inconnu
  LOCKED:           1002,    // PHASE_LOCKED — lock runs/<id>.lock détenu
  BUDGET_EXCEEDED:  1003,    // BUDGET_EXCEEDED
  PROFILE_MISMATCH: 1004,    // PROFILE_MISMATCH
  PROTOCOL_INCOMPAT:1005,    // PROTOCOL_VERSION_UNSUPPORTED
  CLAUDE_EXEC_FAILED:1006,   // CLAUDE_EXEC_FAILED (réservé spawn `claude` — P1)
  // Auth HMAC : non listé dans §8 ; surfacé en -32600 (requête invalide au transport).
  AUTH_FAILED:      -32600,
  NOT_HANDSHAKED:   -32600,  // méthode appelée hors séquence (avant `hello`)
}

// ── Résolution profil / chemins ───────────────────────────────────────────────

function resolveProfileDir() {
  return process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), '.claude')
}

function profileName(profileDir) {
  // ~/.claude-pro → "claude-pro" ; ~/.claude → "claude"
  return path.basename(profileDir).replace(/^\./, '')
}

// ── Erreur taggée (levée par les handlers, mappée en JSON-RPC error) ──────────

class ControlError extends Error {
  /** @param {number} code @param {string} message @param {unknown} [data] */
  constructor(code, message, data) {
    super(message)
    this.code = code
    this.data = data
  }
}

// ── Harnais run.* CLI : intercepte process.exit + capture stdout ──────────────
//
// Les commandes cmd* de run.js sont orientées CLI : elles appellent process.exit()
// et écrivent sur stdout/stderr. Pour les exécuter in-process sans tuer le daemon,
// on intercepte process.exit (→ throw taggé) et on capture les écritures stdout.
//
// Mappe les messages connus vers les codes ADR-016 §8.

/**
 * @param {() => unknown} fn
 * @returns {{ stdout: string, stderr: string, result: unknown }}
 */
function runCliHarness(fn) {
  const realExit  = process.exit
  const realOut   = process.stdout.write.bind(process.stdout)
  const realErr   = process.stderr.write.bind(process.stderr)
  let stdout = ''
  let stderr = ''
  /** @type {{ code: number } | null} */
  let exitSignal = null

  // @ts-ignore — override volontaire et restauré dans finally
  process.exit = (code = 0) => { exitSignal = { code: code | 0 }; throw new __ExitInterrupt(code | 0) }
  // @ts-ignore
  process.stdout.write = (chunk, ...a) => { stdout += String(chunk); return true }
  // @ts-ignore
  process.stderr.write = (chunk, ...a) => { stderr += String(chunk); return true }

  let result
  try {
    result = fn()
  } catch (e) {
    if (!(e instanceof __ExitInterrupt)) {
      // erreur réelle d'un handler → restaurer puis remonter telle quelle
      process.exit = realExit
      process.stdout.write = realOut
      process.stderr.write = realErr
      throw e
    }
    // process.exit intercepté : décider succès / échec selon le code + le texte
  } finally {
    process.exit = realExit
    process.stdout.write = realOut
    process.stderr.write = realErr
  }

  if (exitSignal && exitSignal.code !== 0) {
    const txt = stdout + '\n' + stderr
    throw mapCliFailure(txt, exitSignal.code)
  }

  return { stdout, stderr, result }
}

class __ExitInterrupt extends Error {
  constructor(code) { super('process.exit(' + code + ')'); this.code = code }
}

/**
 * Mappe un échec CLI (texte stdout+stderr) vers un ControlError ADR-016 §8.
 * @param {string} text
 * @param {number} code
 * @returns {ControlError}
 */
function mapCliFailure(text, code) {
  const t = text || ''
  if (/Run not found/i.test(t))          return new ControlError(ERR.RUN_NOT_FOUND, t.trim() || 'Run not found')
  if (/verrouill|locked/i.test(t))       return new ControlError(ERR.LOCKED, 'Run verrouillé par un autre processus')
  if (/budget/i.test(t) && /STOP|exceed|dépass/i.test(t))
                                         return new ControlError(ERR.BUDGET_EXCEEDED, t.trim() || 'Budget exceeded')
  return new ControlError(ERR.INTERNAL, (t.trim() || 'CLI command failed') + ` (exit ${code})`)
}

// ── Registre des méthodes RPC (ADR-016 §2) ────────────────────────────────────
//
// buildMethodRegistry(deps) vit désormais dans control-handlers.js (axe C3) :
// registre de handlers séparé du transport. Appelé depuis le constructeur de
// ControlServer avec les dépendances (constantes, helpers) injectées.

// Lecture des fichiers d'état du daemon sans dépendre de son CLI (process.exit-free).
function readDaemonPid(daemon) {
  try { return parseInt(fs.readFileSync(daemon.PID_FILE, 'utf8').trim(), 10) || null } catch { return null }
}
function readDaemonState(daemon) {
  try { return JSON.parse(fs.readFileSync(daemon.STATE_FILE, 'utf8')) } catch { return { workers: {} } }
}

// cmdStart est async (await diff-review/ACW) — adaptation dédiée avec interception
// de process.exit via une promesse rejetée.
async function runStartAsync(run, p) {
  const realExit = process.exit
  const realOut  = process.stdout.write.bind(process.stdout)
  const realErr  = process.stderr.write.bind(process.stderr)
  let stdout = ''
  let stderr = ''
  let exitCode = null
  // @ts-ignore
  process.exit = (code = 0) => { exitCode = code | 0; throw new __ExitInterrupt(code | 0) }
  // @ts-ignore
  process.stdout.write = (chunk) => { stdout += String(chunk); return true }
  // @ts-ignore
  process.stderr.write = (chunk) => { stderr += String(chunk); return true }
  try {
    await run.cmdStart([p.runId, p.phaseId])
  } catch (e) {
    if (!(e instanceof __ExitInterrupt)) throw e
  } finally {
    process.exit = realExit
    process.stdout.write = realOut
    process.stderr.write = realErr
  }
  if (exitCode && exitCode !== 0) throw mapCliFailure(stdout + '\n' + stderr, exitCode)
  return { ok: true, output: stdout.trim() }
}

/**
 * loadState de run.js appelle process.exit(1) si le run est introuvable.
 * On l'enveloppe pour le traduire en ControlError 1001 sans tuer le daemon.
 */
function safeLoadState(run, runId) {
  const realExit = process.exit
  const realErr  = process.stderr.write.bind(process.stderr)
  let stderr = ''
  let exited = false
  // @ts-ignore
  process.exit = () => { exited = true; throw new __ExitInterrupt(1) }
  // @ts-ignore
  process.stderr.write = (chunk) => { stderr += String(chunk); return true }
  try {
    return run.loadState(runId)
  } catch (e) {
    if (e instanceof __ExitInterrupt) {
      throw new ControlError(ERR.RUN_NOT_FOUND, stderr.trim() || `Run not found: ${runId}`)
    }
    throw e
  } finally {
    process.exit = realExit
    process.stderr.write = realErr
  }
}

// ── Server ────────────────────────────────────────────────────────────────────

class ControlServer {
  /** @param {{ profileDir?: string, tcpPort?: number, secret?: string }} [opts] */
  constructor(opts = {}) {
    this.profileDir = opts.profileDir || resolveProfileDir()
    this.profile    = profileName(this.profileDir)
    this.secret     = opts.secret || loadIpcSecret()
    // S2 — defense-in-depth : un secret absent ne devrait plus arriver (auto-gen),
    // mais si c'est le cas (disque RO…) on le signale au lieu de tourner sans auth en silence.
    if (!this.secret) {
      try { require('./logger').warn('control-server', '⚠ SECRET IPC ABSENT — auth HMAC désactivée ! Vérifier ~/.ada/ipc.secret (doit être 0600)') } catch {}
    }
    this.tcpPort    = opts.tcpPort ?? (process.env.ADA_CONTROL_TCP ? parseInt(process.env.ADA_CONTROL_TCP, 10) : null)
    this.sockPath   = path.join(this.profileDir, 'control.sock')
    this.pidPath    = path.join(this.profileDir, 'control.pid')
    this.eventsLog  = process.env.ADA_EVENTS_LOG || path.join(this.profileDir, 'events.ndjson')
    this.methods    = buildMethodRegistry({
      ERR, PROTOCOL_VERSION, ControlError,
      resolveProfileDir, profileName,
      runCliHarness, runStartAsync, safeLoadState,
      readDaemonPid, readDaemonState, isAlive,
    })
    /** @type {Set<net.Socket>} */
    this.clients    = new Set()
    /** @type {Set<net.Socket>} subscribed to the event stream */
    this.subscribers = new Set()
    this.server     = null
    this.draining   = false
    this._emittedIds = new Set()  // dédup events par id (lossless lifecycle)
  }

  start() {
    return new Promise((resolve, reject) => {
      fs.mkdirSync(this.profileDir, { recursive: true })

      this.server = net.createServer(sock => this._onConnection(sock))
      this.server.on('error', reject)

      const onListen = () => {
        try { fs.writeFileSync(this.pidPath, String(process.pid)) } catch {}
        this._installSignals()
        resolve(this._endpointInfo())
      }

      if (this.tcpPort) {
        // Fallback TCP — strictement loopback, jamais 0.0.0.0 (ADR-016 §9).
        this.server.listen(this.tcpPort, '127.0.0.1', onListen)
      } else {
        try { if (fs.existsSync(this.sockPath)) fs.unlinkSync(this.sockPath) } catch {}
        this.server.listen(this.sockPath, () => {
          try { fs.chmodSync(this.sockPath, 0o600) } catch {}
          onListen()
        })
      }
    })
  }

  _endpointInfo() {
    return this.tcpPort
      ? { transport: 'tcp', host: '127.0.0.1', port: this.tcpPort }
      : { transport: 'uds', path: this.sockPath }
  }

  _onConnection(sock) {
    this.clients.add(sock)
    /** @type {{ handshaked: boolean }} */
    const session = { handshaked: false }
    let buffer = ''

    sock.setEncoding('utf8')
    sock.on('data', chunk => {
      buffer += chunk
      let idx
      while ((idx = buffer.indexOf('\n')) !== -1) {
        const line = buffer.slice(0, idx)
        buffer = buffer.slice(idx + 1)
        if (line.trim()) this._onFrame(sock, session, line)
      }
    })
    sock.on('error', () => {})
    sock.on('close', () => { this.clients.delete(sock); this.subscribers.delete(sock) })
  }

  async _onFrame(sock, session, line) {
    let frame
    try {
      frame = JSON.parse(line)
    } catch {
      return this._sendError(sock, null, ERR.PARSE, 'Parse error: invalid JSON frame')
    }

    if (!frame || frame.jsonrpc !== '2.0' || typeof frame.method !== 'string') {
      return this._sendError(sock, frame?.id ?? null, ERR.INVALID_REQUEST, 'Invalid JSON-RPC 2.0 request')
    }

    const { id, method, params } = frame

    // ── Auth HMAC par frame (ADR-016 §1) ──────────────────────────────────────
    if (this.secret) {
      if (!verify(frame, this.secret)) {
        return this._sendError(sock, id ?? null, ERR.AUTH_FAILED, 'HMAC signature invalide ou absente')
      }
    }

    // ── Handshake (ADR-016 §7) ────────────────────────────────────────────────
    if (method === 'hello') {
      return this._handleHello(sock, session, id, params || {})
    }

    if (!session.handshaked) {
      return this._sendError(sock, id ?? null, ERR.NOT_HANDSHAKED, 'Handshake `hello` requis avant toute méthode')
    }

    if (method === 'subscribe') {
      this.subscribers.add(sock)
      return this._sendResult(sock, id, { subscribed: true })
    }

    const handler = this.methods[method]
    if (!handler) {
      return this._sendError(sock, id ?? null, ERR.METHOD_NOT_FOUND, `Méthode inconnue : ${method}`)
    }

    try {
      const ctx = { emit: (type, payload, corr) => this.emitEvent(type, payload, corr) }
      const result = await handler(params || {}, ctx)
      // Notification (pas d'id) → pas de réponse attendue.
      if (id === undefined || id === null) return
      this._sendResult(sock, id, result)
    } catch (e) {
      if (e instanceof ControlError) {
        return this._sendError(sock, id ?? null, e.code, e.message, e.data)
      }
      return this._sendError(sock, id ?? null, ERR.INTERNAL, e?.message || 'Internal error')
    }
  }

  _handleHello(sock, session, id, params) {
    const clientVersion = params.protocolVersion
    if (typeof clientVersion !== 'string' || !isCompatible(clientVersion, PROTOCOL_VERSION)) {
      return this._sendError(sock, id ?? null, ERR.PROTOCOL_INCOMPAT,
        `protocolVersion incompatible : client=${clientVersion} serveur=${PROTOCOL_VERSION}`)
    }
    if (params.profile && params.profile !== this.profile) {
      return this._sendError(sock, id ?? null, ERR.PROFILE_MISMATCH,
        `profil mismatch : hello.profile=${params.profile} serveur=${this.profile}`)
    }
    session.handshaked = true
    session.profile = this.profile
    return this._sendResult(sock, id, {
      protocolVersion: PROTOCOL_VERSION,
      profile: this.profile,
      serverPid: process.pid,
    })
  }

  // ── Émission de frames ──────────────────────────────────────────────────────

  _frame(obj) {
    const out = this.secret ? attachSignature(obj, this.secret) : obj
    return JSON.stringify(out) + '\n'
  }

  _sendResult(sock, id, result) {
    try { sock.write(this._frame({ jsonrpc: '2.0', id: id ?? null, result })) } catch {}
  }

  _sendError(sock, id, code, message, data) {
    const error = { code, message }
    if (data !== undefined) error.data = data
    try { sock.write(this._frame({ jsonrpc: '2.0', id: id ?? null, error })) } catch {}
  }

  // ── Events normalisés (ADR-016 §3) ────────────────────────────────────────
  //
  // Lifecycle (run.started / run.phase.* / run.completed) = lossless : journalisés
  // dans events.ndjson ET poussés aux abonnés. Dédup par `id`.

  /**
   * @param {string} type
   * @param {object} payload
   * @param {{ runId?: string, workspaceId?: string, conversationId?: string }} [corr]
   */
  emitEvent(type, payload, corr = {}) {
    const evt = {
      id: randomUUID(),
      ts: Date.now(),
      type,
      corr: {
        runId:          corr.runId ?? payload?.runId ?? null,
        workspaceId:    corr.workspaceId ?? process.env.ADA_WORKSPACE_ID ?? null,
        conversationId: corr.conversationId ?? process.env.ADA_CONVERSATION_ID ?? null,
      },
      payload,
    }
    if (this._emittedIds.has(evt.id)) return
    this._emittedIds.add(evt.id)

    const line = signEventLine(evt)  // même encodage signé que ipc-emit

    // events.ndjson — écriture dans le même tick (lossless)
    try {
      fs.mkdirSync(path.dirname(this.eventsLog), { recursive: true })
      fs.appendFileSync(this.eventsLog, line, 'utf8')
    } catch {}

    // Push aux abonnés (lossy si le client est lent / déconnecté)
    for (const sub of this.subscribers) {
      try { sub.write(line) } catch {}
    }
    return evt
  }

  // ── Lifecycle serveur ─────────────────────────────────────────────────────

  _installSignals() {
    if (this._signalsInstalled) return
    this._signalsInstalled = true
    const onTerm = () => { this.stop().then(() => process.exit(0)).catch(() => process.exit(1)) }
    process.on('SIGTERM', onTerm)
    process.on('SIGINT', onTerm)
  }

  /** Arrêt gracieux : refuse les nouvelles connexions, draine puis ferme. */
  stop() {
    return new Promise(resolve => {
      if (this.draining) return resolve()
      this.draining = true
      try { for (const c of this.clients) c.end() } catch {}
      const done = () => {
        try { if (fs.existsSync(this.pidPath)) fs.unlinkSync(this.pidPath) } catch {}
        if (!this.tcpPort) { try { if (fs.existsSync(this.sockPath)) fs.unlinkSync(this.sockPath) } catch {} }
        resolve()
      }
      if (this.server) this.server.close(done)
      else done()
    })
  }
}

// ── Compat semver (majeur identique ⇒ compatible) ─────────────────────────────

function isCompatible(clientVersion, serverVersion) {
  const cm = parseInt(String(clientVersion).split('.')[0], 10)
  const sm = parseInt(String(serverVersion).split('.')[0], 10)
  return Number.isInteger(cm) && cm === sm
}

// ── CLI : start | stop | status ───────────────────────────────────────────────

function pidPathFor(profileDir) { return path.join(profileDir, 'control.pid') }

function readPid(profileDir) {
  try {
    const pid = parseInt(fs.readFileSync(pidPathFor(profileDir), 'utf8').trim(), 10)
    return Number.isInteger(pid) ? pid : null
  } catch { return null }
}

function isAlive(pid) {
  if (!pid) return false
  try { process.kill(pid, 0); return true } catch { return false }
}

async function cliMain() {
  const [,, sub] = process.argv
  const profileDir = resolveProfileDir()

  if (sub === 'stop') {
    const pid = readPid(profileDir)
    if (!isAlive(pid)) { console.log('Control server non démarré'); process.exit(0) }
    try { process.kill(pid, 'SIGTERM') } catch {}
    console.log(`Control server (pid ${pid}) arrêté`)
    process.exit(0)
  }

  if (sub === 'status') {
    const pid = readPid(profileDir)
    if (isAlive(pid)) {
      console.log(JSON.stringify({ running: true, pid, profile: profileName(profileDir), profileDir }))
      process.exit(0)
    }
    console.log(JSON.stringify({ running: false, profileDir }))
    process.exit(1)
  }

  // start (défaut)
  const existing = readPid(profileDir)
  if (isAlive(existing)) {
    console.error(`Control server déjà démarré (pid ${existing})`)
    process.exit(1)
  }
  const server = new ControlServer({ profileDir })
  const info = await server.start()
  console.log(JSON.stringify({ started: true, pid: process.pid, profile: server.profile, ...info }))
  // Garder le process vivant — le serveur écoute jusqu'à SIGTERM.
}

module.exports = { ControlServer, ControlError, ERR, PROTOCOL_VERSION, isCompatible, resolveProfileDir, profileName }

if (require.main === module) {
  cliMain().catch(e => { console.error('[control-server] ' + (e?.message || e)); process.exit(1) })
}
