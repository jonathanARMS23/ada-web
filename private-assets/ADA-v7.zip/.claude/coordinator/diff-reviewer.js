#!/usr/bin/env node
'use strict'
/**
 * coordinator/diff-reviewer.js — Contexte sémantique pour les phases reviewer
 *
 * Avant chaque phase reviewer, récupère depuis bank.js les patterns de reviews
 * passées sur des diffs similaires et retourne un bloc de contexte injecté.
 *
 * Contrat public :
 *   getReviewContext(diffSummary) → Promise<{ patterns, warnings, injectedContext }>
 */

const { join } = require('path')

const CONFIG_DIR = process.env.CLAUDE_CONFIG_DIR || join(process.env.HOME || require('os').homedir(), '.claude')
const BANK_FILE  = join(CONFIG_DIR, 'coordinator', 'bank.js')

// ── Constantes ─────────────────────────────────────────────────────────────────

const MAX_CONTEXT_TOKENS = 300   // limite approx (1 token ≈ 4 chars)
const MAX_CONTEXT_CHARS  = MAX_CONTEXT_TOKENS * 4

/**
 * Charge bank.js de façon lazy — évite un crash au require si bank absent.
 * @returns {object|null}
 */
function loadBank() {
  const { existsSync } = require('fs')
  if (!existsSync(BANK_FILE)) return null
  try {
    return require(BANK_FILE)
  } catch {
    return null
  }
}

/**
 * Extrait les patterns & warnings d'une liste de trajectoires reviewer.
 * @param {Array<{lesson?: string, verdict?: string, summary?: string, phase?: string}>} trajectories
 * @returns {{ patterns: string[], warnings: string[] }}
 */
function extractPatterns(trajectories) {
  const patterns = []
  const warnings = []

  for (const traj of trajectories) {
    const source = traj.lesson || traj.summary || ''
    if (!source) continue

    // Patterns positifs : leçons de succès
    if (traj.verdict === 'success' || traj.verdict === 'partial') {
      const lines = source
        .split(/[.\n]/)
        .map(s => s.trim())
        .filter(s => s.length > 15 && s.length < 200)
      patterns.push(...lines.slice(0, 2))
    }

    // Warnings : leçons d'échec (ce qui a été flaggé)
    if (traj.verdict === 'failure' || traj.verdict === 'partial') {
      const lines = source
        .split(/[.\n]/)
        .map(s => s.trim())
        .filter(s => s.length > 15 && s.length < 200)
      warnings.push(...lines.slice(0, 2))
    }
  }

  // Déduplication — conserver l'ordre d'apparition
  const dedup = arr => [...new Map(arr.map(s => [s.toLowerCase(), s])).values()]

  return {
    patterns: dedup(patterns).slice(0, 5),
    warnings: dedup(warnings).slice(0, 5),
  }
}

/**
 * Construit le bloc de contexte injecté (max MAX_CONTEXT_CHARS).
 * @param {string[]} patterns
 * @param {string[]} warnings
 * @param {Array<{lesson?: string, summary?: string}>} trajectories
 * @returns {string}
 */
function buildInjectedContext(patterns, warnings, trajectories) {
  if (!patterns.length && !warnings.length) return ''

  const lines = [
    '# Review patterns from similar past diffs (ADA memory)',
  ]

  if (patterns.length) {
    lines.push('# Recurring issues:')
    for (const p of patterns) lines.push(`#   - ${p}`)
  }

  if (warnings.length) {
    lines.push('# What was flagged:')
    for (const w of warnings) lines.push(`#   - ${w}`)
  }

  // Leçons agrégées (première trajectoire avec un lesson/summary non-vide)
  const lesson = trajectories.find(t => (t.lesson || t.summary || '').length > 20)
  if (lesson) {
    const text = (lesson.lesson || lesson.summary || '').slice(0, 200)
    lines.push('# Lessons:')
    lines.push(`#   ${text}`)
  }

  const raw = lines.join('\n')
  // Tronquer si trop long — couper sur une limite de ligne propre
  if (raw.length <= MAX_CONTEXT_CHARS) return raw

  const truncated = raw.slice(0, MAX_CONTEXT_CHARS)
  const lastNewline = truncated.lastIndexOf('\n')
  return lastNewline > 0 ? truncated.slice(0, lastNewline) : truncated
}

// ── API publique ───────────────────────────────────────────────────────────────

/**
 * Retourne le contexte de review basé sur des diffs similaires passés.
 *
 * @param {string} diffSummary - résumé du diff git (ex: output de `git diff --stat`) ou description de la phase
 * @returns {Promise<{ patterns: string[], warnings: string[], injectedContext: string }>}
 */
async function getReviewContext(diffSummary) {
  const empty = { patterns: [], warnings: [], injectedContext: '' }

  if (!diffSummary || typeof diffSummary !== 'string') return empty

  const bank = loadBank()
  if (!bank) return empty

  try {
    // Timeout 2s — bank.retrieve peut être lent si Ollama indisponible
    const retrievePromise = (async () => {
      // Utiliser retrieveAsync si disponible, sinon retrieve synchrone
      if (typeof bank.retrieveAsync === 'function') {
        return bank.retrieveAsync(diffSummary, { limit: 4 })
      }
      return bank.retrieve(diffSummary, { limit: 4 })
    })()

    const timeoutPromise = new Promise((_, reject) =>
      setTimeout(() => reject(new Error('bank.retrieve timeout')), 2000)
    )

    /** @type {Array<any>} */
    const raw = await Promise.race([retrievePromise, timeoutPromise])
    if (!Array.isArray(raw)) return empty

    // Filtrer : ne garder que les trajectoires de phase reviewer
    const reviewerTrajs = raw.filter(t =>
      t && (t.agent === 'reviewer' || t.phase === 'review' || t.phase === 'reviewer')
    )

    if (!reviewerTrajs.length) return empty

    const { patterns, warnings } = extractPatterns(reviewerTrajs)
    const injectedContext = buildInjectedContext(patterns, warnings, reviewerTrajs)

    return { patterns, warnings, injectedContext }
  } catch {
    // Dégradation gracieuse — bank indisponible ou timeout
    return empty
  }
}

// ── Module ────────────────────────────────────────────────────────────────────

module.exports = { getReviewContext }
