'use strict'
/**
 * coordinator/embeddings.js — TF-IDF vectorizer natif (zéro dépendance)
 *
 * Produit des vecteurs TF-IDF sparse pour la recherche cosine similarity.
 * Utilisé comme fallback quand ollama est indisponible.
 */

// ── Stop words français + anglais ─────────────────────────────────────────────
const STOP_WORDS = new Set([
  // anglais
  'the','a','an','is','are','was','were','be','been','being','have','has','had',
  'do','does','did','will','would','could','should','may','might','must','shall',
  'to','of','in','for','on','with','at','by','from','as','or','and','but','if',
  'this','that','these','those','it','its','we','i','you','he','she','they',
  'not','no','can','get','use','set','add','new','return','create','build',
  // français
  'le','la','les','un','de','des','du','en','et','ou','mais','donc','or','ni',
  'que','qui','quoi','dont','où','je','tu','il','elle','nous','vous','ils',
  'me','te','se','lui','leur','y','au','aux','est','sont','être','avoir','fait',
  'par','sur','sous','dans','avec','pour','sans','entre','vers','chez',
])

// ── P1-1 — Normalisation lexicale (acronymes + formes équivalentes) ───────────
// Bug audité : "TS" (longueur 2) était jeté par le filtre length>2, et "auth" ≠
// "authentication", "ts" ≠ "typescript" n'étaient jamais unifiés à l'indexation.
// Conséquence : des conventions sémantiquement identiques restaient invisibles au
// recall selon la forme employée dans le prompt.
//
// 1. ACRONYMS_KEEP : acronymes techniques courts (≤2) préservés malgré le filtre.
// 2. NORMALIZE_MAP : table canonique appliquée DANS tokenize() → vaut donc à
//    l'indexation ET à la requête (pas seulement dans expandQuery).
const ACRONYMS_KEEP = new Set(['ts', 'db', 'ci', 'cd', 'ui', 'ux', 'js', 'go', 'qa', 'ai', 'ml'])

const NORMALIZE_MAP = new Map([
  ['ts', 'typescript'],
  ['typescrip', 'typescript'],   // forme stemmée de "typescript"
  ['auth', 'authentication'],
  ['authentica', 'authentication'], // forme stemmée
  ['db', 'database'],
  ['databa', 'database'],
  ['migra', 'migration'],        // stem de migration/migrations
  ['k8s', 'kubernetes'],
])

/**
 * Applique la normalisation canonique à un token déjà stemmé/filtré.
 * @param {string} t
 * @returns {string}
 */
function normalizeToken(t) {
  return NORMALIZE_MAP.get(t) || t
}

/**
 * Tokenize et stemme légèrement une chaîne.
 * P1-1 : préserve les acronymes techniques (ACRONYMS_KEEP) et normalise les
 * formes équivalentes (NORMALIZE_MAP) pour que l'unification s'applique en
 * indexation comme en requête.
 * @param {string} text
 * @returns {string[]}
 */
function tokenize(text) {
  return text
    .toLowerCase()
    .replace(/[^a-zàâäéèêëîïôùûüç0-9_\-]+/g, ' ')
    .split(/\s+/)
    // P1-1 : garder length>2 OU acronyme technique whitelisté
    .filter(t => (t.length > 2 || ACRONYMS_KEEP.has(t)) && !STOP_WORDS.has(t))
    // Stemming minimal : supprimer les suffixes communs (acronymes courts épargnés)
    .map(t => (t.length <= 3 || ACRONYMS_KEEP.has(t)) ? t : t
      .replace(/(?:tion|tions|ment|ments|ing|ings|ed|er|ers|est|ly)$/, '')
      .replace(/(?:ité|ités|ement|ements|eur|eurs)$/, '')
    )
    .filter(t => t.length > 2 || ACRONYMS_KEEP.has(t))
    // P1-1 : normalisation canonique (ts→typescript, auth→authentication…)
    .map(normalizeToken)
}

/**
 * Calcule TF (term frequency) pour un document.
 * @param {string[]} tokens
 * @returns {Map<string, number>}
 */
function termFrequency(tokens) {
  const tf = new Map()
  for (const t of tokens) tf.set(t, (tf.get(t) || 0) + 1)
  const maxFreq = Math.max(...tf.values(), 1)
  for (const [t, n] of tf) tf.set(t, n / maxFreq)
  return tf
}

/**
 * Construit un corpus IDF depuis un tableau de documents tokenisés.
 * @param {string[][]} tokenizedDocs
 * @returns {Map<string, number>}
 */
function buildIDF(tokenizedDocs) {
  const df = new Map()
  for (const doc of tokenizedDocs) {
    const unique = new Set(doc)
    for (const t of unique) df.set(t, (df.get(t) || 0) + 1)
  }
  const N = tokenizedDocs.length
  const idf = new Map()
  for (const [t, n] of df) idf.set(t, Math.log((N + 1) / (n + 1)) + 1)  // smooth IDF
  return idf
}

/**
 * Calcule le vecteur TF-IDF pour un document.
 * @param {string[]} tokens
 * @param {Map<string, number>} tf
 * @param {Map<string, number>} idf
 * @returns {Map<string, number>}
 */
function tfidfVector(tokens, tf, idf) {
  const vec = new Map()
  const unique = new Set(tokens)
  for (const t of unique) {
    const tfidfScore = (tf.get(t) || 0) * (idf.get(t) || Math.log(2))
    if (tfidfScore > 0) vec.set(t, tfidfScore)
  }
  return vec
}

/**
 * Similarité cosine entre deux vecteurs sparse (Map<string, number>).
 * @param {Map<string, number>} a
 * @param {Map<string, number>} b
 * @returns {number} — [0, 1]
 */
function cosineSimilarity(a, b) {
  let dot = 0, normA = 0, normB = 0
  for (const [t, v] of a) {
    if (b.has(t)) dot += v * b.get(t)
    normA += v * v
  }
  for (const v of b.values()) normB += v * v
  if (!normA || !normB) return 0
  return dot / (Math.sqrt(normA) * Math.sqrt(normB))
}

/**
 * Construit un index TF-IDF et retourne une fonction de recherche par
 * similarité cosine.
 *
 * @param {Array<{ id: string, text: string }>} documents
 * @returns {{ search: (query: string, topK?: number) => Array<{ id: string, score: number }> }}
 */
function buildIndex(documents) {
  if (!documents.length) return { search: () => [] }

  const tokenized = documents.map(d => tokenize(d.text))
  const idf = buildIDF(tokenized)

  const vectors = documents.map((d, i) => {
    const tokens = tokenized[i]
    const tf = termFrequency(tokens)
    return { id: d.id, vec: tfidfVector(tokens, tf, idf) }
  })

  function search(query, topK = 10) {
    const qTokens = tokenize(query)
    const qTf = termFrequency(qTokens)
    const qVec = tfidfVector(qTokens, qTf, idf)

    return vectors
      .map(({ id, vec }) => ({ id, score: cosineSimilarity(qVec, vec) }))
      .filter(r => r.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, topK)
  }

  return { search }
}

/**
 * Vectorise un seul texte avec un IDF pré-calculé.
 * Utile pour stocker le vecteur d'une trajectoire.
 * @param {string} text
 * @param {Map<string, number>} [idf]
 * @returns {{ tokens: string[], vector: Record<string, number> }}
 */
function embed(text, idf = new Map()) {
  const tokens = tokenize(text)
  const tf = termFrequency(tokens)
  const vec = tfidfVector(tokens, tf, idf)
  return { tokens, vector: Object.fromEntries(vec) }
}

/**
 * HNSW — Hierarchical Navigable Small World graph
 * Approximate Nearest Neighbor search en O(log n) vs O(n) brute-force.
 * Implémentation pure JS, zéro dépendance.
 *
 * Référence : Malkov & Yashunin (2018), https://arxiv.org/abs/1603.09320
 */
class HNSW {
  /**
   * @param {number} M — max connections par nœud par layer (défaut 16)
   * @param {number} efConstruction — taille du beam pendant la construction (défaut 200)
   */
  constructor(M = 16, efConstruction = 200) {
    this.M = M
    this.Mmax0 = M * 2          // layer 0 peut avoir 2x plus de connexions
    this.mL = 1 / Math.log(M)   // facteur de normalisation pour le tirage du level
    this.efConstruction = efConstruction
    /** @type {Map<string, { vector: number[], neighbors: Array<Set<string>>, level: number }>} */
    this.nodes = new Map()
    /** @type {string|null} */
    this.entryPoint = null
    this.maxLayer = -1
  }

  /** Génère un level aléatoire pour un nouveau nœud. */
  _randomLevel() {
    return Math.floor(-Math.log(Math.random() + 1e-10) * this.mL)
  }

  /**
   * Distance cosine entre deux vecteurs denses.
   * @param {number[]} a @param {number[]} b @returns {number} distance ∈ [0,2]
   */
  _dist(a, b) {
    let dot = 0, na = 0, nb = 0
    for (let i = 0; i < a.length; i++) {
      dot += a[i] * b[i]
      na  += a[i] * a[i]
      nb  += b[i] * b[i]
    }
    if (!na || !nb) return 1
    return 1 - dot / (Math.sqrt(na) * Math.sqrt(nb))
  }

  /**
   * Recherche greedy les ef plus proches voisins de query au layer lc.
   * @param {number[]} query
   * @param {string[]} entryPoints
   * @param {number} ef
   * @param {number} lc
   * @returns {Array<{id:string, dist:number}>} — trié par distance croissante
   */
  _searchLayer(query, entryPoints, ef, lc) {
    const visited  = new Set(entryPoints)
    // candidates = min-heap par dist ; W = max-heap par dist (résultats courants)
    // On simule avec des tableaux triés (volume faible)
    const candidates = entryPoints.map(id => ({
      id, dist: this._dist(query, this.nodes.get(id).vector)
    })).sort((a, b) => a.dist - b.dist)

    const W = [...candidates].sort((a, b) => b.dist - a.dist) // max-heap

    while (candidates.length > 0) {
      const c = candidates.shift() // nearest unvisited
      const fDist = W[0]?.dist ?? Infinity
      if (c.dist > fDist) break  // tous les candidats restants sont plus loin que le pire résultat

      const node = this.nodes.get(c.id)
      if (!node) continue
      const neighbors = node.neighbors[lc] || new Set()

      for (const nId of neighbors) {
        if (visited.has(nId)) continue
        visited.add(nId)
        const nNode = this.nodes.get(nId)
        if (!nNode) continue
        const d = this._dist(query, nNode.vector)

        if (W.length < ef || d < W[0].dist) {
          candidates.push({ id: nId, dist: d })
          candidates.sort((a, b) => a.dist - b.dist)
          W.push({ id: nId, dist: d })
          W.sort((a, b) => b.dist - a.dist)
          if (W.length > ef) W.shift()
        }
      }
    }

    return W.sort((a, b) => a.dist - b.dist)
  }

  /**
   * Sélectionne au maximum M voisins par heuristique simple (plus proches).
   * @param {Array<{id:string,dist:number}>} candidates @param {number} M
   * @returns {string[]}
   */
  _selectNeighbors(candidates, M) {
    return candidates.slice(0, M).map(c => c.id)
  }

  /**
   * Insère un nœud dans le graphe HNSW.
   * @param {string} id — identifiant unique
   * @param {number[]} vector — vecteur dense (même dimension pour tous)
   */
  insert(id, vector) {
    const level = this._randomLevel()
    /** @type {Array<Set<string>>} */
    const neighbors = Array.from({ length: level + 1 }, () => new Set())
    this.nodes.set(id, { vector, neighbors, level })

    if (this.entryPoint === null) {
      this.entryPoint = id
      this.maxLayer = level
      return
    }

    let ep = [this.entryPoint]
    const L = this.maxLayer

    // Descendre des layers supérieurs jusqu'à level+1
    for (let lc = L; lc > level; lc--) {
      const results = this._searchLayer(vector, ep, 1, lc)
      ep = [results[0].id]
    }

    // Insérer aux layers 0..level
    for (let lc = Math.min(level, L); lc >= 0; lc--) {
      const Mmax = lc === 0 ? this.Mmax0 : this.M
      const results = this._searchLayer(vector, ep, this.efConstruction, lc)
      const selected = this._selectNeighbors(results, this.M)

      for (const nId of selected) {
        neighbors[lc].add(nId)
        const nNode = this.nodes.get(nId)
        if (nNode && nNode.neighbors[lc]) {
          nNode.neighbors[lc].add(id)
          // Élagage si dépassement de Mmax
          if (nNode.neighbors[lc].size > Mmax) {
            const sorted = [...nNode.neighbors[lc]]
              .map(x => ({ id: x, dist: this._dist(nNode.vector, this.nodes.get(x)?.vector || []) }))
              .sort((a, b) => a.dist - b.dist)
            nNode.neighbors[lc] = new Set(sorted.slice(0, Mmax).map(x => x.id))
          }
        }
      }

      ep = results.slice(0, 1).map(r => r.id)
    }

    if (level > this.maxLayer) {
      this.maxLayer = level
      this.entryPoint = id
    }
  }

  /**
   * Recherche les k plus proches voisins de queryVector.
   * @param {number[]} queryVector
   * @param {number} k — nombre de résultats (défaut 10)
   * @param {number} ef — beam width (défaut 50, >= k)
   * @returns {Array<{id:string, dist:number, similarity:number}>}
   */
  search(queryVector, k = 10, ef = 50) {
    if (!this.entryPoint || this.nodes.size === 0) return []
    ef = Math.max(ef, k)

    let ep = [this.entryPoint]
    for (let lc = this.maxLayer; lc > 0; lc--) {
      const results = this._searchLayer(queryVector, ep, 1, lc)
      ep = [results[0].id]
    }

    const results = this._searchLayer(queryVector, ep, ef, 0)
    return results.slice(0, k).map(r => ({
      id: r.id,
      dist: r.dist,
      similarity: Math.max(0, 1 - r.dist)
    }))
  }

  /** Sérialise le graphe pour persistance (JSON-safe). */
  serialize() {
    const nodes = {}
    for (const [id, node] of this.nodes) {
      nodes[id] = {
        vector: node.vector,
        level: node.level,
        neighbors: node.neighbors.map(s => [...s])
      }
    }
    return { nodes, entryPoint: this.entryPoint, maxLayer: this.maxLayer, M: this.M }
  }

  /** Reconstruit un HNSW depuis une sérialisation. */
  static deserialize(data) {
    const hnsw = new HNSW(data.M)
    hnsw.entryPoint = data.entryPoint
    hnsw.maxLayer = data.maxLayer
    for (const [id, n] of Object.entries(data.nodes)) {
      hnsw.nodes.set(id, {
        vector: n.vector,
        level: n.level,
        neighbors: n.neighbors.map(arr => new Set(arr))
      })
    }
    return hnsw
  }

  get size() { return this.nodes.size }
}

// ── SmartRetrieval — Query Expansion ─────────────────────────────────────────

const SYNONYMS = {
  'error':  'exception',
  'auth':   'authentication',
  'db':     'database',
  'api':    'endpoint',
  'test':   'spec',
  'deploy': 'docker',
}

/**
 * expandQuery — génère N variantes d'une requête pour le multi-query retrieval.
 * @param {string} query
 * @param {{ phase?: string, maxVariants?: number }} [opts]
 * @returns {string[]} — tableau de requêtes (originale + variantes, dédupliqué)
 */
function expandQuery(query, opts = {}) {
  const variants = [query]
  const maxVariants = opts.maxVariants ?? 3

  // 1. Variante avec phase préfixée
  if (opts.phase && !query.includes(opts.phase)) {
    variants.push(`${opts.phase} ${query}`)
  }

  // 2. Variante sans stop words (tokens > 3 chars)
  const tokens = tokenize(query).filter(t => t.length > 3)
  const filtered = tokens.join(' ')
  if (tokens.length > 0 && filtered !== query) {
    variants.push(filtered)
  }

  // 3. Variante inversée (focus sur le dernier terme)
  const words = query.trim().split(/\s+/)
  if (words.length > 2) {
    variants.push(words.slice(-2).join(' '))
  }

  // 4. Variante avec synonymes techniques
  for (const [term, syn] of Object.entries(SYNONYMS)) {
    if (query.toLowerCase().includes(term)) {
      variants.push(query.replace(new RegExp(term, 'gi'), syn))
      break
    }
  }

  return [...new Set(variants)].slice(0, maxVariants)
}

// ── SmartRetrieval — Recency Boost ───────────────────────────────────────────

/**
 * Calcule un multiplicateur de boost basé sur l'ancienneté d'une trajectoire.
 * Modèle de décroissance exponentielle : boost = exp(-age_days / halfLife)
 * halfLife = 30 jours → une trajectoire d'un mois vaut 0.5× une récente.
 * @param {string} ts   — ISO timestamp de la trajectoire
 * @param {number} [halfLife=30]  — demi-vie en jours
 * @returns {number}  ∈ ]0, 1]  (1.0 = aujourd'hui, → 0 pour très ancienne)
 */
function recencyBoost(ts, halfLife = 30) {
  const ageDays = (Date.now() - new Date(ts).getTime()) / (1000 * 60 * 60 * 24)
  return Math.exp(-ageDays * Math.LN2 / halfLife)
}

// ── SmartRetrieval — Reciprocal Rank Fusion ───────────────────────────────────

/**
 * reciprocalRankFusion — combine plusieurs listes de résultats rankés.
 * Algorithme RRF : score(d) = Σ_i 1/(k + rank_i(d))  où k=60 (paramètre standard).
 * @param {Array<Array<{id: string, score: number}>>} rankedLists
 * @param {number} [k=60] — constante RRF
 * @param {{ recency?: boolean, halfLife?: number, tsMap?: Map<string,string> }} [opts]
 * @returns {Array<{id: string, rrfScore: number}>} — fusionné et trié par rrfScore décroissant
 */
function reciprocalRankFusion(rankedLists, k = 60, opts = {}) {
  const scores = new Map()

  for (const list of rankedLists) {
    list.forEach(({ id }, rank) => {
      const contribution = 1 / (k + rank + 1)
      scores.set(id, (scores.get(id) || 0) + contribution)
    })
  }

  // Recency boost optionnel (activé si opts.recency = true et entrée avec .ts)
  if (opts.recency) {
    for (const [id, score] of scores) {
      const ts = opts.tsMap?.get(id)
      if (ts) {
        const boost = recencyBoost(ts, opts.halfLife)
        scores.set(id, score * (1 + boost * 0.3))  // max +30% pour entrée du jour
      }
    }
  }

  return [...scores.entries()]
    .map(([id, rrfScore]) => ({ id, rrfScore }))
    .sort((a, b) => b.rrfScore - a.rrfScore)
}

// ── SmartRetrieval — Maximal Marginal Relevance ───────────────────────────────

/**
 * jaccardSim — similarité de Jaccard entre deux ensembles de tokens.
 * @param {string[]} tokensA
 * @param {string[]} tokensB
 * @returns {number} — [0, 1]
 */
function jaccardSim(tokensA, tokensB) {
  const setA = new Set(tokensA)
  const setB = new Set(tokensB)
  const intersection = [...setA].filter(t => setB.has(t)).length
  const union = new Set([...setA, ...setB]).size
  return union === 0 ? 0 : intersection / union
}

/**
 * maximalMarginalRelevance — re-rank pour maximiser diversité.
 * MMR(d) = λ * sim(d, query) - (1-λ) * max_{s∈Selected} sim(d, s)
 * @param {Array<{id: string, tokens: string[], score: number}>} candidates
 * @param {string[]} queryTokens
 * @param {{ lambda?: number, topK?: number }} [opts]
 * @returns {Array<{id: string, score: number, mmrScore: number}>}
 */
function maximalMarginalRelevance(candidates, queryTokens, opts = {}) {
  const lambda = opts.lambda ?? 0.5
  const topK   = opts.topK ?? 5

  if (candidates.length <= topK) return candidates.map(c => ({ ...c, mmrScore: 0 }))

  const selected  = []
  const remaining = [...candidates]

  while (selected.length < topK && remaining.length > 0) {
    let bestIdx = 0, bestScore = -Infinity

    for (let i = 0; i < remaining.length; i++) {
      const cand = remaining[i]
      const relevance = jaccardSim(cand.tokens || [], queryTokens)
      const maxSim = selected.length === 0
        ? 0
        : Math.max(...selected.map(s => jaccardSim(cand.tokens || [], s.tokens || [])))
      const mmrScore = lambda * relevance - (1 - lambda) * maxSim

      if (mmrScore > bestScore) { bestScore = mmrScore; bestIdx = i }
    }

    const best = remaining.splice(bestIdx, 1)[0]
    selected.push({ ...best, mmrScore: bestScore })
  }

  return selected
}

// ── BM25 (Okapi BM25) ─────────────────────────────────────────────────────────
// k1=1.5 (saturation du TF), b=0.75 (normalisation longueur)
// Supérieur au TF-IDF cosine : pénalise les docs longs, sature le TF répété

const BM25_K1 = 1.5
const BM25_B  = 0.75

/**
 * Calcule l'index BM25 d'un corpus de documents.
 * @param {string[]} docs — corpus de textes
 * @returns {{ idf: Map<string,number>, avgLen: number, tokenized: string[][] }}
 */
function buildBM25Index(docs) {
  const tokenized = docs.map(d => tokenize(d))  // réutilise tokenize() existant
  const N = docs.length
  const df = new Map()

  for (const tokens of tokenized) {
    const seen = new Set(tokens)
    for (const t of seen) df.set(t, (df.get(t) || 0) + 1)
  }

  const idf = new Map()
  for (const [term, freq] of df) {
    idf.set(term, Math.log((N - freq + 0.5) / (freq + 0.5) + 1))
  }

  const avgLen = tokenized.reduce((s, t) => s + t.length, 0) / Math.max(N, 1)
  return { idf, avgLen, tokenized }
}

/**
 * Score BM25 d'un document pour une query.
 * @param {string[]} queryTokens
 * @param {string[]} docTokens
 * @param {Map<string,number>} idf
 * @param {number} avgLen
 * @returns {number}
 */
function bm25Score(queryTokens, docTokens, idf, avgLen) {
  const docLen = docTokens.length
  const tf = new Map()
  for (const t of docTokens) tf.set(t, (tf.get(t) || 0) + 1)

  let score = 0
  for (const qt of queryTokens) {
    if (!idf.has(qt)) continue
    const f = tf.get(qt) || 0
    const idfScore = idf.get(qt)
    const tfNorm = (f * (BM25_K1 + 1)) / (f + BM25_K1 * (1 - BM25_B + BM25_B * docLen / avgLen))
    score += idfScore * tfNorm
  }
  return score
}

/**
 * Recherche BM25 dans un corpus.
 * @param {string} query
 * @param {string[]} docs
 * @param {{ limit?: number }} opts
 * @returns {{ index: number, score: number }[]} triés par score desc
 */
function searchBM25(query, docs, opts = {}) {
  if (!docs.length) return []
  const { idf, avgLen, tokenized } = buildBM25Index(docs)
  const qTokens = tokenize(query)

  return docs
    .map((_, i) => ({ index: i, score: bm25Score(qTokens, tokenized[i], idf, avgLen) }))
    .filter(r => r.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, opts.limit || 10)
}

module.exports = {
  tokenize, normalizeToken, ACRONYMS_KEEP, NORMALIZE_MAP,
  termFrequency, buildIDF, tfidfVector, cosineSimilarity, buildIndex, embed, HNSW,
  expandQuery, recencyBoost, reciprocalRankFusion, maximalMarginalRelevance, jaccardSim,
  buildBM25Index, bm25Score, searchBM25,
}
