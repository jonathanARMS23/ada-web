#!/usr/bin/env node
'use strict'
/**
 * coordinator/error-context.js — AI Engineering Loop
 *
 * Parse les erreurs brutes d'une phase échouée en contexte structuré,
 * puis formate ce contexte pour injection dans le re-prompt de l'agent.
 *
 * API publique :
 *   parseErrors(rawOutput)                → ParsedError[]
 *   formatForPrompt(errors, iter, maxIter) → string
 *   buildRetryContext(phaseState, iter)    → RetryContext
 *   isNonDeterministicError(raw)           → boolean
 *
 * @typedef {{ type:'typescript'|'test'|'runtime'|'lint'|'unknown', file:string|null, line:number|null, message:string, raw:string, loopable:boolean }} ParsedError
 * @typedef {{ errors:ParsedError[], formattedBlock:string, iteration:number, hasErrors:boolean }} RetryContext
 */

// ── Patterns d'erreurs non-déterministes (réseau, mémoire) ───────────────────
// Ces erreurs ne bénéficient pas d'un re-prompt — escalade humaine immédiate.

const NON_DETERMINISTIC_RE = /ECONNREFUSED|ETIMEDOUT|ENOTFOUND|ECONNRESET|ESOCKETTIMEDOUT|socket hang up|heap out of memory|Allocation failed|ENOMEM/i

// ── Regex de parsing ──────────────────────────────────────────────────────────

// TypeScript : "path(line,col): error TSxxxx: message"
const TS_RE = /^([\w./@\\/-]+)\((\d+)(?:,\d+)?\): error (TS\d+): (.+)$/gm

// Node:test TAP : "not ok N - description"
const TAP_FAIL_RE = /^not ok \d+ - (.+)$/gm

// Runtime : "Error: message" + optional stack "at ... (file:line:col)"
const RUNTIME_HDR_RE = /^(Error|TypeError|ReferenceError|SyntaxError|RangeError|AssertionError): (.+)$/m
const STACK_FRAME_RE = /^\s+at .+\((.+?):(\d+):\d+\)/m

// Lint ESLint : file path on its own line then "  line:col  error  message  rule"
const LINT_FILE_RE = /^([\w./@\\/-]+\.[jt]sx?)$/m
const LINT_LINE_RE = /^\s+(\d+):\d+\s+error\s+(.+?)\s+[@\w/-]+$/gm

// ── Helpers ────────────────────────────────────────────────────────────────────

/**
 * @param {string} raw
 * @returns {boolean}
 */
function isNonDeterministicError(raw) {
  return NON_DETERMINISTIC_RE.test(String(raw || ''))
}

// ── parseErrors ────────────────────────────────────────────────────────────────

/**
 * @param {string|null|undefined} rawOutput
 * @returns {ParsedError[]}
 */
function parseErrors(rawOutput) {
  const raw = String(rawOutput || '')
  if (!raw.trim()) return []

  const loopable = !isNonDeterministicError(raw)
  const errors = []

  // ── TypeScript ──────────────────────────────────────────────────────────────
  {
    const re = new RegExp(TS_RE.source, 'gm')
    let m
    while ((m = re.exec(raw)) !== null) {
      errors.push({
        type: 'typescript',
        file: m[1],
        line: parseInt(m[2], 10),
        message: m[4].trim(),
        raw: m[0],
        loopable,
      })
    }
  }

  // ── Node:test TAP ───────────────────────────────────────────────────────────
  {
    const re = new RegExp(TAP_FAIL_RE.source, 'gm')
    let m
    while ((m = re.exec(raw)) !== null) {
      errors.push({
        type: 'test',
        file: null,
        line: null,
        message: m[1].trim(),
        raw: m[0],
        loopable,
      })
    }
  }

  // ── Lint (ESLint) ─────────────────────────────────────────────────────────
  // Only when no TS errors found (avoids double-counting TS-via-ESLint)
  if (errors.filter(e => e.type === 'typescript').length === 0) {
    const lines = raw.split('\n')
    let currentFile = null
    for (const line of lines) {
      const fileMatch = line.match(/^([\w./@\\/-]+\.[jt]sx?)$/)
      if (fileMatch) { currentFile = fileMatch[1]; continue }
      const lintMatch = line.match(/^\s+(\d+):\d+\s+error\s+(.+?)\s+[@\w/-]+$/)
      if (lintMatch && currentFile) {
        errors.push({
          type: 'lint',
          file: currentFile,
          line: parseInt(lintMatch[1], 10),
          message: lintMatch[2].trim(),
          raw: line,
          loopable,
        })
      }
    }
  }

  // ── Runtime (Error / TypeError / etc.) ────────────────────────────────────
  // Only when no other errors found to avoid double-counting
  if (errors.length === 0) {
    const hdr = raw.match(RUNTIME_HDR_RE)
    if (hdr) {
      const frame = raw.match(STACK_FRAME_RE)
      // Non-deterministic runtime errors get loopable:false even if captured
      const runtimeLoopable = loopable && !isNonDeterministicError(hdr[2])
      errors.push({
        type: 'runtime',
        file: frame ? frame[1] : null,
        line: frame ? parseInt(frame[2], 10) : null,
        message: hdr[2].trim(),
        raw: hdr[0],
        loopable: runtimeLoopable,
      })
    } else if (isNonDeterministicError(raw)) {
      // Non-deterministic error that doesn't match known Error: prefixes
      errors.push({
        type: 'runtime',
        file: null,
        line: null,
        message: raw.trim().split('\n')[0],
        raw: raw.trim().split('\n')[0],
        loopable: false,
      })
    }
  }

  return errors
}

// ── formatForPrompt ────────────────────────────────────────────────────────────

/**
 * @param {ParsedError[]} errors
 * @param {number} iteration  1-based
 * @param {number} maxIter
 * @returns {string}
 */
function formatForPrompt(errors, iteration, maxIter) {
  const isLast = iteration >= maxIter
  const header = isLast
    ? `[AI ENGINEERING LOOP — Final iteration ${iteration}/${maxIter} — last chance before human escalation]`
    : `[AI ENGINEERING LOOP — Iteration ${iteration}/${maxIter}]`

  if (!errors || errors.length === 0) {
    return [
      header,
      'Previous attempt failed without a parseable error output.',
      'Review the implementation thoroughly and apply targeted fixes.',
    ].join('\n')
  }

  const lines = [
    header,
    `Previous attempt failed with ${errors.length} error(s). Fix ONLY what is listed below.`,
    '',
  ]

  errors.forEach((err, i) => {
    const loc = err.file
      ? `${err.file}${err.line ? `:${err.line}` : ''}`
      : '(no file)'
    lines.push(`[ERROR ${i + 1}] ${err.type} — ${loc}`)
    lines.push(err.message)
    lines.push('')
  })

  lines.push('Do not rewrite unrelated code. Apply minimal targeted fixes only.')

  return lines.join('\n')
}

// ── buildRetryContext ──────────────────────────────────────────────────────────

/**
 * @param {{ status: string, error: string|null|undefined, summary?: string }} phaseState
 * @param {number} iteration  1-based, the upcoming retry number
 * @param {number} [maxIter=3]
 * @returns {RetryContext}
 */
function buildRetryContext(phaseState, iteration, maxIter = 3) {
  const rawError = phaseState?.error || ''
  const errors = parseErrors(rawError)
  const hasErrors = errors.length > 0 && errors.some(e => e.loopable !== false)
  const formattedBlock = formatForPrompt(errors, iteration, maxIter)

  return {
    errors,
    formattedBlock,
    iteration,
    hasErrors,
  }
}

module.exports = { parseErrors, formatForPrompt, buildRetryContext, isNonDeterministicError }
