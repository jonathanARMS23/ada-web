#!/usr/bin/env node
'use strict'
/**
 * coordinator/ewc.js — Elastic Weight Consolidation simplifié
 * Protège les connaissances importantes du decay/oubli
 *
 * Concept :
 *   - Priors Thompson = "poids" à protéger
 *   - Certitude Fisher = inverse de la variance Beta(α,β)
 *     Faible variance = forte certitude
 *   - Trajectoires bank = à protéger si très utilisées
 *
 * ⚠ B3 — la certitude Fisher SEULE n'est PAS un poids de protection valide.
 * La variance de Beta(α,β) décroît de façon monotone avec n = α+β : plus un prior
 * a d'historique, plus sa "certitude" est haute. L'utiliser directement comme
 * facteur de protection du decay inverse l'intention du decay : les priors les
 * PLUS anciens (donc ceux dont le poids doit justement baisser) devenaient les
 * plus protégés, jusqu'au gel complet (effectiveFactor = 1.0 avec ewcStrength=1).
 *
 * L'EWC réel protège les paramètres qui importent ENCORE pour une tâche
 * apprise — pas ceux qui ont simplement accumulé du volume. Transposition
 * corrigée ici :
 *
 *   protection = certitude Fisher × récence (décroissance exponentielle)
 *
 * → un prior encore renforcé récemment est protégé (connaissance vivante),
 *   un prior silencieux depuis longtemps perd sa protection et redescend au
 *   facteur de decay nominal, quel que soit son volume d'historique.
 * → effectiveFactor est en plus borné STRICTEMENT sous 1 : aucun prior ne peut
 *   être gelé indéfiniment.
 *
 * Usage CLI :
 *   node coordinator/ewc.js report          # affiche les priors importants
 *   node coordinator/ewc.js top [N]         # top N priors par importance
 *   node coordinator/ewc.js threshold [0.7] # priors au-dessus du seuil
 */

const { join } = require('path')
const { readFileSync, existsSync } = require('fs')

const CONFIG_DIR = process.env.CLAUDE_CONFIG_DIR || join(process.env.HOME ?? '', '.claude')
const COORD_DIR  = join(CONFIG_DIR, 'coordinator')
const STATE_FILE = join(COORD_DIR, 'router-state.json')

const C = {
  reset: '\x1b[0m', bold: '\x1b[1m',
  green: '\x1b[32m', red: '\x1b[31m', yellow: '\x1b[33m',
  cyan: '\x1b[36m', gray: '\x1b[90m', blue: '\x1b[34m'
}

// ── Core EWC ──────────────────────────────────────────────────────────────────

/** Demi-vie par défaut de la récence d'un prior, en jours. */
const DEFAULT_HALF_LIFE_DAYS = 30

/**
 * Plafond STRICT du facteur de decay effectif. Garantit qu'aucun prior ne peut
 * être gelé (facteur 1.0 = plus jamais de decay = oubli impossible → la confiance
 * ne redescend jamais, l'exploration Thompson ne se rouvre jamais).
 */
const MAX_EFFECTIVE_DECAY_FACTOR = 0.999

const MS_PER_DAY = 86_400_000

/**
 * Certitude Fisher d'une distribution Beta(α, β)
 * = inverse normalisé de la variance αβ / ((α+β)²(α+β+1))
 * Faible variance = forte certitude → valeur proche de 1.
 *
 * ⚠ Cette valeur croît de façon monotone avec n = α+β : c'est une mesure de
 * CERTITUDE / volume, pas de valeur-à-protéger. Ne PAS l'utiliser seule comme
 * facteur de protection du decay (cf. en-tête du fichier, bug B3) — passer par
 * computeProtectionWeight(), qui la pondère par la récence.
 *
 * @param {number} alpha
 * @param {number} beta
 * @returns {number} certitude ∈ [0, 1]
 */
function computeFisherImportance(alpha, beta) {
  const n = alpha + beta
  if (n < 2) return 0 // pas assez de données
  const variance = (alpha * beta) / (n * n * (n + 1))
  // Normaliser : prior très certain = variance proche de 0 = certitude proche de 1
  // Seuil : variance de Beta(1,1) = 1/12 ≈ 0.083 → certitude = 0
  const maxVariance = 1 / 12 // variance max de Beta(1,1)
  return Math.max(0, Math.min(1, 1 - variance / maxVariance))
}

/**
 * Poids de récence d'un prior — décroissance exponentielle par demi-vie.
 *   renforcé à l'instant       → 1
 *   renforcé il y a 1 demi-vie → 0.5
 *   renforcé il y a longtemps  → → 0
 *
 * Timestamp absent ou invalide → 0 : sans preuve de renforcement récent, un prior
 * ne mérite AUCUNE protection (il décaie au facteur nominal, comportement
 * documenté du decay). Les priors écrits avant l'introduction de `lastUpdatedAt`
 * tombent volontairement dans ce cas : ce sont, par construction, les anciens.
 *
 * @param {string|number|null|undefined} lastUpdatedAt  ISO string ou epoch ms
 * @param {{ now?: number, halfLifeDays?: number }} [opts]
 * @returns {number} récence ∈ [0, 1]
 */
function computeRecencyWeight(lastUpdatedAt, opts = {}) {
  if (lastUpdatedAt === null || lastUpdatedAt === undefined || lastUpdatedAt === '') return 0
  const halfLifeDays = opts.halfLifeDays ?? DEFAULT_HALF_LIFE_DAYS
  if (!(halfLifeDays > 0)) return 0
  const now = typeof opts.now === 'number' && Number.isFinite(opts.now) ? opts.now : Date.now()
  const t = typeof lastUpdatedAt === 'number' ? lastUpdatedAt : Date.parse(String(lastUpdatedAt))
  if (!Number.isFinite(t)) return 0
  const ageDays = Math.max(0, (now - t) / MS_PER_DAY)
  return Math.max(0, Math.min(1, Math.pow(0.5, ageDays / halfLifeDays)))
}

/**
 * Poids de protection EWC d'un prior = certitude Fisher × récence.
 * C'est CETTE valeur (et non la certitude seule) qui module le decay.
 *
 * @param {{ alpha?: number, beta?: number, lastUpdatedAt?: string|number }} prior
 * @param {{ now?: number, halfLifeDays?: number }} [opts]
 * @returns {number} protection ∈ [0, 1]
 */
function computeProtectionWeight(prior, opts = {}) {
  if (!prior || typeof prior.alpha !== 'number' || typeof prior.beta !== 'number') return 0
  const certainty = computeFisherImportance(prior.alpha, prior.beta)
  if (!(certainty > 0)) return 0
  return certainty * computeRecencyWeight(prior.lastUpdatedAt, opts)
}

/**
 * Calcule le facteur de decay effectif pour un prior donné.
 * Les priors protégés (protection élevée) décayent moins vite — mais décayent
 * TOUJOURS : le résultat est borné strictement sous 1.
 *
 * @param {number} factor      Facteur de decay nominal ∈ ]0, 1[
 * @param {number} protection  Poids de protection EWC ∈ [0, 1] (computeProtectionWeight)
 * @param {number} ewcStrength Force de la protection ∈ [0, 1] (défaut 0.8)
 * @returns {number} facteur effectif ∈ [factor, max(factor, 0.999)] ⊂ ]0, 1[
 *
 * Exemples :
 *   factor=0.95, protection=0,   ewcStrength=0.8 → 0.95  (pas de protection)
 *   factor=0.95, protection=1,   ewcStrength=0.8 → 0.99  (protection max : 5%×0.8 récupéré)
 *   factor=0.95, protection=0.5, ewcStrength=0.8 → 0.97
 *   factor=0.95, protection=1,   ewcStrength=1   → 0.999 (plafonné — jamais 1.0/gel)
 */
function computeEffectiveDecayFactor(factor, protection, ewcStrength = 0.8) {
  const p = Math.max(0, Math.min(1, Number(protection) || 0))
  const s = Math.max(0, Math.min(1, ewcStrength ?? 0.8))
  const raw = factor + (1 - factor) * p * s
  // Le plafond ne doit jamais descendre SOUS le facteur nominal (cas factor > 0.999).
  return Math.min(raw, Math.max(factor, MAX_EFFECTIVE_DECAY_FACTOR))
}

/**
 * Analyse l'état du router et retourne un rapport des priors triés par protection
 * effective (tie-break : certitude).
 *
 * @param {{ priors?: Record<string, { alpha: number, beta: number, successes?: number, failures?: number, lastUpdatedAt?: string }> }} state
 * @param {{ factor?: number, ewcStrength?: number, now?: number, halfLifeDays?: number }} [opts]
 * @returns {Array<{ key: string, importance: number, recency: number, protection: number, effectiveFactor: number, alpha: number, beta: number, successes: number, failures: number }>}
 */
function analyzeRouterState(state, opts = {}) {
  const factor      = opts.factor      ?? 0.95
  const ewcStrength = opts.ewcStrength ?? 0.8
  const recencyOpts = { now: opts.now, halfLifeDays: opts.halfLifeDays }

  const entries = Object.entries(state.priors || {}).map(([key, prior]) => {
    const importance = computeFisherImportance(prior.alpha, prior.beta)
    const recency    = computeRecencyWeight(prior.lastUpdatedAt, recencyOpts)
    const protection = computeProtectionWeight(prior, recencyOpts)
    const effectiveFactor = computeEffectiveDecayFactor(factor, protection, ewcStrength)
    return {
      key,
      importance,
      recency,
      protection,
      effectiveFactor,
      alpha:    prior.alpha,
      beta:     prior.beta,
      successes: prior.successes ?? 0,
      failures:  prior.failures  ?? 0,
    }
  })

  return entries.sort((a, b) => (b.protection - a.protection) || (b.importance - a.importance))
}

// ── Chargement état router ─────────────────────────────────────────────────────

function loadState() {
  try {
    if (existsSync(STATE_FILE)) return JSON.parse(readFileSync(STATE_FILE, 'utf8'))
  } catch {}
  return { priors: {}, totalUpdates: 0 }
}

// ── CLI ───────────────────────────────────────────────────────────────────────

function cmdReport() {
  const state   = loadState()
  const entries = analyzeRouterState(state)

  if (!entries.length) {
    console.log(`${C.yellow}Aucun prior dans le router — lancer : node coordinator/router.js seed${C.reset}`)
    return
  }

  console.log(`\n${C.bold}EWC++ — Protection des priors contre le decay${C.reset}`)
  console.log(`Priors analysés : ${entries.length}\n`)

  const protected_ = entries.filter(e => e.protection > 0.5).length
  console.log(`  Priors protégés (protection > 0.5) : ${C.green}${protected_}${C.reset}`)
  console.log(`  Priors non protégés               : ${C.gray}${entries.length - protected_}${C.reset}`)
  console.log(`  ${C.gray}protection = certitude Fisher × récence (demi-vie ${DEFAULT_HALF_LIFE_DAYS}j)${C.reset}\n`)

  const header = 'Key'.padEnd(35) + 'Certit.'.padEnd(9) + 'Récence'.padEnd(9) + 'Protec.'.padEnd(9) + 'EffFactor'.padEnd(12) + 'α'.padEnd(6) + 'β'.padEnd(6) + 'n'
  console.log(`  ${C.bold}${header}${C.reset}`)
  console.log('  ' + '─'.repeat(90))

  for (const e of entries) {
    const importColor = e.protection > 0.7 ? C.green : e.protection > 0.5 ? C.yellow : C.gray
    const n           = e.successes + e.failures
    console.log(
      `  ${e.key.padEnd(35)}${e.importance.toFixed(3).padEnd(9)}${e.recency.toFixed(3).padEnd(9)}` +
      `${importColor}${e.protection.toFixed(3).padEnd(9)}${C.reset}` +
      `${e.effectiveFactor.toFixed(4).padEnd(12)}${String(e.alpha.toFixed(1)).padEnd(6)}${String(e.beta.toFixed(1)).padEnd(6)}${n.toFixed(1)}`
    )
  }
  console.log('')
}

function cmdTop(args) {
  const n = parseInt(args[0] || '10', 10)
  const state   = loadState()
  const entries = analyzeRouterState(state).slice(0, n)

  if (!entries.length) {
    console.log(`${C.yellow}Aucun prior à afficher${C.reset}`)
    return
  }

  console.log(`\n${C.bold}EWC++ — Top ${n} priors par protection (certitude × récence)${C.reset}\n`)
  for (let i = 0; i < entries.length; i++) {
    const e = entries[i]
    const importColor = e.protection > 0.7 ? C.green : e.protection > 0.5 ? C.yellow : C.gray
    console.log(
      `  ${String(i + 1).padStart(2)}. ${e.key.padEnd(35)} ` +
      `${importColor}${e.protection.toFixed(3)}${C.reset}  ` +
      `${C.gray}(certit=${e.importance.toFixed(2)} récence=${e.recency.toFixed(2)})${C.reset}  ` +
      `decay: ×${e.effectiveFactor.toFixed(4)}`
    )
  }
  console.log('')
}

function cmdThreshold(args) {
  const threshold = parseFloat(args[0] || '0.7')
  if (isNaN(threshold) || threshold < 0 || threshold > 1) {
    console.error('Seuil invalide — doit être un nombre dans [0, 1]')
    process.exit(1)
  }

  const state   = loadState()
  const entries = analyzeRouterState(state).filter(e => e.protection >= threshold)

  if (!entries.length) {
    console.log(`${C.yellow}Aucun prior avec protection ≥ ${threshold}${C.reset}`)
    return
  }

  console.log(`\n${C.bold}EWC++ — Priors avec protection ≥ ${threshold}${C.reset}\n`)
  for (const e of entries) {
    const n = e.successes + e.failures
    console.log(
      `  ${C.green}${e.key.padEnd(35)}${C.reset} ` +
      `protection=${e.protection.toFixed(3)}  ` +
      `certitude=${e.importance.toFixed(3)}  récence=${e.recency.toFixed(3)}  ` +
      `effectiveFactor=×${e.effectiveFactor.toFixed(4)}  ` +
      `n=${n.toFixed(1)}`
    )
  }
  console.log(`\n  Total : ${entries.length} priors\n`)
}

// ── Exports ───────────────────────────────────────────────────────────────────

module.exports = {
  computeFisherImportance,
  computeRecencyWeight,
  computeProtectionWeight,
  computeEffectiveDecayFactor,
  analyzeRouterState,
  DEFAULT_HALF_LIFE_DAYS,
  MAX_EFFECTIVE_DECAY_FACTOR,
}

// ── Dispatch CLI ──────────────────────────────────────────────────────────────

if (require.main === module) {
  const [,, cmd, ...args] = process.argv

  switch (cmd) {
    case 'report':    cmdReport();         break
    case 'top':       cmdTop(args);        break
    case 'threshold': cmdThreshold(args);  break
    default:
      console.log(`\n${C.bold}coordinator/ewc.js — Elastic Weight Consolidation${C.reset}\n`)
      console.log('  report                 Rapport complet des priors par protection')
      console.log('  top [N]                Top N priors les plus protégés (défaut: 10)')
      console.log('  threshold [seuil]      Priors au-dessus du seuil de protection (défaut: 0.7)')
      console.log('\nProtection = certitude Fisher × récence : un prior très certain mais')
      console.log(`silencieux depuis > ${DEFAULT_HALF_LIFE_DAYS}j perd sa protection et redescend au decay nominal.`)
      console.log('')
  }
}
