'use strict'
/**
 * coordinator/federation.js — F13 Federation mTLS sémantique
 *
 * Partage P2P en temps réel des trajectoires sémantiquement proches entre
 * instances ADA (dev local, CI, staging) via mTLS.
 *
 * Contraintes :
 *   - CJS uniquement, zéro dépendance externe
 *   - Modules natifs Node.js : https, crypto, tls, os, fs, child_process
 *   - HTTPS obligatoire pour tous les pairs
 *   - Toutes les erreurs TLS isolées dans try/catch
 */

const https       = require('node:https')
const crypto      = require('node:crypto')
const os          = require('node:os')
const { readFileSync, writeFileSync, existsSync, mkdirSync, appendFileSync, chmodSync, renameSync } = require('node:fs')
const { join, dirname } = require('node:path')
const { spawnSync } = require('node:child_process')

// ── Chemins ───────────────────────────────────────────────────────────────────

const HOME       = process.env.HOME ?? os.homedir()
const CONFIG_DIR = process.env.CLAUDE_CONFIG_DIR || join(HOME, '.claude')
const LOG_DIR    = join(HOME, '.ada', 'logs')
const FED_LOG    = join(LOG_DIR, 'federation.log')
const ADA_CONFIG = join(HOME, '.ada.json')

// ── Logging ───────────────────────────────────────────────────────────────────

function ensureDir(p) {
  if (!existsSync(p)) mkdirSync(p, { recursive: true })
}

function ts() {
  return new Date().toISOString()
}

function log(msg) {
  try {
    ensureDir(LOG_DIR)
    appendFileSync(FED_LOG, `${ts()} ${msg}\n`)
  } catch { /* silencieux */ }
}

// ── Config ~/.ada.json ────────────────────────────────────────────────────────

function loadAdaConfig() {
  if (!existsSync(ADA_CONFIG)) return {}
  try { return JSON.parse(readFileSync(ADA_CONFIG, 'utf8')) } catch { return {} }
}

function saveAdaConfig(cfg) {
  const tmp = ADA_CONFIG + '.tmp'
  writeFileSync(tmp, JSON.stringify(cfg, null, 2) + '\n', 'utf8')
  renameSync(tmp, ADA_CONFIG)
}

function getFederationConfig() {
  const cfg = loadAdaConfig()
  if (!cfg.federation) {
    cfg.federation = {
      enabled:      false,
      certDir:      join(CONFIG_DIR, 'federation', 'certs'),
      port:         7878,
      peers:        [],
      allowedNodes: [],
      topK:         5,
    }
    try { saveAdaConfig(cfg) } catch { /* graceful */ }
  }
  return cfg.federation
}

function saveFederationConfig(fedCfg) {
  const cfg = loadAdaConfig()
  cfg.federation = fedCfg
  saveAdaConfig(cfg)
}

// ── Peers actifs en mémoire ───────────────────────────────────────────────────

/** @type {Array<{ nodeId: string, url: string, lastSync: string|null }>} */
const _activePeers = []

/**
 * getActivePeers — retourne la liste des pairs avec lesquels une connexion
 * a été établie dans cette session.
 * @returns {{ nodeId: string, url: string, lastSync: string|null }[]}
 */
function getActivePeers() {
  return [..._activePeers]
}

function _upsertActivePeer(nodeId, url) {
  const idx = _activePeers.findIndex(p => p.nodeId === nodeId || p.url === url)
  if (idx >= 0) {
    _activePeers[idx].lastSync = ts()
    _activePeers[idx].nodeId   = nodeId
  } else {
    _activePeers.push({ nodeId, url, lastSync: ts() })
  }
}

// ── bank API (lazy require pour éviter la circularité au boot) ─────────────────

let _bank = null
function getBank() {
  if (!_bank) {
    try { _bank = require(join(CONFIG_DIR, 'coordinator', 'bank.js')) }
    catch { _bank = null }
  }
  return _bank
}

// ── Génération de certificats ─────────────────────────────────────────────────

/**
 * generateCerts — génère une chaîne CA + certificat nœud via openssl.
 *
 * 5 commandes openssl :
 *   1. genrsa CA key
 *   2. self-signed CA cert
 *   3. genrsa node key
 *   4. CSR nœud (CN = os.hostname())
 *   5. signature CSR par la CA
 *
 * @param {string} outputDir  Répertoire de sortie (créé si absent)
 * @returns {{ certPath: string, keyPath: string, caPath: string }}
 */
function generateCerts(outputDir) {
  ensureDir(outputDir)
  try { chmodSync(outputDir, 0o700) } catch { /* silencieux si non supporté */ }

  const caKeyPath  = join(outputDir, 'ca.key')
  const caCertPath = join(outputDir, 'ca.pem')
  const keyPath    = join(outputDir, 'key.pem')
  const csrPath    = join(outputDir, 'node.csr')
  const certPath   = join(outputDir, 'cert.pem')
  const hostname   = os.hostname()

  const commands = [
    ['openssl', ['genrsa', '-out', caKeyPath, '2048']],
    ['openssl', ['req', '-x509', '-new', '-key', caKeyPath,
      '-days', '3650', '-out', caCertPath, '-subj', '/CN=ada-ca']],
    ['openssl', ['genrsa', '-out', keyPath, '2048']],
    ['openssl', ['req', '-new', '-key', keyPath,
      '-out', csrPath, '-subj', `/CN=${hostname}`]],
    ['openssl', ['x509', '-req', '-in', csrPath,
      '-CA', caCertPath, '-CAkey', caKeyPath,
      '-CAcreateserial', '-out', certPath, '-days', '365']],
  ]

  for (const [cmd, args] of commands) {
    const r = spawnSync(cmd, args, { encoding: 'utf8' })
    if (r.status !== 0) {
      const msg = `generateCerts: ${cmd} ${args[0]} échoué — ${r.stderr || r.error?.message || 'code ' + r.status}`
      log(`[ERROR] ${msg}`)
      throw new Error(msg)
    }
  }

  // chmod 600 sur les clés privées
  try { chmodSync(caKeyPath, 0o600) } catch { /* silencieux */ }
  try { chmodSync(keyPath,   0o600) } catch { /* silencieux */ }

  log(`[INFO] Certificats générés dans ${outputDir} (CN=${hostname})`)
  return { certPath, keyPath, caPath: caCertPath }
}

// ── Chargement des certificats ────────────────────────────────────────────────

/**
 * loadCerts — lit les 3 fichiers PEM depuis un répertoire.
 * @param {string} dir
 * @returns {{ cert: Buffer, key: Buffer, ca: Buffer }}
 */
function loadCerts(dir) {
  const certPath = join(dir, 'cert.pem')
  const keyPath  = join(dir, 'key.pem')
  const caPath   = join(dir, 'ca.pem')

  if (!existsSync(certPath)) throw new Error(`loadCerts: cert.pem absent dans ${dir}`)
  if (!existsSync(keyPath))  throw new Error(`loadCerts: key.pem absent dans ${dir}`)
  if (!existsSync(caPath))   throw new Error(`loadCerts: ca.pem absent dans ${dir}`)

  return {
    cert: readFileSync(certPath),
    key:  readFileSync(keyPath),
    ca:   readFileSync(caPath),
  }
}

// ── Serveur mTLS ──────────────────────────────────────────────────────────────

/**
 * startFederationServer — démarre un serveur HTTPS avec mTLS.
 *
 * Routes :
 *   POST /federation/sync   — échange de trajectoires (auth mTLS + allowedNodes)
 *   GET  /federation/health — healthcheck public (pas d'auth)
 *
 * @param {{ port?: number, certDir?: string, allowedNodes?: string[] }} [opts]
 * @returns {https.Server}
 */
function startFederationServer(opts = {}) {
  const fedCfg     = getFederationConfig()
  const port       = opts.port       ?? fedCfg.port       ?? 7878
  const certDir    = opts.certDir    ?? fedCfg.certDir    ?? join(CONFIG_DIR, 'federation', 'certs')
  const allowedNodes = opts.allowedNodes ?? fedCfg.allowedNodes ?? []
  const topK       = fedCfg.topK ?? 5

  let certs
  try {
    certs = loadCerts(certDir)
  } catch (err) {
    log(`[ERROR] startFederationServer: impossible de charger les certificats — ${err.message}`)
    throw err
  }

  const localNodeId = _getLocalNodeId(certDir)

  const tlsOpts = {
    cert:               certs.cert,
    key:                certs.key,
    ca:                 certs.ca,
    // requestCert:true permet au serveur de demander le cert client.
    // rejectUnauthorized:false laisse passer les connexions sans cert au niveau TLS ;
    // la vérification obligatoire est faite manuellement via req.socket.authorized
    // dans le handler /federation/sync, ce qui permet au /health de rester public.
    requestCert:        true,
    rejectUnauthorized: false,
  }

  const server = https.createServer(tlsOpts, (req, res) => {
    try {
      // ── GET /federation/health — pas d'auth ───────────────────────────────
      if (req.method === 'GET' && req.url === '/federation/health') {
        _jsonResponse(res, 200, { nodeId: localNodeId, version: '6.0', ok: true })
        return
      }

      // ── POST /federation/sync ─────────────────────────────────────────────
      if (req.method === 'POST' && req.url === '/federation/sync') {
        // Vérification mTLS
        if (!req.socket.authorized) {
          log(`[WARN] /federation/sync — peer non autorisé (cert invalide ou absente)`)
          _jsonResponse(res, 401, { error: 'Client certificate required' })
          return
        }

        let peerNodeId
        try {
          peerNodeId = req.socket.getPeerCertificate()?.subject?.CN
        } catch { /* silencieux */ }

        if (!peerNodeId) {
          log(`[WARN] /federation/sync — CN introuvable dans le certificat pair`)
          _jsonResponse(res, 401, { error: 'Cannot determine peer nodeId from certificate CN' })
          return
        }

        if (allowedNodes.length > 0 && !allowedNodes.includes(peerNodeId)) {
          log(`[WARN] /federation/sync — pair '${peerNodeId}' non autorisé (allowedNodes)`)
          _jsonResponse(res, 403, { error: `Node '${peerNodeId}' not in allowedNodes` })
          return
        }

        _readBody(req, (err, body) => {
          if (err) {
            _jsonResponse(res, 400, { error: 'Invalid request body' })
            return
          }

          let payload
          try { payload = JSON.parse(body) } catch {
            _jsonResponse(res, 400, { error: 'JSON parse error' })
            return
          }

          const query = (payload.query || '').slice(0, 1024) // cap 1 KB — protection DoS mTLS peer
          const k     = Math.min(parseInt(payload.topK, 10) || topK, 50)

          let trajectories = []
          try {
            const bank = getBank()
            if (bank) {
              const results = bank.retrieve(query, { limit: k })
              trajectories  = Array.isArray(results) ? results : []
            }
          } catch (e) {
            log(`[ERROR] bank.retrieve échoué dans /federation/sync — ${e.message}`)
          }

          log(`[INFO] /federation/sync — ${peerNodeId} requête "${query}" → ${trajectories.length} trajectoires envoyées`)
          _jsonResponse(res, 200, { trajectories, nodeId: localNodeId })
        })
        return
      }

      // ── Route inconnue ────────────────────────────────────────────────────
      _jsonResponse(res, 404, { error: 'Not found' })
    } catch (tlsErr) {
      // Isolation TLS — ne jamais crasher le process
      try {
        log(`[ERROR] handler TLS inattendu — ${tlsErr.message}`)
        _jsonResponse(res, 500, { error: 'Internal server error' })
      } catch { /* silencieux */ }
    }
  })

  server.on('tlsClientError', (err, tlsSocket) => {
    try {
      log(`[WARN] tlsClientError — ${err.message}`)
      tlsSocket.destroy()
    } catch { /* silencieux */ }
  })

  server.on('error', err => {
    log(`[ERROR] server error — ${err.message}`)
  })

  server.listen(port, opts.bindHost ?? '127.0.0.1', () => {
    log(`[INFO] Federation server démarré sur port ${port} (nodeId=${localNodeId})`)
  })

  return server
}

// ── Connexion à un pair ───────────────────────────────────────────────────────

/**
 * connectPeer — crée une connexion mTLS vers un pair distant.
 *
 * @param {string} peerUrl   URL HTTPS du pair (ex: https://staging.local:7878)
 * @param {string} certDir   Répertoire contenant cert.pem, key.pem, ca.pem
 * @returns {{ sync(query: string, topK?: number): Promise<{ trajectories: any[], nodeId: string }> }}
 */
function connectPeer(peerUrl, certDir) {
  if (!peerUrl.startsWith('https://')) {
    throw new Error('Federation requires HTTPS — peerUrl must start with https://')
  }

  let certs
  try {
    certs = loadCerts(certDir)
  } catch (err) {
    log(`[ERROR] connectPeer: impossible de charger les certificats — ${err.message}`)
    throw err
  }

  const agent = new https.Agent({
    cert:               certs.cert,
    key:                certs.key,
    ca:                 certs.ca,
    rejectUnauthorized: true,
  })

  return {
    /**
     * sync — appelle /federation/sync sur le pair distant.
     * @param {string} query
     * @param {number} [topK=5]
     * @returns {Promise<{ trajectories: any[], nodeId: string }>}
     */
    async sync(query, topK = 5) {
      const url  = peerUrl.replace(/\/$/, '') + '/federation/sync'
      const body = JSON.stringify({ query, topK })

      return new Promise((resolve, reject) => {
        try {
          const urlObj   = new URL(url)
          const reqOpts  = {
            hostname: urlObj.hostname,
            port:     urlObj.port || 443,
            path:     urlObj.pathname,
            method:   'POST',
            agent,
            headers: {
              'Content-Type':   'application/json',
              'Content-Length': Buffer.byteLength(body),
            },
          }

          const req = https.request(reqOpts, res => {
            let data = ''
            res.on('data', chunk => { data += chunk })
            res.on('end', () => {
              try {
                const parsed = JSON.parse(data)
                if (res.statusCode !== 200) {
                  reject(new Error(`connectPeer.sync: HTTP ${res.statusCode} — ${parsed.error || data}`))
                  return
                }
                resolve(parsed)
              } catch (e) {
                reject(new Error(`connectPeer.sync: JSON parse error — ${e.message}`))
              }
            })
          })

          req.on('error', err => {
            log(`[ERROR] connectPeer.sync vers ${peerUrl} — ${err.message}`)
            reject(err)
          })

          req.write(body)
          req.end()
        } catch (err) {
          // Isolation TLS
          log(`[ERROR] connectPeer.sync setup — ${err.message}`)
          reject(err)
        }
      })
    },
  }
}

// ── Synchronisation avec un pair ──────────────────────────────────────────────

/**
 * syncWithPeer — échange bidirectionnel de trajectoires avec un pair.
 *
 * Filtre les trajectoires dont nodeId === localNodeId (évite les doublons).
 * Stocke silencieusement via bank.store().
 *
 * @param {{ sync(query: string, topK?: number): Promise<{ trajectories: any[], nodeId: string }> }} peer
 * @param {string} query
 * @param {number} [topK=5]
 * @returns {Promise<{ sent: number, received: number }>}
 */
async function syncWithPeer(peer, query, topK = 5) {
  const fedCfg     = getFederationConfig()
  const certDir    = fedCfg.certDir ?? join(CONFIG_DIR, 'federation', 'certs')
  const localNodeId = _getLocalNodeId(certDir)

  let remoteData
  try {
    remoteData = await peer.sync(query, topK)
  } catch (err) {
    log(`[ERROR] syncWithPeer: peer.sync échoué — ${err.message}`)
    throw err
  }

  const { trajectories = [], nodeId: peerNodeId } = remoteData

  // Enregistrer le pair comme actif
  if (peerNodeId) _upsertActivePeer(peerNodeId, '')

  // Filtrer et stocker
  const bank   = getBank()
  let imported = 0

  for (const traj of trajectories) {
    // Ignorer les trajectoires qui proviennent de ce nœud (ré-import)
    if (traj.nodeId && traj.nodeId === localNodeId) continue

    try {
      if (bank && traj.phase && traj.agent && traj.verdict && traj.summary) {
        bank.store(traj.phase, traj.agent, traj.verdict, traj.summary, {
          tags:    traj.tags,
          project: traj.project,
          runId:   traj.runId,
        })
        imported++
      }
    } catch { /* silencieux — store individuel ne doit jamais crasher la boucle */ }
  }

  log(`[INFO] syncWithPeer: envoyé=${topK} reçu=${trajectories.length} importé=${imported} (pair=${peerNodeId || '?'})`)
  return { sent: topK, received: imported }
}

// ── Utilitaires internes ──────────────────────────────────────────────────────

/**
 * _getLocalNodeId — lit le CN du certificat local ou fallback os.hostname().
 * @param {string} certDir
 * @returns {string}
 */
function _getLocalNodeId(certDir) {
  try {
    const certPath = join(certDir, 'cert.pem')
    if (existsSync(certPath)) {
      const pem  = readFileSync(certPath, 'utf8')
      const cert = new crypto.X509Certificate(pem)
      const cn   = cert.subject.split('\n').find(l => l.startsWith('CN='))?.slice(3)
      if (cn) return cn
    }
  } catch { /* silencieux */ }
  return os.hostname()
}

function _jsonResponse(res, status, data) {
  try {
    const body = JSON.stringify(data)
    res.writeHead(status, {
      'Content-Type':   'application/json',
      'Content-Length': Buffer.byteLength(body),
    })
    res.end(body)
  } catch { /* silencieux */ }
}

function _readBody(req, cb) {
  let data = ''
  const MAX = 1024 * 1024  // 1 MB
  req.on('data', chunk => {
    data += chunk
    if (data.length > MAX) {
      cb(new Error('body trop large'))
      req.destroy()
    }
  })
  req.on('end',   () => cb(null, data))
  req.on('error', err => cb(err))
}

// ── Module exports ────────────────────────────────────────────────────────────

module.exports = {
  startFederationServer,
  connectPeer,
  syncWithPeer,
  generateCerts,
  loadCerts,
  getActivePeers,
  // Exposés pour les tests
  _getLocalNodeId,
  getFederationConfig,
  saveFederationConfig,
}
