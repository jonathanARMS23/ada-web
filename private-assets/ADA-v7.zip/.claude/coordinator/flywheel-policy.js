'use strict'
/**
 * coordinator/flywheel-policy.js — lecture de la policy de retrieval/routing active.
 *
 * NOYAU flywheel (inspiré de ruflo `proven-config.ts`, réduit au mono-machine) :
 * une « policy » est un jeu de paramètres NOMMÉS qui modulent le recall/gate. Le fichier
 * `active-policy.json` est écrit UNIQUEMENT par flywheel.js (apply/revert), jamais à la main.
 *
 * Ce module est le point de lecture MINIMAL et fail-safe branché dans le chemin chaud
 * (bank.js `_applyInjectionGate` / `buildRecallBlock`). Contrat :
 *   - fichier absent / corrompu / clé inconnue → DÉFAUTS (aucun changement de comportement).
 *   - défauts = valeurs actuellement en dur → sans policy appliquée, tout est identique à avant.
 *   - cache invalidé par mtime : une écriture par flywheel.js est vue au prochain loadPolicy
 *     sans redémarrer le process, mais un fichier inchangé n'est jamais re-parsé.
 *
 * Zéro dépendance. Pur sauf le stat/read du fichier.
 */

const { readFileSync, statSync } = require('fs')
const { join } = require('path')

const POLICY_PATH = join(__dirname, 'active-policy.json')

/**
 * Paramètres policy-configurables. Défauts = valeurs actuellement EN DUR dans le code :
 *   - gateScoreThreshold  : injection-gate.js `scoreThreshold` (étage 1 du gate) — défaut 1.
 *   - gateMinSharedTokens : injection-gate.js confirmation étage 2 (# tokens concrets
 *                           partagés requis) — défaut 1 (= comportement `shared.length > 0`).
 *   - recallK             : limite du retrieve (k) utilisée par buildRecallBlock — défaut 6.
 * Tous NUMÉRIQUES : validation stricte au chargement (une valeur non-finie est ignorée).
 */
const DEFAULTS = Object.freeze({
  gateScoreThreshold: 1,
  gateMinSharedTokens: 1,
  recallK: 6,
})

/** @type {{ path: string, mtimeMs: number, params: object } | null} */
let _cache = null

/**
 * Lit et valide les params depuis un fichier. Ne lève jamais : renvoie les défauts
 * sur toute erreur (absent, JSON invalide, structure inattendue).
 * @param {string} path
 * @returns {object} params complets (défauts + overrides valides)
 */
function _read(path) {
  const out = { ...DEFAULTS }
  try {
    const obj = JSON.parse(readFileSync(path, 'utf8'))
    const params = obj && typeof obj.params === 'object' && obj.params ? obj.params : {}
    for (const k of Object.keys(DEFAULTS)) {
      const v = params[k]
      if (typeof v === 'number' && Number.isFinite(v)) out[k] = v
    }
  } catch {
    /* fail-safe → défauts */
  }
  return out
}

/**
 * Renvoie les paramètres de la policy active (fusionnés aux défauts).
 * @param {{ path?: string, fresh?: boolean }} [opts]
 *   - path  : fichier alternatif (tests). Bypass du cache global.
 *   - fresh : force une relecture (ignore le cache).
 * @returns {{ gateScoreThreshold: number, gateMinSharedTokens: number, recallK: number }}
 */
function loadPolicy(opts = {}) {
  const path = opts.path || POLICY_PATH
  if (opts.fresh) return _read(path)

  let mtimeMs = 0
  try { mtimeMs = statSync(path).mtimeMs } catch { mtimeMs = 0 }

  if (_cache && _cache.path === path && _cache.mtimeMs === mtimeMs) {
    return _cache.params
  }
  const params = _read(path)
  _cache = { path, mtimeMs, params }
  return params
}

/** Réinitialise le cache (tests / après apply-revert dans le même process). */
function resetPolicyCache() { _cache = null }

module.exports = { loadPolicy, resetPolicyCache, DEFAULTS, POLICY_PATH }
