#!/usr/bin/env node
'use strict'
/**
 * coordinator/flywheel.js — NOYAU « flywheel » : boucle fermée anti-régression du recall.
 *
 * PROBLÈME : un changement de paramètres de retrieval/gate/ranking peut dégrader la
 * qualité d'injection SANS que rien ne bloque (c'est arrivé : « ADA pire en qualité/$
 * que naked-haiku » avant les fixes 2026-06). Les frameworks bench existants (benchmark.js,
 * bench-v2.js) MESURENT mais ne FERMENT pas la boucle.
 *
 * NOYAU (porté de ruflo harness-flywheel-runtime, réduit au mono-machine mono-user —
 * PAS de propagation multi-install, canary, ni distribué) :
 *   1. Un jeu d'ANCRES FIGÉ (flywheel-anchors.json) : requêtes de recall représentatives
 *      + markers attendus dans le top-k. Évalué en recall@k.
 *   2. Une BASELINE monotone (flywheel-baseline.json) : le meilleur score authentifié.
 *      Ne se réécrit qu'à la hausse (≥).
 *   3. `check` : eval + compare → FAIL-CLOSED (exit 1) sur régression, montée à la hausse sinon.
 *   4. `policy apply` : applique un jeu de params NOMMÉ, lance check ; régression →
 *      REVERT AUTOMATIQUE (pointeur `previous`), idempotent et réversible.
 *
 * Zéro dépendance npm. Le recall est évalué via bank.js `buildRecallBlock` (voie sync
 * TF-IDF, gate d'injection ACTIF = config de prod).
 */

const { readFileSync, writeFileSync, existsSync, rmSync } = require('fs')
const { join } = require('path')
const { loadPolicy, resetPolicyCache, DEFAULTS, POLICY_PATH } = require('./flywheel-policy.js')

const ANCHORS_PATH  = join(__dirname, 'flywheel-anchors.json')
const BASELINE_PATH = join(__dirname, 'flywheel-baseline.json')
const EPS = 1e-9

const C = {
  reset: '\x1b[0m', bold: '\x1b[1m', dim: '\x1b[2m',
  green: '\x1b[32m', red: '\x1b[31m', yellow: '\x1b[33m', cyan: '\x1b[36m',
}

/** Horodatage ISO (CLI — Date autorisé hors scripts de workflow). */
function nowIso() { return new Date().toISOString() }

// ── Recall@k (pur) ─────────────────────────────────────────────────────────────

/**
 * recall@k d'une ancre : fraction des markers attendus présents (sous-chaîne,
 * insensible à la casse) dans le bloc recall.
 * @param {string} block
 * @param {string[]} expectedMarkers
 * @returns {{ recall: number, found: string[], missing: string[] }}
 */
function computeRecallAtK(block, expectedMarkers) {
  const markers = Array.isArray(expectedMarkers) ? expectedMarkers : []
  if (!markers.length) return { recall: 1, found: [], missing: [] }
  const hay = String(block || '').toLowerCase()
  const found = [], missing = []
  for (const m of markers) {
    if (hay.includes(String(m).toLowerCase())) found.push(m)
    else missing.push(m)
  }
  return { recall: found.length / markers.length, found, missing }
}

/**
 * Évalue toutes les ancres. `recallFn(query, k) → blockString` est INJECTÉ
 * (testabilité + override de policy hypothétique). Score global = moyenne des recall@k.
 * @param {{ anchors: object[], k?: number, recallFn: Function }} args
 * @returns {{ k: number, score: number, anchors: object[] }}
 */
function evalAnchors({ anchors, k = 5, recallFn }) {
  const list = Array.isArray(anchors) ? anchors : []
  const rows = list.map((a) => {
    const block = recallFn(a.query, k) || ''
    const r = computeRecallAtK(block, a.expectedMarkers || [])
    return {
      id: a.id, query: a.query,
      recall: r.recall, found: r.found, missing: r.missing,
      expected: (a.expectedMarkers || []).length,
    }
  })
  const score = rows.length ? rows.reduce((s, r) => s + r.recall, 0) / rows.length : 0
  return { k, score, anchors: rows }
}

// ── recallFn concrets (bank.js chargé en lazy) ──────────────────────────────────

function _bank() { return require('./bank.js') }

/** recallFn de prod : buildRecallBlock avec la policy ACTIVE (gate actif). */
function defaultRecallFn(query, k) {
  try { return _bank().buildRecallBlock(query, { limit: k }) || '' }
  catch { return '' }
}

/**
 * recallFn avec des seuils de gate HYPOTHÉTIQUES (eval d'une policy sans l'appliquer).
 * Accepte le VOCABULAIRE POLICY (gateScoreThreshold / gateMinSharedTokens) et le traduit
 * vers le vocabulaire du gate (scoreThreshold / minSharedTokens) attendu par bank.js.
 * @param {{ gateScoreThreshold?: number, gateMinSharedTokens?: number }} policyParams
 */
function makeRecallFn(policyParams = {}) {
  const gateParams = {
    scoreThreshold: policyParams.gateScoreThreshold,
    minSharedTokens: policyParams.gateMinSharedTokens,
  }
  return (query, k) => {
    try { return _bank().buildRecallBlock(query, { limit: k, gateParams }) || '' }
    catch { return '' }
  }
}

// ── Ancres & baseline ────────────────────────────────────────────────────────

function loadAnchors(path = ANCHORS_PATH) {
  const obj = JSON.parse(readFileSync(path, 'utf8'))
  return { frozen: obj.frozen === true, k: obj.k || 5, anchors: Array.isArray(obj.anchors) ? obj.anchors : [] }
}

function readBaseline(path = BASELINE_PATH) {
  try { return JSON.parse(readFileSync(path, 'utf8')) }
  catch { return null }
}

/** Normalise le champ `anchors` d'un résultat (array evalAnchors OU map id→recall). */
function _anchorMap(anchors) {
  if (Array.isArray(anchors)) return Object.fromEntries(anchors.map((a) => [a.id, a.recall]))
  return anchors && typeof anchors === 'object' ? anchors : {}
}

/**
 * Écrit la baseline de façon MONOTONE : refuse un score strictement inférieur au
 * courant (sauf `--force`). C'est le garde-fou qui empêche de « figer » une régression.
 * @returns {{ written: boolean, reason?: string }}
 */
function writeBaseline(path = BASELINE_PATH, result, opts = {}) {
  const existing = readBaseline(path)
  if (existing && !opts.force && result.score < existing.score - EPS) {
    return { written: false, reason: `monotone: score ${result.score.toFixed(4)} < baseline ${existing.score.toFixed(4)} — régression refusée (utiliser --force pour outrepasser)` }
  }
  const payload = {
    score: result.score,
    k: result.k,
    ts: nowIso(),
    anchors: _anchorMap(result.anchors),
  }
  writeFileSync(path, JSON.stringify(payload, null, 2) + '\n')
  return { written: true }
}

/**
 * Compare un résultat d'éval à la baseline. FAIL-CLOSED : `ok=false` dès que le score
 * global régresse. `regressions` = ancres dont le recall a chuté (détail par ancre).
 * @returns {{ ok: boolean, firstRun?: boolean, delta: number, regressions: object[], score: number, baselineScore: number|null }}
 */
function checkAgainstBaseline(result, baseline) {
  if (!baseline) {
    return { ok: true, firstRun: true, delta: result.score, regressions: [], score: result.score, baselineScore: null }
  }
  const delta = result.score - baseline.score
  const ok = delta >= -EPS
  const baseAnchors = baseline.anchors || {}
  const regressions = []
  for (const a of (result.anchors || [])) {
    const prev = baseAnchors[a.id]
    if (typeof prev === 'number' && a.recall < prev - EPS) {
      regressions.push({ id: a.id, was: prev, now: a.recall, missing: a.missing || [] })
    }
  }
  return { ok, delta, regressions, score: result.score, baselineScore: baseline.score }
}

// ── Policy : apply / revert (fail-closed, idempotent, réversible) ───────────────

/** Ne conserve que les clés policy connues, valeurs numériques finies. */
function _sanitizeParams(params) {
  const out = {}
  const src = params && typeof params === 'object' ? params : {}
  for (const k of Object.keys(DEFAULTS)) {
    const v = src[k]
    if (typeof v === 'number' && Number.isFinite(v)) out[k] = v
  }
  return out
}

function _sameParams(a, b) {
  const ka = Object.keys(a || {}).sort(), kb = Object.keys(b || {}).sort()
  if (ka.length !== kb.length) return false
  return ka.every((k, i) => k === kb[i] && a[k] === b[k])
}

function _readActive(policyPath) {
  try { return JSON.parse(readFileSync(policyPath, 'utf8')) }
  catch { return null }
}

/** Restaure `previous` (objet policy complet) OU supprime le fichier (retour aux défauts). */
function _restore(policyPath, previous) {
  if (previous) writeFileSync(policyPath, JSON.stringify(previous, null, 2) + '\n')
  else if (existsSync(policyPath)) rmSync(policyPath)
  resetPolicyCache()
}

/** check IN-PROCESS après écriture de la policy (bank relit via mtime + resetPolicyCache). */
function _defaultCheckFn() {
  resetPolicyCache()
  const { anchors, k } = loadAnchors()
  const result = evalAnchors({ anchors, k, recallFn: defaultRecallFn })
  return checkAgainstBaseline(result, readBaseline())
}

/**
 * Applique une policy : sauvegarde la courante dans `previous`, écrit la nouvelle,
 * lance `check`. Régression → REVERT AUTOMATIQUE (fail-closed). Re-apply identique = no-op.
 * @param {{ policyPath?: string, params: object, checkFn?: Function }} args
 * @returns {{ ok: boolean, noop?: boolean, reverted: boolean, check?: object }}
 */
function applyPolicy({ policyPath = POLICY_PATH, params, checkFn }) {
  const newParams = _sanitizeParams(params)
  const current = _readActive(policyPath)

  if (current && _sameParams(current.params || {}, newParams)) {
    return { ok: true, noop: true, reverted: false }
  }

  const previous = current || null
  const next = { params: newParams, previous, appliedAt: nowIso() }
  writeFileSync(policyPath, JSON.stringify(next, null, 2) + '\n')
  resetPolicyCache()

  const check = (checkFn || _defaultCheckFn)()
  if (check && check.ok === false) {
    _restore(policyPath, previous)
    return { ok: false, reverted: true, check }
  }
  return { ok: true, reverted: false, check }
}

/**
 * Restaure la policy précédente (`previous`). Sans `previous` → supprime le fichier
 * (retour aux défauts). Sans policy active → no-op.
 * @param {{ policyPath?: string }} [args]
 */
function revertPolicy({ policyPath = POLICY_PATH } = {}) {
  const current = _readActive(policyPath)
  if (!current) return { ok: true, noop: true }
  const previous = current.previous || null
  _restore(policyPath, previous)
  return { ok: true, restoredTo: previous ? (previous.params || {}) : null }
}

module.exports = {
  computeRecallAtK, evalAnchors,
  defaultRecallFn, makeRecallFn,
  loadAnchors, readBaseline, writeBaseline, checkAgainstBaseline,
  applyPolicy, revertPolicy,
  ANCHORS_PATH, BASELINE_PATH,
}

// ── CLI ─────────────────────────────────────────────────────────────────────

function _fmtPct(x) { return `${(x * 100).toFixed(1)}%` }

function _printEval(result) {
  console.log(`\n${C.bold}Flywheel — recall@${result.k} sur ${result.anchors.length} ancres${C.reset}`)
  console.log('─'.repeat(60))
  for (const a of result.anchors) {
    const ok = a.recall >= 1 - EPS
    const icon = ok ? `${C.green}✓${C.reset}` : `${C.red}✗${C.reset}`
    const detail = ok ? '' : ` ${C.dim}(manque: ${a.missing.join(', ')})${C.reset}`
    console.log(`  ${icon} ${a.id.padEnd(22)} ${_fmtPct(a.recall).padStart(6)}${detail}`)
  }
  console.log('─'.repeat(60))
  console.log(`  ${C.bold}Score global : ${_fmtPct(result.score)}${C.reset}\n`)
}

function _cmdEval(flags) {
  const { anchors, k } = loadAnchors()
  const kk = flags.k ? parseInt(flags.k, 10) : k
  const result = evalAnchors({ anchors, k: kk, recallFn: defaultRecallFn })
  if (flags.json) { console.log(JSON.stringify(result, null, 2)); return 0 }
  _printEval(result)
  return 0
}

function _cmdBaseline(flags) {
  const { anchors, k } = loadAnchors()
  const result = evalAnchors({ anchors, k, recallFn: defaultRecallFn })
  const r = writeBaseline(BASELINE_PATH, result, { force: !!flags.force })
  if (!r.written) {
    console.error(`${C.red}✗ baseline refusée${C.reset} — ${r.reason}`)
    return 1
  }
  console.log(`${C.green}✓ baseline figée${C.reset} : score=${_fmtPct(result.score)} (k=${result.k}, ${result.anchors.length} ancres)`)
  return 0
}

function _cmdCheck(flags) {
  resetPolicyCache()
  const { anchors, k } = loadAnchors()
  const result = evalAnchors({ anchors, k, recallFn: defaultRecallFn })
  const baseline = readBaseline()
  const c = checkAgainstBaseline(result, baseline)

  if (flags.json) {
    console.log(JSON.stringify({ ...c, result }, null, 2))
    return c.ok ? 0 : 1
  }

  if (c.firstRun) {
    console.log(`${C.yellow}⚠ aucune baseline${C.reset} — score courant=${_fmtPct(result.score)}. Fige-la : flywheel.js baseline`)
    return 0
  }
  if (c.ok) {
    console.log(`${C.green}✓ check OK${C.reset} — score=${_fmtPct(result.score)} vs baseline=${_fmtPct(c.baselineScore)} (Δ=${(c.delta * 100).toFixed(1)}pts)`)
    if (c.delta > EPS) {
      writeBaseline(BASELINE_PATH, result, { force: true })
      console.log(`  ${C.cyan}↑ baseline montée à ${_fmtPct(result.score)}${C.reset}`)
    }
    return 0
  }
  console.error(`${C.red}✗ RÉGRESSION${C.reset} — score=${_fmtPct(result.score)} < baseline=${_fmtPct(c.baselineScore)} (Δ=${(c.delta * 100).toFixed(1)}pts)`)
  for (const r of c.regressions) {
    console.error(`    ${C.red}•${C.reset} ${r.id}: ${_fmtPct(r.was)} → ${_fmtPct(r.now)} ${C.dim}(manque: ${(r.missing || []).join(', ')})${C.reset}`)
  }
  return 1
}

function _cmdPolicy(args) {
  const sub = args[0]
  if (sub === 'apply') {
    const file = args[1]
    if (!file || !existsSync(file)) { console.error('Usage: flywheel.js policy apply <file.json>'); return 1 }
    let raw
    try { raw = JSON.parse(readFileSync(file, 'utf8')) } catch (e) { console.error(`JSON invalide: ${e.message}`); return 1 }
    const params = raw && raw.params ? raw.params : raw
    const res = applyPolicy({ params })
    if (res.noop) { console.log(`${C.dim}= policy déjà active (no-op)${C.reset}`); return 0 }
    if (res.ok) {
      console.log(`${C.green}✓ policy appliquée${C.reset} — ${JSON.stringify(_sanitizeParams(params))} ; check OK`)
      return 0
    }
    console.error(`${C.red}✗ policy REVERT automatique${C.reset} — régression détectée (Δ=${(res.check.delta * 100).toFixed(1)}pts), policy précédente restaurée`)
    for (const r of (res.check.regressions || [])) {
      console.error(`    ${C.red}•${C.reset} ${r.id}: ${_fmtPct(r.was)} → ${_fmtPct(r.now)}`)
    }
    return 1
  }
  if (sub === 'revert') {
    const res = revertPolicy({})
    if (res.noop) { console.log(`${C.dim}= aucune policy active${C.reset}`); return 0 }
    console.log(`${C.green}✓ policy revert${C.reset} → ${res.restoredTo ? JSON.stringify(res.restoredTo) : 'défauts (fichier supprimé)'}`)
    return 0
  }
  if (sub === 'show') {
    const active = _readActive(POLICY_PATH)
    console.log(JSON.stringify({ active: active ? active.params : null, effective: loadPolicy({ fresh: true }), defaults: DEFAULTS }, null, 2))
    return 0
  }
  console.error('Usage: flywheel.js policy <apply <file>|revert|show>')
  return 1
}

function _parseFlags(args) {
  const flags = {}, rest = []
  for (let i = 0; i < args.length; i++) {
    if (args[i].startsWith('--')) {
      const key = args[i].slice(2)
      const next = args[i + 1]
      if (next === undefined || next.startsWith('--')) flags[key] = true
      else { flags[key] = next; i++ }
    } else rest.push(args[i])
  }
  return { flags, rest }
}

function main(argv) {
  const cmd = argv[0]
  const { flags, rest } = _parseFlags(argv.slice(1))
  let code = 0
  switch (cmd) {
    case 'eval':     code = _cmdEval(flags); break
    case 'baseline': code = _cmdBaseline(flags); break
    case 'check':    code = _cmdCheck(flags); break
    case 'policy':   code = _cmdPolicy(rest); break
    default:
      console.log(`flywheel.js — boucle fermée anti-régression du recall

Usage:
  flywheel.js eval [--json] [--k N]     évalue le recall@k sur les ancres figées
  flywheel.js baseline [--force]         fige le score courant (monotone : refuse une régression)
  flywheel.js check [--json]             eval + compare à la baseline (exit 1 si régression)
  flywheel.js policy apply <file.json>   applique une policy ; régression → revert auto (fail-closed)
  flywheel.js policy revert              restaure la policy précédente
  flywheel.js policy show                affiche la policy active / effective / défauts`)
      code = cmd ? 1 : 0
  }
  process.exit(code)
}

if (require.main === module) main(process.argv.slice(2))
