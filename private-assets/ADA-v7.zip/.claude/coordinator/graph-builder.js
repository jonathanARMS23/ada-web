#!/usr/bin/env node
/**
 * coordinator/graph-builder.js — Construit un KnowledgeGraph depuis les sources de données.
 *
 * Sources :
 *   - bank-state.json (trajectoires)  → nœuds agent/phase + agrégats WIN_RATE / CO_OCCURRENCE
 *   - pipelines.json (DAG)            → arêtes PRÉCÈDE entre phases consécutives
 *
 * Zéro dépendance externe.
 *
 * CLI :
 *   node graph-builder.js build   — construit et sauvegarde le graphe
 *   node graph-builder.js stats   — affiche les stats du graphe sauvegardé
 */

'use strict'

const fs   = require('fs')
const path = require('path')

const { KnowledgeGraph } = require('./graph-memory.js')

// ── Constantes ────────────────────────────────────────────────────────────────

const CONFIG_DIR      = process.env.CLAUDE_CONFIG_DIR || path.join(process.env.HOME, '.claude')
const COORD_DIR       = path.join(CONFIG_DIR, 'coordinator')
const DEFAULT_GRAPH   = path.join(COORD_DIR, 'graph-state.json')
const DEFAULT_BANK    = path.join(COORD_DIR, 'bank-state.json')
const DEFAULT_PIPELINES = path.join(COORD_DIR, 'pipelines.json')

// ── Utilitaires ───────────────────────────────────────────────────────────────

/**
 * Lit et parse un fichier JSON. Retourne null en cas d'erreur ou absence.
 * @param {string} filePath
 * @returns {unknown|null}
 */
function readJSON (filePath) {
  if (!fs.existsSync(filePath)) return null
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'))
  } catch {
    return null
  }
}

// ── buildFromBankState ────────────────────────────────────────────────────────

/**
 * Construit un graphe depuis bank-state.json.
 *
 * Pour chaque trajectoire :
 *   - addNode agent + phase
 *   - graph.aggregate(agent, phase, verdict)
 *
 * CO_OCCURRENCE : si deux agents différents apparaissent pour la même phase
 * dans une fenêtre de 5 trajectoires consécutives, ajoute CO_OCCURRENCE +=1.
 *
 * @param {string} [bankStatePath]
 * @returns {KnowledgeGraph}
 */
function buildFromBankState (bankStatePath) {
  const filePath = bankStatePath ?? DEFAULT_BANK
  const data     = readJSON(filePath)
  const g        = new KnowledgeGraph()

  if (!data) return g

  // Normalise : supporte { trajectories: [...] } ou un tableau direct
  /** @type {Array<Record<string, unknown>>} */
  const trajectories = Array.isArray(data)
    ? data
    : Array.isArray(data.trajectories)
      ? data.trajectories
      : Object.values(data).filter(v => v && typeof v === 'object' && v.phase)

  if (!trajectories.length) return g

  // Passe 1 : aggregate (WIN_RATE / A_RÉSOLU / ANTI_CORRÈLE)
  for (const traj of trajectories) {
    const agent   = String(traj.agent   ?? '').trim()
    const phase   = String(traj.phase   ?? '').trim()
    const verdict = String(traj.verdict ?? '').trim()

    if (!agent || !phase || !verdict) continue
    g.aggregate(agent, phase, verdict)
  }

  // Passe 2 : CO_OCCURRENCE — fenêtre glissante de 5
  const WINDOW = 5
  for (let i = 0; i < trajectories.length; i++) {
    const tA = trajectories[i]
    if (!tA.agent || !tA.phase) continue

    for (let j = i + 1; j < Math.min(i + WINDOW, trajectories.length); j++) {
      const tB = trajectories[j]
      if (!tB.agent || !tB.phase) continue
      if (tA.agent === tB.agent) continue
      if (tA.phase !== tB.phase) continue

      const nodeA = `agent:${tA.agent}`
      const nodeB = `agent:${tB.agent}`
      g.addEdge(nodeA, nodeB, 'CO_OCCURRENCE', 1)
    }
  }

  return g
}

// ── buildFromPipelines ────────────────────────────────────────────────────────

/**
 * Construit (ou augmente) un graphe depuis pipelines.json.
 *
 * Pour chaque pipeline, crée des arêtes PRÉCÈDE entre phases consécutives.
 * Un pipeline peut avoir des phases dans un tableau `phases` (chaque phase ayant
 * un champ `id`) ou `steps` (champ `phase`).
 *
 * @param {string} [pipelinesPath]
 * @param {KnowledgeGraph} [graph]
 * @returns {KnowledgeGraph}
 */
function buildFromPipelines (pipelinesPath, graph) {
  const filePath = pipelinesPath ?? DEFAULT_PIPELINES
  const data     = readJSON(filePath)
  const g        = graph ?? new KnowledgeGraph()

  if (!data || typeof data !== 'object') return g

  // Normalise : supporte un tableau de pipelines ou un objet { name: pipeline }
  /** @type {Array<Record<string, unknown>>} */
  const pipelines = Array.isArray(data)
    ? data
    : Object.entries(data)
        .filter(([k]) => !k.startsWith('_'))
        .map(([name, def]) => ({ name, .../** @type {Record<string, unknown>} */ (def) }))

  for (const pipeline of pipelines) {
    const pipelineName = String(pipeline.name ?? 'unknown')

    // Normalise les phases (supporte `phases` ou `steps`)
    const rawPhases = Array.isArray(pipeline.phases)
      ? pipeline.phases
      : Array.isArray(pipeline.steps)
        ? pipeline.steps
        : []

    if (rawPhases.length < 2) continue

    // Extrait les identifiants de phase dans l'ordre
    /** @type {string[]} */
    const phaseIds = rawPhases.map(p => String(p.id ?? p.phase ?? '')).filter(Boolean)

    // Crée le nœud pipeline
    g.addNode(`pipeline:${pipelineName}`, 'pipeline', pipelineName)

    // PRÉCÈDE entre phases consécutives
    for (let i = 0; i < phaseIds.length - 1; i++) {
      const fromId = `phase:${phaseIds[i]}`
      const toId   = `phase:${phaseIds[i + 1]}`

      g.addNode(fromId, 'phase', phaseIds[i])
      g.addNode(toId,   'phase', phaseIds[i + 1])
      g.addEdge(fromId, toId, 'PRÉCÈDE', 1, { pipeline: pipelineName })
    }
  }

  return g
}

// ── buildFromSQLite ───────────────────────────────────────────────────────────

/**
 * Construit un graphe directement depuis la base SQLite `bank.db`.
 * Plus précis que bank-state.json (toujours à jour, inclut tier et usage_count).
 *
 * @param {string} [dbPath]
 * @param {KnowledgeGraph} [graph]
 * @returns {KnowledgeGraph}
 */
function buildFromSQLite (dbPath, graph) {
  const filePath = dbPath ?? path.join(COORD_DIR, 'bank.db')
  const g = graph ?? new KnowledgeGraph()

  try {
    const { DatabaseSync } = require('node:sqlite')
    if (!fs.existsSync(filePath)) return g

    const db = new DatabaseSync(filePath)
    const rows = db.prepare(
      'SELECT agent, phase, verdict, ts FROM trajectories ORDER BY ts ASC'
    ).all()
    db.close()

    // Passe 1 — aggregate
    for (const row of rows) {
      const agent   = String(row.agent   ?? '').trim()
      const phase   = String(row.phase   ?? '').trim()
      const verdict = String(row.verdict ?? '').trim()
      if (!agent || !phase || !verdict) continue
      g.aggregate(agent, phase, verdict)
    }

    // Passe 2 — CO_OCCURRENCE fenêtre 5
    const WINDOW = 5
    for (let i = 0; i < rows.length; i++) {
      const tA = rows[i]
      if (!tA.agent || !tA.phase) continue
      for (let j = i + 1; j < Math.min(i + WINDOW, rows.length); j++) {
        const tB = rows[j]
        if (!tB.agent || !tB.phase) continue
        if (tA.agent === tB.agent) continue
        if (tA.phase !== tB.phase) continue
        g.addEdge(`agent:${tA.agent}`, `agent:${tB.agent}`, 'CO_OCCURRENCE', 1)
      }
    }
  } catch (e) {
    require('./logger').warn('graph-builder', 'buildFromSQLite failed — graph-boost disabled for this session', { error: e?.message })
  }

  return g
}

// ── buildFull ─────────────────────────────────────────────────────────────────

/**
 * Construit un graphe complet depuis toutes les sources.
 * Préfère SQLite si `bank.db` est présent, sinon bascule sur bank-state.json.
 * @param {{ configDir?: string, bankStatePath?: string, pipelinesPath?: string, dbPath?: string }} [opts={}]
 * @returns {KnowledgeGraph}
 */
function buildFull (opts = {}) {
  const {
    configDir     = COORD_DIR,
    bankStatePath = path.join(configDir, 'bank-state.json'),
    pipelinesPath = path.join(configDir, 'pipelines.json'),
    dbPath        = path.join(configDir, 'bank.db'),
  } = opts

  // SQLite en priorité si disponible (données fraîches), JSON en fallback
  let g
  if (fs.existsSync(dbPath)) {
    g = buildFromSQLite(dbPath)
    if (g.nodes.size === 0) g = buildFromBankState(bankStatePath)
  } else {
    g = buildFromBankState(bankStatePath)
  }

  buildFromPipelines(pipelinesPath, g)
  return g
}

// ── saveGraph / loadGraph ─────────────────────────────────────────────────────

/**
 * Sauvegarde un graphe sur disque (JSON indenté).
 * Crée le répertoire parent si nécessaire.
 * @param {KnowledgeGraph} graph
 * @param {string} [graphPath]
 */
function saveGraph (graph, graphPath) {
  const filePath = graphPath ?? DEFAULT_GRAPH
  const dir      = path.dirname(filePath)

  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })

  fs.writeFileSync(filePath, JSON.stringify(graph.toJSON(), null, 2), 'utf8')
}

/**
 * Charge un graphe depuis le disque.
 * Retourne null si le fichier est absent ou corrompu.
 * @param {string} [graphPath]
 * @returns {KnowledgeGraph|null}
 */
function loadGraph (graphPath) {
  const filePath = graphPath ?? DEFAULT_GRAPH
  const data     = readJSON(filePath)
  if (!data) return null
  try {
    return KnowledgeGraph.fromJSON(/** @type {{ nodes: unknown[], edges: unknown[] }} */ (data))
  } catch {
    return null
  }
}

// ── loadOrBuild ───────────────────────────────────────────────────────────────

/**
 * Charge le graphe depuis le disque s'il est récent, sinon le reconstruit.
 * @param {{
 *   graphPath?:      string,
 *   configDir?:      string,
 *   bankStatePath?:  string,
 *   pipelinesPath?:  string,
 *   maxAgeMs?:       number,
 * }} [opts={}]
 * @returns {KnowledgeGraph}
 */
// P4 — mémo in-process indexé par (path, mtime) : évite de re-désérialiser le JSON
// du graphe (parse + reconstruction des Maps) à chaque retrieve quand le fichier
// n'a pas changé. loadOrBuild est appelé sur le chemin par défaut (applyGraphBoost).
let _graphMemo = { path: null, mtimeMs: 0, graph: null }

function loadOrBuild (opts = {}) {
  const {
    graphPath     = DEFAULT_GRAPH,
    configDir     = COORD_DIR,
    bankStatePath = path.join(configDir, 'bank-state.json'),
    pipelinesPath = path.join(configDir, 'pipelines.json'),
    maxAgeMs      = 3_600_000, // 1 heure
  } = opts

  if (fs.existsSync(graphPath)) {
    const stat = fs.statSync(graphPath)
    const age  = Date.now() - stat.mtimeMs
    if (age < maxAgeMs) {
      // Cache mémoire : si le fichier n'a pas bougé (même mtime), réutiliser l'objet déjà parsé
      if (_graphMemo.graph && _graphMemo.path === graphPath && _graphMemo.mtimeMs === stat.mtimeMs) {
        return _graphMemo.graph
      }
      const cached = loadGraph(graphPath)
      if (cached) {
        _graphMemo = { path: graphPath, mtimeMs: stat.mtimeMs, graph: cached }
        return cached
      }
    }
  }

  const g = buildFull({ configDir, bankStatePath, pipelinesPath })
  saveGraph(g, graphPath)
  // Mettre à jour le mémo avec le graphe fraîchement construit + son nouveau mtime
  try { _graphMemo = { path: graphPath, mtimeMs: fs.statSync(graphPath).mtimeMs, graph: g } } catch {}
  return g
}

// ── CLI ───────────────────────────────────────────────────────────────────────

if (require.main === module) {
  const cmd = process.argv[2]

  if (cmd === 'build') {
    console.log('Building graph from bank-state.json + pipelines.json …')
    const g = buildFull()
    saveGraph(g)
    console.log(`Done. Nodes: ${g.nodes.size}  Edges: ${g.edges.size}`)
    console.log(`Saved to: ${DEFAULT_GRAPH}`)

  } else if (cmd === 'stats') {
    const g = loadGraph()
    if (!g) {
      console.log('No graph found. Run: node graph-builder.js build')
      process.exit(1)
    }

    console.log(`Nodes : ${g.nodes.size}`)
    console.log(`Edges : ${g.edges.size}`)

    const byNodeType = {}
    for (const n of g.nodes.values()) byNodeType[n.type] = (byNodeType[n.type] ?? 0) + 1
    console.log('Node types :', JSON.stringify(byNodeType, null, 2))

    const byEdgeType = {}
    for (const e of g.edges.values()) byEdgeType[e.type] = (byEdgeType[e.type] ?? 0) + 1
    console.log('Edge types :', JSON.stringify(byEdgeType, null, 2))

  } else {
    console.log('Usage: node graph-builder.js <build|stats>')
    process.exit(1)
  }
}

// ── Exports ───────────────────────────────────────────────────────────────────

module.exports = { buildFromBankState, buildFromSQLite, buildFromPipelines, buildFull, saveGraph, loadGraph, loadOrBuild }
