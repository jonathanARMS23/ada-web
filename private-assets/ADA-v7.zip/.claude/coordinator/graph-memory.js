#!/usr/bin/env node
/**
 * coordinator/graph-memory.js — KnowledgeGraph : graphe de connaissances des agents
 *
 * Nœuds  : agent | phase | pipeline | pattern | error
 * Arêtes : WIN_RATE | PRÉCÈDE | A_RÉSOLU | CO_OCCURRENCE | CAUSE | ANTI_CORRÈLE
 *
 * Algorithmes : BFS, PageRank, scoring combiné agent×phase
 * Zéro dépendance externe.
 *
 * CLI :
 *   node graph-memory.js stats   — compte nœuds/arêtes
 *   node graph-memory.js graph   — affiche le graphe JSON
 */

'use strict'

// ── Types (JSDoc) ─────────────────────────────────────────────────────────────

/**
 * @typedef {{ id: string, type: string, label: string, attrs: Record<string, unknown> }} GraphNode
 * @typedef {{ from: string, to: string, type: string, weight: number, ts: string, attrs: Record<string, unknown> }} GraphEdge
 */

// ── Constantes ────────────────────────────────────────────────────────────────

const NODE_TYPES = new Set(['agent', 'phase', 'pipeline', 'pattern', 'error', 'unknown'])
const EDGE_TYPES = new Set(['WIN_RATE', 'PRÉCÈDE', 'A_RÉSOLU', 'CO_OCCURRENCE', 'CAUSE', 'ANTI_CORRÈLE'])

// ── KnowledgeGraph ────────────────────────────────────────────────────────────

class KnowledgeGraph {
  constructor () {
    /** @type {Map<string, GraphNode>} id → node */
    this.nodes = new Map()
    /** @type {Map<string, GraphEdge>} edgeKey → edge  (key = `${from}→${to}:${type}`) */
    this.edges = new Map()
    /** @type {Map<string, Set<string>>} nodeId → Set(edgeKeys) outgoing */
    this.adj   = new Map()
    /** @type {Map<string, Set<string>>} nodeId → Set(edgeKeys) incoming */
    this.radj  = new Map()
  }

  // ── Helpers internes ───────────────────────────────────────────────────────

  /** @param {string} nodeId */
  _ensureSets (nodeId) {
    if (!this.adj.has(nodeId))  this.adj.set(nodeId, new Set())
    if (!this.radj.has(nodeId)) this.radj.set(nodeId, new Set())
  }

  /** @param {string} from @param {string} to @param {string} type @returns {string} */
  static _edgeKey (from, to, type) {
    return `${from}→${to}:${type}`
  }

  // ── Nœuds ──────────────────────────────────────────────────────────────────

  /**
   * Upsert d'un nœud. Si le nœud existe déjà, fusionne attrs mais conserve type/label.
   * @param {string} id
   * @param {string} type
   * @param {string} label
   * @param {Record<string, unknown>} [attrs={}]
   * @returns {GraphNode}
   */
  addNode (id, type, label, attrs = {}) {
    this._ensureSets(id)
    if (this.nodes.has(id)) {
      const existing = this.nodes.get(id)
      existing.attrs = Object.assign({}, existing.attrs, attrs)
      return existing
    }
    /** @type {GraphNode} */
    const node = { id, type, label, attrs: { ...attrs } }
    this.nodes.set(id, node)
    return node
  }

  /**
   * @param {string} id
   * @returns {GraphNode|null}
   */
  getNode (id) {
    return this.nodes.get(id) ?? null
  }

  // ── Arêtes ─────────────────────────────────────────────────────────────────

  /**
   * Ajoute ou met à jour une arête.
   * Si l'arête existe déjà, met à jour le poids (+=) plutôt que de remplacer.
   * Crée les nœuds manquants avec type='unknown'.
   * @param {string} from
   * @param {string} to
   * @param {string} type
   * @param {number} [weight=1.0]
   * @param {Record<string, unknown>} [attrs={}]
   * @returns {GraphEdge}
   */
  addEdge (from, to, type, weight = 1.0, attrs = {}) {
    // Crée les nœuds manquants
    if (!this.nodes.has(from)) this.addNode(from, 'unknown', from)
    if (!this.nodes.has(to))   this.addNode(to,   'unknown', to)

    const key = KnowledgeGraph._edgeKey(from, to, type)

    if (this.edges.has(key)) {
      const existing = this.edges.get(key)
      existing.weight += weight
      existing.ts      = new Date().toISOString()
      Object.assign(existing.attrs, attrs)
      return existing
    }

    /** @type {GraphEdge} */
    const edge = { from, to, type, weight, ts: new Date().toISOString(), attrs: { ...attrs } }
    this.edges.set(key, edge)

    this._ensureSets(from)
    this._ensureSets(to)
    this.adj.get(from).add(key)
    this.radj.get(to).add(key)

    return edge
  }

  /**
   * Met à jour le poids d'une arête existante (remplace, ne cumule pas).
   * No-op si l'arête n'existe pas.
   * @param {string} from
   * @param {string} to
   * @param {string} type
   * @param {number} newWeight
   */
  updateEdgeWeight (from, to, type, newWeight) {
    const key  = KnowledgeGraph._edgeKey(from, to, type)
    const edge = this.edges.get(key)
    if (!edge) return
    edge.weight = newWeight
    edge.ts     = new Date().toISOString()
  }

  /**
   * @param {string} from
   * @param {string} to
   * @param {string} type
   * @returns {GraphEdge|null}
   */
  getEdge (from, to, type) {
    return this.edges.get(KnowledgeGraph._edgeKey(from, to, type)) ?? null
  }

  // ── Traversée ──────────────────────────────────────────────────────────────

  /**
   * Retourne les voisins d'un nœud.
   * @param {string} nodeId
   * @param {{ edgeType?: string|null, direction?: 'out'|'in'|'both' }} [opts={}]
   * @returns {Array<{ node: GraphNode, edge: GraphEdge }>}
   */
  getNeighbors (nodeId, opts = {}) {
    const { edgeType = null, direction = 'out' } = opts
    /** @type {Set<string>} */
    const keys = new Set()

    if (direction === 'out' || direction === 'both') {
      for (const k of (this.adj.get(nodeId) ?? [])) keys.add(k)
    }
    if (direction === 'in' || direction === 'both') {
      for (const k of (this.radj.get(nodeId) ?? [])) keys.add(k)
    }

    /** @type {Array<{ node: GraphNode, edge: GraphEdge }>} */
    const result = []
    for (const key of keys) {
      const edge = this.edges.get(key)
      if (!edge) continue
      if (edgeType !== null && edge.type !== edgeType) continue
      const neighborId = edge.from === nodeId ? edge.to : edge.from
      const node       = this.nodes.get(neighborId)
      if (node) result.push({ node, edge })
    }
    return result
  }

  /**
   * BFS depuis startId.
   * @param {string} startId
   * @param {{ maxHops?: number, edgeTypes?: string[]|null }} [opts={}]
   * @returns {Map<string, { depth: number, viaEdge: GraphEdge }>}
   */
  bfs (startId, opts = {}) {
    const { maxHops = 3, edgeTypes = null } = opts
    /** @type {Map<string, { depth: number, viaEdge: GraphEdge }>} */
    const visited = new Map()
    /** @type {Array<{ id: string, depth: number }>} */
    const queue   = [{ id: startId, depth: 0 }]
    const seen    = new Set([startId])

    while (queue.length > 0) {
      const { id, depth } = queue.shift()
      if (depth >= maxHops) continue

      const outKeys = this.adj.get(id) ?? new Set()
      for (const key of outKeys) {
        const edge = this.edges.get(key)
        if (!edge) continue
        if (edgeTypes !== null && !edgeTypes.includes(edge.type)) continue

        const neighborId = edge.to
        if (seen.has(neighborId)) continue
        seen.add(neighborId)
        visited.set(neighborId, { depth: depth + 1, viaEdge: edge })
        queue.push({ id: neighborId, depth: depth + 1 })
      }
    }

    return visited
  }

  /**
   * PageRank standard avec gestion des nœuds dangling.
   * @param {{ iterations?: number, damping?: number }} [opts={}]
   * @returns {Map<string, number>}
   */
  pageRank (opts = {}) {
    const { iterations = 20, damping = 0.85 } = opts
    const nodeCount = this.nodes.size
    if (nodeCount === 0) return new Map()

    const baseScore = 1 / nodeCount

    /** @type {Map<string, number>} */
    const scores = new Map()
    for (const id of this.nodes.keys()) scores.set(id, baseScore)

    for (let i = 0; i < iterations; i++) {
      /** @type {Map<string, number>} */
      const next = new Map()
      for (const id of this.nodes.keys()) next.set(id, 0)

      let danglingSum = 0

      for (const [id, score] of scores) {
        const outEdges = this.adj.get(id) ?? new Set()
        const validOut = [...outEdges].filter(k => this.edges.has(k))

        if (validOut.length === 0) {
          // Nœud dangling : distribue son score à tous les nœuds
          danglingSum += score
        } else {
          for (const key of validOut) {
            const edge = this.edges.get(key)
            if (!edge) continue
            next.set(edge.to, (next.get(edge.to) ?? 0) + score / validOut.length)
          }
        }
      }

      // Distribution du score dangling équitablement
      const danglingContrib = danglingSum / nodeCount

      for (const [id] of this.nodes) {
        const base = (1 - damping) / nodeCount
        next.set(id, base + damping * ((next.get(id) ?? 0) + danglingContrib))
      }

      for (const [id, s] of next) scores.set(id, s)
    }

    return scores
  }

  // ── Scoring agent×phase ────────────────────────────────────────────────────

  /**
   * Score combiné WIN_RATE + A_RÉSOLU pour un couple agent×phase.
   * @param {string} agentId
   * @param {string} phaseId
   * @returns {number} ∈ [0, 1]
   */
  scoreAgentPhase (agentId, phaseId) {
    const agentNode = `agent:${agentId}`
    const phaseNode = `phase:${phaseId}`

    const winEdge      = this.getEdge(agentNode, phaseNode, 'WIN_RATE')
    const resolvedEdge = this.getEdge(agentNode, phaseNode, 'A_RÉSOLU')
    const antiEdge     = this.getEdge(agentNode, phaseNode, 'ANTI_CORRÈLE')

    if (!winEdge && !resolvedEdge) return 0

    const winRateWeight  = winEdge      ? winEdge.weight      : 0
    const resolvedWeight = resolvedEdge ? resolvedEdge.weight : 0
    const antiWeight     = antiEdge     ? antiEdge.weight     : 0

    // Score brut normalisé : succès net sur total d'observations
    const total = winRateWeight + antiWeight
    const netRate = total > 0 ? winRateWeight / total : 0.5

    const raw = netRate * 0.7 + (resolvedWeight > 0 ? Math.min(resolvedWeight / 10, 1) : 0) * 0.3
    return Math.min(raw, 1)
  }

  /**
   * Score hybride PageRank × WIN_RATE pour un agent sur une phase.
   * Enrichit scoreAgentPhase avec l'importance structurelle du nœud agent.
   * @param {string} agentId
   * @param {string} phaseId
   * @param {Map<string, number>} [pageRankScores]  résultat de this.pageRank()
   * @returns {number} ∈ [0, 1]
   */
  scoreHybrid (agentId, phaseId, pageRankScores) {
    const localScore = this.scoreAgentPhase(agentId, phaseId)
    if (!pageRankScores || pageRankScores.size === 0) return localScore

    const agentNode = `agent:${agentId}`
    const pr = pageRankScores.get(agentNode) ?? 0
    // Normaliser PR : multiplier par le nombre de nœuds pour obtenir un score relatif
    const prNorm = Math.min(pr * this.nodes.size, 2)  // cap à 2× pour éviter domination

    return Math.min(localScore * (1 + prNorm * 0.2), 1)
  }

  /**
   * Met à jour le graphe à partir d'un verdict d'exécution.
   * @param {string} agentId
   * @param {string} phaseId
   * @param {'success'|'failure'|'partial'} verdict
   */
  aggregate (agentId, phaseId, verdict) {
    const agentNode = `agent:${agentId}`
    const phaseNode = `phase:${phaseId}`

    this.addNode(agentNode, 'agent', agentId)
    this.addNode(phaseNode, 'phase', phaseId)

    if (verdict === 'success') {
      this.addEdge(agentNode, phaseNode, 'WIN_RATE', 1)
      this.addEdge(agentNode, phaseNode, 'A_RÉSOLU', 1)
    } else if (verdict === 'failure') {
      this.addEdge(agentNode, phaseNode, 'ANTI_CORRÈLE', 0.5)
    }
    // 'partial' : pas de mise à jour du graphe
  }

  // ── Sérialisation ──────────────────────────────────────────────────────────

  /**
   * @returns {{ nodes: GraphNode[], edges: GraphEdge[] }}
   */
  toJSON () {
    return {
      nodes: [...this.nodes.values()],
      edges: [...this.edges.values()],
    }
  }

  /**
   * Reconstruit un graphe depuis un objet toJSON().
   * @param {{ nodes: GraphNode[], edges: GraphEdge[] }} data
   * @returns {KnowledgeGraph}
   */
  static fromJSON (data) {
    const g = new KnowledgeGraph()
    if (!data || !Array.isArray(data.nodes) || !Array.isArray(data.edges)) return g

    for (const n of data.nodes) {
      g.nodes.set(n.id, { id: n.id, type: n.type, label: n.label, attrs: n.attrs ?? {} })
      g._ensureSets(n.id)
    }

    for (const e of data.edges) {
      const key = KnowledgeGraph._edgeKey(e.from, e.to, e.type)
      g.edges.set(key, {
        from:   e.from,
        to:     e.to,
        type:   e.type,
        weight: e.weight,
        ts:     e.ts,
        attrs:  e.attrs ?? {},
      })
      g._ensureSets(e.from)
      g._ensureSets(e.to)
      g.adj.get(e.from).add(key)
      g.radj.get(e.to).add(key)
    }

    return g
  }
}

// ── CLI ───────────────────────────────────────────────────────────────────────

if (require.main === module) {
  const { join } = require('path')
  const { existsSync, readFileSync } = require('fs')

  const CONFIG_DIR  = process.env.CLAUDE_CONFIG_DIR || join(process.env.HOME, '.claude')
  const GRAPH_FILE  = join(CONFIG_DIR, 'coordinator', 'graph-state.json')

  const cmd = process.argv[2]

  function loadGraph () {
    if (!existsSync(GRAPH_FILE)) return new KnowledgeGraph()
    try {
      const raw = readFileSync(GRAPH_FILE, 'utf8')
      return KnowledgeGraph.fromJSON(JSON.parse(raw))
    } catch {
      return new KnowledgeGraph()
    }
  }

  if (cmd === 'stats') {
    const g = loadGraph()
    console.log(`Nodes : ${g.nodes.size}`)
    console.log(`Edges : ${g.edges.size}`)

    const byType = {}
    for (const n of g.nodes.values()) byType[n.type] = (byType[n.type] ?? 0) + 1
    console.log('Node types :', JSON.stringify(byType, null, 2))

    const byEdge = {}
    for (const e of g.edges.values()) byEdge[e.type] = (byEdge[e.type] ?? 0) + 1
    console.log('Edge types :', JSON.stringify(byEdge, null, 2))

  } else if (cmd === 'graph') {
    const g = loadGraph()
    console.log(JSON.stringify(g.toJSON(), null, 2))

  } else {
    console.log('Usage: node graph-memory.js <stats|graph>')
    process.exit(1)
  }
}

// ── Exports ───────────────────────────────────────────────────────────────────

module.exports = { KnowledgeGraph }
