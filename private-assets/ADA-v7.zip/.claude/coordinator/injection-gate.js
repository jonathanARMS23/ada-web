'use strict'
/**
 * coordinator/injection-gate.js — Gate d'injection à DEUX ÉTAGES du recall.
 *
 * PROBLÈME : `ada bank recall "<tâche>"` injecte des conventions/leçons sur la base
 * d'heuristiques de similarité seules (étage 1). Un candidat « proche » mais hors-sujet
 * franchit parfois le seuil et gaspille le budget contexte de l'agent.
 *
 * SOLUTION (pattern porté de codegraph `getSegmentMatches` — décision NONE/HINT/FULL
 * par un signal cheap déterministe CONFIRMÉ contre le contenu réel ; le vocabulaire
 * multilingue de codegraph est volontairement NON copié — sur-ingénierie ici) :
 *
 *   Étage 1 (cheap, EXISTANT)     : le score de pertinence déjà calculé par le ranking
 *                                   (`_content`, stampé par scoreTrajectory). On le
 *                                   CONSOMME — on ne le recalcule jamais.
 *   Étage 2 (confirmation, NOUVEAU): le candidat partage-t-il des TOKENS CONCRETS avec
 *                                   la tâche (identifiants techniques : fichiers,
 *                                   symboles, termes de stack) ? Extraction : tokens
 *                                   alphanumériques ≥ 4 chars, minuscules, stopwords
 *                                   FR/EN exclus. Aucun mot vide ne confirme.
 *
 * Un candidat est CONFIRMÉ si (étage 2 : ≥1 token concret partagé) OU (étage 1 : score
 * ≥ seuil). Un candidat NI confirmé NI convention-ride-along est DROPPÉ.
 *
 * MODULATION du niveau :
 *   - FULL : ≥1 leçon (non-convention) confirmée, OU ≥2 candidats confirmés → bloc complet.
 *   - HINT : uniquement des conventions / signal faible → conventions seules (pas de leçons).
 *   - NONE : rien de confirmé → bloc vide, l'orchestrateur n'injecte RIEN.
 *
 * CONVENTIONS PROJET (tag `convention`, ex. TDD / pas de secrets / RLS) : quasi toujours
 * pertinentes. Par défaut (`alwaysKeepConventions:true`) elles sont conservées SANS
 * confirmation token — MAIS seulement si la tâche est on-topic globalement (au moins UN
 * candidat confirmé). Sinon (recette de cuisine) elles ne sont PAS injectées → NONE.
 * Ce garde-fou empêche d'injecter une convention pour une tâche sans aucun rapport.
 *
 * PORTÉE (documentée pour l'appelant bank.js) : ce module est PUR et zéro-dépendance ;
 * il agit EN AMONT sur la PERTINENCE (quels candidats/quel niveau), jamais en aval sur la
 * taille du bloc formaté (le format à puces est un contrat vérifié par les tests).
 */

/**
 * Stopwords FR/EN — LISTE COURTE inline (≥4 chars uniquement : les mots < 4 chars sont
 * déjà exclus par la borne de longueur, inutile de les lister). Objectif : empêcher des
 * mots-outils fréquents de « confirmer » une pertinence par accident.
 */
const STOPWORDS = new Set([
  // FR
  'avec', 'pour', 'dans', 'plus', 'tout', 'tous', 'cette', 'cettes', 'leur', 'leurs',
  'mais', 'donc', 'être', 'etre', 'fait', 'faire', 'sont', 'entre', 'comme', 'sans',
  'sous', 'vers', 'chez', 'très', 'tres', 'aussi', 'alors', 'ainsi', 'quand', 'quel',
  'quelle', 'quels', 'quelles', 'notre', 'votre', 'nous', 'vous', 'elle', 'elles',
  'cela', 'ceci', 'dont', 'peut', 'doit', 'était', 'etait', 'une', 'des', 'les',
  // EN
  'with', 'from', 'that', 'this', 'have', 'been', 'were', 'will', 'your', 'into',
  'when', 'then', 'them', 'they', 'what', 'which', 'while', 'about', 'there', 'their',
  'would', 'should', 'could', 'using', 'used', 'also', 'here', 'over', 'than', 'such',
  'some', 'must', 'does', 'done', 'only', 'very', 'each', 'both', 'more', 'most',
])

/**
 * Extrait les TOKENS CONCRETS d'un texte : alphanumériques ≥ 4 chars, minuscules,
 * stopwords exclus. Segmente sur toute frontière non-alphanumérique — donc
 * `bank.js` → ['bank'], `workspace_id` → ['workspace'], `UserService` → ['userservice'].
 * PURE, déterministe, zéro dépendance.
 *
 * @param {string} text
 * @returns {string[]} tokens concrets uniques (ordre de première apparition)
 */
function extractConcreteTokens(text) {
  if (!text || typeof text !== 'string') return []
  const out = []
  const seen = new Set()
  for (const w of text.toLowerCase().split(/[^a-z0-9]+/)) {
    if (w.length >= 4 && !STOPWORDS.has(w) && !seen.has(w)) {
      seen.add(w)
      out.push(w)
    }
  }
  return out
}

/** Étiquette courte d'un candidat pour les `reasons` (traçabilité sans fuiter tout le texte). */
function _short(c) {
  const s = String((c && c.summary) || '').trim()
  return s.length > 40 ? s.slice(0, 37) + '…' : (s || '(vide)')
}

/**
 * @typedef {object} GateContext
 * @property {boolean}  [alwaysKeepConventions=true]  conventions on-topic gardées sans confirmation token
 * @property {number}   [scoreThreshold=1]            seuil étage 1 sur le score amont (`_content`)
 * @property {number}   [minSharedTokens=1]           étage 2 : # de tokens concrets partagés requis
 *                                                    pour confirmer un candidat (défaut 1 = `shared>0`).
 *                                                    Policy-configurable (flywheel) — 1 = comportement historique.
 * @property {Function} [isConvention]                (candidate)=>bool ; défaut : tag 'convention'
 * @property {Function} [contentScore]                (candidate)=>number ; défaut : candidate._content||0
 */

/**
 * @typedef {object} GateDecision
 * @property {'NONE'|'HINT'|'FULL'} level
 * @property {object[]} kept     candidats à injecter (ordre d'entrée préservé)
 * @property {object[]} dropped  candidats écartés
 * @property {string[]} reasons  trace lisible de la décision
 */

/**
 * Gate d'injection à deux étages.
 *
 * @param {string}   taskDescription
 * @param {object[]} candidates       trajectoires/conventions candidates (post-ranking)
 * @param {GateContext} [context]
 * @returns {GateDecision}
 */
function gateRecall(taskDescription, candidates, context = {}) {
  const {
    alwaysKeepConventions = true,
    scoreThreshold = 1,
    minSharedTokens = 1,
    isConvention,
    contentScore,
  } = context
  // Borne défensive : un minSharedTokens < 1 dégénérerait en « tout confirmer ».
  const minShared = Number.isFinite(minSharedTokens) && minSharedTokens >= 1 ? minSharedTokens : 1

  const list = Array.isArray(candidates) ? candidates.filter(Boolean) : []
  if (!taskDescription || typeof taskDescription !== 'string' || !list.length) {
    return { level: 'NONE', kept: [], dropped: list, reasons: ['no-task-or-candidates'] }
  }

  const convOf = typeof isConvention === 'function'
    ? isConvention
    : (c) => Array.isArray(c.tags) && c.tags.includes('convention')
  const scoreOf = typeof contentScore === 'function'
    ? contentScore
    : (c) => (typeof c._content === 'number' ? c._content : 0)

  const taskTokens = new Set(extractConcreteTokens(taskDescription))

  // Évaluation par candidat : étage 2 (tokens concrets) + étage 1 (score amont).
  const evald = list.map((c) => {
    const cTokens = extractConcreteTokens(`${(c.tags || []).join(' ')} ${c.summary || ''}`)
    const shared = cTokens.filter((t) => taskTokens.has(t))
    const hasToken = shared.length >= minShared
    const score = scoreOf(c)
    const passScore = typeof score === 'number' && score >= scoreThreshold
    return { c, isConv: !!convOf(c), hasToken, shared, score, passScore, confirmed: hasToken || passScore }
  })

  // On-topic = la tâche a un rapport avec AU MOINS un candidat (étage 1 ou 2). C'est la
  // condition du ride-along des conventions : pas de ride-along sur une tâche sans rapport.
  const onTopic = evald.some((e) => e.confirmed)

  const kept = []
  const dropped = []
  const reasons = []
  for (const e of evald) {
    if (e.confirmed) {
      kept.push(e.c)
      reasons.push(`keep:${_short(e.c)} [${e.hasToken ? 'token:' + e.shared.join(',') : 'score:' + e.score}]`)
    } else if (e.isConv && alwaysKeepConventions && onTopic) {
      kept.push(e.c)
      reasons.push(`keep-conv-ride-along:${_short(e.c)}`)
    } else {
      dropped.push(e.c)
      reasons.push(`drop:${_short(e.c)}${e.isConv ? ' (conv,off-topic)' : ''}`)
    }
  }

  if (!kept.length) {
    return { level: 'NONE', kept: [], dropped, reasons: reasons.length ? reasons : ['nothing-confirmed'] }
  }

  const strongNonConv = evald.some((e) => e.confirmed && !e.isConv)
  const confirmedCount = evald.filter((e) => e.confirmed).length
  const level = strongNonConv || confirmedCount >= 2 ? 'FULL' : 'HINT'
  reasons.unshift(`level=${level} (confirmed=${confirmedCount}, strongNonConv=${strongNonConv}, onTopic=${onTopic})`)

  return { level, kept, dropped, reasons }
}

module.exports = { gateRecall, extractConcreteTokens }
