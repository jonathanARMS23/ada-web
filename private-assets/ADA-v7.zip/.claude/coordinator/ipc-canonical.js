'use strict'
/**
 * coordinator/ipc-canonical.js — Sérialisation canonique + HMAC pour le plan de contrôle.
 *
 * Cause racine du bug HMAC historique (ipc-emit.signEvent) : la signature était
 * calculée sur la ligne JSON brute, puis `_sig` était inséré par manipulation de
 * chaîne (`line.slice(0,-2) + ',"_sig":"…"}'`). Le vérificateur devait reconstruire
 * exactement les mêmes octets — impossible à garantir dès qu'un re-`JSON.stringify`
 * réordonnait les clés ou changeait l'échappement.
 *
 * Solution : une représentation CANONIQUE déterministe (clés triées récursivement,
 * `_sig` toujours exclu de la charge signée). Émetteur ET vérificateur appellent
 * `canonicalStringify` → octets identiques garantis, indépendamment de l'ordre
 * d'insertion des clés.
 *
 * Zéro dépendance externe (crypto natif uniquement).
 */

const { createHmac, timingSafeEqual } = require('crypto')

/**
 * Sérialise un objet de façon déterministe :
 *  - clés d'objet triées par ordre lexicographique (récursif)
 *  - la clé `_sig` est toujours retirée de la charge (jamais signée elle-même)
 *  - `undefined` / fonctions ignorés (comme JSON.stringify)
 *  - tableaux : ordre préservé, éléments canonicalisés
 *
 * @param {unknown} value
 * @returns {string}
 */
function canonicalStringify(value) {
  return _canon(value)
}

function _canon(value) {
  if (value === null) return 'null'
  const t = typeof value
  if (t === 'number') return Number.isFinite(value) ? String(value) : 'null'
  if (t === 'boolean') return value ? 'true' : 'false'
  if (t === 'string') return JSON.stringify(value)
  if (t === 'bigint') return JSON.stringify(value.toString())
  if (t === 'undefined' || t === 'function' || t === 'symbol') return undefined

  if (Array.isArray(value)) {
    const items = value.map(v => {
      const s = _canon(v)
      return s === undefined ? 'null' : s
    })
    return '[' + items.join(',') + ']'
  }

  // Objet — clés triées, _sig exclu
  const keys = Object.keys(value).filter(k => k !== '_sig').sort()
  const parts = []
  for (const k of keys) {
    const s = _canon(value[k])
    if (s === undefined) continue   // omettre undefined (parité JSON.stringify)
    parts.push(JSON.stringify(k) + ':' + s)
  }
  return '{' + parts.join(',') + '}'
}

/**
 * Calcule la signature HMAC-SHA256 hex de la charge canonique d'un objet.
 * @param {object} payload  objet à signer (`_sig` est ignoré s'il est présent)
 * @param {string} secret
 * @returns {string} signature hex
 */
function sign(payload, secret) {
  const canon = canonicalStringify(payload)
  return createHmac('sha256', secret).update(canon).digest('hex')
}

/**
 * Vérifie qu'une frame porte une signature `_sig` valide pour `secret`.
 * Compare en temps constant. Retourne false sur signature absente/malformée.
 * @param {object} frame  objet contenant un champ `_sig`
 * @param {string} secret
 * @returns {boolean}
 */
function verify(frame, secret) {
  if (!frame || typeof frame !== 'object') return false
  const provided = frame._sig
  if (typeof provided !== 'string' || provided.length === 0) return false
  const expected = sign(frame, secret)
  // timingSafeEqual exige des Buffers de même longueur
  const a = Buffer.from(provided, 'utf8')
  const b = Buffer.from(expected, 'utf8')
  if (a.length !== b.length) return false
  try { return timingSafeEqual(a, b) } catch { return false }
}

/**
 * Retourne une copie de `payload` augmentée d'un champ `_sig` valide.
 * @param {object} payload
 * @param {string} secret
 * @returns {object}
 */
function attachSignature(payload, secret) {
  return { ...payload, _sig: sign(payload, secret) }
}

module.exports = { canonicalStringify, sign, verify, attachSignature }
