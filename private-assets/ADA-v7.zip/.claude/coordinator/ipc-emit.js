'use strict'
const net  = require('net')
const fs   = require('fs')
const path = require('path')
const os   = require('os')
const { randomUUID } = require('crypto')
const { attachSignature } = require('./ipc-canonical.js')

const IPC_PATH    = process.env.ADA_API_IPC_PATH || '/tmp/ada-api.sock'
const IPC_HOST    = process.env.ADA_API_IPC_HOST || null
const IPC_PORT    = parseInt(process.env.ADA_API_IPC_PORT || '3002', 10)
const IPC_TIMEOUT = parseInt(process.env.ADA_IPC_TIMEOUT  || '500',  10)

const CONFIG_DIR  = process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), '.claude')
const EVENTS_LOG  = process.env.ADA_EVENTS_LOG || path.join(CONFIG_DIR, 'events.ndjson')

// ─── HMAC secret ─────────────────────────────────────────────────────────────
// S2 — fail-CLOSED : si aucun secret n'existe, on en génère un (0600) au lieu de
// tourner sans auth. Ainsi this.secret n'est jamais null → l'auth HMAC du control
// server reste toujours active (avant : secret absent = toutes les méthodes mutatives
// accessibles sans authentification).
function loadIpcSecret() {
  if (process.env.ADA_IPC_HMAC_SECRET) return process.env.ADA_IPC_HMAC_SECRET
  const secretFile = path.join(os.homedir(), '.ada', 'ipc.secret')
  try { return fs.readFileSync(secretFile, 'utf8').trim() } catch {}
  // Auto-génération atomique (wx) — gère la race entre processus concurrents.
  try {
    const secret = require('crypto').randomBytes(32).toString('hex')
    fs.mkdirSync(path.dirname(secretFile), { recursive: true })
    fs.writeFileSync(secretFile, secret, { mode: 0o600, flag: 'wx' })
    return secret
  } catch {
    try { return fs.readFileSync(secretFile, 'utf8').trim() } catch {}
    return null
  }
}

const IPC_SECRET = loadIpcSecret()

/**
 * Signe un objet événement via la sérialisation canonique (ipc-canonical).
 * Retourne la ligne NDJSON (terminée par \n) prête à être émise / journalisée.
 *
 * Correctif racine du bug HMAC : la signature est calculée sur la représentation
 * canonique (clés triées, _sig exclu), pas sur la ligne brute. Émetteur et
 * vérificateur produisent donc les mêmes octets, peu importe l'ordre des clés.
 *
 * Si aucun secret n'est disponible, émet l'objet non signé.
 * @param {object} evt
 * @returns {string} ligne NDJSON signée (\n inclus)
 */
function signEvent(evt) {
  const out = IPC_SECRET ? attachSignature(evt, IPC_SECRET) : evt
  return JSON.stringify(out) + '\n'
}

// ─── Log ─────────────────────────────────────────────────────────────────────
function appendEventLog(line) {
  try {
    fs.mkdirSync(path.dirname(EVENTS_LOG), { recursive: true })
    fs.appendFileSync(EVENTS_LOG, line, { encoding: 'utf8' })
  } catch {}
}

// ─── Emit ─────────────────────────────────────────────────────────────────────
function emitIPC(type, payload) {
  const line = signEvent({ id: randomUUID(), ts: Date.now(), type, payload })
  appendEventLog(line)
  try {
    const socket = IPC_HOST
      ? net.createConnection({ host: IPC_HOST, port: IPC_PORT })
      : net.createConnection({ path: IPC_PATH })
    socket.setTimeout(IPC_TIMEOUT)
    socket.on('connect', () => { socket.write(line, () => { socket.destroy() }) })
    socket.on('timeout', () => { socket.destroy() })
    socket.on('error',   () => { socket.destroy() })
  } catch {}
}

module.exports = { emitIPC, signEvent, loadIpcSecret }
