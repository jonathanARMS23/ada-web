#!/usr/bin/env node
/**
 * coordinator/learn.js — Post-run cost learning sync
 *
 * Scanne les runs complétés et met à jour router-state.json avec les données
 * de coût (tokens par phase) manquantes. Idempotent : safe à rejouer.
 *
 * Commandes :
 *   node learn.js sync [<runId>]   Sync tokens depuis un run ou tous les runs
 *   node learn.js stats            Dashboard efficiency par agent
 *   node learn.js tune             Afficher les recommandations de tuning COST_LAMBDA
 *   node learn.js reset-costs      Effacer les stats de coût (garde succès/échecs)
 *
 * Typiquement appelé via hook post-run :
 *   node run.js done ... && node learn.js sync <runId>
 */

const { readFileSync, existsSync, readdirSync } = require('fs')
const { join } = require('path')

const CONFIG_DIR = process.env.CLAUDE_CONFIG_DIR || join(process.env.HOME ?? '', '.claude')
const COORD_DIR  = join(CONFIG_DIR, 'coordinator')
const RUNS_DIR   = join(CONFIG_DIR, 'runs')

const {
  loadState, saveState,
  updateTokenMean, computeEfficiencySample,
  TOKEN_BASELINE, COST_LAMBDA, MIN_COST_SAMPLES,
} = (() => {
  try { return require('./router.js') }
  catch { console.error('router.js introuvable'); process.exit(1) }
})()

const priorKey = (phase, agent) => `${phase}:${agent}`

const C = {
  reset: '\x1b[0m', bold: '\x1b[1m',
  green: '\x1b[32m', red: '\x1b[31m', yellow: '\x1b[33m',
  cyan: '\x1b[36m', gray: '\x1b[90m', blue: '\x1b[34m', magenta: '\x1b[35m'
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function safeReadJson(p) {
  try { return JSON.parse(readFileSync(p, 'utf8')) } catch { return null }
}

function listRunIds() {
  if (!existsSync(RUNS_DIR)) return []
  return readdirSync(RUNS_DIR, { withFileTypes: true })
    .filter(e => e.isDirectory())
    .map(e => e.name)
}

// ── Core : sync tokens depuis un run vers router-state ────────────────────────

/**
 * Lit les phases d'un run et met à jour les meanTokens dans router-state.
 * IMPORTANT : utiliser en mode exclusif avec --tokens dans run.js done.
 * Si run.js done est appelé avec --tokens, ne pas appeler sync sur ce même run —
 * les deux chemins appellent updateTokenMean, ce qui doublerait tokenSamples.
 * Usage recommandé : sync uniquement pour rétro-alimenter des runs anciens sans tokens.
 * @param {string} runId
 * @returns {{ updated: number, skipped: number }}
 */
function syncRun(runId) {
  const statePath = join(RUNS_DIR, runId, 'state.json')
  if (!existsSync(statePath)) return { updated: 0, skipped: 0 }

  const runState = safeReadJson(statePath)
  if (!runState?.phases) return { updated: 0, skipped: 0 }

  const routerState = loadState()
  let updated = 0, skipped = 0

  for (const [phaseId, phase] of Object.entries(runState.phases)) {
    if (!phase.agent || !['completed', 'failed'].includes(phase.status)) { skipped++; continue }
    if (typeof phase.tokens !== 'number' || phase.tokens <= 0) { skipped++; continue }

    const key   = priorKey(phaseId, phase.agent)
    const prior = routerState.priors[key]
    if (!prior) { skipped++; continue } // phase pas encore dans les priors → seed d'abord

    updateTokenMean(prior, phase.tokens)
    routerState.priors[key] = prior
    updated++
  }

  if (updated > 0) saveState(routerState)
  return { updated, skipped }
}

function cmdSync(args) {
  const targetRun = args[0]

  if (targetRun) {
    const { updated, skipped } = syncRun(targetRun)
    if (updated > 0) {
      console.log(`${C.green}✓${C.reset} ${targetRun} → ${updated} phases coût syncées (${skipped} sans données)`)
    } else {
      console.log(`${C.gray}→ ${targetRun} : aucune donnée de tokens (run en cours ou tokens non fournis)${C.reset}`)
    }
    return
  }

  // Sync tous les runs
  const runs  = listRunIds()
  let totalUpdated = 0, totalSkipped = 0, runsSynced = 0

  for (const runId of runs) {
    const { updated, skipped } = syncRun(runId)
    if (updated > 0) runsSynced++
    totalUpdated += updated
    totalSkipped += skipped
  }

  console.log(`${C.green}✓${C.reset} Sync complet — ${runs.length} runs, ${runsSynced} avec tokens, ${totalUpdated} phases mises à jour`)
}

// ── Stats : dashboard d'efficience ───────────────────────────────────────────

function cmdStats() {
  const state = loadState()
  const keys  = Object.keys(state.priors).sort()

  if (!keys.length) {
    console.log('Aucun prior. Lancer : node router.js seed')
    return
  }

  // Grouper par phase
  const byPhase = {}
  for (const key of keys) {
    const parts = key.split(':')
    const phase = key.startsWith('task:') ? parts.slice(0, 2).join(':') : parts[0]
    const agent = key.startsWith('task:') ? parts[2] : parts[1]
    if (!agent) continue
    ;(byPhase[phase] = byPhase[phase] || {})[agent] = state.priors[key]
  }

  // Uniquement phases multi-agents ou avec données de coût
  const interestingPhases = Object.entries(byPhase)
    .filter(([, agents]) => {
      const vals = Object.values(agents)
      return vals.length > 1 || vals.some(p => (p.tokenSamples || 0) >= MIN_COST_SAMPLES)
    })

  console.log(`\n${C.bold}ADA Learn — Efficiency Dashboard${C.reset}`)
  console.log(`λ=${COST_LAMBDA}  baseline=${TOKEN_BASELINE}tk  min_samples=${MIN_COST_SAMPLES}\n`)

  if (!interestingPhases.length) {
    console.log(`${C.gray}Aucune phase avec données de coût suffisantes (min ${MIN_COST_SAMPLES} samples).`)
    console.log(`Les agents doivent passer --tokens lors des appels à run.js done/fail.${C.reset}`)
    return
  }

  for (const [phase, agents] of interestingPhases) {
    console.log(`${C.bold}${phase}${C.reset}`)
    const rows = Object.entries(agents).map(([agent, prior]) => {
      const total    = prior.successes + prior.failures
      const winRate  = total > 0 ? prior.successes / total : 0
      const hasCost  = (prior.tokenSamples || 0) >= MIN_COST_SAMPLES
      const theta    = prior.alpha / (prior.alpha + prior.beta)
      const effScore = hasCost ? computeEfficiencySample(prior, theta) : null
      return { agent, prior, total, winRate, hasCost, effScore }
    }).sort((a, b) => (b.effScore ?? b.winRate) - (a.effScore ?? a.winRate))

    for (const row of rows) {
      const { agent, prior, total, winRate, hasCost, effScore } = row
      const winStr  = `${Math.round(winRate * 100)}%`.padEnd(4)
      const costStr = hasCost
        ? `  ${C.cyan}~${Math.round(prior.meanTokens)}tk (n=${prior.tokenSamples})${C.reset}`
        : `  ${C.gray}coût inconnu${C.reset}`
      const effStr  = effScore != null
        ? `  ${C.magenta}eff=${effScore.toFixed(3)}${C.reset}`
        : ''
      const tag = rows[0].agent === agent && hasCost ? ` ${C.green}← optimal${C.reset}` : ''
      console.log(`  ${agent.padEnd(18)} win=${winStr} n=${String(total).padEnd(3)}${costStr}${effStr}${tag}`)
    }
    console.log('')
  }
}

// ── Tune : recommandations COST_LAMBDA ───────────────────────────────────────

function cmdTune() {
  const state = loadState()
  const priors = Object.values(state.priors).filter(p => (p.tokenSamples || 0) >= MIN_COST_SAMPLES)

  if (priors.length === 0) {
    console.log(`${C.yellow}Pas encore assez de données de coût pour recommander un tuning.${C.reset}`)
    return
  }

  const tokens = priors.map(p => p.meanTokens || 0)
  const min = Math.min(...tokens)
  const max = Math.max(...tokens)
  const ratio = max / Math.max(min, 1)

  console.log(`\n${C.bold}Tuning COST_LAMBDA${C.reset}`)
  console.log(`Plage observée : ${Math.round(min)}–${Math.round(max)} tokens (ratio ×${ratio.toFixed(1)})`)
  console.log(`λ actuel       : ${COST_LAMBDA}`)
  console.log('')

  if (ratio < 2) {
    console.log(`${C.green}→ Agents homogènes en coût — λ peut baisser (0.10–0.15) pour laisser plus de place à la qualité.${C.reset}`)
  } else if (ratio < 5) {
    console.log(`${C.cyan}→ Dispersion modérée — λ=0.25 (actuel) est adapté.${C.reset}`)
  } else {
    console.log(`${C.yellow}→ Fort écart de coût (×${ratio.toFixed(1)}) — envisager λ=0.35–0.40 pour mieux différencier.${C.reset}`)
    console.log(`  Modifier COST_LAMBDA dans router.js ligne ~170.`)
  }
}

// ── Reset costs ───────────────────────────────────────────────────────────────

function cmdResetCosts() {
  const state  = loadState()
  let cleared  = 0

  for (const key of Object.keys(state.priors)) {
    const p = state.priors[key]
    if (p.meanTokens !== undefined || p.tokenSamples !== undefined) {
      delete p.meanTokens
      delete p.tokenSamples
      cleared++
    }
  }

  saveState(state)
  console.log(`${C.green}✓${C.reset} Stats de coût effacées sur ${cleared} priors (succès/échecs conservés)`)
}

// ── CLI dispatch ──────────────────────────────────────────────────────────────

const [,, cmd, ...args] = process.argv

switch (cmd) {
  case 'sync':        cmdSync(args);       break
  case 'stats':       cmdStats();          break
  case 'tune':        cmdTune();           break
  case 'reset-costs': cmdResetCosts();     break
  default:
    console.log(`\n${C.bold}coordinator/learn.js — Cost-efficiency learning${C.reset}\n`)
    console.log('  sync [<runId>]   Sync tokens depuis un ou tous les runs → router-state')
    console.log('  stats            Dashboard efficiency par agent')
    console.log('  tune             Recommandations de tuning COST_LAMBDA')
    console.log('  reset-costs      Effacer les stats de coût (garde succès/échecs)')
    console.log('')
    console.log(`Config : λ=${COST_LAMBDA}  baseline=${TOKEN_BASELINE}tk  min_samples=${MIN_COST_SAMPLES}`)
    console.log('')
}
