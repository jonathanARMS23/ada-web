#!/usr/bin/env node
'use strict'
/**
 * coordinator/logger.js — Logger structuré ADA
 *
 * Écrit en JSONL dans .claude/logs/ada-errors.log.
 * Niveaux warn/error → stderr immédiat pour visibilité.
 * Aucune dépendance interne pour éviter les cycles.
 *
 * Usage :
 *   const log = require('./logger')
 *   log.warn('acw', 'context injection failed', { phaseId, error: e?.message })
 *   log.error('budget', 'cost record failed', { runId, amount })
 */

const { appendFileSync, mkdirSync, existsSync } = require('fs')
const { join } = require('path')
const os = require('os')

const CONFIG_DIR = process.env.CLAUDE_CONFIG_DIR || join(process.env.HOME || os.homedir(), '.claude')
const LOG_DIR    = join(CONFIG_DIR, 'logs')
const LOG_FILE   = join(LOG_DIR, 'ada-errors.log')

// Garde en mémoire les entrées récentes pour éviter le spam (même message × 5 → 1 log)
const _seen = new Map()
const DEDUP_TTL_MS = 10_000

function shouldDedup(key) {
  const now = Date.now()
  const last = _seen.get(key)
  if (last && now - last < DEDUP_TTL_MS) return true
  _seen.set(key, now)
  if (_seen.size > 200) {
    // Purge des entrées expirées
    for (const [k, t] of _seen) { if (now - t > DEDUP_TTL_MS) _seen.delete(k) }
  }
  return false
}

function write(level, module, message, data) {
  const dedupKey = `${level}:${module}:${message}`
  if (level === 'debug' || shouldDedup(dedupKey)) return

  const entry = JSON.stringify({
    ts: new Date().toISOString(),
    level,
    module,
    message,
    ...(data && typeof data === 'object' && Object.keys(data).length ? { data } : {}),
  }) + '\n'

  // Stderr immédiat pour warn + error (visible dans les hooks et le terminal)
  if (level === 'warn' || level === 'error') {
    process.stderr.write(`[ada:${level}] ${module}: ${message}${data?.error ? ` — ${data.error}` : ''}\n`)
  }

  // Fichier structuré
  try {
    if (!existsSync(LOG_DIR)) mkdirSync(LOG_DIR, { recursive: true })
    appendFileSync(LOG_FILE, entry, 'utf8')
  } catch {
    // Silence absolu ici — le logger ne doit jamais crasher l'appelant
  }
}

module.exports = {
  debug: (module, message, data) => write('debug', module, message, data),
  info:  (module, message, data) => write('info',  module, message, data),
  warn:  (module, message, data) => write('warn',  module, message, data),
  error: (module, message, data) => write('error', module, message, data),
  LOG_FILE,
}
