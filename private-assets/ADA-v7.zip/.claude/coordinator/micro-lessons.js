#!/usr/bin/env node
/**
 * coordinator/micro-lessons.js — Mémoire ultra-compacte par phase
 *
 * Extrait 1 phrase "leçon" par phase réussie/échouée et l'injecte dans les
 * prompts suivants. Coût ~50 tokens vs 2000 pour une trajectoire complète.
 *
 * Stockage : coordinator/lessons.json — array max 500 items, éviction LRU.
 *
 * API :
 *   store(phase, agent, verdict, summary, runId)
 *   retrieve(phaseType, opts)
 *   inject(phaseType)
 *   promote(id)
 *   demote(id)
 *   stats()
 *
 * CLI :
 *   node micro-lessons.js store <phase> <agent> <verdict> "<summary>"
 *   node micro-lessons.js retrieve <phase>
 *   node micro-lessons.js inject <phase>
 *   node micro-lessons.js stats
 */

const { readFileSync, writeFileSync, existsSync, mkdirSync } = require('fs')
const { join, dirname } = require('path')
const { neverWorse } = require('./never-worse.js')

const CONFIG_DIR  = process.env.CLAUDE_CONFIG_DIR || join(process.env.HOME ?? '', '.claude')
const COORD_DIR   = join(CONFIG_DIR, 'coordinator')
const LESSONS_FILE = join(COORD_DIR, 'lessons.json')

const MAX_LESSONS = 500

// ── Cache in-memory (évite les relectures disque à chaque phase du même run) ──

let _lessonsCache = null
let _lessonsMtime = 0

// ── Utilitaires fichier ───────────────────────────────────────────────────────

function ensureDir(p) {
  if (!existsSync(p)) mkdirSync(p, { recursive: true })
}

function safeReadLessons() {
  try {
    if (!existsSync(LESSONS_FILE)) return []
    const mtime = require('fs').statSync(LESSONS_FILE).mtimeMs
    if (_lessonsCache !== null && mtime === _lessonsMtime) return _lessonsCache
    const raw = readFileSync(LESSONS_FILE, 'utf8').trim()
    if (!raw) return []
    const data = JSON.parse(raw)
    _lessonsCache = Array.isArray(data) ? data : []
    _lessonsMtime = mtime
    return _lessonsCache
  } catch {
    return []
  }
}

function saveLessons(lessons) {
  ensureDir(dirname(LESSONS_FILE))
  const tmp = LESSONS_FILE + '.tmp'
  writeFileSync(tmp, JSON.stringify(lessons, null, 2), 'utf8')
  require('fs').renameSync(tmp, LESSONS_FILE)
  _lessonsCache = lessons
  try { _lessonsMtime = require('fs').statSync(LESSONS_FILE).mtimeMs } catch {}
}

// ── Extraction de leçon ───────────────────────────────────────────────────────

/**
 * Extrait la phrase la plus informative d'un summary.
 * @param {string} summary
 * @returns {string|null}
 */
function extractLesson(summary) {
  if (!summary || summary.length < 10) return null

  // Split en phrases (. ! ? \n)
  const sentences = summary
    .split(/[.!?\n]+/)
    .map(s => s.trim())
    .filter(s => s.length > 15 && s.length < 150)

  // Filtrer uniquement les phrases vides de contenu technique (sans mot substantiel après)
  const GENERIC = /^(done|completed|ok|success|la tâche|the task|phase|voici|here is|note that)\.?\s*$/i
  const meaningful = sentences.filter(s => !GENERIC.test(s))

  // Prendre la plus informative (la plus longue parmi les 3 premières significatives)
  const candidates = meaningful.slice(0, 3)
  if (!candidates.length) return null

  return candidates.reduce((a, b) => a.length > b.length ? a : b)
}

// ── API publique ──────────────────────────────────────────────────────────────

/**
 * Stocke une leçon extraite du summary si pertinente.
 * @param {string} phase
 * @param {string} agent
 * @param {'success'|'failure'} verdict
 * @param {string} summary
 * @param {string|null} runId
 */
function store(phase, agent, verdict, summary, runId = null) {
  const lesson = extractLesson(summary)
  if (!lesson) return

  const lessons = safeReadLessons()

  const entry = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    phase,
    agent,
    verdict,
    lesson,
    ts: new Date().toISOString(),
    usages: 0,
    score: verdict === 'success' ? 0.6 : 0.4,
    runId: runId || null,
  }

  lessons.push(entry)

  // Éviction LRU si dépassement de MAX_LESSONS
  // Trier par score desc + ts asc (les moins utilisés et les plus anciens d'abord)
  if (lessons.length > MAX_LESSONS) {
    lessons.sort((a, b) => {
      const scoreDiff = (a.score ?? 0) - (b.score ?? 0)
      if (Math.abs(scoreDiff) > 0.05) return scoreDiff  // moins bon score → évincé en premier
      return new Date(a.ts).getTime() - new Date(b.ts).getTime()  // plus ancien → évincé en premier
    })
    lessons.splice(0, lessons.length - MAX_LESSONS)
  }

  saveLessons(lessons)
}

/**
 * Récupère les leçons pertinentes pour une phase.
 * @param {string} phaseType
 * @param {{ limit?: number, minScore?: number }} opts
 * @returns {Array<object>}
 */
function retrieve(phaseType, opts = {}) {
  const { limit = 3, minScore = 0 } = opts
  const lessons = safeReadLessons()

  const filtered = lessons.filter(l => {
    if (l.score < minScore) return false
    // Filtre par phase : exact ou contains
    return l.phase === phaseType || l.phase.includes(phaseType) || phaseType.includes(l.phase)
  })

  // Trier par score desc, puis recency desc (plus récent en premier à score égal)
  filtered.sort((a, b) => {
    const scoreDiff = (b.score ?? 0) - (a.score ?? 0)
    if (Math.abs(scoreDiff) > 0.05) return scoreDiff
    return new Date(b.ts).getTime() - new Date(a.ts).getTime()
  })

  return filtered.slice(0, limit)
}

/**
 * Retourne une string prête pour injection dans un prompt.
 *
 * Garde « jamais pire » (never-worse.js) : le formatage (en-tête `Lessons[phase]:`
 * + puces) ne doit jamais coûter plus de tokens estimés que le simple concat des
 * leçons brutes — sinon un bug de formatage bloatait silencieusement CHAQUE prompt
 * de phase (inject() est appelé à chaque dispatch d'agent). Fallback : les leçons
 * brutes, sans habillage.
 *
 * @param {string} phaseType
 * @returns {string}
 */
function inject(phaseType) {
  const lessons = retrieve(phaseType, { limit: 2, minScore: 0.4 })
  if (!lessons.length) return ''

  const lines = lessons.map(l => `- ${l.lesson.slice(0, 120)}`).join('\n')
  const transformed = `Lessons[${phaseType}]:\n${lines}`
  const raw = lessons.map(l => l.lesson).join('\n')
  return neverWorse(raw, transformed)
}

/**
 * Augmente le score d'une leçon (feedback positif).
 * @param {string} id
 */
function promote(id) {
  const lessons = safeReadLessons()
  const entry = lessons.find(l => l.id === id)
  if (!entry) return
  entry.score = Math.min(1.0, (entry.score ?? 0) + 0.2)
  entry.usages = (entry.usages ?? 0) + 1
  saveLessons(lessons)
}

/**
 * Diminue le score d'une leçon (feedback négatif).
 * @param {string} id
 */
function demote(id) {
  const lessons = safeReadLessons()
  const entry = lessons.find(l => l.id === id)
  if (!entry) return
  entry.score = Math.max(0, (entry.score ?? 0) - 0.2)
  saveLessons(lessons)
}

/**
 * Statistiques globales.
 * @returns {{ total: number, byPhase: Record<string, number> }}
 */
function stats() {
  const lessons = safeReadLessons()
  const byPhase = {}
  for (const l of lessons) {
    byPhase[l.phase] = (byPhase[l.phase] ?? 0) + 1
  }
  return { total: lessons.length, byPhase }
}

module.exports = { store, retrieve, inject, promote, demote, stats, extractLesson }

// ── CLI ───────────────────────────────────────────────────────────────────────

if (require.main === module) {
  const [,, cmd, ...rest] = process.argv

  switch (cmd) {
    case 'store': {
      const [phase, agent, verdict, ...summaryParts] = rest
      const summary = summaryParts.join(' ')
      if (!phase || !agent || !verdict) {
        console.error('Usage: micro-lessons.js store <phase> <agent> <verdict> "<summary>"')
        process.exit(1)
      }
      store(phase, agent, verdict, summary)
      const lesson = extractLesson(summary)
      if (lesson) {
        console.log(`✓ Leçon stockée pour '${phase}': ${lesson.slice(0, 80)}...`)
      } else {
        console.log(`⚠  Aucune leçon extractible du summary fourni`)
      }
      break
    }

    case 'retrieve': {
      const [phaseType, limitStr] = rest
      if (!phaseType) {
        console.error('Usage: micro-lessons.js retrieve <phase> [limit]')
        process.exit(1)
      }
      const limit = limitStr ? parseInt(limitStr, 10) : 3
      const results = retrieve(phaseType, { limit })
      if (!results.length) {
        console.log(`Aucune leçon pour '${phaseType}'`)
      } else {
        console.log(`\nLeçons pour '${phaseType}' (${results.length}) :\n`)
        for (const l of results) {
          console.log(`  [${l.verdict}] [score:${l.score.toFixed(2)}] ${l.lesson}`)
          console.log(`    ${l.agent} · ${l.ts.slice(0, 10)} · id:${l.id}`)
          console.log('')
        }
      }
      break
    }

    case 'inject': {
      const [phaseType] = rest
      if (!phaseType) {
        console.error('Usage: micro-lessons.js inject <phase>')
        process.exit(1)
      }
      const hint = inject(phaseType)
      if (hint) {
        console.log(hint)
      } else {
        console.log(`(aucune leçon disponible pour '${phaseType}')`)
      }
      break
    }

    case 'stats': {
      const s = stats()
      console.log(`\nMicro-lessons stats :`)
      console.log(`  Total : ${s.total} / ${MAX_LESSONS}`)
      if (Object.keys(s.byPhase).length) {
        console.log(`\n  Par phase :`)
        for (const [phase, count] of Object.entries(s.byPhase).sort((a, b) => b[1] - a[1])) {
          console.log(`    ${phase}: ${count}`)
        }
      }
      console.log('')
      break
    }

    case 'promote': {
      const [id] = rest
      if (!id) { console.error('Usage: micro-lessons.js promote <id>'); process.exit(1) }
      promote(id)
      console.log(`✓ Score augmenté pour ${id}`)
      break
    }

    case 'demote': {
      const [id] = rest
      if (!id) { console.error('Usage: micro-lessons.js demote <id>'); process.exit(1) }
      demote(id)
      console.log(`✓ Score diminué pour ${id}`)
      break
    }

    default:
      console.log('\nmicro-lessons.js — Mémoire ultra-compacte par phase\n')
      console.log('  store    <phase> <agent> <verdict> "<summary>"   Extrait et stocke une leçon')
      console.log('  retrieve <phase> [limit]                         Récupère les leçons pertinentes')
      console.log('  inject   <phase>                                  String prête pour prompt')
      console.log('  stats                                             Statistiques globales')
      console.log('  promote  <id>                                     Score += 0.2 (max 1.0)')
      console.log('  demote   <id>                                     Score -= 0.2 (min 0)')
      console.log('')
  }
}
