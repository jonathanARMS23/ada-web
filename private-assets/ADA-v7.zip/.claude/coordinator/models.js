#!/usr/bin/env node
'use strict'
/**
 * coordinator/models.js — Source unique des IDs de modèles Claude et de leur pricing.
 * Tous les autres fichiers du repo doivent importer TIER_MODELS/PRICING d'ici au
 * lieu de dupliquer ces valeurs (cause de la dérive détectée en review : 7 fichiers
 * avec des copies divergentes de la même table).
 */

/** @type {Record<number, string>} */
const TIER_MODELS = {
  1: 'claude-haiku-4-5-20251001',
  2: 'claude-sonnet-5',
  3: 'claude-opus-4-8',
}

/** Tarifs USD par million de tokens. Clés multiples par modèle (ID daté + alias
 * court + ancien ID encore actif) pour que la résolution par préfixe fonctionne
 * quel que soit le format reçu depuis les transcripts Claude Code. */
const PRICING = {
  'claude-haiku-4-5-20251001': { input: 1.00, output: 5.00, cacheWrite: 1.25, cacheRead: 0.10 },
  'claude-haiku-4-5':          { input: 1.00, output: 5.00, cacheWrite: 1.25, cacheRead: 0.10 },
  'claude-sonnet-5':           { input: 3.00, output: 15.00, cacheWrite: 3.75, cacheRead: 0.30 },
  'claude-sonnet-4-6':         { input: 3.00, output: 15.00, cacheWrite: 3.75, cacheRead: 0.30 },
  'claude-opus-4-8':           { input: 5.00, output: 25.00, cacheWrite: 6.25, cacheRead: 0.50 },
}

/** @param {number} tier @returns {string} */
function modelForTier(tier) {
  return TIER_MODELS[tier] || TIER_MODELS[2]
}

/**
 * Normalise un modelId (potentiellement daté) vers une clé PRICING connue.
 * @param {string} modelId
 * @returns {string}
 */
function resolveModel(modelId) {
  if (!modelId) return TIER_MODELS[2]
  for (const key of Object.keys(PRICING)) {
    if (modelId.startsWith(key)) return key
  }
  return TIER_MODELS[2]
}

module.exports = { TIER_MODELS, PRICING, modelForTier, resolveModel }
