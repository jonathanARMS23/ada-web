#!/usr/bin/env node
'use strict'
/**
 * coordinator/moe-router.js — Mixture of Experts routing
 * 4 experts : Quality, Cost, Speed, Context
 * Agrège les scores pondérés pour enrichir la décision Thompson Sampling.
 *
 * Principe :
 *  - Chaque expert donne un score ∈ [0, 1]
 *  - Agrégation pondérée → score MoE
 *  - Blend avec Thompson : alpha dépend du nombre de données (confiance)
 *  - MoE ne remplace pas Thompson — il l'affine quand la confiance est basse
 */

// ── Expert 1 — Quality Expert ─────────────────────────────────────────────────
// Basé sur le success rate historique (fréquentiste simple)
// Retourne 0.5 si aucune donnée (prior neutre)

/**
 * @param {{ successes: number, failures: number }} prior
 * @returns {number} score ∈ [0, 1]
 */
function qualityExpert(prior) {
  const n = (prior.successes || 0) + (prior.failures || 0)
  if (n === 0) return 0.5 // no data → neutre
  return prior.successes / n
}

// ── Expert 2 — Cost Expert ────────────────────────────────────────────────────
// Inverse du coût normalisé : agent économe → score élevé
// Log-linéaire pour éviter de sur-pénaliser les agents légèrement plus coûteux

/**
 * @param {{ meanTokens?: number, tokenSamples?: number }} prior
 * @param {number} [baseline=2000]
 * @returns {number} score ∈ [0, 1]
 */
function costExpert(prior, baseline = 2000) {
  if (!prior.meanTokens || (prior.tokenSamples || 0) < 2) return 0.5
  return Math.max(0, 1 - Math.log1p(prior.meanTokens / baseline) / Math.log1p(10))
}

// ── Expert 3 — Speed Expert ───────────────────────────────────────────────────
// Basé sur duration_ms si disponible
// 30s = score neutre, 90s = score 0

/**
 * @param {{ meanDurationMs?: number }} prior
 * @returns {number} score ∈ [0, 1]
 */
function speedExpert(prior) {
  if (!prior.meanDurationMs) return 0.5
  const baseline = 30000 // 30s = score neutre
  return Math.max(0, 1 - prior.meanDurationMs / (baseline * 3))
}

// ── Expert 4 — Context Expert ─────────────────────────────────────────────────
// Bonus si l'agent correspond au contexte projet déclaré
// Ex: projet NestJS → contextHint='nestjs' → bonus pour nestjs

/**
 * @param {string} agent
 * @param {string|null} contextHint
 * @returns {number} score ∈ [0, 1]
 */
function contextExpert(agent, contextHint) {
  if (!contextHint) return 0.5
  return agent === contextHint ? 0.8 : 0.3
}

// ── Agrégation ────────────────────────────────────────────────────────────────

/** @type {{ quality: number, cost: number, speed: number, context: number }} */
const WEIGHTS = { quality: 0.45, cost: 0.30, speed: 0.10, context: 0.15 }

/**
 * Score MoE agrégé pour un (agent, prior, contextHint).
 * @param {string} agent
 * @param {{ successes?: number, failures?: number, meanTokens?: number, tokenSamples?: number, meanDurationMs?: number }} prior
 * @param {string|null} [contextHint]
 * @returns {number} score ∈ [0, 1]
 */
function moeScore(agent, prior, contextHint = null) {
  const q = qualityExpert(prior)
  const c = costExpert(prior)
  const s = speedExpert(prior)
  const x = contextExpert(agent, contextHint)

  return (
    WEIGHTS.quality  * q +
    WEIGHTS.cost     * c +
    WEIGHTS.speed    * s +
    WEIGHTS.context  * x
  )
}

// ── moeRecommend ──────────────────────────────────────────────────────────────

/**
 * Enrichit une liste de candidats Thompson avec le score MoE.
 * Le blend dépend de la confiance Thompson :
 *  - n > 10 (haute confiance) : Thompson 80% + MoE 20%
 *  - n > 3  (confiance moyenne) : Thompson 60% + MoE 40%
 *  - n ≤ 3  (faible confiance) : Thompson 40% + MoE 60%
 *
 * @param {string} phaseType
 * @param {Array<{ agent: string, prior: object, thompsonSample: number }>} candidates
 * @param {string|null} [contextHint]
 * @returns {{ best: string, scores: Array<{ agent: string, moe: number, blended: number }> }|null}
 */
function moeRecommend(phaseType, candidates, contextHint = null) {
  if (!candidates || !candidates.length) return null

  const scored = candidates.map(({ agent, prior, thompsonSample }) => {
    const moe = moeScore(agent, prior || {}, contextHint)
    const n   = (prior.successes || 0) + (prior.failures || 0)
    // Alpha = poids Thompson dans le blend
    const alpha   = n > 10 ? 0.8 : n > 3 ? 0.6 : 0.4
    const blended = alpha * (thompsonSample || 0) + (1 - alpha) * moe
    return { agent, moe, blended }
  })

  // Tri décroissant par score blendé
  scored.sort((a, b) => b.blended - a.blended)

  return { best: scored[0].agent, scores: scored }
}

// ── Exports ───────────────────────────────────────────────────────────────────

module.exports = {
  moeScore,
  moeRecommend,
  qualityExpert,
  costExpert,
  speedExpert,
  contextExpert,
  WEIGHTS,
}
