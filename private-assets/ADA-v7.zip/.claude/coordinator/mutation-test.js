#!/usr/bin/env node
'use strict'
/**
 * coordinator/mutation-test.js — Mutation testing du scorer bench-v2.
 *
 * POURQUOI (ADR-021, finding F6) : les fixtures de calibration « écrites à la
 * main » ne suffisent pas à valider un scorer. Les 5 bugs de scorer trouvés lors
 * de la session 2026-08-04/06 étaient TOUS des faux négatifs sur de la VARIATION
 * LÉGITIME IMPRÉVUE (colonne NOT NULL en plus, trigger supplémentaire, FK
 * composite, qualification de schéma, contrainte double-entrée) — jamais des
 * violations d'exigence. On ne peut pas énumérer à la main la variation qu'on
 * n'a pas imaginée : on la GÉNÈRE.
 *
 * PRINCIPE : partir d'un livrable connu-bon (score 100/100), lui appliquer une
 * mutation SÉMANTIQUEMENT NEUTRE au regard des exigences de la tâche, re-scorer
 * avec le VRAI scorer (application Postgres réelle + assertions), et exiger que
 * le score reste STRICTEMENT ÉGAL. Toute chute de score est un faux négatif du
 * scorer — un bug de l'instrument de mesure, pas du livrable.
 *
 * Une mutation qui fait chuter le score = le scorer sur-contraint : il note un
 * détail d'implémentation que l'énoncé n'exige pas.
 *
 * ARCHITECTURE (même séparation que bench-v2.js) :
 *   - Couche PURE   : lexer SQL, repérage des tables, les 9 mutations. Zéro IO,
 *                     testable sans Postgres (tests/coordinator/mutation-test.test.js).
 *   - Couche IMPURE : exécution du scorer réel (bench-v2.scoreSqlDeliverable),
 *                     qui a besoin de psql. `bench-v2.js` est requis PARESSEUSEMENT
 *                     pour que les tests unitaires purs restent verts même si
 *                     bench-v2.js est momentanément cassé.
 *
 * CLI :
 *   node mutation-test.js list
 *   node mutation-test.js run <deliverableFile> [--task <id>] [--mutations m1,m2] [--json]
 *   node mutation-test.js run-all [--arms NATIVE,PIPELINE] [--mutations ...] [--json]
 */

const { readFileSync, existsSync } = require('fs')
const { join } = require('path')

const COORD_DIR = __dirname
const CLAUDE_DIR = join(COORD_DIR, '..')
const TASKS_FILE = join(CLAUDE_DIR, 'benchmarks', 'v2', 'tasks-v2.json')

const C = { reset: '\x1b[0m', bold: '\x1b[1m', green: '\x1b[32m', red: '\x1b[31m', yellow: '\x1b[33m', cyan: '\x1b[36m', gray: '\x1b[90m' }

// Préfixe de tout identifiant introduit par une mutation : garantit qu'on ne
// collisionne jamais avec un identifiant du livrable.
const MUT = 'zmut'

// ─────────────────────────────────────────────────────────────────────────────
// COUCHE PURE — lexer SQL
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Découpe un script SQL en instructions de premier niveau. PURE.
 *
 * Respecte les chaînes `'…'` (avec échappement `''`), les identifiants `"…"`,
 * le dollar-quoting `$$…$$` / `$tag$…$tag$` (indispensable : les corps plpgsql
 * contiennent des `;` qui ne terminent PAS l'instruction), les commentaires
 * ligne `--` et bloc `/* *\/`.
 *
 * Chaque chunk s'étend de la fin de l'instruction précédente jusqu'à son propre
 * `;` inclus : les commentaires d'en-tête restent donc solidaires de
 * l'instruction qu'ils décrivent (ce qui compte pour la mutation de réordonnancement).
 *
 * @param {string} sql
 * @returns {Array<{text:string,start:number,end:number}>}
 */
function splitStatements(sql) {
  const src = String(sql || '')
  const chunks = []
  let i = 0
  let chunkStart = 0
  while (i < src.length) {
    const ch = src[i]
    if (ch === '-' && src[i + 1] === '-') {
      const nl = src.indexOf('\n', i)
      i = nl === -1 ? src.length : nl + 1
      continue
    }
    if (ch === '/' && src[i + 1] === '*') {
      const end = src.indexOf('*/', i + 2)
      i = end === -1 ? src.length : end + 2
      continue
    }
    if (ch === "'" || ch === '"') {
      i = skipQuoted(src, i, ch)
      continue
    }
    if (ch === '$') {
      const tag = dollarTagAt(src, i)
      if (tag) {
        const end = src.indexOf(tag, i + tag.length)
        i = end === -1 ? src.length : end + tag.length
        continue
      }
    }
    if (ch === ';') {
      chunks.push({ text: src.slice(chunkStart, i + 1), start: chunkStart, end: i + 1 })
      i++
      chunkStart = i
      continue
    }
    i++
  }
  const tail = src.slice(chunkStart)
  if (tail.trim()) {
    // Instruction finale sans `;` terminal.
    chunks.push({ text: tail, start: chunkStart, end: src.length })
  } else if (tail && chunks.length) {
    // Blancs/commentaires résiduels : rattachés au dernier chunk pour que la
    // concaténation des chunks reconstruise le SQL À L'IDENTIQUE (invariant dont
    // dépend la mutation de réordonnancement, qui réassemble par chunks).
    const last = chunks[chunks.length - 1]
    last.text += tail
    last.end = src.length
  }
  return chunks
}

/** Avance après une chaîne/identifiant quoté ouvert en `i`. PURE. */
function skipQuoted(src, i, q) {
  i++
  while (i < src.length) {
    if (src[i] === q) {
      if (src[i + 1] === q) { i += 2; continue }  // '' / "" échappé
      return i + 1
    }
    i++
  }
  return i
}

/** Renvoie le tag dollar-quote ouvrant en `i` (`$$`, `$fn$`) ou null. PURE. */
function dollarTagAt(src, i) {
  const m = /^\$([a-zA-Z_][a-zA-Z0-9_]*)?\$/.exec(src.slice(i, i + 64))
  return m ? m[0] : null
}

/**
 * Index de la parenthèse fermante appariée à celle ouverte en `openIdx`. PURE.
 * Ignore parenthèses dans chaînes, identifiants quotés, dollar-quotes, commentaires.
 * @returns {number} index de la `)` appariée, ou -1.
 */
function matchParen(src, openIdx) {
  if (src[openIdx] !== '(') return -1
  let depth = 0
  let i = openIdx
  while (i < src.length) {
    const ch = src[i]
    if (ch === '-' && src[i + 1] === '-') { const nl = src.indexOf('\n', i); i = nl === -1 ? src.length : nl + 1; continue }
    if (ch === '/' && src[i + 1] === '*') { const e = src.indexOf('*/', i + 2); i = e === -1 ? src.length : e + 2; continue }
    if (ch === "'" || ch === '"') { i = skipQuoted(src, i, ch); continue }
    if (ch === '$') { const t = dollarTagAt(src, i); if (t) { const e = src.indexOf(t, i + t.length); i = e === -1 ? src.length : e + t.length; continue } }
    if (ch === '(') depth++
    else if (ch === ')') { depth--; if (depth === 0) return i }
    i++
  }
  return -1
}

/** Retire commentaires et blancs en tête d'un chunk. PURE. */
function stripLeadingNoise(text) {
  let s = String(text || '')
  for (;;) {
    const before = s
    s = s.replace(/^\s+/, '')
    s = s.replace(/^--[^\n]*\n?/, '')
    s = s.replace(/^\/\*[\s\S]*?\*\//, '')
    if (s === before) return s
  }
}

const CREATE_TABLE_RE = /^create\s+(?:unlogged\s+|temp(?:orary)?\s+)?table\s+(?:if\s+not\s+exists\s+)?(?:"?([a-z_][a-z0-9_]*)"?\s*\.\s*)?"?([a-z_][a-z0-9_]*)"?/i

/**
 * Tables créées par le script, dans l'ordre d'apparition. PURE.
 * @returns {Array<{name:string, schema:string|null, chunkIndex:number}>}
 */
function createdTables(sql) {
  const chunks = splitStatements(sql)
  const out = []
  chunks.forEach((c, idx) => {
    const m = CREATE_TABLE_RE.exec(stripLeadingNoise(c.text))
    if (m) out.push({ name: m[2].toLowerCase(), schema: m[1] ? m[1].toLowerCase() : null, chunkIndex: idx })
  })
  return out
}

/** Noms (nus, lowercase, dédoublonnés) des tables créées. PURE. */
function createdTableNames(sql) {
  return [...new Set(createdTables(sql).map(t => t.name))]
}

/**
 * Bornes du corps parenthésé du `CREATE TABLE <name>`. PURE.
 * @returns {{open:number, close:number}|null}
 */
function tableBodyRange(sql, tableName) {
  const src = String(sql || '')
  const name = String(tableName).toLowerCase()
  const re = new RegExp(
    `create\\s+(?:unlogged\\s+|temp(?:orary)?\\s+)?table\\s+(?:if\\s+not\\s+exists\\s+)?(?:"?[a-z_][a-z0-9_]*"?\\s*\\.\\s*)?"?${name}"?\\s*\\(`,
    'i'
  )
  const m = re.exec(src)
  if (!m) return null
  const open = m.index + m[0].length - 1
  const close = matchParen(src, open)
  return close === -1 ? null : { open, close }
}

// ─────────────────────────────────────────────────────────────────────────────
// COUCHE PURE — réécriture des références de table
// ─────────────────────────────────────────────────────────────────────────────

// Mots-clés après lesquels un identifiant est SÛREMENT un nom de table. On ne
// réécrit QUE dans ces contextes : une réécriture globale toucherait aussi les
// noms de colonnes, les littéraux et `information_schema`.
// `on\s+` est sûr : `ON DELETE`/`ON CONFLICT`/`ON UPDATE` ne matchent pas car
// `delete`/`conflict`/`update` ne figurent jamais dans la liste des tables créées.
const TABLE_REF_KEYWORDS = [
  'create\\s+(?:unlogged\\s+|temp(?:orary)?\\s+)?table\\s+(?:if\\s+not\\s+exists\\s+)?',
  'alter\\s+table\\s+(?:if\\s+exists\\s+)?(?:only\\s+)?',
  'drop\\s+table\\s+(?:if\\s+exists\\s+)?',
  'references\\s+',
  'insert\\s+into\\s+',
  'update\\s+(?:only\\s+)?',
  'delete\\s+from\\s+',
  'truncate\\s+(?:table\\s+)?',
  'from\\s+',
  'join\\s+',
  'on\\s+',
].join('|')

/**
 * Découpe un SQL en segments intérieurs/extérieurs aux corps dollar-quotés. PURE.
 * Sert à épargner les corps de fonctions : un livrable durci écrit
 * `SECURITY DEFINER … SET search_path = ''`, et là un nom NON qualifié ne résout
 * plus. Y déqualifier casserait le livrable — ce serait un faux bug de scorer.
 * @returns {Array<{text:string, quoted:boolean}>}
 */
function splitDollarQuoted(sql) {
  const src = String(sql || '')
  const out = []
  let i = 0
  let plainStart = 0
  while (i < src.length) {
    const ch = src[i]
    if (ch === '-' && src[i + 1] === '-') { const nl = src.indexOf('\n', i); i = nl === -1 ? src.length : nl + 1; continue }
    if (ch === '/' && src[i + 1] === '*') { const e = src.indexOf('*/', i + 2); i = e === -1 ? src.length : e + 2; continue }
    if (ch === "'" || ch === '"') { i = skipQuoted(src, i, ch); continue }
    if (ch === '$') {
      const tag = dollarTagAt(src, i)
      if (tag) {
        const end = src.indexOf(tag, i + tag.length)
        const stop = end === -1 ? src.length : end + tag.length
        if (i > plainStart) out.push({ text: src.slice(plainStart, i), quoted: false })
        out.push({ text: src.slice(i, stop), quoted: true })
        i = stop
        plainStart = i
        continue
      }
    }
    i++
  }
  if (plainStart < src.length) out.push({ text: src.slice(plainStart), quoted: false })
  return out
}

/**
 * Réécrit toute référence à l'une des `tableNames` dans un contexte de table. PURE.
 * `fn(bareName, currentSchema, quoted)` renvoie le texte de remplacement complet
 * (schéma + nom), ou null pour ne rien changer.
 * @param {{skipDollarQuoted?:boolean}} [opts] n'applique la réécriture qu'en
 *   dehors des corps de fonctions dollar-quotés.
 */
function rewriteTableRefs(sql, tableNames, fn, opts = {}) {
  const names = (tableNames || []).map(n => String(n).toLowerCase()).filter(Boolean)
  if (!names.length) return String(sql || '')
  const alt = names.map(n => n.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|')
  const re = new RegExp(
    `(${TABLE_REF_KEYWORDS})(?:"?([a-z_][a-z0-9_]*)"?\\s*\\.\\s*)?("?)(${alt})\\3(?![a-z0-9_"])`,
    'gi'
  )
  const rewrite = (segment) => segment.replace(re, (full, kw, schema, quote, name) => {
    const rep = fn(String(name).toLowerCase(), schema ? String(schema).toLowerCase() : null, quote === '"')
    return rep === null || rep === undefined ? full : kw + rep
  })
  if (!opts.skipDollarQuoted) return rewrite(String(sql || ''))
  return splitDollarQuoted(sql).map(s => (s.quoted ? s.text : rewrite(s.text))).join('')
}

/**
 * Tables dans lesquelles le livrable INSÈRE lui-même avec une liste de colonnes
 * EXPLICITE (`INSERT INTO t (a, b) VALUES …`). PURE.
 * Ajouter à une telle table une colonne NOT NULL sans DEFAULT casserait le code
 * du livrable lui-même (son propre trigger d'audit/outbox) : la mutation ne
 * serait pas neutre, et la chute de score ne serait PAS imputable au scorer.
 */
function tablesInsertedWithColumnList(sql) {
  const re = /insert\s+into\s+(?:"?[a-z_][a-z0-9_]*"?\s*\.\s*)?"?([a-z_][a-z0-9_]*)"?\s*\(/gi
  const out = new Set()
  let m
  while ((m = re.exec(String(sql || ''))) !== null) out.add(m[1].toLowerCase())
  return [...out]
}

/** Identifiants définis par un fragment SQL (table/vue/fonction/type/séquence/index…). PURE. */
function definedIdentifiers(sqlFragment) {
  const re = /create\s+(?:or\s+replace\s+)?(?:unique\s+|unlogged\s+|temp(?:orary)?\s+|materialized\s+)*(?:table|view|function|procedure|type|domain|sequence|index|trigger|policy)\s+(?:if\s+not\s+exists\s+)?(?:"?[a-z_][a-z0-9_]*"?\s*\.\s*)?"?([a-z_][a-z0-9_]*)"?/gi
  const out = new Set()
  let m
  while ((m = re.exec(String(sqlFragment || ''))) !== null) out.add(m[1].toLowerCase())
  return [...out]
}

/** Vrai si `fragment` mentionne l'identifiant `name` (frontières de mot). PURE. */
function mentionsIdentifier(fragment, name) {
  return new RegExp(`(^|[^a-z0-9_])${String(name).toLowerCase()}([^a-z0-9_]|$)`, 'i').test(String(fragment || ''))
}

// ─────────────────────────────────────────────────────────────────────────────
// COUCHE PURE — les mutations
// ─────────────────────────────────────────────────────────────────────────────
//
// CONTRAT d'une mutation : (sql, opts) => { ok, sql, note }
//   ok:false  ⇒ mutation NON APPLICABLE à ce livrable (pas un échec : on ne peut
//               pas ajouter un trigger à un livrable sans table). Reporté « n/a ».
//   ok:true   ⇒ `sql` est le livrable muté, sémantiquement équivalent au regard
//               des EXIGENCES de la tâche.

/**
 * M1 — Ajoute une colonne `NOT NULL` AVEC `DEFAULT` dans le corps d'une table.
 * Doit TOUJOURS être neutre : la colonne se remplit seule, aucun INSERT existant
 * n'est impacté. Une chute de score ici = le scorer compte les colonnes ou
 * dépend de leur position.
 */
function mutAddNotNullColumnWithDefault(sql, opts = {}) {
  return insertColumnInBody(sql, opts.table, `${MUT}_note text NOT NULL DEFAULT 'ada'`,
    `colonne NOT NULL DEFAULT ajoutée à ${opts.table}`)
}

/**
 * M2 — Ajoute une colonne `NOT NULL` SANS `DEFAULT`.
 * Teste le correctif « découverte dynamique de colonnes » : les assertions
 * comportementales doivent construire leurs INSERT depuis information_schema,
 * pas depuis une liste de colonnes figée. Une chute de score ici = une assertion
 * a codé en dur sa liste de colonnes.
 */
function mutAddNotNullColumnNoDefault(sql, opts = {}) {
  const table = String(opts.table || '').toLowerCase()
  // GARDE-FOU (sinon faux positif) : si le livrable insère LUI-MÊME dans cette
  // table avec une liste de colonnes explicite (trigger d'audit, outbox…),
  // ajouter une colonne NOT NULL sans DEFAULT casse SON PROPRE code. La mutation
  // ne serait alors pas neutre et la chute de score n'accuserait pas le scorer.
  if (table && tablesInsertedWithColumnList(sql).includes(table)) {
    return { ok: false, sql: String(sql || ''), note: `${table} : le livrable y insère avec une liste de colonnes explicite (mutation non neutre)` }
  }
  return insertColumnInBody(sql, opts.table, `${MUT}_flag boolean NOT NULL`,
    `colonne NOT NULL SANS default ajoutée à ${table}`)
}

/** Insère une définition de colonne en tête du corps d'une table. PURE. */
function insertColumnInBody(sql, table, columnDef, note) {
  if (!table) return { ok: false, sql, note: 'aucune table cible' }
  const src = String(sql || '')
  const range = tableBodyRange(src, table)
  if (!range) return { ok: false, sql: src, note: `table ${table} introuvable` }
  const body = src.slice(range.open + 1, range.close)
  const sep = body.trim() ? ',' : ''
  const injected = `\n  ${columnDef}${sep}`
  return { ok: true, sql: src.slice(0, range.open + 1) + injected + body + src.slice(range.close), note }
}

/**
 * M3 — Renomme toutes les contraintes nommées (`CONSTRAINT x` → `CONSTRAINT x_zmut`).
 * Le renommage est CONSISTANT (déclarations et références), donc le schéma reste
 * strictement équivalent. Une chute de score ici = une assertion teste le NOM
 * d'une contrainte au lieu de son EFFET.
 */
function mutRenameConstraints(sql, _opts = {}) {
  const src = String(sql || '')
  let n = 0
  // 63 = longueur max d'un identifiant Postgres : on tronque avant de suffixer.
  // `(?!trigger\b)` : `CREATE CONSTRAINT TRIGGER x …` n'est PAS une contrainte
  // nommée — `TRIGGER` y est un mot-clé. Le renommer produit un SQL invalide,
  // donc un score 0 et un faux bug de scorer (piège rencontré sur les deux
  // livrables ledger, qui déclarent un CONSTRAINT TRIGGER de bilan).
  const out = src.replace(/\bconstraint\s+(?!trigger\b)("?)([a-z_][a-z0-9_]*)\1/gi, (full, q, name) => {
    n++
    return full.slice(0, full.length - name.length - (q ? 1 : 0)) + `${name.slice(0, 63 - MUT.length - 1)}_${MUT}` + q
  })
  if (!n) return { ok: false, sql: src, note: 'aucune contrainte nommée' }
  return { ok: true, sql: out, note: `${n} contrainte(s) renommée(s)` }
}

/**
 * M4 — Qualifie les noms de table avec le schéma (`orders` → `public.orders`).
 * `public` étant le search_path par défaut, c'est un pur choix de style.
 */
function mutQualifySchema(sql, _opts = {}) {
  const names = createdTableNames(sql)
  if (!names.length) return { ok: false, sql: String(sql || ''), note: 'aucune table créée' }
  let n = 0
  const out = rewriteTableRefs(sql, names, (name, schema) => {
    if (schema) return null       // déjà qualifiée : on laisse
    n++
    return `public.${name}`
  })
  if (!n) return { ok: false, sql: String(sql || ''), note: 'toutes les références sont déjà qualifiées' }
  return { ok: true, sql: out, note: `${n} référence(s) qualifiée(s) public.` }
}

/**
 * M5 — Déqualifie (`public.orders` → `orders`). Mutation inverse de M4 :
 * couvre le cas d'un livrable qui qualifie par défaut.
 *
 * N'opère PAS dans les corps de fonctions dollar-quotés : un livrable durci y
 * pose `SECURITY DEFINER … SET search_path = ''`, où un nom non qualifié ne
 * résout plus. Déqualifier là casserait légitimement le livrable.
 */
function mutUnqualifySchema(sql, _opts = {}) {
  const names = createdTableNames(sql)
  if (!names.length) return { ok: false, sql: String(sql || ''), note: 'aucune table créée' }
  let n = 0
  const out = rewriteTableRefs(sql, names, (name, schema) => {
    if (schema !== 'public') return null
    n++
    return name
  }, { skipDollarQuoted: true })
  if (!n) return { ok: false, sql: String(sql || ''), note: 'aucune référence qualifiée public.' }
  return { ok: true, sql: out, note: `${n} référence(s) déqualifiée(s)` }
}

/**
 * M6 — Ajoute un trigger BEFORE INSERT supplémentaire, sans effet observable
 * (`RETURN NEW`). Teste le correctif « compte EXACT de triggers » : une assertion
 * doit exiger `>= N`, jamais `= N` — un livrable a le droit d'ajouter ses propres
 * triggers (updated_at, outbox, audit…).
 */
function mutAddExtraTrigger(sql, opts = {}) {
  const table = opts.table
  if (!table) return { ok: false, sql: String(sql || ''), note: 'aucune table cible' }
  const src = String(sql || '')
  if (!createdTableNames(src).includes(String(table).toLowerCase())) {
    return { ok: false, sql: src, note: `table ${table} non créée par le livrable` }
  }
  const fn = `${MUT}_noop_${String(table).toLowerCase()}`.slice(0, 63)
  const snippet = [
    '',
    `CREATE OR REPLACE FUNCTION ${fn}() RETURNS trigger LANGUAGE plpgsql AS $${MUT}$ BEGIN RETURN NEW; END $${MUT}$;`,
    `CREATE TRIGGER ${`${MUT}_bi_${table}`.slice(0, 63)} BEFORE INSERT ON ${table} FOR EACH ROW EXECUTE FUNCTION ${fn}();`,
    '',
  ].join('\n')
  return { ok: true, sql: appendStatements(src, snippet), note: `trigger no-op BEFORE INSERT ajouté sur ${table}` }
}

/** Concatène des instructions à la fin d'un script, en garantissant le `;` séparateur. PURE. */
function appendStatements(sql, snippet) {
  const src = String(sql || '')
  const trimmed = src.replace(/\s+$/, '')
  const sep = trimmed.endsWith(';') ? '\n' : ';\n'
  return trimmed + sep + snippet
}

/**
 * M7 — Met les identifiants de table entre guillemets (`orders` → `"orders"`).
 * Les noms étant déjà en minuscules, le quoting est un no-op sémantique
 * (Postgres replie l'identifiant nu en minuscules).
 */
function mutQuoteIdentifiers(sql, _opts = {}) {
  const names = createdTableNames(sql)
  if (!names.length) return { ok: false, sql: String(sql || ''), note: 'aucune table créée' }
  let n = 0
  const out = rewriteTableRefs(sql, names, (name, schema, quoted) => {
    if (quoted) return null
    n++
    return (schema ? `${schema}.` : '') + `"${name}"`
  })
  if (!n) return { ok: false, sql: String(sql || ''), note: 'identifiants déjà quotés' }
  return { ok: true, sql: out, note: `${n} identifiant(s) quoté(s)` }
}

/**
 * M8 — Remplace le type `text` par `varchar(255)` sur la 1re colonne texte de
 * chaque table. `text` et `varchar(n)` sont interchangeables tant qu'aucune
 * exigence ne porte sur le type — aucune tâche above-threshold n'exige `text`
 * (seul `amount_cents` a un type exigé, et il est `bigint`).
 */
function mutTextToVarchar(sql, _opts = {}) {
  let src = String(sql || '')
  const names = createdTableNames(src)
  let n = 0
  for (const name of names) {
    const range = tableBodyRange(src, name)
    if (!range) continue
    const body = src.slice(range.open + 1, range.close)
    // Ligne de définition de colonne : `<ident> text …` (pas `CHECK(x::text)`,
    // pas `CONSTRAINT …` — le 1er token doit être suivi directement de `text`).
    const m = /(\n\s*"?[a-z_][a-z0-9_]*"?\s+)text\b/i.exec(body)
    if (!m) continue
    const idx = m.index + m[1].length
    const newBody = body.slice(0, idx) + 'varchar(255)' + body.slice(idx + 'text'.length)
    src = src.slice(0, range.open + 1) + newBody + src.slice(range.close)
    n++
  }
  if (!n) return { ok: false, sql: String(sql || ''), note: 'aucune colonne de type text' }
  return { ok: true, sql: src, note: `${n} colonne(s) text → varchar(255)` }
}

/**
 * M9 — Réordonne deux blocs de tables INDÉPENDANTS.
 *
 * Un « bloc » = l'instruction `CREATE TABLE` + tout ce qui la suit jusqu'au
 * `CREATE TABLE` suivant (ALTER, index, triggers, policies de cette table) :
 * c'est l'unité que ces livrables organisent naturellement.
 *
 * On ne permute que des blocs ADJACENTS et MUTUELLEMENT INDÉPENDANTS : aucun des
 * deux ne doit mentionner un identifiant défini par l'autre (table, fonction,
 * type…). Sans ce garde-fou on casserait légitimement l'application (une FK ne
 * peut pas référencer une table pas encore créée) — et on rapporterait un faux
 * bug de scorer.
 */
function mutReorderTables(sql, _opts = {}) {
  const src = String(sql || '')
  const chunks = splitStatements(src)
  const tables = createdTables(src)
  if (tables.length < 2) return { ok: false, sql: src, note: 'moins de 2 tables créées' }

  // Blocs : [début de la CREATE TABLE i, début de la CREATE TABLE i+1[
  const blocks = tables.map((t, i) => {
    const from = t.chunkIndex
    const to = i + 1 < tables.length ? tables[i + 1].chunkIndex : chunks.length
    return { table: t.name, from, to, text: chunks.slice(from, to).map(c => c.text).join('') }
  })

  // Traçabilité : on note POURQUOI chaque paire est refusée. Un « n/a » muet
  // se lirait comme « couvert », alors que c'est une lacune de couverture.
  const rejected = []
  for (let i = 0; i + 1 < blocks.length; i++) {
    const a = blocks[i]
    const b = blocks[i + 1]
    const defsA = definedIdentifiers(a.text)
    const defsB = definedIdentifiers(b.text)
    const usedByB = defsA.filter(d => mentionsIdentifier(b.text, d))
    const usedByA = defsB.filter(d => mentionsIdentifier(a.text, d))
    if (usedByB.length || usedByA.length) {
      rejected.push(`${a.table}↔${b.table} (dépendance: ${[...usedByB, ...usedByA].slice(0, 3).join(', ')})`)
      continue
    }
    const head = chunks.slice(0, a.from).map(c => c.text).join('')
    const tail = chunks.slice(b.to).map(c => c.text).join('')
    return { ok: true, sql: head + b.text + a.text + tail, note: `blocs ${a.table} ↔ ${b.table} permutés` }
  }
  return { ok: false, sql: src, note: `aucune paire adjacente indépendante — refusées: ${rejected.join(' · ')}` }
}

/**
 * M0 — Identité : re-emballe le livrable sans rien changer.
 * Sert de témoin : isole l'effet du ré-emballage (extraction + rejointure des
 * blocs ```sql) de l'effet des mutations réelles. Si M0 chute, c'est le harnais
 * de mutation qui est en cause, pas le scorer.
 */
function mutIdentity(sql, _opts = {}) {
  return { ok: true, sql: String(sql || ''), note: 'témoin (aucune mutation)' }
}

/**
 * Registre des mutations.
 *  - perTable:true ⇒ une variante par table créée (isolation automatique du
 *    responsable en cas de régression).
 */
const MUTATIONS = [
  { id: 'identity',                 perTable: false, fn: mutIdentity,                    label: 'témoin — aucune mutation' },
  { id: 'add-notnull-col-default',  perTable: true,  fn: mutAddNotNullColumnWithDefault, label: 'colonne NOT NULL avec DEFAULT' },
  { id: 'add-notnull-col-nodefault', perTable: true, fn: mutAddNotNullColumnNoDefault,   label: 'colonne NOT NULL sans DEFAULT' },
  { id: 'rename-constraints',       perTable: false, fn: mutRenameConstraints,           label: 'renommage des contraintes' },
  { id: 'qualify-schema',           perTable: false, fn: mutQualifySchema,               label: 'qualification public.<table>' },
  { id: 'unqualify-schema',         perTable: false, fn: mutUnqualifySchema,             label: 'déqualification public.<table>' },
  { id: 'add-extra-trigger',        perTable: true,  fn: mutAddExtraTrigger,             label: 'trigger BEFORE INSERT no-op en plus' },
  { id: 'quote-identifiers',        perTable: false, fn: mutQuoteIdentifiers,            label: 'identifiants entre guillemets' },
  { id: 'text-to-varchar',          perTable: false, fn: mutTextToVarchar,               label: 'text → varchar(255)' },
  { id: 'reorder-tables',           perTable: false, fn: mutReorderTables,               label: 'permutation de deux blocs indépendants' },
]

const MUTATION_BY_ID = Object.fromEntries(MUTATIONS.map(m => [m.id, m]))

/** Applique une mutation par identifiant. PURE. */
function applyMutation(id, sql, opts = {}) {
  const m = MUTATION_BY_ID[id]
  if (!m) return { ok: false, sql: String(sql || ''), note: `mutation inconnue: ${id}` }
  return m.fn(sql, opts)
}

/**
 * Développe le registre en variantes concrètes pour un SQL donné. PURE.
 * Une variante `perTable` produit une entrée par table créée.
 * @returns {Array<{id:string,variant:string,table:string|null,label:string}>}
 */
function buildVariants(sql, mutationIds) {
  const wanted = mutationIds && mutationIds.length
    ? MUTATIONS.filter(m => mutationIds.includes(m.id))
    : MUTATIONS
  const tables = createdTableNames(sql)
  const out = []
  for (const m of wanted) {
    if (m.perTable) {
      for (const t of tables) out.push({ id: m.id, variant: `${m.id}@${t}`, table: t, label: m.label })
    } else {
      out.push({ id: m.id, variant: m.id, table: null, label: m.label })
    }
  }
  return out
}

// ─────────────────────────────────────────────────────────────────────────────
// COUCHE PURE — analyse des résultats
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Verdict d'une variante à partir du score de référence et du score muté. PURE.
 *   'n/a'        : mutation non applicable
 *   'stable'     : score STRICTEMENT égal — le scorer a résisté
 *   'regression' : le score a chuté — FAUX NÉGATIF du scorer (bug d'instrument)
 *   'anomalie'   : le score a monté, ou est devenu non numérique (skip inattendu)
 */
function verdictFor(baseline, mutant, applicable) {
  if (!applicable) return 'n/a'
  if (typeof mutant !== 'number' || typeof baseline !== 'number') return 'anomalie'
  if (mutant === baseline) return 'stable'
  return mutant < baseline ? 'regression' : 'anomalie'
}

/**
 * Assertions qui passaient dans la référence et échouent après mutation. PURE.
 * C'est le repro exploitable : le nom de l'assertion sur-contrainte.
 */
function brokenAssertions(baselineDetail, mutantDetail) {
  const base = new Map(((baselineDetail && baselineDetail.assertions) || []).map(a => [a.name, a]))
  const out = []
  for (const a of ((mutantDetail && mutantDetail.assertions) || [])) {
    const b = base.get(a.name)
    if (b && b.ok && !a.ok) out.push({ name: a.name, expect: a.expect, got: a.got })
  }
  return out
}

/** Agrège les résultats d'un livrable. PURE. */
function summarize(rows) {
  const counts = { stable: 0, regression: 0, anomalie: 0, 'n/a': 0 }
  for (const r of rows) counts[r.verdict] = (counts[r.verdict] || 0) + 1
  return counts
}

// ─────────────────────────────────────────────────────────────────────────────
// COUCHE IMPURE — exécution du scorer réel
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Charge bench-v2.js PARESSEUSEMENT. Le require est différé pour que la couche
 * pure (et ses tests unitaires) reste utilisable même si bench-v2.js est cassé
 * ou si Postgres est absent.
 */
function loadBench(benchPath) {
  return require(benchPath || join(COORD_DIR, 'bench-v2.js'))
}

function loadTasks() {
  try { return JSON.parse(readFileSync(TASKS_FILE, 'utf8')).tasks || [] } catch { return [] }
}

/** Déduit le taskId d'un chemin `/tmp/benchv2-<taskId>-<ARM>.txt`. PURE (ids fournis). */
function inferTaskId(filePath, knownIds) {
  const base = String(filePath).split('/').pop().replace(/^benchv2-/, '').replace(/\.txt$/, '')
  // Le taskId contient des tirets : on prend le plus long id qui préfixe le nom.
  let best = null
  for (const id of knownIds || []) {
    if (base === id || base.startsWith(id + '-')) {
      if (!best || id.length > best.length) best = id
    }
  }
  return best
}

let dbCounter = 0
function nextSuffix() { return `mt${process.pid}${(dbCounter++).toString(36)}` }

/** Emballe un SQL muté en livrable scorable (un seul bloc ```sql). PURE. */
function wrapDeliverable(sql) {
  return '```sql\n' + String(sql || '').trim() + '\n```\n'
}

/**
 * Lance le mutation testing d'un livrable. IMPUR (psql via bench-v2).
 * @returns {{taskId, file, baseline, rows[], counts}}
 */
function runDeliverable(bench, task, deliverableText, opts = {}) {
  const blocks = bench.extractSqlBlocks(deliverableText)
  const originalSql = blocks.join('\n;\n')

  // Référence : le livrable EXACTEMENT tel qu'il est sur disque.
  const ref = bench.scoreSqlDeliverable(task, deliverableText, nextSuffix())
  const rows = []
  const variants = buildVariants(originalSql, opts.mutations)

  for (const v of variants) {
    const res = applyMutation(v.id, originalSql, { table: v.table })
    if (!res.ok) {
      rows.push({ variant: v.variant, label: v.label, note: res.note, applicable: false, score: null, verdict: 'n/a', broken: [] })
      if (opts.onRow) opts.onRow(rows[rows.length - 1])
      continue
    }
    const scored = bench.scoreSqlDeliverable(task, wrapDeliverable(res.sql), nextSuffix())
    const verdict = verdictFor(ref.score, scored.score, true)
    const row = {
      variant: v.variant,
      label: v.label,
      note: res.note,
      applicable: true,
      score: scored.score,
      verdict,
      broken: verdict === 'regression' ? brokenAssertions(ref.detail, scored.detail) : [],
      applyError: (scored.detail && scored.detail.applyError) || null,
      mutatedSql: verdict === 'regression' ? res.sql : null,
    }
    rows.push(row)
    if (opts.onRow) opts.onRow(row)
  }
  return { baseline: ref.score, baselineDetail: ref.detail, rows, counts: summarize(rows) }
}

// ─────────────────────────────────────────────────────────────────────────────
// CLI
// ─────────────────────────────────────────────────────────────────────────────
function parseFlags(argv) {
  const flags = {}
  const positional = []
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i]
    if (a.startsWith('--')) {
      const key = a.slice(2)
      const next = argv[i + 1]
      if (next === undefined || next.startsWith('--')) flags[key] = true
      else { flags[key] = next; i++ }
    } else positional.push(a)
  }
  return { flags, positional }
}
const csv = (v) => (typeof v === 'string' ? v.split(',').map(s => s.trim()).filter(Boolean) : [])

function badge(verdict) {
  if (verdict === 'stable') return `${C.green}STABLE${C.reset}`
  if (verdict === 'regression') return `${C.red}RÉGRESSION${C.reset}`
  if (verdict === 'anomalie') return `${C.yellow}ANOMALIE${C.reset}`
  return `${C.gray}n/a${C.reset}`
}

function printRow(row, baseline) {
  const score = row.applicable ? String(row.score) : '·'
  console.log(`  ${badge(row.verdict).padEnd(22)} ${row.variant.padEnd(42)} ${String(baseline).padStart(3)} → ${score.padStart(3)}  ${C.gray}${row.note}${C.reset}`)
  for (const b of row.broken) {
    console.log(`      ${C.red}✗ assertion « ${b.name} » : attendu ${JSON.stringify(b.expect)}, obtenu ${JSON.stringify(String(b.got).slice(0, 120))}${C.reset}`)
  }
}

function main(argv) {
  const cmd = argv[2]
  const { flags, positional } = parseFlags(argv.slice(3))

  if (cmd === 'list' || !cmd) {
    console.log(`${C.bold}mutation-test — mutations disponibles${C.reset}\n`)
    for (const m of MUTATIONS) {
      console.log(`  ${C.cyan}${m.id.padEnd(26)}${C.reset} ${m.label}${m.perTable ? `  ${C.gray}(une variante par table)${C.reset}` : ''}`)
    }
    console.log(`\n${C.gray}node mutation-test.js run <livrable> [--task <id>] [--mutations a,b] [--json]`)
    console.log(`node mutation-test.js run-all [--arms NATIVE,PIPELINE] [--json]${C.reset}`)
    return
  }

  const tasks = loadTasks()
  let bench
  try { bench = loadBench(flags.bench) } catch (e) {
    console.error(`${C.red}bench-v2.js inutilisable: ${e.message}${C.reset}`)
    process.exit(1)
  }

  let files = []
  if (cmd === 'run') {
    files = positional
    if (!files.length) { console.error('usage: run <livrable> [...]'); process.exit(1) }
  } else if (cmd === 'run-all') {
    const arms = csv(flags.arms).length ? csv(flags.arms) : ['NATIVE', 'PIPELINE']
    const atTasks = tasks.filter(t => (t.categories || []).includes('above-threshold'))
    for (const t of atTasks) for (const a of arms) files.push(`/tmp/benchv2-${t.id}-${a}.txt`)
  } else {
    console.error(`commande inconnue: ${cmd}`); process.exit(1)
  }

  const all = []
  for (const file of files) {
    const taskId = flags.task || inferTaskId(file, tasks.map(t => t.id))
    const task = tasks.find(t => t.id === taskId)
    if (!task) { console.error(`${C.red}tâche introuvable pour ${file} (utilise --task)${C.reset}`); continue }
    if (!existsSync(file)) { console.error(`${C.yellow}livrable absent, ignoré: ${file}${C.reset}`); continue }

    const text = readFileSync(file, 'utf8')
    if (!flags.json) console.log(`\n${C.bold}▶ ${taskId}${C.reset} ${C.gray}${file}${C.reset}`)
    const res = runDeliverable(bench, task, text, { mutations: csv(flags.mutations) })
    if (!flags.json) {
      console.log(`  ${C.gray}référence = ${res.baseline}/100${C.reset}`)
      for (const row of res.rows) printRow(row, res.baseline)
    }
    all.push({ taskId, file, baseline: res.baseline, counts: res.counts, rows: res.rows })
  }

  if (flags.json) { console.log(JSON.stringify(all, null, 2)); return }

  // Synthèse
  const tot = { stable: 0, regression: 0, anomalie: 0, 'n/a': 0 }
  for (const r of all) for (const k of Object.keys(tot)) tot[k] += r.counts[k] || 0
  console.log(`\n${C.bold}Synthèse — ${all.length} livrable(s)${C.reset}`)
  console.log(`  ${C.green}stable${C.reset}=${tot.stable}  ${C.red}régression${C.reset}=${tot.regression}  ${C.yellow}anomalie${C.reset}=${tot.anomalie}  ${C.gray}n/a${C.reset}=${tot['n/a']}`)
  if (tot.regression || tot.anomalie) {
    console.log(`\n${C.red}${C.bold}Le scorer N'EST PAS validé : ${tot.regression} régression(s), ${tot.anomalie} anomalie(s).${C.reset}`)
    process.exitCode = 1
  } else {
    console.log(`\n${C.green}${C.bold}Scorer validé par mutation testing : aucune mutation neutre ne fait bouger le score.${C.reset}`)
  }
}

module.exports = {
  // lexer
  splitStatements, matchParen, stripLeadingNoise, dollarTagAt,
  createdTables, createdTableNames, tableBodyRange,
  rewriteTableRefs, definedIdentifiers, mentionsIdentifier,
  splitDollarQuoted, tablesInsertedWithColumnList,
  // mutations
  MUTATIONS, MUTATION_BY_ID, applyMutation, buildVariants,
  mutIdentity, mutAddNotNullColumnWithDefault, mutAddNotNullColumnNoDefault,
  mutRenameConstraints, mutQualifySchema, mutUnqualifySchema, mutAddExtraTrigger,
  mutQuoteIdentifiers, mutTextToVarchar, mutReorderTables, appendStatements,
  // analyse
  verdictFor, brokenAssertions, summarize, wrapDeliverable, inferTaskId,
  // exécution
  runDeliverable,
}

if (require.main === module) main(process.argv)
