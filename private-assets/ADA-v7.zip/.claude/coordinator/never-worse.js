'use strict'
/**
 * coordinator/never-worse.js — Garde « jamais pire » sur les contenus injectés
 *
 * Inspiré de rtk (src/core/guard.rs) : un formateur/optimiseur de contenu ne doit
 * JAMAIS produire un résultat plus gros (en tokens estimés) que la source brute
 * qu'il transforme. Un bug de formatage (duplication, verbosité, en-têtes en trop)
 * ne peut donc jamais dégrader le coût d'injection dans un prompt — au pire on
 * retombe sur le contenu brut, jamais pire que sans la garde.
 *
 * Deux gardes complémentaires :
 *   - neverWorse(raw, transformed)        : formateur pur — transformed gagne s'il
 *                                            n'est pas plus gros que raw, sinon raw.
 *   - guardInjection(base, injection, …)  : assemblage prompt — l'injection ne peut
 *                                            pas dépasser `maxRatio` de la taille du
 *                                            prompt de base ; au-delà elle est
 *                                            tronquée proprement, ou omise si même
 *                                            tronquée elle serait vide.
 *
 * Estimation de tokens : approximation grossière `len/4` (cohérente avec le reste
 * du coordinator, cf. budget-guard.js / token-telemetry.js) — pas de tokenizer
 * exact nécessaire ici, seule la comparaison relative compte.
 *
 * Zéro dépendance npm.
 */

/**
 * Estimation grossière du nombre de tokens d'un texte (len/4, arrondi au-dessus).
 * @param {string} text
 * @returns {number}
 */
function estimateTokens(text) {
  if (!text || typeof text !== 'string') return 0
  return Math.ceil(text.length / 4)
}

/**
 * Ne renvoie `transformed` que s'il n'est pas plus gros (en tokens estimés) que
 * `raw`. Sinon retombe sur `raw` — un formateur bugué ne peut jamais dégrader le
 * volume injecté par rapport à la source brute.
 *
 * @param {string} raw          contenu brut (référence)
 * @param {string} transformed  contenu formaté/optimisé
 * @returns {string} `transformed` ou `raw`, jamais pire que `raw` en tokens
 */
function neverWorse(raw, transformed) {
  const rawText = typeof raw === 'string' ? raw : ''
  const transformedText = typeof transformed === 'string' ? transformed : ''
  return estimateTokens(transformedText) > estimateTokens(rawText) ? rawText : transformedText
}

/**
 * Combine un prompt de base et une injection de contexte, en garantissant que
 * l'injection ne dépasse jamais `maxRatio` de la taille (tokens estimés) du
 * prompt de base :
 *   - injection ≤ maxRatio * base       → base + injection (séparés par \n\n)
 *   - injection > maxRatio * base       → injection tronquée à la limite autorisée
 *   - limite autorisée < 1 token        → injection omise, on renvoie `base` seul
 *
 * Choix volontairement simple (troncature dure, pas de résumé) : la garde doit
 * rester triviale à auditer — un résumé intelligent serait lui-même un
 * "formateur" à protéger par `neverWorse`.
 *
 * Cas limite : `basePrompt` vide → aucun ratio n'est calculable (rien à
 * protéger), l'injection est renvoyée telle quelle. Le ratio ne s'applique
 * qu'en présence d'un prompt de base réel.
 *
 * @param {string} basePrompt
 * @param {string} injection
 * @param {{ maxRatio?: number }} [opts] maxRatio par défaut 0.5 (l'injection ne
 *   peut pas dépasser 50% de la taille du prompt de base)
 * @returns {string}
 */
function guardInjection(basePrompt, injection, opts = {}) {
  const base = typeof basePrompt === 'string' ? basePrompt : ''
  const inj  = typeof injection === 'string' ? injection : ''
  const maxRatio = typeof opts.maxRatio === 'number' ? opts.maxRatio : 0.5

  if (!inj) return base
  if (!base) return inj // pas de base → pas de ratio calculable, rien à protéger

  const baseTokens = estimateTokens(base)
  const maxInjectionTokens = Math.floor(baseTokens * maxRatio)
  const injTokens = estimateTokens(inj)

  if (injTokens <= maxInjectionTokens) {
    return base ? `${base}\n\n${inj}` : inj
  }

  // Dépassement : tronquer proprement à la limite autorisée (≈4 chars/token).
  const maxChars = maxInjectionTokens * 4
  if (maxChars < 1) return base // rien à injecter sans dépasser le ratio → omission

  const truncated = inj.slice(0, maxChars).trim()
  if (!truncated) return base
  return base ? `${base}\n\n${truncated}` : truncated
}

module.exports = { estimateTokens, neverWorse, guardInjection }
