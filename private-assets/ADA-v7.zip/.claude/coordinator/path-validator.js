'use strict'
/**
 * coordinator/path-validator.js — Validation sécurisée des chemins de fichiers
 */
const { resolve } = require('path')
const { existsSync } = require('fs')

/**
 * Vérifie qu'un chemin reste dans le répertoire autorisé (jail).
 * @param {string} inputPath — chemin à valider
 * @param {string} allowedBase — répertoire racine autorisé
 * @returns {{ safe: boolean, resolved?: string, reason?: string }}
 */
function validatePath(inputPath, allowedBase) {
  if (!inputPath || typeof inputPath !== 'string') {
    return { safe: false, reason: 'Chemin vide ou invalide' }
  }
  if (inputPath.includes('\0')) {
    return { safe: false, reason: 'Null byte dans le chemin' }
  }

  const resolved = resolve(allowedBase, inputPath)
  const base     = resolve(allowedBase)

  if (!resolved.startsWith(base + require('path').sep) && resolved !== base) {
    return { safe: false, reason: `Path traversal détecté: ${inputPath} → ${resolved}` }
  }

  return { safe: true, resolved }
}

/**
 * Valide un nom de fichier (pas de chemin, juste le basename).
 * @param {string} filename
 * @returns {boolean}
 */
function isSafeFilename(filename) {
  if (!filename || typeof filename !== 'string') return false
  if (filename.includes('/') || filename.includes('\\') || filename.includes('\0')) return false
  if (filename.startsWith('.') && filename.length === 1) return false
  return /^[a-zA-Z0-9_\-\.]{1,255}$/.test(filename)
}

/**
 * Vérifie que le chemin n'accède pas à des fichiers sensibles.
 * @param {string} resolvedPath
 * @returns {{ safe: boolean, reason?: string }}
 */
function checkSensitiveFiles(resolvedPath) {
  const SENSITIVE_PATTERNS = [
    /\.env(\.|$)/i,
    /\.(pem|key|p12|pfx|crt|cer)$/i,
    /id_(rsa|ecdsa|ed25519)(\.pub)?$/i,
    /\.aws\/credentials$/i,
    /\.ssh\//i,
    /secrets?\.(json|yaml|yml|toml)$/i,
  ]
  for (const pattern of SENSITIVE_PATTERNS) {
    if (pattern.test(resolvedPath)) {
      return { safe: false, reason: `Accès à un fichier sensible: ${resolvedPath}` }
    }
  }
  return { safe: true }
}

module.exports = { validatePath, isSafeFilename, checkSensitiveFiles }
