'use strict'
/**
 * coordinator/plugin-sdk.js — SDK pour les plugins AI-Dev-Assistant
 *
 * Fournit :
 *  - validateManifest(manifest) : valide un manifest.json de plugin
 *  - listPlugins() : liste les plugins installés dans ~/.claude/plugins/
 *  - loadPlugin(name) : charge et valide un plugin par nom
 *  - PLUGIN_EVENTS : liste des événements supportés
 *  - MANIFEST_SCHEMA : schéma de référence pour un manifest valide
 */

const { existsSync, readdirSync, readFileSync, statSync } = require('node:fs')
const { join } = require('node:path')

const CURRENT_SDK_VERSION = '1.0.0'
const MIN_NODE_VERSION = 22

const PLUGIN_EVENTS = [
  'git-commit', 'git-push',
  'test-js', 'test-py',
  'db-migration', 'docker-build', 'ts-build',
  'dep-install', 'cve-critical'
]

const MANIFEST_SCHEMA = {
  required: ['name', 'version', 'description'],
  optional: ['hooks', 'minSdkVersion', 'minNodeVersion', 'author', 'license', 'categories', 'tags', 'homepage', 'keywords'],
  types: {
    name:           'string',
    version:        'string',
    description:    'string',
    hooks:          'array',
    minSdkVersion:  'string',
    minNodeVersion: 'number',
    author:         'string',
    license:        'string',
    categories:     'array',
    tags:           'array',
    homepage:       'string',
    keywords:       'array',
  }
}

const LIFECYCLE_EVENTS = ['load', 'unload', 'enable', 'disable']

// ── Semver helpers ─────────────────────────────────────────────────────────────

/** @param {string} v */
function parseSemver(v) {
  const m = /^(\d+)\.(\d+)\.(\d+)$/.exec(v)
  if (!m) return null
  return [parseInt(m[1], 10), parseInt(m[2], 10), parseInt(m[3], 10)]
}

/**
 * Compare deux versions semver sous la forme "X.Y.Z".
 * @param {string} a
 * @param {string} b
 * @returns {-1|0|1}
 */
function semverCompare(a, b) {
  const pa = parseSemver(a)
  const pb = parseSemver(b)
  if (!pa || !pb) return 0
  for (let i = 0; i < 3; i++) {
    if (pa[i] < pb[i]) return -1
    if (pa[i] > pb[i]) return  1
  }
  return 0
}

// ── validateManifest ───────────────────────────────────────────────────────────

/**
 * Valide un manifest.json de plugin.
 * @param {Record<string, unknown>} manifest
 * @returns {{ valid: boolean, errors: string[], warnings: string[] }}
 */
function validateManifest(manifest) {
  const errors   = []
  const warnings = []

  if (!manifest || typeof manifest !== 'object' || Array.isArray(manifest)) {
    return { valid: false, errors: ['manifest doit être un objet'], warnings }
  }

  // Champs required
  for (const field of MANIFEST_SCHEMA.required) {
    if (manifest[field] === undefined || manifest[field] === null) {
      errors.push(`Champ requis manquant : "${field}"`)
    }
  }

  // Types des champs présents
  for (const [field, expectedType] of Object.entries(MANIFEST_SCHEMA.types)) {
    const value = manifest[field]
    if (value === undefined || value === null) continue

    if (expectedType === 'array') {
      if (!Array.isArray(value)) {
        errors.push(`"${field}" doit être un tableau, reçu ${typeof value}`)
      }
    } else if (typeof value !== expectedType) {
      errors.push(`"${field}" doit être de type ${expectedType}, reçu ${typeof value}`)
    }
  }

  // Strings non vides pour les champs required string
  for (const field of MANIFEST_SCHEMA.required) {
    const val = manifest[field]
    if (typeof val === 'string' && val.trim() === '') {
      errors.push(`"${field}" ne peut pas être une chaîne vide`)
    }
  }

  // Validation des hooks
  if (Array.isArray(manifest.hooks)) {
    const unknownHooks = manifest.hooks.filter(h => !PLUGIN_EVENTS.includes(h))
    for (const h of unknownHooks) {
      errors.push(`Hook inconnu : "${h}". Valeurs valides : ${PLUGIN_EVENTS.join(', ')}`)
    }
    if (manifest.hooks.length === 0) {
      warnings.push('Le tableau "hooks" est vide — ce plugin ne sera jamais déclenché')
    }
  }

  // Validation minSdkVersion
  if (manifest.minSdkVersion !== undefined && typeof manifest.minSdkVersion === 'string') {
    if (!parseSemver(manifest.minSdkVersion)) {
      errors.push(`"minSdkVersion" doit respecter le format semver X.Y.Z, reçu "${manifest.minSdkVersion}"`)
    } else if (semverCompare(manifest.minSdkVersion, CURRENT_SDK_VERSION) > 0) {
      warnings.push(`"minSdkVersion" (${manifest.minSdkVersion}) est supérieur à la version SDK courante (${CURRENT_SDK_VERSION})`)
    }
  }

  // Validation minNodeVersion
  if (manifest.minNodeVersion !== undefined && typeof manifest.minNodeVersion === 'number') {
    const currentMajor = parseInt(process.versions.node.split('.')[0], 10)
    if (manifest.minNodeVersion > currentMajor) {
      warnings.push(`"minNodeVersion" (${manifest.minNodeVersion}) supérieur à la version Node.js courante (${currentMajor})`)
    }
  }

  // Warnings qualitatifs
  if (typeof manifest.description === 'string' && manifest.description.trim().length < 10) {
    warnings.push('"description" trop courte (< 10 caractères) — soyez plus explicite')
  }

  if (manifest.hooks === undefined) {
    warnings.push('"hooks" non déclaré — ce plugin ne sera jamais déclenché automatiquement')
  }

  if (!manifest.license) {
    warnings.push('"license" non déclarée — ajoutez un identifiant SPDX (ex: MIT, Apache-2.0)')
  }

  return { valid: errors.length === 0, errors, warnings }
}

// ── listPlugins ────────────────────────────────────────────────────────────────

/**
 * Liste les plugins installés dans pluginsDir (défaut : ~/.claude/plugins/).
 * @param {string} [pluginsDir]
 * @returns {Array<{ name: string, manifest: object|null, hasWorker: boolean, hasHook: boolean, path: string }>}
 */
function listPlugins(pluginsDir) {
  const dir = pluginsDir || join(process.env.HOME, '.claude', 'plugins')

  if (!existsSync(dir)) return []

  let entries
  try {
    entries = readdirSync(dir)
  } catch {
    return []
  }

  const plugins = []
  for (const entry of entries) {
    const pluginPath = join(dir, entry)
    try {
      const stat = statSync(pluginPath)
      if (!stat.isDirectory()) continue
    } catch {
      continue
    }

    const manifestPath = join(pluginPath, 'manifest.json')
    let manifest = null
    if (existsSync(manifestPath)) {
      try {
        manifest = JSON.parse(readFileSync(manifestPath, 'utf8'))
      } catch {
        manifest = null
      }
    }

    plugins.push({
      name:      entry,
      manifest,
      hasWorker: existsSync(join(pluginPath, 'worker.js')),
      hasHook:   existsSync(join(pluginPath, 'hook.js')),
      path:      pluginPath,
    })
  }

  return plugins
}

// ── loadPlugin ─────────────────────────────────────────────────────────────────

/**
 * Charge et valide un plugin par nom.
 * @param {string} name
 * @param {string} [pluginsDir]
 * @returns {{ manifest: object|null, workerPath: string|null, hookPath: string|null, validation: ReturnType<typeof validateManifest> }}
 */
function loadPlugin(name, pluginsDir) {
  const dir        = pluginsDir || join(process.env.HOME, '.claude', 'plugins')
  const pluginPath = join(dir, name)

  if (!existsSync(pluginPath)) {
    return {
      manifest:   null,
      workerPath: null,
      hookPath:   null,
      validation: { valid: false, errors: [`Plugin "${name}" introuvable dans ${dir}`], warnings: [] }
    }
  }

  const manifestPath = join(pluginPath, 'manifest.json')
  let manifest = null

  if (!existsSync(manifestPath)) {
    return {
      manifest:   null,
      workerPath: null,
      hookPath:   null,
      validation: { valid: false, errors: [`manifest.json manquant dans ${pluginPath}`], warnings: [] }
    }
  }

  try {
    manifest = JSON.parse(readFileSync(manifestPath, 'utf8'))
  } catch (err) {
    return {
      manifest:   null,
      workerPath: null,
      hookPath:   null,
      validation: { valid: false, errors: [`manifest.json invalide (JSON malformé) : ${err.message}`], warnings: [] }
    }
  }

  const validation = validateManifest(manifest)
  const workerPath = existsSync(join(pluginPath, 'worker.js')) ? join(pluginPath, 'worker.js') : null
  const hookPath   = existsSync(join(pluginPath, 'hook.js'))   ? join(pluginPath, 'hook.js')   : null

  return { manifest, workerPath, hookPath, validation }
}

// ── PluginBuilder ──────────────────────────────────────────────────────────────

/**
 * Builder pattern fluent pour créer des manifests de plugin.
 */
class PluginBuilder {
  /** @param {string} name */
  constructor(name) {
    this._manifest = { name }
  }

  /** @param {string} v @returns {this} */
  version(v) { this._manifest.version = v; return this }

  /** @param {string} d @returns {this} */
  description(d) { this._manifest.description = d; return this }

  /** @param {string} a @returns {this} */
  author(a) { this._manifest.author = a; return this }

  /** @param {string} l @returns {this} */
  license(l) { this._manifest.license = l; return this }

  /** @param {...string} events @returns {this} */
  hooks(...events) { this._manifest.hooks = events.flat(); return this }

  /** @param {...string} cats @returns {this} */
  categories(...cats) { this._manifest.categories = cats.flat(); return this }

  /** @param {...string} t @returns {this} */
  tags(...t) { this._manifest.tags = t.flat(); return this }

  /** @param {string} v @returns {this} */
  minSdkVersion(v) { this._manifest.minSdkVersion = v; return this }

  /** @param {number} n @returns {this} */
  minNodeVersion(n) { this._manifest.minNodeVersion = n; return this }

  /**
   * Valide et retourne le manifest final.
   * @returns {Record<string, unknown>}
   * @throws {Error} si le manifest est invalide
   */
  build() {
    const result = validateManifest(this._manifest)
    if (!result.valid) {
      throw new Error(`Manifest invalide : ${result.errors.join('; ')}`)
    }
    return { ...this._manifest }
  }
}

// ── createPlugin ───────────────────────────────────────────────────────────────

/**
 * Raccourci pour créer un manifest simple.
 * @param {string} name
 * @param {{ version?: string, description?: string, author?: string, hooks?: string[], categories?: string[] }} [opts]
 * @returns {Record<string, unknown>}
 */
function createPlugin(name, opts = {}) {
  const builder = new PluginBuilder(name)
    .version(opts.version || '1.0.0')
    .description(opts.description || '')

  if (opts.author)     builder.author(opts.author)
  if (opts.hooks)      builder.hooks(...opts.hooks)
  if (opts.categories) builder.categories(...opts.categories)

  return builder.build()
}

// ── searchPlugins ──────────────────────────────────────────────────────────────

/**
 * Recherche des plugins par nom/description et/ou catégorie.
 * @param {string} query
 * @param {{ category?: string, tag?: string, pluginsDir?: string }} [opts]
 * @returns {Array<{ name: string, manifest: object }>}
 */
function searchPlugins(query, opts = {}) {
  const plugins = listPlugins(opts.pluginsDir)
  const q = (query || '').toLowerCase()

  return plugins
    .filter(p => p.manifest !== null)
    .filter(p => {
      if (opts.category) {
        const cats = Array.isArray(p.manifest.categories) ? p.manifest.categories : []
        if (!cats.includes(opts.category)) return false
      }
      if (opts.tag) {
        const tags = Array.isArray(p.manifest.tags) ? p.manifest.tags : []
        if (!tags.includes(opts.tag)) return false
      }
      if (q === '') return true
      const inName = (p.name || '').toLowerCase().includes(q)
      const inDesc = (p.manifest.description || '').toLowerCase().includes(q)
      return inName || inDesc
    })
    .map(p => ({ name: p.name, manifest: p.manifest }))
}

// ── getPluginsByCategory ───────────────────────────────────────────────────────

/**
 * Retourne les plugins dont le manifest contient la catégorie donnée.
 * @param {string} category
 * @param {string} [pluginsDir]
 * @returns {Array<{ name: string, manifest: object }>}
 */
function getPluginsByCategory(category, pluginsDir) {
  return searchPlugins('', { category, pluginsDir })
}

// ── Exports ────────────────────────────────────────────────────────────────────

module.exports = {
  validateManifest,
  listPlugins,
  loadPlugin,
  semverCompare,
  createPlugin,
  searchPlugins,
  getPluginsByCategory,
  PluginBuilder,
  PLUGIN_EVENTS,
  LIFECYCLE_EVENTS,
  MANIFEST_SCHEMA,
  CURRENT_SDK_VERSION,
}
