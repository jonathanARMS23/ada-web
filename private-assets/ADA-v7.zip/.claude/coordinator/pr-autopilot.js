#!/usr/bin/env node
/**
 * coordinator/pr-autopilot.js — F3 PR Autopilot ADA
 *
 * Contrat public :
 *   createPR(runState, opts?)       → { prUrl, prNumber }
 *   postRunSummary(prNumber, runState) → void
 *   pollCIStatus(prNumber, opts?)   → 'success'|'failure'|'pending'|'timeout'
 *   buildPRBody(runState)           → string (markdown)
 *
 * Config lue depuis ~/.ada.json > clé `prAutopilot`.
 * GITHUB_TOKEN uniquement depuis process.env — jamais hardcodé.
 */

'use strict'

const { existsSync, readFileSync } = require('fs')
const { join }  = require('path')
const { homedir } = require('os')
const https     = require('https')
const { spawnSync } = require('child_process')

const ADA_JSON = join(homedir(), '.ada.json')

// ── Config ────────────────────────────────────────────────────────────────────

const PR_DEFAULTS = {
  enabled:      false,
  autoCreate:   false,
  baseBranch:   'main',
  draftPR:      false,
  notifyOnCI:   true,
}

/**
 * Charge la config prAutopilot depuis ~/.ada.json.
 * @returns {typeof PR_DEFAULTS}
 */
function loadPrConfig() {
  try {
    if (!existsSync(ADA_JSON)) return { ...PR_DEFAULTS }
    const ada = JSON.parse(readFileSync(ADA_JSON, 'utf8'))
    const raw = ada.prAutopilot || {}
    return {
      enabled:    typeof raw.enabled    === 'boolean' ? raw.enabled    : PR_DEFAULTS.enabled,
      autoCreate: typeof raw.autoCreate === 'boolean' ? raw.autoCreate : PR_DEFAULTS.autoCreate,
      baseBranch: typeof raw.baseBranch === 'string'  ? raw.baseBranch : PR_DEFAULTS.baseBranch,
      draftPR:    typeof raw.draftPR    === 'boolean' ? raw.draftPR    : PR_DEFAULTS.draftPR,
      notifyOnCI: typeof raw.notifyOnCI === 'boolean' ? raw.notifyOnCI : PR_DEFAULTS.notifyOnCI,
    }
  } catch {
    return { ...PR_DEFAULTS }
  }
}

// ── Erreur dédiée ─────────────────────────────────────────────────────────────

class GithubTokenMissing extends Error {
  constructor() {
    super('GITHUB_TOKEN absent de process.env — PR non créée')
    this.name = 'GithubTokenMissing'
    this.code = 'GITHUB_TOKEN_MISSING'
  }
}

// ── Git helpers ───────────────────────────────────────────────────────────────

/**
 * Extrait owner/repo depuis `git remote get-url origin`.
 * Supporte SSH (git@github.com:owner/repo.git) et HTTPS.
 * @returns {{ owner: string, repo: string }}
 */
function getGitRepo() {
  const r = spawnSync('git', ['remote', 'get-url', 'origin'], { encoding: 'utf8' })
  if (r.status !== 0) throw new Error('Impossible de lire le remote git origin')
  const url = r.stdout.trim()

  // SSH : git@github.com:owner/repo.git
  let m = url.match(/github\.com[:/]([^/]+)\/([^/]+?)(?:\.git)?$/)
  if (!m) throw new Error(`Remote URL non reconnue: ${url}`)
  return { owner: m[1], repo: m[2] }
}

/**
 * Retourne le SHA du dernier commit (court) sur la branche courante.
 * @returns {string}
 */
function getCurrentSha() {
  const r = spawnSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' })
  if (r.status !== 0) return ''
  return r.stdout.trim()
}

/**
 * Retourne le nom de la branche courante.
 * @returns {string}
 */
function getCurrentBranch() {
  const r = spawnSync('git', ['rev-parse', '--abbrev-ref', 'HEAD'], { encoding: 'utf8' })
  if (r.status !== 0) return 'main'
  return r.stdout.trim()
}

// ── HTTP helper ───────────────────────────────────────────────────────────────

/**
 * Effectue une requête HTTPS vers l'API GitHub.
 * @param {'GET'|'POST'} method
 * @param {string}       path   ex: '/repos/owner/repo/pulls'
 * @param {object|null}  body   body JSON (POST uniquement)
 * @param {string}       token  GITHUB_TOKEN
 * @returns {Promise<{ status: number, data: any }>}
 */
function githubRequest(method, path, body, token) {
  return new Promise((resolve, reject) => {
    const payload = body ? JSON.stringify(body) : null
    const options = {
      hostname: 'api.github.com',
      port:     443,
      path,
      method,
      headers: {
        'Accept':               'application/vnd.github+json',
        'Authorization':        `Bearer ${token}`,
        'User-Agent':           'ada-pr-autopilot/1.0',
        'X-GitHub-Api-Version': '2022-11-28',
        ...(payload ? {
          'Content-Type':   'application/json',
          'Content-Length': Buffer.byteLength(payload),
        } : {}),
      },
      timeout: 15000,
    }

    const req = https.request(options, res => {
      let raw = ''
      res.on('data', chunk => { raw += chunk })
      res.on('end', () => {
        let data = null
        try { data = JSON.parse(raw) } catch {}
        resolve({ status: res.statusCode, data })
      })
    })

    req.on('timeout', () => { req.destroy(); reject(new Error('GitHub API timeout')) })
    req.on('error', reject)

    if (payload) req.write(payload)
    req.end()
  })
}

// ── buildPRBody ───────────────────────────────────────────────────────────────

/**
 * Génère le corps de la PR en Markdown à partir du runState.
 * @param {object} runState
 * @returns {string}
 */
function buildPRBody(runState) {
  const {
    id: runId = '?',
    pipeline  = '?',
    startedAt,
    completedAt,
    totalCost   = 0,
    phases      = {},
  } = runState

  // Durée run
  let duration = '?'
  if (startedAt && completedAt) {
    const diffMs = new Date(completedAt) - new Date(startedAt)
    const diffMin = Math.floor(diffMs / 60000)
    const diffSec = Math.floor((diffMs % 60000) / 1000)
    duration = diffMin > 0 ? `${diffMin}m ${diffSec}s` : `${diffSec}s`
  }

  const phaseList = Object.entries(phases)
  const phaseCount = phaseList.length

  // Budget
  const budgetConfig = (() => {
    try {
      const bg = require('./budget-guard')
      return bg.loadBudgetConfig()
    } catch { return { perRun: 5 } }
  })()
  const perRun = budgetConfig.perRun ?? 5

  // ACW savings estimation (if acwContext present on any phase)
  let savedAcw = 0
  for (const [, p] of phaseList) {
    if (p.acwContext?.trajectories?.length) {
      // Estimation heuristique : 10% du coût de la phase économisé via contexte
      savedAcw += (p.cost ?? 0) * 0.10
    }
  }

  // Tableau des phases
  const phaseRows = phaseList.map(([phaseId, p]) => {
    const phaseDuration = (p.startedAt && p.completedAt)
      ? (() => {
          const ms = new Date(p.completedAt) - new Date(p.startedAt)
          const m  = Math.floor(ms / 60000)
          const s  = Math.floor((ms % 60000) / 1000)
          return m > 0 ? `${m}m ${s}s` : `${s}s`
        })()
      : '—'
    const statusIcon = p.status === 'completed' ? '✅'
                     : p.status === 'failed'    ? '❌'
                     : p.status === 'skipped'   ? '⏭️'
                     : '⏳'
    const tier = p.tier ?? '?'
    const cost = typeof p.cost === 'number' ? `$${p.cost.toFixed(4)}` : '—'
    return `| ${phaseId} | ${p.agent ?? '—'} | ${tier} | ${phaseDuration} | ${cost} | ${statusIcon} |`
  }).join('\n')

  const lines = [
    `## ADA Run Summary`,
    ``,
    `| Champ | Valeur |`,
    `|---|---|`,
    `| Run ID | \`${runId}\` |`,
    `| Pipeline | \`${pipeline}\` |`,
    `| Durée | \`${duration}\` |`,
    `| Coût total | \`$${totalCost.toFixed(4)}\` |`,
    `| Phases | \`${phaseCount}\` |`,
    ``,
    `### Phases`,
    ``,
    `| Phase | Agent | Tier | Durée | Coût | Statut |`,
    `|---|---|---|---|---|---|`,
    phaseRows,
    ``,
    `### Budget`,
    `- Coût run : \`$${totalCost.toFixed(4)}\` / limite \`$${perRun}\``,
    `- Économies ACW : \`$${savedAcw.toFixed(4)}\` (estimé)`,
    ``,
    `---`,
    `🤖 Généré par [ADA](https://github.com/jonathanARMS23/AI-Dev-Assistant) — run \`${runId}\``,
  ]

  return lines.join('\n')
}

// ── createPR ──────────────────────────────────────────────────────────────────

/**
 * Crée une PR GitHub pour le run ADA.
 * @param {object} runState
 * @param {{ baseBranch?: string, draft?: boolean }} [opts]
 * @returns {Promise<{ prUrl: string, prNumber: number }>}
 */
async function createPR(runState, opts = {}) {
  const token = process.env.GITHUB_TOKEN
  if (!token) throw new GithubTokenMissing()

  let owner, repo
  try {
    ({ owner, repo } = getGitRepo())
  } catch (e) {
    throw new Error(`createPR: ${e.message}`)
  }

  const prCfg     = loadPrConfig()
  const baseBranch = opts.baseBranch ?? prCfg.baseBranch ?? 'main'
  const draft      = opts.draft      ?? prCfg.draftPR    ?? false
  const headBranch = runState.branch || getCurrentBranch()
  const title      = `feat: ${runState.args?.name || runState.id}`
  const body       = buildPRBody(runState)

  const payload = {
    title,
    head:  headBranch,
    base:  baseBranch,
    body,
    draft,
  }

  let result
  try {
    result = await githubRequest('POST', `/repos/${owner}/${repo}/pulls`, payload, token)
  } catch (e) {
    throw new Error(`createPR: GitHub API error — ${e.message}`)
  }

  if (result.status === 201 && result.data?.number) {
    return {
      prUrl:    result.data.html_url,
      prNumber: result.data.number,
    }
  }

  // Gestion d'erreurs spécifiques
  const msg = result.data?.message ?? result.data?.errors?.[0]?.message ?? `HTTP ${result.status}`
  throw new Error(`createPR: GitHub API a retourné ${result.status} — ${msg}`)
}

// ── postRunSummary ────────────────────────────────────────────────────────────

/**
 * Poste un commentaire de résumé sur la PR (tableau des phases).
 * @param {number} prNumber
 * @param {object} runState
 * @returns {Promise<void>}
 */
async function postRunSummary(prNumber, runState) {
  const token = process.env.GITHUB_TOKEN
  if (!token) throw new GithubTokenMissing()

  let owner, repo
  try {
    ({ owner, repo } = getGitRepo())
  } catch (e) {
    throw new Error(`postRunSummary: ${e.message}`)
  }

  const { phases = {}, id: runId = '?', totalCost = 0 } = runState

  // Version courte : tableau des phases uniquement
  const phaseRows = Object.entries(phases).map(([phaseId, p]) => {
    const statusIcon = p.status === 'completed' ? '✅'
                     : p.status === 'failed'    ? '❌'
                     : p.status === 'skipped'   ? '⏭️'
                     : '⏳'
    const cost = typeof p.cost === 'number' ? `$${p.cost.toFixed(4)}` : '—'
    return `| ${phaseId} | ${p.agent ?? '—'} | ${cost} | ${statusIcon} |`
  }).join('\n')

  const body = [
    `### Résumé des phases — run \`${runId}\``,
    ``,
    `| Phase | Agent | Coût | Statut |`,
    `|---|---|---|---|`,
    phaseRows,
    ``,
    `**Coût total :** \`$${totalCost.toFixed(4)}\``,
  ].join('\n')

  try {
    await githubRequest('POST', `/repos/${owner}/${repo}/issues/${prNumber}/comments`, { body }, token)
  } catch (e) {
    throw new Error(`postRunSummary: ${e.message}`)
  }
}

// ── pollCIStatus ──────────────────────────────────────────────────────────────

/**
 * Monitore les check-runs GitHub CI pour une PR.
 * Utilise Atomics.wait pour les pauses (pas de setTimeout).
 *
 * @param {number} prNumber
 * @param {{ maxWaitMs?: number, intervalMs?: number, sha?: string }} [opts]
 * @returns {Promise<'success'|'failure'|'pending'|'timeout'>}
 */
async function pollCIStatus(prNumber, opts = {}) {
  const token = process.env.GITHUB_TOKEN
  if (!token) throw new GithubTokenMissing()

  const maxWaitMs  = opts.maxWaitMs  ?? 300_000  // 5 min
  const intervalMs = opts.intervalMs ?? 15_000   // 15s
  const sharedBuf  = new SharedArrayBuffer(4)
  const sharedArr  = new Int32Array(sharedBuf)

  let owner, repo
  try {
    ({ owner, repo } = getGitRepo())
  } catch (e) {
    throw new Error(`pollCIStatus: ${e.message}`)
  }

  // Récupérer le SHA de la PR (HEAD de la branche)
  let sha = opts.sha
  if (!sha) {
    try {
      const prResult = await githubRequest('GET', `/repos/${owner}/${repo}/pulls/${prNumber}`, null, token)
      if (prResult.status === 200 && prResult.data?.head?.sha) {
        sha = prResult.data.head.sha
      }
    } catch {}
    if (!sha) sha = getCurrentSha()
  }

  if (!sha) return 'pending'

  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms))
  const deadline = Date.now() + maxWaitMs

  while (Date.now() < deadline) {
    let result
    try {
      result = await githubRequest('GET', `/repos/${owner}/${repo}/commits/${sha}/check-runs?per_page=100`, null, token)
    } catch {
      // Erreur réseau transitoire → on continue à poller
      await sleep(intervalMs)
      continue
    }

    if (result.status !== 200) {
      await sleep(intervalMs)
      continue
    }

    const checkRuns = result.data?.check_runs ?? []

    // Pas encore de check-runs → CI n'a pas démarré
    if (checkRuns.length === 0) {
      await sleep(intervalMs)
      continue
    }

    // Vérifier si tous les checks sont terminés
    const allCompleted = checkRuns.every(cr => cr.status === 'completed')
    if (!allCompleted) {
      await sleep(intervalMs)
      continue
    }

    // Tous completed → analyser les conclusions
    const allSuccess = checkRuns.every(cr => cr.conclusion === 'success' || cr.conclusion === 'neutral' || cr.conclusion === 'skipped')
    return allSuccess ? 'success' : 'failure'
  }

  return 'timeout'
}

// ── Exports ───────────────────────────────────────────────────────────────────

module.exports = {
  createPR,
  postRunSummary,
  pollCIStatus,
  buildPRBody,
  loadPrConfig,
  GithubTokenMissing,
}
