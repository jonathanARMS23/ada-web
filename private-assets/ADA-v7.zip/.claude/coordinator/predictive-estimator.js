#!/usr/bin/env node
/**
 * coordinator/predictive-estimator.js — Estimation préventive durée/coût/succès
 *
 * Fonctions publiques :
 *   estimateRun(phases, routerState)  → PhaseEstimate[]
 *   formatEstimate(estimates)         → string (tableau ASCII)
 */

'use strict'

// ── Prix par tier (dérivés de models.js — source unique de vérité, pas de table dupliquée) ──
// Tarifs en USD / 1 000 000 tokens (input uniquement pour l'estimation)
const { TIER_MODELS, PRICING } = require('./models.js')
/** @type {Record<number, number>} */
const PRICE_PER_TOKEN_BY_TIER = Object.fromEntries(
  Object.entries(TIER_MODELS).map(([tier, model]) => [Number(tier), PRICING[model].input / 1e6])
)

/** Tier par défaut si non spécifié */
const DEFAULT_TIER     = 2
/** Tokens moyens par défaut (absence de prior) */
const DEFAULT_TOKENS   = 50_000
/** Durée par défaut en ms (absence de prior) */
const DEFAULT_DURATION = 30_000

/**
 * @typedef {{
 *   phaseId: string,
 *   agent: string,
 *   tier: number,
 *   estimatedTokens: number,
 *   estimatedCostUsd: number,
 *   estimatedDurationMs: number,
 *   successRate: number
 * }} PhaseEstimate
 */

/**
 * @typedef {{
 *   alpha: number,
 *   beta: number,
 *   successes?: number,
 *   failures?: number,
 *   meanTokens?: number,
 *   meanDurationMs?: number,
 *   meanDuration?: number
 * }} Prior
 */

/**
 * @typedef {{ priors: Record<string, Prior>, totalUpdates?: number }} RouterState
 */

// ── Core ──────────────────────────────────────────────────────────────────────

/**
 * Estime durée / coût / succès pour chaque phase d'un run.
 * Pur (pas de I/O) — toutes les données proviennent des paramètres.
 *
 * @param {Array<{ id: string, agent?: string, tier?: number }>} phases
 * @param {RouterState} routerState
 * @returns {PhaseEstimate[]}
 */
function estimateRun(phases, routerState) {
  if (!Array.isArray(phases)) return []
  const priors = (routerState && routerState.priors) || {}

  return phases.map(phase => {
    const phaseId = phase.id || ''
    const agent   = phase.agent || ''
    const tier    = typeof phase.tier === 'number' ? phase.tier : DEFAULT_TIER

    // Chercher le prior dans l'ordre : "phaseId:agent" puis "phaseId" seul
    const priorKey  = agent ? `${phaseId}:${agent}` : phaseId
    const prior     = priors[priorKey] || priors[phaseId] || null

    // Taux de succès (Thompson mean de Beta(α, β))
    const alpha = prior && typeof prior.alpha === 'number' ? prior.alpha : 1
    const beta  = prior && typeof prior.beta  === 'number' ? prior.beta  : 1
    const successRate = alpha / (alpha + beta)

    // Tokens estimés
    const estimatedTokens = (prior && typeof prior.meanTokens === 'number' && prior.meanTokens > 0)
      ? Math.round(prior.meanTokens)
      : DEFAULT_TOKENS

    // Coût estimé
    const pricePerToken   = PRICE_PER_TOKEN_BY_TIER[tier] || PRICE_PER_TOKEN_BY_TIER[DEFAULT_TIER]
    const estimatedCostUsd = estimatedTokens * pricePerToken

    // Durée estimée
    // B6 (bug jumeau) — le nom canonique est `meanDurationMs` : c'est ce que
    // router.updateDurationMean() ÉCRIT et ce que moe-router lit. Ce fichier
    // lisait `meanDuration`, qui n'existe nulle part → la durée estimée retombait
    // systématiquement sur DEFAULT_DURATION (30s) même avec un historique complet.
    // `meanDuration` reste accepté en lecture seule pour d'éventuels états legacy.
    const meanDurationMs = (prior && typeof prior.meanDurationMs === 'number' && prior.meanDurationMs > 0)
      ? prior.meanDurationMs
      : (prior && typeof prior.meanDuration === 'number' && prior.meanDuration > 0 ? prior.meanDuration : null)
    const estimatedDurationMs = meanDurationMs !== null
      ? Math.round(meanDurationMs)
      : DEFAULT_DURATION

    return {
      phaseId,
      agent,
      tier,
      estimatedTokens,
      estimatedCostUsd,
      estimatedDurationMs,
      successRate,
    }
  })
}

// ── Formatage ASCII ───────────────────────────────────────────────────────────

/**
 * Formate les estimations en un tableau ASCII lisible pour le CLI.
 * @param {PhaseEstimate[]} estimates
 * @returns {string}
 */
function formatEstimate(estimates) {
  if (!Array.isArray(estimates) || estimates.length === 0) {
    return '(aucune estimation disponible)'
  }

  // Calculs totaux
  let totalCost = 0
  let totalDuration = 0
  for (const e of estimates) {
    totalCost     += e.estimatedCostUsd
    totalDuration += e.estimatedDurationMs
  }

  // Helpers de formatage
  function fmtCost(usd) {
    return '$' + usd.toFixed(2)
  }
  function fmtDuration(ms) {
    const secs = Math.round(ms / 1000)
    if (secs < 60) return `~${secs}s`
    const mins = Math.round(secs / 60)
    return `~${mins}min`
  }
  function fmtRate(rate) {
    return Math.round(rate * 100) + '%'
  }

  // Largeur dynamique des colonnes
  const COL_PHASE   = Math.max(16, ...estimates.map(e => e.phaseId.length)) + 2
  const COL_COST    = 12
  const COL_DURATION = 12
  const COL_SUCCESS = 9
  const TOTAL_WIDTH = COL_PHASE + COL_COST + COL_DURATION + COL_SUCCESS + 5  // separators

  function pad(str, len) {
    return String(str).padEnd(len)
  }

  const sep = '─'.repeat(TOTAL_WIDTH)
  const lines = []

  lines.push('┌' + '─'.repeat(TOTAL_WIDTH + 2) + '┐')
  lines.push(
    '│  ' +
    pad('Phase', COL_PHASE) +
    pad('Coût est.', COL_COST) +
    pad('Durée est.', COL_DURATION) +
    pad('Succès', COL_SUCCESS) +
    '│'
  )

  for (const e of estimates) {
    lines.push(
      '│  ' +
      pad(e.phaseId, COL_PHASE) +
      pad(fmtCost(e.estimatedCostUsd), COL_COST) +
      pad(fmtDuration(e.estimatedDurationMs), COL_DURATION) +
      pad(fmtRate(e.successRate), COL_SUCCESS) +
      '│'
    )
  }

  lines.push('│  ' + sep.padEnd(TOTAL_WIDTH) + '│')
  lines.push(
    '│  ' +
    pad('TOTAL', COL_PHASE) +
    pad(fmtCost(totalCost), COL_COST) +
    pad(fmtDuration(totalDuration), COL_DURATION) +
    pad('', COL_SUCCESS) +
    '│'
  )
  lines.push('└' + '─'.repeat(TOTAL_WIDTH + 2) + '┘')

  return lines.join('\n')
}

// ── Exports ───────────────────────────────────────────────────────────────────

module.exports = {
  estimateRun,
  formatEstimate,
}
