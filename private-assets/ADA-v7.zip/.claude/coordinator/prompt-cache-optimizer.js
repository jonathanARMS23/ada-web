#!/usr/bin/env node
'use strict'
/**
 * coordinator/prompt-cache-optimizer.js — Prompt Cache Optimizer
 *
 * Structures Anthropic API messages to maximise prompt-cache hit rate.
 * Tracks real savings via response headers.
 *
 * Public API:
 *   optimizeMessages(messages)         → Array   (pure function)
 *   trackCacheMetrics(headers)         → void
 *   getCacheStats()                    → { hitTokens, missTokens, savedUsd, hitRate, … }
 *   buildSystemBlock(static, dynamic)  → [{ type, text, cache_control? }]
 *
 * For tests, override the metrics file path:
 *   const pco = require('./prompt-cache-optimizer')
 *   pco._overrideMetricsFile('/tmp/test-metrics.json')
 */

const { readFileSync, writeFileSync, mkdirSync, renameSync, existsSync } = require('fs')
const { join, dirname } = require('path')
const os = require('os')

// ── Configuration ─────────────────────────────────────────────────────────────

// Default path; tests may override via _overrideMetricsFile()
let _metricsFile = join(os.homedir(), '.ada', 'logs', 'cache-metrics.json')

/**
 * Override the metrics file path (for testing only).
 * @param {string} filePath
 */
function _overrideMetricsFile(filePath) {
  _metricsFile = filePath
}

/** Sonnet 4.6 pricing: $3.00 input, $0.30 cache-read per 1M tokens */
const PRICE_INPUT_PER_1M      = 3.00
const PRICE_CACHE_READ_PER_1M = 0.30
const SAVINGS_PER_TOKEN = (PRICE_INPUT_PER_1M - PRICE_CACHE_READ_PER_1M) / 1_000_000

// ── Heuristics ────────────────────────────────────────────────────────────────

const RE_ISO_DATE  = /\d{4}-\d{2}-\d{2}T/
const RE_HEADING   = /^#/m
const RE_STABLE_KW = /micro-lessons|instructions/i

/**
 * Returns true if a text block is "stable" (good cache candidate):
 *  - starts with a markdown heading (#), OR
 *  - contains 'micro-lessons' or 'instructions', OR
 *  - length > 200 chars AND no recent ISO timestamp
 *
 * @param {string} text
 * @returns {boolean}
 */
function isStable(text) {
  if (typeof text !== 'string') return false
  if (RE_HEADING.test(text))   return true
  if (RE_STABLE_KW.test(text)) return true
  if (text.length > 200 && !RE_ISO_DATE.test(text)) return true
  return false
}

/**
 * Returns true if a text block is "dynamic" (must not be cached):
 *  - contains a recent ISO timestamp (\d{4}-\d{2}-\d{2}T)
 *
 * @param {string} text
 * @returns {boolean}
 */
function isDynamic(text) {
  if (typeof text !== 'string') return false
  return RE_ISO_DATE.test(text)
}

// ── optimizeMessages ──────────────────────────────────────────────────────────

/**
 * Reorders message content blocks so stable blocks come first with
 * cache_control on the LAST stable block, and dynamic blocks follow
 * without cache_control.
 *
 * Pure function — no side effects, no mutations of input.
 *
 * @param {Array<{ role: string, content: string | Array }>} messages
 * @returns {Array<{ role: string, content: Array }>}
 */
function optimizeMessages(messages) {
  if (!Array.isArray(messages)) return messages

  return messages.map(msg => {
    const blocks    = normalizeToBlocks(msg.content)
    const optimized = optimizeBlocks(blocks)
    return { ...msg, content: optimized }
  })
}

/**
 * Normalize message content to an array of { type, text, … } blocks.
 *
 * @param {string | Array} content
 * @returns {Array<{ type: string, text: string }>}
 */
function normalizeToBlocks(content) {
  if (typeof content === 'string') {
    return [{ type: 'text', text: content }]
  }
  if (Array.isArray(content)) {
    return content.map(b => {
      if (typeof b === 'string') return { type: 'text', text: b }
      return { ...b } // shallow clone
    })
  }
  return [{ type: 'text', text: String(content) }]
}

/**
 * Partition blocks into stable/dynamic/rest, strip existing cache_control,
 * place stable blocks first, add cache_control to the LAST stable block only.
 *
 * @param {Array<{ type: string, text?: string }>} blocks
 * @returns {Array<{ type: string, text?: string, cache_control?: object }>}
 */
function optimizeBlocks(blocks) {
  const stable  = []
  const dynamic = []
  const rest    = []

  for (const block of blocks) {
    const clean = stripCacheControl(block)
    const text  = typeof clean.text === 'string' ? clean.text : ''

    if (isDynamic(text)) {
      dynamic.push(clean)
    } else if (isStable(text)) {
      stable.push(clean)
    } else {
      rest.push(clean)
    }
  }

  // Add cache_control on the LAST stable block only
  if (stable.length > 0) {
    stable[stable.length - 1] = {
      ...stable[stable.length - 1],
      cache_control: { type: 'ephemeral' },
    }
  }

  // Render order: stable → unclassified rest → dynamic
  return [...stable, ...rest, ...dynamic]
}

/**
 * Remove cache_control from a block (immutably).
 *
 * @param {{ cache_control?: object }} block
 * @returns {object}
 */
function stripCacheControl(block) {
  if (!Object.prototype.hasOwnProperty.call(block, 'cache_control')) return block
  const { cache_control: _cc, ...rest } = block
  return rest
}

// ── buildSystemBlock ──────────────────────────────────────────────────────────

/**
 * Builds a system content array:
 *   - staticContent  → gets cache_control (stable, rarely changes)
 *   - dynamicContent → no cache_control (changes per request)
 *
 * @param {string} staticContent
 * @param {string} dynamicContent
 * @returns {Array<{ type: string, text: string, cache_control?: object }>}
 */
function buildSystemBlock(staticContent, dynamicContent) {
  const blocks = []

  if (staticContent) {
    blocks.push({
      type: 'text',
      text: staticContent,
      cache_control: { type: 'ephemeral' },
    })
  }

  if (dynamicContent) {
    blocks.push({
      type: 'text',
      text: dynamicContent,
    })
  }

  return blocks
}

// ── trackCacheMetrics ─────────────────────────────────────────────────────────

/**
 * Accumulates Anthropic cache header values into the persistent metrics file.
 * Silent no-op if headers are absent or carry zero values.
 *
 * Accepts:
 *   - WHATWG Headers (has .get())
 *   - Plain object  { 'anthropic-cache-read-input-tokens': '123', … }
 *   - Node http.IncomingMessage headers (same plain-object shape, keys lowercase)
 *
 * @param {object | Headers | null | undefined} responseHeaders
 */
function trackCacheMetrics(responseHeaders) {
  if (!responseHeaders) return

  const hitRaw  = getHeader(responseHeaders, 'anthropic-cache-read-input-tokens')
  const missRaw = getHeader(responseHeaders, 'anthropic-cache-creation-input-tokens')

  const hitTokensNew  = parseInt(hitRaw,  10) || 0
  const missTokensNew = parseInt(missRaw, 10) || 0

  if (hitTokensNew === 0 && missTokensNew === 0) return

  const stats = loadMetrics()

  stats.hitTokens  += hitTokensNew
  stats.missTokens += missTokensNew
  stats.savedUsd    = stats.savedUsd + hitTokensNew * SAVINGS_PER_TOKEN
  stats.calls      += 1
  stats.lastUpdated = new Date().toISOString()

  saveMetrics(stats)
}

/**
 * Normalised header value accessor.
 *
 * @param {object} headers
 * @param {string} name  — lowercase header name
 * @returns {string | null}
 */
function getHeader(headers, name) {
  if (!headers) return null
  if (typeof headers.get === 'function') return headers.get(name)
  const v = headers[name]
  if (v !== undefined && v !== null) return String(v)
  return null
}

// ── getCacheStats ─────────────────────────────────────────────────────────────

/**
 * Returns accumulated cache stats plus derived metrics.
 *
 * @returns {{
 *   hitTokens: number,
 *   missTokens: number,
 *   savedUsd: number,
 *   calls: number,
 *   lastUpdated: string,
 *   hitRate: number,
 *   projectedMonthlySavedUsd: number,
 * }}
 */
function getCacheStats() {
  const stats = loadMetrics()

  const total   = stats.hitTokens + stats.missTokens
  const hitRate = total > 0 ? stats.hitTokens / total : 0

  // Monthly projection: assume current data represents ~1 day of traffic
  const projectedMonthlySavedUsd = stats.calls > 0
    ? stats.savedUsd * 30
    : 0

  return {
    hitTokens:  stats.hitTokens,
    missTokens: stats.missTokens,
    savedUsd:   stats.savedUsd,
    calls:      stats.calls,
    lastUpdated: stats.lastUpdated,
    hitRate,
    projectedMonthlySavedUsd,
  }
}

// ── Metrics persistence ───────────────────────────────────────────────────────

function emptyMetrics() {
  return { hitTokens: 0, missTokens: 0, savedUsd: 0, calls: 0, lastUpdated: '' }
}

/**
 * Read metrics from disk; return zeros if absent or corrupt.
 *
 * @returns {{ hitTokens: number, missTokens: number, savedUsd: number, calls: number, lastUpdated: string }}
 */
function loadMetrics() {
  if (!existsSync(_metricsFile)) return emptyMetrics()
  try {
    const raw    = readFileSync(_metricsFile, 'utf8')
    const parsed = JSON.parse(raw)
    return {
      hitTokens:  Number(parsed.hitTokens)  || 0,
      missTokens: Number(parsed.missTokens) || 0,
      savedUsd:   Number(parsed.savedUsd)   || 0,
      calls:      Number(parsed.calls)      || 0,
      lastUpdated: String(parsed.lastUpdated || ''),
    }
  } catch (_) {
    return emptyMetrics()
  }
}

/**
 * Atomically write metrics (temp file + rename).
 * Creates the directory if it doesn't exist.
 * Best-effort — never throws.
 *
 * @param {{ hitTokens: number, missTokens: number, savedUsd: number, calls: number, lastUpdated: string }} stats
 */
function saveMetrics(stats) {
  try {
    mkdirSync(dirname(_metricsFile), { recursive: true })
    const tmp = _metricsFile + '.tmp'
    writeFileSync(tmp, JSON.stringify(stats, null, 2), 'utf8')
    renameSync(tmp, _metricsFile)
  } catch (_) {
    // Best-effort persistence — never crash the caller
  }
}

// ── Exports ───────────────────────────────────────────────────────────────────

module.exports = {
  // Public API
  optimizeMessages,
  trackCacheMetrics,
  getCacheStats,
  buildSystemBlock,
  // Internals exposed for testing
  isStable,
  isDynamic,
  normalizeToBlocks,
  optimizeBlocks,
  loadMetrics,
  // Test helper — override metrics file path
  _overrideMetricsFile,
}
