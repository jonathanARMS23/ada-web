#!/usr/bin/env node
'use strict'
/**
 * coordinator/provider-gateway.js — Multi-Provider LLM Gateway
 *
 * Abstraction unifiée pour Anthropic, OpenAI, DeepSeek et Ollama.
 * - Sélection par tier (1 cheap → 3 expensive)
 * - Circuit breaker : closed → open (3 failures/60s) → half-open (5min)
 * - Retry automatique (1x) avant comptage circuit breaker
 * - Timeout 10s par appel
 * - Embed : Ollama (free) → OpenAI text-embedding-3-small
 * - Aucune clé hardcodée : process.env[provider.envKey]
 *
 * Usage :
 *   const { createGateway } = require('./provider-gateway')
 *   const gw = createGateway()
 *   const { content, tokens, provider, costUsd } = await gw.complete(messages, { tier: 2 })
 *   const vector = await gw.embed('text to embed')
 */

const https = require('https')
const http  = require('http')
const { join } = require('path')
const { existsSync, readFileSync } = require('fs')
const { TIER_MODELS, PRICING } = require('./models.js')

// ── Provider catalogue ────────────────────────────────────────────────────────

/** @type {Record<string, ProviderDef>} */
const PROVIDERS = {
  anthropic: {
    tier1: { model: TIER_MODELS[1], inputPrice: PRICING[TIER_MODELS[1]].input, outputPrice: PRICING[TIER_MODELS[1]].output },
    tier2: { model: TIER_MODELS[2], inputPrice: PRICING[TIER_MODELS[2]].input, outputPrice: PRICING[TIER_MODELS[2]].output },
    tier3: { model: TIER_MODELS[3], inputPrice: PRICING[TIER_MODELS[3]].input, outputPrice: PRICING[TIER_MODELS[3]].output },
    baseUrl: 'https://api.anthropic.com/v1',
    envKey: 'ANTHROPIC_API_KEY',
    embedModel: null,
  },
  openai: {
    tier1: { model: 'gpt-4o-mini', inputPrice: 0.15,  outputPrice: 0.60  },
    tier2: { model: 'gpt-4o',      inputPrice: 2.50,  outputPrice: 10.00 },
    tier3: { model: 'o3',          inputPrice: 10.00, outputPrice: 40.00 },
    baseUrl: 'https://api.openai.com/v1',
    envKey: 'OPENAI_API_KEY',
    embedModel: 'text-embedding-3-small',
  },
  deepseek: {
    tier1: { model: 'deepseek-chat',     inputPrice: 0.27, outputPrice: 1.10 },
    tier2: { model: 'deepseek-chat',     inputPrice: 0.27, outputPrice: 1.10 },
    tier3: { model: 'deepseek-reasoner', inputPrice: 0.55, outputPrice: 2.19 },
    baseUrl: 'https://api.deepseek.com/v1',
    envKey: 'DEEPSEEK_API_KEY',
    embedModel: null,
  },
  ollama: {
    tier1: { model: 'llama3.2:3b',  inputPrice: 0, outputPrice: 0 },
    tier2: { model: 'llama3.1:8b',  inputPrice: 0, outputPrice: 0 },
    tier3: { model: 'llama3.3:70b', inputPrice: 0, outputPrice: 0 },
    baseUrl: process.env.OLLAMA_URL || 'http://localhost:11434',
    envKey: null,
    embedModel: process.env.EMBED_MODEL || 'nomic-embed-text',
  },
}

// Default priority order when no user preference
const DEFAULT_ORDER = ['anthropic', 'openai', 'deepseek', 'ollama']

// ── Circuit breaker constants ─────────────────────────────────────────────────

const CB_WINDOW_MS     = 60_000  // 60s sliding window
const CB_THRESHOLD     = 3       // failures in window to open
const CB_HALF_OPEN_MS  = 5 * 60_000  // 5min before half-open probe

// ── Helpers ───────────────────────────────────────────────────────────────────

/**
 * Load ~/.ada.json providers config (best-effort, never throws).
 * @returns {{ preferred?: string[], disabled?: string[], preferCheap?: boolean }}
 */
function loadAdaConfig() {
  try {
    const adaJson = join(process.env.HOME || '', '.ada.json')
    if (!existsSync(adaJson)) return {}
    const raw = readFileSync(adaJson, 'utf8')
    const parsed = JSON.parse(raw)
    return parsed.providers || {}
  } catch {
    return {}
  }
}

/**
 * Simple JSON-over-HTTPS/HTTP POST with timeout.
 * @param {string} fullUrl
 * @param {object} headers
 * @param {object} body
 * @param {number} timeoutMs
 * @returns {Promise<object>}
 */
function jsonPost(fullUrl, headers, body, timeoutMs = 10_000) {
  return new Promise((resolve, reject) => {
    const url = new URL(fullUrl)
    const isHttps = url.protocol === 'https:'
    const lib = isHttps ? https : http
    const payload = JSON.stringify(body)

    const options = {
      hostname: url.hostname,
      port: url.port || (isHttps ? 443 : 80),
      path: url.pathname + url.search,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(payload),
        ...headers,
      },
    }

    const req = lib.request(options, (res) => {
      const chunks = []
      res.on('data', (d) => chunks.push(d))
      res.on('end', () => {
        const text = Buffer.concat(chunks).toString('utf8')
        try {
          const json = JSON.parse(text)
          if (res.statusCode >= 400) {
            const err = new Error(`HTTP ${res.statusCode}: ${json.error?.message || text}`)
            err.statusCode = res.statusCode
            err.body = json
            return reject(err)
          }
          resolve(json)
        } catch {
          reject(new Error(`Non-JSON response (${res.statusCode}): ${text.slice(0, 200)}`))
        }
      })
    })

    const timer = setTimeout(() => {
      req.destroy()
      reject(new Error(`Timeout after ${timeoutMs}ms`))
    }, timeoutMs)

    req.on('error', (e) => {
      clearTimeout(timer)
      reject(e)
    })

    req.on('close', () => clearTimeout(timer))
    req.write(payload)
    req.end()
  })
}

/**
 * Estimate cost in USD for given tokens and provider tier config.
 * Uses 1M-token pricing.
 */
function estimateCost(inputTokens, outputTokens, tierConfig) {
  return (
    (inputTokens  / 1_000_000) * tierConfig.inputPrice +
    (outputTokens / 1_000_000) * tierConfig.outputPrice
  )
}

// ── Provider-specific call adapters ──────────────────────────────────────────

/**
 * Call Anthropic Messages API.
 * @param {string} model
 * @param {object[]} messages
 * @param {string} apiKey
 * @returns {Promise<{ content: string, inputTokens: number, outputTokens: number }>}
 */
async function callAnthropic(model, messages, apiKey) {
  // Prompt cache optimizer — graceful no-op si module absent
  let optimized = messages
  let pco = null
  try {
    pco = require('./prompt-cache-optimizer')
    optimized = pco.optimizeMessages(messages)
  } catch {}

  const data = await jsonPost(
    'https://api.anthropic.com/v1/messages',
    {
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
      'anthropic-beta': 'prompt-caching-2024-07-31',
    },
    {
      model,
      max_tokens: 4096,
      messages: optimized,
    },
  )
  const content = data.content?.[0]?.text || ''

  // Tracker les économies cache depuis usage (cache_read_input_tokens, cache_creation_input_tokens)
  if (pco && data.usage) {
    try {
      pco.trackCacheMetrics({
        'anthropic-cache-read-input-tokens':     String(data.usage.cache_read_input_tokens    || 0),
        'anthropic-cache-creation-input-tokens': String(data.usage.cache_creation_input_tokens || 0),
      })
    } catch {}
  }

  return {
    content,
    inputTokens:  data.usage?.input_tokens  || 0,
    outputTokens: data.usage?.output_tokens || 0,
  }
}

/**
 * Call OpenAI-compatible Chat Completions API (OpenAI, DeepSeek).
 * @param {string} baseUrl
 * @param {string} model
 * @param {object[]} messages
 * @param {string} apiKey
 * @returns {Promise<{ content: string, inputTokens: number, outputTokens: number }>}
 */
async function callOpenAICompat(baseUrl, model, messages, apiKey) {
  const data = await jsonPost(
    `${baseUrl}/chat/completions`,
    { Authorization: `Bearer ${apiKey}` },
    { model, messages },
  )
  const content = data.choices?.[0]?.message?.content || ''
  return {
    content,
    inputTokens:  data.usage?.prompt_tokens     || 0,
    outputTokens: data.usage?.completion_tokens || 0,
  }
}

/**
 * Call Ollama generate API.
 * @param {string} baseUrl
 * @param {string} model
 * @param {object[]} messages
 * @returns {Promise<{ content: string, inputTokens: number, outputTokens: number }>}
 */
async function callOllama(baseUrl, model, messages) {
  const data = await jsonPost(
    `${baseUrl}/api/chat`,
    {},
    { model, messages, stream: false },
  )
  const content = data.message?.content || ''
  return {
    content,
    inputTokens:  data.prompt_eval_count || 0,
    outputTokens: data.eval_count        || 0,
  }
}

/**
 * Dispatch a completion call to the right adapter.
 */
async function dispatchComplete(providerName, providerDef, tierConfig, messages) {
  const apiKey = providerDef.envKey ? process.env[providerDef.envKey] : null

  switch (providerName) {
    case 'anthropic':
      return callAnthropic(tierConfig.model, messages, apiKey)

    case 'openai':
    case 'deepseek':
      return callOpenAICompat(providerDef.baseUrl, tierConfig.model, messages, apiKey)

    case 'ollama':
      return callOllama(providerDef.baseUrl, tierConfig.model, messages)

    default:
      throw new Error(`Unknown provider: ${providerName}`)
  }
}

/**
 * Embed via Ollama /api/embeddings.
 */
async function embedOllama(baseUrl, model, text) {
  const data = await jsonPost(
    `${baseUrl}/api/embeddings`,
    {},
    { model, prompt: text },
  )
  if (!Array.isArray(data.embedding)) throw new Error('Ollama embed: no embedding in response')
  return data.embedding
}

/**
 * Embed via OpenAI /v1/embeddings.
 */
async function embedOpenAI(apiKey, model, text) {
  const data = await jsonPost(
    'https://api.openai.com/v1/embeddings',
    { Authorization: `Bearer ${apiKey}` },
    { model, input: text },
  )
  const vec = data.data?.[0]?.embedding
  if (!Array.isArray(vec)) throw new Error('OpenAI embed: no embedding in response')
  return vec
}

// ── Circuit Breaker ───────────────────────────────────────────────────────────

/**
 * @typedef {'closed'|'open'|'half-open'} CBState
 * @typedef {{ state: CBState, failures: number[], openedAt: number|null }} CBEntry
 */

/** @param {Map<string, CBEntry>} cbMap */
function makeCB(cbMap) {
  function getEntry(name) {
    if (!cbMap.has(name)) cbMap.set(name, { state: 'closed', failures: [], openedAt: null })
    return cbMap.get(name)
  }

  function getState(name) {
    const e = getEntry(name)
    if (e.state === 'open') {
      if (Date.now() - e.openedAt >= CB_HALF_OPEN_MS) {
        e.state = 'half-open'
      }
    }
    return e.state
  }

  function recordSuccess(name) {
    const e = getEntry(name)
    e.state    = 'closed'
    e.failures = []
    e.openedAt = null
  }

  function recordFailure(name) {
    const e = getEntry(name)
    const now = Date.now()
    e.failures = e.failures.filter(t => now - t < CB_WINDOW_MS)
    e.failures.push(now)
    if (e.failures.length >= CB_THRESHOLD) {
      e.state    = 'open'
      e.openedAt = now
    }
  }

  return { getState, recordSuccess, recordFailure }
}

// ── createGateway ─────────────────────────────────────────────────────────────

/**
 * @typedef {object} CompleteOptions
 * @property {1|2|3} [tier]          - Model tier (default 2)
 * @property {boolean} [preferCheap] - Sort by inputPrice ascending
 * @property {number}  [maxCostUsd]  - Max estimated cost at 2000 tokens
 */

/**
 * @typedef {object} CompleteResult
 * @property {string}   content
 * @property {{ input: number, output: number }} tokens
 * @property {string}   provider
 * @property {number}   costUsd
 */

/**
 * Creates a gateway instance.
 * @param {object} [config]
 * @param {string[]} [config.preferred]   - Ordered provider names
 * @param {string[]} [config.disabled]    - Disabled provider names
 * @param {boolean}  [config.preferCheap] - Global prefer-cheap flag
 * @returns {GatewayInstance}
 */
function createGateway(config = {}) {
  // Merge config: explicit arg > ~/.ada.json > defaults
  const adaCfg    = loadAdaConfig()
  const preferred = config.preferred  || adaCfg.preferred  || DEFAULT_ORDER
  const disabled  = config.disabled   || adaCfg.disabled   || []
  const gPreferCheap = config.preferCheap ?? adaCfg.preferCheap ?? false

  /** @type {Map<string, CBEntry>} */
  const cbMap = new Map()
  const cb    = makeCB(cbMap)

  /**
   * Check if a provider has an API key (or doesn't need one).
   */
  function hasCredential(name) {
    const def = PROVIDERS[name]
    if (!def) return false
    if (!def.envKey) return true                 // Ollama — no key needed
    return !!process.env[def.envKey]
  }

  /**
   * Returns provider names that are active (not disabled, have creds, circuit not open).
   * @returns {string[]}
   */
  function getAvailableProviders() {
    return preferred.filter(name => {
      if (!PROVIDERS[name])          return false
      if (disabled.includes(name))   return false
      if (!hasCredential(name))      return false
      const state = cb.getState(name)
      return state === 'closed' || state === 'half-open'
    })
  }

  /**
   * Select and sort candidates for a completion call.
   * @param {CompleteOptions} opts
   * @returns {Array<{ name: string, tierConfig: object, def: object }>}
   */
  function selectCandidates(opts = {}) {
    const tier     = opts.tier       || 2
    const cheap    = opts.preferCheap ?? gPreferCheap
    const maxCost  = opts.maxCostUsd

    const available = getAvailableProviders()

    let candidates = available.map(name => {
      const def        = PROVIDERS[name]
      const tierKey    = `tier${tier}`
      const tierConfig = def[tierKey]
      return { name, tierConfig, def }
    })

    // Filter by maxCostUsd (estimate at 2000 tokens)
    if (maxCost !== undefined) {
      candidates = candidates.filter(({ tierConfig }) => {
        const est = estimateCost(2000, 500, tierConfig)
        return est <= maxCost
      })
    }

    // Sort: cheap first, or by preferred order
    if (cheap) {
      candidates.sort((a, b) => a.tierConfig.inputPrice - b.tierConfig.inputPrice)
    }

    return candidates
  }

  /**
   * Attempt one provider call with 1 automatic retry.
   * Records circuit breaker outcomes.
   */
  async function tryProvider(name, def, tierConfig, messages) {
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        const result = await dispatchComplete(name, def, tierConfig, messages)
        cb.recordSuccess(name)
        return result
      } catch (err) {
        if (attempt === 0) continue  // one silent retry
        // Second failure → record to circuit breaker
        cb.recordFailure(name)
        throw err
      }
    }
  }

  // ── Public API ──────────────────────────────────────────────────────────────

  /**
   * Run a completion against the best available provider.
   * @param {object[]} messages - Array of { role, content }
   * @param {CompleteOptions} [opts]
   * @returns {Promise<CompleteResult>}
   */
  async function complete(messages, opts = {}) {
    const candidates = selectCandidates(opts)

    if (candidates.length === 0) {
      const err = new Error('AllProvidersUnavailable: no provider could handle this request')
      err.code = 'AllProvidersUnavailable'
      throw err
    }

    const errors = []
    for (const { name, tierConfig, def } of candidates) {
      const state = cb.getState(name)
      if (state === 'open') continue  // re-check (half-open transitions happen in getState)

      try {
        const raw = await tryProvider(name, def, tierConfig, messages)
        const costUsd = estimateCost(raw.inputTokens, raw.outputTokens, tierConfig)

        return {
          content:  raw.content,
          tokens:   { input: raw.inputTokens, output: raw.outputTokens },
          provider: name,
          model:    tierConfig.model,
          costUsd,
        }
      } catch (err) {
        errors.push(`${name}: ${err.message}`)
        // Continue to next candidate
      }
    }

    const err = new Error(
      `AllProvidersUnavailable: all providers failed — ${errors.join(' | ')}`,
    )
    err.code   = 'AllProvidersUnavailable'
    err.errors = errors
    throw err
  }

  /**
   * Embed text using Ollama (preferred, free) or OpenAI fallback.
   * @param {string} text
   * @returns {Promise<number[]>}
   */
  async function embed(text) {
    // Try Ollama first (free, local)
    if (!disabled.includes('ollama')) {
      const state = cb.getState('ollama')
      if (state !== 'open') {
        try {
          const ollamaDef = PROVIDERS.ollama
          const vec = await embedOllama(ollamaDef.baseUrl, ollamaDef.embedModel, text)
          cb.recordSuccess('ollama')
          return vec
        } catch {
          cb.recordFailure('ollama')
          // Fall through to OpenAI
        }
      }
    }

    // Fallback: OpenAI text-embedding-3-small
    if (!disabled.includes('openai') && hasCredential('openai')) {
      const state = cb.getState('openai')
      if (state !== 'open') {
        try {
          const vec = await embedOpenAI(
            process.env[PROVIDERS.openai.envKey],
            PROVIDERS.openai.embedModel,
            text,
          )
          cb.recordSuccess('openai')
          return vec
        } catch {
          cb.recordFailure('openai')
        }
      }
    }

    const err = new Error('AllProvidersUnavailable: no embed provider available (tried Ollama, OpenAI)')
    err.code = 'AllProvidersUnavailable'
    throw err
  }

  /**
   * Current circuit breaker state for a provider.
   * @param {string} providerName
   * @returns {CBState}
   */
  function getCircuitState(providerName) {
    return cb.getState(providerName)
  }

  return { complete, embed, getAvailableProviders, getCircuitState }
}

// ── CLI (thin wrapper for quick testing) ─────────────────────────────────────

if (require.main === module) {
  const [,, cmd, ...args] = process.argv

  async function main() {
    const gw = createGateway()

    if (cmd === 'providers') {
      console.log('Available:', gw.getAvailableProviders().join(', '))
      return
    }

    if (cmd === 'complete') {
      const userMsg = args.join(' ') || 'Hello, say hi briefly.'
      const result  = await gw.complete([{ role: 'user', content: userMsg }], { tier: 1 })
      console.log(`[${result.provider}/${result.model}] $${result.costUsd.toFixed(6)}`)
      console.log(result.content)
      return
    }

    if (cmd === 'embed') {
      const text = args.join(' ') || 'test embedding'
      const vec  = await gw.embed(text)
      console.log(`Vector length: ${vec.length}, first 4: ${vec.slice(0, 4).map(v => v.toFixed(4)).join(', ')}`)
      return
    }

    console.error('Usage: node provider-gateway.js <providers|complete [text]|embed [text]>')
    process.exit(1)
  }

  main().catch(err => { console.error(err.message); process.exit(1) })
}

// ── Exports ───────────────────────────────────────────────────────────────────

module.exports = { createGateway, PROVIDERS }
