#!/usr/bin/env node
/**
 * coordinator/router.js — Thompson Sampling Router
 *
 * Routing adaptatif : choisit l'agent optimal pour chaque type de phase
 * en se basant sur l'historique des succès/échecs via Beta distribution.
 *
 * Principe Thompson Sampling :
 *  - Chaque (phaseType, agent) maintient un prior Beta(α, β)
 *  - α = succès + 1 (prior optimiste)   β = échecs + 1
 *  - Pour router : sample θ ~ Beta(α, β) pour chaque candidat → prendre le max
 *  - Sur succès : α++   Sur échec : β++
 *  - Plus on a de données, moins on explore (exploitation naturelle)
 *
 * CLI :
 *   node router.js recommend <phaseType>            → agent recommandé
 *   node router.js update <phaseType> <agent> <success|failure> [--tokens <n>]
 *   node router.js seed                             → bootstrap depuis runs/ (inclut tokens)
 *   node router.js stats                            → tableau des priors + efficiency
 *   node router.js reset <phaseType> [agent]        → réinitialiser
 *   node router.js model <1|2|3>                   → modèle recommandé pour un tier
 *
 * Module :
 *   const { recommend, update, recommendModel } = require('./router.js')
 */

/**
 * @typedef {{ alpha: number, beta: number, successes: number, failures: number, meanTokens?: number, tokenSamples?: number, meanDurationMs?: number, durationSamples?: number, lastUpdatedAt?: string }} Prior
 * @typedef {{ priors: Record<string, Prior>, totalUpdates: number, lastUpdated?: string, decayAppliedAt?: string }} RouterState
 * @typedef {{ agent: string|null, confidence: 'high'|'medium'|'low'|'none'|'context'|'stack'|'booster'|number, winRate: number|null, sample: number, efficiencySample?: number, stackSource?: 'context'|'detected'|'default', reason: string }} RecommendResult
 * @typedef {{ candidates?: string[], contextHint?: string|null, cwd?: string }} RecommendOpts
 */

const { readFileSync, writeFileSync, existsSync, mkdirSync, readdirSync, renameSync, openSync, unlinkSync, statSync } = require('fs')
const { spawnSync } = require('child_process')
const { join } = require('path')

const CONFIG_DIR    = process.env.CLAUDE_CONFIG_DIR || join(process.env.HOME ?? '', '.claude')
const COORD_DIR     = join(CONFIG_DIR, 'coordinator')
const RUNS_DIR      = join(CONFIG_DIR, 'runs')
const STATE_FILE    = join(COORD_DIR, 'router-state.json')

// ── Agents candidats par type de phase ───────────────────────────────────────
//
// PHASE_CANDIDATES = choix RÉELLEMENT SUBSTITUABLES, seuls légitimes à être
// arbitrés par Thompson Sampling : plusieurs agents objectivement qualifiés pour
// la même phase, sans dépendance à la stack du projet. Ce que Thompson apprend
// alors est une vraie préférence de qualité.
//
// ⚠ Ce qui N'A RIEN à faire ici (bug B1) : une stack contre une autre. Voir
// STACK_FAMILIES ci-dessous — nestjs↔drf, ios↔android, web↔mobile ne sont pas
// des variantes dont on peut apprendre « laquelle est meilleure » : un projet
// est NestJS OU Django. Ces familles sont résolues DÉTERMINISTEMENT.
//
// Les phases avec un seul candidat sont quand même tracées (routerUpdate écrit
// leur prior) : ces priors ne sont pas morts — ils alimentent
// predictive-estimator (meanTokens/meanDurationMs/successRate), `router stats`,
// `ewc report` et never-worse. Seule l'ARBITRAGE Thompson est réservée aux
// entrées à ≥2 candidats.
//
// ⚠ La table est indexée par phase.id NU, or un même id existe dans plusieurs
// pipelines avec des agents de familles différentes ('review' = reviewer dans
// feature/hotfix, technical-architect dans api-design, performance-analyst dans
// perf-audit). run.js:selectAgentForPhase applique donc un garde-fou : le router
// n'est consulté que si l'agent DÉCLARÉ par le pipeline fait partie des
// candidats — jamais de substitution entre familles d'agents.

/** @type {Record<string, string[]>} */
const PHASE_CANDIDATES = {
  // ── Phases de pipeline (pipelines.json) ─────────────────────────────────────
  // Audit B2 : sur les 13 pipelines / ~50 phases de pipelines.json, la grande
  // majorité n'a qu'UN agent objectivement qualifié (schema→db, specs→tester,
  // deploy→devops, apply→db…). Les 4 phases ci-dessous sont les seules avec un
  // vrai choix substituable — constaté, pas inventé pour gonfler la couverture.
  schema:   ['db'],
  specs:    ['tester'],
  frontend: ['nextjs'],
  coverage: ['tester'],
  deploy:   ['devops'],
  // review (feature/hotfix/bug-fix/review) : un diff peut légitimement être relu
  // par le reviewer généraliste OU par le security-auditor (revue orientée
  // sécurité). Choix indépendant de la stack → Thompson pertinent.
  review:       ['reviewer', 'security-auditor'],
  // deps (security-audit) : audit de dépendances/CVE — reviewer ou security-auditor.
  deps:         ['reviewer', 'security-auditor'],
  // safety (migration) : safety-check d'une migration (idempotence, rollback,
  // index concurrents) — reviewer généraliste ou migration-strategist spécialiste.
  safety:       ['reviewer', 'migration-strategist'],
  // data-model (saas-bootstrap) : modélisation DB — data-modeler ou db.
  'data-model': ['data-modeler', 'db'],
  // Absents volontairement (stack, pas apprentissage — B1) :
  //   backend / fix / mobile → cf. STACK_FAMILIES + run.js:selectAgentForPhase
  // Absents volontairement (un seul agent qualifié) : diff, generate, apply,
  //   unit, integration, diagnose, regression, design, verify, api-contract,
  //   auth, profile, db-audit, fixes, scan, requirements, contract, docs, plan,
  //   expand, migrate-data, rollback-expand.
  //
  // ── Types de tâches générales (hors pipeline) ───────────────────────────────
  'task:db':            ['db'],
  'task:review':        ['reviewer', 'security-auditor'],
  'task:devops':        ['devops'],
  'task:test':          ['tester'],
  // Agents spécialisés — spécialiste vs généraliste DANS la même stack : vrai choix
  'task:graphql':       ['graphql', 'nestjs'],
  'task:realtime':      ['realtime'],
  'task:k8s':           ['k8s', 'devops'],
  'task:observability': ['observability'],
  // Agents IA & spécialisés
  'task:ai':            ['ai-engineer', 'agent-architect'],
  'task:ai-backend':    ['python-backend', 'ai-engineer'],
  'task:ai-infra':      ['ml-ops', 'perception-engineer'],
  'task:ai-security':   ['sandbox-security', 'security-auditor'],
  'task:memory':        ['memory-engineer', 'ai-engineer'],
  // Agents design & architecture
  'task:architecture':  ['feature-architect', 'technical-architect'],
  'task:design':        ['ux-designer', 'feature-architect'],
  'task:data':          ['data-modeler', 'db', 'migration-strategist'],
  // Mobile natif — plateforme unique, pas de choix
  'task:ios':           ['swift'],
  'task:android':       ['android'],
  // Business
  'task:business':      ['business-researcher', 'financial-analyst'],
}

// ── Familles de stacks mutuellement exclusives (JAMAIS apprises) ─────────────
//
// B1 — repro du bug corrigé : avec des priors nestjs 30✓ / drf 30✓ et un contexte
// projet 'nestjs' explicite, recommendWithContext routait encore vers drf ~46% du
// temps : le garde-fou contextuel ne s'appliquait qu'en confiance low/none, or dès
// n≥4 la confiance montait à medium/high et écrasait le contexte. Un projet NestJS
// recevait donc un agent Django une fois sur deux.
//
// Règle : dès que TOUS les candidats d'un choix appartiennent à la même famille,
// la sélection est DÉTERMINISTE et l'ordre de priorité est absolu :
//   1. contexte explicite (--backend / state.args.backend)  ← ne peut PAS être écrasé
//   2. stack réellement détectée sur le disque (marqueurs ci-dessous)
//   3. premier candidat déclaré (défaut documenté)
// Thompson n'intervient jamais. Un mélange de familles (ex. ['graphql','nestjs'],
// spécialiste vs généraliste d'une même stack) reste arbitré par Thompson.

/** @type {Array<{ name: string, agents: string[] }>} */
const STACK_FAMILIES = [
  { name: 'backend',       agents: ['nestjs', 'drf'] },
  { name: 'web-vs-mobile', agents: ['nextjs', 'react-native'] },
  { name: 'mobile',        agents: ['react-native', 'android', 'swift'] },
]

/**
 * Choix de stack connus, retirés de PHASE_CANDIDATES pour ne plus être arbitrés
 * par Thompson mais toujours résolvables (recommend / CLI / control plane
 * retournent un agent déterministe au lieu de `null`).
 * @type {Record<string, string[]>}
 */
const STACK_PHASE_CANDIDATES = {
  backend:              ['nestjs', 'drf'],
  fix:                  ['nestjs', 'drf'],
  'task:backend':       ['nestjs', 'drf'],
  'task:frontend':      ['nextjs', 'react-native'],
  'task:mobile':        ['react-native', 'android', 'swift'],
  'task:mobile-native': ['android', 'swift'],
}

/**
 * Retourne la famille de stack d'un agent, ou null.
 * @param {string} agent
 * @returns {{ name: string, agents: string[] }|null}
 */
function stackFamilyOf(agent) {
  if (!agent) return null
  return STACK_FAMILIES.find(f => f.agents.includes(agent)) || null
}

/**
 * Un jeu de candidats est-il exclusivement une famille de stacks ?
 * (≥2 candidats ET tous membres de la MÊME famille)
 * @param {string[]} candidates
 * @returns {{ name: string, agents: string[] }|null}
 */
function stackExclusiveFamily(candidates) {
  if (!Array.isArray(candidates) || candidates.length < 2) return null
  for (const family of STACK_FAMILIES) {
    if (candidates.every(a => family.agents.includes(a))) return family
  }
  return null
}

// Marqueurs de stack sur disque — alignés sur bin/create.js:STACK_DETECTORS.
/** @type {Record<string, { files?: string[], pkgDeps?: string[], pyDeps?: string[] }>} */
const STACK_MARKERS = {
  nestjs:         { files: ['nest-cli.json'], pkgDeps: ['@nestjs/core'] },
  drf:            { files: ['manage.py'],     pyDeps:  ['djangorestframework', 'django'] },
  nextjs:         { files: ['next.config.js', 'next.config.mjs', 'next.config.ts'], pkgDeps: ['next'] },
  'react-native': { files: ['app.json'],      pkgDeps: ['expo', 'react-native'] },
  android:        { files: ['build.gradle', 'build.gradle.kts', 'settings.gradle'] },
  swift:          { files: ['Package.swift'] },
}

/** Cache de dépendances par répertoire (évite de relire package.json N fois). */
const _depsCache = new Map()

/** @param {string} dir @returns {{ pkg: Set<string>, py: Set<string> }} */
function readProjectDeps(dir) {
  if (_depsCache.has(dir)) return _depsCache.get(dir)
  const pkg = new Set(), py = new Set()
  try {
    const raw = JSON.parse(readFileSync(join(dir, 'package.json'), 'utf8'))
    for (const d of Object.keys({ ...raw.dependencies, ...raw.devDependencies })) pkg.add(d)
  } catch {}
  try {
    for (const line of readFileSync(join(dir, 'requirements.txt'), 'utf8').split('\n')) {
      const name = line.split(/[=<>!;\s]/)[0].trim().toLowerCase()
      if (name && !name.startsWith('#')) py.add(name)
    }
  } catch {}
  const deps = { pkg, py }
  _depsCache.set(dir, deps)
  return deps
}

/**
 * Détecte la stack réellement présente sur le disque parmi une liste de candidats.
 * Best-effort, purement lecture (jamais bloquant) — retourne null si indécidable.
 * @param {string[]} candidates
 * @param {string} [cwd]
 * @returns {string|null}
 */
function detectProjectStack(candidates, cwd = process.cwd()) {
  if (!Array.isArray(candidates)) return null
  const deps = readProjectDeps(cwd)
  for (const agent of candidates) {
    const m = STACK_MARKERS[agent]
    if (!m) continue
    if (m.files?.some(f => existsSync(join(cwd, f))))    return agent
    if (m.pkgDeps?.some(d => deps.pkg.has(d)))           return agent
    if (m.pyDeps?.some(d => deps.py.has(d)))             return agent
  }
  return null
}

/**
 * Résolution DÉTERMINISTE d'un choix de stack. Ne consulte JAMAIS les priors.
 * @param {string[]} candidates
 * @param {string|null} contextHint  stack explicitement déclarée (--backend, state.args.backend)
 * @param {{ cwd?: string }} [opts]
 * @returns {{ agent: string, source: 'context'|'detected'|'default' }}
 */
function resolveStackChoice(candidates, contextHint, opts = {}) {
  // 1. Contexte explicite — ABSOLU (aucun prior ne peut l'écraser)
  if (contextHint && candidates.includes(contextHint)) {
    return { agent: contextHint, source: 'context' }
  }
  // 2. Stack réellement détectée sur disque
  const detected = detectProjectStack(candidates, opts.cwd || process.cwd())
  if (detected) return { agent: detected, source: 'detected' }
  // 3. Défaut documenté = premier candidat déclaré
  return { agent: candidates[0], source: 'default' }
}

/**
 * Construit le RecommendResult déterministe d'un choix de stack.
 * @param {string} phaseType
 * @param {string[]} candidates
 * @param {string|null} contextHint
 * @param {{ cwd?: string }} [opts]
 * @returns {RecommendResult}
 */
function stackRecommendation(phaseType, candidates, contextHint, opts = {}) {
  const { agent, source } = resolveStackChoice(candidates, contextHint, opts)
  const state = loadState()
  const prior = getPrior(state, phaseType, agent)
  const total = prior.successes + prior.failures
  const REASONS = {
    context:  `Stack imposée par le contexte projet (${agent}) — choix déterministe, jamais arbitré par Thompson`,
    detected: `Stack détectée sur le disque (${agent}) — choix déterministe, jamais arbitré par Thompson`,
    default:  `Stack non déclarée et non détectée — défaut documenté ${agent} (candidats: ${candidates.join(', ')})`,
  }
  return {
    agent,
    confidence:  'stack',
    stackSource: source,
    winRate:     total > 0 ? prior.successes / total : null,
    // Déterministe : moyenne du prior, pas un tirage Beta (traçabilité du choix)
    sample:      prior.alpha / (prior.alpha + prior.beta),
    reason:      REASONS[source],
  }
}

// Modèle de coût — 3 tiers (ADR coût LLM — aligné run.js)
// tier 1 : Claude Haiku  (rapide, économique — coverage, vérifications simples)
// tier 2 : Claude Sonnet (équilibré — frontend, specs, migrations)
// tier 3 : Claude Opus   (raisonnement complexe — backend, review, architecture)
// Source unique de vérité : coordinator/models.js (évite la dérive multi-fichiers).
const { TIER_MODELS } = require('./models.js')

/**
 * Modèle recommandé pour un tier.
 *
 * ⚠ Le tier 0 (codemod déterministe, zéro appel LLM) n'a PAS de modèle par
 * conception : TIER_MODELS[0] n'existe pas et le `|| TIER_MODELS[2]` renvoie
 * silencieusement Sonnet. Les appelants qui partent d'un `classifyTask()` doivent
 * donc traiter le tier 0 AVANT d'appeler cette fonction — soit en exécutant le
 * codemod (ada.js: mode 'codemod'), soit en repliant explicitement sur le tier 2
 * quand le codemod est bypassé (`r.mode === 'codemod' ? 2 : r.tier`, cf. ada.js
 * --pipeline/--solo et bench-v2.routedModel). Bug B5 : bench-v2 facturait un
 * modèle payant pour une tâche tier 0 faute de cette garde.
 *
 * @param {number} tier
 * @returns {string}
 */
function recommendModel(tier) {
  return TIER_MODELS[tier] || TIER_MODELS[2]
}

// ── Statistiques par (phaseType, agent) ──────────────────────────────────────

const C = {
  reset: '\x1b[0m', bold: '\x1b[1m',
  green: '\x1b[32m', red: '\x1b[31m', yellow: '\x1b[33m',
  cyan: '\x1b[36m', gray: '\x1b[90m', blue: '\x1b[34m'
}

/** @param {string} p @returns {void} */
function ensureDir(p) { if (!existsSync(p)) mkdirSync(p, { recursive: true }) }

/**
 * Formate un compteur/paramètre potentiellement fractionnaire pour l'affichage.
 * α/β ET successes/failures deviennent fractionnaires après `decay` (B4) — sans
 * ça les CLI affichent « 9.499999999999998 ».
 * @param {number} n @returns {string}
 */
function fmtCount(n) {
  const v = Number(n) || 0
  return Number.isInteger(v) ? String(v) : v.toFixed(1)
}

const ROUTER_LOCK = STATE_FILE + '.lock'
const LOCK_TIMEOUT_MS = 5000

/** Acquiert le lock O_EXCL sur router-state.json (atomic, pas de TOCTOU). */
function acquireRouterLock() {
  // Tentative unique + nettoyage zombie — pas de Atomics.wait (interdit sur main thread Node.js 20+)
  try {
    const fd = openSync(ROUTER_LOCK, 'wx')
    writeFileSync(fd, String(process.pid))
    require('fs').closeSync(fd)
    return true
  } catch {
    // Lock tenu — nettoyer les zombies (lock > 8s)
    try {
      if (Date.now() - statSync(ROUTER_LOCK).mtimeMs > 8000) {
        unlinkSync(ROUTER_LOCK)
        const fd = openSync(ROUTER_LOCK, 'wx')
        writeFileSync(fd, String(process.pid))
        require('fs').closeSync(fd)
        return true
      }
    } catch (e) {
      require('./logger').warn('router', 'zombie lock cleanup failed — Thompson update skipped', { lock: ROUTER_LOCK, error: e?.message })
    }
    return false  // L'appelant (routerUpdate) est fire-and-forget — le skip est acceptable
  }
}

/** Relâche le lock. */
function releaseRouterLock() {
  try { if (existsSync(ROUTER_LOCK)) unlinkSync(ROUTER_LOCK) } catch {}
}

/** @returns {RouterState} */
function loadState() {
  try {
    if (existsSync(STATE_FILE)) return JSON.parse(readFileSync(STATE_FILE, 'utf8'))
  } catch (e) {
    if (e.code !== 'ENOENT') process.stderr.write(`[router] Impossible de parser router-state.json : ${e.message} — priors réinitialisés\n`)
  }
  return { priors: {}, lastUpdated: undefined, totalUpdates: 0 }
}

/** @param {RouterState} state @returns {void} */
function saveState(state) {
  ensureDir(COORD_DIR)
  state.lastUpdated = new Date().toISOString()
  const tmp = STATE_FILE + '.tmp'
  writeFileSync(tmp, JSON.stringify(state, null, 2))
  renameSync(tmp, STATE_FILE)
}

/** @param {string} phaseType @param {string} agent @returns {string} */
function priorKey(phaseType, agent) { return `${phaseType}:${agent}` }

/** @param {RouterState} state @param {string} phaseType @param {string} agent */
function getPrior(state, phaseType, agent) {
  const key = priorKey(phaseType, agent)
  return state.priors[key] || { alpha: 1, beta: 1, successes: 0, failures: 0 }
}

// ── Cost-efficiency constants ────────────────────────────────────────────────
//
// TOKEN_BASELINE : tokens "normaux" pour une phase tier 2 (Sonnet, tâche moyenne)
// COST_LAMBDA    : sensibilité au coût — 0 = pur Thompson, 1 = forte penalisation
// MIN_COST_SAMPLES : mesures minimales avant d'ajuster (évite le biais sur 1 run)

const TOKEN_BASELINE    = 2000
const COST_LAMBDA       = 0.25
const MIN_COST_SAMPLES  = 5

/**
 * Ajuste un sample Thompson par un facteur de coût log-linéaire.
 * Formula : efficiency = theta / (1 + λ * ln(1 + meanTokens / baseline))
 * Interprétation : un agent 2× plus coûteux doit avoir ~17% de succès en plus pour gagner.
 * @param {Prior} prior
 * @param {number} rawSample  résultat de sampleBeta(α, β)
 * @returns {number}
 */
function computeEfficiencySample(prior, rawSample) {
  if (!prior.meanTokens || (prior.tokenSamples || 0) < MIN_COST_SAMPLES) return rawSample
  const costFactor = 1 + COST_LAMBDA * Math.log1p(prior.meanTokens / TOKEN_BASELINE)
  return rawSample / costFactor
}

/**
 * Met à jour la moyenne de tokens avec l'algorithme de Welford (online, O(1)).
 * @param {Prior} prior
 * @param {number} tokens
 */
function updateTokenMean(prior, tokens) {
  if (typeof tokens !== 'number' || tokens <= 0) return
  prior.tokenSamples = (prior.tokenSamples || 0) + 1
  prior.meanTokens   = (prior.meanTokens || 0) + (tokens - (prior.meanTokens || 0)) / prior.tokenSamples
}

/**
 * Met à jour la durée moyenne d'une phase (Welford online mean).
 * @param {Prior} prior
 * @param {number} durationMs
 */
function updateDurationMean(prior, durationMs) {
  if (typeof durationMs !== 'number' || isNaN(durationMs) || durationMs <= 0) return
  prior.durationSamples = (prior.durationSamples || 0) + 1
  prior.meanDurationMs  = (prior.meanDurationMs || 0) + (durationMs - (prior.meanDurationMs || 0)) / prior.durationSamples
}

// ── Gamma / Beta sampling (Marsaglia-Tsang) ───────────────────────────────────

// Seam RNG injectable — défaut = Math.random (comportement prod IDENTIQUE).
// Permet de seeder un RNG déterministe dans les tests via _setRng / _resetRng.
let _rng = Math.random

/** Injecte un RNG déterministe (tests uniquement). @param {() => number} fn */
function _setRng(fn) { _rng = fn }
/** Restaure le RNG par défaut (Math.random). */
function _resetRng() { _rng = Math.random }

function normalSample() {
  // Box-Muller
  const u1 = _rng(), u2 = _rng()
  return Math.sqrt(-2 * Math.log(u1 + 1e-10)) * Math.cos(2 * Math.PI * u2)
}

/** @param {number} shape @returns {number} */
function sampleGamma(shape) {
  if (shape < 1) {
    return sampleGamma(shape + 1) * Math.pow(_rng() + 1e-10, 1 / shape)
  }
  const d = shape - 1 / 3
  const c = 1 / Math.sqrt(9 * d)
  for (let i = 0; i < 1000; i++) {
    const x = normalSample()
    const v = Math.pow(1 + c * x, 3)
    if (v <= 0) continue
    const u = _rng()
    if (u < 1 - 0.0331 * Math.pow(x, 4)) return d * v
    if (Math.log(u + 1e-10) < 0.5 * x * x + d * (1 - v + Math.log(v + 1e-10))) return d * v
  }
  return d // fallback
}

/** @param {number} alpha @param {number} beta @returns {number} */
function sampleBeta(alpha, beta) {
  const x = sampleGamma(alpha)
  const y = sampleGamma(beta)
  return x / (x + y + 1e-10)
}

// ── Core API ──────────────────────────────────────────────────────────────────

/**
 * Recommande l'agent optimal pour un type de phase via Thompson Sampling.
 * Si opts.content est fourni et qu'une règle Tier 0 est applicable, retourne '__booster__'.
 * @param {string} phaseType  ex: 'backend', 'task:frontend'
 * @param {RecommendOpts & { content?: string }} [opts]
 * @returns {RecommendResult}
 */
function recommend(phaseType, opts = {}) {
  // ── Tier 0 : Agent Booster (bypass LLM pour transformations déterministes) ──
  if (opts.content) {
    try {
      const { canBoost } = require('./agent-booster')
      const boost = canBoost({ type: phaseType, content: opts.content })
      if (boost.boosted) {
        return {
          agent:       '__booster__',
          tier:        0,
          confidence:  'booster',
          winRate:     1.0,
          sample:      1.0,
          reason:      `Agent Booster Tier 0 — règle: ${boost.rule} (${Math.round(boost.confidence * 100)}%)`,
          boosterRule: boost.rule,
        }
      }
    } catch {
      // agent-booster absent ou erreur → Thompson normal
    }
  }

  const state      = loadState()
  const candidates = opts.candidates || PHASE_CANDIDATES[phaseType] || STACK_PHASE_CANDIDATES[phaseType] || []

  if (!candidates.length) {
    return { agent: null, confidence: 0, sample: 0, reason: `Aucun candidat pour '${phaseType}'` }
  }

  // ── B1 — Choix de stack : déterministe, JAMAIS de tirage Thompson ───────────
  // Intercepte aussi les appels qui passent la paire explicitement via
  // opts.candidates (ex. run.js, control plane) — la garantie est absolue.
  if (stackExclusiveFamily(candidates)) {
    const hint = opts.contextHint || (typeof opts.context === 'string' ? opts.context : null)
    return stackRecommendation(phaseType, candidates, hint, opts)
  }

  if (candidates.length === 1) {
    const prior = getPrior(state, phaseType, candidates[0])
    const total = prior.successes + prior.failures
    const winRate = total > 0 ? prior.successes / total : null
    return {
      agent:      candidates[0],
      confidence: total > 5 ? 'high' : total > 0 ? 'medium' : 'none',
      winRate,
      sample:     sampleBeta(prior.alpha, prior.beta),
      reason:     total > 0
        ? `Seul candidat — ${fmtCount(prior.successes)}✓ ${fmtCount(prior.failures)}✗ (${Math.round((winRate || 0) * 100)}%)`
        : `Seul candidat — pas encore de données`
    }
  }

  // Thompson Sampling + cost-efficiency sur plusieurs candidats
  /** @type {string|null} */
  let best = null
  let bestEff = -1
  /** @type {Record<string, {sample: number, effSample: number, prior: Prior}>} */
  const samples = {}

  for (const agent of candidates) {
    const prior     = getPrior(state, phaseType, agent)
    const rawSample = sampleBeta(prior.alpha, prior.beta)
    const effSample = computeEfficiencySample(prior, rawSample)
    samples[agent]  = { sample: rawSample, effSample, prior }
    if (effSample > bestEff) { bestEff = effSample; best = agent }
  }

  const bestPrior = samples[best].prior
  const total     = bestPrior.successes + bestPrior.failures
  const winRate   = total > 0 ? bestPrior.successes / total : null
  const hasCost   = candidates.some(a => (samples[a].prior.tokenSamples || 0) >= MIN_COST_SAMPLES)

  const explanation = candidates.map(a => {
    const { sample, effSample, prior } = samples[a]
    const t = prior.successes + prior.failures
    const costStr = (prior.tokenSamples || 0) >= MIN_COST_SAMPLES
      ? ` ~${Math.round(prior.meanTokens || 0)}tk`
      : ''
    const effStr = hasCost ? ` eff=${effSample.toFixed(3)}` : ''
    return `${a}(θ=${sample.toFixed(3)}${effStr}${costStr} α=${fmtCount(prior.alpha)} β=${fmtCount(prior.beta)} n=${fmtCount(t)})`
  }).join(', ')

  // ── MoE blend optionnel (enrichit Thompson quand confiance basse) ───────────
  try {
    const { moeRecommend } = require('./moe-router.js')
    const candidateData = candidates.map(agent => ({
      agent,
      prior:          getPrior(state, phaseType, agent),
      thompsonSample: samples[agent].effSample,
    }))
    const moeResult = moeRecommend(phaseType, candidateData, opts.context || null)
    if (moeResult && moeResult.best !== best) {
      // MoE diverge de Thompson — utiliser MoE si confiance Thompson est basse
      const thompsonConf = total > 10 ? 'high' : total > 3 ? 'medium' : 'low'
      if (thompsonConf === 'low') {
        best = moeResult.best
        // Recalculer winRate et bestEff pour le nouvel agent
        const newPrior = getPrior(state, phaseType, best)
        const newTotal  = newPrior.successes + newPrior.failures
        return {
          agent:            best,
          confidence:       'low',
          winRate:          newTotal > 0 ? newPrior.successes / newTotal : null,
          sample:           samples[best]?.sample ?? sampleBeta(newPrior.alpha, newPrior.beta),
          efficiencySample: samples[best]?.effSample ?? 0,
          reason:           `[MoE override Thompson low-conf] ${explanation}`,
        }
      }
    }
  } catch {
    // moe-router absent ou erreur → résultat Thompson normal
  }

  return {
    agent:            best,
    confidence:       total === 0 ? 'none' : total > 10 ? 'high' : total > 3 ? 'medium' : 'low',
    winRate,
    sample:           samples[best].sample,
    efficiencySample: bestEff,
    reason:           explanation
  }
}

/**
 * Enregistre le résultat d'une phase et met à jour le prior.
 * @param {string} phaseType
 * @param {string} agent
 * @param {'success'|'failure'} outcome
 * @param {{ tokens?: number }} [opts]
 */
function update(phaseType, agent, outcome, opts = {}) {
  if (!['success', 'failure'].includes(outcome)) {
    throw new Error(`outcome doit être 'success' ou 'failure', reçu: '${outcome}'`)
  }

  if (!acquireRouterLock()) {
    process.stderr.write('[router] lock timeout sur router-state.json — update ignoré\n')
    return null
  }
  try {
    const state = loadState()
    const key   = priorKey(phaseType, agent)
    const prior = state.priors[key] || { alpha: 1, beta: 1, successes: 0, failures: 0 }

    if (outcome === 'success') {
      prior.alpha++
      prior.successes++
    } else {
      prior.beta++
      prior.failures++
    }

    // Tracking coût (Welford online mean — O(1), sans stocker tous les runs)
    if (typeof opts.tokens === 'number' && opts.tokens > 0) updateTokenMean(prior, opts.tokens)
    if (typeof opts.durationMs === 'number' && opts.durationMs > 0) updateDurationMean(prior, opts.durationMs)

    // B3 — horodatage du dernier renforcement : c'est la RÉCENCE (et non le
    // volume d'historique) qui détermine si le prior mérite la protection EWC
    // contre le decay. Sans ce champ, un prior est traité comme ancien.
    prior.lastUpdatedAt = new Date().toISOString()

    state.priors[key]  = prior
    state.totalUpdates = (state.totalUpdates || 0) + 1
    saveState(state)

    return { key, prior }
  } finally {
    releaseRouterLock()
  }
}

/**
 * Bootstrap les priors depuis les fichiers d'état des runs existants.
 */
function seed() {
  if (!existsSync(RUNS_DIR)) return { seeded: 0, runs: 0 }

  const state = loadState()
  let seededCount = 0, runCount = 0

  for (const runId of readdirSync(RUNS_DIR)) {
    const statePath = join(RUNS_DIR, runId, 'state.json')
    if (!existsSync(statePath)) continue
    runCount++

    let runState
    try { runState = JSON.parse(readFileSync(statePath, 'utf8')) } catch { continue }
    if (!runState.phases) continue

    for (const [phaseId, phase] of Object.entries(runState.phases)) {
      if (!phase.agent || !['completed', 'failed'].includes(phase.status)) continue

      const outcome = phase.status === 'completed' ? 'success' : 'failure'
      const key     = priorKey(phaseId, phase.agent)
      const prior   = state.priors[key] || { alpha: 1, beta: 1, successes: 0, failures: 0 }

      if (outcome === 'success') { prior.alpha++; prior.successes++ }
      else { prior.beta++; prior.failures++ }

      if (typeof phase.tokens === 'number' && phase.tokens > 0) {
        updateTokenMean(prior, phase.tokens)
      }

      // B3 — récence du prior = date réelle du run importé (pas « maintenant ») :
      // seeder d'anciens runs ne doit pas les faire passer pour récents.
      const runTs = Date.parse(phase.completedAt || phase.startedAt || '')
      const seedTs = Number.isFinite(runTs) ? new Date(runTs).toISOString() : new Date().toISOString()
      if (!prior.lastUpdatedAt || prior.lastUpdatedAt < seedTs) prior.lastUpdatedAt = seedTs

      state.priors[key] = prior
      seededCount++
    }
  }

  state.totalUpdates = (state.totalUpdates || 0) + seededCount
  saveState(state)
  return { seeded: seededCount, runs: runCount }
}

// ── CLI ───────────────────────────────────────────────────────────────────────

function cmdUpdate(args) {
  // Parse --tokens / --duration flags
  let tokens = null
  let durationMs = null
  const positional = []
  for (let i = 0; i < args.length; i++) {
    if ((args[i] === '--tokens' || args[i] === '-t') && i + 1 < args.length) {
      const v = parseInt(args[++i], 10)
      if (!isNaN(v) && v > 0) tokens = v
    } else if ((args[i] === '--duration' || args[i] === '-d') && i + 1 < args.length) {
      const v = parseInt(args[++i], 10)
      if (!isNaN(v) && v > 0) durationMs = v
    } else {
      positional.push(args[i])
    }
  }
  const [phaseType, agent, outcome] = positional
  if (!phaseType || !agent || !outcome) {
    console.error('Usage: router.js update <phaseType> <agent> <success|failure> [--tokens <n>]')
    process.exit(1)
  }

  try {
    const { key, prior } = update(phaseType, agent, outcome, { tokens, durationMs })
    const icon = outcome === 'success' ? `${C.green}✓${C.reset}` : `${C.red}✗${C.reset}`
    const costStr = prior.meanTokens ? ` ~${Math.round(prior.meanTokens)}tk(n=${prior.tokenSamples})` : ''
    const durationStr = prior.meanDurationMs ? ` ~${Math.round(prior.meanDurationMs)}ms(n=${prior.durationSamples})` : ''
    console.log(`${icon} Prior mis à jour : ${C.bold}${key}${C.reset} → α=${fmtCount(prior.alpha)} β=${fmtCount(prior.beta)} (${fmtCount(prior.successes)}✓ ${fmtCount(prior.failures)}✗)${costStr}${durationStr}`)
  } catch (/** @type {any} */ err) {
    console.error(err.message)
    process.exit(1)
  }
}

function cmdSeed() {
  console.log(`${C.cyan}→${C.reset} Bootstrap depuis les runs existants...`)
  const { seeded, runs } = seed()
  console.log(`${C.green}✓${C.reset} ${runs} runs analysés, ${seeded} outcomes importés`)

  // Afficher un résumé
  const state = loadState()
  const keys = Object.keys(state.priors)
  if (keys.length) {
    console.log(`\nPriors bootstrap :`)
    for (const key of keys.sort()) {
      const p = state.priors[key]
      const total = p.successes + p.failures
      const rate  = total > 0 ? Math.round(p.successes / total * 100) : '?'
      console.log(`  ${key.padEnd(30)} α=${p.alpha} β=${p.beta}  win=${rate}%  n=${total}`)
    }
  }
}

function cmdStats() {
  const state = loadState()
  const keys  = Object.keys(state.priors).sort()

  console.log(`\n${C.bold}Thompson Sampling — État des priors${C.reset}`)
  console.log(`Total updates : ${state.totalUpdates || 0}`)
  console.log(`Dernière MAJ  : ${state.lastUpdated ? state.lastUpdated.slice(0, 16).replace('T', ' ') : 'jamais'}`)
  console.log('')

  if (!keys.length) {
    console.log(`  Aucune donnée — lancer : node router.js seed`)
    return
  }

  // Grouper par phaseType — gère 'backend:nestjs' et 'task:backend:nestjs'
  const byPhase = {}
  for (const key of keys) {
    const parts = key.split(':')
    const phase = key.startsWith('task:') ? parts.slice(0, 2).join(':') : parts[0]
    const agent = key.startsWith('task:') ? parts[2] : parts[1]
    if (!agent) continue
    ;(byPhase[phase] = byPhase[phase] || {})[agent] = state.priors[key]
  }

  for (const [phase, agents] of Object.entries(byPhase)) {
    console.log(`${C.bold}${phase}${C.reset}`)
    for (const [agent, prior] of Object.entries(agents)) {
      const total   = prior.successes + prior.failures
      const winRate = total > 0 ? Math.round(prior.successes / total * 100) : null
      const bar     = '█'.repeat(Math.round((prior.alpha / (prior.alpha + prior.beta)) * 10))
                    + '░'.repeat(10 - Math.round((prior.alpha / (prior.alpha + prior.beta)) * 10))
      const rateStr = winRate !== null ? `${winRate}%` : ' ? '

      // Efficiency score (moyenne θ ajustée par le coût)
      const hasCost = (prior.tokenSamples || 0) >= MIN_COST_SAMPLES
      const meanTheta = prior.alpha / (prior.alpha + prior.beta)
      const effScore = hasCost ? computeEfficiencySample(prior, meanTheta) : null
      const costStr  = hasCost
        ? ` ${C.cyan}~${Math.round(prior.meanTokens)}tk eff=${effScore.toFixed(2)}${C.reset}`
        : ''

      console.log(
        `  ${agent.padEnd(15)} ${bar} ${C.gray}α=${fmtCount(prior.alpha).padEnd(5)} β=${fmtCount(prior.beta).padEnd(5)} ` +
        `win=${rateStr.padEnd(4)} n=${fmtCount(total)}${C.reset}${costStr}`
      )
    }
    console.log('')
  }
}

function cmdReset(args) {
  const [phaseType, agent] = args
  if (!phaseType) { console.error('Usage: router.js reset <phaseType> [agent]'); process.exit(1) }

  const SAFE_PHASE_RE = /^[a-zA-Z0-9][a-zA-Z0-9_-]{0,63}$/
  const SAFE_AGENT_RE = /^[a-z0-9-]{1,32}$/
  if (!SAFE_PHASE_RE.test(phaseType)) {
    console.error(`phaseType invalide : "${phaseType}"`)
    process.exit(1)
  }
  if (agent && !SAFE_AGENT_RE.test(agent)) {
    console.error(`agent invalide : "${agent}"`)
    process.exit(1)
  }

  const state = loadState()

  if (agent) {
    const key = priorKey(phaseType, agent)
    delete state.priors[key]
    console.log(`Réinitialisé : ${key}`)
  } else {
    const prefix = phaseType + ':'
    for (const key of Object.keys(state.priors)) {
      if (key.startsWith(prefix)) delete state.priors[key]
    }
    console.log(`Réinitialisé : tous les agents de '${phaseType}'`)
  }

  saveState(state)
}

// ── Decay des priors (évite le biais des anciennes données) ─────────────────

/**
 * Applique un decay multiplicatif sur tous les priors : α,β *= effectiveFactor (min 1.0)
 * ET, de façon proportionnelle, sur les compteurs successes/failures (min 0).
 * À appeler périodiquement (ex: mensuel) pour réduire le poids des anciens runs.
 *
 * B4 — pourquoi décayer aussi successes/failures : `confidence` (recommend) et
 * `winRate` sont calculés depuis ces compteurs, PAS depuis α/β. Ne décayer que
 * α/β laissait donc la confiance bloquée en 'high' à vie : ni l'exploration
 * Thompson ni le garde-fou contextuel ne pouvaient se rouvrir. Le decay est
 * proportionnel (même effectiveFactor) → winRate (un ratio) est préservé, seule
 * la MASSE de preuve diminue, ce qui est exactement le sens de l'oubli.
 *
 * B3 — protection EWC : basée sur `certitude × récence` (ewc.computeProtectionWeight),
 * pas sur la certitude seule. Un prior avec 500 observations mais silencieux depuis
 * des mois décaie désormais au facteur NOMINAL (avant : il était le plus protégé —
 * effet inversé). Le facteur effectif est en plus borné < 1 : aucun gel possible.
 *
 * @param {number} [factor=0.95]  Facteur de decay nominal ∈ ]0, 1[
 * @param {{ ewc?: boolean, ewcStrength?: number, now?: number, halfLifeDays?: number }} [opts]
 *   opts.ewc          : activer la protection EWC (défaut true)
 *   opts.ewcStrength  : force de la protection ∈ [0,1] (défaut 0.8)
 *   opts.now          : horloge injectable (tests)
 *   opts.halfLifeDays : demi-vie de la récence (défaut ewc.DEFAULT_HALF_LIFE_DAYS)
 * @returns {{ count: number, factor: number, protected: number }}
 */
function decay(factor = 0.95, opts = {}) {
  if (factor <= 0 || factor >= 1) throw new Error('factor doit être dans ]0,1[')

  const ewc         = opts.ewc !== false   // true par défaut
  const ewcStrength = opts.ewcStrength ?? 0.8
  const now         = typeof opts.now === 'number' && Number.isFinite(opts.now) ? opts.now : Date.now()
  const recencyOpts = { now, halfLifeDays: opts.halfLifeDays }

  // decay réécrit TOUS les priors → même verrou que update() (sinon un update
  // concurrent est écrasé). Le lock est atomique (O_EXCL) et relâché en finally.
  if (!acquireRouterLock()) {
    throw new Error('router-state.json est verrouillé par un autre processus — decay annulé, réessayer')
  }
  try {
    const state = loadState()
    let count = 0, protectedCount = 0

    for (const key of Object.keys(state.priors)) {
      const p = state.priors[key]

      let effectiveFactor = factor
      if (ewc) {
        const protection = computeProtectionWeight(p, recencyOpts)
        effectiveFactor  = computeEffectiveDecayFactor(factor, protection, ewcStrength)
        if (protection > 0.5) protectedCount++
      }

      p.alpha = Math.max(1, p.alpha * effectiveFactor)
      p.beta  = Math.max(1, p.beta  * effectiveFactor)
      // B4 — compteurs décayés au MÊME facteur (plancher 0, pas 1 : ce sont des
      // observations, pas des pseudo-comptes du prior Beta).
      if (typeof p.successes === 'number') p.successes = Math.max(0, p.successes * effectiveFactor)
      if (typeof p.failures  === 'number') p.failures  = Math.max(0, p.failures  * effectiveFactor)
      count++
    }

    state.decayAppliedAt = new Date(now).toISOString()
    saveState(state)
    return { count, factor, protected: protectedCount }
  } finally {
    releaseRouterLock()
  }
}

function cmdModel(args) {
  const tier = parseInt(args[0], 10)
  if (!tier || tier < 1 || tier > 3) {
    console.error('Usage: router.js model <1|2|3>')
    process.exit(1)
  }
  const model = recommendModel(tier)
  console.log(`Tier ${tier} → ${model}`)
}

function cmdDecay(args) {
  const factorArg    = args.find(a => a.startsWith('--factor='))?.split('=')[1]
                    || (args.includes('--factor') ? args[args.indexOf('--factor') + 1] : null)
  const factor       = factorArg ? parseFloat(factorArg) : 0.95
  const noEwc        = args.includes('--no-ewc')
  const ewcStrengthArg = args.find(a => a.startsWith('--ewc-strength='))?.split('=')[1]
                      || (args.includes('--ewc-strength') ? args[args.indexOf('--ewc-strength') + 1] : null)
  const ewcStrength  = ewcStrengthArg ? parseFloat(ewcStrengthArg) : 0.8

  try {
    const result = decay(factor, { ewc: !noEwc, ewcStrength })
    console.log(`${C.green}✓${C.reset} Decay ×${factor} appliqué sur ${result.count} priors`)
    if (!noEwc) {
      console.log(`  ${C.cyan}EWC actif (force=${ewcStrength}) — ${result.protected} priors protégés${C.reset}`)
    }
    console.log(`  Les anciennes données pèsent moins — exploration relancée si données faibles`)
  } catch (/** @type {any} */ err) {
    console.error(err.message); process.exit(1)
  }
}

// ── Routing contextuel (hint sur stack du projet) ────────────────────────────

/**
 * Étend la recommandation avec un bonus contextuel.
 *
 * Deux régimes STRICTEMENT distincts :
 *  - choix de stack (tous les candidats d'une même STACK_FAMILY) → déterministe,
 *    le contexte est ABSOLU et ne peut jamais être écrasé par les priors (B1) ;
 *  - choix réellement substituable → Thompson garde la main dès que sa confiance
 *    est suffisante (apprentissage légitime d'une préférence de qualité).
 *
 * @param {string} phaseType
 * @param {string|null} contextHint
 * @param {RecommendOpts} [opts]
 * @returns {RecommendResult}
 */
function recommendWithContext(phaseType, contextHint, opts = {}) {
  const candidates = opts.candidates || PHASE_CANDIDATES[phaseType] || STACK_PHASE_CANDIDATES[phaseType] || []
  if (!candidates.length) return recommend(phaseType, opts)

  // ── B1 — choix de stack : contexte absolu, aucun arbitrage probabiliste ─────
  if (stackExclusiveFamily(candidates)) {
    return stackRecommendation(phaseType, candidates, contextHint, opts)
  }

  // Si contextHint n'est pas un candidat valide → Thompson normal
  if (!contextHint || !candidates.includes(contextHint)) {
    return recommend(phaseType, opts)
  }

  // Si Thompson a déjà une confiance élevée → il l'emporte sur le contexte
  const thompsonResult = recommend(phaseType, opts)
  if (thompsonResult.confidence === 'high' || thompsonResult.confidence === 'medium') {
    return thompsonResult
  }

  // Confiance low/none → le contexte prend la main
  const state = loadState()
  const prior = getPrior(state, phaseType, contextHint)
  const total  = prior.successes + prior.failures
  return {
    agent:      contextHint,
    confidence: 'context',
    winRate:    total > 0 ? prior.successes / total : null,
    sample:     sampleBeta(prior.alpha, prior.beta),
    reason:     `Contexte projet impose ${contextHint} (n=${total} — confiance insuffisante pour Thompson)`
  }
}

function cmdRecommend(args) {
  const flags = {}
  const positional = []
  for (let i = 0; i < args.length; i++) {
    if (args[i].startsWith('--')) {
      flags[args[i].slice(2)] = args[i+1] || true; i++
    } else positional.push(args[i])
  }

  const [phaseType, ...candidatesArg] = positional
  if (!phaseType) { console.error('Usage: router.js recommend <phaseType> [--context <agent>]'); process.exit(1) }

  const candidates = candidatesArg.length ? candidatesArg : undefined
  const context    = flags.context || null
  const result     = context
    ? recommendWithContext(phaseType, context, { candidates })
    : recommend(phaseType, { candidates })

  if (!result.agent) {
    console.log(`Aucun candidat pour '${phaseType}'`)
    process.exit(1)
  }

  // Fallback = second meilleur candidat (hors agent recommandé). Aucun fallback
  // proposé pour un choix de stack : l'autre stack n'est pas un repli valide.
  const allCandidates = candidates || PHASE_CANDIDATES[phaseType] || []
  const fallback = result.confidence === 'stack'
    ? null
    : allCandidates.filter(a => a !== result.agent)[0] || null

  console.log(`\n${C.bold}Recommandation — ${phaseType}${C.reset}`)
  console.log(`  Agent     : ${C.green}${C.bold}${result.agent}${C.reset}`)
  if (fallback) console.log(`  Fallback  : ${C.gray}${fallback}${C.reset}`)
  console.log(`  Confiance : ${result.confidence}`)
  if (result.winRate !== null) {
    console.log(`  Win rate  : ${Math.round(result.winRate * 100)}%`)
  }
  console.log(`  Sampling  : ${result.reason}`)
  console.log(`\n${result.agent}`)
}

// ── Exports (mode module) ─────────────────────────────────────────────────────

const { computeFisherImportance, computeProtectionWeight, computeEffectiveDecayFactor } = require('./ewc.js')
module.exports = {
  recommend, recommendWithContext, update, seed, decay, loadState, saveState,
  PHASE_CANDIDATES, STACK_PHASE_CANDIDATES, STACK_FAMILIES,
  stackFamilyOf, stackExclusiveFamily, resolveStackChoice, detectProjectStack,
  recommendModel, TIER_MODELS,
  computeFisherImportance, computeProtectionWeight, computeEffectiveDecayFactor,
  computeEfficiencySample, updateTokenMean, updateDurationMean,
  TOKEN_BASELINE, COST_LAMBDA, MIN_COST_SAMPLES, _setRng, _resetRng,
}

// ── Dispatch CLI ──────────────────────────────────────────────────────────────

if (require.main === module) {
  const [,, cmd, ...args] = process.argv

  switch (cmd) {
    case 'recommend': cmdRecommend(args); break
    case 'update':    cmdUpdate(args);    break
    case 'seed':      cmdSeed();          break
    case 'stats':     cmdStats();         break
    case 'reset':     cmdReset(args);     break
    case 'decay':     cmdDecay(args);     break
    case 'model':     cmdModel(args);     break
    default:
      console.log(`\n${C.bold}coordinator/router.js — Thompson Sampling Router${C.reset}\n`)
      console.log('  recommend <phaseType> [--context <agent>]   Agent recommandé')
      console.log('  update <phaseType> <agent> <outcome>        Enregistrer un résultat')
      console.log('  decay [--factor 0.95]                       Réduire poids anciennes données')
      console.log('  seed                                        Bootstrap depuis runs/')
      console.log('  stats                                        Tableau des priors')
      console.log('  reset <phaseType> [agent]                   Réinitialiser')
      console.log('  model <1|2|3>                               Modèle recommandé pour un tier')
      console.log('')
      console.log(`Phases arbitrées par Thompson : ${Object.keys(PHASE_CANDIDATES).join(', ')}`)
      console.log('')
      console.log(`Phases résolues DÉTERMINISTEMENT (stack, jamais apprise) : ${Object.keys(STACK_PHASE_CANDIDATES).join(', ')}`)
      console.log('')
  }
}
