#!/usr/bin/env node
/**
 * coordinator/run.js — State machine pour l'orchestration multi-agents
 *
 * Commandes :
 *   node run.js init   <pipeline> <feature> [--backend nestjs|drf] [--api-only]
 *   node run.js start  <runId> <phaseId>
 *   node run.js done   <runId> <phaseId> "<summary>" [--tokens <n>] [--cost <n>]
 *   node run.js fail   <runId> <phaseId> "<error>" [--retry] [--tokens <n>] [--cost <n>] [--error-output <filepath>]
 *   node run.js skip   <runId> <phaseId> "<reason>"
 *   node run.js retry  <runId>
 *   node run.js status <runId>
 *   node run.js list
 *   node run.js rollback <runId> [<phaseId>]
 *
 * État stocké dans : .claude/runs/<runId>/state.json
 */

/**
 * @typedef {{ id: string, status: string, agent: string, startedAt?: string, completedAt?: string, summary?: string, tier?: number, tokens?: number, cost?: number }} PhaseState
 * @typedef {{ id: string, pipeline: string, name: string, status: 'running'|'completed'|'failed'|'completed_with_errors', startedAt: string, completedAt?: string, phases: Record<string, PhaseState>, flags: string[], totalTokens?: number, totalCost?: number, commitHash?: string|null, branch?: string|null }} RunState
 * @typedef {{ id: string, label: string, agent: string, required: boolean, maxRetries: number, depends: string[], stopOnFailure: boolean, tier?: number, skipIf?: string[], outputKey?: string }} PipelinePhase
 * @typedef {{ description: string, onFailure: string, phases: PipelinePhase[] }} Pipeline
 */

const { readFileSync, writeFileSync, existsSync, mkdirSync, readdirSync, appendFileSync, renameSync } = require('fs')
const { join, dirname }  = require('path')
const { spawn }          = require('child_process')

const { validatePipelines, validateRunState, assertValid } = require('./schema-validator')
const budgetGuard = require('./budget-guard')
const { estimateRun, formatEstimate } = require('./predictive-estimator')
const { buildPhaseContext, injectContext } = require('./context-advisor')
const { emitIPC } = require('./ipc-emit.js')

const CONFIG_DIR    = process.env.CLAUDE_CONFIG_DIR || join(process.env.HOME ?? '', '.claude')
const COORD_DIR     = join(CONFIG_DIR, 'coordinator')
const RUNS_DIR      = join(CONFIG_DIR, 'runs')
const LOGS_DIR      = join(CONFIG_DIR, 'logs')
const PIPELINE_FILE = join(COORD_DIR, 'pipelines.json')
const ROUTER_FILE   = join(COORD_DIR, 'router.js')
const BANK_FILE     = join(COORD_DIR, 'bank.js')
const AUDIT_FILE    = join(COORD_DIR, 'audit.log')
const REVIEW_MANDATES_FILE = join(COORD_DIR, 'review-mandates.json')

function appendLog(file, line) {
  try {
    ensureDir(dirname(file))
    appendFileSync(file, line, 'utf8')
  } catch {}
}

// ── Audit Log ─────────────────────────────────────────────────────────────────

function appendAudit(op, subject, detail) {
  try {
    const entry = JSON.stringify({
      ts: new Date().toISOString(),
      op,
      subject,
      detail: detail ?? null,
    }) + '\n'
    appendFileSync(AUDIT_FILE, entry, 'utf8')
  } catch {}
}

// ── Webhook dispatch (délégué à coordinator/webhook.js) ──────────────────────

const { dispatchWebhook } = require('./webhook.js')

// ── PR Autopilot (F3) ─────────────────────────────────────────────────────────

const PR_WORKER_FILE = join(CONFIG_DIR, 'workers', 'pr-create.js')

/**
 * Lance le worker PR de façon fire-and-forget.
 * @param {string} runId
 * @param {object} _state  (non utilisé directement — le worker relit state.json)
 */
function dispatchPrWorker(runId, _state) {
  if (!existsSync(PR_WORKER_FILE)) return
  try {
    const child = spawn('node', [PR_WORKER_FILE, runId], {
      detached: true, stdio: ['ignore', 'ignore', 'pipe'],
      env: { ...process.env, CLAUDE_CONFIG_DIR: CONFIG_DIR }
    })
    child.stderr?.on('data', d => appendLog(join(LOGS_DIR, 'worker-errors.log'), `${ts()} [pr-create] ${d}`))
    child.unref()
  } catch {}
}

/**
 * Charge la config prAutopilot depuis ~/.ada.json (inline pour éviter la dépendance circulaire).
 * @returns {{ enabled: boolean, autoCreate: boolean } | null}
 */
function loadPrConfig() {
  try {
    const adaJson = join(require('os').homedir(), '.ada.json')
    if (!existsSync(adaJson)) return null
    const ada = JSON.parse(readFileSync(adaJson, 'utf8'))
    return ada.prAutopilot ?? null
  } catch { return null }
}

// ── Bascule adaptative des pipelines (ADR-023 étape 5) ────────────────────────
//
// Flag réversible, désactivé par défaut : tant qu'il n'est pas explicitement
// activé, `next --json` retourne exactement la même topologie qu'avant ce
// chantier (aucune régression).
//
// ÉCART ASSUMÉ AU PLAN (2026-08-11) : l'ADR-023 étape 5 prescrit une bascule
// « un par un », en ne basculant le pipeline suivant qu'après mesure du
// précédent. Seul `review` a été mesuré en conditions réelles (voir section
// « Mesure du point 2 » de l'ADR). L'utilisateur a demandé explicitement de
// basculer les 6 autres candidats d'un coup, sans attendre une mesure
// individuelle de chacun — ce n'est PAS une application du séquençage de
// l'ADR, c'est une extension de périmètre non mesurée faite à sa demande.
// Voir la section « Bascule des 6 pipelines restants — écart assumé au plan »
// en fin d'ADR-023 pour le détail et les risques (couverture review-mandates
// limitée au domaine `sql-rls`, aucune donnée sur ces 6 pipelines).
//
// Les 7 noms ci-dessous sont exactement les candidats sans aucune phase
// `sideEffect: true` dans pipelines.json (vérifié par grep avant ajout) —
// aucun pipeline à effet de bord (`feature`, `hotfix`, `migration`,
// `db-migrate`, `saas-bootstrap`, `data-migration`) n'est ni n'a jamais été
// inclus ici, indépendamment de la config utilisateur (cf. garde-fou dans
// `resolveEffectiveTopology` et test dédié dans coordinator.test.js).
const ADAPTIVE_ELIGIBLE_PIPELINES = [
  'review',
  'test',
  'mobile',
  'bug-fix',
  'perf-audit',
  'security-audit',
  'api-design',
]

/**
 * Charge le flag `adaptivePipelines` depuis ~/.ada.json (même mécanisme que
 * loadPrConfig, surchargeable via ADA_CONFIG_PATH pour les tests hermétiques).
 * Défaut : tout désactivé — comportement figé inchangé.
 * @returns {Record<string, boolean>}
 */
function loadAdaptivePipelinesConfig() {
  try {
    const adaJson = process.env.ADA_CONFIG_PATH || join(require('os').homedir(), '.ada.json')
    if (!existsSync(adaJson)) return {}
    const ada = JSON.parse(readFileSync(adaJson, 'utf8'))
    const raw = ada.adaptivePipelines
    if (!raw || typeof raw !== 'object') return {}
    return raw
  } catch { return {} }
}

/**
 * Charge, depuis review-mandates.json, les mandats de revue par domaine dont
 * `appliesToPhaseIds` intersecte les phaseIds donnés. Source de vérité
 * déclarative (pas d'inférence lexicale) — ADR-023, correctif « checklist de
 * mandat de revue par domaine » de la section « Mise à jour post-étape 2 ».
 * @param {string[]} phaseIds
 * @returns {Array<{ domain: string, description: string, checklist: object[] }>}
 */
function loadApplicableReviewMandates(phaseIds) {
  try {
    if (!existsSync(REVIEW_MANDATES_FILE)) return []
    const data = JSON.parse(readFileSync(REVIEW_MANDATES_FILE, 'utf8'))
    const domains = data.domains || {}
    const matches = []
    for (const [domain, def] of Object.entries(domains)) {
      const applies = Array.isArray(def.appliesToPhaseIds) ? def.appliesToPhaseIds : []
      if (applies.some(p => phaseIds.includes(p))) {
        matches.push({ domain, description: def.description, checklist: def.checklist || [] })
      }
    }
    return matches
  } catch { return [] }
}

/**
 * Résout la topologie effective à retourner par `next --json`, en tenant
 * compte du flag adaptatif (ADR-023 étape 5). Fonction pure — aucun I/O,
 * testable isolément.
 *
 * - flag désactivé (défaut), OU pipeline non éligible → `baseTopology`
 *   inchangée (aucune régression, cf. ADR-023 « Décisions irréversibles » :
 *   le pipeline figé n'est jamais supprimé ni modifié structurellement).
 * - flag activé ET pipeline éligible (7 pipelines — voir
 *   `ADAPTIVE_ELIGIBLE_PIPELINES` et l'écart assumé au plan documenté au-dessus
 *   de cette constante) → topology `'adaptive'`, avec le(s) mandat(s) de revue
 *   applicable(s) et les plafonds de gouvernance de l'étape 4 inclus, pour que
 *   l'appelant (session Claude Code) les respecte lors de ses délégations
 *   libres.
 *
 * @param {{ topology: 'parallel_mesh'|'sequential', parallelizable: string[], ratio: number }} baseTopology
 * @param {string} pipelineName
 * @param {Record<string, boolean>} adaptiveConfig
 * @param {Array<{ domain: string, description: string, checklist: object[] }>} mandates
 * @param {{ maxDelegationsPerRun: number, perRun: number, adaptiveOnExceed: string }} governance
 * @returns {{ topology: string, parallelizable: string[], ratio: number, adaptive?: object }}
 */
function resolveEffectiveTopology(baseTopology, pipelineName, adaptiveConfig, mandates, governance) {
  const enabled = !!(adaptiveConfig && adaptiveConfig[pipelineName] === true)
  if (!enabled || !ADAPTIVE_ELIGIBLE_PIPELINES.includes(pipelineName)) {
    return baseTopology
  }

  return {
    ...baseTopology,
    topology: 'adaptive',
    adaptive: {
      pipeline: pipelineName,
      mandates,
      governance: {
        maxDelegationsPerRun: governance?.maxDelegationsPerRun,
        perRunBudgetUsd: governance?.perRun,
        onExceed: governance?.adaptiveOnExceed || 'stop',
      },
    },
  }
}

// ── Logs JSONL structurés par run ─────────────────────────────────────────────

/**
 * Écrit une entrée JSONL dans runs/<runId>/run.log.
 * No-op si le répertoire du run n'existe pas encore.
 * @param {string} runId
 * @param {'info'|'warn'|'error'} level
 * @param {string} event
 * @param {Record<string,unknown>} [data]
 */
function runLog(runId, level, event, data = {}) {
  const runDir = join(RUNS_DIR, runId)
  if (!existsSync(runDir)) return
  const entry = JSON.stringify({ ts: new Date().toISOString(), level, event, ...data }) + '\n'
  try { appendFileSync(join(runDir, 'run.log'), entry) } catch {}
}

// ── Intégration router (fire-and-forget) ─────────────────────────────────────

/**
 * Écrit le prior `<phaseId>:<agent>` (Thompson + télémétrie coût/durée).
 *
 * B2 — pourquoi on écrit AUSSI les phases à agent unique déterministe (audit :
 * « écriture morte ») : ces priors sont bel et bien relus, juste pas par
 * l'arbitrage Thompson (réservé aux entrées ≥2 candidats de PHASE_CANDIDATES) —
 *   • predictive-estimator.estimateRun() : meanTokens / meanDurationMs /
 *     successRate par `phaseId:agent`, pour TOUTE phase (cf. cmdNext, corrigé en B6) ;
 *   • `router.js stats`, `ewc.js report`, workers/metrics + dashboard ;
 *   • never-worse / flywheel (détection de dégradation d'un agent).
 * Les supprimer casserait l'estimation préventive et la télémétrie : on les garde
 * délibérément. Seul l'ARBITRAGE est restreint, pas la mesure.
 *
 * @param {string} phaseId
 * @param {string|undefined} agent
 * @param {string} outcome
 * @param {number|null} [tokens]     tokens consommés par la phase (optionnel)
 * @param {number|null} [durationMs] durée de la phase en ms (optionnel)
 */
function routerUpdate(phaseId, agent, outcome, tokens, durationMs) {
  if (!existsSync(ROUTER_FILE) || !agent) return
  const extraArgs = [
    ...(typeof tokens === 'number' && tokens > 0 ? ['--tokens', String(Math.round(tokens))] : []),
    ...(typeof durationMs === 'number' && durationMs > 0 ? ['--duration', String(Math.round(durationMs))] : []),
  ]
  const { validateCommand } = require('./safe-executor.js')
  const check = validateCommand('node', [ROUTER_FILE, 'update', phaseId, agent, outcome, ...extraArgs])
  if (!check.safe) return  // silencieux — fire-and-forget ne doit pas crasher
  try {
    const child = spawn('node', [ROUTER_FILE, 'update', phaseId, agent, outcome, ...extraArgs], {
      detached: true, stdio: ['ignore', 'ignore', 'pipe'],
      env: { ...process.env, CLAUDE_CONFIG_DIR: CONFIG_DIR }
    })
    child.stderr?.on('data', d => appendLog(join(LOGS_DIR, 'worker-errors.log'), `${ts()} [worker] ${d}`))
    child.unref()
  } catch {}
}

// ── Intégration ReasoningBank (fire-and-forget) ───────────────────────────────

/** @param {string} phaseId @param {string|undefined} agent @param {string} verdict @param {string} summary @param {string|undefined} runId @param {number|null} durationMs */
function bankStore(phaseId, agent, verdict, summary, runId, durationMs) {
  if (!existsSync(BANK_FILE) || !agent) return
  const { validateCommand } = require('./safe-executor.js')
  const check = validateCommand('node', [BANK_FILE, 'store', phaseId, agent, verdict])
  if (!check.safe) return  // silencieux — fire-and-forget ne doit pas crasher
  try {
    const durationSecs = durationMs ? Math.round(durationMs / 1000) : null
    const storeArgs = ['store', phaseId, agent, verdict, summary || '']
    if (runId)       storeArgs.push('--run', runId)
    if (durationSecs) storeArgs.push('--duration', String(durationSecs))
    const child = spawn('node', [BANK_FILE, ...storeArgs], {
      detached: true, stdio: ['ignore', 'ignore', 'pipe'],
      env: { ...process.env, CLAUDE_CONFIG_DIR: CONFIG_DIR }
    })
    child.stderr?.on('data', d => appendLog(join(LOGS_DIR, 'worker-errors.log'), `${ts()} [worker] ${d}`))
    child.unref()
  } catch {}
}

// ── Utilitaires ───────────────────────────────────────────────────────────────

function ensureDir(p) { if (!existsSync(p)) mkdirSync(p, { recursive: true }) }
function readJson(p)  { return JSON.parse(readFileSync(p, 'utf8')) }
function safeReadJson(p, fallback) {
  try { return existsSync(p) ? readJson(p) : fallback } catch { return fallback }
}
function writeJson(p, data) {
  ensureDir(dirname(p))
  const tmp = p + '.tmp'
  writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf8')
  renameSync(tmp, p)
}

// ── Parse --tokens / --cost flags from an args array ─────────────────────────

/**
 * Extracts --tokens <n> and --cost <n> from an args array.
 * Returns { tokens: number|null, cost: number|null, remaining: string[] }
 */
function parseTokenCostFlags(args) {
  let tokens = null
  let cost = null
  const remaining = []
  let i = 0
  while (i < args.length) {
    if (args[i] === '--tokens' && i + 1 < args.length) {
      const v = parseInt(args[i + 1], 10)
      if (!isNaN(v)) tokens = v
      i += 2
    } else if (args[i] === '--cost' && i + 1 < args.length) {
      const v = parseFloat(args[i + 1])
      if (!isNaN(v)) cost = v
      i += 2
    } else {
      remaining.push(args[i])
      i++
    }
  }
  return { tokens, cost, remaining }
}

// ── Fallback télémétrie tokens (fallback automatique) ──────────────────
// Constat : l'orchestrateur ne passe presque jamais --tokens/--cost à `done`/`fail`
// → totalTokens=0 sur la quasi-totalité des runs. Fallback best-effort : reconstituer
// l'usage réel depuis les transcripts Claude Code (token-telemetry.sumUsageIncremental)
// via un cache d'offsets d'octets par fichier (state.telemetryOffsets), pour ne lire
// que les octets nouveaux depuis le dernier appel. Jamais bloquant : try/catch partout,
// retourne null si indisponible (transcripts absents, dossier introuvable, etc.).

/**
 * Résout le dossier de transcripts le plus probable pour la session courante.
 * Délègue à token-telemetry.js (source de vérité, déjà utilisée par benchmark.js).
 * @returns {string|null}
 */
function resolveTranscriptDir() {
  try {
    const tt = require('./token-telemetry.js')
    if (typeof tt.locateLatestTranscriptDir === 'function') {
      return tt.locateLatestTranscriptDir(CONFIG_DIR)
    }
  } catch {}
  return null
}

/**
 * Tente d'estimer tokens/coût d'une phase depuis les transcripts réels quand
 * --tokens n'a pas été fourni. Best-effort : ne lève jamais, retourne null si
 * l'estimation est indisponible ou nulle.
 * NOTE : le cache `state.telemetryOffsets` (offset d'octets PAR FICHIER transcript,
 * persisté dans state.json) remplace l'ancien mécanisme `state.telemetryWatermark`
 * (fenêtre temporelle globale avancée après CHAQUE estimation). Chaque fichier
 * transcript n'est relu qu'à partir des octets nouveaux depuis son dernier offset
 * connu, ce qui élimine le double comptage ENTRE PHASES d'un même run (topologie
 * parallel_mesh) de façon plus précise qu'un watermark temporel (par fichier, pas
 * par fenêtre globale), tout en évitant de re-scanner l'intégralité de chaque
 * transcript à chaque appel.
 * On garde néanmoins `phase.startedAt` comme plancher temporel (`sinceISO`) passé
 * à `sumUsageIncremental` : `state.telemetryOffsets` repart à zéro à CHAQUE run
 * (nouveau state.json), donc la toute première lecture d'un fichier transcript
 * partagé (session Claude Code réutilisée par un run ADA précédent) part d'un
 * offset 0 — sans plancher temporel, elle attribuerait tout l'historique déjà
 * écrit AVANT le début de cette phase à la phase courante. Le plancher élimine ce
 * risque de cross-comptage entre runs successifs sans coûter d'I/O (les octets ne
 * sont lus qu'une fois, filtrés ou non). Reste hors scope : le cross-comptage entre
 * deux runs ADA VRAIMENT concurrents lisant le même fichier au même instant
 * (limitation architecturale préexistante de `locateLatestTranscriptDir`).
 * @param {RunState|null|undefined} state
 * @param {PhaseState} phase
 * @returns {{tokens:number, cost:number}|null}
 */
function estimateTokensFallback(state, phase) {
  if (!phase || !phase.startedAt) return null
  try {
    const tt = require('./token-telemetry.js')
    if (typeof tt.sumUsageIncremental !== 'function') return null
    const dir = resolveTranscriptDir()
    if (!dir) return null
    if (state) state.telemetryOffsets = state.telemetryOffsets || {}
    const offsets = state ? state.telemetryOffsets : {}
    const usage = tt.sumUsageIncremental(dir, offsets, phase.startedAt)
    if (!usage) return null
    const totalTokens = Math.round((usage.totalInput ?? 0) + (usage.output ?? 0))
    if (!(totalTokens > 0)) return null
    return { tokens: totalTokens, cost: usage.realCostUsd ?? 0 }
  } catch {
    return null
  }
}

/**
 * Résout tokens/cost effectifs pour une phase : --tokens explicite (source
 * 'reported') sinon fallback transcript (source 'estimated') sinon aucun (null).
 * Si aucune mesure n'est disponible, logge un warning visible (console + run.log
 * event 'telemetry.missing') pour que l'absence ne soit plus silencieuse.
 * @param {string} runId
 * @param {string} phaseId
 * @param {PhaseState} phase
 * @param {number|null} tokens   --tokens explicite (ou null)
 * @param {number|null} cost     --cost explicite (ou null)
 * @param {RunState} [state]     état du run — avance state.telemetryOffsets (par fichier transcript) quand l'estimation transcript est utilisée
 * @returns {{tokens:number|null, cost:number|null, source:'reported'|'estimated'|null}}
 */
function resolveTelemetry(runId, phaseId, phase, tokens, cost, state) {
  if (tokens != null) {
    return { tokens, cost: cost ?? null, source: 'reported' }
  }
  const est = estimateTokensFallback(state, phase)
  if (est) {
    return { tokens: est.tokens, cost: cost != null ? cost : est.cost, source: 'estimated' }
  }
  const msg = `Aucune télémétrie tokens pour la phase '${phaseId}' (ni --tokens, ni fallback transcript)`
  process.stderr.write(`[telemetry] ⚠ ${msg}\n`)
  runLog(runId, 'warn', 'telemetry.missing', { phaseId })
  return { tokens: null, cost: cost ?? null, source: null }
}

// ── Détection de dépendances circulaires (DFS) ────────────────────────────────

function detectCycles(phases) {
  const graph = {}
  for (const p of phases) graph[p.id] = p.depends || []
  const visited = new Set(), recStack = new Set()
  function dfs(id) {
    visited.add(id); recStack.add(id)
    for (const dep of (graph[id] || [])) {
      if (!visited.has(dep) && dfs(dep)) return true
      if (recStack.has(dep)) return true
    }
    recStack.delete(id)
    return false
  }
  for (const p of phases) {
    if (!visited.has(p.id) && dfs(p.id)) return true
  }
  return false
}

// ── File lock (évite les race conditions sur state.json) ─────────────────────

function acquireLock(runId, attempt = 0) {
  if (attempt > 3) return false
  validateRunId(runId)
  const lockFile = join(RUNS_DIR, `${runId}.lock`)
  try {
    // O_EXCL garantit l'atomicité — pas de TOCTOU entre existsSync + writeFileSync
    const fd = require('fs').openSync(lockFile, 'wx')
    require('fs').writeSync(fd, String(process.pid))
    require('fs').closeSync(fd)
    return true
  } catch (/** @type {any} */ err) {
    if (err.code === 'EEXIST') {
      // Lock existant — vérifier l'âge pour éviter les locks zombies
      try {
        const age = Date.now() - require('fs').statSync(lockFile).mtimeMs
        if (age < 10_000) return false
        // Lock trop ancien (> 10s) → forcer la reprise
        require('fs').unlinkSync(lockFile)
        return acquireLock(runId, attempt + 1)
      } catch { return false }
    }
    return false
  }
}

function releaseLock(runId) {
  try {
    const lockFile = join(RUNS_DIR, `${runId}.lock`)
    if (existsSync(lockFile)) require('fs').unlinkSync(lockFile)
  } catch {}
}
function ts()  { return new Date().toISOString() }
function pad2(n) { return String(n).padStart(2, '0') }
function runId(pipeline, name) {
  const d = new Date()
  const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 30)
  return `${pipeline}-${slug}-${d.getFullYear()}${pad2(d.getMonth()+1)}${pad2(d.getDate())}-${pad2(d.getHours())}${pad2(d.getMinutes())}`
}

const SAFE_RUN_ID_RE = /^[a-z0-9][a-z0-9-]{2,59}$/

function validateRunId(id) {
  if (!SAFE_RUN_ID_RE.test(id)) { console.error(`Invalid runId: "${id}"`); process.exit(1) }
}

function statePath(id) { return join(RUNS_DIR, id, 'state.json') }

function loadState(id) {
  validateRunId(id)
  const p = statePath(id)
  if (!existsSync(p)) { console.error(`Run not found: ${id}`); process.exit(1) }
  return readJson(p)
}

function saveState(state) {
  writeJson(statePath(state.id), state)
}

let _pipelineCache = null
let _pipelineMtime = 0

function loadPipeline(name) {
  if (!existsSync(PIPELINE_FILE)) { console.error('pipelines.json not found'); process.exit(1) }
  try {
    const mtime = require('fs').statSync(PIPELINE_FILE).mtimeMs
    if (_pipelineCache === null || mtime !== _pipelineMtime) {
      _pipelineCache = readJson(PIPELINE_FILE)
      _pipelineMtime = mtime
      const errors = validatePipelines(_pipelineCache)
      if (errors.length) {
        appendLog(join(LOGS_DIR, 'schema-errors.log'), `${ts()} pipelines.json: ${errors.join(', ')}\n`)
      }
    }
  } catch {
    if (!_pipelineCache) _pipelineCache = readJson(PIPELINE_FILE)
  }
  if (!_pipelineCache[name]) { console.error(`Pipeline not found: ${name}`); process.exit(1) }
  return _pipelineCache[name]
}

// ── Couleurs terminal ─────────────────────────────────────────────────────────

const C = {
  reset: '\x1b[0m', bold: '\x1b[1m',
  green: '\x1b[32m', red: '\x1b[31m', yellow: '\x1b[33m',
  cyan: '\x1b[36m', gray: '\x1b[90m', blue: '\x1b[34m'
}
const ok   = msg => console.log(`${C.green}✓${C.reset} ${msg}`)
const fail = msg => console.log(`${C.red}✗${C.reset} ${msg}`)
const info = msg => console.log(`${C.cyan}→${C.reset} ${msg}`)
const warn = msg => console.log(`${C.yellow}⚠${C.reset}  ${msg}`)

// ── Affichage status ──────────────────────────────────────────────────────────

const STATUS_ICONS = {
  pending:   `${C.gray}○${C.reset}`,
  running:   `${C.blue}●${C.reset}`,
  completed: `${C.green}✓${C.reset}`,
  failed:    `${C.red}✗${C.reset}`,
  skipped:   `${C.yellow}–${C.reset}`,
  retrying:   `${C.yellow}↺${C.reset}`,
  rolled_back: `${C.yellow}↩${C.reset}`
}

function printStatus(state) {
  const elapsed = state.completedAt
    ? Math.round((new Date(state.completedAt) - new Date(state.startedAt)) / 1000)
    : Math.round((Date.now() - new Date(state.startedAt)) / 1000)

  console.log('')
  console.log(`${C.bold}Run: ${state.id}${C.reset}`)
  console.log(`${C.bold}Feature: ${state.args.name}${C.reset}  [${state.status.toUpperCase()}]  ${elapsed}s`)
  console.log(`Pipeline: ${state.pipeline}  Backend: ${state.args.backend || 'nestjs'}`)
  if (state.totalTokens != null || state.totalCost != null) {
    const tokStr  = state.totalTokens != null ? `${state.totalTokens} tokens` : ''
    const costStr = state.totalCost   != null ? `$${state.totalCost.toFixed(4)}` : ''
    console.log(`Tokens/Cost: ${[tokStr, costStr].filter(Boolean).join('  ')}`)
  }
  console.log('')

  const phases = state.pipeline === 'feature'
    ? loadPipeline('feature').phases
    : Object.keys(state.phases).map(id => ({ id, label: id }))

  for (const phase of phases) {
    const p = state.phases[phase.id] || { status: 'pending' }
    const icon = STATUS_ICONS[p.status] || STATUS_ICONS.pending
    const agent = p.agent ? ` ${C.gray}[${p.agent}]${C.reset}` : ''
    const retries = p.retries > 0 ? ` ${C.yellow}(retry ${p.retries})${C.reset}` : ''
    const duration = p.completedAt && p.startedAt ? ` ${C.gray}${Math.round((new Date(p.completedAt) - new Date(p.startedAt)) / 1000)}s${C.reset}` : ''
    console.log(`  ${icon} ${phase.label || phase.id}${agent}${retries}${duration}`)
    if (p.status === 'failed' && p.error) {
      console.log(`     ${C.red}↳ ${p.error.slice(0, 100)}${C.reset}`)
    }
    if (p.status === 'completed' && p.summary) {
      console.log(`     ${C.gray}↳ ${p.summary.slice(0, 100)}${C.reset}`)
    }
  }
  console.log('')

  if (state.status === 'completed') ok(`Feature '${state.args.name}' terminée avec succès`)
  else if (state.status === 'failed') fail(`Bloqué en phase '${state.blockedAt}'`)
  else if (state.status === 'running') info(`Phase active: ${state.activePhase}`)
}

// ── Commandes ─────────────────────────────────────────────────────────────────

function cmdInit(args) {
  const [pipeline, name, ...flags] = args
  if (!pipeline || !name) {
    console.error('Usage: run.js init <pipeline> <feature-name> [flags]')
    process.exit(1)
  }

  const pipelineDef = loadPipeline(pipeline)

  // Validation : détecter les dépendances circulaires
  if (detectCycles(pipelineDef.phases)) {
    console.error('Pipeline corrompu : dépendances circulaires détectées dans pipelines.json')
    process.exit(1)
  }

  const id = runId(pipeline, name)

  // Capture git state
  let commitHash = null, branch = null
  try {
    const { spawnSync } = require('child_process')
    const gitLog = spawnSync('git', ['log', '-1', '--format=%H'], { cwd: process.cwd(), encoding: 'utf8' })
    if (gitLog.status === 0) commitHash = gitLog.stdout.trim().slice(0, 12)
    const gitBranch = spawnSync('git', ['rev-parse', '--abbrev-ref', 'HEAD'], { cwd: process.cwd(), encoding: 'utf8' })
    if (gitBranch.status === 0) branch = gitBranch.stdout.trim()
  } catch {}

  const state = {
    id,
    pipeline,
    status: 'initialized',
    startedAt: ts(),
    completedAt: null,
    blockedAt: null,
    activePhase: null,
    commitHash,
    branch,
    totalTokens: 0,
    totalCost: 0,
    loopIteration: 0,
    args: {
      name,
      backend: (() => {
        const BACKEND_ALLOWLIST = new Set(['nestjs', 'drf'])
        const raw = flags.includes('--backend')
          ? flags[flags.indexOf('--backend') + 1]
          : flags.find(f => f.startsWith('--backend='))?.split('=')[1]
        if (raw && BACKEND_ALLOWLIST.has(raw)) return raw
        if (raw) {
          process.stderr.write(`[run] --backend "${raw}" inconnu — détection auto. Valeurs : ${[...BACKEND_ALLOWLIST].join(', ')}\n`)
        }
        // B1 — pas de --backend : détecter la stack RÉELLE du projet (nest-cli.json,
        // manage.py, deps) au lieu de supposer nestjs. La stack n'est jamais un
        // choix probabiliste : déclarée > détectée > défaut documenté 'nestjs'.
        try {
          const { detectProjectStack } = require('./router.js')
          const detected = typeof detectProjectStack === 'function'
            ? detectProjectStack(['nestjs', 'drf'], process.cwd())
            : null
          if (detected) return detected
        } catch {}
        return 'nestjs'
      })(),
      apiOnly: flags.includes('--api-only'),
      noDeploy: flags.includes('--no-deploy'),
      flags
    },
    phases: {}
  }

  // Initialiser toutes les phases à 'pending'
  for (const phase of pipelineDef.phases) {
    const shouldSkip = phase.skipIf?.some(flag => flags.includes(flag))
    // A0 — routing adaptatif Thompson activé pour les phases multi-candidats (sinon statique)
    const sel = selectAgentForPhase(phase, state)
    state.phases[phase.id] = {
      status: shouldSkip ? 'skipped' : 'pending',
      agent: sel.agent,
      agentSource: sel.source,
      required: phase.required,
      maxRetries: phase.maxRetries,
      retries: 0,
      startedAt: null,
      completedAt: null,
      summary: null,
      error: null
    }
    if (sel.source === 'router') {
      runLog(id, 'info', 'router.select', { phaseId: phase.id, agent: sel.agent, confidence: sel.confidence, reason: sel.reason })
    }
    if (shouldSkip) state.phases[phase.id].skipReason = `flag ${phase.skipIf.find(f => flags.includes(f))}`
  }

  saveState(state)
  emitIPC('run.started', { runId: id, pipeline, name: state.args.name })
  runLog(id, 'info', 'run.started', { pipeline, phases: Object.keys(state.phases) })
  ok(`Run initialisé : ${id}`)
  console.log(`  Pipeline : ${pipeline}`)
  console.log(`  Feature  : ${name}`)
  console.log(`  Backend  : ${state.args.backend}`)
  if (commitHash) console.log(`  Commit   : ${commitHash}${branch ? ` (${branch})` : ''}`)
  console.log(`  État     : ${join(RUNS_DIR, id, 'state.json')}`)
  console.log('')
  console.log(`Prochaine phase : ${C.bold}${pipelineDef.phases[0].id}${C.reset}`)
  console.log(`  node run.js start ${id} ${pipelineDef.phases[0].id}`)

  // Topologie initiale
  const topoInit = analyzeTopology(state, pipelineDef)
  if (topoInit.topology === 'parallel_mesh' && topoInit.parallelizable.length >= 2) {
    console.log('')
    console.log(`${C.cyan}⚡ PARALLEL_MESH${C.reset} — ${topoInit.parallelizable.length} phases parallélisables dès le départ (${topoInit.ratio}%)`)
    console.log(`Lancer simultanément : ${topoInit.parallelizable.join(', ')}`)
  }

  process.stdout.write(`RUN_ID:${id}\n`)
  appendAudit('run.init', id, 'pipeline=' + pipeline)
  return id
}

async function cmdStart(args) {
  const [id, phaseId] = args
  if (!id || !phaseId) { console.error('Usage: run.js start <runId> <phaseId>'); process.exit(1) }

  // Acquérir le lock AVANT de lire l'état pour éviter le TOCTOU entre lecture et écriture
  if (!acquireLock(id)) {
    warn(`Run '${id}' est verrouillé par un autre processus — réessayer dans quelques secondes`)
    process.exit(1)
  }

  const state = loadState(id)
  const phase = state.phases[phaseId]
  if (!phase) { releaseLock(id); console.error(`Phase not found: ${phaseId}`); process.exit(1) }
  if (phase.status === 'running') { releaseLock(id); warn(`Phase '${phaseId}' est déjà en cours`); return }
  if (phase.status === 'completed') { releaseLock(id); warn(`Phase '${phaseId}' est déjà terminée`); return }

  // Vérifier les dépendances (sauf pour un retry — elles ont déjà été vérifiées)
  const pipelineDef = loadPipeline(state.pipeline)
  const phaseDef = pipelineDef.phases.find(p => p.id === phaseId)
  if (phaseDef?.depends?.length && phase.status !== 'retrying') {
    for (const dep of phaseDef.depends) {
      const depState = state.phases[dep]
      if (depState && !['completed', 'skipped'].includes(depState.status)) {
        releaseLock(id)
        fail(`Dépendance non satisfaite : '${dep}' est '${depState.status}'`)
        console.log(`  Terminez d'abord : node run.js done ${id} ${dep} "<summary>"`)
        process.exit(1)
      }
    }
  }

  phase.status = 'running'
  phase.startedAt = ts()
  state.status = 'running'
  state.activePhase = phaseId

  // ── F2 — Adaptive Context Window (ACW) ─────────────────────────────────────
  // A1 : un SEUL pipeline de retrieval — bank.smartRetrieve (expand→RRF→MMR→graph-boost).
  // Auparavant run.js ré-implémentait ce pipeline (smartSearch inline) APRÈS bank.retrieve()
  // → double exécution sur les mêmes données. Supprimé : on délègue au bank, source unique.
  try {
    if (existsSync(BANK_FILE)) {
      const bank = require(BANK_FILE)
      if (typeof bank.smartRetrieve === 'function' || typeof bank.retrieve === 'function') {
        const taskDescription = phaseDef?.label || phaseId
        const _acwStart = Date.now()
        const rawTrajectories = (typeof bank.smartRetrieve === 'function'
          ? bank.smartRetrieve(taskDescription, { limit: 8, phase: phaseId })
          : bank.retrieve(taskDescription, { limit: 8 })) || []
        if (Date.now() - _acwStart > 2000) {
          process.stderr.write(`[acw] retrieval lent (${Date.now() - _acwStart}ms) — skip injection\n`)
          throw new Error('ACW_TIMEOUT')
        }
        const filtered = (Array.isArray(rawTrajectories) ? rawTrajectories : [])
          .filter(t => t.verdict === 'success')
          .slice(0, 5)

        let lesson = ''
        try {
          const ml = require('./micro-lessons.js')
          if (typeof ml.inject === 'function') lesson = (ml.inject(phaseId) || '').trim()
        } catch (e) {
          require('./logger').warn('acw', 'micro-lessons inject failed', { phaseId, error: e?.message })
        }

        if (filtered.length || lesson) {
          const ids    = filtered.map(t => t.id).filter(Boolean).slice(0, 5)
          const durations = filtered.map(t => t.duration).filter(n => typeof n === 'number' && n > 0)
          const avgMin = durations.length
            ? Math.round(durations.reduce((a, b) => a + b, 0) / durations.length / 60)
            : null
          const parts = []
          if (ids.length)      parts.push(`Similar past runs: [${ids.join(', ')}]`)
          if (filtered.length) parts.push(`avg success: 100%`)
          if (avgMin !== null) parts.push(`avg duration: ${avgMin}min`)
          const header     = parts.join(' | ')
          const lessonLine = lesson ? `Key lessons: ${lesson}` : ''
          const summary    = [header, lessonLine].filter(Boolean).join('\n')
          phase.acwContext = {
            trajectories: filtered.map(t => ({ id: t.id, verdict: t.verdict, summary: (t.summary || '').slice(0, 120), duration: t.duration })),
            lesson,
            summary,
            injected: true,
          }
          runLog(id, 'info', 'acw.context', { phaseId, trajectories: filtered.length })
          process.stderr.write(`[acw] Injected context for ${phaseId}: ${filtered.length} trajectories\n`)
        }
      }
    }
  } catch (e) {
    require('./logger').warn('acw', 'ACW block failed — agent will run without historical context', { phaseId, error: e?.message })
  }

  // ── F9 — Semantic Diff Review ──────────────────────────────────────────────
  // Avant une phase reviewer, injecter les patterns de reviews passées sur
  // des diffs similaires (via diff-reviewer.js → bank.retrieve).
  const isReviewerPhase = (phase.agent === 'reviewer'
    || phaseId === 'review'
    || phaseId === 'reviewer')

  if (isReviewerPhase) {
    try {
      const DIFF_REVIEWER_FILE = join(COORD_DIR, 'diff-reviewer.js')
      if (existsSync(DIFF_REVIEWER_FILE)) {
        const { getReviewContext } = require(DIFF_REVIEWER_FILE)

        // Capturer le diff git (non-bloquant)
        let diffStat = ''
        try {
          const { spawnSync } = require('child_process')
          const res = spawnSync('git', ['diff', '--stat', 'HEAD'], {
            cwd: process.cwd(),
            encoding: 'utf8',
            timeout: 3000,
          })
          if (res.status === 0) diffStat = res.stdout.trim()
        } catch {}

        // Fallback : utiliser le label/id de la phase comme query
        const query = diffStat || phaseDef?.label || phaseId

        // getReviewContext est async — attendre avec timeout 2.5s
        const reviewCtx = await new Promise(resolve => {
          const t = setTimeout(() => resolve({ patterns: [], warnings: [], injectedContext: '' }), 2500)
          Promise.resolve(getReviewContext(query))
            .then(r => { clearTimeout(t); resolve(r) })
            .catch(() => { clearTimeout(t); resolve({ patterns: [], warnings: [], injectedContext: '' }) })
        })

        if (reviewCtx && reviewCtx.injectedContext) {
          phase.diffReviewContext = {
            patterns:         reviewCtx.patterns,
            warnings:         reviewCtx.warnings,
            injectedContext:  reviewCtx.injectedContext,
          }
          runLog(id, 'info', 'diff-review.injected', {
            phaseId,
            patterns: reviewCtx.patterns.length,
          })
          process.stderr.write(
            `[diff-review] Injected ${reviewCtx.patterns.length} review patterns for ${phaseId}
`
          )
        }
      }
    } catch (e) {
      require('./logger').warn('diff-review', 'Diff review context injection failed — reviewer will run without past review patterns', { phaseId, error: e?.message })
    }
  }

  saveState(state)
  emitIPC('run.phase.started', { runId: id, phaseId, agent: phase.agent })
  releaseLock(id)

  runLog(id, 'info', 'phase.started', { phaseId, agent: phase.agent })
  info(`Phase démarrée : ${phaseId}  [agent: ${phase.agent}]`)
  appendAudit('phase.start', phaseId, 'runId=' + id)
}

function cmdDone(args) {
  // Parse --tokens and --cost before extracting positional args
  const { tokens, cost, remaining } = parseTokenCostFlags(args)
  const [id, phaseId, ...summaryParts] = remaining
  let summary = summaryParts.join(' ')
  if (!id || !phaseId) { console.error('Usage: run.js done <runId> <phaseId> "<summary>" [--tokens <n>] [--cost <n>]'); process.exit(1) }

  try {
    const { assertSafe } = require('./ada-defence.js')
    assertSafe(summary, 'run.done.summary', { internal: true })
  } catch (e) {
    if (e && e.type === 'INJECTION') {
      summary = '[REDACTED by AIDefence — injection detected]'
      console.warn(`⚠ AIDefence: injection détectée dans le summary de ${phaseId}`)
    }
  }

  if (!acquireLock(id)) {
    console.error('Run verrouillé — réessayer dans un instant')
    process.exit(1)
  }
  try {
    const state = loadState(id)
    const phase = state.phases[phaseId]
    if (!phase) { console.error(`Phase not found: ${phaseId}`); throw new Error(`Phase not found: ${phaseId}`) }

    phase.status = 'completed'
    phase.completedAt = ts()
    phase.summary = summary || null

    // Token/cost tracking — --tokens explicite sinon fallback transcript
    const telemetry = resolveTelemetry(id, phaseId, phase, tokens, cost, state)
    if (telemetry.tokens != null) phase.tokens = telemetry.tokens
    if (telemetry.cost   != null) phase.cost   = telemetry.cost
    if (telemetry.source)         phase.tokensSource = telemetry.source
    state.totalTokens = (state.totalTokens ?? 0) + (telemetry.tokens ?? 0)
    state.totalCost   = (state.totalCost   ?? 0) + (telemetry.cost   ?? 0)

    const durationMs = phase.startedAt ? Date.now() - new Date(phase.startedAt).getTime() : null

    // Budget guard — enregistrement et vérification du circuit-breaker
    try {
      const phaseCost = telemetry.cost ?? 0
      budgetGuard.recordCost(id, phaseCost, phase.agent || undefined)
      const budgetConfig = budgetGuard.loadBudgetConfig()
      const budgetResult = budgetGuard.checkBudget(id, phaseCost, state.totalCost ?? 0, budgetConfig, {
        todayCost:   budgetGuard.getDailyCost(),
        sessionCost: budgetGuard.getSessionCost(id),
      })
      if (budgetResult.action === 'warn') {
        process.stderr.write(`[budget] Attention : ${budgetResult.message}\n`)
      } else if (budgetResult.action === 'stop') {
        process.stderr.write(`[budget] STOP : ${budgetResult.message}\n`)
        state.status    = 'failed'
        state.blockedAt = phaseId
        state.activePhase = null
        // Annoter la raison dans le state avant sauvegarde
        phase.error = `budget_exceeded: ${budgetResult.message}`
        saveState(state)
        releaseLock(id)
        process.exit(1)
      } else if (budgetResult.action === 'downgrade_tier') {
        // Persister le downgrade dans state.phases[x].tierOverride (le clone était jeté avant)
        const pipelineDefForDowngrade = loadPipeline(state.pipeline)
        const downgradedPhases = []
        for (const pDef of pipelineDefForDowngrade.phases) {
          const pState = state.phases[pDef.id]
          const currentTier = pState?.tierOverride ?? pDef.tier ?? 2
          if (pState && pState.status === 'pending' && currentTier > 1) {
            pState.tierOverride = currentTier - 1
            downgradedPhases.push({ id: pDef.id, from: currentTier, to: pState.tierOverride })
          }
        }
        require('./logger').warn('budget', 'Tier downgrade persisted in state', {
          runId: id, phases: downgradedPhases, reason: budgetResult.message,
        })
      }
    } catch (e) {
      require('./logger').warn('budget', 'Budget guard check failed', { phaseId, error: e?.message })
    }

    // Mettre à jour le router Thompson Sampling + ReasoningBank
    routerUpdate(phaseId, phase.agent, 'success', telemetry.tokens, durationMs || null)
    bankStore(phaseId, phase.agent, 'success', summary, id, durationMs)

    // Micro-lessons : extraire et stocker une leçon (fire-and-forget)
    try {
      const ml = require('./micro-lessons.js')
      ml.store(phaseId, phase.agent, 'success', summary, id)
    } catch (e) {
      require('./logger').warn('micro-lessons', 'store(success) failed', { phaseId, error: e?.message })
    }

    // Vérifier si toutes les phases sont terminales (completed / skipped / failed)
    const allTerminal = Object.values(state.phases).every(p =>
      ['completed', 'skipped', 'failed'].includes(p.status)
    )

    runLog(id, 'info', 'phase.completed', { phaseId, agent: phase.agent, durationMs })

    if (allTerminal) {
      const anyFailed = Object.values(state.phases).some(p => p.status === 'failed' && p.required)
      state.status = anyFailed ? 'completed_with_errors' : 'completed'
      state.completedAt = ts()
      state.activePhase = null
      const completedPhases = Object.values(state.phases).filter(p => p.status === 'completed').length
      const totalPhases = Object.keys(state.phases).length
      runLog(id, 'info', 'run.completed', { status: state.status, totalPhases, completedPhases })
      ok(`Phase '${phaseId}' terminée`)
      ok(`Run complet : ${id}`)
      saveState(state)
      emitIPC('run.completed', { runId: id, pipeline: state.pipeline, status: state.status, totalTokens: state.totalTokens ?? 0, totalCost: state.totalCost ?? 0 })
      appendAudit('phase.done', phaseId, 'runId=' + id)
      // Webhook — run complete
      if (state.status === 'completed' || state.status === 'completed_with_errors') {
        dispatchWebhook('run.complete', { runId: state.id, pipeline: state.pipeline, totalCost: state.totalCost ?? 0 })
      }

      // PR Autopilot — déclenché uniquement sur completed (pas completed_with_errors)
      if (state.status === 'completed') {
        try {
          const prCfg = loadPrConfig()
          if (prCfg?.enabled) {
            if (prCfg.autoCreate) {
              dispatchPrWorker(state.id, state)
            } else {
              process.stdout.write(`[pr-autopilot] Run complet — créer la PR ? (ada pr create ${state.id})\n`)
            }
          }
        } catch {}
      }
    } else {
      const pipelineDef = loadPipeline(state.pipeline)
      const phases = pipelineDef.phases
      const currentIdx = phases.findIndex(p => p.id === phaseId)
      const nextPhase = phases.slice(currentIdx + 1).find(p => state.phases[p.id]?.status === 'pending')
      if (nextPhase) {
        state.activePhase = nextPhase.id
        ok(`Phase '${phaseId}' terminée`)
        console.log('')
        info(`Prochaine phase : ${C.bold}${nextPhase.id}${C.reset}  [agent: ${state.phases[nextPhase.id]?.agent}]`)
        console.log(`  node run.js start ${id} ${nextPhase.id}`)
      } else {
        ok(`Phase '${phaseId}' terminée`)
      }
      saveState(state)
      emitIPC('run.phase.completed', { runId: id, phaseId, agent: phase.agent, tokens: telemetry.tokens ?? null, cost: telemetry.cost ?? null, durationMs: durationMs ?? null })
      appendAudit('phase.done', phaseId, 'runId=' + id)
    }
  } finally {
    releaseLock(id)
  }
}

function cmdFail(args) {
  // Parse --tokens / --cost before extracting other flags
  const { tokens, cost, remaining: remaining0 } = parseTokenCostFlags(args)
  const isRetry = remaining0.includes('--retry')

  // Extract --error-output <filepath> (AI Engineering Loop)
  let errorOutputFile = null
  const eoIdx = remaining0.findIndex(a => a === '--error-output')
  if (eoIdx !== -1 && remaining0[eoIdx + 1]) errorOutputFile = remaining0[eoIdx + 1]

  const filtered = remaining0.filter((a, i) => {
    if (a === '--retry' || a === '--error-output') return false
    if (eoIdx !== -1 && i === eoIdx + 1) return false
    return true
  })
  const [id, phaseId, ...rest] = filtered
  let errorMsg = rest.join(' ')
  if (!id || !phaseId) { console.error('Usage: run.js fail <runId> <phaseId> "<error>" [--retry] [--tokens <n>] [--cost <n>] [--error-output <filepath>]'); process.exit(1) }

  let safeError = errorMsg
  try {
    const { assertSafe } = require('./ada-defence.js')
    assertSafe(safeError, 'run.fail.error', { internal: true })
  } catch (e) {
    if (e && e.type === 'INJECTION') {
      safeError = '[REDACTED — injection détectée]'
      process.stderr.write(`[AIDefence] injection dans cmdFail phase ${phaseId}\n`)
    }
  }
  errorMsg = safeError

  if (!acquireLock(id)) {
    console.error('Run verrouillé — réessayer dans un instant')
    process.exit(1)
  }
  try {
    const state = loadState(id)
    const phase = state.phases[phaseId]
    if (!phase) { console.error(`Phase not found: ${phaseId}`); throw new Error(`Phase not found: ${phaseId}`) }

    const pipelineDef = loadPipeline(state.pipeline)
    const phaseDef = pipelineDef.phases.find(p => p.id === phaseId)

    // Token/cost tracking (even on retry/fail) — --tokens explicite sinon fallback
    const telemetry = resolveTelemetry(id, phaseId, phase, tokens, cost, state)
    if (telemetry.tokens != null) phase.tokens = telemetry.tokens
    if (telemetry.cost   != null) phase.cost   = telemetry.cost
    if (telemetry.source)         phase.tokensSource = telemetry.source
    state.totalTokens = (state.totalTokens ?? 0) + (telemetry.tokens ?? 0)
    state.totalCost   = (state.totalCost   ?? 0) + (telemetry.cost   ?? 0)

    // Budget guard — enregistrement sur fail également
    try {
      const phaseCost = telemetry.cost ?? 0
      budgetGuard.recordCost(id, phaseCost, phase.agent || undefined)
    } catch (e) {
      require('./logger').warn('budget', 'recordCost failed — budget tracking may be inaccurate', { runId: id, phaseId, error: e?.message })
    }

    if (isRetry && phase.retries < (phaseDef?.maxRetries || 0)) {
      phase.retries++
      phase.status = 'retrying'
      phase.error = errorMsg

      // ── F4 — Smart Retry avec Diagnostic ─────────────────────────────────
      // Récupérer les trajectoires d'échec similaires depuis le bank
      // et les stocker dans phase.retryContext pour guider la prochaine tentative.
      try {
        if (existsSync(BANK_FILE)) {
          const bank = require(BANK_FILE)
          if (typeof bank.retrieve === 'function') {
            const failureTrajectories = bank.retrieve(errorMsg, { limit: 3 }) || []
            const failures = Array.isArray(failureTrajectories)
              ? failureTrajectories.filter(t => t.verdict === 'failure')
              : []
            if (failures.length) {
              const corrections = failures
                .map(t => t.summary)
                .filter(Boolean)
                .slice(0, 3)
              phase.retryContext = {
                failurePatterns: failures.map(t => ({ id: t.id, summary: t.summary })),
                corrections,
                errorMsg,
                retryN: phase.retries,
              }
              runLog(id, 'warn', 'smart-retry.context', { phaseId, failures: failures.length })
              process.stderr.write(`[smart-retry] ${phaseId} retry #${phase.retries} — injected ${failures.length} failure patterns\n`)
            }
          }
        }
      } catch (e) {
        require('./logger').warn('smart-retry', 'Retry context injection failed — retry will run without failure patterns', { phaseId, error: e?.message })
      }

      // Auto-retry signal avec backoff exponentiel
      const backoffMs = Math.min(1000 * Math.pow(2, phase.retries - 1), 30000)  // 1s, 2s, 4s ... max 30s
      phase.retryAt = new Date(Date.now() + backoffMs).toISOString()
      phase.retryReason = errorMsg

      saveState(state)
      emitIPC('run.phase.failed', { runId: id, phaseId, agent: phase.agent, error: errorMsg, retryable: isRetry, tokens: telemetry.tokens ?? null, cost: telemetry.cost ?? null })
      console.log(`${C.yellow}⟳ AUTO-RETRY${C.reset} [${phaseId}] dans ${backoffMs/1000}s (tentative ${phase.retries}/${phaseDef.maxRetries})`)
      console.log(`  Lancer : node run.js start ${id} ${phaseId}`)
      appendAudit('phase.fail', phaseId, 'runId=' + id + ' retry=1')
      return
    }

    phase.status = 'failed'
    phase.completedAt = ts()
    phase.error = errorMsg

    // ── AI Engineering Loop — parse error output si fourni ────────────────────
    let errorFileContent = null
    if (errorOutputFile) {
      try {
        const { validatePath } = require('./path-validator.js')
        const pathCheck = validatePath(errorOutputFile, process.env.CLAUDE_CONFIG_DIR || join(process.env.HOME ?? '', '.claude'))
        if (pathCheck.safe) {
          errorFileContent = readFileSync(pathCheck.resolved, 'utf8')
          const ec = require('./error-context.js')
          const retryCtx = ec.buildRetryContext(
            { status: 'failed', error: errorFileContent },
            (state.loopIteration ?? 0) + 1,
            phaseDef?.maxLoops ?? 3,
          )
          phase.errorContext = retryCtx
        } else {
          require('./logger').warn('error-context', 'error-output path rejected — skipping read', { phaseId, path: errorOutputFile, reason: pathCheck.reason })
        }
      } catch (e) {
        require('./logger').warn('error-context', 'parse failed — loop-back context unavailable', { phaseId, error: e?.message })
      }
    }

    const durationMsFail = phase.startedAt ? Date.now() - new Date(phase.startedAt).getTime() : null

    runLog(id, 'error', 'phase.failed', { phaseId, agent: phase.agent, error: errorMsg })

    // Mettre à jour le router Thompson Sampling + ReasoningBank (échec définitif, pas retry)
    routerUpdate(phaseId, phase.agent, 'failure', telemetry.tokens, durationMsFail || null)
    bankStore(phaseId, phase.agent, 'failure', errorMsg, id, durationMsFail)

    // Micro-lessons : extraire et stocker une leçon d'échec (fire-and-forget)
    try {
      const ml = require('./micro-lessons.js')
      ml.store(phaseId, phase.agent, 'failure', errorMsg, id)
    } catch (e) {
      require('./logger').warn('micro-lessons', 'store(failure) failed', { phaseId, error: e?.message })
    }

    if (phaseDef?.stopOnFailure !== false) {
      state.status = 'failed'
      state.blockedAt = phaseId
      state.activePhase = null
      fail(`Phase critique '${phaseId}' échouée — pipeline stoppé`)
      if (errorMsg) console.log(`  Erreur : ${errorMsg}`)
      console.log('')
      console.log(`Pour débloquer :`)
      console.log(`  node run.js start ${id} ${phaseId}   # relancer la phase`)
      console.log(`  node run.js skip  ${id} ${phaseId}   # sauter (si non critique)`)
      saveState(state)
      emitIPC('run.phase.failed', { runId: id, phaseId, agent: phase.agent, error: errorMsg, retryable: false, tokens: telemetry.tokens ?? null, cost: telemetry.cost ?? null })
      appendAudit('phase.fail', phaseId, 'runId=' + id + ' retry=0')
      dispatchWebhook('run.fail', { runId: state.id, pipeline: state.pipeline, failedPhase: phaseId })
    } else {
      // ── AI Engineering Loop — loop-back si loopTo configuré ─────────────────
      const loopTo    = phaseDef?.loopTo ?? null
      const maxLoops  = phaseDef?.maxLoops ?? 3
      const curIter   = state.loopIteration ?? 0
      const rawForNonDet = errorFileContent || errorMsg

      if (loopTo && state.phases[loopTo]) {
        let isNonDet = false
        try {
          const ec = require('./error-context.js')
          isNonDet = ec.isNonDeterministicError(rawForNonDet)
        } catch {}

        if (!isNonDet) {
          const nextIter = curIter + 1
          state.loopIteration = nextIter

          if (nextIter >= maxLoops) {
            // Escalade humaine — limit atteinte
            phase.summary = `[LOOP LIMIT REACHED] ${maxLoops} iterations without success. Manual intervention required.`
            state.status = 'failed'
            state.blockedAt = phaseId
            saveState(state)
            emitIPC('run.phase.failed', { runId: id, phaseId, agent: phase.agent, error: errorMsg, retryable: false, tokens: telemetry.tokens ?? null, cost: telemetry.cost ?? null })
            appendAudit('phase.fail', phaseId, `runId=${id} loop_limit=${maxLoops}`)
            fail(`[LOOP LIMIT REACHED] ${phaseId} → ${loopTo} : ${maxLoops} itérations max atteintes — intervention manuelle requise`)
          } else {
            // Loop-back : remettre la phase cible en pending avec contexte injecté
            const loopContextBlock = phase.errorContext?.formattedBlock || ''
            const targetPhase = state.phases[loopTo]
            targetPhase.status      = 'pending'
            targetPhase.loopContext = loopContextBlock
            targetPhase.startedAt   = null
            targetPhase.completedAt = null
            targetPhase.summary     = null
            targetPhase.error       = null
            state.activePhase = loopTo
            saveState(state)
            emitIPC('run.loop.back', { runId: id, phaseId, loopTo, iteration: nextIter, maxLoops })
            appendAudit('phase.loop', phaseId, `runId=${id} loopTo=${loopTo} iter=${nextIter}`)
            info(`⟳ LOOP-BACK [${phaseId} → ${loopTo}] — itération ${nextIter}/${maxLoops}`)
            console.log(`  node run.js start ${id} ${loopTo}`)
          }
          return
        }
        // isNonDet=true → chute dans le comportement standard ci-dessous
      }

      // Comportement standard (pas de loopTo, ou erreur non-déterministe)
      warn(`Phase '${phaseId}' échouée (non critique) — pipeline continue`)
      const phases = pipelineDef.phases
      const currentIdx = phases.findIndex(p => p.id === phaseId)
      const nextPhase = phases.slice(currentIdx + 1).find(p => state.phases[p.id]?.status === 'pending')
      if (nextPhase) {
        state.activePhase = nextPhase.id
        info(`Prochaine phase : ${nextPhase.id}`)
        console.log(`  node run.js start ${id} ${nextPhase.id}`)
      }
      saveState(state)
      emitIPC('run.phase.failed', { runId: id, phaseId, agent: phase.agent, error: errorMsg, retryable: false, tokens: telemetry.tokens ?? null, cost: telemetry.cost ?? null })
      appendAudit('phase.fail', phaseId, 'runId=' + id + ' retry=0')
    }
  } finally {
    releaseLock(id)
  }
}

function cmdSkip(args) {
  const [id, phaseId, ...rest] = args
  let reason = rest.join(' ') || 'skipped by operator'
  if (!id || !phaseId) { console.error('Usage: run.js skip <runId> <phaseId> "<reason>"'); process.exit(1) }

  let safeReason = reason
  try {
    const { assertSafe } = require('./ada-defence.js')
    assertSafe(safeReason, 'run.skip.reason')
  } catch (e) {
    if (e && e.type === 'INJECTION') {
      safeReason = '[REDACTED — injection détectée]'
      process.stderr.write(`[AIDefence] injection dans cmdSkip phase ${phaseId}\n`)
    }
  }
  reason = safeReason

  if (!acquireLock(id)) {
    console.error('Run verrouillé — réessayer dans un instant')
    process.exit(1)
  }
  try {
    const state = loadState(id)
    const phase = state.phases[phaseId]
    if (!phase) { console.error(`Phase not found: ${phaseId}`); throw new Error(`Phase not found: ${phaseId}`) }

    phase.status = 'skipped'
    phase.completedAt = ts()
    phase.skipReason = reason

    // Vérifier si toutes les phases sont terminales après ce skip
    const allTerminal = Object.values(state.phases).every(p =>
      ['completed', 'skipped', 'failed'].includes(p.status)
    )
    if (allTerminal && !['completed', 'completed_with_errors'].includes(state.status)) {
      const anyFailed = Object.values(state.phases).some(p => p.status === 'failed' && p.required)
      state.status = anyFailed ? 'completed_with_errors' : 'completed'
      state.completedAt = ts()
      state.activePhase = null
    }

    runLog(id, 'info', 'phase.skipped', { phaseId, reason })
    saveState(state)
    warn(`Phase '${phaseId}' skippée : ${reason}`)
    appendAudit('phase.skip', phaseId, 'runId=' + id)
  } finally {
    releaseLock(id)
  }
}

function cmdStatus(args) {
  const [id] = args
  if (!id) { console.error('Usage: run.js status <runId>'); process.exit(1) }
  const state = loadState(id)
  printStatus(state)

  // Topologie : afficher si des phases sont pending
  const hasPending = Object.values(state.phases).some(p => p.status === 'pending')
  if (hasPending) {
    const pipelines = safeReadJson(PIPELINE_FILE, {})
    const pipelineDef = (() => {
      const raw = pipelines[state.pipeline]
      if (!raw) return null
      if (Array.isArray(raw.phases)) return raw
      return null
    })()
    if (pipelineDef) {
      const topo = analyzeTopology(state, pipelineDef)
      if (topo.topology === 'parallel_mesh' && topo.parallelizable.length >= 2) {
        console.log(`${C.cyan}⚡ PARALLEL_MESH${C.reset} — ${topo.parallelizable.length} phases parallélisables (${topo.ratio}%)`)
        console.log(`Lancer simultanément : ${topo.parallelizable.join(', ')}`)
        console.log('')
      }
    }

    // Micro-lessons : afficher les leçons pour la prochaine phase pending
    const nextPhase = Object.entries(state.phases).find(([, p]) => p.status === 'pending')?.[0]
    if (nextPhase) {
      try {
        const ml = require('./micro-lessons.js')
        const hint = ml.inject(nextPhase)
        if (hint) console.log(`\n${hint}`)
      } catch {}
    }
  }

  // Circuit-breaker : afficher les phases en attente de retry
  const retrying = Object.entries(state.phases).filter(([, p]) => p.status === 'retrying' || (p.status === 'pending' && p.retryAt))
  if (retrying.length) {
    console.log(`\n${C.yellow}⟳ En attente de retry :${C.reset}`)
    for (const [pid, phase] of retrying) {
      const wait = Math.max(0, new Date(phase.retryAt).getTime() - Date.now())
      console.log(`  ${pid} dans ${Math.ceil(wait/1000)}s`)
    }
  }
}

// ── Commande next : phases parallélisables ────────────────────────────────────

/**
 * Retourne toutes les phases "prêtes" (dépendances satisfaites, status pending).
 * Quand plusieurs phases sont prêtes simultanément → l'orchestrateur les délègue en parallèle.
 * Flag --json : sortie structurée pour l'orchestrateur (topology + ready phases + model hints).
 *
 * ADR-023 étape 5 : si `~/.ada.json.adaptivePipelines.<pipeline>` est `true` et
 * que le pipeline est éligible (`review` seul pour l'instant), `topology` vaut
 * `'adaptive'` et la sortie inclut un champ `adaptive` (mandat de revue +
 * plafonds de gouvernance étape 4) au lieu de faire suivre les 2 phases
 * figées. Flag désactivé par défaut → comportement 100% inchangé.
 */
function cmdNext(args) {
  const [id] = args.filter(a => !a.startsWith('--'))
  if (!id) { console.error('Usage: run.js next <runId> [--json]'); process.exit(1) }

  const state       = loadState(id)
  const pipelineDef = loadPipeline(state.pipeline)

  const readyPhases = []
  for (const phaseDef of pipelineDef.phases) {
    const phase = state.phases[phaseDef.id]
    if (!phase || phase.status !== 'pending') continue

    // Vérifier que toutes les dépendances sont satisfaites
    const depsOk = (phaseDef.depends || []).every(dep => {
      const depPhase = state.phases[dep]
      return depPhase && ['completed', 'skipped'].includes(depPhase.status)
    })
    if (depsOk) readyPhases.push({
      id: phaseDef.id,
      agent: phase.agent,
      label: phaseDef.label,
      tier: phaseDef.tier,
      required: phase.required,
    })
  }

  // ── Mode JSON (pour l'orchestrateur) ──────────────────────────────────────
  if (args.includes('--json')) {
    const topo = analyzeTopology(state, pipelineDef)

    // ADR-023 étape 5 — bascule adaptative réversible par flag (défaut : off,
    // topologie inchangée). Restreinte au pipeline `review` pour l'instant.
    const adaptiveConfig = loadAdaptivePipelinesConfig()
    const pipelineName    = state.pipeline
    const mandates = adaptiveConfig[pipelineName] === true
      ? loadApplicableReviewMandates(pipelineDef.phases.map(p => p.id))
      : []
    const governanceConfig = budgetGuard.loadBudgetConfig()
    const effectiveTopo = resolveEffectiveTopology(topo, pipelineName, adaptiveConfig, mandates, governanceConfig)

    const output = {
      runId: id,
      topology: effectiveTopo.topology,
      ready: readyPhases.map(p => {
        const ph = state.phases[p.id]
        const effectiveTier = ph?.tierOverride ?? p.tier ?? 2
        return {
          phaseId: p.id,
          agent: ph?.agent || p.agent,
          tier: effectiveTier,
          required: p.required,
          model: recommendModel(effectiveTier),
          // F2 — ACW context (populated by cmdStart, null if bank unavailable)
          acwContext: ph?.acwContext ?? null,
          // F4 — Retry diagnostic (populated by cmdFail retry block)
          retryContext: ph?.retryContext ?? null,
          // AI Engineering Loop — error context injection
          loopContext: ph?.loopContext ?? null,
          isLoopRetry: !!(ph?.loopContext),
        }
      }),
      parallelizable: effectiveTopo.parallelizable,
      // ADR-023 étape 5 — présent uniquement quand topology === 'adaptive'.
      ...(effectiveTopo.adaptive ? { adaptive: effectiveTopo.adaptive } : {}),
    }
    console.log(JSON.stringify(output, null, 2))
    return
  }

  // ── Mode display normal ────────────────────────────────────────────────────

  if (!readyPhases.length) {
    if (['completed', 'completed_with_errors', 'failed'].includes(state.status)) {
      info(`Run terminé [${state.status}]`)
    } else {
      info(`Aucune phase prête — phases en cours ou toutes complètes`)
    }
    return
  }

  // ── Estimation préventive (sauf --no-estimate) ─────────────────────────────
  if (!args.includes('--no-estimate') && readyPhases.length > 0) {
    try {
      // B6 — router.js exporte `loadState` (pas `loadRouterState`) : l'ancien
      // destructuring donnait undefined, le ternaire le masquait en {} et
      // estimateRun retombait TOUJOURS sur ses valeurs par défaut (50k tokens /
      // 30s / 50% de succès), rendant l'estimation préventive purement décorative.
      const { loadState: loadRouterState } = require('./router.js')
      const routerState = typeof loadRouterState === 'function' ? loadRouterState() : { priors: {} }
      const estimates = estimateRun(readyPhases, routerState)
      if (estimates.length > 0) {
        console.log(`\n${C.cyan}${C.bold}Estimation des phases :${C.reset}`)
        console.log(formatEstimate(estimates))
      }
    } catch (e) {
      // Ne plus avaler l'erreur en silence (c'est ce qui a masqué B6 : mauvais nom
      // d'export → estimation muette sur les défauts pendant des mois).
      require('./logger').warn('estimate', 'estimation préventive indisponible', { runId: id, error: e?.message })
    }
  }

  const topo = analyzeTopology(state, pipelineDef)

  if (readyPhases.length === 1) {
    console.log(`\n${C.bold}PHASE SUIVANTE (séquentielle) :${C.reset}\n`)
    const p = readyPhases[0]
    console.log(`  ${C.cyan}→${C.reset} ${C.bold}${p.id}${C.reset}  [agent: ${p.agent}]  ${C.gray}${p.label || ''}${C.reset}`)
    console.log(`\n  node run.js start ${id} ${p.id}`)
  } else {
    if (topo.topology === 'parallel_mesh') {
      console.log(`\n${C.cyan}${C.bold}LANCER SIMULTANÉMENT (utiliser Task multiple dans Claude Code) :${C.reset}\n`)
    } else {
      console.log(`\n${C.bold}${readyPhases.length} phases prêtes :${C.reset}\n`)
    }
    for (const p of readyPhases) {
      console.log(`  ${C.cyan}→${C.reset} ${C.bold}${p.id}${C.reset}  [agent: ${p.agent}]  ${C.gray}${p.label || ''}${C.reset}`)
    }
    console.log(`\n  ${C.yellow}Déléguer aux ${readyPhases.length} agents simultanément via Task tool.${C.reset}`)
    for (const p of readyPhases) {
      console.log(`  node run.js start ${id} ${p.id}`)
    }
  }

  // Afficher la topologie
  if (topo.topology === 'parallel_mesh' && topo.parallelizable.length >= 2) {
    console.log(`\n${C.cyan}PARALLEL_MESH${C.reset} — ${topo.parallelizable.length} phases parallélisables (${topo.ratio}%)`)
    console.log(`Lancer simultanément : ${topo.parallelizable.join(', ')}`)
  }
}

function cmdList() {
  if (!existsSync(RUNS_DIR)) { info('Aucun run enregistré'); return }
  const runs = readdirSync(RUNS_DIR).filter(d => existsSync(join(RUNS_DIR, d, 'state.json')))
  if (!runs.length) { info('Aucun run enregistré'); return }

  console.log(`\n${C.bold}Runs enregistrés :${C.reset}\n`)
  for (const id of runs.reverse().slice(0, 20)) {
    const state = safeReadJson(join(RUNS_DIR, id, 'state.json'), {})
    const icon = STATUS_ICONS[state.status] || '?'
    const elapsed = state.completedAt
      ? `${Math.round((new Date(state.completedAt) - new Date(state.startedAt)) / 1000)}s`
      : `${Math.round((Date.now() - new Date(state.startedAt)) / 1000)}s`
    const costStr = state.totalCost ? ` $${state.totalCost.toFixed(4)}` : ''
    console.log(`  ${icon} ${C.bold}${state.args.name}${C.reset}  ${C.gray}[${state.status}]  ${elapsed}${costStr}  ${id}${C.reset}`)
  }
  console.log('')
}


// ── Rollback ──────────────────────────────────────────────────────────────────

function cmdRollback(args) {
  const [id, phaseId] = args
  if (!id) { console.error('Usage: run.js rollback <runId> [<phaseId>]'); process.exit(1) }

  if (!acquireLock(id)) { console.error('Run verrouillé — réessayer'); process.exit(1) }
  try {
    const state = loadState(id)

    if (phaseId) {
      // Rollback d'une phase spécifique → la repasser en 'pending'
      if (!state.phases[phaseId]) { console.error(`Phase inconnue: ${phaseId}`); process.exit(1) }
      state.phases[phaseId].status      = 'pending'
      state.phases[phaseId].startedAt   = undefined
      state.phases[phaseId].completedAt = undefined
      state.phases[phaseId].summary     = undefined
      state.status = 'running'
      saveState(state)
      runLog(id, 'warn', 'run.rollback', { scope: phaseId })
      ok(`Phase '${phaseId}' repassée en pending pour rollback`)
    } else {
      // Rollback global → marquer le run comme rolled_back
      state.status = 'rolled_back'
      state.completedAt = ts()
      saveState(state)
      runLog(id, 'warn', 'run.rollback', { scope: 'full' })
      warn(`Run '${id}' marqué rolled_back`)
    }
    appendAudit('run.rollback', id, 'phase=' + (phaseId ?? 'all'))
  } finally {
    releaseLock(id)
  }
}

// ── Retry ─────────────────────────────────────────────────────────────────────

function cmdRetry(args) {
  const [id] = args
  if (!id) { console.error('Usage: run.js retry <runId>'); process.exit(1) }
  validateRunId(id)
  if (!acquireLock(id)) { console.error('Run verrouillé — réessayer'); process.exit(1) }
  try {
    const state = loadState(id)
    // Reset only failed phases (skipped phases were intentionally skipped by flags — don't touch them)
    let resetCount = 0
    for (const [phaseId, phase] of Object.entries(state.phases)) {
      if (phase.status === 'failed') {
        state.phases[phaseId] = {
          ...phase,
          status: 'pending',
          startedAt: undefined,
          completedAt: undefined,
          error: undefined,
          summary: undefined,
          retries: 0,
        }
        resetCount++
      }
    }
    state.status = resetCount > 0 ? 'running' : state.status
    saveState(state)
    console.log(`✓ Retry: ${resetCount} phase(s) remises en pending — run ${id}`)
    appendAudit('run.retry', id, `phases_reset=${resetCount}`)
  } finally {
    releaseLock(id)
  }
}

// ── Sélection d'agent par phase (A0 — routing Thompson activé) ────────────────

/**
 * Sélectionne l'agent d'une phase, en DEUX régimes strictement séparés :
 *
 *  1. Choix de STACK (B1) — si l'agent déclaré appartient à une famille de stacks
 *     mutuellement exclusives (nestjs↔drf), la sélection est déterministe : la
 *     stack déclarée du run (state.args.backend, allowlistée à l'init) gagne
 *     TOUJOURS. Jamais de Thompson : un projet est NestJS OU Django, ce n'est pas
 *     une préférence que l'on apprend. Couvre aussi les pipelines qui déclarent
 *     'nestjs' sans agentSelector (bug-fix.fix, saas-bootstrap.backend,
 *     perf-audit.fixes) — auparavant un run `--backend drf` y recevait nestjs.
 *
 *  2. Choix SUBSTITUABLE — plusieurs agents objectivement qualifiés pour la même
 *     phase (review: reviewer↔security-auditor…) : Thompson arbitre, c'est son
 *     rôle légitime.
 *
 * ⚠ Garde-fou : PHASE_CANDIDATES est indexé par phase.id NU, or le même id existe
 * dans plusieurs pipelines avec des agents de familles différentes ('review' =
 * reviewer dans feature, technical-architect dans api-design, performance-analyst
 * dans perf-audit). Le router n'est donc consulté QUE si l'agent déclaré par le
 * pipeline figure parmi les candidats — sinon le pipeline garde son agent. Sans
 * ce garde-fou, ajouter un 2ᵉ candidat à un id partagé substituerait un agent
 * hors-sujet dans les autres pipelines.
 *
 * @param {PipelinePhase} phase
 * @param {RunState} state
 * @returns {{ agent: string, source: 'router'|'stack'|'static', reason: string, confidence: string|number }}
 */
function selectAgentForPhase(phase, state) {
  const staticAgent = phase.agentSelector === 'backend'
    ? (state.args?.backend === 'drf' ? phase.agentAlt : phase.agent)
    : phase.agent
  try {
    const { recommendWithContext, PHASE_CANDIDATES, stackFamilyOf } = require('./router.js')

    // ── 1. Famille de stacks → déterministe, jamais appris ────────────────────
    const family = typeof stackFamilyOf === 'function' ? stackFamilyOf(staticAgent) : null
    if (family && family.name === 'backend') {
      const declared = state.args?.backend
      if (declared && family.agents.includes(declared)) {
        return {
          agent:      declared,
          source:     'stack',
          reason:     `Stack backend déclarée du run (${declared}) — choix déterministe, jamais arbitré par Thompson`,
          confidence: 'stack',
        }
      }
      // Stack non déclarée → on garde l'agent du pipeline (déterministe aussi).
      return { agent: staticAgent, source: 'static', reason: 'stack non déclarée — agent du pipeline', confidence: 'stack' }
    }

    // ── 2. Choix réellement substituable → Thompson ───────────────────────────
    const candidates = PHASE_CANDIDATES[phase.id]
    if (candidates && candidates.length > 1 && candidates.includes(staticAgent) && typeof recommendWithContext === 'function') {
      const r = recommendWithContext(phase.id, staticAgent, { candidates })
      if (r && r.agent) return { agent: r.agent, source: 'router', reason: r.reason || 'thompson', confidence: r.confidence ?? 'none' }
    }
  } catch (e) {
    require('./logger').warn('router', 'selectAgentForPhase échec — fallback statique', { phase: phase?.id, error: e?.message })
  }
  return { agent: staticAgent, source: 'static', reason: 'static', confidence: 'none' }
}

// ── Model recommendation par tier ────────────────────────────────────────────

/**
 * Retourne le modèle recommandé selon le tier de la phase.
 * Délègue à router.js (source de vérité) avec fallback inline aligné sur l'ADR.
 * @param {number} tier
 * @returns {string}
 */
function recommendModel(tier) {
  try { return require('./router.js').recommendModel(tier) } catch (e) {
    require('./logger').warn('router', 'recommendModel failed — using inline fallback', { tier, error: e?.message })
  }
  // fallback inline (aligné sur models.js — source unique de vérité)
  const { modelForTier } = require('./models.js')
  return modelForTier(tier)
}

// ── Topology detection ────────────────────────────────────────────────────────

/**
 * Analyse les phases d'un run pour recommander la topologie d'exécution.
 * parallel_mesh : plusieurs phases sans dépendances → lancer simultanément
 * sequential    : phases chaînées → exécuter en ordre
 *
 * @param {RunState} state
 * @param {Pipeline|null} pipelineDef
 * @returns {{ topology: 'parallel_mesh'|'sequential', parallelizable: string[], ratio: number }}
 */
function analyzeTopology(state, pipelineDef) {
  if (!pipelineDef?.phases) return { topology: 'sequential', parallelizable: [], ratio: 0 }

  const pending = pipelineDef.phases.filter(p => {
    const ph = state.phases[p.id]
    return ph && ph.status === 'pending'
  })

  const ready = pending.filter(p => {
    if (!p.depends || p.depends.length === 0) return true
    return p.depends.every(dep => state.phases[dep]?.status === 'completed')
  })

  const ratio = ready.length / Math.max(pending.length, 1)
  const topology = ratio >= 0.4 && ready.length >= 2 ? 'parallel_mesh' : 'sequential'

  return { topology, parallelizable: ready.map(p => p.id), ratio: Math.round(ratio * 100) }
}


// ── check-retry : phases prêtes pour retry ────────────────────────────────────

function cmdCheckRetry(args) {
  const [id] = args
  if (!id) { console.error('Usage: run.js check-retry <runId>'); process.exit(1) }
  validateRunId(id)

  const statePath = join(RUNS_DIR, id, 'state.json')
  if (!existsSync(statePath)) { console.error(`Run ${id} introuvable`); process.exit(1) }
  const state = safeReadJson(statePath, {})

  const now = Date.now()
  const ready = []

  for (const [phaseId, phase] of Object.entries(state.phases || {})) {
    if ((phase.status === 'retrying' || phase.status === 'pending') && phase.retryAt) {
      const retryAt = new Date(phase.retryAt).getTime()
      if (now >= retryAt) {
        ready.push({ phaseId, agent: phase.agent, retries: phase.retries })
      }
    }
  }

  if (!ready.length) {
    console.log('Aucun retry prêt.')
    process.exit(0)
  }

  console.log(`${C.yellow}Retries prêts :${C.reset}`)
  for (const r of ready) {
    console.log(`  → ${r.phaseId} [${r.agent}] (tentative ${r.retries}) — node run.js start ${id} ${r.phaseId}`)
  }
  // Exit code 2 = retries disponibles (pour scripting)
  process.exit(2)
}

// ── Exports (tests) ───────────────────────────────────────────────────────────

if (require.main !== module) {
  module.exports = {
    runLog,
    cmdInit, cmdStart, cmdDone, cmdFail, cmdSkip, cmdRetry, cmdRollback,
    analyzeTopology, recommendModel,
    // ADR-023 étape 5 — bascule adaptative par flag
    resolveEffectiveTopology, loadAdaptivePipelinesConfig, loadApplicableReviewMandates,
    ADAPTIVE_ELIGIBLE_PIPELINES,
    // F10 / F12
    budgetGuard,
    estimateRun,
    formatEstimate,
    // F2 / F4 — ACW + Smart Retry
    buildPhaseContext,
    injectContext,
    // P0 — Control Plane (lecture d'état propre, sans process.exit pour l'appelant in-process)
    loadState,
    loadPipeline,
    RUNS_DIR,
  }
} else {
  // ── Dispatch ────────────────────────────────────────────────────────────────

  const [,, cmd, ...rest] = process.argv

  switch (cmd) {
    case 'init':     cmdInit(rest);     break
    case 'start':    cmdStart(rest).catch(e => { process.stderr.write('[run] cmdStart error: ' + e.message + '\n'); process.exit(1) }); break
    case 'done':     cmdDone(rest);     break
    case 'fail':     cmdFail(rest);     break
    case 'skip':     cmdSkip(rest);     break
    case 'next':     cmdNext(rest);     break
    case 'status':   cmdStatus(rest);   break
    case 'rollback': cmdRollback(rest); break
    case 'retry':    cmdRetry(rest);    break
    case 'check-retry': cmdCheckRetry(rest); break
    case 'list':     cmdList();         break
    default:
      console.log(`\n${C.bold}coordinator/run.js — State machine multi-agents${C.reset}\n`)
      console.log('  init     <pipeline> <feature> [flags]             Initialise un run')
      console.log('  start    <runId> <phaseId>                        Démarre une phase')
      console.log('  done     <runId> <phaseId> "<summary>" [--tokens <n>] [--cost <n>]  Marque terminée')
      console.log('  fail     <runId> <phaseId> "<error>" [--retry] [--tokens <n>] [--cost <n>]  Marque échouée')
      console.log('  skip     <runId> <phaseId> "<reason>"             Saute une phase')
      console.log('  retry    <runId>                                   Remet phases failed/skipped en pending')
      console.log('  next     <runId> [--json]                          Phases prêtes (JSON pour orchestrateur)')
      console.log('  status   <runId>                                   Affiche l\'état d\'un run')
      console.log('  rollback <runId> [<phaseId>]                      Rollback un run ou une phase')
      console.log('  check-retry <runId>                               Phases prêtes pour retry (exit 2 si oui)')
      console.log('  list                                               Liste les runs récents')
      console.log('')
  }
}
