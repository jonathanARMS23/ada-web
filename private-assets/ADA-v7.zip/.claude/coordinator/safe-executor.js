'use strict'
/**
 * coordinator/safe-executor.js — Validation sécurisée des commandes
 *
 * Fournit validateCommand(cmd) et sanitizeArg(arg) pour les commandes
 * exécutées par les workers via spawnSync/spawn.
 */

// Caractères interdits dans les arguments (shell injection)
const FORBIDDEN_CHARS = /[;&|`$<>\\!]/
// Séquences de traversal de chemin
const PATH_TRAVERSAL  = /\.\.[/\\]/

/**
 * Valide une commande avant exécution.
 * @param {string} cmd
 * @param {string[]} args
 * @returns {{ safe: boolean, reason?: string }}
 */
function validateCommand(cmd, args = []) {
  if (!cmd || typeof cmd !== 'string') return { safe: false, reason: 'Commande vide ou invalide' }

  // Commandes autorisées pour les workers internes
  const ALLOWED_COMMANDS = new Set(['node', 'git', 'npm', 'npx', 'python', 'python3', 'pip', 'pip3', 'uv', 'ruff', 'tsc'])
  const basecmd = (cmd.split('/').pop() || cmd).split('\\').pop() || cmd
  if (!ALLOWED_COMMANDS.has(basecmd)) {
    return { safe: false, reason: `Commande non autorisée: ${basecmd}` }
  }

  // S5 — bloquer les flags d'exécution de code arbitraire des binaires autorisés.
  // (FORBIDDEN_CHARS n'attrape pas `node -e "..."`, `python -c "..."`, `git -c alias=!sh`.)
  // Les usages légitimes des workers (node <script>, git commit, npm run) n'utilisent pas ces flags.
  const DANGEROUS_FLAGS = {
    node:    new Set(['-e', '--eval', '-p', '--print']),
    python:  new Set(['-c']),
    python3: new Set(['-c']),
    git:     new Set(['-c', '--upload-pack', '--receive-pack', '--exec']),
  }
  const danger = DANGEROUS_FLAGS[basecmd]
  if (danger) {
    for (const arg of args) {
      if (typeof arg !== 'string') continue
      if (danger.has(arg.split('=')[0])) {
        return { safe: false, reason: `Flag d'exécution inline interdit pour ${basecmd}: ${arg}` }
      }
    }
  }

  for (const arg of args) {
    if (typeof arg !== 'string') continue
    if (FORBIDDEN_CHARS.test(arg)) return { safe: false, reason: `Argument dangereux: ${arg}` }
    if (arg.includes('\0')) return { safe: false, reason: 'Null byte détecté dans argument' }
    if (PATH_TRAVERSAL.test(arg)) return { safe: false, reason: `Path traversal détecté dans l'argument: "${arg}"` }
  }

  return { safe: true }
}

/**
 * Nettoie un argument en retirant les caractères dangereux.
 * @param {string} arg
 * @returns {string}
 */
function sanitizeArg(arg) {
  if (typeof arg !== 'string') return ''
  return arg.replace(FORBIDDEN_CHARS, '').replace(/\0/g, '').slice(0, 1000)
}

/**
 * Valide un verdict pour le ReasoningBank.
 * @param {string} verdict
 * @returns {boolean}
 */
function isValidVerdict(verdict) {
  return ['success', 'failure', 'partial'].includes(verdict)
}

/**
 * Valide une phase pour le router Thompson Sampling.
 * @param {string} phase
 * @returns {boolean}
 */
function isValidPhase(phase) {
  return typeof phase === 'string' && /^[a-z0-9_:\-]{1,64}$/.test(phase)
}

/**
 * Valide un agent name.
 * @param {string} agent
 * @returns {boolean}
 */
function isValidAgent(agent) {
  return typeof agent === 'string' && /^[a-z0-9\-]{1,32}$/.test(agent)
}

module.exports = { validateCommand, sanitizeArg, isValidVerdict, isValidPhase, isValidAgent }
