#!/usr/bin/env node
'use strict'

const PHASE_SCHEMA = {
  required: ['id', 'label', 'agent'],
  properties: {
    id: 'string', label: 'string', agent: 'string',
    agentAlt: 'string?', tier: 'number?',
    required: 'boolean?', maxRetries: 'number?',
    depends: 'array?', stopOnFailure: 'boolean?',
    skipIf: 'array?', rollbackPhase: 'string?', rollbackOnFailure: 'boolean?'
  }
}

const PIPELINE_SCHEMA = {
  required: ['id', 'phases'],
  properties: {
    id: 'string', label: 'string?',
    rollbackOnFailure: 'boolean?', phases: 'array'
  }
}

const RUN_STATE_SCHEMA = {
  required: ['pipeline', 'status'],
  properties: {
    pipeline: 'string', status: 'string',
    startedAt: 'string?', completedAt: 'string?',
    phases: 'object?', lockFile: 'string?'
  }
}

function validate(obj, schema, path = 'root') {
  const errors = []
  if (!obj || typeof obj !== 'object') {
    return [`${path}: expected object, got ${typeof obj}`]
  }
  for (const key of schema.required || []) {
    if (obj[key] === undefined || obj[key] === null) {
      errors.push(`${path}.${key}: required field missing`)
    }
  }
  for (const [key, type] of Object.entries(schema.properties || {})) {
    const optional = type.endsWith('?')
    const expectedType = optional ? type.slice(0, -1) : type
    const value = obj[key]
    if (value === undefined || value === null) continue
    if (expectedType === 'array' && !Array.isArray(value)) {
      errors.push(`${path}.${key}: expected array`)
    } else if (expectedType === 'object' && (typeof value !== 'object' || Array.isArray(value))) {
      errors.push(`${path}.${key}: expected object`)
    } else if (!['array', 'object'].includes(expectedType) && typeof value !== expectedType) {
      errors.push(`${path}.${key}: expected ${expectedType}, got ${typeof value}`)
    }
  }
  return errors
}

/**
 * Valide un objet pipelines.json.
 * Accepte deux formats :
 *   - tableau de pipelines (chaque élément doit avoir id + phases)
 *   - objet dictionnaire { [name]: { phases, ... } } (format actuel)
 */
function validatePipelines(pipelinesData) {
  if (pipelinesData === null || typeof pipelinesData !== 'object') {
    return ['pipelines: expected object or array at root']
  }

  const errors = []

  if (Array.isArray(pipelinesData)) {
    for (let i = 0; i < pipelinesData.length; i++) {
      const p = pipelinesData[i]
      errors.push(...validate(p, PIPELINE_SCHEMA, `pipeline[${i}]`))
      if (Array.isArray(p?.phases)) {
        for (let j = 0; j < p.phases.length; j++) {
          errors.push(...validate(p.phases[j], PHASE_SCHEMA, `pipeline[${i}].phases[${j}]`))
        }
      }
    }
    return errors
  }

  // Format dictionnaire { name: { phases, ... } }
  const entries = Object.entries(pipelinesData).filter(([k]) => !k.startsWith('_'))
  for (const [name, p] of entries) {
    if (!p || typeof p !== 'object') {
      errors.push(`pipeline[${name}]: expected object`)
      continue
    }
    if (!Array.isArray(p.phases)) {
      errors.push(`pipeline[${name}].phases: required field missing`)
      continue
    }
    for (let j = 0; j < p.phases.length; j++) {
      errors.push(...validate(p.phases[j], PHASE_SCHEMA, `pipeline[${name}].phases[${j}]`))
    }
  }
  return errors
}

function validateRunState(state) {
  return validate(state, RUN_STATE_SCHEMA)
}

function assertValid(errors, context) {
  if (errors.length > 0) {
    throw new Error(`Schema validation failed (${context}):\n  ${errors.join('\n  ')}`)
  }
}

module.exports = { validatePipelines, validateRunState, validate, assertValid }
