'use strict'
/**
 * shell-lexer.js — State-machine de tokenisation shell (zéro dépendance).
 *
 * But sécurité : découper une commande composée en segments AUX BONNES
 * frontières (opérateurs hors-quotes) pour que les règles de blocage
 * s'appliquent à CHAQUE segment, et pas seulement à la chaîne brute.
 *
 * Pattern porté de rtk (src/discover/lexer.rs, src/hooks/permissions.rs) :
 *  - parcours caractère par caractère
 *  - suivi de l'état des quotes simples/doubles et des échappements (\)
 *  - ne coupe QUE sur les opérateurs hors-quotes : && || ; | & \n
 *  - les substitutions $()/backticks et les redirections sont détectées
 *    comme des constructions (flags), jamais coupées
 *
 * États gérés par la machine :
 *   - escaped        : le caractère suivant est littéral (hors single-quote)
 *   - inSingle       : dans une chaîne '...'
 *   - inDouble       : dans une chaîne "..."
 *   - inBacktick     : dans une substitution `...`
 *   - parenDepth     : profondeur d'imbrication d'une substitution $( ... )
 *
 * Exports :
 *   - splitCompoundCommand(cmd) → string[]  (segments hors-quotes)
 *   - analyzeCommand(cmd)       → { segments, substitutions,
 *                                   hasSubstitution, hasBackticks,
 *                                   hasEval, hasRedirection }
 */

/**
 * Scan principal : produit les segments (découpe hors-quotes) et le flag
 * de redirection. Les substitutions $()/backticks restent opaques (non
 * coupées) — leur contenu est extrait séparément par scanSubstitutions().
 *
 * @param {string} cmd
 * @returns {{ segments: string[], hasRedirection: boolean }}
 */
function splitScan(cmd) {
  const out = { segments: [], hasRedirection: false }
  if (typeof cmd !== 'string' || cmd.length === 0) return out

  const chars = Array.from(cmd)
  let seg = ''
  let inSingle = false
  let inDouble = false
  let inBacktick = false
  let parenDepth = 0
  let escaped = false

  const push = () => {
    const s = seg.trim()
    if (s) out.segments.push(s)
    seg = ''
  }

  for (let i = 0; i < chars.length; i++) {
    const c = chars[i]
    const next = i + 1 < chars.length ? chars[i + 1] : ''

    // 1. Caractère échappé → littéral
    if (escaped) { seg += c; escaped = false; continue }
    if (c === '\\' && !inSingle) { escaped = true; seg += c; continue }

    // 2. Dans une single-quote : tout est littéral jusqu'à la fermeture
    if (inSingle) { seg += c; if (c === "'") inSingle = false; continue }

    // 3. Dans une substitution backtick : opaque jusqu'à la fermeture
    if (inBacktick) { seg += c; if (c === '`') inBacktick = false; continue }

    // 4. Dans une substitution $( ... ) : opaque, on suit la profondeur
    if (parenDepth > 0) {
      if (c === '(') parenDepth++
      else if (c === ')') parenDepth--
      seg += c
      continue
    }

    // 5. Ouverture de quotes / substitutions (valides aussi dans "..." )
    if (c === "'" && !inDouble) { inSingle = true; seg += c; continue }
    if (c === '"') { inDouble = !inDouble; seg += c; continue }
    if (c === '`') { inBacktick = true; seg += c; continue }
    if (c === '$' && next === '(') { parenDepth++; seg += '$('; i++; continue }

    // 6. Dans une double-quote : littéral (pas de coupe sur opérateur)
    if (inDouble) { seg += c; continue }

    // 7. Opérateurs hors-quotes → frontières de segment
    if (c === '\n' || c === '\r' || c === ';') { push(); continue }
    if (c === '&') {
      if (next === '&') { push(); i++; continue }        // && logique
      if (next === '>') { out.hasRedirection = true; seg += c; continue } // &> redir
      if (next && /[0-9-]/.test(next)) { seg += c; continue }             // >&1 / >&- fd-dup
      push(); continue                                    // & background
    }
    if (c === '|') {
      if (next === '&') { push(); i++; continue }         // |& (pipe + stderr)
      if (next === '|') { push(); i++; continue }         // || logique
      push(); continue                                    // | pipe
    }

    // 8. Redirections (flag ; restent dans le segment)
    if (c === '>' || c === '<') { out.hasRedirection = true; seg += c; continue }

    // 9. Caractère ordinaire
    seg += c
  }

  push()
  return out
}

/**
 * Extrait le contenu des substitutions $( ... ) et `...`, en respectant
 * les quotes de premier niveau (une substitution en single-quote est
 * littérale et n'est donc PAS extraite — bash ne l'exécute pas).
 *
 * @param {string} cmd
 * @returns {{ substitutions: string[], hasSubstitution: boolean, hasBackticks: boolean }}
 */
function scanSubstitutions(cmd) {
  const out = { substitutions: [], hasSubstitution: false, hasBackticks: false }
  if (typeof cmd !== 'string' || cmd.length === 0) return out

  const chars = Array.from(cmd)
  let inSingle = false
  let inDouble = false
  let escaped = false

  for (let i = 0; i < chars.length; i++) {
    const c = chars[i]
    const next = i + 1 < chars.length ? chars[i + 1] : ''

    if (escaped) { escaped = false; continue }
    if (c === '\\' && !inSingle) { escaped = true; continue }
    if (c === "'" && !inDouble) { inSingle = !inSingle; continue }
    if (c === '"' && !inSingle) { inDouble = !inDouble; continue }
    if (inSingle) continue // substitution littérale → ignorée

    // Backtick : capture jusqu'au prochain backtick non échappé
    if (c === '`') {
      out.hasBackticks = true
      out.hasSubstitution = true
      let j = i + 1
      let buf = ''
      while (j < chars.length && chars[j] !== '`') {
        if (chars[j] === '\\' && j + 1 < chars.length) { buf += chars[j + 1]; j += 2; continue }
        buf += chars[j]; j++
      }
      out.substitutions.push(buf)
      i = j // la boucle incrémentera au-delà du backtick fermant
      continue
    }

    // $( ... ) : capture en suivant la profondeur de parenthèses
    if (c === '$' && next === '(') {
      out.hasSubstitution = true
      let depth = 1
      let j = i + 2
      let buf = ''
      while (j < chars.length && depth > 0) {
        const cj = chars[j]
        if (cj === '(') depth++
        else if (cj === ')') { depth--; if (depth === 0) break }
        buf += cj
        j++
      }
      out.substitutions.push(buf)
      i = j // positionné sur le ')' fermant
      continue
    }
  }

  return out
}

/** Premier mot significatif d'un segment (ignore les préfixes VAR=val). */
function firstWord(segment) {
  const toks = segment.split(/\s+/).filter(Boolean)
  for (const t of toks) {
    if (/^[A-Za-z_][A-Za-z0-9_]*=/.test(t)) continue // affectation d'env
    return t
  }
  return ''
}

/**
 * Découpe une commande composée en segments hors-quotes.
 * @param {string} cmd
 * @returns {string[]}
 */
function splitCompoundCommand(cmd) {
  return splitScan(cmd).segments
}

/**
 * Analyse complète d'une commande shell.
 * @param {string} cmd
 * @returns {{
 *   segments: string[],
 *   substitutions: string[],
 *   hasSubstitution: boolean,
 *   hasBackticks: boolean,
 *   hasEval: boolean,
 *   hasRedirection: boolean
 * }}
 */
function analyzeCommand(cmd) {
  const { segments, hasRedirection } = splitScan(cmd)
  const { substitutions, hasSubstitution, hasBackticks } = scanSubstitutions(cmd)

  let hasEval = false
  for (const s of segments) {
    if (firstWord(s) === 'eval') { hasEval = true; break }
  }
  if (!hasEval) {
    for (const sub of substitutions) {
      if (/(^|[\s;&|])eval([\s"'`$(]|$)/.test(sub)) { hasEval = true; break }
    }
  }

  return { segments, substitutions, hasSubstitution, hasBackticks, hasEval, hasRedirection }
}

module.exports = { splitCompoundCommand, analyzeCommand }
