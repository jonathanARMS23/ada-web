'use strict'
/**
 * coordinator/skill-registry.js — Skill Marketplace ADA (F14)
 *
 * Installe des skills packagés (priors Thompson, micro-lessons, templates).
 * Commande : ada skill install <name>
 *
 * Règles de sécurité :
 *   - HTTPS-only pour tous les téléchargements
 *   - SHA256 vérifié avant extraction (supply chain)
 *   - isSafeFilename sur tous les noms avant opération filesystem
 *   - validatePath (jail) pour chaque répertoire extrait
 *   - Écriture atomique (tmp→rename) pour router-state.json
 *   - Pas de zod — validation manuelle des champs requis
 */

const crypto     = require('crypto')
const fs         = require('fs')
const path       = require('path')
const os         = require('os')
const https      = require('https')
const http       = require('http')
const { spawnSync } = require('child_process')

const { isSafeFilename, validatePath } = require('./path-validator')
const { isPrivateHost } = require('./webhook')

// ── Constantes ────────────────────────────────────────────────────────────────

const REGISTRY_URL   = 'https://raw.githubusercontent.com/jonathanARMS23/ada-skills/main/index.json'
const CACHE_TTL_MS   = 3_600_000 // 1 heure
const ADA_DIR        = path.join(os.homedir(), '.ada')
const CACHE_DIR      = path.join(ADA_DIR, 'skill-cache')
const CACHE_FILE     = path.join(CACHE_DIR, 'index.json')
const SKILLS_DIR     = path.join(ADA_DIR, 'skills')
const MEMORY_DIR     = path.join(ADA_DIR, 'memory', 'skills')

const CONFIG_DIR     = process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), '.claude')
const COORD_DIR      = path.join(CONFIG_DIR, 'coordinator')
const ROUTER_STATE   = path.join(COORD_DIR, 'router-state.json')

// Répertoire de skills locaux embarqués (distribués avec ADA)
const LOCAL_SKILLS_DIR = path.join(__dirname, '..', 'skills')

// ── ANSI ──────────────────────────────────────────────────────────────────────

const C = {
  reset:  '\x1b[0m',
  bold:   '\x1b[1m',
  green:  '\x1b[32m',
  red:    '\x1b[31m',
  yellow: '\x1b[33m',
  cyan:   '\x1b[36m',
  gray:   '\x1b[90m',
}

// ── Helpers réseau ────────────────────────────────────────────────────────────

// isPrivateHost (garde SSRF) vit dans webhook.js — foyer unique partagé par
// skill-registry et plugins. Importé en tête de fichier, re-exporté pour les tests.

/**
 * Télécharge une URL HTTPS et retourne un Buffer.
 * @param {string} url
 * @param {number} [redirects=0]
 * @returns {Promise<Buffer>}
 */
function fetchUrl(url, redirects = 0) {
  return new Promise((resolve, reject) => {
    if (redirects > 5) {
      return reject(new Error(`Trop de redirections pour : ${url}`))
    }

    let parsedUrl
    try { parsedUrl = new URL(url) } catch { return reject(new Error(`URL invalide : ${url}`)) }

    // Registry distant = HTTPS uniquement (aucun caller légitime en http, y compris loopback).
    if (parsedUrl.protocol !== 'https:') {
      return reject(new Error(`HTTP non sécurisé interdit — utilisez HTTPS : ${url}`))
    }

    // SSRF — valider l'URL de DÉPART (pas seulement les redirections), tous protocoles.
    // Bloque 127.x, 10.x, 169.254.x (metadata cloud), ::1, ULA IPv6, IP décimale…
    if (isPrivateHost(parsedUrl.hostname)) {
      return reject(new Error(`Adresse privée/interne bloquée (SSRF) : ${parsedUrl.hostname}`))
    }

    const lib = parsedUrl.protocol === 'https:' ? https : http
    // S4 — anti DNS-rebinding : on épingle l'IP RÉSOLUE et on la valide.
    // Un domaine public qui résout vers une IP interne est bloqué à la connexion.
    const getOpts = {
      timeout: 15000,
      lookup(hostname, lopts, cb) {
        require('dns').lookup(hostname, lopts, (err, address, family) => {
          if (err) return cb(err)
          if (isPrivateHost(String(address))) return cb(new Error(`SSRF: IP résolue bloquée (${address})`))
          cb(null, address, family)
        })
      },
    }
    const req = lib.get(url, getOpts, res => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        // Bloquer les redirections vers des adresses privées (SSRF)
        let redirectParsed
        try { redirectParsed = new URL(res.headers.location, url) } catch {
          return reject(new Error(`URL de redirection invalide : ${res.headers.location}`))
        }
        if (isPrivateHost(redirectParsed.hostname)) {
          return reject(new Error(`Redirection vers adresse privée bloquée (SSRF) : ${redirectParsed.hostname}`))
        }
        return resolve(fetchUrl(redirectParsed.href, redirects + 1))
      }
      if (res.statusCode !== 200) {
        return reject(new Error(`HTTP ${res.statusCode} pour ${url}`))
      }
      const chunks = []
      res.on('data', chunk => chunks.push(chunk))
      res.on('end', () => resolve(Buffer.concat(chunks)))
      res.on('error', reject)
    })
    req.on('timeout', () => { req.destroy(); reject(new Error(`Timeout (15s) pour ${url}`)) })
    req.on('error', reject)
  })
}

/**
 * Calcule le SHA256 d'un Buffer.
 * @param {Buffer} buf
 * @returns {string}
 */
function computeChecksum(buf) {
  return crypto.createHash('sha256').update(buf).digest('hex')
}

// ── Helpers filesystem ────────────────────────────────────────────────────────

function ensureDir(p) {
  if (!fs.existsSync(p)) fs.mkdirSync(p, { recursive: true })
}

/**
 * Écriture atomique via tmp→rename.
 * @param {string} filePath
 * @param {string} content
 */
function atomicWrite(filePath, content) {
  const tmp = filePath + '.tmp'
  fs.writeFileSync(tmp, content, 'utf8')
  fs.renameSync(tmp, filePath)
}

// ── Validation du manifest skill.json ────────────────────────────────────────

const REQUIRED_MANIFEST_FIELDS = ['name', 'version', 'description', 'author', 'agent', 'tags', 'priors']

/**
 * Valide un manifest skill.json — validation manuelle, sans zod.
 * @param {object} manifest
 * @returns {{ valid: boolean, errors: string[] }}
 */
function validateManifest(manifest) {
  const errors = []
  for (const field of REQUIRED_MANIFEST_FIELDS) {
    if (manifest[field] === undefined || manifest[field] === null) {
      errors.push(`Champ requis manquant : ${field}`)
    }
  }
  if (manifest.name && !isSafeFilename(manifest.name)) {
    errors.push(`Nom de skill invalide : "${manifest.name}" — caractères autorisés : a-zA-Z0-9_-. (1-255 chars)`)
  }
  if (manifest.priors) {
    if (typeof manifest.priors.winRate !== 'number' || manifest.priors.winRate < 0 || manifest.priors.winRate > 1) {
      errors.push('priors.winRate doit être un nombre entre 0 et 1')
    }
    if (typeof manifest.priors.totalRuns !== 'number' || manifest.priors.totalRuns < 0) {
      errors.push('priors.totalRuns doit être un entier non-négatif')
    }
  }
  if (manifest.tags && !Array.isArray(manifest.tags)) {
    errors.push('tags doit être un tableau')
  }
  return { valid: errors.length === 0, errors }
}

// ── Index registry ────────────────────────────────────────────────────────────

/**
 * Charge le cache local si valide (TTL 1h).
 * @returns {object|null}
 */
function loadCachedIndex() {
  try {
    if (!fs.existsSync(CACHE_FILE)) return null
    const index = JSON.parse(fs.readFileSync(CACHE_FILE, 'utf8'))
    if (!index.cachedAt) return null
    if (Date.now() - index.cachedAt > CACHE_TTL_MS) return null // TTL expiré
    return index
  } catch { return null }
}

/**
 * Charge l'index du registry distant. Utilise le cache si valide ou si fetch échoue.
 * @returns {Promise<object[]>} — tableau de skill entries
 */
async function fetchRemoteIndex() {
  const cached = loadCachedIndex()
  if (cached) return cached.skills || []

  try {
    const buf   = await fetchUrl(REGISTRY_URL)
    const raw   = JSON.parse(buf.toString('utf8'))
    const index = { ...raw, cachedAt: Date.now() }
    ensureDir(CACHE_DIR)
    atomicWrite(CACHE_FILE, JSON.stringify(index, null, 2) + '\n')
    return index.skills || []
  } catch (err) {
    // Fetch échoue → fallback cache même expiré
    try {
      if (fs.existsSync(CACHE_FILE)) {
        const stale = JSON.parse(fs.readFileSync(CACHE_FILE, 'utf8'))
        process.stderr.write(`${C.yellow}⚠ Registry distant inaccessible — cache local utilisé (${err.message})${C.reset}\n`)
        return stale.skills || []
      }
    } catch {}
    return []
  }
}

/**
 * Fusionne skills locaux et distants, les locaux ont priorité.
 * @returns {Promise<object[]>}
 */
async function getAllSkills() {
  const remote = await fetchRemoteIndex()
  const local  = loadLocalSkills()
  const byName = new Map()
  // remote d'abord, puis les locaux écrasent
  for (const s of remote) byName.set(s.name, s)
  for (const s of local)  byName.set(s.name, { ...s, _local: true })
  return Array.from(byName.values())
}

/**
 * Charge les skills locaux depuis .claude/skills/.
 * @returns {object[]}
 */
function loadLocalSkills() {
  if (!fs.existsSync(LOCAL_SKILLS_DIR)) return []
  const skills = []
  try {
    const entries = fs.readdirSync(LOCAL_SKILLS_DIR, { withFileTypes: true })
    for (const entry of entries) {
      if (!entry.isDirectory()) continue
      if (!isSafeFilename(entry.name)) continue
      const manifestPath = path.join(LOCAL_SKILLS_DIR, entry.name, 'skill.json')
      if (!fs.existsSync(manifestPath)) continue
      try {
        const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'))
        skills.push({ ...manifest, _localPath: path.join(LOCAL_SKILLS_DIR, entry.name) })
      } catch {}
    }
  } catch {}
  return skills
}

// ── Thompson Priors import ────────────────────────────────────────────────────

/**
 * Importe les priors d'un skill dans router-state.json.
 * Clé : `<phaseType>:<agent>` — compatible avec router.js
 * alpha = Math.round(winRate * totalRuns) + 1
 * beta  = totalRuns - Math.round(winRate * totalRuns) + 1
 * Écriture atomique (tmp→rename).
 *
 * @param {string} skillName
 * @param {string} agent
 * @param {{ winRate: number, totalRuns: number }} priors
 * @returns {{ key: string, alpha: number, beta: number }}
 */
function importPriors(skillName, agent, priors) {
  ensureDir(COORD_DIR)

  let state = { priors: {}, totalUpdates: 0 }
  try {
    if (fs.existsSync(ROUTER_STATE)) {
      state = JSON.parse(fs.readFileSync(ROUTER_STATE, 'utf8'))
    }
  } catch {}

  const wins  = Math.round(priors.winRate * priors.totalRuns)
  const alpha = wins + 1
  const beta  = priors.totalRuns - wins + 1

  // Clé `<skillName>:<agent>` — les skills ont leur propre namespace
  // distinct des phases pipeline (ex: 'backend:nestjs')
  const key = `${skillName}:${agent}`

  const existing = state.priors[key]
  if (existing) {
    // Merger avec l'existant : cumuler les succès/echecs
    state.priors[key] = {
      ...existing,
      alpha: existing.alpha + alpha - 1,  // -1 pour éviter double-comptage du prior uniforme
      beta:  Math.max(1, existing.beta + beta - 1),
      successes: (existing.successes || 0) + wins,
      failures:  (existing.failures  || 0) + (priors.totalRuns - wins),
    }
  } else {
    state.priors[key] = {
      alpha,
      beta,
      successes: wins,
      failures:  priors.totalRuns - wins,
    }
  }

  state.totalUpdates = (state.totalUpdates || 0) + priors.totalRuns
  state.lastUpdated  = new Date().toISOString()

  atomicWrite(ROUTER_STATE, JSON.stringify(state, null, 2) + '\n')
  return { key, alpha: state.priors[key].alpha, beta: state.priors[key].beta }
}

// ── Installation depuis archive distante ─────────────────────────────────────

/**
 * Télécharge et extrait une archive .tar.gz dans un répertoire temporaire.
 * Vérifie le SHA256 avant extraction.
 * @param {string} downloadUrl
 * @param {string} expectedSha256
 * @param {string} tmpDir
 * @returns {Promise<void>}
 */
async function downloadAndExtract(downloadUrl, expectedSha256, tmpDir) {
  if (!downloadUrl.startsWith('https://')) {
    throw new Error(`URL de téléchargement non HTTPS interdite : ${downloadUrl}`)
  }

  const buf      = await fetchUrl(downloadUrl)
  const checksum = computeChecksum(buf)

  if (checksum !== expectedSha256) {
    throw new Error(`Checksum SHA256 invalide\n  attendu : ${expectedSha256}\n  reçu    : ${checksum}`)
  }

  ensureDir(tmpDir)
  const tarball = path.join(tmpDir, 'skill.tar.gz')
  fs.writeFileSync(tarball, buf)

  // Zip-slip — AVANT extraction : lister les entrées et REJETER toute entrée
  // dangereuse (chemin absolu, segment '..', null byte). spawnSync en tableau
  // d'args (jamais shell:true).
  const listing = spawnSync('tar', ['-tzf', tarball], { encoding: 'utf8' })
  if (listing.status !== 0) {
    throw new Error(`Lecture de l'archive tar échouée : ${listing.stderr || listing.stdout}`)
  }
  const tarCheck = validateTarEntries(listing.stdout)
  if (!tarCheck.safe) {
    throw new Error(`Archive tar non sûre (zip-slip) : ${tarCheck.reason}`)
  }

  const result = spawnSync('tar', ['-xzf', tarball, '-C', tmpDir], { encoding: 'utf8' })
  if (result.status !== 0) {
    throw new Error(`Extraction tar échouée : ${result.stderr || result.stdout}`)
  }
  fs.unlinkSync(tarball)

  // Défense en profondeur — APRÈS extraction : vérifier que CHAQUE fichier
  // résolu (symlinks suivis) reste bien à l'intérieur de tmpDir.
  assertExtractionJailed(tmpDir)
}

/**
 * Valide la liste des entrées d'une archive tar (sortie de `tar -tzf`).
 * Fonction PURE (pas d'I/O) — testable en isolation.
 * Rejette : chemin absolu (/…), composant '..', null byte, ~ initial.
 * @param {string} listing — stdout de `tar -tzf`, une entrée par ligne
 * @returns {{ safe: boolean, reason?: string }}
 */
function validateTarEntries(listing) {
  if (typeof listing !== 'string') return { safe: false, reason: 'listing invalide' }
  const lines = listing.split('\n').map(l => l.trim()).filter(Boolean)
  if (lines.length === 0) return { safe: false, reason: 'archive vide' }
  for (const entry of lines) {
    if (entry.includes('\0')) {
      return { safe: false, reason: `null byte dans l'entrée : ${entry}` }
    }
    if (entry.startsWith('/') || entry.startsWith('\\')) {
      return { safe: false, reason: `chemin absolu interdit : ${entry}` }
    }
    if (/^[a-zA-Z]:[\\/]/.test(entry)) {
      return { safe: false, reason: `chemin absolu Windows interdit : ${entry}` }
    }
    if (entry.startsWith('~')) {
      return { safe: false, reason: `expansion home interdite : ${entry}` }
    }
    // Segment '..' à n'importe quelle position (gère ../, /../, …/..)
    const segments = entry.split(/[/\\]/)
    if (segments.includes('..')) {
      return { safe: false, reason: `traversée de répertoire interdite : ${entry}` }
    }
  }
  return { safe: true }
}

/**
 * Parcourt récursivement un répertoire et vérifie que chaque entrée résolue
 * (symlinks compris) reste à l'intérieur de root. Throw sinon.
 * Défense en profondeur post-extraction contre les symlinks malveillants.
 * @param {string} root
 */
function assertExtractionJailed(root) {
  // realpathSync sur le root : sur macOS /var → /private/var, sinon faux positifs.
  let resolvedRoot
  try { resolvedRoot = fs.realpathSync(path.resolve(root)) } catch { resolvedRoot = path.resolve(root) }
  const prefix = resolvedRoot + path.sep
  const walk = (dir) => {
    let entries
    try { entries = fs.readdirSync(dir, { withFileTypes: true }) } catch { return }
    for (const entry of entries) {
      const full = path.join(dir, entry.name)
      // realpathSync suit les symlinks → détecte une cible hors du jail.
      let real
      try { real = fs.realpathSync(full) } catch {
        throw new Error(`Entrée extraite illisible (symlink cassé ?) : ${full}`)
      }
      if (real !== resolvedRoot && !real.startsWith(prefix)) {
        throw new Error(`Path traversal détecté après extraction : ${entry.name} → ${real}`)
      }
      if (entry.isDirectory()) walk(full)
    }
  }
  walk(resolvedRoot)
}

// ── API publique ──────────────────────────────────────────────────────────────

/**
 * Recherche des skills par nom ou tag.
 * @param {string} [query='']
 * @returns {Promise<object[]>}
 */
async function searchSkills(query = '') {
  const skills = await getAllSkills()
  if (!query) return skills

  const q = query.toLowerCase()
  return skills.filter(s => {
    const nameMatch = (s.name || '').toLowerCase().includes(q)
    const descMatch = (s.description || '').toLowerCase().includes(q)
    const tagMatch  = Array.isArray(s.tags) && s.tags.some(t => t.toLowerCase().includes(q))
    return nameMatch || descMatch || tagMatch
  })
}

/**
 * Installe un skill par son nom.
 * @param {string} skillName
 * @returns {Promise<{ installed: boolean, priorKey?: string, lessonsCount?: number, reason?: string }>}
 */
async function installSkill(skillName) {
  if (!isSafeFilename(skillName)) {
    return { installed: false, reason: `Nom de skill invalide : "${skillName}"` }
  }

  const skills = await getAllSkills()
  const entry  = skills.find(s => s.name === skillName)
  if (!entry) {
    return { installed: false, reason: `Skill inconnu : "${skillName}" — lancez 'ada skill list' pour voir les disponibles` }
  }

  const installDir = path.join(SKILLS_DIR, skillName)

  // Cas 1 : skill local (distribué avec ADA)
  if (entry._localPath) {
    return installFromLocal(entry, installDir)
  }

  // Cas 2 : skill distant avec archive
  if (entry.downloadUrl) {
    return installFromRemote(entry, installDir)
  }

  // Cas 3 : entrée registry sans archive — installer les priors et lessons inline
  return installFromRegistryEntry(entry, installDir)
}

/**
 * Installe depuis les fichiers locaux .claude/skills/<name>/.
 * @param {object} entry
 * @param {string} installDir
 */
function installFromLocal(entry, installDir) {
  const { valid, errors } = validateManifest(entry)
  if (!valid) {
    return { installed: false, reason: `Manifest invalide : ${errors.join('; ')}` }
  }

  ensureDir(installDir)

  // Copier les fichiers du skill local → ~/.ada/skills/<name>/
  const srcDir = entry._localPath
  copyDirRecursive(srcDir, installDir)

  let lessonsCount = 0
  let priorKey     = null

  // Import des priors
  if (entry.priors && typeof entry.priors.winRate === 'number') {
    const result = importPriors(entry.name, entry.agent, entry.priors)
    priorKey     = result.key
  }

  // Copier les lessons
  const lessonsSrc = path.join(srcDir, 'lessons')
  if (fs.existsSync(lessonsSrc)) {
    const lessonsDst = path.join(MEMORY_DIR, entry.name)
    ensureDir(lessonsDst)
    copyDirRecursive(lessonsSrc, lessonsDst)
    lessonsCount = fs.readdirSync(lessonsSrc).filter(f => f.endsWith('.md')).length
  }

  return { installed: true, priorKey, lessonsCount }
}

/**
 * Installe depuis une archive distante.
 * @param {object} entry
 * @param {string} installDir
 */
async function installFromRemote(entry, installDir) {
  const tmpDir = path.join(os.tmpdir(), `ada-skill-${entry.name}-${Date.now()}`)
  try {
    await downloadAndExtract(entry.downloadUrl, entry.sha256, tmpDir)

    // Trouver le manifest dans l'archive extraite
    const manifestPath = findManifest(tmpDir)
    if (!manifestPath) {
      return { installed: false, reason: 'skill.json introuvable dans l\'archive' }
    }

    const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'))
    const { valid, errors } = validateManifest(manifest)
    if (!valid) {
      return { installed: false, reason: `Manifest invalide : ${errors.join('; ')}` }
    }

    // Vérifier que le nom de la skill correspond
    if (manifest.name !== entry.name) {
      return { installed: false, reason: `Nom de skill incohérent : attendu "${entry.name}", trouvé "${manifest.name}"` }
    }

    ensureDir(installDir)
    const extractedDir = path.resolve(path.dirname(manifestPath))
    const resolvedTmp  = path.resolve(tmpDir)
    // Jail check : s'assurer que le répertoire extrait est bien dans tmpDir
    if (extractedDir !== resolvedTmp && !extractedDir.startsWith(resolvedTmp + path.sep)) {
      return { installed: false, reason: `Path traversal détecté dans l'archive (extractedDir hors du tmpDir)` }
    }
    copyDirRecursive(extractedDir, installDir)

    let lessonsCount = 0
    let priorKey     = null

    // Charger priors.json si présent, sinon utiliser manifest.priors
    let priorsData = manifest.priors
    const priorsFile = path.join(extractedDir, 'priors.json')
    if (fs.existsSync(priorsFile)) {
      try { priorsData = JSON.parse(fs.readFileSync(priorsFile, 'utf8')) } catch {}
    }

    if (priorsData && typeof priorsData.winRate === 'number') {
      const result = importPriors(manifest.name, manifest.agent, priorsData)
      priorKey     = result.key
    }

    // Copier les lessons
    const lessonsSrc = path.join(extractedDir, 'lessons')
    if (fs.existsSync(lessonsSrc)) {
      const lessonsDst = path.join(MEMORY_DIR, manifest.name)
      ensureDir(lessonsDst)
      copyDirRecursive(lessonsSrc, lessonsDst)
      lessonsCount = fs.readdirSync(lessonsSrc).filter(f => f.endsWith('.md')).length
    }

    return { installed: true, priorKey, lessonsCount }
  } finally {
    try { fs.rmSync(tmpDir, { recursive: true, force: true }) } catch {}
  }
}

/**
 * Installe une entrée de registry sans archive (priors et metadata inline).
 * @param {object} entry
 * @param {string} installDir
 */
function installFromRegistryEntry(entry, installDir) {
  const { valid, errors } = validateManifest(entry)
  if (!valid) {
    return { installed: false, reason: `Entrée registry invalide : ${errors.join('; ')}` }
  }

  ensureDir(installDir)

  // Sauvegarder le manifest
  const manifestDest = path.join(installDir, 'skill.json')
  atomicWrite(manifestDest, JSON.stringify(entry, null, 2) + '\n')

  let priorKey = null
  if (entry.priors && typeof entry.priors.winRate === 'number') {
    const result = importPriors(entry.name, entry.agent, entry.priors)
    priorKey     = result.key
  }

  return { installed: true, priorKey, lessonsCount: 0 }
}

/**
 * Liste les skills installés dans ~/.ada/skills/.
 * @returns {object[]}
 */
function listInstalled() {
  if (!fs.existsSync(SKILLS_DIR)) return []
  const skills = []
  try {
    const entries = fs.readdirSync(SKILLS_DIR, { withFileTypes: true })
    for (const entry of entries) {
      if (!entry.isDirectory()) continue
      if (!isSafeFilename(entry.name)) continue
      const manifestPath = path.join(SKILLS_DIR, entry.name, 'skill.json')
      if (!fs.existsSync(manifestPath)) continue
      try {
        const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'))
        const lessonDir = path.join(MEMORY_DIR, entry.name)
        const lessons   = fs.existsSync(lessonDir)
          ? fs.readdirSync(lessonDir).filter(f => f.endsWith('.md')).length
          : 0
        skills.push({ ...manifest, installedAt: fs.statSync(manifestPath).mtime.toISOString(), lessons })
      } catch {}
    }
  } catch {}
  return skills
}

/**
 * Désinstalle un skill.
 * @param {string} skillName
 * @returns {{ uninstalled: boolean, reason?: string }}
 */
function uninstallSkill(skillName) {
  if (!isSafeFilename(skillName)) {
    return { uninstalled: false, reason: `Nom de skill invalide : "${skillName}"` }
  }

  const skillDir  = path.join(SKILLS_DIR, skillName)
  const lessonDir = path.join(MEMORY_DIR, skillName)

  if (!fs.existsSync(skillDir)) {
    return { uninstalled: false, reason: `Skill non installé : "${skillName}"` }
  }

  // Validation jail avant suppression
  const jailCheck = validatePath(skillName, SKILLS_DIR)
  if (!jailCheck.safe) {
    return { uninstalled: false, reason: `Path invalide : ${jailCheck.reason}` }
  }

  fs.rmSync(skillDir, { recursive: true, force: true })
  if (fs.existsSync(lessonDir)) {
    fs.rmSync(lessonDir, { recursive: true, force: true })
  }

  return { uninstalled: true }
}

/**
 * Met à jour un skill installé.
 * @param {string} skillName
 * @returns {Promise<{ updated: boolean, reason?: string }>}
 */
async function updateSkill(skillName) {
  if (!isSafeFilename(skillName)) {
    return { updated: false, reason: `Nom de skill invalide : "${skillName}"` }
  }

  const skillDir = path.join(SKILLS_DIR, skillName)
  if (!fs.existsSync(skillDir)) {
    return { updated: false, reason: `Skill non installé : "${skillName}" — lancez 'ada skill install ${skillName}'` }
  }

  // Désinstaller puis réinstaller
  const unResult = uninstallSkill(skillName)
  if (!unResult.uninstalled) {
    return { updated: false, reason: `Désinstallation échouée : ${unResult.reason}` }
  }

  const inResult = await installSkill(skillName)
  if (!inResult.installed) {
    return { updated: false, reason: `Réinstallation échouée : ${inResult.reason}` }
  }

  return { updated: true, priorKey: inResult.priorKey, lessonsCount: inResult.lessonsCount }
}

/**
 * Retourne les informations détaillées d'un skill (installé ou disponible).
 * @param {string} skillName
 * @returns {Promise<object|null>}
 */
async function getSkillInfo(skillName) {
  if (!isSafeFilename(skillName)) return null

  // Chercher dans installés en premier
  const installedPath = path.join(SKILLS_DIR, skillName, 'skill.json')
  if (fs.existsSync(installedPath)) {
    try {
      const manifest  = JSON.parse(fs.readFileSync(installedPath, 'utf8'))
      const lessonDir = path.join(MEMORY_DIR, skillName)
      const lessons   = fs.existsSync(lessonDir)
        ? fs.readdirSync(lessonDir).filter(f => f.endsWith('.md'))
        : []
      return { ...manifest, installed: true, lessons }
    } catch {}
  }

  // Chercher dans le registry
  const skills = await getAllSkills()
  const entry  = skills.find(s => s.name === skillName)
  if (!entry) return null
  return { ...entry, installed: false }
}

// ── Utilitaires ───────────────────────────────────────────────────────────────

/**
 * Copie un répertoire récursivement.
 * @param {string} src
 * @param {string} dst
 */
function copyDirRecursive(src, dst) {
  ensureDir(dst)
  const entries = fs.readdirSync(src, { withFileTypes: true })
  for (const entry of entries) {
    if (!isSafeFilename(entry.name)) continue
    const srcPath = path.join(src, entry.name)
    const dstPath = path.join(dst, entry.name)
    if (entry.isDirectory()) {
      copyDirRecursive(srcPath, dstPath)
    } else {
      fs.copyFileSync(srcPath, dstPath)
    }
  }
}

/**
 * Trouve le chemin vers skill.json dans un répertoire extrait.
 * @param {string} dir
 * @returns {string|null}
 */
function findManifest(dir) {
  // Chercher à la racine d'abord
  const root = path.join(dir, 'skill.json')
  if (fs.existsSync(root)) return root

  // Puis dans les sous-dossiers immédiats
  try {
    const entries = fs.readdirSync(dir, { withFileTypes: true })
    for (const entry of entries) {
      if (!entry.isDirectory()) continue
      if (!isSafeFilename(entry.name)) continue
      const candidate = path.join(dir, entry.name, 'skill.json')
      if (fs.existsSync(candidate)) return candidate
    }
  } catch {}
  return null
}

// ── Exports ───────────────────────────────────────────────────────────────────

module.exports = {
  searchSkills,
  installSkill,
  listInstalled,
  uninstallSkill,
  updateSkill,
  getSkillInfo,
  // Exposés pour les tests
  validateManifest,
  importPriors,
  computeChecksum,
  fetchUrl,
  isPrivateHost,
  validateTarEntries,
  assertExtractionJailed,
  SKILLS_DIR,
  MEMORY_DIR,
  CACHE_FILE,
}
