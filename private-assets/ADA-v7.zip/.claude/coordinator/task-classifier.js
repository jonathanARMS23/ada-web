#!/usr/bin/env node
'use strict'
/**
 * task-classifier.js — Axe B : classifieur de complexité (solo vs pipeline).
 *
 * Décide AVANT toute délégation si une tâche justifie une décomposition
 * (pipeline multi-agents) ou si UN SEUL agent suffit (solo). Tue le surcoût
 * de décomposition (~2,5× tokens) quand la tâche est ciblée.
 *
 * Fonction PURE, déterministe, FR + EN, zéro dépendance, zéro LLM.
 *
 *   classifyTask(description, opts={}) →
 *     { mode:'solo'|'pipeline', pipeline:string|null, tier:1|2|3,
 *       signals:string[], reason:string }
 *
 * CLI :
 *   node task-classifier.js "<description>"   → affiche le JSON
 */

// ── Normalisation ───────────────────────────────────────────────────────────
// Minuscule + suppression des accents pour un matching robuste FR/EN.
function normalize(s) {
  return String(s || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .trim()
}

function wordCount(s) {
  const t = String(s || '').trim()
  return t ? t.split(/\s+/).length : 0
}

// ── Lexiques (sur texte normalisé sans accents) ─────────────────────────────

// Livrables techniques distincts. ≥2 reliés par et/+/,/avec → signal pipeline.
const DELIVERABLES = [
  { key: 'migration',  re: /\bmigrations?\b/ },
  { key: 'schema',     re: /\bsch[ée]ma\b|\bschema\b/ },
  { key: 'service',    re: /\bservices?\b/ },
  { key: 'endpoint',   re: /\bendpoints?\b/ },
  { key: 'dto',        re: /\bdtos?\b/ },
  { key: 'validation', re: /\bvalidations?\b/ },
  { key: 'tests',      re: /\btests?\b|\bspecs?\b/ },
  { key: 'frontend',   re: /\bfrontend\b|\bfront-?end\b/ },
  { key: 'ui',         re: /\bui\b|\binterface\b|\b[ée]cran?s?\b|\bpages?\b/ },
  { key: 'controller', re: /\bcontrollers?\b|\bcontroleurs?\b/ },
  { key: 'api',        re: /\bapi\b/ },
]

// Connecteurs de composition (« migration + service + tests »).
// C1 : la ponctuation SEULE (`,` `;` `:`) ne suffit pas — « documentation : mets
// à jour les specs de l'api » n'est pas une composition multi-livrables. Une
// énumération réelle (≥2 séparateurs) reste acceptée via ENUM_PUNCT_RE.
const CONNECTOR_RE = /\bet\b|\+|\bavec\b|\bpuis\b|\bainsi que\b|\bainsi qu'\b/
const ENUM_PUNCT_RE = /[,;]/g
// C1 : un connecteur ne suffit pas non plus — il faut un vrai faisceau de
// livrables distincts (3+) pour justifier une décomposition multi-agents.
const MIN_DELIVERABLES = 3
// Livrables « neutres » : présents dans presque toute tâche, ils ne suffisent
// pas à sortir d'un pipeline mono-domaine (cf. db-migrate).
const MIGRATION_NEUTRAL_KEYS = new Set(['migration', 'tests'])

// Multi-couches / stack complète → décomposer.
// NB : "saas" seul est EXCLU d'ici (C8, ADR-021 point 2) — "pour mon SaaS multi-tenant"
// est la formulation de contexte la plus courante de ce corpus pour une tâche mono-domaine
// (schéma SQL, endpoint isolé…), pas une demande de construire un SaaS complet. "saas" ne
// compte comme signal multi-couches que couplé à un verbe de construction (cf.
// SAAS_BUILD_RE plus bas) — "bootstrap" seul reste un signal fort (rarement du contexte).
const MULTILAYER_RE = /\bfull-?stack\b|\bde bout en bout\b|\bend-?to-?end\b|\bfeature compl[èe]te\b|\bbootstrap\b|\bcrud complet\b|\bback-?end et front-?end\b|\bbackend\s*\+\s*frontend\b/
const SAAS_MENTION_RE = /\bsaas\b/
const SAAS_BUILD_RE = /\b(cr[ée]e[rz]?|construi[rst]\w*|lance[rz]?|d[ée]marre[rz]?|monte[rz]?|bootstrap\w*|build)\b/

/** "saas" ne compte comme multi-couches que couplé à un verbe de construction (C8). */
function hasMultilayerSignal(n) {
  return MULTILAYER_RE.test(n) || (SAAS_MENTION_RE.test(n) && SAAS_BUILD_RE.test(n))
}
const STACK_PAIR_RE = /\bnestjs\b[\s\S]*\bnext\b|\bnext\b[\s\S]*\bnestjs\b|\bdrf\b[\s\S]*\bnext\b|\bdjango\b[\s\S]*\breact\b/

// Verbes d'action impératifs (FR + EN). ≥3 distincts = scope large.
const ACTION_VERBS = [
  'cree', 'creer', 'construis', 'construire', 'implemente', 'implementer',
  'ajoute', 'ajouter', 'genere', 'generer', 'developpe', 'developper',
  'scaffolde', 'mets en place', 'build', 'create', 'implement', 'add',
  'generate', 'develop', 'design', 'concois', 'concevoir', 'refactore',
  'refactorise', 'migre', 'migrer', 'teste', 'tester', 'deploie', 'deployer',
]

// Édition ciblée / question → 1 agent.
const SOLO_RE = /\bcorrige\b|\bcorriger\b|\bfix\b|\brenomme\b|\brename\b|\bmodifie\b|\bmodifier\b|\bsupprime\b|\bsupprimer\b|\bexplique\b|\bexplain\b|\bpourquoi\b|\bwhy\b|\bqu'?est-?ce\b|\bwhat\b|\bcomment\b|\bbug\b|\bbugfix\b/
// C2 : une question pure ne se décompose jamais — signal solo FORT.
const QUESTION_RE = /\bexplique\b|\bexpliquer\b|\bexplain\b|\bpourquoi\b|\bwhy\b|\bqu'?est-?ce\b|\bc'?est quoi\b|\bdifference\b|\bcomment\s+(?:fonctionne|marche|faire|ca)\b|\bhow\s+(?:does|do|to)\b|\?/
const SINGLE_FIELD_RE = /\bajoute\s+(un|une)\s+champ\b|\bajoute\s+(un|une)\s+attribut\b|\badd\s+(a|an)\s+field\b|\bajoute\s+(un|une)\s+\w+\s+au?\s+(dto|model|modele|entite|entity)\b/

// ── Noms de fichiers (C4) ───────────────────────────────────────────────────
// L'intention métier ne se déduit JAMAIS d'un nom de fichier : `lock.ts`,
// `security.ts`, `perf.js` ne sont pas des tâches de verrouillage / sécurité /
// performance. On neutralise ces tokens avant tout calcul de tier ou de
// pipeline (le reste du classifieur, dont detectCodemod, voit le texte brut).
const FILE_TOKEN_RE = /\b[\w-]+\.(?:ts|tsx|js|jsx|mjs|cjs|json|py|go|rs|rb|php|java|kt|swift|sql|ya?ml|toml|md|mdx|css|scss|less|html|sh|bash|env|lock|txt|csv|xml|ini|cfg)\b/g
function stripFileNames(s) {
  return String(s || '').replace(FILE_TOKEN_RE, ' ')
}

// ── Intentions réelles (C4) ─────────────────────────────────────────────────
// Un mot nu (« review », « sécurité », « lock », « perf ») ne prouve rien : il
// faut la forme grammaticale d'une VRAIE demande de review / sécurité / perf.
const REVIEW_INTENT_RE = /\b(?:code|peer)\s*-?\s*(?:review|revue)\b|\b(?:review|revue|relecture|audit)s?\s+(?:complet|complete|approfondi|approfondie|technique|de|du|des|d'|sur|global|globale)\b|\b(?:fais|faire|fait|effectue|effectuer|lance|lancer|realise|realiser|mene|mener|do|run|perform|conduct)\s+(?:un|une|le|la|l')?\s*(?:review|revue|relecture|audit)\b|\b(?:revois|revoir|relis|relire|audite|auditer|reviewer)\b/
const SECURITY_STRONG_RE = /\bowasp\b|\bfailles?\b|\bvulnerabilit\w*|\binjection\b|\bxss\b|\bcsrf\b|\bssrf\b|\bidor\b|\bsecuris\w*|\bhardening\b|\bdurciss?\w*|\bpentest\w*/
const SECURITY_CONTEXT_RE = /\b(?:securit[ée]|security)\s+(?:de|du|des|d'|sur|dans|applicative|api|web)\b|\b(?:audit|revue|review|analyse|test|tests|controle|verification)\w*\s+(?:de\s+|du\s+)?(?:securit[ée]|security)\b|\b(?:securit[ée]|security)\s+(?:audit|review)\b/
const LOCKFILE_RE = /\bpackage[-\s]?lock\b|\byarn\s*\.?\s*lock\b|\block[-\s]?file\b|\bfichier\s+lock\b/
// Workflow migration : le mot « migration » n'est pas obligatoire — un
// expand/contract sans interruption EST une migration multi-phases.
const MIGRATION_WORKFLOW_RE = /\bmigrations?\b|\bexpand\s*\/?\s*contract\b|\bsans (?:aucune )?interruption\b|\bzero-?downtime\b|\bsans downtime\b/
const MIGRATION_APPLY_RE = /\bapplique\b|\bappliquer\b|\bapply\b|\brollback\b|\bbackfill\w*|\bbascule\b/
// Concept de verrouillage, y compris conjugué FR (« qui locke la table »).
const LOCK_CONCEPT_RE = /\block(?:s|ing|e|es|er|ee|ees|ent)?\b|\bverrou\w*|\bmutex\b/
const PERF_ABBREV_RE = /\bperfs?\b/
const PERF_CONTEXT_RE = /\boptimis\w*|\blent\w*|\bralenti\w*|\bdegradation\b|\bbottleneck\b|\bgoulot\b|\bprofil\w*|\blatence\b|\bp9[59]\b|\bcharge\b|\bscalab\w*/

// ── Tiers ───────────────────────────────────────────────────────────────────
// tier 3 : raisonnement complexe. tier 1 : trivial. tier 2 : standard.
const TIER3_ALWAYS_RE = /\barchitecture\b|\bconcurrence\b|\bconcurrent\b|\brace\b|\batomique\b|\batomic\b|\bmigrations?\b|\boptimis|\boptimize\b|\bsans downtime\b|\bzero-?downtime\b|\bsans (?:aucune )?interruption\b|\bexpand\s*\/?\s*contract\b|\bbackfill\w*|\bdouble[-\s]?ecriture\b|\bn\s*\+\s*1\b|\bidempoten|\bdeadlock\b|\bperformances?\b|\bdistribu/
const TIER1_RE = /\btypo\b|\brenomme\b|\brenommer\b|\brename\b|\bcommentaires?\b|\bcomment\b|\bdoc\b|\bdocs\b|\bdocumentation\b|\bformatte\w*|\bformater\b|\bformatage\b|\bformatting\b|\breformat\w*|\bformat\s+(?:le|la|les|ce|cette|ces|the)\b|\blint\b|\blinter\b|\bprettier\b/

// ── Familles de complexité réelle (C3) ──────────────────────────────────────
// Un prompt long n'est décomposable que s'il croise PLUSIEURS problèmes durs
// distincts. Deux familles ou plus = vraie surface multi-phases.
const COMPLEXITY_FAMILIES = [
  { key: 'concurrence',  re: /\bconcurren\w*|\brace\b|\bsimultan\w*|\bthreads?\b/ },
  { key: 'verrouillage', re: LOCK_CONCEPT_RE },
  { key: 'idempotence',  re: /\bidempoten\w*|\bexactly[-\s]?once\b|\bdeduplicat\w*|\bdedup\w*|\breplays?\b/ },
  { key: 'migration',    re: /\bmigrations?\b|\bbackfill\w*|\bexpand\s*\/?\s*contract\b|\bsans (?:aucune )?interruption\b/ },
  { key: 'performance',  re: /\bperformances?\b|\boptimis\w*|\bscalab\w*|\blatence\b|\bn\s*\+\s*1\b/ },
  { key: 'securite',     re: /\bowasp\b|\bfailles?\b|\bvulnerabilit\w*|\binjection\b|\bxss\b|\bcsrf\b|\bssrf\b|\bidor\b|\bfuite\w*|\bisolation\b|\bmulti-?tenant\b/ },
  { key: 'architecture', re: /\barchitecture\b|\bdistribu\w*|\bcheckpoint\w*|\bsaga\b|\bevent[-\s]?sourc\w*/ },
]

/**
 * isTier3 — raisonnement complexe, sur texte déjà débarrassé des noms de fichiers.
 * Chaque terme ambigu (review / sécurité / lock / perf) exige son contexte (C4).
 */
function isTier3(nf) {
  if (TIER3_ALWAYS_RE.test(nf)) return true
  if (REVIEW_INTENT_RE.test(nf)) return true
  if (SECURITY_STRONG_RE.test(nf) || SECURITY_CONTEXT_RE.test(nf)) return true
  if (LOCK_CONCEPT_RE.test(nf) && !LOCKFILE_RE.test(nf)) return true
  if (PERF_ABBREV_RE.test(nf) && PERF_CONTEXT_RE.test(nf)) return true
  return false
}

// ── Détection Tier 0 (codemod déterministe, $0) ───────────────────────────────
// Tâches PUREMENT mécaniques correspondant aux 3 intents sûrs de codemod.js.
// Conservateur : uniquement des demandes courtes et sans jugement (types /
// gestion d'erreurs / archi / async → routées vers un modèle, jamais codemod).
const CODEMOD_REMOVE_VERB = /retire|retirer|supprim|enlev|elimin|remove|strip|nettoi|clean|efface|delete/
const CODEMOD_CONV_VERB   = /remplac|convert|convertis|convertir|transform|change|passe|migrate|switch/
const CODEMOD_JUDGMENT_RE = /\btypes?\b|\btypage\b|error handling|gestion d'?erreurs?|\barchitecture\b|\basync\b|\bawait\b|refactor/

function detectCodemod(n, words) {
  if (words > 15) return null                      // tâche trop large pour être mécanique
  if (CODEMOD_JUDGMENT_RE.test(n)) return null     // besoin de jugement → modèle

  // remove-console
  if (/\bconsole\b/.test(n) && (CODEMOD_REMOVE_VERB.test(n) || /\bconsole\.logs?\b/.test(n))) {
    return 'remove-console'
  }
  // var-to-const
  if (/\bvar\b/.test(n) && /\bconst\b/.test(n) &&
      (CODEMOD_CONV_VERB.test(n) || /var\s*(->|=>|→|par|en|to|vers)\s*const|en const|par const|to const/.test(n))) {
    return 'var-to-const'
  }
  // strip-trailing-whitespace
  const wsTarget = /trailing|whitespace|espaces?\s*(en|de)\s*fin|fin de ligne|espaces?\s*(superflus|inutiles)/
  if (wsTarget.test(n) && (CODEMOD_REMOVE_VERB.test(n) || /normalis/.test(n))) {
    return 'strip-trailing-whitespace'
  }
  return null
}

// Signaux d'incident réels : seuls eux justifient un hotfix (C5).
const INCIDENT_RE = /\bhotfix\b|\burgen\w*|\bincident\b|\bpanne\b|\bdown\b|\bcass[ée]\w*|\bregression\b|\bcritique\b|\bp0\b|\bprod\s+ko\b|\brollback\b/

// ── Sélection de pipeline (best-fit par mots-clés) ───────────────────────────
// C5 : l'ordre compte. `production` NU ne capture plus tout (il masquait
// db-migrate et mobile) — il faut un signal d'incident pour router en hotfix.
function selectPipeline(input) {
  const n = stripFileNames(normalize(input))
  if (SECURITY_STRONG_RE.test(n) || SECURITY_CONTEXT_RE.test(n)) return 'security-audit'
  if (REVIEW_INTENT_RE.test(n)) return 'review'
  if (/\bsans downtime\b|\bzero-?downtime\b|\bexpand\b|\bcontract\b/.test(n)) return 'migration'
  // Migration (+ ses tests, livrable neutre) sans autre livrable → mono-domaine.
  if (/\bmigrations?\b/.test(n) &&
      !DELIVERABLES.some(d => !MIGRATION_NEUTRAL_KEYS.has(d.key) && d.re.test(n))) return 'db-migrate'
  if (/\bmobile\b|\breact native\b|\bexpo\b/.test(n)) return 'mobile'
  if (/\bhotfix\b/.test(n) || (/\bproduction\b|\bprod\b/.test(n) && INCIDENT_RE.test(n))) return 'hotfix'
  if (/\burgen\w*/.test(n)) return 'hotfix'
  // "saas" seul (contexte : "pour mon SaaS multi-tenant") ne route plus ici (C8) —
  // seulement couplé à un verbe de construction, ou "bootstrap" qui reste un signal fort.
  if (/\bbootstrap\b/.test(n) || (SAAS_MENTION_RE.test(n) && SAAS_BUILD_RE.test(n))) return 'saas-bootstrap'
  return 'feature'
}

// ── Pondération de la décision (C2) ─────────────────────────────────────────
// Un signal solo FORT doit pouvoir gagner contre un signal pipeline FAIBLE.
const PIPELINE_WEIGHTS = {
  'livrables-multiples': 2,
  'multi-couches': 2,
  'stack-double': 2,
  'workflow-review': 2,
  'workflow-migration': 2,
  'scope-long': 1,
  'verbes-multiples': 1,
}
const SOLO_WEIGHTS = {
  'question-pure': 3,
  'ajout-champ-simple': 2,
  'edition-ciblee': 1,
  'description-courte': 0,
}
function weigh(signals, table) {
  return signals.reduce((sum, s) => {
    const key = Object.keys(table).find(k => s === k || s.startsWith(`${k}(`))
    return sum + (key ? table[key] : 0)
  }, 0)
}

// ── Classifieur ───────────────────────────────────────────────────────────────
/**
 * @param {string} description
 * @param {{}} [opts]
 * @returns {{mode:'solo'|'pipeline', pipeline:string|null, tier:1|2|3, signals:string[], reason:string}}
 */
function classifyTask(description, opts = {}) {
  const raw = String(description || '')
  const n = normalize(raw)
  const words = wordCount(raw)
  const signals = []

  // ── Tier 0 : codemod déterministe ($0) — court-circuite tout le reste ─────────
  const codemodIntent = detectCodemod(n, words)
  if (codemodIntent) {
    return {
      mode: 'codemod',
      pipeline: null,
      tier: 0,
      codemod: codemodIntent,
      signals: [`codemod:${codemodIntent}`],
      reason: `Tier 0 (codemod déterministe, $0, ~1ms) : ${codemodIntent}. Exécuté par codemod.js, aucun agent.`,
    }
  }

  // Texte sans noms de fichiers : base de toute déduction d'intention (C4).
  const nf = stripFileNames(n)

  // ── Signaux PIPELINE ───────────────────────────────────────────────────────
  // 1. ≥MIN_DELIVERABLES livrables distincts reliés par un connecteur (C1).
  const matchedDeliverables = DELIVERABLES.filter(d => d.re.test(nf)).map(d => d.key)
  const uniqueDeliverables = [...new Set(matchedDeliverables)]
  const enumSeparators = (n.match(ENUM_PUNCT_RE) || []).length
  const hasConnector = CONNECTOR_RE.test(n) || enumSeparators >= 2
  if (uniqueDeliverables.length >= MIN_DELIVERABLES && hasConnector) {
    signals.push(`livrables-multiples(${uniqueDeliverables.join('+')})`)
  }

  // 2. Multi-couches / stack complète.
  if (hasMultilayerSignal(n)) signals.push('multi-couches')
  if (STACK_PAIR_RE.test(n)) signals.push('stack-double')

  // 3. Scope large : ≥3 verbes d'action distincts, ou >40 mots MAIS corrélés à
  //    une complexité réelle (C3) — la verbosité seule ne décompose rien.
  const verbsFound = [...new Set(ACTION_VERBS.filter(v => new RegExp(`\\b${v}\\b`).test(n)))]
  const enumItems = (n.match(/(?:^|[\s(])[1-9][).]\s/g) || []).length
  const families = COMPLEXITY_FAMILIES.filter(f => f.re.test(nf)).map(f => f.key)
  const longScopeIsComplex = uniqueDeliverables.length >= 2 || hasMultilayerSignal(n) ||
    verbsFound.length >= 2 || enumItems >= 2 || families.length >= 2
  if (words > 40 && longScopeIsComplex) signals.push('scope-long')
  if (verbsFound.length >= 3) signals.push(`verbes-multiples(${verbsFound.length})`)

  // 4. Workflows canoniques multi-phases mais mono-domaine : review/audit (diff→review)
  //    et migration avec application (generate→apply). Décomposés via leur pipeline dédié.
  const isReviewWorkflow = REVIEW_INTENT_RE.test(nf) && !SINGLE_FIELD_RE.test(n)
  const isMigrationApply = MIGRATION_WORKFLOW_RE.test(nf) && MIGRATION_APPLY_RE.test(nf)
  if (isReviewWorkflow) signals.push('workflow-review')
  if (isMigrationApply) signals.push('workflow-migration')

  const pipelineSignals = signals.filter(s =>
    s.startsWith('livrables-multiples') || s === 'multi-couches' ||
    s === 'stack-double' || s === 'scope-long' || s.startsWith('verbes-multiples') ||
    s === 'workflow-review' || s === 'workflow-migration')

  // ── Signaux SOLO ─────────────────────────────────────────────────────────────
  const isQuestion = QUESTION_RE.test(n)
  if (SOLO_RE.test(n) || isQuestion) signals.push('edition-ciblee')
  if (isQuestion) signals.push('question-pure')
  if (SINGLE_FIELD_RE.test(n)) signals.push('ajout-champ-simple')
  if (words > 0 && words < 15 && pipelineSignals.length === 0) signals.push('description-courte')

  const soloSignals = signals.filter(s => s in SOLO_WEIGHTS ||
    Object.keys(SOLO_WEIGHTS).some(k => s.startsWith(`${k}(`)))

  // ── Décision mode ────────────────────────────────────────────────────────────
  // C2 : poids pipeline vs poids solo (un signal solo fort bat un signal
  // pipeline faible), au lieu d'un simple `pipelineSignals.length > 0`.
  const pipelineWeight = weigh(pipelineSignals, PIPELINE_WEIGHTS)
  const soloWeight = weigh(soloSignals, SOLO_WEIGHTS)
  const mode = pipelineWeight > soloWeight ? 'pipeline' : 'solo'

  // ── Tier ─────────────────────────────────────────────────────────────────────
  let tier = 2
  let tierReason = 'standard'
  const tier3 = isTier3(nf)
  // tier 1 prioritaire seulement si trivial ET pas de signal complexe.
  if (TIER1_RE.test(nf) && !tier3) {
    tier = 1; tierReason = 'trivial'
  } else if (tier3) {
    tier = 3; tierReason = 'raisonnement complexe'
  }
  // Un pipeline full-stack reste au moins tier 2 (jamais 1).
  if (mode === 'pipeline' && tier === 1) { tier = 2; tierReason = 'standard' }

  // ── Pipeline best-fit ────────────────────────────────────────────────────────
  const pipeline = mode === 'pipeline' ? selectPipeline(n) : null

  // ── Raison lisible ───────────────────────────────────────────────────────────
  let reason
  if (mode === 'pipeline') {
    reason = `Décomposition (${pipeline}) : ${pipelineSignals.join(', ')}. Tier ${tier} (${tierReason}).`
  } else {
    const why = signals.length ? signals.join(', ') : 'tâche ciblée'
    reason = `Solo (1 agent) : ${why}. Tier ${tier} (${tierReason}).`
  }

  return { mode, pipeline, tier, codemod: null, signals, reason }
}

module.exports = { classifyTask, normalize, selectPipeline, stripFileNames }

// ── CLI ───────────────────────────────────────────────────────────────────────
if (require.main === module) {
  const desc = process.argv.slice(2).join(' ')
  if (!desc.trim()) {
    console.error('Usage : node task-classifier.js "<description de la tâche>"')
    process.exit(1)
  }
  console.log(JSON.stringify(classifyTask(desc), null, 2))
}
