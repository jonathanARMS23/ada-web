#!/usr/bin/env node
/**
 * coordinator/team-sync.js — F6 Team Sync Protocol
 *
 * Partage de trajectoires HNSW, micro-lessons et priors Thompson via un
 * dépôt git partagé. Rend les agents progressivement plus intelligents
 * à mesure que l'équipe les utilise.
 *
 * Structure du dépôt sync :
 *   trajectories/<userId>-<date>.json   — max 100 trajectoires récentes
 *   lessons/<phaseId>.json              — micro-lessons par phase
 *   priors/router-state.json            — priors Thompson (alpha/beta)
 *   manifest.json                       — métadonnées du dernier push
 *
 * Merge Thompson :
 *   alpha_merged = alpha_local + alpha_remote - 1
 *   beta_merged  = beta_local  + beta_remote  - 1
 *
 * API publique : initTeamRepo, push, pull, getStatus, resolveConflict
 */

'use strict'

const {
  existsSync, mkdirSync, readFileSync, writeFileSync, readdirSync, renameSync, appendFileSync
} = require('fs')
const { join, resolve, sep } = require('path')
const { spawnSync } = require('child_process')
const os = require('os')

// ── Chemins ────────────────────────────────────────────────────────────────────

const HOME       = os.homedir()
const CONFIG_DIR = process.env.CLAUDE_CONFIG_DIR || join(HOME, '.claude')
const COORD_DIR  = join(CONFIG_DIR, 'coordinator')
const LOGS_DIR   = join(CONFIG_DIR, 'logs')
const SYNC_LOG   = join(HOME, '.ada', 'logs', 'team-sync.log')

// ── Utilitaires ────────────────────────────────────────────────────────────────

function ensureDir(p) { if (!existsSync(p)) mkdirSync(p, { recursive: true }) }

function ts() { return new Date().toISOString() }

function log(msg) {
  try {
    ensureDir(join(HOME, '.ada', 'logs'))
    appendFileSync(SYNC_LOG, `${ts()} ${msg}\n`)
  } catch {}
}

function readJson(p, fallback = null) {
  try { return JSON.parse(readFileSync(p, 'utf8')) } catch { return fallback }
}

/** Écriture atomique via tmp + renameSync. */
function writeJsonAtomic(p, data) {
  ensureDir(join(p, '..').replace(/[^/\\]+$/, '') || '.')
  const tmp = p + '.tmp'
  writeFileSync(tmp, JSON.stringify(data, null, 2))
  renameSync(tmp, p)
}

// ── Validation URL HTTPS (même regex que ada.js cmdProfile pull) ───────────────

const HTTPS_URL_RE = /^https:\/\/[a-zA-Z0-9][a-zA-Z0-9._-]*\.[a-zA-Z]{2,}(\/.*)?$/

function validateHttpsUrl(url) {
  if (!HTTPS_URL_RE.test(url)) {
    throw new Error(`URL invalide — seules les URLs HTTPS sont acceptées (ex: https://github.com/user/team-sync)`)
  }
}

// ── Résolution userId ─────────────────────────────────────────────────────────

function resolveUserId() {
  try {
    const r = spawnSync('git', ['config', 'user.email'], { encoding: 'utf8' })
    if (r.status === 0 && r.stdout.trim()) {
      // Nettoyer l'email pour usage dans un nom de fichier (@ interdit dans les noms de fichiers)
      return r.stdout.trim().replace(/[^a-zA-Z0-9._-]/g, '-').slice(0, 50)
    }
  } catch {}
  return os.hostname().replace(/[^a-zA-Z0-9._-]/g, '-').slice(0, 50)
}

// ── Chargement config ~/.ada.json ─────────────────────────────────────────────

function loadAdaConfig() {
  const cfgPath = join(HOME, '.ada.json')
  return readJson(cfgPath, {})
}

function saveAdaConfig(cfg) {
  const cfgPath = join(HOME, '.ada.json')
  writeJsonAtomic(cfgPath, cfg)
}

function getSyncConfig() {
  const cfg = loadAdaConfig()
  return cfg.teamSync || {}
}

function getSyncDir(syncCfg) {
  return syncCfg.syncDir
    ? syncCfg.syncDir.replace(/^~/, HOME)
    : join(HOME, '.ada', 'team-sync')
}

// ── Opérations git (toutes via spawnSync, jamais async exec) ─────────────────

function git(args, cwd) {
  const r = spawnSync('git', args, { cwd, encoding: 'utf8', env: { ...process.env, GIT_TERMINAL_PROMPT: '0' } })
  return { status: r.status ?? 1, stdout: (r.stdout || '').trim(), stderr: (r.stderr || '').trim() }
}

// ── initTeamRepo ──────────────────────────────────────────────────────────────

/**
 * Initialise le dépôt git de synchronisation.
 * @param {string} remoteUrl  URL HTTPS du dépôt partagé
 * @param {{ syncDir?: string, autoSync?: boolean }} [opts]
 */
function initTeamRepo(remoteUrl, opts = {}) {
  validateHttpsUrl(remoteUrl)

  const adaCfg  = loadAdaConfig()
  const existing = adaCfg.teamSync || {}

  const syncDir = opts.syncDir
    ? opts.syncDir.replace(/^~/, HOME)
    : (existing.syncDir ? existing.syncDir.replace(/^~/, HOME) : join(HOME, '.ada', 'team-sync'))

  // Validation périmètre — path escape check
  const resolvedSync = resolve(syncDir)
  if (!resolvedSync.startsWith(HOME + sep)) {
    throw new Error(`syncDir hors périmètre HOME : ${syncDir}`)
  }

  ensureDir(syncDir)

  const gitDir = join(syncDir, '.git')
  if (!existsSync(gitDir)) {
    // Clone depuis le remote
    const cloneResult = git(['clone', remoteUrl, '.'], syncDir)
    if (cloneResult.status !== 0) {
      // Dépôt vide : init + remote
      const initResult = git(['init'], syncDir)
      if (initResult.status !== 0) throw new Error(`git init échoué : ${initResult.stderr}`)
      git(['remote', 'add', 'origin', remoteUrl], syncDir)
    }
  } else {
    // Mettre à jour l'URL remote
    const urlResult = git(['remote', 'get-url', 'origin'], syncDir)
    if (urlResult.status !== 0) {
      git(['remote', 'add', 'origin', remoteUrl], syncDir)
    } else if (urlResult.stdout !== remoteUrl) {
      git(['remote', 'set-url', 'origin', remoteUrl], syncDir)
    }
  }

  // Créer les sous-dossiers du dépôt sync
  for (const d of ['trajectories', 'lessons', 'priors']) {
    ensureDir(join(syncDir, d))
  }

  // Sauvegarder la config teamSync dans ~/.ada.json
  adaCfg.teamSync = {
    ...existing,
    remoteUrl,
    syncDir: syncDir.replace(HOME, '~'),
    autoSync: opts.autoSync !== undefined ? opts.autoSync : (existing.autoSync ?? false),
    initializedAt: ts(),
  }
  saveAdaConfig(adaCfg)

  log(`[init] repo initialisé → ${remoteUrl}`)
  return { syncDir, remoteUrl }
}

// ── push ──────────────────────────────────────────────────────────────────────

/**
 * Exporte les trajectoires, lessons et priors vers le dépôt partagé.
 * @returns {{ pushed: boolean, trajectories: number, lessons: number }}
 */
function push() {
  const syncCfg = getSyncConfig()
  if (!syncCfg.remoteUrl) throw new Error('Team sync non initialisé — lancez : ada sync init <url>')

  const syncDir = getSyncDir(syncCfg)
  if (!existsSync(syncDir)) throw new Error(`syncDir introuvable : ${syncDir}`)

  const userId  = resolveUserId()
  const dateStr = new Date().toISOString().slice(0, 10)

  // ── 1. Trajectoires ─────────────────────────────────────────────────────────
  let trajCount = 0
  try {
    const bankFile = join(COORD_DIR, 'bank.js')
    if (existsSync(bankFile)) {
      const bank = require(bankFile)
      const trajs = bank.getRecent(100) // max 100 trajectoires récentes
      if (Array.isArray(trajs) && trajs.length > 0) {
        const destPath = join(syncDir, 'trajectories', `${userId}-${dateStr}.json`)
        writeJsonAtomic(destPath, { userId, exportedAt: ts(), trajectories: trajs })
        trajCount = trajs.length
      }
    }
  } catch (err) {
    log(`[push] trajectoires error: ${err.message}`)
  }

  // ── 2. Lessons (micro-lessons depuis coordinator/lessons.json) ───────────────
  let lessonCount = 0
  try {
    const lessonsFile = join(COORD_DIR, 'lessons.json')
    if (existsSync(lessonsFile)) {
      const lessons = readJson(lessonsFile, [])
      if (Array.isArray(lessons) && lessons.length > 0) {
        // Grouper par phaseId
        const byPhase = {}
        for (const l of lessons) {
          if (!l?.phase || !l?.lesson) continue
          if (!byPhase[l.phase]) byPhase[l.phase] = []
          byPhase[l.phase].push(l)
        }
        for (const [phaseId, phaseLessons] of Object.entries(byPhase)) {
          const dest = join(syncDir, 'lessons', `${phaseId}.json`)
          writeJsonAtomic(dest, { phaseId, updatedAt: ts(), userId, lessons: phaseLessons })
          lessonCount += phaseLessons.length
        }
      }
    }
  } catch (err) {
    log(`[push] lessons error: ${err.message}`)
  }

  // ── 3. Priors Thompson (router-state.json) ────────────────────────────────────
  try {
    const routerStateFile = join(COORD_DIR, 'router-state.json')
    if (existsSync(routerStateFile)) {
      const routerState = readJson(routerStateFile, null)
      if (routerState) {
        const dest = join(syncDir, 'priors', 'router-state.json')
        writeJsonAtomic(dest, { ...routerState, _pushedBy: userId, _pushedAt: ts() })
      }
    }
  } catch (err) {
    log(`[push] priors error: ${err.message}`)
  }

  // ── 4. manifest.json ──────────────────────────────────────────────────────────
  try {
    const manifest = {
      lastPush: ts(),
      userId,
      trajectories: trajCount,
      lessons: lessonCount,
      version: '1.0.0',
    }
    writeJsonAtomic(join(syncDir, 'manifest.json'), manifest)
  } catch {}

  // ── 5. git add / commit / push ───────────────────────────────────────────────
  try {
    git(['add', '-A'], syncDir)

    // Vérifier s'il y a quelque chose à committer
    const statusResult = git(['status', '--porcelain'], syncDir)
    if (!statusResult.stdout.trim()) {
      log(`[push] rien à committer`)
      return { pushed: false, trajectories: trajCount, lessons: lessonCount }
    }

    const commitMsg = `sync: ${userId} ${ts()}`
    const commitResult = git(['commit', '-m', commitMsg], syncDir)
    if (commitResult.status !== 0) {
      log(`[push] commit échoué : ${commitResult.stderr}`)
      return { pushed: false, trajectories: trajCount, lessons: lessonCount }
    }

    // Récupérer la branche courante
    const branchResult = git(['rev-parse', '--abbrev-ref', 'HEAD'], syncDir)
    const branch = branchResult.status === 0 ? (branchResult.stdout || 'main') : 'main'

    const pushResult = git(['push', '-u', 'origin', branch], syncDir)
    if (pushResult.status !== 0) {
      log(`[push] push échoué : ${pushResult.stderr}`)
      return { pushed: false, trajectories: trajCount, lessons: lessonCount }
    }

    log(`[push] ok — ${trajCount} trajectoires, ${lessonCount} lessons → ${syncCfg.remoteUrl}`)
    return { pushed: true, trajectories: trajCount, lessons: lessonCount }
  } catch (err) {
    log(`[push] git error: ${err.message}`)
    return { pushed: false, trajectories: trajCount, lessons: lessonCount }
  }
}

// ── pull ──────────────────────────────────────────────────────────────────────

/**
 * Importe les trajectoires, lessons et priors depuis le dépôt partagé.
 * @returns {{ pulled: boolean, trajectories: number, lessons: number }}
 */
function pull() {
  const syncCfg = getSyncConfig()
  if (!syncCfg.remoteUrl) throw new Error('Team sync non initialisé — lancez : ada sync init <url>')

  const syncDir = getSyncDir(syncCfg)
  if (!existsSync(syncDir)) throw new Error(`syncDir introuvable — lancez : ada sync init <url>`)

  // ── 1. git fetch + merge ────────────────────────────────────────────────────
  try {
    const fetchResult = git(['fetch', 'origin'], syncDir)
    if (fetchResult.status !== 0) {
      log(`[pull] fetch échoué : ${fetchResult.stderr}`)
      return { pulled: false, trajectories: 0, lessons: 0 }
    }

    // Récupérer la branche courante
    const branchResult = git(['rev-parse', '--abbrev-ref', 'HEAD'], syncDir)
    const branch = branchResult.status === 0 ? (branchResult.stdout || 'main') : 'main'

    const mergeResult = git(['merge', `origin/${branch}`, '--no-edit'], syncDir)
    if (mergeResult.status !== 0) {
      log(`[pull] merge échoué : ${mergeResult.stderr}`)
      return { pulled: false, trajectories: 0, lessons: 0 }
    }
  } catch (err) {
    log(`[pull] git error: ${err.message}`)
    return { pulled: false, trajectories: 0, lessons: 0 }
  }

  const userId = resolveUserId()
  let trajImported = 0
  let lessonsImported = 0

  // ── 2. Import trajectoires via bank.store() ────────────────────────────────
  try {
    const bankFile = join(COORD_DIR, 'bank.js')
    const trajDir  = join(syncDir, 'trajectories')
    if (existsSync(bankFile) && existsSync(trajDir)) {
      const bank  = require(bankFile)
      const files = readdirSync(trajDir).filter(f => f.endsWith('.json'))
      for (const file of files) {
        // Ne pas réimporter ses propres trajectoires
        if (file.startsWith(userId + '-')) continue
        try {
          const data = readJson(join(trajDir, file), null)
          if (!data?.trajectories || !Array.isArray(data.trajectories)) continue
          for (const t of data.trajectories) {
            if (!t?.phase || !t?.agent) continue
            try {
              bank.store(t.phase, t.agent, t.verdict || 'success', t.summary || '', {
                tokens: t.tokens,
                durationMs: t.durationMs,
              })
              trajImported++
            } catch {}
          }
        } catch {}
      }
    }
  } catch (err) {
    log(`[pull] trajectoires import error: ${err.message}`)
  }

  // ── 3. Merge priors Thompson ──────────────────────────────────────────────
  try {
    const localRouterFile  = join(COORD_DIR, 'router-state.json')
    const remoteRouterFile = join(syncDir, 'priors', 'router-state.json')
    if (existsSync(remoteRouterFile)) {
      const remote = readJson(remoteRouterFile, null)
      if (remote?.priors) {
        const routerMod = require(join(COORD_DIR, 'router.js'))
        const local = routerMod.loadState()

        for (const [key, remotePrior] of Object.entries(remote.priors)) {
          const localPrior = local.priors[key] || { alpha: 1, beta: 1, successes: 0, failures: 0 }
          // Formule de merge Thompson : alpha_merged = alpha_local + alpha_remote - 1
          local.priors[key] = {
            ...localPrior,
            alpha: Math.max(1, localPrior.alpha + remotePrior.alpha - 1),
            beta:  Math.max(1, localPrior.beta  + remotePrior.beta  - 1),
            // Conserver les stats locales (successes/failures ne se mergent pas simplement)
            successes: localPrior.successes || 0,
            failures:  localPrior.failures  || 0,
          }
        }
        local.totalUpdates = (local.totalUpdates || 0) + Object.keys(remote.priors).length
        routerMod.saveState(local)
        log(`[pull] priors mergés : ${Object.keys(remote.priors).length} entrées`)
      }
    }
  } catch (err) {
    log(`[pull] priors merge error: ${err.message}`)
  }

  // ── 4. Merge lessons ──────────────────────────────────────────────────────
  try {
    const lessonsDir = join(syncDir, 'lessons')
    const localLessonsFile = join(COORD_DIR, 'lessons.json')
    if (existsSync(lessonsDir)) {
      let localLessons = existsSync(localLessonsFile)
        ? (readJson(localLessonsFile, []) || [])
        : []
      if (!Array.isArray(localLessons)) localLessons = []

      const seen = new Set(localLessons.map(l => `${l.phase}:${l.lesson}`))
      const files = readdirSync(lessonsDir).filter(f => f.endsWith('.json'))

      for (const file of files) {
        try {
          const data = readJson(join(lessonsDir, file), null)
          if (!data?.lessons || !Array.isArray(data.lessons)) continue
          for (const l of data.lessons) {
            if (!l?.phase || !l?.lesson) continue
            const key = `${l.phase}:${l.lesson}`
            if (!seen.has(key)) {
              seen.add(key)
              localLessons.push(l)
              lessonsImported++
            }
          }
        } catch {}
      }

      // Garder les 500 lessons les plus récentes
      const trimmed = localLessons.slice(-500)
      writeJsonAtomic(localLessonsFile, trimmed)
    }
  } catch (err) {
    log(`[pull] lessons merge error: ${err.message}`)
  }

  log(`[pull] ok — ${trajImported} trajectoires, ${lessonsImported} lessons importés`)
  return { pulled: true, trajectories: trajImported, lessons: lessonsImported }
}

// ── getStatus ─────────────────────────────────────────────────────────────────

/**
 * Retourne l'état de la synchronisation.
 * @returns {{ initialized: boolean, remoteUrl?: string, lastPush?: string, ahead: number, behind: number }}
 */
function getStatus() {
  const syncCfg = getSyncConfig()
  if (!syncCfg.remoteUrl) {
    return { initialized: false }
  }

  const syncDir = getSyncDir(syncCfg)
  if (!existsSync(syncDir) || !existsSync(join(syncDir, '.git'))) {
    return { initialized: false, remoteUrl: syncCfg.remoteUrl }
  }

  // Lire manifest.json
  const manifest = readJson(join(syncDir, 'manifest.json'), {})

  // Compter commits ahead/behind (git rev-list)
  let ahead = 0, behind = 0
  try {
    const branchResult = git(['rev-parse', '--abbrev-ref', 'HEAD'], syncDir)
    const branch = branchResult.status === 0 ? (branchResult.stdout || 'main') : 'main'

    // Timeout 5s pour ne pas bloquer session-end
    spawnSync('git', ['fetch', 'origin', '--quiet'], {
      cwd: syncDir, encoding: 'utf8', timeout: 5000,
      env: { ...process.env, GIT_TERMINAL_PROMPT: '0' },
    })

    const aheadResult = git(['rev-list', '--count', `origin/${branch}..HEAD`], syncDir)
    if (aheadResult.status === 0) ahead = parseInt(aheadResult.stdout, 10) || 0

    const behindResult = git(['rev-list', '--count', `HEAD..origin/${branch}`], syncDir)
    if (behindResult.status === 0) behind = parseInt(behindResult.stdout, 10) || 0
  } catch {}

  return {
    initialized: true,
    remoteUrl:   syncCfg.remoteUrl,
    syncDir,
    autoSync:    syncCfg.autoSync || false,
    lastPush:    manifest.lastPush || null,
    userId:      manifest.userId   || null,
    ahead,
    behind,
  }
}

// ── resolveConflict ───────────────────────────────────────────────────────────

/**
 * Résout les conflits git dans le dépôt sync en favorisant les données locales.
 * @returns {{ resolved: boolean, message: string }}
 */
function resolveConflict() {
  const syncCfg = getSyncConfig()
  if (!syncCfg.remoteUrl) throw new Error('Team sync non initialisé')

  const syncDir = getSyncDir(syncCfg)
  if (!existsSync(syncDir)) throw new Error(`syncDir introuvable : ${syncDir}`)

  try {
    // Stratégie : ours (favoriser les données locales)
    const abortResult = git(['merge', '--abort'], syncDir)
    if (abortResult.status !== 0) {
      // Pas de merge en cours — essayer reset
      const resetResult = git(['reset', '--hard', 'HEAD'], syncDir)
      if (resetResult.status !== 0) {
        return { resolved: false, message: `reset échoué : ${resetResult.stderr}` }
      }
    }
    log(`[resolveConflict] conflit résolu via merge --abort`)
    return { resolved: true, message: 'Conflit résolu — données locales conservées' }
  } catch (err) {
    log(`[resolveConflict] error: ${err.message}`)
    return { resolved: false, message: err.message }
  }
}

// ── Exports (API publique) ─────────────────────────────────────────────────────

module.exports = { initTeamRepo, push, pull, getStatus, resolveConflict, loadAdaConfig, getSyncConfig, resolveUserId }

// ── CLI ───────────────────────────────────────────────────────────────────────

if (require.main === module) {
  const [,, cmd, ...args] = process.argv

  switch (cmd) {
    case 'init': {
      const [url, ...opts] = args
      if (!url) { console.error('Usage: team-sync.js init <remoteUrl>'); process.exit(1) }
      try {
        const autoSync = opts.includes('--auto')
        const result   = initTeamRepo(url, { autoSync })
        console.log(`Dépôt sync initialisé → ${result.syncDir}`)
      } catch (err) { console.error(err.message); process.exit(1) }
      break
    }
    case 'push': {
      try {
        const result = push()
        console.log(`Push : ${result.pushed ? 'ok' : 'rien'} — ${result.trajectories} trajectoires, ${result.lessons} lessons`)
      } catch (err) { console.error(err.message); process.exit(1) }
      break
    }
    case 'pull': {
      try {
        const result = pull()
        console.log(`Pull : ${result.pulled ? 'ok' : 'rien'} — ${result.trajectories} trajectoires, ${result.lessons} lessons importés`)
      } catch (err) { console.error(err.message); process.exit(1) }
      break
    }
    case 'status': {
      try {
        const s = getStatus()
        if (!s.initialized) { console.log('Team sync non initialisé'); break }
        console.log(`\nTeam Sync Status`)
        console.log(`  Remote   : ${s.remoteUrl}`)
        console.log(`  syncDir  : ${s.syncDir}`)
        console.log(`  autoSync : ${s.autoSync}`)
        console.log(`  lastPush : ${s.lastPush || 'jamais'}`)
        console.log(`  ahead    : ${s.ahead} commits`)
        console.log(`  behind   : ${s.behind} commits`)
      } catch (err) { console.error(err.message); process.exit(1) }
      break
    }
    case 'resolve-conflict': {
      try {
        const result = resolveConflict()
        console.log(result.message)
        if (!result.resolved) process.exit(1)
      } catch (err) { console.error(err.message); process.exit(1) }
      break
    }
    default:
      console.log('\nADA Team Sync — F6 Protocol\n')
      console.log('  init <url>         Initialiser le dépôt sync')
      console.log('  push               Exporter vers le dépôt partagé')
      console.log('  pull               Importer depuis le dépôt partagé')
      console.log('  status             État de la synchronisation')
      console.log('  resolve-conflict   Résoudre un conflit git')
  }
}
