#!/usr/bin/env bash
# coordinator/tests/run-tests.sh
# Lance la test suite avec node:test natif
# Usage : ./tests/run-tests.sh [--reporter <tap|spec|dot>]

set -euo pipefail

cd "$(dirname "$0")/.."

REPORTER="${2:-spec}"

echo "→ Running coordinator test suite (node:test natif)..."
echo ""

node --test \
  --experimental-vm-modules \
  --test-reporter="${REPORTER}" \
  tests/coordinator.test.js 2>&1

EXIT_CODE=$?

if [ $EXIT_CODE -eq 0 ]; then
  echo ""
  echo "✓ Tous les tests passent"
else
  echo ""
  echo "✗ Des tests échouent (exit code: $EXIT_CODE)"
fi

exit $EXIT_CODE
