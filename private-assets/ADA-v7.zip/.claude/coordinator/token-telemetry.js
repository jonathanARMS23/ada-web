#!/usr/bin/env node
'use strict'
/**
 * coordinator/token-telemetry.js — Télémétrie tokens RÉELLE (mesurée, pas modélisée)
 *
 * Source de vérité : le transcript JSONL de Claude Code (champ `usage` par tour
 * assistant), qui contient input_tokens / cache_creation_input_tokens /
 * cache_read_input_tokens / output_tokens. C'est la seule donnée d'usage réel
 * disponible (l'orchestration passe par le tool Agent, pas par provider-gateway).
 *
 * Persiste par session (overwrite — le transcript est cumulatif) + agrégat global.
 *
 * API :
 *   readTranscript(path)            → usage agrégé + savings d'une session
 *   record(path, sessionId)         → persiste dans token-telemetry.json
 *   report()                        → agrégat + dernière session
 *
 * CLI :
 *   node token-telemetry.js record <transcript.jsonl> [sessionId]
 *   node token-telemetry.js report
 */

const { readFileSync, writeFileSync, existsSync, mkdirSync, renameSync, openSync, readSync, closeSync, statSync, readdirSync } = require('fs')
const { join, dirname, basename } = require('path')
const os = require('os')

const CONFIG_DIR   = process.env.CLAUDE_CONFIG_DIR || join(process.env.HOME ?? os.homedir(), '.claude')
const METRICS_FILE = join(CONFIG_DIR, 'logs', 'token-telemetry.json')

// Tarifs Anthropic par 1M tokens (défaut Sonnet 4.6 — le % d'économie input est
// indépendant du tier car cache_read = 0.1 × input pour tout modèle ; seul le $ varie).
const PRICE = {
  input:      Number(process.env.ADA_PRICE_INPUT)  || 3.00,
  cacheRead:  Number(process.env.ADA_PRICE_CR)     || 0.30,   // 90% de remise
  cacheWrite: Number(process.env.ADA_PRICE_CW)     || 3.75,   // 1.25× input
  output:     Number(process.env.ADA_PRICE_OUTPUT) || 15.00,
}

/** Extrait l'objet `usage` d'une ligne JSONL parsée (message.usage ou usage). @returns {object|null} */
function usageOf(j) {
  return (j && j.message && j.message.usage) || (j && j.usage) || null
}

/** Accumule les compteurs bruts d'un `usage` dans un agrégat mutable. */
function addUsage(acc, u) {
  acc.turns++
  acc.input += u.input_tokens || 0
  acc.cc    += u.cache_creation_input_tokens || 0
  acc.cr    += u.cache_read_input_tokens || 0
  acc.out   += u.output_tokens || 0
}

/** Agrège les compteurs bruts d'un buffer de lignes JSONL. @returns {{input,cc,cr,out,turns}} */
function sumUsageLines(text) {
  const acc = { input: 0, cc: 0, cr: 0, out: 0, turns: 0 }
  for (const line of text.split('\n')) {
    if (!line.trim()) continue
    let j
    try { j = JSON.parse(line) } catch { continue }
    const u = usageOf(j)
    if (!u) continue
    addUsage(acc, u)
  }
  return acc
}

/**
 * Agrège l'usage de TOUS les `*.jsonl` d'un dossier de transcripts, en ne comptant
 * QUE les lignes dont le `timestamp` tombe dans [fromISO, toISO] (bornes inclusives).
 *
 * Conçu pour la mesure de coût d'un bras de benchmark : quand un bras délègue à un
 * sous-agent, les tokens partent dans un AUTRE transcript (ou des lignes sidechain).
 * Un delta mono-fichier les rate ; la fenêtre temporelle les capte tous.
 *
 * @param {string} transcriptDir   dossier scanné NON-récursivement (les *.jsonl du projet)
 * @param {string} fromISO         borne basse ISO 8601
 * @param {string} toISO           borne haute ISO 8601
 * @returns {object|null}          computeUsage(raw) (même forme que readTranscript), ou null si aucun token dans la fenêtre
 */
function sumUsageWindow(transcriptDir, fromISO, toISO) {
  if (!transcriptDir || !existsSync(transcriptDir)) return null
  const from = Date.parse(fromISO), to = Date.parse(toISO)
  if (Number.isNaN(from) || Number.isNaN(to)) return null

  const acc = { input: 0, cc: 0, cr: 0, out: 0, turns: 0 }
  let files
  try { files = readdirSync(transcriptDir) } catch { return null }
  for (const f of files) {
    if (!f.endsWith('.jsonl')) continue
    let text
    try { text = readFileSync(join(transcriptDir, f), 'utf8') } catch { continue }
    for (const line of text.split('\n')) {
      if (!line.trim()) continue
      let j
      try { j = JSON.parse(line) } catch { continue }   // ligne JSON invalide → ignorée
      const u = usageOf(j)
      if (!u || !j.timestamp) continue                  // pas de usage ou pas de timestamp → ignorée
      const t = Date.parse(j.timestamp)
      if (Number.isNaN(t) || t < from || t > to) continue
      addUsage(acc, u)
    }
  }
  return computeUsage(acc)   // null si aucun token accumulé (totalInput === 0 && out === 0)
}

/** Calcule l'usage dérivé (coûts, hit rate) depuis des compteurs bruts. */
function computeUsage(raw) {
  const { input, cc, cr, out, turns } = raw
  const totalInput = input + cc + cr
  if (totalInput === 0 && out === 0) return null
  const PIN = PRICE.input / 1e6, PCR = PRICE.cacheRead / 1e6
  const PCW = PRICE.cacheWrite / 1e6, POUT = PRICE.output / 1e6
  const realCostUsd    = input * PIN + cc * PCW + cr * PCR + out * POUT
  const noCacheCostUsd = totalInput * PIN + out * POUT
  const savedUsd       = noCacheCostUsd - realCostUsd
  return {
    turns,
    input, cacheCreation: cc, cacheRead: cr, output: out, totalInput,
    cacheHitRate: totalInput ? cr / totalInput : 0,
    realCostUsd, noCacheCostUsd, savedUsd,
    inputCostSavingsPct: noCacheCostUsd > 0 ? savedUsd / noCacheCostUsd : 0,
  }
}

/**
 * Parse INTÉGRAL d'un transcript JSONL (utilisé par le CLI/benchmark, hors hot path).
 * @param {string} transcriptPath
 * @returns {object|null}
 */
function readTranscript(transcriptPath) {
  if (!transcriptPath || !existsSync(transcriptPath)) return null
  let text
  try { text = readFileSync(transcriptPath, 'utf8') } catch { return null }
  return computeUsage(sumUsageLines(text))
}

/**
 * Lecture INCRÉMENTALE depuis un offset (hot path stop-hook).
 * Le transcript est append-only JSONL → on ne lit que les nouveaux octets et on
 * ne consomme que les lignes COMPLÈTES (jusqu'au dernier '\n').
 * @returns {{ input,cc,cr,out,turns, newOffset }|{ reset:true }|null}
 */
function readTranscriptDelta(transcriptPath, fromOffset) {
  let st
  try { st = statSync(transcriptPath) } catch { return null }
  if (st.size < fromOffset) return { reset: true }                 // rotation / nouveau fichier
  if (st.size === fromOffset) return { input:0,cc:0,cr:0,out:0,turns:0, newOffset: fromOffset }
  const fd = openSync(transcriptPath, 'r')
  try {
    const len = st.size - fromOffset
    const buf = Buffer.allocUnsafe(len)
    readSync(fd, buf, 0, len, fromOffset)
    const text = buf.toString('utf8')
    const lastNl = text.lastIndexOf('\n')
    if (lastNl < 0) return { input:0,cc:0,cr:0,out:0,turns:0, newOffset: fromOffset } // pas de ligne complète
    const complete     = text.slice(0, lastNl)
    const consumedBytes = Buffer.byteLength(text.slice(0, lastNl + 1), 'utf8')
    const d = sumUsageLines(complete)
    return { ...d, newOffset: fromOffset + consumedBytes }
  } finally { closeSync(fd) }
}

/**
 * Lit les lignes JSONL COMPLÈTES depuis un offset d'octets, sans les agréger
 * (contrairement à `readTranscriptDelta`) — nécessaire à `sumUsageIncremental`
 * pour pouvoir filtrer chaque ligne par timestamp avant agrégation.
 * @returns {{ lines:string[], newOffset:number }|{ reset:true }|null}
 */
function readCompleteLinesDelta(transcriptPath, fromOffset) {
  let st
  try { st = statSync(transcriptPath) } catch { return null }
  if (st.size < fromOffset) return { reset: true }                 // rotation / nouveau fichier
  if (st.size === fromOffset) return { lines: [], newOffset: fromOffset }
  const fd = openSync(transcriptPath, 'r')
  try {
    const len = st.size - fromOffset
    const buf = Buffer.allocUnsafe(len)
    readSync(fd, buf, 0, len, fromOffset)
    const text = buf.toString('utf8')
    const lastNl = text.lastIndexOf('\n')
    if (lastNl < 0) return { lines: [], newOffset: fromOffset }    // pas de ligne complète
    const complete      = text.slice(0, lastNl)
    const consumedBytes = Buffer.byteLength(text.slice(0, lastNl + 1), 'utf8')
    return { lines: complete.split('\n'), newOffset: fromOffset + consumedBytes }
  } finally { closeSync(fd) }
}

/** Agrège un lot de lignes JSONL brutes dans `acc`, en excluant celles antérieures à `since` (epoch ms, ou NaN = pas de plancher). */
function addUsageLinesSince(acc, lines, since) {
  for (const line of lines) {
    if (!line.trim()) continue
    let j
    try { j = JSON.parse(line) } catch { continue }
    const u = usageOf(j)
    if (!u) continue
    if (!Number.isNaN(since)) {
      if (!j.timestamp) continue                    // pas de timestamp → non attribuable de façon fiable, ignorée
      const t = Date.parse(j.timestamp)
      if (Number.isNaN(t) || t < since) continue     // antérieur au plancher → backlog hors scope de CETTE phase
    }
    addUsage(acc, u)
  }
}

/**
 * Variante incrémentale de sumUsageWindow : au lieu de re-scanner l'intégralité
 * de chaque fichier .jsonl à chaque appel, ne lit que les octets nouveaux depuis
 * le dernier offset connu par fichier (persisté par l'appelant dans `offsets`).
 * Mute `offsets` en place (ajoute/avance les entrées par nom de fichier).
 *
 * `sinceISO`, si fourni, exclut les lignes dont le timestamp est antérieur à cette
 * borne. Nécessaire car un fichier jamais vu par CE run démarre avec un offset à 0
 * (aucun historique connu) — sans plancher temporel, la toute première lecture d'un
 * fichier partagé (ex. transcript de session réutilisé par un run ADA précédent)
 * attribuerait TOUT son historique antérieur à la phase courante. Le plancher ne
 * coûte rien en I/O supplémentaire (les octets sont lus une seule fois quel que
 * soit le résultat du filtre — seul l'agrégat en est affecté) et l'offset avance
 * quand même sur les octets filtrés, donc ils ne sont jamais relus.
 *
 * @param {string} transcriptDir
 * @param {Record<string, number>} offsets  — { [filename]: byteOffset }, muté en place
 * @param {string} [sinceISO]  borne basse optionnelle (ISO 8601) — typiquement phase.startedAt
 * @returns {object|null}  computeUsage(raw), ou null si aucun token nouveau
 */
function sumUsageIncremental(transcriptDir, offsets, sinceISO) {
  if (!transcriptDir || !existsSync(transcriptDir)) return null
  const since = sinceISO ? Date.parse(sinceISO) : NaN
  const acc = { input: 0, cc: 0, cr: 0, out: 0, turns: 0 }
  let files
  try { files = readdirSync(transcriptDir) } catch { return null }
  for (const f of files) {
    if (!f.endsWith('.jsonl')) continue
    const fromOffset = offsets[f] || 0
    const filePath = join(transcriptDir, f)
    const delta = readCompleteLinesDelta(filePath, fromOffset)
    if (!delta) continue
    if (delta.reset) {
      const full = readCompleteLinesDelta(filePath, 0)
      if (!full || full.reset) continue
      addUsageLinesSince(acc, full.lines, since)
      offsets[f] = full.newOffset
      continue
    }
    addUsageLinesSince(acc, delta.lines, since)
    offsets[f] = delta.newOffset
  }
  return computeUsage(acc)
}

/**
 * Localise, sous `configDir/projects/<sous-dossier>`, le dossier de transcripts
 * dont un `*.jsonl` a été modifié le plus récemment. `dir` contient TOUS les
 * transcripts du projet (session principale + sous-agents/sidechains) — c'est
 * ce dossier que `sumUsageWindow` doit scanner pour capter la délégation.
 * Centralise la logique (utilisée par benchmark.js et par le fallback télémétrie
 * de run.js) — best-effort, ne lève jamais.
 * @param {string} [configDir]
 * @returns {string|null}
 */
function locateLatestTranscriptDir(configDir = CONFIG_DIR) {
  try {
    const projDir = join(configDir, 'projects')
    if (!existsSync(projDir)) return null
    let latestDir = null, latestM = 0
    for (const d of readdirSync(projDir)) {
      const sub = join(projDir, d)
      try {
        for (const f of readdirSync(sub)) {
          if (!f.endsWith('.jsonl')) continue
          const m = statSync(join(sub, f)).mtimeMs
          if (m > latestM) { latestM = m; latestDir = sub }
        }
      } catch {}
    }
    return latestDir
  } catch { return null }
}

/** Charge le store de métriques (sessions + agrégat). */
function loadStore() {
  if (!existsSync(METRICS_FILE)) return { sessions: {}, updatedAt: null }
  try { return JSON.parse(readFileSync(METRICS_FILE, 'utf8')) } catch { return { sessions: {}, updatedAt: null } }
}

function saveStore(store) {
  try {
    mkdirSync(dirname(METRICS_FILE), { recursive: true })
    const tmp = METRICS_FILE + '.tmp'
    writeFileSync(tmp, JSON.stringify(store, null, 2))
    renameSync(tmp, METRICS_FILE)
  } catch { /* best-effort */ }
}

/** Recalcule l'agrégat global depuis les sessions. */
function aggregate(sessions) {
  const a = { turns: 0, input: 0, cacheCreation: 0, cacheRead: 0, output: 0, realCostUsd: 0, noCacheCostUsd: 0, savedUsd: 0, sessions: 0 }
  for (const s of Object.values(sessions)) {
    a.sessions++
    a.turns += s.turns || 0; a.input += s.input || 0; a.cacheCreation += s.cacheCreation || 0
    a.cacheRead += s.cacheRead || 0; a.output += s.output || 0
    a.realCostUsd += s.realCostUsd || 0; a.noCacheCostUsd += s.noCacheCostUsd || 0; a.savedUsd += s.savedUsd || 0
  }
  const totIn = a.input + a.cacheCreation + a.cacheRead
  a.cacheHitRate = totIn ? a.cacheRead / totIn : 0
  a.inputCostSavingsPct = a.noCacheCostUsd > 0 ? a.savedUsd / a.noCacheCostUsd : 0
  return a
}

/**
 * Enregistre l'usage d'un transcript (overwrite par session — le transcript est cumulatif).
 * @param {string} transcriptPath
 * @param {string} [sessionId]
 * @returns {object|null} usage de la session
 */
function record(transcriptPath, sessionId) {
  if (!transcriptPath || !existsSync(transcriptPath)) return null
  const id = sessionId || basename(transcriptPath, '.jsonl')
  const store = loadStore()
  if (!store.sessions) store.sessions = {}

  const prev = store.sessions[id]
  let raw    = prev && prev._raw ? { ...prev._raw } : { input: 0, cc: 0, cr: 0, out: 0, turns: 0 }
  let offset = prev && typeof prev._offset === 'number' ? prev._offset : 0

  let delta = readTranscriptDelta(transcriptPath, offset)
  if (!delta) return null
  if (delta.reset) {                       // rotation → full reparse depuis 0
    raw = { input: 0, cc: 0, cr: 0, out: 0, turns: 0 }
    delta = readTranscriptDelta(transcriptPath, 0)
    if (!delta || delta.reset) return null
  }
  raw.input += delta.input; raw.cc += delta.cc; raw.cr += delta.cr; raw.out += delta.out; raw.turns += delta.turns
  offset = delta.newOffset

  const usage = computeUsage(raw)
  if (!usage) return null
  store.sessions[id] = { ...usage, _raw: raw, _offset: offset, updatedAt: new Date().toISOString() }
  store.aggregate = aggregate(store.sessions)
  store.updatedAt = new Date().toISOString()
  saveStore(store)
  return usage
}

function report() {
  const store = loadStore()
  return { aggregate: store.aggregate || aggregate(store.sessions || {}), sessions: store.sessions || {}, updatedAt: store.updatedAt }
}

module.exports = { readTranscript, sumUsageWindow, sumUsageIncremental, record, report, loadStore, PRICE, locateLatestTranscriptDir }

// ── CLI ─────────────────────────────────────────────────────────────────────
if (require.main === module) {
  const [,, cmd, ...args] = process.argv
  const pct = n => (n * 100).toFixed(1) + '%'
  const usd = n => '$' + (n || 0).toFixed(2)

  if (cmd === 'record') {
    const [path, sessionId] = args
    if (!path) { console.error('Usage: token-telemetry.js record <transcript.jsonl> [sessionId]'); process.exit(1) }
    const u = record(path, sessionId)
    if (!u) { console.error('Aucun usage lisible dans le transcript'); process.exit(1) }
    console.log(`✓ Enregistré — hit ${pct(u.cacheHitRate)}, économie input ${pct(u.inputCostSavingsPct)} (${usd(u.savedUsd)} sur ${usd(u.noCacheCostUsd)})`)

  } else if (cmd === 'report') {
    const { aggregate: a, sessions } = report()
    if (!a || !a.sessions) { console.log('Aucune télémétrie. Lancer : token-telemetry.js record <transcript>'); process.exit(0) }
    console.log(`\nTélémétrie tokens RÉELLE — ${a.sessions} session(s), ${a.turns} tours assistant\n`)
    console.log(`  input plein   : ${a.input.toLocaleString()}`)
    console.log(`  cache write   : ${a.cacheCreation.toLocaleString()}`)
    console.log(`  cache read    : ${a.cacheRead.toLocaleString()}  (remise 90%)`)
    console.log(`  output        : ${a.output.toLocaleString()}`)
    console.log(`  CACHE HIT RATE: ${pct(a.cacheHitRate)}`)
    console.log(`  coût réel     : ${usd(a.realCostUsd)}  vs sans cache : ${usd(a.noCacheCostUsd)}`)
    console.log(`  ÉCONOMIE      : ${pct(a.inputCostSavingsPct)}  (${usd(a.savedUsd)})`)
    console.log(`\n  (tarifs ${PRICE.input}/${PRICE.cacheRead}/${PRICE.output} $/Mtok — le % est robuste au tier, le $ suppose Sonnet)\n`)

  } else {
    console.log('Usage: token-telemetry.js <record <transcript> [id] | report>')
    process.exit(1)
  }
}
