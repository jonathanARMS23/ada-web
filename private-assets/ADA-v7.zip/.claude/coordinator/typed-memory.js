#!/usr/bin/env node
'use strict'
/**
 * coordinator/typed-memory.js — Système de mémoire typée 3-stores pour ADA
 *
 * Stores :
 *   episodic   — TTL 7j, contexte récent, décroissance temporelle rapide
 *   semantic   — persistant, connaissances accumulées, score TF-IDF pur
 *   procedural — append-oriented, patterns & recettes, boost par usage
 *
 * Zéro dépendance externe — Node.js CJS pur.
 *
 * CLI :
 *   node typed-memory.js store <type> "<key>" "<content>"
 *   node typed-memory.js retrieve "<query>" [--type episodic|semantic|procedural] [--limit 5]
 *   node typed-memory.js stats
 *   node typed-memory.js expire
 */

const { readFileSync, writeFileSync, existsSync, mkdirSync, openSync, closeSync, unlinkSync } = require('fs')
const { join } = require('path')
const os = require('os')

// ── Config ────────────────────────────────────────────────────────────────────

const CONFIG_DIR = process.env.CLAUDE_CONFIG_DIR || join(process.env.HOME ?? os.homedir(), '.claude')
const COORD_DIR  = join(CONFIG_DIR, 'coordinator')

const STORE_FILES = {
  episodic:   join(COORD_DIR, 'memory-episodic.json'),
  semantic:   join(COORD_DIR, 'memory-semantic.json'),
  procedural: join(COORD_DIR, 'memory-procedural.json'),
}

const MAX_PER_STORE    = 500
const TTL_EPISODIC_MS  = 7 * 24 * 60 * 60 * 1000   // 7 jours
const STALE_DAYS       = 30
const MIN_SCORE_KEEP   = 0.1

// ── Helpers I/O ───────────────────────────────────────────────────────────────

function ensureDir(p) {
  if (!existsSync(p)) mkdirSync(p, { recursive: true })
}

/**
 * @param {'episodic'|'semantic'|'procedural'} type
 * @returns {Array<Entry>}
 */
function loadStore(type) {
  const file = STORE_FILES[type]
  if (!existsSync(file)) return []
  try {
    const raw = JSON.parse(readFileSync(file, 'utf8'))
    return Array.isArray(raw) ? raw : []
  } catch {
    return []
  }
}

/**
 * Acquiert un lock O_EXCL sur <file>.lock. Retourne un booléen.
 * @param {string} lockPath
 * @returns {boolean}
 */
function acquireLock(lockPath) {
  try {
    const fd = openSync(lockPath, 'wx')
    closeSync(fd)
    return true
  } catch {
    return false
  }
}

/**
 * @param {string} lockPath
 */
function releaseLock(lockPath) {
  try { unlinkSync(lockPath) } catch { /* already gone */ }
}

/**
 * @param {'episodic'|'semantic'|'procedural'} type
 * @param {Array<Entry>} entries
 */
function saveStore(type, entries) {
  ensureDir(COORD_DIR)
  const file     = STORE_FILES[type]
  const lockPath = file + '.lock'
  const tmp      = file + '.tmp'
  const deadline = Date.now() + 2000
  while (!acquireLock(lockPath)) {
    if (Date.now() > deadline) throw new Error(`Timeout acquisition lock ${lockPath}`)
    Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 50)
  }
  try {
    writeFileSync(tmp, JSON.stringify(entries, null, 2), 'utf8')
    require('fs').renameSync(tmp, file)
  } finally {
    releaseLock(lockPath)
  }
}

// ── ID ────────────────────────────────────────────────────────────────────────

function makeId() {
  return `mem-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`
}

// ── TF-IDF inline ─────────────────────────────────────────────────────────────

/**
 * Tokenise en gardant les caractères unicode basiques (fr/en).
 * @param {string} text
 * @returns {string[]}
 */
function tokenize(text) {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9àâéèêëîïôùûüç\s]/g, ' ')
    .split(/\s+/)
    .filter(t => t.length > 2)
}

/**
 * Similarité cosine sparse sur les tokens communs.
 * @param {string[]} a
 * @param {string[]} b
 * @returns {number} ∈ [0, 1]
 */
function cosineSimilarity(a, b) {
  const aSet = new Set(a)
  const bSet = new Set(b)
  let common = 0
  for (const t of aSet) { if (bSet.has(t)) common++ }
  return common / (Math.sqrt(aSet.size) * Math.sqrt(bSet.size) + 1e-10)
}

// ── Détection automatique du type ─────────────────────────────────────────────

/**
 * @param {string} query
 * @returns {'episodic'|'semantic'|'procedural'}
 */
function detectType(query) {
  const q = query.toLowerCase()
  if (/récemment|dernier|aujourd|session|hier|ce matin|vient de|just now/.test(q)) return 'episodic'
  if (/comment|how to|étapes|procédure|pattern|best practice|recette|template/.test(q)) return 'procedural'
  return 'semantic'
}

// ── Scoring par type ──────────────────────────────────────────────────────────

/**
 * @param {Entry} entry
 * @param {string[]} queryTokens
 * @param {'episodic'|'semantic'|'procedural'} type
 * @returns {number}
 */
function scoreEntry(entry, queryTokens, type) {
  const entryTokens = tokenize((entry.key || '') + ' ' + (entry.content || ''))
  const tfidf = cosineSimilarity(queryTokens, entryTokens)

  if (type === 'episodic') {
    const ageHours = (Date.now() - new Date(entry.ts).getTime()) / 3_600_000
    return tfidf * Math.exp(-ageHours / 48)
  }

  if (type === 'procedural') {
    return tfidf * (1 + 0.1 * (entry.usages || 0))
  }

  // semantic : TF-IDF pur
  return tfidf
}

// ── Éviction LRU (score × recency) quand > MAX_PER_STORE ─────────────────────

/**
 * Trie par score × recency desc et garde les MAX_PER_STORE premiers.
 * @param {Array<Entry>} entries
 * @returns {Array<Entry>}
 */
function evictLRU(entries) {
  if (entries.length <= MAX_PER_STORE) return entries
  return entries
    .map(e => {
      const ageMs = Date.now() - new Date(e.ts).getTime()
      const recency = Math.exp(-ageMs / (30 * 24 * 3_600_000))
      return { e, rank: (e.score || 0) * recency + (e.usages || 0) * 0.01 }
    })
    .sort((a, b) => b.rank - a.rank)
    .slice(0, MAX_PER_STORE)
    .map(x => x.e)
}

// ── API publique ──────────────────────────────────────────────────────────────

/**
 * Stocke une entrée dans le store approprié.
 * @param {'episodic'|'semantic'|'procedural'|'auto'} type
 * @param {string} key
 * @param {string} content
 * @param {Record<string,any>} [metadata]
 * @returns {string} ID de l'entrée
 */
function store(type, key, content, metadata = {}) {
  const resolved = type === 'auto' ? detectType(content) : type
  if (!STORE_FILES[resolved]) throw new Error('Type invalide : ' + type)

  const id  = makeId()
  const now = new Date().toISOString()
  const tags = [...new Set(tokenize((key || '') + ' ' + (content || '')).slice(0, 20))]

  /** @type {Entry} */
  const entry = {
    id,
    key:     String(key || '').slice(0, 200),
    content: String(content || '').slice(0, 4000),
    tags,
    ts:      now,
    usages:  0,
    score:   metadata.score != null ? metadata.score : 0.5,
  }

  // TTL pour episodic seulement
  if (resolved === 'episodic') {
    entry.ttl = new Date(Date.now() + TTL_EPISODIC_MS).toISOString()
  }

  // Métadonnées supplémentaires libres (phase, agent, verdict, runId…)
  if (Object.keys(metadata).length) {
    entry.meta = metadata
  }

  const entries = loadStore(resolved)
  entries.push(entry)
  saveStore(resolved, evictLRU(entries))

  return id
}

/**
 * Retrouve des entrées par similarité TF-IDF.
 * @param {string} query
 * @param {{ type?: string, limit?: number, minScore?: number }} [opts]
 * @returns {Array<{ id: string, key: string, content: string, score: number, type: string }>}
 */
function retrieve(query, opts = {}) {
  const limit    = opts.limit    ?? 5
  const minScore = opts.minScore ?? 0.01
  const queryTokens = tokenize(query)

  const typesOrder = opts.type && STORE_FILES[opts.type]
    ? [opts.type, ...Object.keys(STORE_FILES).filter(t => t !== opts.type)]
    : (() => {
        const detected = detectType(query)
        return [detected, ...Object.keys(STORE_FILES).filter(t => t !== detected)]
      })()

  const results = []

  for (const type of typesOrder) {
    const entries = loadStore(type)
    for (const entry of entries) {
      const score = scoreEntry(entry, queryTokens, type)
      if (score >= minScore) {
        results.push({
          id:      entry.id,
          key:     entry.key,
          content: entry.content,
          score:   parseFloat(score.toFixed(4)),
          type,
        })
      }
    }
  }

  return results
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
}

/**
 * Détecte le type optimal pour une requête donnée.
 * @param {string} query
 * @returns {'episodic'|'semantic'|'procedural'}
 */
function routeQuery(query) {
  return detectType(query)
}

/**
 * Purge les entrées expirées ou dormantes.
 * - Episodic : supprime si ttl < now
 * - Tous : supprime si score < 0.1, usages = 0, âge > 30j
 */
function expire() {
  const now = Date.now()
  const staleMs = STALE_DAYS * 24 * 3_600_000
  let totalPurged = 0

  for (const type of Object.keys(STORE_FILES)) {
    const entries = loadStore(type)
    const before  = entries.length

    const kept = entries.filter(e => {
      // TTL episodic
      if (type === 'episodic' && e.ttl && new Date(e.ttl).getTime() < now) return false
      // Stale global
      const ageMs = now - new Date(e.ts).getTime()
      if (ageMs > staleMs && (e.score || 0) < MIN_SCORE_KEEP && (e.usages || 0) === 0) return false
      return true
    })

    if (kept.length !== before) {
      saveStore(type, kept)
      totalPurged += before - kept.length
    }
  }

  return totalPurged
}

/**
 * Statistiques des 3 stores.
 * @returns {{ episodic: number, semantic: number, procedural: number, total: number }}
 */
function stats() {
  const episodic   = loadStore('episodic').length
  const semantic   = loadStore('semantic').length
  const procedural = loadStore('procedural').length
  return { episodic, semantic, procedural, total: episodic + semantic + procedural }
}

/**
 * Incrémente le compteur d'usage d'une entrée.
 * @param {string} id
 * @param {'episodic'|'semantic'|'procedural'} type
 */
function incrementUsage(id, type) {
  if (!STORE_FILES[type]) return
  const entries = loadStore(type)
  let found = false
  for (const e of entries) {
    if (e.id === id) {
      e.usages = (e.usages || 0) + 1
      found = true
      break
    }
  }
  if (found) saveStore(type, entries)
}

// ── Exports ───────────────────────────────────────────────────────────────────

module.exports = { store, retrieve, routeQuery, expire, stats, incrementUsage }

// ── CLI ───────────────────────────────────────────────────────────────────────

if (require.main === module) {
  const [,, cmd, ...rest] = process.argv

  const C = {
    reset: '\x1b[0m', bold: '\x1b[1m',
    green: '\x1b[32m', cyan: '\x1b[36m', yellow: '\x1b[33m', gray: '\x1b[90m',
  }

  switch (cmd) {
    case 'store': {
      // node typed-memory.js store <type> "<key>" "<content>"
      const [type, key, content] = rest
      if (!type || !key || !content) {
        console.error('Usage: node typed-memory.js store <type> "<key>" "<content>"')
        process.exit(1)
      }
      try {
        const id = store(type, key, content)
        console.log(`${C.green}✓${C.reset} Stocké [${type}] ${id}`)
      } catch (e) {
        console.error(`✗ ${e.message}`)
        process.exit(1)
      }
      break
    }

    case 'retrieve': {
      // node typed-memory.js retrieve "<query>" [--type x] [--limit n]
      const flags = {}
      const queryParts = []
      for (let i = 0; i < rest.length; i++) {
        if (rest[i].startsWith('--')) {
          flags[rest[i].slice(2)] = rest[i + 1] || true
          i++
        } else {
          queryParts.push(rest[i])
        }
      }
      const query = queryParts.join(' ')
      if (!query) {
        console.error('Usage: node typed-memory.js retrieve "<query>" [--type x] [--limit n]')
        process.exit(1)
      }
      const results = retrieve(query, {
        type:  flags.type  || undefined,
        limit: flags.limit ? parseInt(flags.limit, 10) : 5,
      })
      if (!results.length) {
        console.log(`${C.yellow}Aucun résultat${C.reset}`)
        break
      }
      console.log(`\n${C.bold}Résultats pour : "${query}"${C.reset}\n`)
      for (const r of results) {
        console.log(`  ${C.cyan}[${r.type}]${C.reset} score=${r.score.toFixed(3)}  ${C.bold}${r.key}${C.reset}`)
        console.log(`  ${C.gray}${r.content.slice(0, 120)}${r.content.length > 120 ? '…' : ''}${C.reset}`)
        console.log('')
      }
      break
    }

    case 'stats': {
      const s = stats()
      console.log(`\n${C.bold}Typed Memory — Stats${C.reset}`)
      console.log(`  episodic   : ${s.episodic}`)
      console.log(`  semantic   : ${s.semantic}`)
      console.log(`  procedural : ${s.procedural}`)
      console.log(`  total      : ${s.total}`)
      console.log('')
      break
    }

    case 'expire': {
      const n = expire()
      console.log(`${C.green}✓${C.reset} ${n} entrée(s) purgée(s)`)
      break
    }

    default:
      console.log(`\n${C.bold}coordinator/typed-memory.js — Mémoire typée ADA${C.reset}\n`)
      console.log('  store    <type> "<key>" "<content>"   Stocker (episodic|semantic|procedural|auto)')
      console.log('  retrieve "<query>" [--type x] [--limit n]  Retrouver')
      console.log('  stats                                  Compter les entrées par store')
      console.log('  expire                                 Purger les entrées expirées/dormantes')
      console.log('')
  }
}
