#!/usr/bin/env node
'use strict'
/**
 * coordinator/vault.js — AES-256-GCM encryption at rest
 *
 * API :
 *   encrypt(plaintext, key)                    → { ciphertext, iv, tag }
 *   decrypt(payload, key)                      → plaintext
 *   deriveKey(passphrase, salt?)               → { key: Buffer, salt: string }
 *   encryptFile(filePath, passphrase)          → { encPath, salt }
 *   decryptFile(encPath, passphrase, salt)     → plaintext
 *
 * Zéro dépendance externe — uniquement node:crypto et node:fs
 *
 * CLI :
 *   VAULT_PASSPHRASE=<secret> node vault.js encrypt <file>
 *   VAULT_PASSPHRASE=<secret> node vault.js decrypt <file.enc> <salt>
 */

const crypto = require('node:crypto')
const fs     = require('node:fs')

// ── Helpers ───────────────────────────────────────────────────────────────────

/**
 * Normalise une clé en Buffer de 32 bytes.
 * @param {Buffer|string} key  — Buffer 32 bytes ou hex string 64 chars
 * @returns {Buffer}
 */
function toKeyBuffer(key) {
  if (Buffer.isBuffer(key)) {
    if (key.length !== 32) throw new Error(`vault: clé invalide — attendu 32 bytes, reçu ${key.length}`)
    return key
  }
  if (typeof key === 'string') {
    const buf = Buffer.from(key, 'hex')
    if (buf.length !== 32) throw new Error(`vault: hex key invalide — attendu 64 chars hex (32 bytes), reçu ${buf.length}`)
    return buf
  }
  throw new TypeError('vault: key doit être un Buffer ou une hex string')
}

// ── encrypt / decrypt ─────────────────────────────────────────────────────────

/**
 * Chiffre un plaintext avec AES-256-GCM.
 * @param {string} plaintext
 * @param {Buffer|string} key  — 32 bytes (256 bits) en hex string ou Buffer
 * @returns {{ ciphertext: string, iv: string, tag: string }}
 */
function encrypt(plaintext, key) {
  const keyBuf = toKeyBuffer(key)
  const iv     = crypto.randomBytes(12)
  const cipher = crypto.createCipheriv('aes-256-gcm', keyBuf, iv)
  const ct     = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()])
  const tag    = cipher.getAuthTag()
  return {
    ciphertext: ct.toString('hex'),
    iv:         iv.toString('hex'),
    tag:        tag.toString('hex')
  }
}

/**
 * Déchiffre un payload AES-256-GCM.
 * @param {{ ciphertext: string, iv: string, tag: string }} payload
 * @param {Buffer|string} key
 * @returns {string} plaintext
 */
function decrypt(payload, key) {
  const keyBuf   = toKeyBuffer(key)
  const decipher = crypto.createDecipheriv(
    'aes-256-gcm',
    keyBuf,
    Buffer.from(payload.iv, 'hex')
  )
  decipher.setAuthTag(Buffer.from(payload.tag, 'hex'))
  return decipher.update(Buffer.from(payload.ciphertext, 'hex')) + decipher.final('utf8')
}

// ── deriveKey ─────────────────────────────────────────────────────────────────

/**
 * Dérive une clé 32 bytes depuis une passphrase (PBKDF2, 100000 iter, sha256).
 * @param {string} passphrase
 * @param {Buffer|string} [salt]  — si absent, génère 16 bytes aléatoires
 * @returns {{ key: Buffer, salt: string }}
 */
function deriveKey(passphrase, salt) {
  let saltBuf
  if (salt == null) {
    saltBuf = crypto.randomBytes(16)
  } else if (Buffer.isBuffer(salt)) {
    saltBuf = salt
  } else {
    saltBuf = Buffer.from(salt, 'hex')
  }

  const keyBuf = crypto.pbkdf2Sync(passphrase, saltBuf, 100_000, 32, 'sha256')
  return { key: keyBuf, salt: saltBuf.toString('hex') }
}

// ── encryptFile / decryptFile ─────────────────────────────────────────────────

/**
 * Chiffre un fichier en place → <filePath>.enc
 * Le .enc contient un JSON : { ciphertext, iv, tag }
 * @param {string} filePath
 * @param {string} passphrase
 * @returns {{ encPath: string, salt: string }}
 */
function encryptFile(filePath, passphrase) {
  const plaintext    = fs.readFileSync(filePath, 'utf8')
  const { key, salt } = deriveKey(passphrase)
  const payload      = encrypt(plaintext, key)
  const encPath      = filePath + '.enc'
  fs.writeFileSync(encPath, JSON.stringify(payload), 'utf8')
  return { encPath, salt }
}

/**
 * Déchiffre un .enc → plaintext
 * @param {string} encPath
 * @param {string} passphrase
 * @param {string} salt  — hex string retourné par encryptFile
 * @returns {string}  — contenu déchiffré
 */
function decryptFile(encPath, passphrase, salt) {
  const raw     = fs.readFileSync(encPath, 'utf8')
  const payload = JSON.parse(raw)
  const { key } = deriveKey(passphrase, salt)
  return decrypt(payload, key)
}

// ── Exports ───────────────────────────────────────────────────────────────────

module.exports = { encrypt, decrypt, deriveKey, encryptFile, decryptFile }

// ── CLI ───────────────────────────────────────────────────────────────────────

if (require.main === module) {
  const [,, cmd, filePath, saltArg] = process.argv
  const passphrase = process.env.VAULT_PASSPHRASE

  if (!cmd || !filePath) {
    console.error('Usage:')
    console.error('  VAULT_PASSPHRASE=<secret> node vault.js encrypt <file>')
    console.error('  VAULT_PASSPHRASE=<secret> node vault.js decrypt <file.enc> <salt>')
    process.exit(1)
  }

  if (!passphrase) {
    console.error('Erreur: VAULT_PASSPHRASE manquant (variable d\'environnement requise)')
    process.exit(1)
  }

  if (cmd === 'encrypt') {
    const result = encryptFile(filePath, passphrase)
    console.log(`Chiffré → ${result.encPath}`)
    console.log(`Salt    : ${result.salt}`)
    console.log('Conserve le salt pour le déchiffrement.')

  } else if (cmd === 'decrypt') {
    if (!saltArg) {
      console.error('Erreur: salt manquant pour decrypt')
      process.exit(1)
    }
    const plaintext = decryptFile(filePath, passphrase, saltArg)
    console.log(plaintext)

  } else {
    console.error(`Commande inconnue: ${cmd}. Utilise encrypt ou decrypt.`)
    process.exit(1)
  }
}
