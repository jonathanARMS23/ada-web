#!/usr/bin/env node
/**
 * coordinator/webhook.js — Dispatch webhook ADA (partagé run.js + session-end.js)
 *
 * Utilisation :
 *   const { dispatchWebhook } = require('./webhook.js')
 *   dispatchWebhook('run.complete', { runId, pipeline, totalCost })
 *
 * Config lue depuis ~/.ada.json :
 *   { webhook: { url: "https://...", events: ["run.complete", "run.fail", "session.end"] } }
 *
 * Sécurité :
 *   - SSRF guard : bloque localhost, LAN, loopback, link-local, Unique-Local IPv6
 *   - Pas de redirect suivi
 *   - Timeout 5s
 *   - Échoue silencieusement (fire-and-forget)
 */

'use strict'

const { existsSync, readFileSync } = require('fs')
const { join } = require('path')
const os = require('os')

// ── SSRF guard ─────────────────────────────────────────────────────────────────
// Couvre : localhost, 127.x, 0.0.0.0, ::1, ::ffff:, ULA IPv6 (fd…),
//          RFC-1918 (10., 172.16-31., 192.168.), link-local (169.254.), octal 0177.
const BLOCKED_HOSTS = /^(localhost|127\.|0\.0\.0\.0|::1$|::ffff:|fd[0-9a-f]{2}:|10\.|172\.(1[6-9]|2\d|3[01])\.|192\.168\.|169\.254\.|0177\.)/i

/**
 * Vérifie qu'une URL webhook est sûre (non-SSRF).
 * @param {string} urlStr
 * @returns {boolean}
 */
function isWebhookUrlSafe(urlStr) {
  try {
    const u = new URL(urlStr)
    if (!['http:', 'https:'].includes(u.protocol)) return false
    // URL.hostname returns "[::1]" for IPv6 — strip brackets before regex test
    const host = u.hostname.replace(/^\[|\]$/g, '')
    if (BLOCKED_HOSTS.test(host)) return false
    // Bloquer les hostnames purement numériques (ex: "2130706433" = 127.0.0.1 en décimal)
    if (/^\d+$/.test(host)) return false
    return true
  } catch { return false }
}

// Formes IPv6 que BLOCKED_HOSTS ne couvre pas explicitement : loopback ::1,
// IPv4-mapped ::ffff:, ULA fc00::/7 (fc.. en plus de fd..).
const EXTRA_PRIVATE_RE = /^(::1|::ffff:|fc[0-9a-f]{2}:|fd[0-9a-f]{2}:)/i

/**
 * Détermine si un hostname pointe vers une cible privée/interne (anti-SSRF).
 * Fonction PURE (pas d'I/O réseau) — testable en isolation. Foyer unique de la
 * garde, réutilisé par skill-registry et plugins (DRY).
 * @param {string} hostname — hostname brut (peut être bracketé pour IPv6)
 * @returns {boolean} true si l'hôte est privé/interne (donc à bloquer)
 */
function isPrivateHost(hostname) {
  if (!hostname || typeof hostname !== 'string') return true
  const h = hostname.replace(/^\[|\]$/g, '') // dé-bracket IPv6
  if (!isWebhookUrlSafe(`https://${h}/`)) return true
  if (EXTRA_PRIVATE_RE.test(h)) return true
  return false
}

/**
 * Dispatche un événement webhook de façon fire-and-forget.
 * Lit la config depuis ~/.ada.json.
 *
 * @param {string} event     Identifiant de l'événement (ex: "run.complete", "session.end")
 * @param {object} payload   Données additionnelles sérialisées dans le body JSON
 * @param {object|null} [adaCfg]  Contenu de ~/.ada.json déjà lu (évite double I/O)
 */
function dispatchWebhook(event, payload, adaCfg) {
  try {
    let cfg = adaCfg
    if (!cfg) {
      const cfgPath = join(os.homedir(), '.ada.json')
      if (!existsSync(cfgPath)) return
      cfg = JSON.parse(readFileSync(cfgPath, 'utf8'))
    }

    const wh = cfg && cfg.webhook
    if (!wh || !wh.url || !Array.isArray(wh.events) || !wh.events.includes(event)) return
    if (!isWebhookUrlSafe(wh.url)) return

    const body = JSON.stringify({ event, ts: new Date().toISOString(), ...payload })
    const url  = new URL(wh.url)
    const headers = {
      'Content-Type':   'application/json',
      'Content-Length': Buffer.byteLength(body),
    }
    // S3 — signature HMAC du body (style GitHub) si un secret est configuré.
    // Permet au récepteur de vérifier l'authenticité/intégrité du payload.
    if (wh.secret) {
      try {
        const sig = require('crypto').createHmac('sha256', String(wh.secret)).update(body).digest('hex')
        headers['X-ADA-Signature'] = `sha256=${sig}`
      } catch {}
    }
    const options = {
      hostname: url.hostname,
      port:     url.port || (url.protocol === 'https:' ? 443 : 80),
      path:     url.pathname + url.search,
      method:   'POST',
      headers,
      timeout: 5000,
      // S4 — anti DNS-rebinding : on valide l'IP RÉSOLUE (pas seulement le hostname) et
      // on épingle cette IP pour la connexion. Bloque un domaine qui résout vers une IP
      // interne (127.x, RFC-1918, link-local 169.254, metadata cloud…).
      lookup(hostname, lopts, cb) {
        require('dns').lookup(hostname, lopts, (err, address, family) => {
          if (err) return cb(err)
          if (BLOCKED_HOSTS.test(String(address))) return cb(new Error('SSRF: IP résolue bloquée'))
          cb(null, address, family)
        })
      },
    }

    const mod = url.protocol === 'https:' ? require('https') : require('http')
    const req = mod.request(options)
    req.on('timeout', () => req.destroy())
    req.on('error', () => {})
    // Consommer la réponse pour éviter les memory leaks
    req.on('response', res => res.resume())
    req.write(body)
    req.end()
  } catch {
    // Fire-and-forget — ne jamais laisser un webhook crasher l'appelant
  }
}

module.exports = { dispatchWebhook, isWebhookUrlSafe, isPrivateHost }
