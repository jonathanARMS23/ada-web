#!/usr/bin/env node
'use strict'
/**
 * coordinator/witness.js — Witness anti-régression (zéro dépendance npm).
 *
 * Adapté du mécanisme ruflo (verification/), SIMPLIFIÉ pour un usage
 * mono-utilisateur : PAS de signature Ed25519. Chaque fix protégé est
 * attesté par un SHA-256 par fichier + un marker (sous-chaîne distinctive
 * CRÉÉE par le fix). Le verify distingue finement :
 *
 *   - pass       marker présent ET sha256 == baseline
 *   - drift      marker présent MAIS sha256 != baseline  → toléré (warning)
 *   - regressed  marker ABSENT                           → bloque (exit 1)
 *   - missing    fichier introuvable                     → bloque (exit 1)
 *
 * Le drift est attendu (le fichier évolue autour du fix) ; seule la
 * disparition du marker signale que la ligne porteuse du fix a été perdue.
 * `regen` recalcule les SHA une fois un drift accepté. Un historique JSONL
 * append-only (last-pass → regressed-at) permet un bisect rapide.
 *
 * Dépendances : uniquement node:crypto, node:fs, node:path, node:child_process.
 *
 * CLI :
 *   node witness.js verify                       exit 0 (pass/drift) | 1 (regressed/missing)
 *   node witness.js regen                        recalcule les SHA (baseline) + snapshot history
 *   node witness.js history [summary|regressions|timeline|list] [--id X] [--json]
 *   node witness.js add <id> <file> <marker> [desc]
 */

const { readFileSync, writeFileSync, existsSync, appendFileSync } = require('node:fs')
const { join, resolve } = require('node:path')
const { createHash } = require('node:crypto')
const { execSync } = require('node:child_process')

// ─── chemins par défaut ────────────────────────────────────────────
const HERE = __dirname
const DEFAULT_FIXES = join(HERE, 'witness-fixes.json')
const DEFAULT_HISTORY = join(HERE, 'witness-history.jsonl')
// __dirname = <repo>/.claude/coordinator → repoRoot = <repo>
const DEFAULT_REPO_ROOT = resolve(HERE, '..', '..')
// install.sh copie coordinator/ vers un profil runtime (ex: ~/.claude-pro/)
// dont le layout n'a PAS le préfixe `.claude/` : witness.js y vit dans
// <runtimeRoot>/coordinator/, donc le parent immédiat de HERE EST la racine
// runtime. En repo (HERE = <repo>/.claude/coordinator), ce même calcul ne
// vaut que <repo>/.claude — inoffensif : ce fallback n'est consulté que si
// le premier essai (repoRoot détecté) échoue, ce qui n'arrive jamais en repo.
const RUNTIME_FALLBACK_ROOT = resolve(HERE, '..')
const SCHEMA = 'ada-witness/v1'
const CLAUDE_PREFIX = '.claude/'

// ─── helpers bas niveau ────────────────────────────────────────────
function fileSha256(absPath) {
  return createHash('sha256').update(readFileSync(absPath)).digest('hex')
}

function fileContent(absPath) {
  return readFileSync(absPath, 'utf8')
}

/** Compte les occurrences (non chevauchantes) d'un marker dans un texte. */
function countOccurrences(haystack, needle) {
  if (!needle) return 0
  let n = 0
  let i = 0
  while ((i = haystack.indexOf(needle, i)) !== -1) { n++; i += needle.length }
  return n
}

/**
 * Résout le chemin absolu d'un fix avec fallback runtime (deux essais) :
 *   1. tel quel, relatif à repoRoot (comportement historique — repo layout) ;
 *   2. si absent ET que file commence par `.claude/`, on strippe ce préfixe
 *      et on réessaie relatif à fallbackRoot (layout runtime, sans `.claude/`).
 * Ne rapporte `null` (→ missing) que si les DEUX essais échouent.
 * @param {string} repoRoot
 * @param {string} file
 * @param {string} [fallbackRoot] défaut : RUNTIME_FALLBACK_ROOT
 * @returns {string|null}
 */
function resolveFixPath(repoRoot, file, fallbackRoot) {
  const primary = join(repoRoot, file)
  if (existsSync(primary)) return primary
  if (file.startsWith(CLAUDE_PREFIX)) {
    const base = fallbackRoot || RUNTIME_FALLBACK_ROOT
    const fallback = join(base, file.slice(CLAUDE_PREFIX.length))
    if (existsSync(fallback)) return fallback
  }
  return null
}

// ─── évaluation d'un fix ───────────────────────────────────────────
/**
 * Évalue un fix contre l'arbre courant.
 * @param {string} repoRoot
 * @param {{id:string,file:string,marker:string,sha256?:string}} fix
 * @param {{fallbackRoot?:string}} [opts] fallbackRoot surchargeable (tests / layouts alternatifs)
 * @returns {{id,file,marker,status,markerPresent,markerCount,sha256Match,liveSha256,recordedSha256}}
 */
function evaluateFix(repoRoot, fix, opts = {}) {
  const abs = resolveFixPath(repoRoot, fix.file, opts.fallbackRoot)
  const recordedSha256 = fix.sha256 || null
  if (!abs) {
    return {
      id: fix.id, file: fix.file, marker: fix.marker,
      status: 'missing', markerPresent: false, markerCount: 0,
      sha256Match: false, liveSha256: null, recordedSha256,
    }
  }
  const content = fileContent(abs)
  const markerCount = countOccurrences(content, fix.marker)
  const markerPresent = markerCount > 0
  const liveSha256 = fileSha256(abs)
  // Pas de baseline enregistré → on ne peut pas juger le drift : marker seul fait foi.
  const sha256Match = recordedSha256 ? liveSha256 === recordedSha256 : true
  const status = !markerPresent
    ? 'regressed'
    : (sha256Match ? 'pass' : 'drift')
  return {
    id: fix.id, file: fix.file, marker: fix.marker,
    status, markerPresent, markerCount, sha256Match, liveSha256, recordedSha256,
  }
}

// ─── I/O fixes ─────────────────────────────────────────────────────
function loadFixes(fixesPath) {
  if (!existsSync(fixesPath)) return { schema: SCHEMA, fixes: [] }
  const raw = JSON.parse(readFileSync(fixesPath, 'utf8'))
  return { schema: raw.schema || SCHEMA, fixes: Array.isArray(raw.fixes) ? raw.fixes : [] }
}

function saveFixes(fixesPath, doc) {
  writeFileSync(fixesPath, JSON.stringify({ schema: doc.schema || SCHEMA, fixes: doc.fixes }, null, 2) + '\n')
}

// ─── verify ────────────────────────────────────────────────────────
/**
 * @param {{fixesPath?:string, repoRoot?:string, fallbackRoot?:string}} [opts]
 * @returns {{ok:boolean, summary:{pass,drift,regressed,missing,total}, results:Array}}
 */
function runVerify(opts = {}) {
  const fixesPath = opts.fixesPath || DEFAULT_FIXES
  const repoRoot = opts.repoRoot || DEFAULT_REPO_ROOT
  const { fixes } = loadFixes(fixesPath)
  const results = fixes.map(f => evaluateFix(repoRoot, f, { fallbackRoot: opts.fallbackRoot }))
  const summary = {
    pass: results.filter(r => r.status === 'pass').length,
    drift: results.filter(r => r.status === 'drift').length,
    regressed: results.filter(r => r.status === 'regressed').length,
    missing: results.filter(r => r.status === 'missing').length,
    total: results.length,
  }
  const ok = summary.regressed === 0 && summary.missing === 0
  return { ok, summary, results }
}

// ─── regen ─────────────────────────────────────────────────────────
function currentCommit(repoRoot) {
  try { return execSync('git rev-parse HEAD', { cwd: repoRoot }).toString().trim() }
  catch { return 'unknown' }
}
function currentBranch(repoRoot) {
  try { return execSync('git rev-parse --abbrev-ref HEAD', { cwd: repoRoot }).toString().trim() }
  catch { return 'unknown' }
}

/**
 * Recalcule le SHA baseline de chaque fix (fichier présent) et l'écrit
 * dans le fichier de fixes. Append un snapshot dans l'historique JSONL.
 * @param {{fixesPath?,repoRoot?,historyPath?,commit?,branch?,issuedAt?,fallbackRoot?}} [opts]
 */
function runRegen(opts = {}) {
  const fixesPath = opts.fixesPath || DEFAULT_FIXES
  const repoRoot = opts.repoRoot || DEFAULT_REPO_ROOT
  const historyPath = opts.historyPath || DEFAULT_HISTORY
  const doc = loadFixes(fixesPath)

  const evaluated = []
  const updatedFixes = doc.fixes.map(f => {
    const abs = resolveFixPath(repoRoot, f.file, opts.fallbackRoot)
    const present = !!abs
    const sha256 = present ? fileSha256(abs) : (f.sha256 || '')
    const markerVerified = present ? countOccurrences(fileContent(abs), f.marker) > 0 : false
    evaluated.push({ id: f.id, sha256, markerVerified, present })
    return { ...f, sha256 }
  })

  saveFixes(fixesPath, { schema: doc.schema, fixes: updatedFixes })

  const commit = opts.commit || currentCommit(repoRoot)
  const branch = opts.branch || currentBranch(repoRoot)
  const issuedAt = opts.issuedAt || new Date().toISOString()
  const fixesIndex = {}
  for (const e of evaluated) fixesIndex[e.id] = { sha256: e.sha256, markerVerified: e.markerVerified }
  const snapshot = {
    v: 1,
    commit,
    branch,
    issuedAt,
    summary: {
      totalFixes: evaluated.length,
      verified: evaluated.filter(e => e.markerVerified).length,
      missing: evaluated.filter(e => !e.present).length,
    },
    fixes: fixesIndex,
  }
  appendFileSync(historyPath, JSON.stringify(snapshot) + '\n')
  return { fixes: updatedFixes, snapshot }
}

// ─── add ───────────────────────────────────────────────────────────
/**
 * Ajoute un fix au manifeste (sha256 vide tant que non regen).
 * @param {{fixesPath?,id:string,file:string,marker:string,desc?:string}} opts
 */
function addFix(opts) {
  const fixesPath = opts.fixesPath || DEFAULT_FIXES
  if (!opts.id || !opts.file || !opts.marker) {
    throw new Error('addFix requiert id, file et marker')
  }
  const doc = loadFixes(fixesPath)
  if (doc.fixes.some(f => f.id === opts.id)) {
    throw new Error(`fix id déjà présent : ${opts.id}`)
  }
  const entry = { id: opts.id, desc: opts.desc || '', file: opts.file, marker: opts.marker, sha256: '' }
  doc.fixes.push(entry)
  saveFixes(fixesPath, doc)
  return entry
}

// ─── historique (bisect temporel) ──────────────────────────────────
function loadHistory(historyPath) {
  const p = historyPath || DEFAULT_HISTORY
  if (!existsSync(p)) return []
  return readFileSync(p, 'utf8').split('\n').filter(Boolean).map(l => JSON.parse(l))
}

/**
 * Pour chaque fix actuellement regressed (markerVerified=false dans la
 * dernière entrée), remonte jusqu'au dernier pass. L'entrée suivante = fenêtre
 * d'introduction de la régression.
 */
function findRegressionIntroductions(history) {
  if (!history.length) return []
  const latest = history[history.length - 1]
  const out = []
  for (const [id, state] of Object.entries(latest.fixes)) {
    if (state.markerVerified) continue
    let lastPass = null
    let regressedAt = latest
    for (let i = history.length - 2; i >= 0; i--) {
      const e = history[i]
      const s = e.fixes[id]
      if (s && s.markerVerified) { lastPass = e; break }
      regressedAt = e
    }
    out.push({
      id,
      lastPassCommit: lastPass ? lastPass.commit : null,
      lastPassIssuedAt: lastPass ? lastPass.issuedAt : null,
      regressedAtCommit: regressedAt.commit,
      regressedAtIssuedAt: regressedAt.issuedAt,
    })
  }
  return out
}

/** Timeline de statut d'un fix à travers l'historique (pass|regressed|absent). */
function fixTimeline(history, fixId) {
  return history.map(e => ({
    commit: e.commit,
    issuedAt: e.issuedAt,
    status: e.fixes[fixId]
      ? (e.fixes[fixId].markerVerified ? 'pass' : 'regressed')
      : 'absent',
  }))
}

/** Compare la dernière entrée à la précédente. */
function diffLatest(history) {
  if (history.length < 2) return { newlyRegressed: [], newlyPassing: [], added: [], removed: [] }
  const prev = history[history.length - 2]
  const curr = history[history.length - 1]
  const newlyRegressed = []; const newlyPassing = []; const added = []; const removed = []
  for (const id of Object.keys(curr.fixes)) {
    if (!(id in prev.fixes)) added.push(id)
    else if (prev.fixes[id].markerVerified && !curr.fixes[id].markerVerified) newlyRegressed.push(id)
    else if (!prev.fixes[id].markerVerified && curr.fixes[id].markerVerified) newlyPassing.push(id)
  }
  for (const id of Object.keys(prev.fixes)) {
    if (!(id in curr.fixes)) removed.push(id)
  }
  return { newlyRegressed, newlyPassing, added, removed }
}

module.exports = {
  fileSha256, countOccurrences, evaluateFix, resolveFixPath,
  loadFixes, saveFixes,
  runVerify, runRegen, addFix,
  loadHistory, findRegressionIntroductions, fixTimeline, diffLatest,
  DEFAULT_FIXES, DEFAULT_HISTORY, DEFAULT_REPO_ROOT, RUNTIME_FALLBACK_ROOT,
}

// ─── CLI ───────────────────────────────────────────────────────────
if (require.main === module) {
  main(process.argv.slice(2))
}

function parseFlags(argv) {
  const out = { _: [] }
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i]
    if (a === '--json') { out.json = true; continue }
    if (a.startsWith('--')) {
      const key = a.slice(2)
      const next = argv[i + 1]
      if (next && !next.startsWith('--')) { out[key] = next; i++ }
      else out[key] = true
      continue
    }
    out._.push(a)
  }
  return out
}

function main(argv) {
  const flags = parseFlags(argv)
  const cmd = flags._[0]

  if (!cmd || cmd === 'help' || flags.help) {
    printUsage()
    process.exit(cmd ? 0 : 2)
  }

  if (cmd === 'verify') {
    const { ok, summary, results } = runVerify()
    console.log('ADA witness — verify')
    console.log('────────────────────')
    console.log(`Summary: pass=${summary.pass} drift=${summary.drift} regressed=${summary.regressed} missing=${summary.missing} (total=${summary.total})`)
    const drifts = results.filter(r => r.status === 'drift')
    if (drifts.length) {
      console.log('\nDrift (toléré — SHA changé, marker présent ; lancez `regen` pour rebaser) :')
      for (const r of drifts) console.log(`  ⚠ ${r.id}  ${r.file}`)
    }
    const regressed = results.filter(r => r.status === 'regressed')
    if (regressed.length) {
      console.log('\nRÉGRESSIONS (marker disparu) :')
      for (const r of regressed) console.log(`  ✗ ${r.id}  marker absent dans ${r.file}\n      marker: ${JSON.stringify(r.marker)}`)
    }
    const missing = results.filter(r => r.status === 'missing')
    if (missing.length) {
      console.log('\nFichiers manquants :')
      for (const r of missing) console.log(`  ✗ ${r.id}  ${r.file}`)
    }
    const ambiguous = results.filter(r => r.markerCount > 1)
    if (ambiguous.length) {
      console.log('\nMarkers ambigus (>1 occurrence — envisagez un marker plus distinctif) :')
      for (const r of ambiguous) console.log(`  · ${r.id}  ${r.markerCount}× dans ${r.file}`)
    }
    console.log(`\n${ok ? '✓ OK — aucune régression' : '✗ ÉCHEC — régression/fichier manquant'}`)
    process.exit(ok ? 0 : 1)
  }

  if (cmd === 'regen') {
    const { fixes, snapshot } = runRegen()
    console.log('ADA witness — regen')
    console.log('───────────────────')
    console.log(`commit:   ${snapshot.commit.slice(0, 12)}  (${snapshot.branch})`)
    console.log(`issuedAt: ${snapshot.issuedAt}`)
    console.log(`fixes:    ${fixes.length}  verified=${snapshot.summary.verified}  missing=${snapshot.summary.missing}`)
    console.log(`\nSHA baseline recalculé pour ${fixes.length} fix(es).`)
    console.log(`Snapshot ajouté à ${DEFAULT_HISTORY}`)
    process.exit(0)
  }

  if (cmd === 'history') {
    const sub = flags._[1] || 'list'
    const history = loadHistory()
    if (!history.length) { console.error('historique vide — lancez `regen` d\'abord'); process.exit(1) }
    if (sub === 'list') {
      if (flags.json) return console.log(JSON.stringify(history.map(e => ({ commit: e.commit, issuedAt: e.issuedAt, summary: e.summary })), null, 2))
      for (const e of history) {
        const s = e.summary
        console.log(`${e.issuedAt}  ${String(e.commit).slice(0, 12)}  total=${s.totalFixes} verified=${s.verified} missing=${s.missing}`)
      }
      process.exit(0)
    }
    if (sub === 'summary') {
      const d = diffLatest(history)
      if (flags.json) return console.log(JSON.stringify({ entries: history.length, ...d }, null, 2))
      console.log(`entrées: ${history.length}`)
      console.log(`newly regressed: ${d.newlyRegressed.join(', ') || '(aucune)'}`)
      console.log(`newly passing:   ${d.newlyPassing.join(', ') || '(aucune)'}`)
      console.log(`added:           ${d.added.join(', ') || '(aucun)'}`)
      console.log(`removed:         ${d.removed.join(', ') || '(aucun)'}`)
      process.exit(d.newlyRegressed.length > 0 ? 1 : 0)
    }
    if (sub === 'regressions') {
      const r = findRegressionIntroductions(history)
      if (flags.json) return console.log(JSON.stringify(r, null, 2))
      if (!r.length) { console.log('aucune régression dans le dernier snapshot'); process.exit(0) }
      for (const x of r) {
        console.log(`${x.id}`)
        console.log(`  last pass:    ${x.lastPassCommit ? String(x.lastPassCommit).slice(0, 12) : '(jamais)'}  ${x.lastPassIssuedAt || ''}`)
        console.log(`  regressed at: ${String(x.regressedAtCommit).slice(0, 12)}  ${x.regressedAtIssuedAt}`)
      }
      process.exit(1)
    }
    if (sub === 'timeline') {
      if (!flags.id) { console.error('--id <fixId> requis pour timeline'); process.exit(2) }
      const t = fixTimeline(history, flags.id)
      if (flags.json) return console.log(JSON.stringify(t, null, 2))
      for (const e of t) console.log(`${e.issuedAt}  ${String(e.commit).slice(0, 12)}  ${e.status}`)
      process.exit(0)
    }
    console.error(`sous-commande history inconnue: ${sub}`); process.exit(2)
  }

  if (cmd === 'add') {
    const [, id, file, marker, ...descParts] = flags._
    if (!id || !file || !marker) {
      console.error('usage: node witness.js add <id> <file> <marker> [desc]'); process.exit(2)
    }
    try {
      const entry = addFix({ id, file, marker, desc: descParts.join(' ') })
      console.log(`✓ fix ajouté : ${entry.id}  (${entry.file})`)
      console.log('Lancez `node witness.js regen` pour enregistrer le SHA baseline.')
      process.exit(0)
    } catch (e) {
      console.error(`✗ ${e.message}`); process.exit(1)
    }
  }

  console.error(`commande inconnue: ${cmd}`)
  printUsage()
  process.exit(2)
}

function printUsage() {
  console.log(`ADA witness — anti-régression (SHA-256 + marker, zéro dépendance)

Usage:
  node witness.js verify                       vérifie l'arbre courant (exit 0 pass/drift | 1 regressed/missing)
  node witness.js regen                         recalcule les SHA baseline + snapshot historique
  node witness.js history [list|summary|regressions|timeline] [--id X] [--json]
  node witness.js add <id> <file> <marker> [desc]

Statuts:
  pass       marker présent + SHA == baseline
  drift      marker présent + SHA != baseline (toléré — 'regen' pour rebaser)
  regressed  marker absent (BLOQUE)
  missing    fichier introuvable (BLOQUE)`)
}
