#!/usr/bin/env node
// mark-summarized.js — Marque la session courante comme sauvegardée
// Appelé par /summarize pour désactiver les rappels du stop-hook

const { readFileSync, writeFileSync, existsSync, mkdirSync } = require('fs')
const { join, dirname } = require('path')

const CONFIG_DIR   = process.env.CLAUDE_CONFIG_DIR || join(process.env.HOME, '.claude')
const SESSION_FILE = join(CONFIG_DIR, 'session-state.json')

function ensureDir(p) { if (!existsSync(p)) mkdirSync(p, { recursive: true }) }

try {
  ensureDir(dirname(SESSION_FILE))
  let state = {}
  try { state = JSON.parse(readFileSync(SESSION_FILE, 'utf8')) } catch {}
  state.summarized = true
  state.lastSummarizedAt = new Date().toISOString()
  writeFileSync(SESSION_FILE, JSON.stringify(state, null, 2), 'utf8')
  console.log('[mark-summarized] Session marquée comme sauvegardée.')
  process.stdout.write('summarized=true\n')
} catch (e) {
  console.error('[mark-summarized] Erreur :', e.message)
}
process.exit(0)
