#!/usr/bin/env node
// memory-manager.js — PostToolUse hook (Write|Edit|MultiEdit)

const { readFileSync, writeFileSync, existsSync, mkdirSync, appendFileSync } = require('fs')
const { join, dirname, basename } = require('path')

const CONFIG_DIR = process.env.CLAUDE_CONFIG_DIR || join(process.env.HOME, '.claude')
const PROJECT_ID = process.env.AI_DEV_PROJECT || detectProjectFromCwd()

const MEMORY_DIR  = join(CONFIG_DIR, 'memory')
const GLOBAL_DIR  = join(MEMORY_DIR, 'global')
const PROJECT_DIR = join(MEMORY_DIR, 'projects', PROJECT_ID)
const LOG_FILE    = join(MEMORY_DIR, 'hook.log')

const COMPRESS_THRESHOLD = 150
const KEEP_RECENT        = 30

const SKIP_PATTERNS = [
  'memory/', 'hooks/', 'node_modules', '.git/',
  'dist/', 'build/', '__pycache__', '.next/', 'coverage/',
  'session-state.json', 'session-skill-cache.json',
]

function logError(msg) {
  try {
    appendFileSync(LOG_FILE, `[${new Date().toISOString()}] ERROR: ${msg}\n`)
  } catch {}
}

// Extensions sans valeur mémorielle — config/infra/lock
const SKIP_EXTENSIONS = new Set([
  '.json', '.lock', '.yaml', '.yml', '.toml', '.ini',
  '.env', '.log', '.tmp', '.bak', '.map',
  '.png', '.jpg', '.jpeg', '.gif', '.svg', '.ico', '.webp',
  '.woff', '.woff2', '.ttf', '.eot',
  '.zip', '.tar', '.gz',
])

// Exceptions : JSON qui méritent d'être mémorisés
const JSON_WHITELIST = ['package.json', 'tsconfig.json', 'prisma/schema.prisma']

function ensureDir(p) { if (!existsSync(p)) mkdirSync(p, { recursive: true }) }
function readFile(p, fallback = '') { return existsSync(p) ? readFileSync(p, 'utf8') : fallback }
function writeFile(p, text) { ensureDir(dirname(p)); writeFileSync(p, text, 'utf8') }
function now() { return new Date().toISOString().slice(0, 16).replace('T', ' ') }
function lineCount(text) { return text.split('\n').length }

function detectProjectFromCwd() {
  try {
    const cwd = process.cwd()
    const pkgPath = join(cwd, 'package.json')
    if (existsSync(pkgPath)) {
      const pkg = JSON.parse(readFileSync(pkgPath, 'utf8'))
      if (pkg.name) return pkg.name.replace(/[^a-z0-9-]/gi, '-').toLowerCase()
    }
    const pyPath = join(cwd, 'pyproject.toml')
    if (existsSync(pyPath)) {
      const match = readFileSync(pyPath, 'utf8').match(/^name\s*=\s*"([^"]+)"/m)
      if (match) return match[1].replace(/[^a-z0-9-]/gi, '-').toLowerCase()
    }
    return basename(cwd).replace(/[^a-z0-9-]/gi, '-').toLowerCase() || 'workspace'
  } catch { return 'workspace' }
}

function getWeekLabel() {
  const d = new Date(), year = d.getFullYear()
  const week = Math.ceil((((d - new Date(year, 0, 1)) / 86400000) + 1) / 7)
  return `${year}-W${String(week).padStart(2, '0')}`
}

function classify(content, filePath) {
  const c = content.toLowerCase(), f = filePath.toLowerCase()
  if (c.includes('decision:') || c.includes('adr:') || c.includes('on décide')) return 'decision'
  if (c.includes('fix:') || c.includes('bug:') || c.includes('hotfix') || f.includes('fix')) return 'bug_fix'
  if (c.includes('pattern:') || f.includes('utils') || f.includes('helpers')) return 'pattern'
  if (f.includes('migration') || f.includes('.sql') || c.includes('create table')) return 'db_change'
  return 'context_update'
}

function formatEntry(type, content, filePath) {
  const ts = now(), file = filePath ? ` \`${basename(filePath)}\`` : ''
  const snippet = content.slice(0, 400).replace(/\n{3,}/g, '\n\n').trim()
  switch (type) {
    case 'decision':  return `\n## [${ts}] Décision${file}\n${snippet}\n`
    case 'bug_fix':   return `\n### [${ts}] Fix${file}\n${snippet}\n`
    case 'pattern':   return `\n### [${ts}] Pattern${file}\n\`\`\`\n${snippet}\n\`\`\`\n`
    case 'db_change': return `\n### [${ts}] DB${file}\n${snippet}\n`
    default:          return `- \`${basename(filePath) || 'output'}\` — ${ts}\n`
  }
}

function compressIfNeeded(filePath) {
  const content = readFile(filePath)
  if (lineCount(content) < COMPRESS_THRESHOLD) return
  const lines = content.split('\n')
  const headerLines = [], entryLines = []
  let inHeader = true
  for (const line of lines) {
    if (inHeader && (line.startsWith('#') || line.startsWith('>') || line.startsWith('<!--') || !line.trim())) headerLines.push(line)
    else { inHeader = false; entryLines.push(line) }
  }
  const recentLines = entryLines.slice(-(KEEP_RECENT * 4))
  const oldLines    = entryLines.slice(0, -(KEEP_RECENT * 4))
  if (!oldLines.length) return
  const summary = oldLines.filter(l => l.trim()).filter(l => l.startsWith('##') || l.startsWith('- ')).slice(0, 25).join('\n')
  const week    = getWeekLabel()
  const archDir = join(dirname(filePath), 'archive')
  const archFile = join(archDir, `${week}.md`)
  ensureDir(archDir)
  writeFile(archFile, readFile(archFile, `# Archive — ${week}\n\n`) + `\n## From ${basename(filePath)} — ${now()}\n\n${summary}\n`)
  writeFile(filePath, headerLines.join('\n') + '\n\n> Archived → [' + week + '](archive/' + week + '.md)\n\n' + recentLines.join('\n'))
}

function initProjectContext() {
  const ctxPath = join(PROJECT_DIR, 'context.md')
  if (!existsSync(ctxPath)) {
    ensureDir(PROJECT_DIR)
    writeFile(ctxPath,
      `# Context — ${PROJECT_ID.toUpperCase()}\n\n` +
      `## Stack\n\n## Dernières modifications\n\n## Décisions récentes\n\n## Blockers actifs\n`
    )
  }
}

function run(raw) {
  let payload = {}
  try { payload = JSON.parse(raw) } catch { return }

  const { tool_input, tool_result } = payload
  const filePath = tool_input?.path || tool_input?.file_path || ''
  const content  = tool_input?.content || tool_input?.new_str || tool_result || ''

  if (!content || content.length < 80) return
  if (SKIP_PATTERNS.some(p => filePath.includes(p))) return

  // Filtre par extension — skip les fichiers sans valeur mémorielle
  if (filePath) {
    const ext = filePath.slice(filePath.lastIndexOf('.')).toLowerCase()
    const isSkippedExt = SKIP_EXTENSIONS.has(ext)
    const isWhitelisted = JSON_WHITELIST.some(w => filePath.endsWith(w))
    if (isSkippedExt && !isWhitelisted) return
  }

  ensureDir(GLOBAL_DIR)
  initProjectContext()

  const type  = classify(content, filePath)
  const entry = formatEntry(type, content, filePath)
  const ctxPath = join(PROJECT_DIR, 'context.md')

  if (type === 'decision') {
    const decPath = join(GLOBAL_DIR, 'decisions.md')
    writeFile(decPath, readFile(decPath) + entry)
    compressIfNeeded(decPath)
    const shortEntry = `- [${now()}] ${content.slice(0, 120).trim()}\n`
    writeFile(ctxPath, readFile(ctxPath).replace('## Décisions récentes\n', `## Décisions récentes\n${shortEntry}`))
  } else if (type === 'pattern') {
    const patPath = join(GLOBAL_DIR, 'patterns.md')
    writeFile(patPath, readFile(patPath) + entry)
    compressIfNeeded(patPath)
  } else if (type === 'bug_fix') {
    const errPath = join(GLOBAL_DIR, 'errors.md')
    writeFile(errPath, readFile(errPath) + entry)
    compressIfNeeded(errPath)
  } else {
    const section = '## Dernières modifications\n'
    const ctx = readFile(ctxPath)
    writeFile(ctxPath, ctx.includes(section) ? ctx.replace(section, section + entry) : ctx + `\n${section}${entry}`)
    compressIfNeeded(ctxPath)
  }
}

// Read stdin synchronously
let raw = ''
process.stdin.setEncoding('utf8')
process.stdin.on('data', chunk => { raw += chunk })
process.stdin.on('end', () => {
  try {
    run(raw)
  } catch (err) {
    logError(`${err.message}\n${err.stack}`)
  }
  process.exit(0)
})
process.stdin.on('error', () => process.exit(0))

// Safety timeout — never block Claude Code more than 3s
setTimeout(() => process.exit(0), 3000)
