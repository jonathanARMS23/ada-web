#!/usr/bin/env node
// notify.js — PostToolUse hook
// Déclenche une notification système quand une tâche longue se termine.
// Détecte la fin d'une slash command en observant l'écriture du fichier
// de résumé final (pattern : "## Feature:", "## Push staging", "✅", etc.)
//
// Compatible : macOS (osascript), Linux (notify-send), terminal bell (fallback)

const { execSync } = require('child_process')
const { join } = require('path')

// ─── Lire le payload stdin ────────────────────────────────────────────────────

// Lecture synchrone de stdin (fd 0) — compatible CJS (pas de top-level await).
let raw = ''
try { raw = require('fs').readFileSync(0, 'utf8') } catch { /* pas de stdin */ }

let payload = {}
try { payload = JSON.parse(raw) } catch { process.exit(0) }

const toolName  = payload.tool_name  || ''
const toolInput = payload.tool_input || {}
const content   = toolInput.content  || toolInput.new_str || ''
const filePath  = toolInput.path     || ''

// ─── Détecter la fin d'une tâche longue ──────────────────────────────────────
// On observe les patterns de résumé final des slash commands

const COMPLETION_PATTERNS = [
  // /feature — résumé final
  /^## Feature:.*—\s*Résumé/m,
  // /push-staging — succès
  /^## Push staging.*✅/m,
  // /deploy — succès
  /^## Deploy.*✅/m,
  // /test — rapport de coverage
  /Coverage\s*:\s*\d+(\.\d+)?%/,
  // /review — verdict final
  /^## Code Review.*—.*PR/m,
  // /summarize — résumé sauvegardé
  /Résumé de session sauvegardé\s*✅/,
  // /db-migrate — migration appliquée
  /Migration.*appliquée|Migration.*OK/i,
]

// Vérifier le contenu uniquement pour les outils d'écriture
if (!['Write', 'Edit', 'MultiEdit'].includes(toolName)) process.exit(0)
if (!content || content.length < 50) process.exit(0)

const matchedPattern = COMPLETION_PATTERNS.find(p => p.test(content))
if (!matchedPattern) process.exit(0)

// ─── Identifier le type de tâche ─────────────────────────────────────────────

function detectTaskType(content) {
  if (/## Feature:/m.test(content))        return { title: 'Feature terminée', emoji: '✅' }
  if (/Push staging.*✅/m.test(content))   return { title: 'Push staging OK',   emoji: '🚀' }
  if (/Deploy.*✅/m.test(content))         return { title: 'Déploiement OK',    emoji: '🚀' }
  if (/Coverage\s*:/m.test(content))       return { title: 'Tests terminés',    emoji: '🧪' }
  if (/Code Review/m.test(content))        return { title: 'Review terminée',   emoji: '🔍' }
  if (/session sauvegardé/m.test(content)) return { title: 'Session sauvegardée', emoji: '💾' }
  if (/Migration.*OK/im.test(content))     return { title: 'Migration appliquée', emoji: '🗄️' }
  return { title: 'Tâche terminée', emoji: '✅' }
}

const task    = detectTaskType(content)
const project = process.env.AI_DEV_PROJECT || 'AI Dev'
const title   = `${task.emoji} ${task.title}`
const message = `Projet : ${project}`

// ─── Envoyer la notification ──────────────────────────────────────────────────

notify(title, message)
process.exit(0)

function notify(title, message) {
  const platform = process.platform

  // macOS — osascript
  if (platform === 'darwin') {
    try {
      const escaped = (s) => s.replace(/"/g, '\\"')
      execSync(
        `osascript -e 'display notification "${escaped(message)}" with title "${escaped(title)}"'`,
        { stdio: 'ignore', timeout: 3000 }
      )
      return
    } catch { /* fallback */ }
  }

  // Linux — notify-send
  if (platform === 'linux') {
    try {
      execSync(`notify-send "${title}" "${message}" --urgency=normal --expire-time=5000`, {
        stdio: 'ignore',
        timeout: 3000,
      })
      return
    } catch { /* fallback */ }

    // Linux — zenity (GNOME)
    try {
      execSync(
        `zenity --notification --text="${title}: ${message}" 2>/dev/null`,
        { stdio: 'ignore', timeout: 3000 }
      )
      return
    } catch { /* fallback */ }
  }

  // Fallback universel — terminal bell + print visible
  // Le bell sera audible dans le terminal tmux
  try {
    process.stdout.write(`\x07`) // bell character
    process.stderr.write(`[notify] ${title} — ${message}\n`)
  } catch { /* ignore */ }
}
