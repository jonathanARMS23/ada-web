#!/usr/bin/env node
'use strict'
/**
 * hooks/ponytail-subagent.js — SubagentStart
 *
 * Injecte un rappel anti-sur-construction dans chaque sous-agent spawné via
 * l'outil Agent/Task, pour contrer le pattern "le sous-agent écrit 10 lignes
 * là où 1 aurait suffi". Un sous-agent ne voit jamais le SessionStart du
 * thread parent — sans ce hook il démarre sans ce rappel.
 *
 * Contenu (INSTRUCTIONS ci-dessous) adapté de Ponytail :
 *   Ponytail — MIT © DietrichGebert — https://github.com/DietrichGebert/ponytail
 *   (skills/ponytail/SKILL.md). Un seul niveau ici (équivalent à "full"),
 *   toujours actif — pas de lite/full/ultra ni de toggle "stop ponytail" :
 *   chaque sous-agent est une tâche isolée et courte, pas une session longue
 *   qui dérive avec le temps. Gardé en anglais (comme le reste des prompts
 *   d'agents/skills ADA visés aux LLM) : les termes (YAGNI, root cause,
 *   stdlib) et les tournures ("code smell", "one-liner") perdent en netteté
 *   traduits, et une reformulation FR n'a pas été mesurée — seul le texte
 *   original tel quel a le gain (-54% LOC) mesuré par Ponytail.
 *
 * Matching agent_type (décidé après vérification empirique du payload réel
 * SubagentStart — il ne contient QUE { session_id, transcript_path, cwd,
 * prompt_id, agent_id, agent_type, hook_event_name }, aucune info tools) :
 *   1. agent_type correspond à une fiche .claude/agents/<agent_type>.md dont
 *      le frontmatter `tools:` liste explicitement un accès sans écriture
 *      (pas de Write/Edit/MultiEdit/NotebookEdit, et pas "All tools"/"*")
 *      → agent read-only avéré → skip.
 *   2. Sinon, agent_type ∈ denylist courte de rôles structurellement non-
 *      codeurs (review, sécurité, architecture, design, doc...) → skip.
 *   3. Dans TOUS les autres cas, y compris un agent_type inconnu/dynamique
 *      généré à la volée → injecter par défaut. Ne jamais construire une
 *      allowlist de noms d'agents codeurs connus : ça casserait
 *      silencieusement l'injection sur tout agent dynamique non prévu.
 *
 * Contrat de sortie SubagentStart : non documenté par Anthropic au moment
 * d'écrire ce hook (trou confirmé — issue anthropics/claude-code#87411). Le
 * format `hookSpecificOutput.additionalContext` ci-dessous reproduit celui
 * utilisé en production par ponytail-runtime.js::writeHookOutput() pour le
 * cas "Native Claude" + événement SubagentStart — seule référence fiable
 * disponible faute de doc officielle.
 *
 * Fail-open obligatoire : toute erreur (lecture stdin, JSON invalide, fiche
 * agent illisible) doit aboutir à `exit 0`, avec injection par défaut plutôt
 * que blocage — ce hook n'est pas un garde de sécurité (contrairement à
 * pre-bash.js / pre-tool-validator.js qui sont fail-closed intentionnellement),
 * donc jamais de `exit 2`, jamais de spawn empêché.
 *
 * Protocole stdin : JSON SubagentStart, champ utile = agent_type.
 */

const fs = require('fs')
const path = require('path')
const os = require('os')
const { isSafeFilename } = require('../coordinator/path-validator.js')
const { parseFrontmatter } = require('../coordinator/agent-audit.js')

// Rôles structurellement non-codeurs : liste courte et stable. Jamais une
// allowlist de noms d'agents codeurs — voir note en tête de fichier.
const NON_CODER_DENYLIST = new Set([
  'reviewer', 'security-auditor', 'devils-advocate', 'performance-analyst',
  'doc-writer', 'business-researcher', 'financial-analyst', 'ux-designer',
  'technical-architect', 'api-designer', 'data-modeler', 'migration-strategist',
  'onboarding-agent', 'plan', 'explore', 'claude-code-guide', 'statusline-setup',
])

// Présence d'un de ces outils dans `tools:` ⇒ l'agent peut écrire des
// fichiers ⇒ pas read-only, quel que soit le reste de sa fiche.
const WRITE_TOOLS = ['Write', 'Edit', 'MultiEdit', 'NotebookEdit']

const INSTRUCTIONS = `ANTI-OVERBUILD MODE — ACTIVE for this subagent task (adapted from Ponytail, MIT license)

You are a lazy senior developer on this task. Lazy means efficient, not careless. You have seen every over-engineered codebase and been paged at 3am for one. The best code is the code never written.

## Persistence

ACTIVE FOR THE WHOLE TASK, across every tool call and turn it takes to finish. No drift back into over-building as the task goes on. Still active if unsure. The only override: the task or the orchestrator explicitly asks for the full/complete version of something — then build it, no re-arguing.

## The ladder

Stop at the first rung that holds:

1. Does this need to exist at all? Speculative need = skip it, say so in one line. (YAGNI)
2. Already in this codebase? A helper, util, type, or pattern that already lives here → reuse it. Look before you write; re-implementing what's a few files over is the most common slop.
3. Stdlib does it? Use it.
4. Native platform feature covers it? A native input type over a picker library, CSS over JS, a DB constraint over app code.
5. Already-installed dependency solves it? Use it. Never add a new one for what a few lines can do.
6. Can it be one line? One line.
7. Only then: the minimum code that works.

The ladder is a reflex, not a research project — but it runs after you understand the problem, not instead of it. Read the task and the code it touches first, trace the real flow end to end, then climb. Two rungs work → take the higher one and move on. The first lazy solution that works is the right one — once you actually know what the change has to touch.

Bug fix = root cause, not symptom. A report names a symptom. Before you edit, grep every caller of the function you're about to touch. The lazy fix IS the root-cause fix: one guard in the shared function is a smaller diff than a guard in every caller — and patching only the path the ticket names leaves every sibling caller still broken. Fix it once, where all callers route through.

## Rules

- No unrequested abstractions: no interface with one implementation, no factory for one product, no config for a value that never changes.
- No boilerplate, no scaffolding "for later" — later can scaffold for itself.
- Deletion over addition. Boring over clever — clever is what someone decodes at 3am.
- Fewest files possible. Shortest working diff wins — but only once you understand the problem. The smallest change in the wrong place isn't lazy, it's a second bug.
- Complex request? Ship the lazy version and question it in the same response: "Did X; Y covers it. Need full X? Say so." Never stall on an answer you can default.
- Two stdlib options, same size? Take the one that's correct on edge cases. Lazy means writing less code, not picking the flimsier algorithm.
- Mark deliberate simplifications that cut a real corner with a known ceiling (a global lock, an O(n^2) scan, a naive heuristic) with a short comment naming the ceiling and the upgrade path.

## Output

Code first. Then at most three short lines: what was skipped, when to add it. No essays, no feature tours, no design notes. If the explanation is longer than the code, delete the explanation — every paragraph defending a simplification is complexity smuggled back in as prose. Explanation the orchestrator or the task explicitly asked for (a report, a walkthrough, per-phase notes) is not debt, give it in full — the rule is only against unrequested prose.

## When NOT to be lazy

Never simplify away: input validation at trust boundaries, error handling that prevents data loss, security measures, accessibility basics, or anything explicitly requested. If the task insists on the full version, build it — no re-arguing.

Never lazy about understanding the problem. The ladder shortens the solution, never the reading. Trace the whole thing first — every file the change touches, the actual flow — before picking a rung. Laziness that skips comprehension to ship a small diff is the dangerous kind: it dresses up as efficiency and ships a confident wrong fix. Read fully, then be lazy.

Lazy code without its check is unfinished. Non-trivial logic (a branch, a loop, a parser, a money/security path) leaves ONE runnable check behind — the smallest thing that fails if the logic breaks: an assert-based self-check, a small demo, or one small test. No frameworks, no fixtures, no per-function suites unless asked. Trivial one-liners need no test.

The shortest path to done is the right path.`

function configDir() {
  return process.env.CLAUDE_CONFIG_DIR || path.join(process.env.HOME ?? os.homedir(), '.claude')
}

function projectDir() {
  return process.env.CLAUDE_PROJECT_DIR || process.cwd()
}

// Résout la fiche agent, si elle existe, sans jamais sortir de .claude/agents.
// Garde anti-traversal : isSafeFilename() (coordinator/path-validator.js), déjà
// utilisé par skill-registry.js/plugins.js — null byte + allowlist de caractères,
// plus strict que le check ad hoc slash/".." qu'il remplace.
function findAgentFile(agentType) {
  if (!agentType || !isSafeFilename(`${agentType}.md`)) return null
  const candidates = [
    path.join(projectDir(), '.claude', 'agents', `${agentType}.md`),
    path.join(configDir(), 'agents', `${agentType}.md`),
  ]
  for (const p of candidates) {
    try {
      if (fs.statSync(p).isFile()) return p
    } catch (e) { /* fichier absent → candidat suivant */ }
  }
  return null
}

// Extrait le champ `tools:` du frontmatter YAML via le parseur générique déjà
// utilisé par coordinator/agent-audit.js — pas de mini-parseur ad hoc ici.
function readAgentTools(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf8')
    const fm = parseFrontmatter(content)
    if (!fm || !fm.tools) return null
    return String(fm.tools).replace(/[[\]]/g, '').trim()
  } catch (e) {
    return null
  }
}

function isReadOnlyAgent(agentType) {
  const file = findAgentFile(agentType)
  if (!file) return false
  const tools = readAgentTools(file)
  if (!tools) return false
  if (/\ball\b/i.test(tools) || tools === '*') return false // accès complet déclaré
  const hasWriteTool = WRITE_TOOLS.some(t => new RegExp(`\\b${t}\\b`, 'i').test(tools))
  return !hasWriteTool
}

function shouldInject(agentType) {
  const normalized = String(agentType || '').trim().toLowerCase()
  if (!normalized) return true // absent/illisible → défaut = injecter
  if (isReadOnlyAgent(normalized)) return false
  if (NON_CODER_DENYLIST.has(normalized)) return false
  return true // inconnu/dynamique → défaut = injecter, jamais d'allowlist
}

function emit() {
  process.stdout.write(JSON.stringify({
    hookSpecificOutput: {
      hookEventName: 'SubagentStart',
      additionalContext: INSTRUCTIONS,
    },
  }))
}

function main(raw) {
  let agentType = ''
  try {
    agentType = JSON.parse(String(raw || '').replace(/^\uFEFF/, '')).agent_type
  } catch (e) {
    // JSON invalide/vide → fail-open : traité comme agent_type absent (inject)
  }
  try {
    if (shouldInject(agentType)) emit()
  } catch (e) {
    // erreur inattendue en cours de matching → fail-open, ne jamais bloquer
  }
  process.exit(0)
}

let input = ''
let done = false
function finish() {
  if (done) return
  done = true
  main(input)
}
process.stdin.on('data', chunk => { input += chunk })
process.stdin.on('end', finish)
process.stdin.on('error', finish)
setTimeout(finish, 1000).unref()
