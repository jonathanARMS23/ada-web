#!/usr/bin/env node
/**
 * hooks/post-bash.js — PostToolUse(Bash)
 *
 * Rôle :
 *  1. Détecte les événements significatifs (git, tests, migrations, deploy)
 *  2. Met à jour les logs de mémoire projet
 *  3. Dispatch des workers en background selon l'événement
 *
 * Workers déclenchés :
 *  - testgaps   → après un test run avec failures
 *  - audit      → après git commit sur fichiers backend
 *  - ultralearn → après git push (apprentissage post-session)
 *
 * Protocole : stdin JSON { tool_name, tool_input, tool_result }
 * Pas de décision à prendre — PostToolUse est informatif uniquement.
 */

const { appendFileSync, existsSync, mkdirSync, readdirSync, readFileSync, writeFileSync } = require('fs')
const { join, dirname, basename } = require('path')
const { spawn } = require('child_process')
const crypto = require('crypto')
const os = require('os')

const CONFIG_DIR  = process.env.CLAUDE_CONFIG_DIR || join(process.env.HOME ?? os.homedir(), '.claude')
const PROJECT_ID  = process.env.AI_DEV_PROJECT || detectProjectFromCwd()
const LOGS_DIR    = join(CONFIG_DIR, 'logs')
const MEMORY_DIR  = join(CONFIG_DIR, 'memory')
const PROJECT_DIR = join(MEMORY_DIR, 'projects', PROJECT_ID)
const WORKERS_DIR = join(CONFIG_DIR, 'workers')

function ensureDir(p) { if (!existsSync(p)) mkdirSync(p, { recursive: true }) }
function now()  { return new Date().toISOString().slice(0, 16).replace('T', ' ') }
function ts()   { return new Date().toISOString() }
function readFile(p, fallback = '') { return existsSync(p) ? readFileSync(p, 'utf8') : fallback }
function appendLog(file, line) {
  ensureDir(dirname(file))
  try { appendFileSync(file, line) } catch {}
}

function detectProjectFromCwd() {
  try {
    const cwd = process.cwd()
    const pkg = join(cwd, 'package.json')
    if (existsSync(pkg)) {
      const name = JSON.parse(readFileSync(pkg, 'utf8')).name
      if (name) return name.replace(/[^a-z0-9-]/gi, '-').toLowerCase()
    }
    return basename(cwd).replace(/[^a-z0-9-]/gi, '-').toLowerCase() || 'workspace'
  } catch { return 'workspace' }
}

// ── Dispatch worker en background ─────────────────────────────────────────────

function dispatchWorker(name, args = []) {
  const workerPath = join(WORKERS_DIR, `${name}.js`)
  if (!existsSync(workerPath)) return

  const child = spawn('node', [workerPath, ...args], {
    detached: true,
    stdio:    'ignore',
    env:      { ...process.env, CLAUDE_CONFIG_DIR: CONFIG_DIR, AI_DEV_PROJECT: PROJECT_ID }
  })
  child.unref()

  appendLog(
    join(LOGS_DIR, 'workers.log'),
    `${ts()} dispatch ${name} ${args.join(' ')}\n`
  )
}

// ── Détecteurs d'événements ───────────────────────────────────────────────────

function detectEvent(cmd, output) {
  const c = cmd.toLowerCase()
  const o = (output || '').toLowerCase()

  // Git commit
  if (/^git\s+commit/.test(c)) {
    const sha   = (output || '').match(/\[[\w-]+ ([a-f0-9]{7})\]/)?.[1] || 'unknown'
    const msg   = cmd.match(/-m\s+["']?([^"']+)["']?/)?.[1]?.trim() || 'no message'
    return { type: 'git-commit', sha, msg }
  }

  // Git push
  if (/^git\s+push/.test(c)) {
    const branch = cmd.match(/origin\s+([\w/-]+)/)?.[1] || 'unknown'
    return { type: 'git-push', branch }
  }

  // Test run — JS/TS
  if (/vitest|jest|npm\s+(?:run\s+)?test/.test(c)) {
    const passed  = (output || '').match(/(\d+)\s+(?:test[s]?\s+)?passed/i)?.[1]
    const failed  = (output || '').match(/(\d+)\s+(?:test[s]?\s+)?failed/i)?.[1]
    const coverage= (output || '').match(/(?:all files|statements)[^\d]*(\d+(?:\.\d+)?)%/i)?.[1]
    return { type: 'test-js', passed: parseInt(passed)||0, failed: parseInt(failed)||0, coverage }
  }

  // Test run — Python
  if (/pytest|python\s+-m\s+pytest/.test(c)) {
    const passed = (output || '').match(/(\d+)\s+passed/i)?.[1]
    const failed = (output || '').match(/(\d+)\s+failed/i)?.[1]
    const errors = (output || '').match(/(\d+)\s+error/i)?.[1]
    return { type: 'test-py', passed: parseInt(passed)||0, failed: parseInt(failed)||0, errors: parseInt(errors)||0 }
  }

  // Migration DB
  if (/prisma\s+migrate|supabase.*migrate|psql.*migration|alembic\s+upgrade/.test(c)) {
    return { type: 'db-migration', cmd }
  }

  // Docker build
  if (/^docker\s+build/.test(c)) {
    const success = o.includes('successfully built') || o.includes('successfully tagged')
    return { type: 'docker-build', success }
  }

  // Build TypeScript
  if (/^(?:npm\s+run\s+build|tsc\b)/.test(c)) {
    const errors = (output || '').match(/(\d+)\s+error/)?.[1]
    return { type: 'ts-build', errors: parseInt(errors)||0 }
  }

  // Installation de dépendances (déclenche cve-scan)
  if (/^npm\s+(?:install|ci|i\b)|pip\s+install|uv\s+(?:add|sync)/.test(c)) {
    return { type: 'dep-install' }
  }

  return null
}

// ── Handlers par type d'événement ────────────────────────────────────────────

function handleGitCommit({ sha, msg }) {
  appendLog(
    join(PROJECT_DIR, 'git-log.md'),
    `- [${now()}] ${sha} — ${msg}\n`
  )
  // Déclencher audit léger après chaque commit
  dispatchWorker('audit', ['--quick'])
}

function handleGitPush({ branch }) {
  appendLog(
    join(LOGS_DIR, 'git-push.log'),
    `${ts()} pushed to ${branch} [project: ${PROJECT_ID}]\n`
  )
  // Apprentissage post-push
  dispatchWorker('ultralearn', [PROJECT_ID])
}

function handleTestResults({ type, passed, failed, coverage, errors }) {
  const isFailure = failed > 0 || errors > 0
  const status    = isFailure ? 'FAIL' : 'PASS'
  const covStr    = coverage ? ` | coverage: ${coverage}%` : ''
  const line      = `${now()} [${status}] ${passed} passed, ${failed} failed${errors ? `, ${errors} errors` : ''}${covStr} [${type}]\n`

  appendLog(join(PROJECT_DIR, 'test-results.log'), line)

  // Mettre à jour context.md avec le dernier résultat de test
  const ctxPath = join(PROJECT_DIR, 'context.md')
  const ctx     = readFile(ctxPath)
  const testLine = `- Tests : ${status} — ${passed}✓ ${failed}✗${covStr} — ${now()}`
  const updated = ctx.includes('## Tests')
    ? ctx.replace(/- Tests : .+\n/, testLine + '\n')
    : ctx + `\n## Tests\n${testLine}\n`
  try { ensureDir(dirname(ctxPath)); writeFileSync(ctxPath, updated) } catch {}

  // Dispatcher testgaps si des tests échouent
  if (isFailure) dispatchWorker('testgaps', [PROJECT_ID, String(failed)])
}

function handleDbMigration({ cmd }) {
  appendLog(
    join(PROJECT_DIR, 'migrations.log'),
    `${now()} migration appliquée : ${cmd.slice(0, 100)}\n`
  )
}

function handleDockerBuild({ success }) {
  appendLog(
    join(LOGS_DIR, 'docker-builds.log'),
    `${now()} [${success ? 'OK' : 'FAIL'}] project: ${PROJECT_ID}\n`
  )
}

function handleTsBuild({ errors }) {
  if (errors > 0) {
    appendLog(
      join(PROJECT_DIR, 'build-errors.log'),
      `${now()} TypeScript: ${errors} erreurs de compilation\n`
    )
  }
}

function handleDepInstall() {
  // CVE scan en background après chaque install (cache 24h activé)
  dispatchWorker('cve-scan', ['--quick'])
}

// ── Plugin system ─────────────────────────────────────────────────────────────

const PLUGINS_DIR    = join(CONFIG_DIR, 'plugins')
const PLUGINS_LOG    = join(LOGS_DIR, 'plugins.log')
const MAX_PLUGINS    = 10

function loadPluginWorkers(event) {
  try {
    if (!existsSync(PLUGINS_DIR)) return
    const entries = readdirSync(PLUGINS_DIR, { withFileTypes: true })
      .filter(d => d.isDirectory())
      .slice(0, MAX_PLUGINS)

    const deadline = Date.now() + 5000

    for (const entry of entries) {
      if (Date.now() > deadline) break
      try {
        const pluginDir  = join(PLUGINS_DIR, entry.name)
        const manifestPath = join(pluginDir, 'manifest.json')
        if (!existsSync(manifestPath)) continue

        const manifestContent = readFileSync(manifestPath)
        let manifest
        try { manifest = JSON.parse(manifestContent.toString('utf8')) } catch { continue }

        if (!Array.isArray(manifest.hooks) || !manifest.hooks.includes(event.type)) continue

        // Verify signature before spawning worker — unsigned plugins are skipped
        if (!manifest.signature) {
          process.stderr.write(`SKIP unsigned plugin: ${entry.name}\n`)
          continue
        }
        {
          const keySource = manifest.signKey
          if (!keySource || !keySource.startsWith('env:')) continue
          const key = process.env[keySource.slice(4)]
          if (!key) continue
          const colonIdx = manifest.signature.indexOf(':')
          if (colonIdx === -1) continue
          const algo     = manifest.signature.slice(0, colonIdx)
          const sigValue = manifest.signature.slice(colonIdx + 1)
          let verified = false
          if (algo === 'hmac-sha256') {
            const actualBuf = Buffer.from(crypto.createHmac('sha256', key).update(manifestContent).digest('hex'), 'hex')
            const sigBuf    = Buffer.from(sigValue, 'hex')
            verified = actualBuf.length === sigBuf.length && crypto.timingSafeEqual(actualBuf, sigBuf)
          } else if (algo === 'ed25519') {
            try {
              const pubKey = crypto.createPublicKey(key)
              verified = crypto.verify(null, manifestContent, pubKey, Buffer.from(sigValue, 'base64'))
            } catch {}
          }
          if (!verified) {
            process.stderr.write(`SKIP plugin invalid signature: ${entry.name}\n`)
            continue
          }

        }

        const workerPath = join(pluginDir, 'worker.js')
        if (!existsSync(workerPath)) continue

        // Verify worker.js integrity via workerHash in manifest
        if (manifest && manifest.workerHash) {
          const actualWorkerHash = crypto.createHash('sha256').update(readFileSync(workerPath)).digest('hex')
          if (actualWorkerHash !== manifest.workerHash) {
            process.stderr.write(`SKIP plugin worker.js tampered: ${entry.name}\n`)
            continue
          }
        } else if (manifest) {
          process.stderr.write(`WARN plugin missing workerHash (manifest-only signature): ${entry.name}\n`)
        }

        const child = spawn('node', [workerPath], {
          detached: true,
          stdio:    'ignore',
          env:      {
            ...process.env,
            CLAUDE_CONFIG_DIR: CONFIG_DIR,
            AI_DEV_PROJECT:    PROJECT_ID,
            PLUGIN_EVENT:      event.type,
            PLUGIN_DATA:       JSON.stringify(event)
          }
        })
        child.unref()

        appendLog(PLUGINS_LOG, `${ts()} dispatch plugin:${manifest.name} event:${event.type}\n`)
      } catch {}
    }
  } catch {}
}

// ── Main ──────────────────────────────────────────────────────────────────────

let raw = ''
process.stdin.setEncoding('utf8')
process.stdin.on('data', chunk => { raw += chunk })
process.stdin.on('end', () => {
  try {
    const payload = JSON.parse(raw)
    const cmd     = payload?.tool_input?.command || ''
    const output  = payload?.tool_result || ''

    if (!cmd) { process.exit(0) }

    ensureDir(PROJECT_DIR)

    const event = detectEvent(cmd, output)
    if (!event) { process.exit(0) }

    switch (event.type) {
      case 'git-commit':    handleGitCommit(event);    break
      case 'git-push':      handleGitPush(event);      break
      case 'test-js':
      case 'test-py':       handleTestResults(event);  break
      case 'db-migration':  handleDbMigration(event);  break
      case 'docker-build':  handleDockerBuild(event);  break
      case 'ts-build':      handleTsBuild(event);      break
      case 'dep-install':   handleDepInstall();        break
    }

    loadPluginWorkers(event)
  } catch (e) {
    try { appendFileSync(join(LOGS_DIR, 'post-bash-errors.log'), `${ts()} ERROR: ${e?.message}\n`) } catch {}
  }
  process.exit(0)
})

process.stdin.on('error', () => process.exit(0))
setTimeout(() => process.exit(0), 3000)

if (require.main !== module) {
  module.exports = { detectEvent, handleGitCommit, handleTestResults, handleDbMigration }
}
