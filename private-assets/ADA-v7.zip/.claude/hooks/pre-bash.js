#!/usr/bin/env node
/**
 * hooks/pre-bash.js — PreToolUse(Bash)
 *
 * Rôle :
 *  1. Garde de sécurité étendu (patterns dangereux non couverts par la deny list)
 *  2. Log de chaque commande dans logs/commands.log
 *  3. Blocage avec raison structurée (retour JSON {"decision":"block","reason":"..."})
 *
 * Protocole Claude Code PreToolUse :
 *  - stdin  : JSON { tool_name, tool_input: { command } }
 *  - stdout : JSON { hookSpecificOutput: { permissionDecision: "deny", ... } }
 *  - exit 0 : traitement normal (deny selon JSON, sinon flux de permission normal)
 *  - exit 2 : blocage dur (utilisé pour les erreurs internes — fail-closed)
 *
 * FAIL-CLOSED : toute erreur interne (lexer indisponible, payload illisible,
 * exception, timeout du watchdog) BLOQUE la commande. Un hook cassé ne doit
 * jamais dégrader silencieusement en « tout autoriser ».
 *
 * Note : on n'émet JAMAIS permissionDecision:"allow" — cela court-circuiterait
 * l'allowlist de settings.json et auto-approuverait toute commande. Le chemin
 * « OK » se contente de sortir 0 sans décision, laissant le flux de permission
 * normal (allow/deny/ask de settings.json) s'appliquer.
 */

/**
 * @typedef {{ pattern: RegExp, reason: string, suggestion?: string }} BlockRule
 * @typedef {{ pattern: RegExp, message: string }} WarnRule
 * @typedef {{ action: 'block'|'warn'|'allow', reason?: string, warnings?: string[] }} Decision
 */

const { appendFileSync, existsSync, mkdirSync, readdirSync, readFileSync, realpathSync } = require('fs')
const { join, dirname, sep } = require('path')
const crypto = require('crypto')
const os = require('os')

// Chargement fail-closed du lexer : s'il est absent/cassé, on ne peut plus
// analyser les segments composés → on bloque au lieu de laisser passer.
/** @type {((cmd: string) => { segments: string[], substitutions: string[] })|null} */
let analyzeCommand = null
/** @type {((segment: string) => string[])|null} */
let tokenizeWords = null
/** @type {((arg: string, danger: Set<string>, valueTaking: Set<string>) => boolean)|null} */
let matchesDangerousFlag = null
/** @type {((cmd: string) => string[][])|null} */
let extractCommands = null
/** @type {string|null} */
let lexerLoadError = null
try {
  const lexer = require(join(__dirname, '..', 'coordinator', 'shell-lexer.js'))
  if (typeof lexer?.analyzeCommand !== 'function') throw new Error('analyzeCommand absent du module shell-lexer')
  if (typeof lexer?.tokenizeWords !== 'function') throw new Error('tokenizeWords absent du module shell-lexer')
  analyzeCommand = lexer.analyzeCommand
  tokenizeWords  = lexer.tokenizeWords
  const executor = require(join(__dirname, '..', 'coordinator', 'safe-executor.js'))
  if (typeof executor?.matchesDangerousFlag !== 'function') throw new Error('matchesDangerousFlag absent du module safe-executor')
  matchesDangerousFlag = executor.matchesDangerousFlag
  // Couche AST (round 4) — vrai parseur shell. Chargée dans le MÊME try
  // fail-closed : si elle manque (dépendance `mvdan-sh` non installée), le hook
  // bloque au lieu de retomber silencieusement sur la seule couche regex.
  const ast = require(join(__dirname, '..', 'coordinator', 'shell-ast.js'))
  if (typeof ast?.extractCommands !== 'function') throw new Error('extractCommands absent du module shell-ast')
  extractCommands = ast.extractCommands
} catch (e) {
  lexerLoadError = e?.message || String(e)
}

const CONFIG_DIR = process.env.CLAUDE_CONFIG_DIR || join(process.env.HOME ?? os.homedir(), '.claude')
const LOGS_DIR   = join(CONFIG_DIR, 'logs')
const CMD_LOG    = join(LOGS_DIR, 'commands.log')

// ── F7 — formes équivalentes d'un flag dangereux ──────────────────────────────
// Un flag d'exécution inline s'écrit de plusieurs façons, toutes équivalentes
// pour l'interpréteur mais pas pour une regex naïve :
//   isolée  : node -e code          groupée : node -pe code / python3 -Bc code
//   avec =  : node --eval=code      collée  : python3 -cCODE / perl -eCODE
//   décalée : node -r fs -e code    (un flag AVEC SA VALEUR intercalé)
// Vérifié : node refuse la forme collée (`-eCODE`) mais accepte la forme
// groupée (`-pe`) ; python et perl acceptent les deux. On bloque toutes les
// formes pour tous les interpréteurs (défense en profondeur : le comportement
// varie selon l'interpréteur et sa version).

// Suite de flags intercalés entre le binaire et le flag dangereux.
//
// F7-followup — le scan s'arrête au PREMIER jeton non-flag : c'est le chemin du
// script, et tout ce qui suit appartient au script, pas à l'interpréteur
// (`node app.js -p 3000` passe `-p` au script). L'ancienne forme
// `(?:[^-\s]\S*\s+)?` avalait n'importe quel jeton non-flag, donc aussi ce
// chemin — elle refusait des commandes légitimes.
// Seul un flag CONNU pour consommer une valeur (`node -r fs -e code`) autorise
// à sauter le jeton suivant.
// Plafond assumé : un flag à valeur absent de VALUE_FLAG fait prendre sa valeur
// pour le chemin du script → scan arrêté un cran trop tôt. Correction =
// ajouter le flag dans la liste.
//
// ReDoS : le jeton de flag est `-\S*` (une seule façon de le découper) et non
// `--?[\w.-]+` — cette dernière forme est ambiguë (le `-` appartient aussi à la
// classe, donc `--flag` se découpe de 2 façons), ce qui rend la boucle `*`
// exponentielle et fait expirer le watchdog sur une commande longue.
const VALUE_FLAG  = String.raw`(?:--require|--import|--loader|--experimental-loader|--conditions|--env-file|-r|-I|-M|-m|-W|-X|-Q)`
const FLAG_PREFIX = String.raw`(?:${VALUE_FLAG}\s+[^-\s]\S*\s+|-\S*\s+)*`

// Lettres de flags BOOLÉENS pouvant précéder le flag dangereux dans un groupe
// collé. Volontairement restreint aux flags sans valeur : inclure une lettre
// qui consomme une valeur (`node -r module`, `perl -I dir`) ferait matcher les
// lettres de cette valeur (`-rpreload.js` contient un « p »).
// NB : node/deno/bun et perl/ruby/php sont désormais détectés sur le TABLEAU de
// mots (voir INLINE_INTERP/detectInlineExec, RC4) — plus par regex sur chaîne,
// donc leurs classes de flags booléens (NODE_BOOL, PERL_BOOL) ont disparu.
const PY_BOOL   = '[BEOsSuvxqbdIiRt0-9]'
const SH_BOOL   = '[exuvilnmaBbfkpt]'

// ── RC4 — détection d'exécution inline par interpréteur, sur le TABLEAU de mots ─
// Le déquotage réaplati en chaîne perd la POSITION DE COMMANDE : `grep "node" -e
// motif` devient `grep node -e motif` et une regex `node\s+-e` matchait à tort
// (faux positifs : grep/find/docker/echo…). On examine donc `words[0]` comme nom
// de commande (après les préfixes VAR=val), puis on scanne les flags suivants
// avec la MÊME logique que safe-executor (matchesDangerousFlag), en s'arrêtant
// au chemin du script — exactement comme l'interpréteur lit son argv.
const INLINE_INTERP = {
  node: { danger: new Set(['-e', '--eval', '-p', '--print']), short: new Set(['e', 'p', 'r']),
          sep: new Set(['-r', '--require', '--import', '--loader', '--experimental-loader', '--conditions', '--env-file']) },
  deno: { danger: new Set(['-e', '--eval', '-p', '--print']), short: new Set(['e', 'p']), sep: new Set() },
  bun:  { danger: new Set(['-e', '--eval', '-p', '--print']), short: new Set(['e', 'p']), sep: new Set() },
  // perl `-E` == `-e` + features modernes : même exécution inline (ex-RC5).
  perl: { danger: new Set(['-e', '-E']), short: new Set(['e', 'E']), sep: new Set() },
  ruby: { danger: new Set(['-e']), short: new Set(['e']), sep: new Set() },
  php:  { danger: new Set(['-r', '-e']), short: new Set(['r', 'e']), sep: new Set() },
}

// Interpréteurs dont l'exécution inline passe par une SOUS-COMMANDE et non par
// un flag : `deno eval <code>`, `bun eval <code>` (ex-RC5).
const EVAL_SUBCOMMAND = { deno: 'eval', bun: 'eval' }

/** Basename d'un mot (dépouille le chemin : `/usr/bin/node` → `node`). */
function baseName(w) { return (String(w).split('/').pop() || w).split('\\').pop() || String(w) }

/**
 * Détecte une invocation d'interpréteur avec flag d'exécution inline, sur un
 * tableau de mots déquotés (un segment ou une substitution). Renvoie la raison
 * de blocage ou null.
 * @param {string[]} words
 * @returns {string|null}
 */
function detectInlineExec(words) {
  if (!Array.isArray(words) || words.length === 0) return null
  let start = 0
  while (start < words.length && /^[A-Za-z_][A-Za-z0-9_]*=/.test(words[start])) start++ // préfixes FOO=bar
  // Wrapper `env` : `env [opts] [NAME=val]… <cmd> …` lance <cmd>. L'interpréteur
  // réel suit env — sans ce saut, `env node -e` (et `/usr/bin/env node -e`)
  // passait, alors que node reçoit bien `-e`.
  while (start < words.length && baseName(words[start]) === 'env') {
    start++
    while (start < words.length) {
      const w = words[start]
      if (w === '-u' || w === '--unset') { start += 2; continue } // -u NAME (valeur séparée)
      if (w.startsWith('-')) { start++; continue }                // -i, --split-string, -C dir=…, etc.
      if (/^[A-Za-z_][A-Za-z0-9_]*=/.test(w)) { start++; continue } // affectation d'env
      break
    }
  }
  if (start >= words.length) return null
  const cmd = baseName(words[start])

  // Sous-commande d'évaluation (`deno eval …`) : le premier argument non-flag.
  const evalSub = EVAL_SUBCOMMAND[cmd]
  if (evalSub) {
    for (let i = start + 1; i < words.length; i++) {
      if (typeof words[i] !== 'string' || words[i].startsWith('-')) continue
      if (words[i] === evalSub) {
        return `Exécution de code inline (${cmd} ${evalSub}) interdite — écrire un script versionné`
      }
      break // première sous-commande non-flag : ce n'est pas `eval`
    }
  }

  const spec = INLINE_INTERP[cmd]
  if (!spec) return null
  for (let i = start + 1; i < words.length; i++) {
    const arg = words[i]
    if (typeof arg !== 'string') continue
    if (!arg.startsWith('-')) break // premier non-flag = chemin du script → le reste lui appartient
    if (matchesDangerousFlag(arg, spec.danger, spec.short)) {
      return `Exécution de code inline (${cmd} -e/--eval/-p, y compris les formes groupée/collée/quotée) interdite — écrire un script versionné`
    }
    if (spec.sep.has(arg)) i++ // ce flag consomme le jeton suivant (sa valeur)
  }
  return null
}

// ── Fichiers protégés — DÉFINITION UNIQUE ─────────────────────────────────────
// Écraser `settings.json` ou un `hooks/*.js` désarme toute la couche de
// sécurité (allowlist permissive réinstallée, hooks neutralisés). Cette source
// unique est partagée par :
//   - la règle de redirection/`sed -i` (BLOCK_RULES, plus bas)
//   - la règle d'écriture par outil (detectProtectedCopy : cp/mv/install/ln/
//     tee/dd/rsync)
// Ne PAS en dériver une seconde liste : les deux chemins doivent protéger
// exactement le même ensemble de fichiers.
const PROTECTED_FILE = String.raw`(?:settings(?:\.local)?\.json|hooks\/[\w.-]*\.js)`
const PROTECTED_FILE_RE = new RegExp(PROTECTED_FILE)

// ── Écriture d'un fichier protégé sans redirection ───────────────────────────
// `cp`, `mv`, `install`, `ln`, `tee`, `dd` et `rsync` écrivent un fichier SANS
// passer par `>`/`>>` : la règle de BLOCK_RULES, qui raisonne sur l'OPÉRATEUR
// de redirection (et `sed -i`), ne les voit pas. `cp piege.json
// .claude/settings.json` désarmait donc toute la sécurité en session normale.
// Cette règle raisonne au contraire sur la CIBLE d'écriture, quel que soit
// l'outil — ce qui ferme au passage le gap `tee`/`dd` relevé mais laissé ouvert
// au round 3.
//
// Friction ZÉRO dans le cas courant : si aucun opérande ne désigne un fichier
// protégé, la fonction rend null et le hook ne prend AUCUNE décision (le flux
// de permission habituel s'applique, `Bash(cp *)` continue d'auto-approuver).
// Seule une cible protégée déclenche un refus — voir `requireHumanEdit` pour
// pourquoi c'est un `deny` et non un `ask`.
//
// `mv` est le seul pour lequel la SOURCE compte aussi : déplacer
// `.claude/hooks/pre-bash.js` ailleurs neutralise le hook aussi sûrement que
// l'écraser. Pour `cp`/`install`/`ln`, seule la destination est destructrice
// (lire un fichier protégé est inoffensif).
//
// Plafond assumé : les opérandes sont pris littéralement (pas de résolution de
// chemin ni de symlink) — `cp x .claude/../.claude/settings.json` passe. La
// règle vise l'écrasement direct, pas l'obfuscation de chemin, qui relève d'une
// normalisation de chemin à part entière.
const COPY_CMDS = new Set(['cp', 'mv', 'install', 'ln', 'tee', 'dd', 'rsync'])
const COPY_TARGET_FLAG = new Set(['-t', '--target-directory'])

/**
 * Détecte une copie/déplacement/écriture touchant un fichier protégé.
 * @param {string[]} argv argv RÉSOLU (wrappers déjà sautés) d'une commande
 * @returns {string|null} le chemin protégé concerné, ou null
 */
function detectProtectedCopy(argv) {
  if (!Array.isArray(argv) || argv.length < 2) return null
  const cmd = baseName(argv[0])
  if (!COPY_CMDS.has(cmd)) return null

  // `tee FICHIER…` : TOUS les opérandes sont des cibles d'écriture.
  if (cmd === 'tee') {
    return argv.slice(1).find(a => typeof a === 'string' && !a.startsWith('-') && PROTECTED_FILE_RE.test(a)) || null
  }
  // `dd of=FICHIER` : la cible est portée par l'option `of=`.
  if (cmd === 'dd') {
    const of = argv.slice(1).map(a => /^of=([\s\S]*)$/.exec(String(a))).find(Boolean)
    return of && PROTECTED_FILE_RE.test(of[1]) ? of[1] : null
  }

  /** @type {string[]} */
  const operands = []
  let targetDir = null
  for (let i = 1; i < argv.length; i++) {
    const a = argv[i]
    if (typeof a !== 'string') continue
    if (a === '--') {
      for (const rest of argv.slice(i + 1)) if (typeof rest === 'string') operands.push(rest)
      break
    }
    if (COPY_TARGET_FLAG.has(a)) { targetDir = argv[i + 1] ?? null; i++; continue }
    const eq = /^--target-directory=(.*)$/.exec(a)
    if (eq) { targetDir = eq[1]; continue }
    if (a.length > 1 && a.startsWith('-')) continue   // option
    operands.push(a)
  }

  const dest    = targetDir ?? (operands.length >= 2 ? operands[operands.length - 1] : null)
  const sources = targetDir ? operands : operands.slice(0, -1)

  /** @type {string[]} */
  const checked = []
  if (dest) checked.push(dest)
  if (cmd === 'mv') checked.push(...sources)
  // Destination RÉPERTOIRE : `cp evil.js .claude/hooks/` écrit bien un fichier
  // protégé alors que l'opérande de destination n'est qu'un dossier. Restreint
  // aux formes non ambiguës (barre finale, ou dernier composant `hooks`) pour
  // ne pas transformer `cp settings.json /tmp/x` en faux positif.
  if (dest && (/\/$/.test(dest) || baseName(dest) === 'hooks')) {
    const base = dest.replace(/\/+$/, '')
    for (const s of sources) checked.push(`${base}/${baseName(s)}`)
  }

  return checked.find(p => PROTECTED_FILE_RE.test(p)) || null
}

// ── Patterns bloquants (en plus de la deny list settings.json) ────────────────

const BLOCK_RULES = [
  {
    pattern: /rm\s+-rf\s+(?!.*\.tmp)(?!.*node_modules)(?!.*\.cache)(?!.*dist\/)/,
    reason: 'rm -rf sur un chemin non temporaire — utiliser une suppression ciblée'
  },
  {
    pattern: /git\s+push\s+.*--force(?!.*staging)/,
    reason: 'git push --force interdit sauf sur staging — risque de perte de commits'
  },
  {
    pattern: />\s*(?:~\/|\/etc\/|\/usr\/)/,
    reason: 'Redirection vers un chemin système critique interdite'
  },
  {
    pattern: /curl\s+.*\|\s*(?:bash|sh|node|python)/,
    reason: 'Pipe curl vers interpréteur — risque d\'exécution de code distant non vérifié'
  },
  {
    pattern: /chmod\s+(?:777|a\+x)\s+(?!.*\.sh$)/,
    reason: 'chmod 777 sur un fichier non-script — permissions trop larges'
  },
  {
    pattern: /DROP\s+(?:TABLE|DATABASE|SCHEMA)\s+(?!.*_test|.*_dev)/i,
    reason: 'DROP en dehors des environnements de test — action irréversible'
  },
  {
    pattern: /truncate\s+table\s+(?!.*_test|.*_dev)/i,
    reason: 'TRUNCATE en dehors des environnements de test — action irréversible'
  },
  {
    pattern: /export\s+(?:AWS_SECRET|DATABASE_URL|API_KEY|SECRET_KEY|PRIVATE_KEY)\s*=/,
    reason: 'Export de secret dans l\'environnement shell — utiliser .env'
  },
  // ── Auto-protection de la config de sécurité ────────────────────────────────
  // Sans cette règle, `echo ... > .claude/settings.json` ou `sed -i` suffit à
  // réinstaller une allowlist permissive ou à neutraliser ces hooks.
  // PROTECTED_FILE (défini plus haut) est la définition UNIQUE de « fichier
  // protégé » — la règle cp/mv/install/ln la réutilise telle quelle.
  {
    pattern: new RegExp(String.raw`(?:>>?\s*|(?:sed|perl|ruby)\s+(?:-\w+\s+)*-i(?:\.\w+)?\s|--in-place[=\s])[^|;&]*${PROTECTED_FILE}`),
    reason: 'Écriture directe dans la configuration de permissions/hooks interdite — utiliser l\'outil Edit (revue humaine)'
  },
  {
    pattern: /(?:>>?\s*|(?:sed|perl|ruby)\s+(?:-\w+\s+)*-i(?:\.\w+)?\s|--in-place[=\s])[^|;&]*(?:\.zshrc|\.zshenv|\.zprofile|\.bashrc|\.bash_profile|\.profile\b|authorized_keys|crontab)/,
    reason: 'Écriture dans un fichier de démarrage shell / clé SSH — vecteur de persistance'
  },
  // ── Exécution de code inline (RCE) ──────────────────────────────────────────
  // node/deno/bun -e/--eval/-p, perl/ruby -e et php -r/-e sont détectés sur le
  // TABLEAU de mots (detectInlineExec, RC4) et non plus ici : la regex sur
  // chaîne déquotée réaplatie produisait des faux positifs (`grep "node" -e`,
  // `find -name node`, `docker run "node" -e`). Les règles ci-dessous restent
  // en regex car elles dépendent du CONTENU (python -c / sh -c) ou d'un chemin.
  {
    // L'allowlist n'autorise `node` que sur des préfixes de chemins projet
    // (coordinator/, .claude/coordinator/, run.js). Un `..` permettrait de
    // sortir de ce préfixe tout en le satisfaisant littéralement.
    // NB : le préfixe utilise FLAG_PREFIX (jeton `-\S*`, non ambigu). La forme
    // précédente `(?:--?[\w-]+(?:=\S+)?\s+)*` était exponentielle — une
    // commande de ~200 caractères (`node --a=b --a=b …`) faisait expirer le
    // watchdog de 5 s, donc bloquait une commande légitime (fail-closed).
    pattern: new RegExp(String.raw`\bnode\s+${FLAG_PREFIX}[^\s;|&]*\.\.\/`),
    reason: 'Chemin remontant (..) dans une invocation node — contourne la restriction de l\'allowlist aux scripts du projet'
  },
  {
    // python -c est toléré pour l'inspection (json, print) mais pas avec des
    // primitives d'exécution / réseau / écriture.
    pattern: new RegExp(String.raw`\bpython[0-9.]*\s+${FLAG_PREFIX}-${PY_BOOL}*c[^\n]*(?:os\.system|os\.popen|os\.exec|subprocess|__import__|\beval\s*\(|\bexec\s*\(|socket|urllib|requests\.|shutil|pty\.|open\s*\([^)]*['"][wa])`),
    reason: 'python -c avec primitive d\'exécution/réseau/écriture — interdit, écrire un script versionné'
  },
  {
    pattern: new RegExp(String.raw`\b(?:ba|z|k)?sh\s+${FLAG_PREFIX}-${SH_BOOL}*c[^\n]*(?:curl|wget|nc\b|netcat|base64\s+(?:-d|--decode)|\/dev\/tcp)`),
    reason: 'sh -c combiné à un téléchargement/décodage — pattern d\'exécution de payload distant'
  },
  {
    pattern: /(?:curl|wget)\b[^|;&]*\|\s*(?:[a-z]*sh|node|python[0-9.]*|perl|ruby|php)\b/,
    reason: 'Téléchargement piped vers un interpréteur — exécution de code distant interdite'
  }
]

// ── Patterns à surveiller (log warning, ne pas bloquer) ──────────────────────

const WARN_PATTERNS = [
  { pattern: /git\s+commit\s+.*--no-verify/,       label: 'git-no-verify' },
  { pattern: /npm\s+install\s+--ignore-scripts/,   label: 'npm-no-scripts' },
  { pattern: /--skip-tests?/,                       label: 'skip-tests' },
  // npx/dlx télécharge et exécute un paquet arbitraire. Non bloqué (le
  // scaffolding /saas-init en a besoin) mais retiré de l'allowlist → prompt.
  { pattern: /\b(?:npx|bunx|(?:pnpm|yarn)\s+dlx)\b/,  label: 'remote-package-exec' },
  { pattern: /force.*push|push.*force/,             label: 'force-push-attempt' },
  { pattern: /production/i,                         label: 'production-context' }
]

// ── AI Defence — détection d'injection et PII ─────────────────────────────────

const AI_DEFENCE_RULES = [
  // Prompt injection patterns
  { pattern: /ignore\s+(?:previous|all|above)\s+instructions?/i,         type: 'prompt-injection', severity: 'high' },
  { pattern: /(?:system|assistant)\s*:\s*(?:you are|act as|pretend)/i,   type: 'prompt-injection', severity: 'high' },
  { pattern: /jailbreak|DAN\s+mode|do\s+anything\s+now/i,               type: 'prompt-injection', severity: 'high' },
  { pattern: /\[\[INST\]\]|\[\/INST\]|<\|im_start\|>/i,                 type: 'prompt-injection', severity: 'medium' },
  // PII detection
  { pattern: /\b\d{3}-\d{2}-\d{4}\b/,                                   type: 'pii-ssn',      severity: 'high' },
  { pattern: /\b(?:\d[ -]?){13,16}\b/,                                   type: 'pii-card',     severity: 'high' },
  { pattern: /\bpassword\s*[:=]\s*\S{8,}/i,                             type: 'pii-password', severity: 'medium' },
  { pattern: /\btoken\s*[:=]\s*[A-Za-z0-9_\-\.]{20,}/i,               type: 'pii-token',    severity: 'medium' },
  // Command injection
  { pattern: /;\s*(?:wget|curl)\s+http/i,                                type: 'cmd-injection', severity: 'high' },
  { pattern: /\$\(.*(?:curl|wget|nc|netcat)/i,                          type: 'cmd-injection', severity: 'high' },
]

/**
 * Analyse une commande pour détecter des patterns AI Defence.
 * @param {string} input
 * @returns {{ type: string, severity: string }[]}
 */
function runAiDefence(input) {
  const matches = []
  for (const rule of AI_DEFENCE_RULES) {
    if (rule.pattern.test(input)) {
      matches.push({ type: rule.type, severity: rule.severity })
    }
  }
  return matches
}

// ── Catégorisation de la commande ─────────────────────────────────────────────

function categorize(cmd) {
  if (/^git\s+commit/.test(cmd))               return 'git-commit'
  if (/^git\s+push/.test(cmd))                 return 'git-push'
  if (/^git\s+merge/.test(cmd))                return 'git-merge'
  if (/npm\s+(?:run\s+)?test|vitest|jest/.test(cmd)) return 'test-run'
  if (/pytest|python\s+-m\s+pytest/.test(cmd)) return 'test-run-python'
  if (/^docker\s+build/.test(cmd))             return 'docker-build'
  if (/supabase|psql|prisma\s+migrate/.test(cmd)) return 'db-operation'
  if (/^node\s+.*coordinator\/run\.js/.test(cmd)) return 'coordinator'
  if (/^npm\s+run\s+build|tsc\s+/.test(cmd))  return 'build'
  return 'general'
}

function ensureDir(p) { if (!existsSync(p)) mkdirSync(p, { recursive: true }) }

// ── Plugin hook system ────────────────────────────────────────────────────────

const PLUGINS_DIR   = join(CONFIG_DIR, 'plugins')
const MAX_HOOK_PLUGINS = 5

/** @param {string} cmd @returns {Decision|null} */
function loadPluginHooks(cmd) {
  if (!existsSync(PLUGINS_DIR)) return null
  try {
    const entries = readdirSync(PLUGINS_DIR, { withFileTypes: true })
      .filter(d => d.isDirectory())
      .slice(0, MAX_HOOK_PLUGINS)

    const deadline = Date.now() + 1000
    const extraWarnings = []

    for (const entry of entries) {
      if (Date.now() > deadline) break
      try {
        const hookPath = join(PLUGINS_DIR, entry.name, 'hook.js')
        if (!existsSync(hookPath)) continue

        // Jail : résoudre les symlinks et vérifier que les fichiers restent dans PLUGINS_DIR
        let realHookPath, realManifestPath, realPluginsDir
        try {
          realPluginsDir  = realpathSync(PLUGINS_DIR)
          realHookPath    = realpathSync(hookPath)
          realManifestPath = realpathSync(join(PLUGINS_DIR, entry.name, 'manifest.json'))
        } catch {
          process.stderr.write(`SKIP plugin symlink non résolvable: ${entry.name}\n`)
          continue
        }
        if (!realHookPath.startsWith(realPluginsDir + sep)) {
          process.stderr.write(`SKIP plugin symlink escape (hook.js): ${entry.name}\n`)
          continue
        }
        if (!realManifestPath.startsWith(realPluginsDir + sep)) {
          process.stderr.write(`SKIP plugin symlink escape (manifest.json): ${entry.name}\n`)
          continue
        }

        // Verify plugin signature before loading — unsigned plugins are skipped
        const manifestPath = join(PLUGINS_DIR, entry.name, 'manifest.json')
        if (!existsSync(manifestPath)) {
          process.stderr.write(`SKIP unsigned plugin: ${entry.name}\n`)
          continue
        }
        try {
          const manifest = JSON.parse(readFileSync(manifestPath, 'utf8'))
          if (!manifest.signature) {
            process.stderr.write(`SKIP unsigned plugin: ${entry.name}\n`)
            continue
          }
          const keySource = manifest.signKey
          if (!keySource || !keySource.startsWith('env:')) continue
          const envVarName = keySource.slice(4)
          const key = process.env[envVarName]
          if (!key) {
            process.stderr.write(`[pre-bash] Plugin "${entry.name}" ignoré — variable env "${envVarName}" non définie\n`)
            continue
          }
          const manifestContent = readFileSync(manifestPath)
          const colonIdx = manifest.signature.indexOf(':')
          if (colonIdx === -1) continue
          const algo     = manifest.signature.slice(0, colonIdx)
          const sigValue = manifest.signature.slice(colonIdx + 1)
          let verified = false
          if (algo === 'hmac-sha256') {
            const actualBuf = Buffer.from(crypto.createHmac('sha256', key).update(manifestContent).digest('hex'), 'hex')
            const sigBuf    = Buffer.from(sigValue, 'hex')
            verified = actualBuf.length === sigBuf.length && crypto.timingSafeEqual(actualBuf, sigBuf)
          } else if (algo === 'ed25519') {
            try {
              const pubKey = crypto.createPublicKey(key)
              verified = crypto.verify(null, manifestContent, pubKey, Buffer.from(sigValue, 'base64'))
            } catch {}
          }
          if (!verified) {
            process.stderr.write(`SKIP plugin invalid signature: ${entry.name}\n`)
            continue
          }

          // Verify hook.js integrity via hookHash in manifest (sha256 of hook.js content)
          if (manifest.hookHash) {
            const actualHookHash = crypto.createHash('sha256').update(readFileSync(hookPath)).digest('hex')
            if (actualHookHash !== manifest.hookHash) {
              process.stderr.write(`SKIP plugin hook.js tampered: ${entry.name}\n`)
              continue
            }
          } else {
            process.stderr.write(`WARN plugin missing hookHash (manifest-only signature): ${entry.name}\n`)
          }
        } catch { continue }

        const hookFn = require(hookPath)
        if (typeof hookFn !== 'function' && typeof hookFn.check !== 'function') continue

        const check = typeof hookFn === 'function' ? hookFn : hookFn.check
        const result = check(cmd)
        if (!result) continue

        if (result.block) return { action: 'block', reason: result.reason }
        if (result.warn)  extraWarnings.push(result.reason)
      } catch {}
    }

    return extraWarnings.length > 0 ? { action: 'warn', warnings: extraWarnings } : null
  } catch {
    return null
  }
}

function logCommand(cmd, category, blocked, warning) {
  ensureDir(LOGS_DIR)
  const ts    = new Date().toISOString().slice(0, 19).replace('T', ' ')
  const flags = [blocked ? 'BLOCKED' : null, warning ? `WARN:${warning}` : null].filter(Boolean).join(' ')
  const line  = `${ts} [${category.padEnd(20)}] ${flags ? `[${flags}] ` : ''}${cmd.slice(0, 200)}\n`
  try { appendFileSync(CMD_LOG, line) } catch {}
}

/**
 * Aucune décision : on laisse le flux de permission normal de Claude Code
 * s'appliquer (allowlist/denylist de settings.json). On n'émet JAMAIS
 * permissionDecision:"allow" — cela auto-approuverait toute commande.
 * @param {string} cmd @param {string} category @param {string|null|undefined} warning @returns {void}
 */
function pass(cmd, category, warning) {
  logCommand(cmd, category, false, warning)
  process.stdout.write(JSON.stringify({ suppressOutput: true }))
  process.exit(0)
}

/** @param {string} cmd @param {string} category @param {string} reason @returns {void} */
function block(cmd, category, reason) {
  logCommand(cmd, category, true, null)
  process.stdout.write(JSON.stringify({
    hookSpecificOutput: {
      hookEventName: 'PreToolUse',
      permissionDecision: 'deny',
      permissionDecisionReason: reason
    }
  }))
  process.exit(0)
}

/**
 * Exige une validation humaine explicite pour une cible sensible.
 *
 * POURQUOI `deny` ET PAS `ask` — le protocole ne permet pas la nuance.
 * L'intention était de rendre la main à l'humain (« confirme ») plutôt que de
 * refuser. La documentation PreToolUse de Claude Code (2026) ne documente que
 * `permissionDecision: "allow"` et `"deny"` — `"ask"` n'y figure pas (vérifié
 * sur deux pages de la doc officielle). Émettre une valeur non reconnue est le
 * PIRE choix ici : si Claude Code ignore le `hookSpecificOutput`, la commande
 * retombe sur `permissions.allow`, où `Bash(cp *)` l'auto-approuve — donc
 * AUCUNE protection. On préfère un refus certain à une confirmation
 * hypothétique, et le message indique la marche à suivre.
 *
 * Mesuré : un `deny` de hook l'emporte bien sur une entrée de `permissions.allow`
 * (le hook s'exécute AVANT le flux de permission — vérifié en session réelle),
 * d'où le choix de LAISSER `Bash(cp *)`/`Bash(mv *)` dans l'allowlist : l'usage
 * courant reste sans friction, seule la cible sensible est arrêtée.
 * @param {string} cmd @param {string} category @param {string} reason @returns {void}
 */
function requireHumanEdit(cmd, category, reason) {
  logCommand(cmd, category, true, 'protected-target')
  process.stdout.write(JSON.stringify({
    hookSpecificOutput: {
      hookEventName: 'PreToolUse',
      permissionDecision: 'deny',
      permissionDecisionReason: reason
    }
  }))
  process.exit(0)
}

/**
 * FAIL-CLOSED — erreur interne du hook : on bloque.
 * Double garantie : JSON deny sur stdout + message sur stderr + exit 2
 * (exit 2 = blocage dur PreToolUse, indépendant du parsing du stdout).
 * @param {string} detail @returns {void}
 */
function failClosed(detail) {
  const reason = `[Sécurité] Hook de validation en échec — commande bloquée par précaution (fail-closed).\nDétail : ${detail}`
  try { logCommand('<hook-error>', 'hook-failure', true, null) } catch {}
  try {
    process.stdout.write(JSON.stringify({
      hookSpecificOutput: {
        hookEventName: 'PreToolUse',
        permissionDecision: 'deny',
        permissionDecisionReason: reason
      }
    }))
  } catch {}
  try { process.stderr.write(`${reason}\n`) } catch {}
  process.exit(2)
}

// ── Main ──────────────────────────────────────────────────────────────────────
// Exécuté uniquement quand le fichier est lancé comme hook (`node pre-bash.js`).
// Sans cette garde, un simple `require()` (tests, outillage) enregistrerait les
// listeners stdin + le watchdog dans le process appelant et le tuerait via
// process.exit(2) au moment du fail-closed.

let raw = ''
let decided = false

if (require.main === module) {

// Toute exception non capturée doit bloquer, jamais laisser passer.
process.on('uncaughtException',  e => failClosed(`exception non capturée: ${e?.message || e}`))
process.on('unhandledRejection', e => failClosed(`rejet non géré: ${e?.message || e}`))

process.stdin.setEncoding('utf8')
process.stdin.on('data', chunk => { raw += chunk })
process.stdin.on('end', () => {
  try {
    if (decided) return
    if (lexerLoadError) { decided = true; failClosed(`shell-lexer indisponible (${lexerLoadError}) — analyse des segments composés impossible`); return }

    /** @type {any} */
    let payload
    try { payload = JSON.parse(raw) }
    catch (e) { decided = true; failClosed(`payload PreToolUse illisible: ${e?.message || e}`); return }

    // Hook câblé sur matcher "Bash" : un autre outil ne devrait pas arriver ici.
    const toolName = payload?.tool_name || ''
    if (toolName && toolName !== 'Bash') { decided = true; process.stdout.write(JSON.stringify({ suppressOutput: true })); process.exit(0); return }

    const cmd = payload?.tool_input?.command || ''
    if (!cmd) { decided = true; process.stdout.write(JSON.stringify({ suppressOutput: true })); process.exit(0); return }

    const category = categorize(cmd)

    // Cibles d'analyse : chaîne brute (défense en profondeur — 1re passe) +
    // chaque segment hors-quotes + le contenu de chaque substitution. Ceci ferme
    // le trou où une commande dangereuse cachée après &&/;/|/&/newline ou dans
    // une $()/backtick passait car le motif ne matchait que le début de la chaîne.
    //
    // + la vue DÉQUOTÉE de chacun (tokenizeWords) : le shell retire les
    // guillemets AVANT que l'interpréteur ne voie ses flags, donc `node "-e" x`
    // exécute bien du code inline alors qu'aucune règle ancrée sur la frontière
    // du flag (`\s+-e`) ne matchait la chaîne brute. Les deux vues sont
    // conservées : le déquotage ferme le contournement, la vue brute garde les
    // motifs qui dépendent des guillemets (ex. `open(...,'w')` en python -c).
    //
    // Si le lexer échoue sur cette commande, on ne dispose pas de la vue
    // segmentée → fail-closed plutôt que de n'analyser que la chaîne brute.
    // RC3 — l'extraction des substitutions est RÉCURSIVE : `$(…)` (ou backtick)
    // imbriqué re-analyse son contenu jusqu'à point fixe. Sans ça, une commande
    // dangereuse à la profondeur ≥ 2 (`echo $(echo $(node "-e" x))`) disparaît
    // de toutes les vues, car tokenizeWords SUPPRIME les expansions non quotées.
    // Fail-closed au-delà de MAX_DEPTH (cohérent avec la politique du hook).
    const MAX_DEPTH = 8
    let targets, wordArrays
    try {
      const rawParts = []   // segments + substitutions (chaînes brutes)
      const wordLists = []  // tokenizeWords de chaque segment/substitution
      let frontier = [cmd]
      let depth = 0
      while (frontier.length) {
        if (depth++ > MAX_DEPTH) {
          decided = true
          failClosed(`profondeur de substitution > ${MAX_DEPTH} — analyse abandonnée (fail-closed)`)
          return
        }
        const nextFrontier = []
        for (const piece of frontier) {
          const a = analyzeCommand(piece)
          for (const seg of (a?.segments || [])) { rawParts.push(seg); wordLists.push(tokenizeWords(seg)) }
          for (const sub of (a?.substitutions || [])) { rawParts.push(sub); nextFrontier.push(sub) }
        }
        frontier = nextFrontier
      }
      targets = [cmd, ...rawParts, ...wordLists.map(w => w.join(' '))]
      wordArrays = wordLists
    } catch (e) {
      decided = true
      failClosed(`analyse lexicale de la commande impossible: ${e?.message || e}`)
      return
    }

    // Vérifier les règles de blocage sur chaque cible
    for (const rule of BLOCK_RULES) {
      if (targets.some(t => rule.pattern.test(t))) {
        decided = true
        block(cmd, category, `[Sécurité] ${rule.reason}\nCommande : ${cmd.slice(0, 150)}`)
        return
      }
    }

    // ── Passe 1 (round 4) — COUCHE AST ────────────────────────────────────────
    // `shell-ast.extractCommands` rend l'argv RÉSOLU de chaque commande
    // réellement exécutée : wrappers (`nice`, `sudo`, `xargs`, `timeout`…)
    // sautés, groupements/blocs/substitutions traversés par le parseur, et code
    // de `sh -c`/`eval` ré-analysé comme une ligne à part entière. C'est cette
    // vue — et non `words[0]` d'un découpage maison — qui donne la vraie
    // position de commande.
    // Fail-closed : une ligne que le parseur refuse n'est pas analysable.
    /** @type {string[][]} */
    let astCommands
    try {
      astCommands = extractCommands(cmd)
    } catch (e) {
      decided = true
      failClosed(`analyse AST de la commande impossible: ${e?.message || e}`)
      return
    }

    for (const argv of astCommands) {
      const reason = detectInlineExec(argv)
      if (reason) {
        decided = true
        block(cmd, category, `[Sécurité] ${reason}\nCommande : ${cmd.slice(0, 150)}`)
        return
      }
    }

    // Écriture/déplacement d'un fichier protégé : exige une validation humaine
    // (refus + marche à suivre). Placé APRÈS les règles de blocage dur, pour
    // qu'une commande par ailleurs dangereuse soit refusée pour SA raison.
    for (const argv of astCommands) {
      const target = detectProtectedCopy(argv)
      if (target) {
        decided = true
        requireHumanEdit(cmd, category,
          `[Sécurité] Cette commande ${baseName(argv[0])} écrit ou déplace un fichier de configuration de sécurité (${target}).\n`
          + 'Écraser ou déplacer settings.json / hooks/*.js désarme les protections d\'ADA.\n'
          + 'Si le changement est voulu : utiliser l\'outil Edit (revue humaine du diff), ou demander explicitement à l\'utilisateur de le faire à la main.\n'
          + `Commande : ${cmd.slice(0, 150)}`)
        return
      }
    }

    // ── Passe 2 — COUCHE HISTORIQUE (défense en profondeur) ───────────────────
    // Détection RC4 sur le découpage maison (shell-lexer). Conservée
    // DÉLIBÉRÉMENT en plus de la couche AST : les deux passes sont indépendantes
    // et le verdict est un OU logique. C'est la suppression de cette couche au
    // round 2 qui avait causé la pire régression du chantier ; elle reste aussi
    // le filet si `mvdan-sh` venait à mal parser une forme exotique.
    for (const words of wordArrays) {
      const reason = detectInlineExec(words)
      if (reason) {
        decided = true
        block(cmd, category, `[Sécurité] ${reason}\nCommande : ${cmd.slice(0, 150)}`)
        return
      }
    }

    // ── AI Defence ────────────────────────────────────────────────────────────
    const aiMatches = runAiDefence(cmd)
    if (aiMatches.length > 0) {
      // Sévérité high : cmd-injection et pii-* → bloquer
      // prompt-injection → warn seulement (faux positifs possibles dans les commandes légitimes)
      const highBlocking = aiMatches.find(m => m.severity === 'high' && m.type !== 'prompt-injection')
      if (highBlocking) {
        decided = true
        block(cmd, category, `[AI Defence] ${highBlocking.type}\nCommande : ${cmd.slice(0, 150)}`)
        return
      }
    }

    // Règles additionnelles depuis les plugins
    const pluginDecision = loadPluginHooks(cmd)
    if (pluginDecision?.action === 'block') {
      decided = true
      block(cmd, category, `[Plugin] ${pluginDecision.reason}`)
      return
    }

    // Vérifier les patterns de warning (WARN_PATTERNS + AI Defence medium/prompt-injection)
    const pluginWarning = pluginDecision?.warnings?.join(', ') || null
    const stdWarning    = WARN_PATTERNS.find(w => w.pattern.test(cmd))?.label || null

    let aiWarning = null
    if (aiMatches.length > 0) {
      // prompt-injection (any severity) → warn
      // pii-*/cmd-injection medium → warn
      const warnMatch = aiMatches.find(m =>
        m.type === 'prompt-injection' || m.severity === 'medium'
      )
      if (warnMatch) aiWarning = `ai-defence:${warnMatch.type}`
    }

    const warning = stdWarning || aiWarning || pluginWarning

    decided = true
    pass(cmd, category, warning)
  } catch (e) {
    // FAIL-CLOSED : si le hook plante, on bloque (une garde de sécurité muette
    // est pire que pas de garde du tout).
    if (!decided) { decided = true; failClosed(`erreur interne: ${e?.message || e}`) }
  }
})

process.stdin.on('error', e => {
  if (!decided) { decided = true; failClosed(`lecture stdin impossible: ${e?.message || e}`) }
})

// Watchdog : au-delà de 5 s on bloque (ne jamais dégrader en « autoriser »).
// Aligné sous le `timeout` déclaré dans settings.json pour que ce chemin
// fail-closed s'exécute avant que Claude Code ne tue le hook.
setTimeout(() => {
  if (!decided) { decided = true; failClosed('watchdog 5 s — analyse non terminée') }
}, 5000)

// Garde ultime : si la boucle d'événements se vide sans qu'aucune décision
// n'ait été prise (stdin fermé sans 'end', etc.), sortir en 2 plutôt qu'en 0.
process.on('exit', code => { if (!decided && code === 0) process.exitCode = 2 })

} // fin de `require.main === module`

// Export pour les tests unitaires (aucun effet de bord à l'import).
module.exports = { BLOCK_RULES, WARN_PATTERNS, AI_DEFENCE_RULES, runAiDefence, categorize }
