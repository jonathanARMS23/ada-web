#!/usr/bin/env node
/**
 * hooks/pre-bash.js — PreToolUse(Bash)
 *
 * Rôle :
 *  1. Garde de sécurité étendu (patterns dangereux non couverts par la deny list)
 *  2. Log de chaque commande dans logs/commands.log
 *  3. Blocage avec raison structurée (retour JSON {"decision":"block","reason":"..."})
 *
 * Protocole Claude Code PreToolUse :
 *  - stdin  : JSON { tool_name, tool_input: { command } }
 *  - stdout : JSON { hookSpecificOutput: { permissionDecision: "deny", ... } }
 *  - exit 0 : traitement normal (deny selon JSON, sinon flux de permission normal)
 *  - exit 2 : blocage dur (utilisé pour les erreurs internes — fail-closed)
 *
 * FAIL-CLOSED : toute erreur interne (lexer indisponible, payload illisible,
 * exception, timeout du watchdog) BLOQUE la commande. Un hook cassé ne doit
 * jamais dégrader silencieusement en « tout autoriser ».
 *
 * Note : on n'émet JAMAIS permissionDecision:"allow" — cela court-circuiterait
 * l'allowlist de settings.json et auto-approuverait toute commande. Le chemin
 * « OK » se contente de sortir 0 sans décision, laissant le flux de permission
 * normal (allow/deny/ask de settings.json) s'appliquer.
 */

/**
 * @typedef {{ pattern: RegExp, reason: string, suggestion?: string }} BlockRule
 * @typedef {{ pattern: RegExp, message: string }} WarnRule
 * @typedef {{ action: 'block'|'warn'|'allow', reason?: string, warnings?: string[] }} Decision
 */

const { appendFileSync, existsSync, mkdirSync, readdirSync, readFileSync, realpathSync } = require('fs')
const { join, dirname, sep } = require('path')
const crypto = require('crypto')
const os = require('os')

// Chargement fail-closed du lexer : s'il est absent/cassé, on ne peut plus
// analyser les segments composés → on bloque au lieu de laisser passer.
/** @type {((cmd: string) => { segments: string[], substitutions: string[] })|null} */
let analyzeCommand = null
/** @type {string|null} */
let lexerLoadError = null
try {
  const lexer = require(join(__dirname, '..', 'coordinator', 'shell-lexer.js'))
  if (typeof lexer?.analyzeCommand !== 'function') throw new Error('analyzeCommand absent du module shell-lexer')
  analyzeCommand = lexer.analyzeCommand
} catch (e) {
  lexerLoadError = e?.message || String(e)
}

const CONFIG_DIR = process.env.CLAUDE_CONFIG_DIR || join(process.env.HOME ?? os.homedir(), '.claude')
const LOGS_DIR   = join(CONFIG_DIR, 'logs')
const CMD_LOG    = join(LOGS_DIR, 'commands.log')

// ── Patterns bloquants (en plus de la deny list settings.json) ────────────────

const BLOCK_RULES = [
  {
    pattern: /rm\s+-rf\s+(?!.*\.tmp)(?!.*node_modules)(?!.*\.cache)(?!.*dist\/)/,
    reason: 'rm -rf sur un chemin non temporaire — utiliser une suppression ciblée'
  },
  {
    pattern: /git\s+push\s+.*--force(?!.*staging)/,
    reason: 'git push --force interdit sauf sur staging — risque de perte de commits'
  },
  {
    pattern: />\s*(?:~\/|\/etc\/|\/usr\/)/,
    reason: 'Redirection vers un chemin système critique interdite'
  },
  {
    pattern: /curl\s+.*\|\s*(?:bash|sh|node|python)/,
    reason: 'Pipe curl vers interpréteur — risque d\'exécution de code distant non vérifié'
  },
  {
    pattern: /chmod\s+(?:777|a\+x)\s+(?!.*\.sh$)/,
    reason: 'chmod 777 sur un fichier non-script — permissions trop larges'
  },
  {
    pattern: /DROP\s+(?:TABLE|DATABASE|SCHEMA)\s+(?!.*_test|.*_dev)/i,
    reason: 'DROP en dehors des environnements de test — action irréversible'
  },
  {
    pattern: /truncate\s+table\s+(?!.*_test|.*_dev)/i,
    reason: 'TRUNCATE en dehors des environnements de test — action irréversible'
  },
  {
    pattern: /export\s+(?:AWS_SECRET|DATABASE_URL|API_KEY|SECRET_KEY|PRIVATE_KEY)\s*=/,
    reason: 'Export de secret dans l\'environnement shell — utiliser .env'
  },
  // ── Auto-protection de la config de sécurité ────────────────────────────────
  // Sans cette règle, `echo ... > .claude/settings.json` ou `sed -i` suffit à
  // réinstaller une allowlist permissive ou à neutraliser ces hooks.
  {
    pattern: /(?:>>?\s*|(?:sed|perl|ruby)\s+(?:-\w+\s+)*-i(?:\.\w+)?\s|--in-place[=\s])[^|;&]*(?:settings(?:\.local)?\.json|hooks\/[\w.-]*\.js)/,
    reason: 'Écriture directe dans la configuration de permissions/hooks interdite — utiliser l\'outil Edit (revue humaine)'
  },
  {
    pattern: /(?:>>?\s*|(?:sed|perl|ruby)\s+(?:-\w+\s+)*-i(?:\.\w+)?\s|--in-place[=\s])[^|;&]*(?:\.zshrc|\.zshenv|\.zprofile|\.bashrc|\.bash_profile|\.profile\b|authorized_keys|crontab)/,
    reason: 'Écriture dans un fichier de démarrage shell / clé SSH — vecteur de persistance'
  },
  // ── Exécution de code inline (RCE) ──────────────────────────────────────────
  {
    pattern: /\b(?:node|deno|bun)\s+(?:-\w*\s+)*(?:-e|--eval|-p|--print)\b/,
    reason: 'Exécution de code inline (node -e/--eval/-p) interdite — écrire un script versionné'
  },
  {
    pattern: /\b(?:perl|ruby|php)\s+(?:-\w+\s+)*-e\b/,
    reason: 'Exécution de code inline (interpréteur -e) interdite — écrire un script versionné'
  },
  {
    // L'allowlist n'autorise `node` que sur des préfixes de chemins projet
    // (coordinator/, .claude/coordinator/, run.js). Un `..` permettrait de
    // sortir de ce préfixe tout en le satisfaisant littéralement.
    pattern: /\bnode\s+(?:--?[\w-]+(?:=\S+)?\s+)*[^\s;|&]*\.\.\//,
    reason: 'Chemin remontant (..) dans une invocation node — contourne la restriction de l\'allowlist aux scripts du projet'
  },
  {
    // python -c est toléré pour l'inspection (json, print) mais pas avec des
    // primitives d'exécution / réseau / écriture.
    pattern: /\bpython[0-9.]*\s+(?:-\w+\s+)*-c\b[^\n]*(?:os\.system|os\.popen|os\.exec|subprocess|__import__|\beval\s*\(|\bexec\s*\(|socket|urllib|requests\.|shutil|pty\.|open\s*\([^)]*['"][wa])/,
    reason: 'python -c avec primitive d\'exécution/réseau/écriture — interdit, écrire un script versionné'
  },
  {
    pattern: /\b(?:ba|z|k)?sh\s+(?:-\w+\s+)*-c\b[^\n]*(?:curl|wget|nc\b|netcat|base64\s+(?:-d|--decode)|\/dev\/tcp)/,
    reason: 'sh -c combiné à un téléchargement/décodage — pattern d\'exécution de payload distant'
  },
  {
    pattern: /(?:curl|wget)\b[^|;&]*\|\s*(?:[a-z]*sh|node|python[0-9.]*|perl|ruby|php)\b/,
    reason: 'Téléchargement piped vers un interpréteur — exécution de code distant interdite'
  }
]

// ── Patterns à surveiller (log warning, ne pas bloquer) ──────────────────────

const WARN_PATTERNS = [
  { pattern: /git\s+commit\s+.*--no-verify/,       label: 'git-no-verify' },
  { pattern: /npm\s+install\s+--ignore-scripts/,   label: 'npm-no-scripts' },
  { pattern: /--skip-tests?/,                       label: 'skip-tests' },
  // npx/dlx télécharge et exécute un paquet arbitraire. Non bloqué (le
  // scaffolding /saas-init en a besoin) mais retiré de l'allowlist → prompt.
  { pattern: /\b(?:npx|bunx|(?:pnpm|yarn)\s+dlx)\b/,  label: 'remote-package-exec' },
  { pattern: /force.*push|push.*force/,             label: 'force-push-attempt' },
  { pattern: /production/i,                         label: 'production-context' }
]

// ── AI Defence — détection d'injection et PII ─────────────────────────────────

const AI_DEFENCE_RULES = [
  // Prompt injection patterns
  { pattern: /ignore\s+(?:previous|all|above)\s+instructions?/i,         type: 'prompt-injection', severity: 'high' },
  { pattern: /(?:system|assistant)\s*:\s*(?:you are|act as|pretend)/i,   type: 'prompt-injection', severity: 'high' },
  { pattern: /jailbreak|DAN\s+mode|do\s+anything\s+now/i,               type: 'prompt-injection', severity: 'high' },
  { pattern: /\[\[INST\]\]|\[\/INST\]|<\|im_start\|>/i,                 type: 'prompt-injection', severity: 'medium' },
  // PII detection
  { pattern: /\b\d{3}-\d{2}-\d{4}\b/,                                   type: 'pii-ssn',      severity: 'high' },
  { pattern: /\b(?:\d[ -]?){13,16}\b/,                                   type: 'pii-card',     severity: 'high' },
  { pattern: /\bpassword\s*[:=]\s*\S{8,}/i,                             type: 'pii-password', severity: 'medium' },
  { pattern: /\btoken\s*[:=]\s*[A-Za-z0-9_\-\.]{20,}/i,               type: 'pii-token',    severity: 'medium' },
  // Command injection
  { pattern: /;\s*(?:wget|curl)\s+http/i,                                type: 'cmd-injection', severity: 'high' },
  { pattern: /\$\(.*(?:curl|wget|nc|netcat)/i,                          type: 'cmd-injection', severity: 'high' },
]

/**
 * Analyse une commande pour détecter des patterns AI Defence.
 * @param {string} input
 * @returns {{ type: string, severity: string }[]}
 */
function runAiDefence(input) {
  const matches = []
  for (const rule of AI_DEFENCE_RULES) {
    if (rule.pattern.test(input)) {
      matches.push({ type: rule.type, severity: rule.severity })
    }
  }
  return matches
}

// ── Catégorisation de la commande ─────────────────────────────────────────────

function categorize(cmd) {
  if (/^git\s+commit/.test(cmd))               return 'git-commit'
  if (/^git\s+push/.test(cmd))                 return 'git-push'
  if (/^git\s+merge/.test(cmd))                return 'git-merge'
  if (/npm\s+(?:run\s+)?test|vitest|jest/.test(cmd)) return 'test-run'
  if (/pytest|python\s+-m\s+pytest/.test(cmd)) return 'test-run-python'
  if (/^docker\s+build/.test(cmd))             return 'docker-build'
  if (/supabase|psql|prisma\s+migrate/.test(cmd)) return 'db-operation'
  if (/^node\s+.*coordinator\/run\.js/.test(cmd)) return 'coordinator'
  if (/^npm\s+run\s+build|tsc\s+/.test(cmd))  return 'build'
  return 'general'
}

function ensureDir(p) { if (!existsSync(p)) mkdirSync(p, { recursive: true }) }

// ── Plugin hook system ────────────────────────────────────────────────────────

const PLUGINS_DIR   = join(CONFIG_DIR, 'plugins')
const MAX_HOOK_PLUGINS = 5

/** @param {string} cmd @returns {Decision|null} */
function loadPluginHooks(cmd) {
  if (!existsSync(PLUGINS_DIR)) return null
  try {
    const entries = readdirSync(PLUGINS_DIR, { withFileTypes: true })
      .filter(d => d.isDirectory())
      .slice(0, MAX_HOOK_PLUGINS)

    const deadline = Date.now() + 1000
    const extraWarnings = []

    for (const entry of entries) {
      if (Date.now() > deadline) break
      try {
        const hookPath = join(PLUGINS_DIR, entry.name, 'hook.js')
        if (!existsSync(hookPath)) continue

        // Jail : résoudre les symlinks et vérifier que les fichiers restent dans PLUGINS_DIR
        let realHookPath, realManifestPath, realPluginsDir
        try {
          realPluginsDir  = realpathSync(PLUGINS_DIR)
          realHookPath    = realpathSync(hookPath)
          realManifestPath = realpathSync(join(PLUGINS_DIR, entry.name, 'manifest.json'))
        } catch {
          process.stderr.write(`SKIP plugin symlink non résolvable: ${entry.name}\n`)
          continue
        }
        if (!realHookPath.startsWith(realPluginsDir + sep)) {
          process.stderr.write(`SKIP plugin symlink escape (hook.js): ${entry.name}\n`)
          continue
        }
        if (!realManifestPath.startsWith(realPluginsDir + sep)) {
          process.stderr.write(`SKIP plugin symlink escape (manifest.json): ${entry.name}\n`)
          continue
        }

        // Verify plugin signature before loading — unsigned plugins are skipped
        const manifestPath = join(PLUGINS_DIR, entry.name, 'manifest.json')
        if (!existsSync(manifestPath)) {
          process.stderr.write(`SKIP unsigned plugin: ${entry.name}\n`)
          continue
        }
        try {
          const manifest = JSON.parse(readFileSync(manifestPath, 'utf8'))
          if (!manifest.signature) {
            process.stderr.write(`SKIP unsigned plugin: ${entry.name}\n`)
            continue
          }
          const keySource = manifest.signKey
          if (!keySource || !keySource.startsWith('env:')) continue
          const envVarName = keySource.slice(4)
          const key = process.env[envVarName]
          if (!key) {
            process.stderr.write(`[pre-bash] Plugin "${entry.name}" ignoré — variable env "${envVarName}" non définie\n`)
            continue
          }
          const manifestContent = readFileSync(manifestPath)
          const colonIdx = manifest.signature.indexOf(':')
          if (colonIdx === -1) continue
          const algo     = manifest.signature.slice(0, colonIdx)
          const sigValue = manifest.signature.slice(colonIdx + 1)
          let verified = false
          if (algo === 'hmac-sha256') {
            const actualBuf = Buffer.from(crypto.createHmac('sha256', key).update(manifestContent).digest('hex'), 'hex')
            const sigBuf    = Buffer.from(sigValue, 'hex')
            verified = actualBuf.length === sigBuf.length && crypto.timingSafeEqual(actualBuf, sigBuf)
          } else if (algo === 'ed25519') {
            try {
              const pubKey = crypto.createPublicKey(key)
              verified = crypto.verify(null, manifestContent, pubKey, Buffer.from(sigValue, 'base64'))
            } catch {}
          }
          if (!verified) {
            process.stderr.write(`SKIP plugin invalid signature: ${entry.name}\n`)
            continue
          }

          // Verify hook.js integrity via hookHash in manifest (sha256 of hook.js content)
          if (manifest.hookHash) {
            const actualHookHash = crypto.createHash('sha256').update(readFileSync(hookPath)).digest('hex')
            if (actualHookHash !== manifest.hookHash) {
              process.stderr.write(`SKIP plugin hook.js tampered: ${entry.name}\n`)
              continue
            }
          } else {
            process.stderr.write(`WARN plugin missing hookHash (manifest-only signature): ${entry.name}\n`)
          }
        } catch { continue }

        const hookFn = require(hookPath)
        if (typeof hookFn !== 'function' && typeof hookFn.check !== 'function') continue

        const check = typeof hookFn === 'function' ? hookFn : hookFn.check
        const result = check(cmd)
        if (!result) continue

        if (result.block) return { action: 'block', reason: result.reason }
        if (result.warn)  extraWarnings.push(result.reason)
      } catch {}
    }

    return extraWarnings.length > 0 ? { action: 'warn', warnings: extraWarnings } : null
  } catch {
    return null
  }
}

function logCommand(cmd, category, blocked, warning) {
  ensureDir(LOGS_DIR)
  const ts    = new Date().toISOString().slice(0, 19).replace('T', ' ')
  const flags = [blocked ? 'BLOCKED' : null, warning ? `WARN:${warning}` : null].filter(Boolean).join(' ')
  const line  = `${ts} [${category.padEnd(20)}] ${flags ? `[${flags}] ` : ''}${cmd.slice(0, 200)}\n`
  try { appendFileSync(CMD_LOG, line) } catch {}
}

/**
 * Aucune décision : on laisse le flux de permission normal de Claude Code
 * s'appliquer (allowlist/denylist de settings.json). On n'émet JAMAIS
 * permissionDecision:"allow" — cela auto-approuverait toute commande.
 * @param {string} cmd @param {string} category @param {string|null|undefined} warning @returns {void}
 */
function pass(cmd, category, warning) {
  logCommand(cmd, category, false, warning)
  process.stdout.write(JSON.stringify({ suppressOutput: true }))
  process.exit(0)
}

/** @param {string} cmd @param {string} category @param {string} reason @returns {void} */
function block(cmd, category, reason) {
  logCommand(cmd, category, true, null)
  process.stdout.write(JSON.stringify({
    hookSpecificOutput: {
      hookEventName: 'PreToolUse',
      permissionDecision: 'deny',
      permissionDecisionReason: reason
    }
  }))
  process.exit(0)
}

/**
 * FAIL-CLOSED — erreur interne du hook : on bloque.
 * Double garantie : JSON deny sur stdout + message sur stderr + exit 2
 * (exit 2 = blocage dur PreToolUse, indépendant du parsing du stdout).
 * @param {string} detail @returns {void}
 */
function failClosed(detail) {
  const reason = `[Sécurité] Hook de validation en échec — commande bloquée par précaution (fail-closed).\nDétail : ${detail}`
  try { logCommand('<hook-error>', 'hook-failure', true, null) } catch {}
  try {
    process.stdout.write(JSON.stringify({
      hookSpecificOutput: {
        hookEventName: 'PreToolUse',
        permissionDecision: 'deny',
        permissionDecisionReason: reason
      }
    }))
  } catch {}
  try { process.stderr.write(`${reason}\n`) } catch {}
  process.exit(2)
}

// ── Main ──────────────────────────────────────────────────────────────────────
// Exécuté uniquement quand le fichier est lancé comme hook (`node pre-bash.js`).
// Sans cette garde, un simple `require()` (tests, outillage) enregistrerait les
// listeners stdin + le watchdog dans le process appelant et le tuerait via
// process.exit(2) au moment du fail-closed.

let raw = ''
let decided = false

if (require.main === module) {

// Toute exception non capturée doit bloquer, jamais laisser passer.
process.on('uncaughtException',  e => failClosed(`exception non capturée: ${e?.message || e}`))
process.on('unhandledRejection', e => failClosed(`rejet non géré: ${e?.message || e}`))

process.stdin.setEncoding('utf8')
process.stdin.on('data', chunk => { raw += chunk })
process.stdin.on('end', () => {
  try {
    if (decided) return
    if (lexerLoadError) { decided = true; failClosed(`shell-lexer indisponible (${lexerLoadError}) — analyse des segments composés impossible`); return }

    /** @type {any} */
    let payload
    try { payload = JSON.parse(raw) }
    catch (e) { decided = true; failClosed(`payload PreToolUse illisible: ${e?.message || e}`); return }

    // Hook câblé sur matcher "Bash" : un autre outil ne devrait pas arriver ici.
    const toolName = payload?.tool_name || ''
    if (toolName && toolName !== 'Bash') { decided = true; process.stdout.write(JSON.stringify({ suppressOutput: true })); process.exit(0); return }

    const cmd = payload?.tool_input?.command || ''
    if (!cmd) { decided = true; process.stdout.write(JSON.stringify({ suppressOutput: true })); process.exit(0); return }

    const category = categorize(cmd)

    // Cibles d'analyse : chaîne brute (défense en profondeur — 1re passe) +
    // chaque segment hors-quotes + le contenu de chaque substitution. Ceci ferme
    // le trou où une commande dangereuse cachée après &&/;/|/&/newline ou dans
    // une $()/backtick passait car le motif ne matchait que le début de la chaîne.
    // Si le lexer échoue sur cette commande, on ne dispose pas de la vue
    // segmentée → fail-closed plutôt que de n'analyser que la chaîne brute.
    let targets
    try {
      const analysis = analyzeCommand(cmd)
      targets = [cmd, ...(analysis?.segments || []), ...(analysis?.substitutions || [])]
    } catch (e) {
      decided = true
      failClosed(`analyse lexicale de la commande impossible: ${e?.message || e}`)
      return
    }

    // Vérifier les règles de blocage sur chaque cible
    for (const rule of BLOCK_RULES) {
      if (targets.some(t => rule.pattern.test(t))) {
        decided = true
        block(cmd, category, `[Sécurité] ${rule.reason}\nCommande : ${cmd.slice(0, 150)}`)
        return
      }
    }

    // ── AI Defence ────────────────────────────────────────────────────────────
    const aiMatches = runAiDefence(cmd)
    if (aiMatches.length > 0) {
      // Sévérité high : cmd-injection et pii-* → bloquer
      // prompt-injection → warn seulement (faux positifs possibles dans les commandes légitimes)
      const highBlocking = aiMatches.find(m => m.severity === 'high' && m.type !== 'prompt-injection')
      if (highBlocking) {
        decided = true
        block(cmd, category, `[AI Defence] ${highBlocking.type}\nCommande : ${cmd.slice(0, 150)}`)
        return
      }
    }

    // Règles additionnelles depuis les plugins
    const pluginDecision = loadPluginHooks(cmd)
    if (pluginDecision?.action === 'block') {
      decided = true
      block(cmd, category, `[Plugin] ${pluginDecision.reason}`)
      return
    }

    // Vérifier les patterns de warning (WARN_PATTERNS + AI Defence medium/prompt-injection)
    const pluginWarning = pluginDecision?.warnings?.join(', ') || null
    const stdWarning    = WARN_PATTERNS.find(w => w.pattern.test(cmd))?.label || null

    let aiWarning = null
    if (aiMatches.length > 0) {
      // prompt-injection (any severity) → warn
      // pii-*/cmd-injection medium → warn
      const warnMatch = aiMatches.find(m =>
        m.type === 'prompt-injection' || m.severity === 'medium'
      )
      if (warnMatch) aiWarning = `ai-defence:${warnMatch.type}`
    }

    const warning = stdWarning || aiWarning || pluginWarning

    decided = true
    pass(cmd, category, warning)
  } catch (e) {
    // FAIL-CLOSED : si le hook plante, on bloque (une garde de sécurité muette
    // est pire que pas de garde du tout).
    if (!decided) { decided = true; failClosed(`erreur interne: ${e?.message || e}`) }
  }
})

process.stdin.on('error', e => {
  if (!decided) { decided = true; failClosed(`lecture stdin impossible: ${e?.message || e}`) }
})

// Watchdog : au-delà de 5 s on bloque (ne jamais dégrader en « autoriser »).
// Aligné sous le `timeout` déclaré dans settings.json pour que ce chemin
// fail-closed s'exécute avant que Claude Code ne tue le hook.
setTimeout(() => {
  if (!decided) { decided = true; failClosed('watchdog 5 s — analyse non terminée') }
}, 5000)

// Garde ultime : si la boucle d'événements se vide sans qu'aucune décision
// n'ait été prise (stdin fermé sans 'end', etc.), sortir en 2 plutôt qu'en 0.
process.on('exit', code => { if (!decided && code === 0) process.exitCode = 2 })

} // fin de `require.main === module`

// Export pour les tests unitaires (aucun effet de bord à l'import).
module.exports = { BLOCK_RULES, WARN_PATTERNS, AI_DEFENCE_RULES, runAiDefence, categorize }
