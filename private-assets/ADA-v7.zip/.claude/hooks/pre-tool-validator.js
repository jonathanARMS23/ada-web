#!/usr/bin/env node
// pre-tool-validator.js — PreToolUse hook
// Intercepte les outils AVANT exécution et bloque les patterns dangereux.
// Complète le deny list statique de settings.json (patterns dynamiques/variantes).
//
// Exit 0 = laisser passer
// Exit 2 = bloquer + injecter le message de refus dans le contexte
//
// FAIL-CLOSED : toute erreur interne (module manquant, payload illisible,
// exception, timeout) sort en 2 et bloque la commande. Un validateur muet
// donnerait une fausse assurance de sécurité.

'use strict'

const { join } = require('path')

let decided = false

/** Bloque sur erreur interne. @param {string} detail @returns {void} */
function failClosed(detail) {
  decided = true
  process.stdout.write([
    '[pre-tool-validator] BLOQUANT — ERREUR INTERNE DU HOOK',
    `Détail : ${detail}`,
    '',
    'La commande est bloquée par précaution (fail-closed). Corrige le hook',
    'avant de réessayer — ne contourne pas la validation.',
  ].join('\n'))
  process.stderr.write(`[pre-tool-validator] fail-closed: ${detail}\n`)
  process.exit(2)
}

// Chargement fail-closed du lexer : sans lui, les commandes composées
// (&&, ;, |, $()) ne sont plus analysées → bloquer au lieu de laisser passer.
/** @type {((cmd: string) => { segments: string[], substitutions: string[] })|null} */
let analyzeCommand = null
/** @type {string|null} */
let lexerLoadError = null
try {
  const lexer = require(join(__dirname, '..', 'coordinator', 'shell-lexer.js'))
  if (typeof lexer?.analyzeCommand !== 'function') throw new Error('analyzeCommand absent du module shell-lexer')
  analyzeCommand = lexer.analyzeCommand
} catch (e) {
  lexerLoadError = e?.message || String(e)
}

// ─── Règles de blocage ────────────────────────────────────────────────────────

const BLOCKED = [
  // rm -rf sur chemins non-triviaux (au-delà de *.tmp déjà dans l'allow list)
  {
    pattern: /rm\s+-rf?\s+(?!.*\.tmp)(?!.*node_modules)(?!\s*$)/,
    reason:  'rm -rf sur un chemin non-trivial détecté. Utilise rm ciblé ou ajoute le chemin à la allow list.',
    level:   'BLOQUANT',
  },
  // git push --force / -f (variantes non couvertes par le deny statique)
  {
    pattern: /git\s+push\s+.*(-f\b|--force)\b/,
    reason:  'git push --force détecté. Force push interdit sauf exception explicite.',
    level:   'BLOQUANT',
  },
  // DROP TABLE / DROP DATABASE via SQL brut ou psql
  {
    pattern: /\bDROP\s+(TABLE|DATABASE|SCHEMA)\b/i,
    reason:  'Commande SQL DROP détectée. Utilise une migration versionnée avec rollback.',
    level:   'BLOQUANT',
  },
  // TRUNCATE sans condition (dangereux en prod)
  {
    pattern: /\bTRUNCATE\s+(?!.*WHERE)/i,
    reason:  'TRUNCATE sans WHERE détecté. Risque de perte de données en production.',
    level:   'BLOQUANT',
  },
  // curl | bash — pattern d'exécution de code distant
  {
    pattern: /curl\b.*\|\s*(ba)?sh\b/,
    reason:  'curl | bash détecté. Exécution de code distant non autorisée.',
    level:   'BLOQUANT',
  },
  // wget | bash
  {
    pattern: /wget\b.*\|\s*(ba)?sh\b/,
    reason:  'wget | bash détecté. Exécution de code distant non autorisée.',
    level:   'BLOQUANT',
  },
  // eval de contenu arbitraire
  {
    pattern: /\beval\s+["'`$\(]/,
    reason:  'eval avec contenu dynamique détecté. Pattern à risque.',
    level:   'BLOQUANT',
  },
  // Écriture dans /etc
  {
    pattern: />\s*\/etc\//,
    reason:  'Écriture dans /etc/ détectée. Modification de fichiers système non autorisée.',
    level:   'BLOQUANT',
  },
  // chmod 777 (variantes)
  {
    pattern: /chmod\s+777/,
    reason:  'chmod 777 détecté. Permissions trop permissives.',
    level:   'BLOQUANT',
  },
  // Suppression du répertoire de travail courant
  {
    pattern: /rm\s+-rf?\s+\.\s*$/,
    reason:  'Suppression du répertoire courant (rm -rf .) détectée.',
    level:   'BLOQUANT',
  },
]

// ─── Avertissements (non bloquants — loggés seulement) ────────────────────────

const WARNINGS = [
  // psql avec mot de passe en clair
  {
    pattern: /psql\s+.*(-W|password=)/i,
    reason:  'Mot de passe PostgreSQL potentiellement en clair dans la commande.',
  },
  // export de credentials dans l'environnement
  {
    pattern: /export\s+.*(KEY|SECRET|TOKEN|PASSWORD)\s*=/i,
    reason:  'Export de credential détecté. Préférer un fichier .env non commité.',
  },
]

// ─── Lire le payload stdin ────────────────────────────────────────────────────
// Garde `require.main` : sans elle, un `require()` de ce fichier (tests,
// outillage) installerait les listeners stdin + le watchdog dans le process
// appelant et le tuerait au premier fail-closed.

let raw = ''

if (require.main === module) {

// Toute exception non capturée doit bloquer, jamais laisser passer.
process.on('uncaughtException',  e => failClosed(`exception non capturée: ${e?.message || e}`))
process.on('unhandledRejection', e => failClosed(`rejet non géré: ${e?.message || e}`))

process.stdin.setEncoding('utf8')
process.stdin.on('data', chunk => { raw += chunk })
process.stdin.on('end', () => {
  if (decided) return

  let payload = {}
  try { payload = JSON.parse(raw) }
  catch (e) { failClosed(`payload PreToolUse illisible: ${e?.message || e}`); return }

  const toolName  = payload.tool_name  || ''
  const toolInput = payload.tool_input || {}

  // ─── Seuls les outils Bash sont analysés ──────────────────────────────────────

  if (toolName !== 'Bash') { decided = true; process.exit(0); return }

  const cmd = (toolInput.command || '').trim()
  if (!cmd) { decided = true; process.exit(0); return }

  if (lexerLoadError) {
    failClosed(`shell-lexer indisponible (${lexerLoadError}) — analyse des commandes composées impossible`)
    return
  }

  // ─── Vérification ─────────────────────────────────────────────────────────────

  // Cibles : chaîne brute (défense en profondeur — 1re passe) + chaque segment
  // hors-quotes + contenu des substitutions. Ferme le bypass où une commande
  // dangereuse cachée après un opérateur composé (&&/;/|/&/newline) ou dans une
  // $()/backtick échappait au motif appliqué uniquement au début de la chaîne.
  let targets
  try {
    const analysis = analyzeCommand(cmd)
    targets = [cmd, ...(analysis?.segments || []), ...(analysis?.substitutions || [])]
  } catch (e) {
    failClosed(`analyse lexicale impossible: ${e?.message || e}`)
    return
  }

  for (const rule of BLOCKED) {
    if (targets.some(t => rule.pattern.test(t))) {
      const message = [
        `[pre-tool-validator] BLOQUANT — ${rule.level}`,
        `Commande : ${cmd.slice(0, 120)}`,
        `Raison   : ${rule.reason}`,
        ``,
        `La commande a été bloquée. Modifie l'approche ou justifie explicitement l'exception.`,
      ].join('\n')

      decided = true
      process.stdout.write(message)
      process.exit(2)
    }
  }

  // Avertissements — sortie stderr (non injecté dans le contexte)
  for (const rule of WARNINGS) {
    if (rule.pattern.test(cmd)) {
      process.stderr.write(`[pre-tool-validator] AVERTISSEMENT : ${rule.reason}\n`)
    }
  }

  // Tout OK — pas de décision : le flux de permission normal s'applique
  decided = true
  process.exit(0)
})

process.stdin.on('error', e => {
  if (!decided) failClosed(`lecture stdin impossible: ${e?.message || e}`)
})

// Watchdog : au-delà de 5 s on bloque plutôt que de laisser passer.
setTimeout(() => {
  if (!decided) failClosed('watchdog 5 s — validation non terminée')
}, 5000)

// Garde ultime : sortie « naturelle » sans décision → exit 2, jamais 0.
process.on('exit', code => { if (!decided && code === 0) process.exitCode = 2 })

} // fin de `require.main === module`

// Export pour les tests unitaires (aucun effet de bord à l'import).
module.exports = { BLOCKED, WARNINGS }
