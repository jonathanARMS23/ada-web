#!/usr/bin/env node
// reset-session-cache.js
// Appelé par /compact pour réinitialiser l'état de session.
// Vide le cache des skills lus et remet le compteur d'échanges à 0.

const { existsSync, unlinkSync } = require('fs')
const { join } = require('path')

const CONFIG_DIR    = process.env.CLAUDE_CONFIG_DIR || join(process.env.HOME, '.claude')
const CACHE_FILE    = join(CONFIG_DIR, 'session-skill-cache.json')
const SESSION_FILE  = join(CONFIG_DIR, 'session-state.json')

let cleaned = []

try {
  if (existsSync(CACHE_FILE))   { unlinkSync(CACHE_FILE);  cleaned.push('skill-cache') }
  if (existsSync(SESSION_FILE)) { unlinkSync(SESSION_FILE); cleaned.push('session-state') }
  if (cleaned.length) {
    console.log(`[reset-session-cache] Nettoyé : ${cleaned.join(', ')}`)
  } else {
    console.log('[reset-session-cache] Rien à nettoyer.')
  }
  process.exit(0)
} catch (e) {
  console.error('[reset-session-cache] Erreur :', e.message)
  process.exit(0)
}
