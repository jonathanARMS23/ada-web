#!/usr/bin/env node
/**
 * hooks/session-end.js — Stop hook
 *
 * Déclenché à la fin de chaque réponse Claude Code (event Stop).
 * Rôle :
 *  1. Écrire un checkpoint léger dans logs/sessions.log
 *  2. Compter l'activité de la session (fichiers modifiés depuis le dernier checkpoint)
 *  3. Dispatcher consolidate si la mémoire dépasse le seuil
 *  4. Dispatcher ultralearn si activité significative
 *  5. Écrire une note Obsidian si configuré (session >= 2 échanges)
 *
 * Note : Stop se déclenche à chaque fin de réponse, pas uniquement en fin de session.
 * On utilise un fichier de session state pour éviter les duplicates.
 */

const {
  existsSync, mkdirSync, readFileSync, writeFileSync, appendFileSync, readdirSync, renameSync, statSync
} = require('fs')
const { join, dirname } = require('path')
const { spawn } = require('child_process')
const os = require('os')

// ── Constantes globales ────────────────────────────────────────────────────────
const CONFIG_DIR   = process.env.CLAUDE_CONFIG_DIR || join(process.env.HOME ?? os.homedir(), '.claude')
const PROJECT_ID   = (process.env.AI_DEV_PROJECT || 'workspace')
  .replace(/[^a-z0-9_\-]/gi, '-')
  .slice(0, 128)
const LOGS_DIR     = join(CONFIG_DIR, 'logs')
const MEMORY_DIR   = join(CONFIG_DIR, 'memory')
const WORKERS_DIR  = join(CONFIG_DIR, 'workers')
const SESSION_FILE = join(LOGS_DIR, '.session-state.json')

const CONSOLIDATE_THRESHOLD = 200  // lignes mémoire avant consolidation

// ── Cache keep-alive (TTL Anthropic prompt cache = 5min = 300s) ───────────────
const CACHE_TTL_MS         = 270_000  // 270s < 300s TTL — marge de sécurité
const CACHE_KEEPALIVE_FILE = join(LOGS_DIR, 'cache-keepalive.json')

// ── Utilitaires ────────────────────────────────────────────────────────────────
function ensureDir(p) { if (!existsSync(p)) mkdirSync(p, { recursive: true }) }
function ts()  { return new Date().toISOString() }
function now() { return new Date().toISOString().slice(0, 16).replace('T', ' ') }

function readJson(p, fallback = {}) {
  try { return JSON.parse(readFileSync(p, 'utf8')) } catch { return fallback }
}

function writeJson(p, data) {
  ensureDir(dirname(p))
  const tmp = p + '.tmp'
  writeFileSync(tmp, JSON.stringify(data, null, 2))
  renameSync(tmp, p)
}

// ── Webhook (délégué à coordinator/webhook.js, chargé lazily) ────────────────

function dispatchWebhook(...args) {
  try {
    const webhookPath = require('path').join(
      process.env.CLAUDE_CONFIG_DIR || require('path').join(require('os').homedir(), '.claude'),
      'coordinator', 'webhook.js'
    )
    return require(webhookPath).dispatchWebhook(...args)
  } catch { /* webhook.js absent — no-op */ }
}

// ── Workers ────────────────────────────────────────────────────────────────────
function dispatchWorker(name, args = []) {
  const workerPath = join(WORKERS_DIR, `${name}.js`)
  if (!existsSync(workerPath)) return
  const child = spawn('node', [workerPath, ...args], {
    detached: true,
    stdio:    'ignore',
    env:      { ...process.env, CLAUDE_CONFIG_DIR: CONFIG_DIR, AI_DEV_PROJECT: PROJECT_ID }
  })
  child.unref()
  try {
    appendFileSync(join(LOGS_DIR, 'workers.log'), `${ts()} dispatch ${name} ${args.join(' ')}\n`)
  } catch {}
}

// ── Cache keep-alive ───────────────────────────────────────────────────────────
/**
 * Écrire le timestamp de la dernière réponse dans cache-keepalive.json.
 * Appelé à chaque fin de réponse pour suivre les gaps d'activité.
 */
function updateCacheTimestamp(responseCount) {
  try {
    ensureDir(LOGS_DIR)
    writeJson(CACHE_KEEPALIVE_FILE, { ts: Date.now(), responseCount })
  } catch {}
}

/**
 * Vérifier si le cache est probablement expiré (gap > 270s depuis le dernier enregistrement).
 * Retourne false si le fichier est absent (pas de crash).
 */
function checkCacheExpiry() {
  try {
    const data = readJson(CACHE_KEEPALIVE_FILE, null)
    if (!data || typeof data.ts !== 'number') return false
    return (Date.now() - data.ts) > CACHE_TTL_MS
  } catch {
    return false
  }
}

// ── Mémoire ────────────────────────────────────────────────────────────────────
// C2 — gated par mtime : à chaque réponse, on ne re-lit+split le contenu que si un
// .md a changé depuis le dernier check. Sinon on réutilise le compte caché dans
// session-state (statSync seul, bien moins coûteux que readFileSync+split).
function countMemoryLines(state = null) {
  const globalDir = join(MEMORY_DIR, 'global')
  if (!existsSync(globalDir)) return 0
  try {
    const files = readdirSync(globalDir).filter(f => f.endsWith('.md'))
    let maxMtime = 0
    let totalBytes = 0
    for (const file of files) {
      try {
        const st = statSync(join(globalDir, file))
        maxMtime = Math.max(maxMtime, st.mtimeMs)
        totalBytes += st.size
      } catch {}
    }
    // totalBytes ferme le trou résiduel : une édition à mtime restaurée + même
    // longueur de ligne mais taille d'octets différente invalide quand même le cache.
    const sig = `${files.length}:${maxMtime}:${totalBytes}`
    if (state?.memLinesCache && state.memLinesCache.sig === sig) {
      return state.memLinesCache.count
    }
    let total = 0
    for (const file of files) {
      total += readFileSync(join(globalDir, file), 'utf8').split('\n').length
    }
    if (state) state.memLinesCache = { sig, count: total }
    return total
  } catch { return 0 }
}

// ── Obsidian ───────────────────────────────────────────────────────────────────
/**
 * Extraire le nom court du profil depuis CONFIG_DIR.
 * Ex: /Users/x/.claude-pro → "pro", /Users/x/.claude → "default"
 */
function getProfileName() {
  const base = require('path').basename(CONFIG_DIR)
  // base = ".claude-pro" → "pro", ".claude" → "default"
  const match = base.match(/^\.claude-(.+)$/)
  return match ? match[1] : 'default'
}

/**
 * Résoudre le chemin du vault Obsidian selon le mode configuré.
 * @param {object} obs — adaCfg.obsidian
 * @returns {string|null} chemin absolu du vault
 */
function resolveVaultDir(obs) {
  if (!obs.mode || obs.mode === 'per-profile') {
    // Vault embarqué dans le profil — toujours CONFIG_DIR/_obsidian
    return join(CONFIG_DIR, '_obsidian')
  }
  // Mode unified : vaultPath/profiles/<profile>
  if (obs.vaultPath) {
    const profile = getProfileName()
    return join(obs.vaultPath.replace(/^~/, os.homedir()), 'profiles', profile)
  }
  return null
}

// ── Topic extraction (inline, O(ms)) ──────────────────────────────────────────
/**
 * Extraction légère des topics depuis le PROJECT_ID et les fichiers récemment
 * modifiés dans le répertoire projet. Aucune lecture de fichier externe.
 * Budget : < 5ms même en P99.
 *
 * @param {object} state — session state courant
 * @returns {string[]} liste de topics (max 5)
 */
function extractTopicsInline(state) {
  const INLINE_PATTERNS = [
    { re: /nestjs|nest/i,               topic: 'NestJS'        },
    { re: /next\.?js|nextjs/i,          topic: 'Next.js'       },
    { re: /fastapi|python/i,            topic: 'FastAPI'       },
    { re: /react.native|expo/i,         topic: 'React Native'  },
    { re: /migration|prisma|sql/i,      topic: 'DB Migration'  },
    { re: /auth|jwt|oauth/i,            topic: 'Auth'          },
    { re: /docker|deploy|ci/i,          topic: 'DevOps'        },
    { re: /graphql/i,                   topic: 'GraphQL'       },
    { re: /agent|llm|rag/i,             topic: 'AI/Agent'      },
    { re: /obsidian|vault|memory/i,     topic: 'Memory'        },
    { re: /test|spec|jest/i,            topic: 'Testing'       },
    { re: /ui|component|tailwind/i,     topic: 'UI'            },
    { re: /architecture|adr/i,          topic: 'Architecture'  },
    { re: /postgresql|postgres|redis/i, topic: 'Database'      },
    { re: /security|audit|rbac/i,       topic: 'Security'      },
  ]

  const seen    = new Set()
  const matched = []

  // Signal 1 — PROJECT_ID + sessionStart
  const signal1 = [PROJECT_ID, state.sessionStart || ''].join(' ')
  for (const { re, topic } of INLINE_PATTERNS) {
    if (re.test(signal1) && !seen.has(topic)) {
      seen.add(topic); matched.push(topic)
    }
  }

  // Signal 2 — Topics récurrents dans context.md (déjà écrits par ultralearn)
  try {
    const ctxPath = require('path').join(MEMORY_DIR, 'context.md')
    if (require('fs').existsSync(ctxPath)) {
      const ctx = require('fs').readFileSync(ctxPath, 'utf8')
      const m   = ctx.match(/## Topics récurrents[\s\S]*?(?=\n## |\s*$)/)
      if (m) {
        const topicRe = /\*\*([^*]+)\*\*/g
        let hit
        while ((hit = topicRe.exec(m[0])) !== null) {
          const t = hit[1].trim()
          if (t && !seen.has(t)) { seen.add(t); matched.push(t) }
        }
      }
    }
  } catch {}

  // Fallback : utiliser le PROJECT_ID nettoyé comme topic générique
  if (!matched.length && PROJECT_ID && PROJECT_ID !== 'workspace') {
    matched.push(PROJECT_ID.replace(/-/g, ' '))
  }

  return matched.slice(0, 6)
}

/**
 * Écrire une note de session dans le vault Obsidian.
 * Fast-path : si obsidian non configuré, zero I/O.
 * Toutes les opérations sont dans try/catch — ne bloque jamais le hook.
 *
 * @param {object|null} adaCfg — contenu de ~/.ada.json
 * @param {object} state — session state courant
 * @param {string[]} topics — liste de topics extraits (optionnel)
 */
function writeObsidianNote(adaCfg, state, topics = []) {
  try {
    const obs = adaCfg?.obsidian
    // Fast-path : obsidian non configuré
    if (!obs?.enabled) return

    const vaultDir = resolveVaultDir(obs)
    if (!vaultDir) return

    const sessDir = join(vaultDir, 'sessions')
    // Vault pas initialisé = skip silencieux (pas de création automatique)
    if (!existsSync(sessDir)) return

    const profile    = getProfileName()
    const now        = new Date()
    // Format "HHhMM" pour le nom de fichier et l'affichage
    const hh         = String(now.getHours()).padStart(2, '0')
    const mm         = String(now.getMinutes()).padStart(2, '0')
    const timeLabel  = `${hh}h${mm}`
    const dateStr    = now.toISOString().slice(0, 10)           // YYYY-MM-DD
    const fileName   = `${dateStr}-${timeLabel}.md`
    const notePath   = join(sessDir, fileName)

    // ── Note de session ──────────────────────────────────────────────────────
    const frontmatter = [
      '---',
      `date: ${now.toISOString()}`,
      `profile: ${profile}`,
      `project: ${PROJECT_ID}`,
      `exchanges: ${state.responseCount}`,
      'tags: [session, ada]',
      topics.length ? `topics: [${topics.map(t => `"${t}"`).join(', ')}]` : null,
      '---',
    ].filter(Boolean).join('\n')

    const table = [
      `## ${timeLabel} — ${PROJECT_ID}`,
      '',
      '| Champ | Valeur |',
      '|---|---|',
      `| Profil | ${profile} |`,
      `| Échanges | ${state.responseCount} |`,
      `| Début | ${state.sessionStart} |`,
      topics.length ? `| Topics | ${topics.join(' · ')} |` : null,
      '',
      '<!-- Annotations -->',
    ].filter(Boolean).join('\n')

    const noteContent = `${frontmatter}\n\n${table}\n`

    // Écriture atomique : tmp → rename
    const noteTmp = notePath + '.tmp'
    writeFileSync(noteTmp, noteContent, 'utf8')
    renameSync(noteTmp, notePath)

    // ── Daily note (append) ──────────────────────────────────────────────────
    const dailyDir  = join(vaultDir, 'daily')
    ensureDir(dailyDir)
    const dailyPath = join(dailyDir, `${dateStr}.md`)
    const dailyLine = `- ${timeLabel} [[sessions/${dateStr}-${timeLabel}|${PROJECT_ID}]] (${state.responseCount} échanges)\n`
    appendFileSync(dailyPath, dailyLine, 'utf8')

  } catch {
    // Resilience : jamais bloquer le hook
  }
}

// ── Main ───────────────────────────────────────────────────────────────────────
function run() {
  ensureDir(LOGS_DIR)

  // Lire ~/.ada.json UNE FOIS — partagé avec webhook et obsidian
  let adaCfg = null
  try {
    const cfgPath = join(os.homedir(), '.ada.json')
    if (existsSync(cfgPath)) adaCfg = JSON.parse(readFileSync(cfgPath, 'utf8'))
  } catch {}

  // Lire ou initialiser le state de session
  const state = readJson(SESSION_FILE, {
    sessionStart: ts(),
    responseCount: 0,
    lastConsolidate: null,
    lastUltralearn: null,
    lastDecay: null
  })

  state.responseCount = (state.responseCount || 0) + 1

  // Cache keep-alive : détecter les gaps > 270s avant de mettre à jour le timestamp
  const cacheExpired = checkCacheExpiry()
  if (cacheExpired) {
    try {
      const prev = readJson(CACHE_KEEPALIVE_FILE, {})
      const gapSecs = prev.ts ? Math.round((Date.now() - prev.ts) / 1000) : '?'
      appendFileSync(
        join(LOGS_DIR, 'cache-keepalive.log'),
        `${ts()} [cache-miss] gap de ${gapSecs}s — cache probablement expiré (project=${PROJECT_ID})\n`
      )
    } catch {}
  }
  updateCacheTimestamp(state.responseCount)

  // Checkpoint léger dans sessions.log
  try {
    appendFileSync(
      join(LOGS_DIR, 'sessions.log'),
      `${now()} [response #${state.responseCount}] project=${PROJECT_ID}\n`
    )
  } catch {}

  // Consolidate si mémoire trop grande — check à chaque réponse, cooldown 5 min
  const CONSOLIDATE_COOLDOWN_MS = 5 * 60 * 1000
  const memLines = countMemoryLines(state)
  if (memLines > CONSOLIDATE_THRESHOLD) {
    const lastMs = state.lastConsolidate ? new Date(state.lastConsolidate).getTime() : 0
    if (Date.now() - lastMs > CONSOLIDATE_COOLDOWN_MS) {
      dispatchWorker('consolidate', [PROJECT_ID])
      state.lastConsolidate = ts()
    }
  }

  // Ultralearn : déclencher toutes les 20 réponses si activité significative
  if (state.responseCount % 20 === 0) {
    dispatchWorker('ultralearn', [PROJECT_ID])
    state.lastUltralearn = ts()
  }

  // Team Sync auto-push (F6) : déclencher si >= 5 réponses, autoSync actif et remoteUrl configuré
  if (state.responseCount >= 5 && adaCfg?.teamSync?.autoSync && adaCfg?.teamSync?.remoteUrl) {
    dispatchWorker('team-sync-push')
  }

  // Auto-banking : persiste les phases completed non encore bankées du run actif
  // Protège les trajectoires si l'orchestrateur crash avant d'appeler `node run.js done`
  try {
    const RUNS_DIR = join(CONFIG_DIR, 'runs')
    if (existsSync(RUNS_DIR)) {
      // Trouver le run actif : status='running' ou le plus récemment modifié
      let activeRunDir = null
      let activeState  = null
      let latestMtime  = 0

      for (const runId of readdirSync(RUNS_DIR)) {
        const stateFile = join(RUNS_DIR, runId, 'state.json')
        if (!existsSync(stateFile)) continue
        // P5 — stat AVANT parse : on ignore les runs inactifs (>1h) et ceux de mtime
        // inférieur au meilleur déjà trouvé → évite des JSON.parse inutiles à chaque réponse.
        let mtime
        try { mtime = require('fs').statSync(stateFile).mtimeMs } catch { continue }
        if (Date.now() - mtime > 3_600_000) continue
        if (mtime <= latestMtime) continue
        try {
          const rs = JSON.parse(readFileSync(stateFile, 'utf8'))
          if (rs.status === 'running' && rs.activePhase !== null) {
            latestMtime  = mtime
            activeRunDir = join(RUNS_DIR, runId)
            activeState  = rs
          }
        } catch {}
      }

      if (activeRunDir && activeState) {
        const bankPath = join(CONFIG_DIR, 'coordinator', 'bank.js')
        if (existsSync(bankPath)) {
          const bank = require(bankPath)
          // Initialiser le registre banked dans le session-state (pas dans state.json du run)
          if (!state.bankedPhases) state.bankedPhases = {}
          const runKey = activeState.id

          let count = 0
          for (const [phaseId, phase] of Object.entries(activeState.phases || {})) {
            if (count >= 3) break  // budget max 3 phases par cycle
            if (phase.status !== 'completed') continue
            const bankKey = `${runKey}:${phaseId}`
            if (state.bankedPhases[bankKey]) continue  // déjà banké

            // Retry avec backoff exponentiel (3 tentatives : 0ms, 200ms, 800ms)
            const _storeWithRetry = (attempt = 0) => {
              try {
                bank.store(
                  phaseId,
                  phase.agent || 'unknown',
                  'success',
                  phase.summary || `Phase ${phaseId} completed`,
                  {
                    runId:   runKey,
                    project: PROJECT_ID,
                    duration: phase.startedAt && phase.completedAt
                      ? new Date(phase.completedAt).getTime() - new Date(phase.startedAt).getTime()
                      : null,
                  }
                )
                state.bankedPhases[bankKey] = ts()
                count++
                try {
                  appendFileSync(
                    join(LOGS_DIR, 'workers.log'),
                    `${ts()} auto-bank phase=${phaseId} run=${runKey} agent=${phase.agent}\n`
                  )
                } catch {}
              } catch (storeErr) {
                if (attempt < 2) {
                  setTimeout(() => _storeWithRetry(attempt + 1), attempt === 0 ? 200 : 800)
                } else {
                  try {
                    appendFileSync(
                      join(LOGS_DIR, 'workers.log'),
                      `${ts()} auto-bank FAILED phase=${phaseId} run=${runKey} err=${storeErr?.message}\n`
                    )
                  } catch {}
                }
              }
            }
            _storeWithRetry()
          }
        }
      }
    }
  } catch (e) {
    try { appendFileSync(join(LOGS_DIR, 'workers.log'), `${ts()} [session-end] auto-bank ERROR: ${e?.message}\n`) } catch {}
  }

  // Auto-decay des priors Thompson Sampling (1 fois par 30 réponses)
  if (state.responseCount % 30 === 0) {
    const routerPath = join(CONFIG_DIR, 'coordinator', 'router.js')
    if (existsSync(routerPath)) {
      const child = spawn('node', [routerPath, 'decay', '--factor', '0.95'], {
        detached: true,
        stdio: 'ignore',
        env: { ...process.env, CLAUDE_CONFIG_DIR: CONFIG_DIR }
      })
      child.unref()
      state.lastDecay = ts()
    }
  }

  writeJson(SESSION_FILE, state)

  // Obsidian : uniquement si session non triviale (>= 2 échanges)
  if (state.responseCount >= 2) {
    const inlineTopics = extractTopicsInline(state)
    writeObsidianNote(adaCfg, state, inlineTopics)
  }

  // Webhook dispatch — session.end (adaCfg partagé, pas de double lecture)
  dispatchWebhook('session.end', { responseCount: state.responseCount, project: PROJECT_ID }, adaCfg)
}

if (require.main === module) {
  let raw = ''
  process.stdin.setEncoding('utf8')
  process.stdin.on('data', chunk => { raw += chunk })
  process.stdin.on('end', () => {
    try { run() } catch {}
    process.exit(0)
  })
  process.stdin.on('error', () => process.exit(0))
  setTimeout(() => process.exit(0), 3000)
} else {
  // P-fusion : exporté pour être appelé in-process par stop-hook (un seul process Stop).
  module.exports = { run, updateCacheTimestamp, checkCacheExpiry, CACHE_TTL_MS, CACHE_KEEPALIVE_FILE }
}
