#!/usr/bin/env node
// skill-cache.js — PostToolUse hook sur Read
// Objectif : éviter qu'un agent relise un skill déjà lu dans la même session.
//
// Fonctionnement :
//   1. Quand un agent lit un fichier skills/**/**.md → on l'enregistre dans le cache
//   2. Avant chaque lecture, l'agent peut consulter le cache (via Read sur skill-cache.txt)
//      mais le vrai guard est dans les agents eux-mêmes (règle "vérifier le cache")
//   3. Le cache est vidé automatiquement après 2h (nouvelle session) ou via /compact
//
// Ce hook gère uniquement l'écriture du cache.
// La lecture du cache est faite par les agents via : cat $CACHE_FILE

const { readFileSync, writeFileSync, existsSync, mkdirSync } = require('fs')
const { join } = require('path')

const CONFIG_DIR  = process.env.CLAUDE_CONFIG_DIR || join(process.env.HOME, '.claude')
const CACHE_FILE  = join(CONFIG_DIR, 'session-skill-cache.json')

// Lire le payload depuis stdin — lecture synchrone (fd 0), compatible CJS.
let raw = ''
try { raw = readFileSync(0, 'utf8') } catch { /* pas de stdin */ }

let payload = {}
try { payload = JSON.parse(raw) } catch { process.exit(0) }

const filePath = payload.tool_input?.path || ''

// N'agir que si c'est la lecture d'un fichier skill
if (!filePath.includes('/skills/') || !filePath.endsWith('.md')) {
  process.exit(0)
}

// Extraire le skill key : "agent/skill-name"
// ex: ~/.claude/skills/nestjs/create-module.md → "nestjs/create-module"
const skillMatch = filePath.match(/skills\/([^/]+)\/([^/]+)\.md$/)
if (!skillMatch) process.exit(0)

const skillKey = `${skillMatch[1]}/${skillMatch[2]}`

// Lire ou créer le cache
const cache = readCache()

// Déjà dans le cache — rien à faire
if (cache.skills[skillKey]) process.exit(0)

// Ajouter au cache
cache.skills[skillKey] = {
  readAt: new Date().toISOString(),
  file: filePath,
}
cache.lastUpdated = new Date().toISOString()
cache.count = Object.keys(cache.skills).length

writeCache(cache)
process.exit(0)

// ─── Fonctions ────────────────────────────────────────────────────────────────

function readCache() {
  try {
    if (existsSync(CACHE_FILE)) {
      const data = JSON.parse(readFileSync(CACHE_FILE, 'utf8'))
      // Expirer si > 2h
      const last = new Date(data.lastUpdated || 0)
      const diffH = (new Date() - last) / 1000 / 3600
      if (diffH > 2) return emptyCache()
      return data
    }
  } catch { /* ignore */ }
  return emptyCache()
}

function emptyCache() {
  return { skills: {}, count: 0, lastUpdated: new Date().toISOString() }
}

function writeCache(cache) {
  try {
    const dir = CONFIG_DIR
    if (!existsSync(dir)) mkdirSync(dir, { recursive: true })
    writeFileSync(CACHE_FILE, JSON.stringify(cache, null, 2), 'utf8')
  } catch { /* ne jamais bloquer */ }
}
