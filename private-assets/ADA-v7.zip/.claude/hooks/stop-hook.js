#!/usr/bin/env node
'use strict'
// stop-hook.js — Stop hook Claude Code
// Déclenché quand Claude Code s'apprête à terminer sa réponse.
// Si la session a eu ≥ 3 échanges et que le résumé n'a pas encore été fait,
// injecte un rappel pour forcer /summarize.
// Retour : exit 0 = laisser passer | exit 2 = bloquer + injecter du contexte

const { readFileSync, writeFileSync, existsSync, mkdirSync } = require('fs')
const { join } = require('path')

const CONFIG_DIR   = process.env.CLAUDE_CONFIG_DIR || join(process.env.HOME || require('os').homedir(), '.claude')
const PROJECT_ID   = process.env.AI_DEV_PROJECT    || detectProjectFromCwd()
const SESSION_FILE = join(CONFIG_DIR, 'session-state.json')

// Lire le payload JSON depuis stdin (event-based, compatible CJS)
let raw = ''
process.stdin.setEncoding('utf8')
process.stdin.on('data', chunk => { raw += chunk })
process.stdin.on('end', () => {
  let payload = {}
  try { payload = JSON.parse(raw) } catch { process.exit(0) }

  // Éviter les boucles infinies — si Claude Code a déjà relancé le stop hook
  if (payload.stop_hook_active) process.exit(0)

  // Télémétrie tokens RÉELLE — parse le transcript (usage par tour) et persiste.
  // Best-effort, jamais bloquant.
  if (payload.transcript_path) {
    try {
      const ttPath = require('path').join(
        process.env.CLAUDE_CONFIG_DIR || require('path').join(require('os').homedir(), '.claude'),
        'coordinator', 'token-telemetry.js'
      )
      require(ttPath).record(payload.transcript_path, payload.session_id)
    } catch { /* token-telemetry absent ou erreur — no-op */ }
  }

  // Fusion hooks : exécuter la logique session-end DANS ce process (un seul process Stop
  // au lieu de deux → -1 cold-start node/réponse). session-end n'auto-exécute pas quand
  // requis (guard require.main). Best-effort, ne bloque jamais le stop-hook.
  try { require('./session-end.js').run() } catch { /* session-end absent/erreur — no-op */ }

  // Lire ou initialiser l'état de session
  const state = readSessionState()

  // Incrémenter le compteur d'échanges
  state.exchanges = (state.exchanges || 0) + 1
  state.project   = PROJECT_ID
  state.lastActive = new Date().toISOString()

  // Détecter si /summarize a déjà été lancé dans cette session
  const alreadySummarized = state.summarized === true

  // Seuil : 3 échanges minimum avant de suggérer /summarize
  // Seuil haut : 6 échanges → forcer (proche du auto-compact à 7)
  const SOFT_THRESHOLD = 3
  const HARD_THRESHOLD = 6

  writeSessionState(state)

  if (!alreadySummarized && state.exchanges >= HARD_THRESHOLD) {
    const message = buildReminderMessage(state, true)
    process.stdout.write(message)
    process.exit(2)
  }

  if (!alreadySummarized && state.exchanges >= SOFT_THRESHOLD) {
    const message = buildReminderMessage(state, false)
    process.stdout.write(message)
    process.exit(2)
  }

  process.exit(0)
})

process.stdin.on('error', () => process.exit(0))

// Timeout de sécurité
setTimeout(() => process.exit(0), 3000)

// ─── Fonctions ────────────────────────────────────────────────────────────────

function buildReminderMessage(state, hard) {
  const prefix = hard
    ? 'SESSION LONGUE DETECTEE'
    : 'Rappel de sauvegarde'

  const action = hard
    ? 'Lance /summarize MAINTENANT avant de continuer pour ne pas perdre le contexte.'
    : 'Pense a lancer /summarize avant de fermer la session pour sauvegarder le contexte.'

  return [
    `[stop-hook] ${prefix}`,
    `Echanges : ${state.exchanges} | Projet : ${state.project}`,
    action,
    `Commande : /summarize`,
    '',
  ].join('\n')
}

function readSessionState() {
  try {
    if (existsSync(SESSION_FILE)) {
      const data = JSON.parse(readFileSync(SESSION_FILE, 'utf8'))
      const last = new Date(data.lastActive || 0)
      const now  = new Date()
      const diffH = (now - last) / 1000 / 3600
      if (diffH > 2) return { exchanges: 0, summarized: false }
      return data
    }
  } catch {}
  return { exchanges: 0, summarized: false }
}

function writeSessionState(state) {
  try {
    if (!existsSync(CONFIG_DIR)) mkdirSync(CONFIG_DIR, { recursive: true })
    writeFileSync(SESSION_FILE, JSON.stringify(state, null, 2), 'utf8')
  } catch {}
}

function detectProjectFromCwd() {
  try {
    const path = require('path')
    const cwd    = process.cwd()
    const pkg    = path.join(cwd, 'package.json')
    const pyproj = path.join(cwd, 'pyproject.toml')
    if (existsSync(pkg)) {
      const { name } = JSON.parse(readFileSync(pkg, 'utf8'))
      if (name) return name.replace(/[^a-z0-9-]/gi, '-').toLowerCase()
    }
    if (existsSync(pyproj)) {
      const match = readFileSync(pyproj, 'utf8').match(/^name\s*=\s*"([^"]+)"/m)
      if (match) return match[1].replace(/[^a-z0-9-]/gi, '-').toLowerCase()
    }
    return path.basename(cwd).replace(/[^a-z0-9-]/gi, '-').toLowerCase() || 'workspace'
  } catch {
    return 'workspace'
  }
}
