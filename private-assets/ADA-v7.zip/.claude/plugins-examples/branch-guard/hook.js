'use strict'

const { spawnSync } = require('child_process')

const PROTECTED = new Set(['main', 'master'])

/**
 * @param {string} cmd
 * @returns {null | { block: true, reason: string } | { warn: true, reason: string }}
 */
function check(cmd) {
  const trimmed = cmd.trim()
  if (!/^git\s+(commit|push)/.test(trimmed)) return null

  const result = spawnSync('git', ['branch', '--show-current'], {
    encoding: 'utf8',
    timeout:  1000
  })
  if (result.status !== 0 || result.error) return null

  const branch = (result.stdout || '').trim()
  if (!branch || !PROTECTED.has(branch)) return null

  return {
    block: true,
    reason: `Commits directs sur ${branch} interdits — utiliser une feature branch`
  }
}

module.exports = check
