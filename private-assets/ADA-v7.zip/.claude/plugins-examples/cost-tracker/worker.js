'use strict'
/**
 * plugins-examples/cost-tracker/worker.js
 * Enregistre le coût LLM estimé par phase dans logs/cost.log
 *
 * Déclenchement : hook git-commit
 * Variables d'environnement :
 *   PLUGIN_EVENT  — nom de l'événement (ex: "git-commit")
 *   PLUGIN_DATA   — données JSON de l'événement (ex: { sha, message })
 *   CLAUDE_CONFIG_DIR — répertoire de config Claude
 */

const { existsSync, readFileSync, appendFileSync, mkdirSync } = require('fs')
const { join } = require('path')

const COST_PER_TIER = { 1: 0.001, 2: 0.005, 3: 0.015 }

function main() {
  const event = process.env.PLUGIN_EVENT || ''

  if (event !== 'git-commit') return

  const configDir = process.env.CLAUDE_CONFIG_DIR || join(process.env.HOME, '.claude')
  const bankPath  = join(configDir, 'coordinator', 'bank-state.json')

  // Lire les données de l'événement (silencieux si absent)
  let sha = 'unknown'
  try {
    const raw = process.env.PLUGIN_DATA
    if (raw) {
      const data = JSON.parse(raw)
      sha = data.sha || data.commit || 'unknown'
    }
  } catch {}

  // Lire bank-state.json pour compter les trajectoires du dernier run
  let phases = 0
  let estimatedCost = 0

  try {
    if (existsSync(bankPath)) {
      const bank = JSON.parse(readFileSync(bankPath, 'utf8'))
      const trajs = bank.trajectories || []
      phases = trajs.length

      // Calculer le coût estimé en sommant par tier
      for (const traj of trajs) {
        const tier = traj.tier || 1
        const costPerPhase = COST_PER_TIER[tier] || COST_PER_TIER[1]
        estimatedCost += costPerPhase
      }
    }
  } catch {}

  // Appender dans logs/cost.log
  try {
    const logsDir = join(configDir, 'logs')
    if (!existsSync(logsDir)) mkdirSync(logsDir, { recursive: true })

    const logPath = join(logsDir, 'cost.log')
    const ts      = new Date().toISOString()
    const line    = `[${ts}] commit: ${sha} | estimé: $${estimatedCost.toFixed(3)} | phases: ${phases}\n`
    appendFileSync(logPath, line, 'utf8')
  } catch {}
}

main()
