'use strict'
/**
 * plugins-examples/lint-guard/hook.js
 * Bloque le commit si des fichiers JS stagés ont des erreurs de syntaxe
 *
 * Export : check(cmd) → { block: true, reason: string } | null
 */

const { spawnSync } = require('child_process')

/**
 * @param {string} cmd — la commande interceptée (ex: "git commit -m 'feat: ...'")
 * @returns {{ block: true, reason: string } | null}
 */
function check(cmd) {
  if (typeof cmd !== 'string' || !cmd.match(/git\s+commit/)) return null

  // Lister les fichiers stagés
  let stagedResult
  try {
    stagedResult = spawnSync(
      'git',
      ['diff', '--cached', '--name-only', '--diff-filter=ACM'],
      { encoding: 'utf8', timeout: 5000 }
    )
  } catch {
    return null
  }

  if (stagedResult.status !== 0 || !stagedResult.stdout) return null

  const jsFiles = stagedResult.stdout
    .split('\n')
    .map(f => f.trim())
    .filter(f => f.endsWith('.js'))

  if (jsFiles.length === 0) return null

  // Vérifier la syntaxe de chaque fichier JS avec node --check
  for (const file of jsFiles) {
    try {
      const r = spawnSync('node', ['--check', file], {
        encoding: 'utf8',
        timeout: 5000
      })
      if (r.status !== 0) {
        return { block: true, reason: `Erreur syntaxe JS: ${file}` }
      }
    } catch {
      // Silencieux sur erreur système
    }
  }

  return null
}

module.exports = { check }
