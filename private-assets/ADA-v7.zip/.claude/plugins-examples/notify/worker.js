#!/usr/bin/env node
'use strict'

const { spawnSync } = require('child_process')

const eventType = process.env.PLUGIN_EVENT || ''
let data = {}
try { data = JSON.parse(process.env.PLUGIN_DATA || '{}') } catch {}

function notify(title, message) {
  const result = spawnSync('which', ['osascript'], { encoding: 'utf8' })
  if (result.status !== 0) return
  spawnSync('osascript', [
    '-e',
    `display notification "${message.replace(/"/g, '\\"')}" with title "${title.replace(/"/g, '\\"')}"`
  ], { timeout: 3000 })
}

switch (eventType) {
  case 'git-push': {
    const branch = data.branch || 'unknown'
    notify('AI-Dev-Assistant', `Pushed to ${branch}`)
    break
  }
  case 'test-js':
  case 'test-py': {
    const failed = data.failed || 0
    const errors = data.errors || 0
    const total  = failed + errors
    if (total > 0) {
      notify('AI-Dev-Assistant — Tests', `${total} test${total > 1 ? 's' : ''} failed`)
    }
    break
  }
  case 'cve-critical': {
    const critical = data.critical || 0
    const project  = data.project  || 'unknown'
    if (critical > 0) {
      notify('AI-Dev-Assistant — CVE', `⚠️ ${critical} CVE critiques dans ${project}`)
    }
    break
  }
}

process.exit(0)
