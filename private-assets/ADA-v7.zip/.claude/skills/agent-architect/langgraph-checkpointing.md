# langgraph-checkpointing
MemorySaver (dev), PostgresSaver (prod), reprise de session, snapshot state.

## MemorySaver (développement)
```python
from langgraph.checkpoint.memory import MemorySaver

memory = MemorySaver()
app = graph.compile(checkpointer=memory)

config = {"configurable": {"thread_id": "conversation-123"}}
result = await app.ainvoke({"messages": [...]}, config=config)

# Reprendre la session
result2 = await app.ainvoke({"messages": [HumanMessage("suite")]}, config=config)
```

## PostgresSaver (production)
```python
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
import asyncpg

async def get_checkpointer():
    conn = await asyncpg.connect(DATABASE_URL)
    checkpointer = AsyncPostgresSaver(conn)
    await checkpointer.setup()  # crée les tables si absent
    return checkpointer

app = graph.compile(checkpointer=await get_checkpointer())
```

## Inspecter un checkpoint
```python
snapshot = await app.aget_state(config)
print(snapshot.values)       # état actuel
print(snapshot.next)         # prochains nœuds
print(snapshot.created_at)   # timestamp
```
