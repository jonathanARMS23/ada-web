# langgraph-stategraph
StateGraph, TypedDict state, Annotated reducers (add_messages), compilation.

## Setup de base
```python
from langgraph.graph import StateGraph, END
from langgraph.graph.message import add_messages
from typing import TypedDict, Annotated

class AgentState(TypedDict):
    messages: Annotated[list, add_messages]  # reducer automatique
    current_agent: str
    iteration: int
    result: str | None

graph = StateGraph(AgentState)
```

## Nœuds et edges
```python
async def router_node(state: AgentState) -> AgentState:
    last_msg = state["messages"][-1].content
    agent = classify_intent(last_msg)
    return {"current_agent": agent, "iteration": state["iteration"] + 1}

graph.add_node("router", router_node)
graph.add_node("worker_a", worker_a_node)
graph.add_node("worker_b", worker_b_node)

graph.set_entry_point("router")
graph.add_conditional_edges("router", lambda s: s["current_agent"], {
    "worker_a": "worker_a",
    "worker_b": "worker_b",
    "done": END,
})
graph.add_edge("worker_a", "router")
graph.add_edge("worker_b", "router")

app = graph.compile()
```

## Invocation
```python
result = await app.ainvoke({
    "messages": [HumanMessage(content="Bonjour")],
    "current_agent": "",
    "iteration": 0,
    "result": None,
})
```
