# parallel-subgraph
Skill : parallel-subgraph — agent agent-architect.
