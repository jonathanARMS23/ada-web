# react-loop
Reason-Act loop, Thought/Action/Observation cycle, MAX_ITERATIONS, terminaison.

## ReAct avec LangGraph
```python
from langchain_core.tools import tool

MAX_ITERATIONS = 10

@tool
def search_web(query: str) -> str:
    """Recherche sur le web."""
    return web_search(query)

@tool
def execute_python(code: str) -> str:
    """Exécute du code Python dans un sandbox."""
    return sandbox.run(code)

TOOLS = [search_web, execute_python]
TOOL_MAP = {t.name: t for t in TOOLS}

async def agent_node(state: AgentState) -> AgentState:
    if state["iteration"] >= MAX_ITERATIONS:
        return {"result": "MAX_ITERATIONS atteint", "current_agent": "FINISH"}
    
    response = await llm_with_tools.complete(state["messages"])
    
    if response.tool_calls:
        tool_results = []
        for call in response.tool_calls:
            result = await TOOL_MAP[call.name].ainvoke(call.args)
            tool_results.append(ToolMessage(content=str(result), tool_call_id=call.id))
        return {"messages": [response, *tool_results]}
    
    return {"result": response.content, "current_agent": "FINISH"}
```
