# supervisor-pattern
Supervisor node, classification d'intention, délégation dynamique aux workers.

## Supervisor avec LLM routing
```python
from langchain_core.messages import HumanMessage, AIMessage
import json

WORKERS = ["researcher", "coder", "reviewer"]

SUPERVISOR_PROMPT = f"""Tu es un superviseur. Analyse la demande et délègue au bon worker.
Workers disponibles : {', '.join(WORKERS)}
Réponds en JSON : {{"next": "<worker_name>", "reason": "<pourquoi>"}}
Si la tâche est terminée : {{"next": "FINISH", "reason": "<synthèse>"}}"""

async def supervisor_node(state: AgentState) -> AgentState:
    response = await llm.complete([
        {"role": "system", "content": SUPERVISOR_PROMPT},
        *[{"role": m.type, "content": m.content} for m in state["messages"]],
    ])
    decision = json.loads(response.content)
    return {"current_agent": decision["next"]}

# Routing conditionnel
def route(state: AgentState) -> str:
    agent = state["current_agent"]
    return END if agent == "FINISH" else agent
```
