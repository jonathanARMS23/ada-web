# context-window-management
Sliding window, token counting (tiktoken), summarization trigger, truncation strategy.

## Token counting
```python
import tiktoken

def count_tokens(messages: list[dict], model: str = "gpt-4") -> int:
    enc = tiktoken.encoding_for_model(model)
    total = 0
    for m in messages:
        total += 4  # overhead par message
        total += len(enc.encode(m["content"]))
    return total + 2  # overhead global

def fits_in_window(messages, model: str, max_tokens: int = 4096) -> bool:
    return count_tokens(messages, model) < max_tokens * 0.85  # 15% de marge
```

## Sliding window
```python
def sliding_window(messages: list[dict], max_tokens: int = 4096) -> list[dict]:
    """Garde le system prompt + les N derniers messages qui rentrent."""
    system = [m for m in messages if m["role"] == "system"]
    history = [m for m in messages if m["role"] != "system"]
    
    result = system.copy()
    for msg in reversed(history):
        candidate = result + [msg]
        if count_tokens(candidate) < max_tokens * 0.8:
            result.insert(len(system), msg)
        else:
            break
    return result
```

## Summarization trigger (à ~80% de la fenêtre)
```python
async def maybe_summarize(messages, provider, threshold=0.8):
    if count_tokens(messages) / MAX_TOKENS > threshold:
        summary = await provider.complete([
            *messages,
            {"role": "user", "content": "Résume la conversation en 3-5 points clés."}
        ])
        return [messages[0], {"role": "assistant", "content": f"[Résumé]: {summary.content}"}]
    return messages
```
