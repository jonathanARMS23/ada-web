# llm-provider-pattern
Protocol abstrait LLMProvider, implémentations DeepSeek + Local, interface commune.

## Interface abstraite
```python
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import AsyncIterator

@dataclass
class LLMMessage:
    role: str  # "system" | "user" | "assistant"
    content: str

@dataclass
class LLMResponse:
    content: str
    model: str
    prompt_tokens: int
    completion_tokens: int
    latency_ms: float

class LLMProvider(ABC):
    @abstractmethod
    async def complete(self, messages: list[LLMMessage], **kwargs) -> LLMResponse: ...
    
    @abstractmethod
    async def stream(self, messages: list[LLMMessage], **kwargs) -> AsyncIterator[str]: ...
    
    @abstractmethod
    async def health_check(self) -> bool: ...
```

## Implémentation DeepSeek/OpenAI
```python
import httpx, time

class OpenAIProvider(LLMProvider):
    def __init__(self, api_key: str, model: str, base_url: str = "https://api.openai.com/v1"):
        self.client = httpx.AsyncClient(
            base_url=base_url,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=30.0
        )
        self.model = model

    async def complete(self, messages, temperature=0.7, max_tokens=2048) -> LLMResponse:
        start = time.monotonic()
        r = await self.client.post("/chat/completions", json={
            "model": self.model,
            "messages": [{"role": m.role, "content": m.content} for m in messages],
            "temperature": temperature,
            "max_tokens": max_tokens,
        })
        r.raise_for_status()
        data = r.json()
        return LLMResponse(
            content=data["choices"][0]["message"]["content"],
            model=data["model"],
            prompt_tokens=data["usage"]["prompt_tokens"],
            completion_tokens=data["usage"]["completion_tokens"],
            latency_ms=(time.monotonic() - start) * 1000,
        )

    async def health_check(self) -> bool:
        try:
            r = await self.client.get("/models", timeout=5.0)
            return r.status_code == 200
        except Exception:
            return False
```
