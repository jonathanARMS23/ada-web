# llm-retry-fallback
tenacity retry exponentiel, circuit breaker, fallback API→Local automatique.

## Retry avec tenacity
```python
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
import httpx

@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=1, max=10),
    retry=retry_if_exception_type((httpx.TimeoutException, httpx.HTTPStatusError)),
    reraise=True
)
async def call_with_retry(provider, messages, **kwargs):
    return await provider.complete(messages, **kwargs)
```

## Fallback API → Local
```python
class FallbackRouter:
    def __init__(self, primary: LLMProvider, fallback: LLMProvider):
        self.primary = primary
        self.fallback = fallback
        self._primary_failures = 0
        self._circuit_open = False

    async def complete(self, messages, **kwargs):
        if self._circuit_open:
            return await self.fallback.complete(messages, **kwargs)
        try:
            result = await call_with_retry(self.primary, messages, **kwargs)
            self._primary_failures = 0
            return result
        except Exception:
            self._primary_failures += 1
            if self._primary_failures >= 3:
                self._circuit_open = True
                asyncio.create_task(self._reset_circuit_after(60))
            return await self.fallback.complete(messages, **kwargs)

    async def _reset_circuit_after(self, seconds: int):
        await asyncio.sleep(seconds)
        self._circuit_open = False
        self._primary_failures = 0
```
