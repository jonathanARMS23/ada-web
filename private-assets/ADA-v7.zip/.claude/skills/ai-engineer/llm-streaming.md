# llm-streaming
Streaming SSE token-by-token, chunked response, AsyncIterator, affichage progressif client.

## Stream depuis OpenAI/DeepSeek
```python
async def stream(self, messages, temperature=0.7) -> AsyncIterator[str]:
    async with self.client.stream("POST", "/chat/completions", json={
        "model": self.model,
        "messages": [{"role": m.role, "content": m.content} for m in messages],
        "temperature": temperature,
        "stream": True,
    }) as response:
        async for line in response.aiter_lines():
            if not line.startswith("data: "):
                continue
            data = line[6:]
            if data == "[DONE]":
                return
            chunk = json.loads(data)
            delta = chunk["choices"][0]["delta"].get("content", "")
            if delta:
                yield delta
```

## Endpoint FastAPI SSE
```python
from fastapi.responses import StreamingResponse

@router.post("/chat/stream")
async def chat_stream(request: ChatRequest):
    async def generate():
        async for token in provider.stream(request.messages):
            yield f"data: {json.dumps({'token': token})}\n\n"
        yield "data: [DONE]\n\n"
    
    return StreamingResponse(generate(), media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})
```
