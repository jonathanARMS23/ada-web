# prompt-engineering
ChatML format, system prompts, few-shot, chain-of-thought, JSON mode, rôles.

## Structure de base
```python
messages = [
    {"role": "system", "content": "Tu es un assistant expert en Python."},
    {"role": "user",   "content": "Comment optimiser cette requête SQL ?"},
]
```

## Few-shot (2-3 exemples max)
```python
few_shot = [
    {"role": "user",      "content": "Traduis : 'Hello World'"},
    {"role": "assistant", "content": "Bonjour le monde"},
    {"role": "user",      "content": "Traduis : 'Goodbye'"},
    {"role": "assistant", "content": "Au revoir"},
    {"role": "user",      "content": f"Traduis : '{input_text}'"},
]
```

## Chain-of-thought
```python
cot_system = """Résous le problème étape par étape :
1. Analyse ce qui est demandé
2. Décompose en sous-problèmes
3. Résous chaque partie
4. Synthétise la réponse finale"""
```

## JSON mode (forcer la structure)
```python
json_system = """Réponds UNIQUEMENT en JSON valide, sans markdown ni explication.
Format attendu : {"result": ..., "confidence": 0.0-1.0, "reasoning": "..."}"""
```

## Règles
- System prompt : rôle + contraintes + format de sortie
- Jamais de "Bien sûr !" ou de filler — aller direct
- Temperature 0.0-0.2 pour les tâches déterministes, 0.7-0.9 pour la créativité
- max_tokens = estimation × 1.5 pour éviter les troncatures
