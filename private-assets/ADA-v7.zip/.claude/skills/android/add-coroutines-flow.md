# add-coroutines-flow
Flow dans ViewModel : StateFlow, SharedFlow, collectAsState.

```kotlin
@HiltViewModel
class ResourceViewModel @Inject constructor(
    private val repository: ResourceRepository,
) : ViewModel() {

    // StateFlow pour l'état UI (dernière valeur toujours disponible)
    private val _uiState = MutableStateFlow<ResourceUiState>(ResourceUiState.Loading)
    val uiState: StateFlow<ResourceUiState> = _uiState.asStateFlow()

    // SharedFlow pour les événements one-shot (navigation, toast)
    private val _events = MutableSharedFlow<ResourceEvent>()
    val events: SharedFlow<ResourceEvent> = _events.asSharedFlow()

    init {
        viewModelScope.launch {
            repository.observeResources()
                .catch { e -> _uiState.value = ResourceUiState.Error(e.message) }
                .collect { resources -> _uiState.value = ResourceUiState.Success(resources) }
        }
    }

    fun deleteResource(id: String) {
        viewModelScope.launch {
            repository.delete(id)
                .onSuccess { _events.emit(ResourceEvent.Deleted) }
                .onFailure { _events.emit(ResourceEvent.Error("Suppression échouée")) }
        }
    }
}

// Dans le Composable
val events = viewModel.events.collectAsStateWithLifecycle(initialValue = null)
LaunchedEffect(events.value) {
    when (val event = events.value) {
        is ResourceEvent.Deleted -> navController.popBackStack()
        is ResourceEvent.Error -> snackbarHostState.showSnackbar(event.message)
        null -> {}
    }
}
```
