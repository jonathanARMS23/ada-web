# add-crashlytics
Firebase Crashlytics avec logs et error boundaries.

```kotlin
// build.gradle.kts
plugins { id("com.google.firebase.crashlytics") }
dependencies { implementation("com.google.firebase:firebase-crashlytics-ktx") }
```

```kotlin
// Logger custom avec Crashlytics
object CrashReporter {
    fun log(message: String) = FirebaseCrashlytics.getInstance().log(message)

    fun setUser(userId: String) = FirebaseCrashlytics.getInstance().setUserId(userId)

    fun recordException(e: Throwable, context: String? = null) {
        context?.let { FirebaseCrashlytics.getInstance().log("Context: $it") }
        FirebaseCrashlytics.getInstance().recordException(e)
    }

    fun setCustomKey(key: String, value: String) =
        FirebaseCrashlytics.getInstance().setCustomKey(key, value)
}

// Dans le Repository
suspend fun getResources(): Result<List<Resource>> = try {
    Result.success(api.getResources())
} catch (e: Exception) {
    CrashReporter.recordException(e, "ResourceRepository.getResources")
    Result.failure(e)
}
```
