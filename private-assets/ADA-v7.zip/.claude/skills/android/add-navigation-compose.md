# add-navigation-compose
Navigation Compose avec routes, args et deep links.

```kotlin
// NavGraph.kt
@Composable
fun AppNavGraph(navController: NavHostController) {
    NavHost(navController, startDestination = "resources") {
        composable("resources") {
            ResourceListScreen(onNavigateToDetail = { id ->
                navController.navigate("resources/$id")
            })
        }
        composable(
            route = "resources/{resourceId}",
            arguments = listOf(navArgument("resourceId") { type = NavType.StringType }),
            deepLinks = listOf(navDeepLink { uriPattern = "myapp://resources/{resourceId}" }),
        ) { backStackEntry ->
            val id = backStackEntry.arguments?.getString("resourceId") ?: return@composable
            ResourceDetailScreen(resourceId = id, onBack = navController::popBackStack)
        }
        composable("resources/create") {
            CreateResourceScreen(onSuccess = { navController.popBackStack() })
        }
    }
}
```
