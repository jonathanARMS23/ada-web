# create-composable-screen
Screen Jetpack Compose avec state hoisting et preview.

```kotlin
@Composable
fun ResourceListScreen(
    viewModel: ResourceViewModel = hiltViewModel(),
    onNavigateToDetail: (String) -> Unit,
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    ResourceListContent(
        uiState = uiState,
        onResourceClick = onNavigateToDetail,
        onRetry = viewModel::loadResources,
    )
}

@Composable
private fun ResourceListContent(
    uiState: ResourceUiState,
    onResourceClick: (String) -> Unit,
    onRetry: () -> Unit,
) {
    when (uiState) {
        ResourceUiState.Loading -> CircularProgressIndicator(modifier = Modifier.fillMaxSize().wrapContentCenter())
        is ResourceUiState.Success -> LazyColumn {
            items(uiState.resources, key = { it.id }) { resource ->
                ResourceItem(resource = resource, onClick = { onResourceClick(resource.id) })
            }
        }
        is ResourceUiState.Error -> ErrorScreen(message = uiState.message, onRetry = onRetry)
    }
}

@Preview(showBackground = true)
@Composable
private fun ResourceListPreview() {
    ResourceListContent(
        uiState = ResourceUiState.Success(listOf(Resource("1", "Test"))),
        onResourceClick = {}, onRetry = {},
    )
}
```
