# create-feature-module
Module feature Android MVVM complet.

## Structure
```
feature/<name>/
  di/
    <Name>Module.kt       # Hilt module
  domain/
    model/<Name>.kt       # Data class
    repository/<Name>Repository.kt  # Interface
    usecase/Get<Name>UseCase.kt
  data/
    repository/<Name>RepositoryImpl.kt
    remote/<Name>Api.kt   # Retrofit
    local/<Name>Dao.kt    # Room
  presentation/
    <Name>ViewModel.kt
    <Name>Screen.kt       # Composable
    <Name>UiState.kt      # Sealed class
```

## ViewModel
```kotlin
@HiltViewModel
class ResourceViewModel @Inject constructor(
    private val getResources: GetResourcesUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow<ResourceUiState>(ResourceUiState.Loading)
    val uiState: StateFlow<ResourceUiState> = _uiState.asStateFlow()

    init { loadResources() }

    private fun loadResources() {
        viewModelScope.launch {
            getResources()
                .onSuccess { _uiState.value = ResourceUiState.Success(it) }
                .onFailure { _uiState.value = ResourceUiState.Error(it.message) }
        }
    }
}

sealed class ResourceUiState {
    object Loading : ResourceUiState()
    data class Success(val resources: List<Resource>) : ResourceUiState()
    data class Error(val message: String?) : ResourceUiState()
}
```
