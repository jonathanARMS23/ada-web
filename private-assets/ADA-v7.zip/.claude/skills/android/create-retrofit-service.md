# create-retrofit-service
Service Retrofit avec intercepteurs et error handling.

```kotlin
interface ResourceApi {
    @GET("resources")
    suspend fun getResources(@Query("page") page: Int = 1): ResourcesResponse

    @POST("resources")
    suspend fun createResource(@Body request: CreateResourceRequest): Resource

    @PATCH("resources/{id}")
    suspend fun updateResource(@Path("id") id: String, @Body request: UpdateResourceRequest): Resource
}

// Intercepteur d'authentification
class AuthInterceptor @Inject constructor(
    private val tokenStorage: TokenStorage,
) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val token = tokenStorage.getAccessToken() ?: return chain.proceed(chain.request())
        val request = chain.request().newBuilder()
            .addHeader("Authorization", "Bearer $token")
            .build()
        val response = chain.proceed(request)
        if (response.code == 401) tokenStorage.clearTokens()
        return response
    }
}

// Extension pour gestion d'erreurs
suspend fun <T> safeApiCall(apiCall: suspend () -> T): Result<T> = try {
    Result.success(apiCall())
} catch (e: HttpException) {
    Result.failure(ApiException(e.code(), e.message()))
} catch (e: IOException) {
    Result.failure(NetworkException("No network"))
}
```
