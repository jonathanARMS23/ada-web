# create-room-entity
Entity Room avec DAO, migrations, relations.

```kotlin
@Entity(tableName = "resources")
data class ResourceEntity(
    @PrimaryKey val id: String,
    val workspaceId: String,
    val name: String,
    val status: String,
    val createdAt: Long,  // epoch millis
    val synced: Boolean = false,
)

@Dao
interface ResourceDao {
    @Query("SELECT * FROM resources WHERE workspaceId = :workspaceId ORDER BY createdAt DESC")
    fun observeAll(workspaceId: String): Flow<List<ResourceEntity>>

    @Upsert
    suspend fun upsert(resources: List<ResourceEntity>)

    @Query("DELETE FROM resources WHERE id = :id")
    suspend fun delete(id: String)

    @Query("SELECT * FROM resources WHERE synced = 0")
    suspend fun getPendingSync(): List<ResourceEntity>
}

// Migration
val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(database: SupportSQLiteDatabase) {
        database.execSQL("ALTER TABLE resources ADD COLUMN synced INTEGER NOT NULL DEFAULT 0")
    }
}
```
