# create-work-manager
WorkManager pour tâches background : constraints et chaining.

```kotlin
class SyncWorker(
    context: Context,
    params: WorkerParameters,
    @Assisted private val repository: ResourceRepository,
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        return try {
            val count = repository.syncPendingResources()
            Result.success(workDataOf("synced_count" to count))
        } catch (e: Exception) {
            if (runAttemptCount < 3) Result.retry() else Result.failure()
        }
    }
}

// Planifier avec contraintes
fun scheduleSyncWork(workManager: WorkManager) {
    val constraints = Constraints.Builder()
        .setRequiredNetworkType(NetworkType.CONNECTED)
        .setRequiresBatteryNotLow(true)
        .build()

    val request = PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES)
        .setConstraints(constraints)
        .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 1, TimeUnit.MINUTES)
        .build()

    workManager.enqueueUniquePeriodicWork(
        "sync_resources",
        ExistingPeriodicWorkPolicy.KEEP,
        request,
    )
}
```
