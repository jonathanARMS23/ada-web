# write-viewmodel-tests
Tests ViewModel avec Mockk et Turbine pour Flow.

## Template
```kotlin
@ExtendWith(CoroutinesTestExtension::class)
class ResourceViewModelTest {

    private val getResources: GetResourcesUseCase = mockk()
    private lateinit var viewModel: ResourceViewModel

    @BeforeEach
    fun setup() {
        viewModel = ResourceViewModel(getResources)
    }

    @Test
    fun `should emit Success when resources loaded`() = runTest {
        val resources = listOf(Resource(id = "1", name = "Test"))
        coEvery { getResources() } returns Result.success(resources)

        viewModel.uiState.test {
            val state = awaitItem()
            assertThat(state).isInstanceOf(ResourceUiState.Success::class.java)
            assertThat((state as ResourceUiState.Success).resources).isEqualTo(resources)
            cancelAndIgnoreRemainingEvents()
        }
    }

    @Test
    fun `should emit Error when loading fails`() = runTest {
        coEvery { getResources() } returns Result.failure(Exception("Network error"))

        viewModel.uiState.test {
            val state = awaitItem()
            assertThat(state).isInstanceOf(ResourceUiState.Error::class.java)
        }
    }
}
```
