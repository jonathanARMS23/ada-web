# design-auth-endpoints
Endpoints auth complets.

```
POST /api/v1/auth/register
  Body : { email, password, name }
  → 201 { user: { id, email, name }, accessToken, refreshToken }

POST /api/v1/auth/login
  Body : { email, password }
  → 200 { user, accessToken, refreshToken }
  → 401 INVALID_CREDENTIALS (pas de distinction email/password)

POST /api/v1/auth/refresh
  Body : { refreshToken }
  → 200 { accessToken, refreshToken }  (rotation obligatoire)
  → 401 INVALID_REFRESH_TOKEN

POST /api/v1/auth/logout
  Auth : Bearer
  Body : { refreshToken }
  → 204

POST /api/v1/auth/forgot-password
  Body : { email }
  → 204 (toujours, même si email inconnu — anti-enumeration)

POST /api/v1/auth/reset-password
  Body : { token, newPassword }
  → 204 | 400 INVALID_TOKEN | 400 TOKEN_EXPIRED

GET /api/v1/auth/me
  Auth : Bearer
  → 200 { id, email, name, workspace }
```
