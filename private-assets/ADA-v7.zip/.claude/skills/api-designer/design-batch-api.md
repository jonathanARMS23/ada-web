# design-batch-api
API batch : opérations bulk avec partial success.

## Endpoint bulk create
```
POST /api/v1/resources/batch
Body : { items: [{ name, status }, ...] }  (max 100 items)

→ 207 Multi-Status
{
  "results": [
    { "index": 0, "status": 201, "data": { id, name } },
    { "index": 1, "status": 422, "error": { "code": "VALIDATION_ERROR" } },
    { "index": 2, "status": 201, "data": { id, name } }
  ],
  "summary": { "total": 3, "succeeded": 2, "failed": 1 }
}
```

## Règles
- Max 100 items par batch (éviter les timeouts)
- Partial success : continuer si un item échoue
- Transaction : option `atomic: true` pour tout-ou-rien
- Retourner 207 même si tous réussissent (pour cohérence)
- Rate limit : 10 batch requests/min (plus restrictif que les endpoints normaux)
