# design-crud-endpoints
CRUD standard avec conventions cohérentes.

```
GET    /api/v1/resources              → liste paginée
POST   /api/v1/resources              → créer
GET    /api/v1/resources/:id          → détail
PATCH  /api/v1/resources/:id          → mise à jour partielle
DELETE /api/v1/resources/:id          → soft delete (204)

GET    /api/v1/resources/:id/items    → sous-ressources
POST   /api/v1/resources/:id/items    → créer sous-ressource
```

## Réponses standards
```
GET list  → 200 { data: [...], total, page, limit, hasNext }
POST      → 201 { id, ...fields, createdAt }
PATCH     → 200 { id, ...updatedFields, updatedAt }
DELETE    → 204 (no body)
GET :id   → 200 { id, ...fields } | 404 { error: { code: 'NOT_FOUND' } }
```
