# design-error-responses
Système d'erreurs cohérent sur toute l'API.

## Format standard
```typescript
interface ApiError {
  error: {
    code: string      // SNAKE_UPPER_CASE
    message: string   // Message lisible, jamais de stack trace
    details?: Record<string, string[]>  // Erreurs par champ (validation)
    requestId?: string  // Pour le debugging
  }
}
```

## Codes d'erreur standard
```
UNAUTHORIZED          401  Token manquant ou invalide
FORBIDDEN             403  Accès refusé (ressource d'un autre workspace)
NOT_FOUND             404  Ressource inexistante
CONFLICT              409  Doublon ou état incompatible
VALIDATION_ERROR      422  Données invalides (avec details par champ)
RATE_LIMIT_EXCEEDED   429  Trop de requêtes
INTERNAL_ERROR        500  Erreur serveur (jamais de détails exposés)
```

## NestJS Exception Filter
```typescript
@Catch(HttpException)
export class HttpExceptionFilter implements ExceptionFilter {
  catch(exception: HttpException, host: ArgumentsHost) {
    const status = exception.getStatus()
    const response = exception.getResponse()
    host.switchToHttp().getResponse().status(status).json({
      error: {
        code: this.getCode(status, response),
        message: typeof response === 'string' ? response : (response as any).message,
        details: (response as any).details,
      }
    })
  }
}
```
