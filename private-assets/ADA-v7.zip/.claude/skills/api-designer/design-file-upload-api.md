# design-file-upload-api
API upload : multipart vs signed URLs.

## Option 1 — Upload direct (petits fichiers < 5MB)
```
POST /api/v1/uploads
Content-Type: multipart/form-data
Body : file (binary), type (image|document), resourceId (optional)

→ 201 { id, url, filename, size, mimeType, createdAt }
→ 422 { error: { code: 'INVALID_FILE', details: { file: ['Type non autorisé'] } } }
→ 413 { error: { code: 'FILE_TOO_LARGE' } }
```

## Option 2 — Signed URL S3 (fichiers > 5MB, recommandé)
```
POST /api/v1/uploads/signed-url
Body : { filename, mimeType, size }
→ 200 { uploadUrl, fileId, expiresAt }

# Client upload directement vers S3 avec uploadUrl
PUT uploadUrl
Content-Type: <mimeType>
Body : <file binary>

# Confirmer l'upload
POST /api/v1/uploads/:fileId/confirm
→ 200 { id, url, filename, size }
```
