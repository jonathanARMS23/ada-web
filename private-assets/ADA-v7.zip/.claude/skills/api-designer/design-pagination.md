# design-pagination
Choisir et implémenter la bonne stratégie de pagination.

## Offset vs Cursor

### Offset (simple, limité)
Usage : petites tables < 10k lignes, tri par colonnes non-uuid
```typescript
// Request : GET /resources?page=2&limit=20
// Response :
{ data: [...], total: 150, page: 2, limit: 20, hasNext: true }

// SQL
SELECT * FROM resources ORDER BY created_at DESC LIMIT 20 OFFSET 20
```

### Cursor (scalable, recommandé en production)
Usage : grandes tables, scroll infini, tri par created_at
```typescript
// Request : GET /resources?cursor=<base64>&limit=20
// Response :
{ data: [...], nextCursor: "<base64>|null", hasNext: true }

// Cursor = base64(JSON.stringify({ id, createdAt }))
// SQL
SELECT * FROM resources
WHERE (created_at, id) < (cursor.createdAt, cursor.id)
ORDER BY created_at DESC, id DESC
LIMIT 20
```

## Règle de choix
- < 10k lignes + UI avec numéros de pages → offset
- > 10k lignes ou scroll infini → cursor obligatoire
