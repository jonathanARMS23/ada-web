# design-rest-api
Conception REST complète avec conventions cohérentes.

## Conventions obligatoires
- Base URL : `/api/v1/`
- Ressources : kebab-case pluriel (`/user-profiles`)
- Auth : `Authorization: Bearer <token>`
- Pagination : `?page=1&limit=20` → `{ data, total, page, limit, hasNext }`
- Erreurs : `{ error: { code, message, details? } }`
- Timestamps : ISO 8601 (`2024-01-15T10:30:00Z`)

## Template endpoint
```yaml
POST /api/v1/resources
Authorization: Bearer <token>
Content-Type: application/json

Request:
  { "name": "string (required, 1-255)", "status": "draft|active" }

Response 201:
  { "id": "uuid", "name": "string", "status": "string", "createdAt": "ISO8601" }

Errors:
  400 INVALID_REQUEST   - JSON malformé
  401 UNAUTHORIZED      - Token manquant ou invalide
  422 VALIDATION_ERROR  - Données invalides + détails par champ
  409 CONFLICT          - Ressource déjà existante
```
