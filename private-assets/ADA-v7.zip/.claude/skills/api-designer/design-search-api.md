# design-search-api
API recherche : query params, filtres, tri, full-text.

## Endpoint
```
GET /api/v1/resources/search?q=terme&status=active&sort=created_at:desc&page=1&limit=20
```

## Paramètres standardisés
```
q          → full-text search (min 2 chars)
status     → filtre enum (valeurs multiples : status=active,draft)
created_after / created_before → filtre dates (ISO 8601)
sort       → champ:direction (created_at:desc, name:asc)
page + limit → pagination offset
cursor     → pagination cursor (si grandes tables)
fields     → projection des champs (fields=id,name,status)
```

## Réponse
```json
{
  "data": [...],
  "total": 150,
  "page": 1,
  "limit": 20,
  "query": "terme",
  "facets": {
    "status": { "active": 120, "draft": 30 }
  }
}
```
