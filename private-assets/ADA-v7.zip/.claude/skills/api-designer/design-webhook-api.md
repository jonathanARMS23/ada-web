# design-webhook-api
API webhook sortant : inscription, signature, retry, events.

## Endpoints de gestion des webhooks
```
POST   /api/v1/webhooks              → inscrire un endpoint
GET    /api/v1/webhooks              → lister les inscriptions
DELETE /api/v1/webhooks/:id          → désinscrire
POST   /api/v1/webhooks/:id/test     → envoyer un event de test
GET    /api/v1/webhooks/:id/logs     → historique des livraisons
```

## Format de livraison
```json
{
  "id": "evt_uuid",
  "type": "resource.created",
  "created": 1700000000,
  "data": { "object": { ...resource } },
  "webhook_id": "wh_uuid"
}
```

## Signature HMAC (header)
```
X-Webhook-Signature: sha256=<hmac-sha256(secret, body)>
X-Webhook-Id: evt_uuid           (idempotence)
X-Webhook-Timestamp: 1700000000  (replay protection)
```

## Retry policy
- 3 tentatives : immédiat → 5min → 30min
- Timeout : 10s par tentative
- Désactiver l'endpoint après 10 échecs consécutifs
