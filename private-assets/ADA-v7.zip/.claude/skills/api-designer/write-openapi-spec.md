# write-openapi-spec
Spec OpenAPI 3.0 complète.

## Structure de base
```yaml
openapi: 3.0.3
info:
  title: API Name
  version: 1.0.0
  description: Description de l'API

servers:
  - url: https://api.example.com/api/v1
    description: Production
  - url: http://localhost:3000/api/v1
    description: Development

security:
  - BearerAuth: []

components:
  securitySchemes:
    BearerAuth:
      type: http
      scheme: bearer
      bearerFormat: JWT

  schemas:
    Resource:
      type: object
      properties:
        id: { type: string, format: uuid }
        name: { type: string, minLength: 1, maxLength: 255 }
        status: { type: string, enum: [draft, active, archived] }
        createdAt: { type: string, format: date-time }
      required: [id, name, status, createdAt]

    Error:
      type: object
      properties:
        error:
          type: object
          properties:
            code: { type: string }
            message: { type: string }
            details: { type: object }

paths:
  /resources:
    get:
      summary: Liste des ressources
      tags: [Resources]
      parameters:
        - name: page
          in: query
          schema: { type: integer, default: 1 }
      responses:
        '200':
          description: Success
          content:
            application/json:
              schema:
                type: object
                properties:
                  data:
                    type: array
                    items: { $ref: '#/components/schemas/Resource' }
```
