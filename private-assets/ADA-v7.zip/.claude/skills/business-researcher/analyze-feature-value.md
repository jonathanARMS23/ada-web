# analyze-feature-value
Analyser la valeur réelle d'une feature avant de la construire.

## Questions à répondre
```
1. Quel problème exact cette feature résout-elle ?
   → Décrire en termes utilisateur, pas en termes techniques

2. Pour qui ?
   → Segment spécifique (pas "tous les utilisateurs")
   → Fréquence d'utilisation attendue (daily/weekly/monthly/one-time)

3. Quelle est la preuve que ce besoin existe ?
   → Retours utilisateurs directs ? Données analytics ? Hypothèse ?

4. Quelle valeur mesurable crée-t-elle ?
   → Réduit le churn de X% ? Augmente l'activation de X% ?
   → Débloque un segment de marché ?
   → Réduit les tickets support de X% ?
```

## Format de sortie
```markdown
## Analyse valeur — <feature>

**Problème :** [1 phrase]
**Utilisateur cible :** [segment précis]
**Fréquence d'usage :** [daily/weekly/monthly]
**Preuve du besoin :** [donnée / retour / hypothèse à valider]
**Valeur métier :**
  - Impact rétention : [estimé]
  - Impact conversion : [estimé]
  - Impact support : [estimé]
**Risque si on ne la fait pas :** [faible/moyen/élevé + raison]
**Recommandation :** go / no-go / valider d'abord
```
