# competitive-analysis
Analyse concurrentielle : features, pricing, positioning.

## Template
```markdown
## Analyse concurrentielle — <feature/produit>

### Concurrents identifiés
| Concurrent | Position | Prix | Part de marché |
|------------|----------|------|----------------|

### Comparaison de features
| Feature | Notre produit | Concurrent A | Concurrent B |
|---------|--------------|--------------|--------------|
| [Feature 1] | ✅ | ✅ | ❌ |
| [Feature 2] | ❌ | ✅ | ✅ |

### Notre positionnement
- Différenciateurs : [ce que nous faisons mieux]
- Parité : [ce que nous matchons]
- Lacunes : [ce que nous n'avons pas encore]

### Opportunités identifiées
[Features que personne ne fait bien et que nos utilisateurs veulent]

### Recommandation
[Go / No-go / Différencier sur X angle]
```
