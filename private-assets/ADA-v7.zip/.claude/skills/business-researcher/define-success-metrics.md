# define-success-metrics
Définir des KPIs mesurables à 30/60/90 jours.

## Framework HEART (Google)
- **Happiness** : satisfaction utilisateur (NPS, CSAT)
- **Engagement** : fréquence d'utilisation (DAU/MAU, sessions/semaine)
- **Adoption** : nouveaux utilisateurs de la feature (% d'activation)
- **Retention** : utilisateurs qui reviennent (rétention J7, J30)
- **Task success** : taux de complétion du flow principal

## Template
```markdown
## Métriques de succès — <feature>

### Métrique principale (North Star)
[Une seule métrique qui mesure la valeur créée]
Cible à 90j : [valeur]

### Métriques secondaires
| Métrique | Baseline actuelle | Cible 30j | Cible 60j | Cible 90j |
|----------|------------------|-----------|-----------|-----------|

### Métriques de guardrail (ne pas dégrader)
| Métrique | Valeur actuelle | Seuil d'alarme |
|----------|----------------|----------------|

### Comment mesurer
[Outil de tracking : Mixpanel, Amplitude, custom analytics]
[Événements à tracker : resource.created, resource.viewed, etc.]
```
