# market-sizing
Estimation TAM/SAM/SOM.

## Définitions
- **TAM** (Total Addressable Market) : marché total si 100% de part
- **SAM** (Serviceable Addressable Market) : portion qu'on peut adresser avec notre produit
- **SOM** (Serviceable Obtainable Market) : part réaliste à 3-5 ans

## Approche bottom-up (plus précise)
```markdown
## Market Sizing — <marché>

### Bottom-up
1. Nombre de clients potentiels : X entreprises dans [segment] en [géographie]
   Source : [base de données, LinkedIn, rapport sectoriel]
2. Valeur par client : X€/an (ARPU)
3. Taux de conversion réaliste : X%

TAM = X entreprises × X€/an = X M€/an
SAM = X entreprises ciblées × X€/an = X M€/an
SOM Y1 = X clients × X€/an = X K€/an (avec les ressources actuelles)
SOM Y3 = X clients × X€/an = X M€/an (avec croissance)

### Hypothèses critiques
- [Hypothèse 1] → si fausse, impact : [X% du SOM]

### Comparaison
[Concurrents qui adressent ce marché et leur valorisation]
```
