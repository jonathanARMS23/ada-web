# prioritization-matrix
Matrice impact/effort/risque pour prioriser le backlog.

## Grille de scoring

### Impact (1-5)
1 — Amélioration marginale, peu d'utilisateurs touchés
2 — Amélioration notable pour un segment
3 — Impact clair sur une métrique clé (activation, rétention)
4 — Déblocage d'un segment important ou réduction churn significative
5 — Différenciateur compétitif ou nouveau segment de marché

### Effort (1-5, inversé — 5 = très rapide)
1 — > 3 semaines de dev
2 — 1-3 semaines
3 — 3-5 jours
4 — 1-3 jours
5 — < 1 jour

### Risque (1-5, inversé — 5 = sans risque)
1 — Changements irréversibles, impact prod critique
2 — Risque technique élevé, dépendances fragiles
3 — Risque modéré, bien maîtrisé
4 — Risque faible, bien testé
5 — Aucun risque

## Score = Impact × Effort × Risque

## Template
| Feature | Impact | Effort | Risque | Score | Priorité |
|---------|--------|--------|--------|-------|----------|
| X | 4 | 3 | 4 | 48 | P0 |
| Y | 5 | 1 | 5 | 25 | P1 |
