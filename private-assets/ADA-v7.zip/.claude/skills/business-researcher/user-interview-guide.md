# user-interview-guide
Guide d'entretien utilisateur pour valider une hypothèse.

## Règles d'or
1. Parler du passé, pas du futur (comportement réel vs intention)
2. Éviter les questions suggestives ("Trouveriez-vous utile...")
3. Creuser avec "Pourquoi ?" et "Pouvez-vous me montrer ?"
4. 5-7 entretiens suffisent pour identifier les patterns

## Template guide
```markdown
## Guide d'entretien — <hypothèse à valider>

### Introduction (2 min)
"Je cherche à comprendre comment vous [contexte], pas à vous vendre quoi que ce soit.
Il n'y a pas de bonne ou mauvaise réponse."

### Questions de contexte (5 min)
1. "Décrivez votre rôle au quotidien en lien avec [domaine]"
2. "Quelle est la partie la plus frustrante de [processus actuel] ?"

### Questions sur le problème (15 min)
3. "La dernière fois que vous avez dû [tâche], comment avez-vous procédé ?"
4. "Qu'est-ce qui a été le plus difficile ?"
5. "Qu'avez-vous essayé avant ?"
6. "Si vous pouviez changer une chose, ce serait quoi ?"

### Validation de la solution (5 min)
7. "Si je vous dis [solution proposée], qu'est-ce que ça évoque ?"
8. "Utiliseriez-vous quelque chose comme ça ? Pourquoi ?"

### Clôture (2 min)
"Y a-t-il quelque chose que je n'ai pas abordé et qui vous semble important ?"
```
