# write-product-brief
Brief produit complet avant démarrage du développement.

## Template
```markdown
## Product Brief — <nom feature>
**Date :** YYYY-MM-DD
**Auteur :** [nom]
**Status :** Draft | Approved | In Progress

### Problème
[Description du problème utilisateur en 2-3 phrases]

### Solution proposée
[Ce qu'on va construire — pas le comment, le quoi]

### Non-scope (ce qu'on ne fait PAS)
- [liste explicite]

### Utilisateurs cibles
- Segment principal : [description]
- Cas d'usage principal : [description]

### Critères de succès (mesurables à 30/60/90j)
- [ ] [métrique] atteint [valeur] dans [délai]
- [ ] [métrique] atteint [valeur] dans [délai]

### Risques identifiés
- [risque] → [mitigation]

### Dépendances
- Technique : [liste]
- Produit : [features prérequises]

### Estimation effort
- DB : X j/h
- Backend : X j/h
- Frontend : X j/h
- Total : X j/h

### Décision
- [ ] Approuvé pour développement
- [ ] En attente de validation
- [ ] Rejeté — raison : [...]
```
