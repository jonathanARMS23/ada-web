# design-audit-trail
Historique complet des changements — qui, quoi, quand.

## Option 1 — Table d'audit générique (recommandé)
```sql
CREATE TABLE audit_logs (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  table_name  TEXT NOT NULL,
  record_id   UUID NOT NULL,
  action      TEXT NOT NULL CHECK (action IN ('INSERT','UPDATE','DELETE')),
  changed_by  UUID REFERENCES users(id),
  old_data    JSONB,
  new_data    JSONB,
  diff        JSONB,  -- seulement les champs qui ont changé
  ip_address  INET,
  user_agent  TEXT,
  changed_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_audit_record ON audit_logs(table_name, record_id, changed_at DESC);
```

## Option 2 — Temporal tables (PG 16+ ou extension)
```sql
-- Garder toutes les versions de chaque enregistrement
CREATE TABLE resources_history (LIKE resources INCLUDING ALL);
ALTER TABLE resources_history ADD COLUMN valid_from TIMESTAMPTZ;
ALTER TABLE resources_history ADD COLUMN valid_to TIMESTAMPTZ;
```

## Règle de choix
- Audit légal/compliance → Option 1 (immutable, indexé)
- Time-travel queries → Option 2
- Audit simple d'activité → champs created_by/updated_by sur la table principale
