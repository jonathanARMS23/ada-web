# design-hierarchical-data
Données hiérarchiques : adjacency list vs closure table.

## Adjacency List (simple, récursion nécessaire)
```sql
CREATE TABLE categories (
  id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_id UUID REFERENCES categories(id),
  name      TEXT NOT NULL
);

-- Récursion avec CTE
WITH RECURSIVE category_tree AS (
  SELECT id, name, parent_id, 0 AS depth, name::TEXT AS path
  FROM categories WHERE parent_id IS NULL
  UNION ALL
  SELECT c.id, c.name, c.parent_id, ct.depth + 1, ct.path || ' > ' || c.name
  FROM categories c
  JOIN category_tree ct ON c.parent_id = ct.id
)
SELECT * FROM category_tree ORDER BY path;
```

## Closure Table (requêtes rapides, write plus lente)
```sql
CREATE TABLE category_paths (
  ancestor   UUID REFERENCES categories(id),
  descendant UUID REFERENCES categories(id),
  depth      INTEGER NOT NULL,
  PRIMARY KEY (ancestor, descendant)
);

-- Tous les descendants
SELECT c.* FROM categories c
JOIN category_paths cp ON cp.descendant = c.id
WHERE cp.ancestor = $parent_id AND cp.depth > 0;
```

## Règle de choix
- Hiérarchie peu profonde (< 5 niveaux) + lectures fréquentes → Closure Table
- Hiérarchie profonde + writes fréquents → Adjacency List + CTE
