# design-jsonb-schema
JSONB PostgreSQL : quand l'utiliser et comment l'indexer.

## Quand utiliser JSONB
✅ Bonne utilisation :
- Métadonnées variables selon le type de ressource
- Configuration flexible par workspace
- Données externes (réponses API tierce)
- Champs rarement filtrés

❌ Mauvaise utilisation :
- Champs filtrés fréquemment → colonne dédiée
- Champs obligatoires → colonne avec contrainte
- Relations → table dédiée
- Compteurs ou agrégats → colonne numérique

## Index sur JSONB
```sql
-- Index GIN pour recherche dans le JSONB
CREATE INDEX idx_metadata ON resources USING GIN(metadata);

-- Index sur un champ spécifique du JSON (plus ciblé)
CREATE INDEX idx_metadata_type ON resources((metadata->>'type'));
CREATE INDEX idx_metadata_tags ON resources USING GIN((metadata->'tags'));
```

## Requêtes courantes
```sql
-- Égalité sur un champ JSON
SELECT * FROM resources WHERE metadata->>'type' = 'invoice';

-- Contient un tag
SELECT * FROM resources WHERE metadata->'tags' ? 'urgent';

-- Champ JSON dans un ensemble
SELECT * FROM resources WHERE metadata->>'status' IN ('pending', 'processing');
```
