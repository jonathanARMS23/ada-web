# design-multi-tenant
Schéma multi-tenant row-level avec isolation complète.

## Pattern workspace_id (recommandé)
```sql
-- Toutes les tables métier ont workspace_id
CREATE TABLE resources (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID NOT NULL REFERENCES workspaces(id),
  ...
);

-- RLS force l'isolation
CREATE POLICY "workspace_isolation" ON resources
  FOR ALL TO authenticated
  USING (workspace_id = current_setting('app.workspace_id')::uuid);
```

## Checklist isolation
```
□ workspace_id sur toutes les tables métier (jamais oublier)
□ FK ON DELETE CASCADE vers workspaces
□ Index sur workspace_id (partiel si soft delete)
□ RLS activé + testé avec user d'un autre workspace
□ Les API ne permettent pas de passer workspace_id depuis le client
□ Le backend injecte workspace_id depuis le token JWT
□ Les exports/reports filtrent par workspace
```

## Test d'isolation
```python
# Toujours tester qu'un user ne peut pas voir les données d'un autre workspace
def test_workspace_isolation(api_client, user_a, user_b, resource_b):
    api_client.force_authenticate(user=user_a)
    response = api_client.get(f'/api/v1/resources/{resource_b.id}/')
    assert response.status_code == 404  # pas 403 — ne pas révéler l'existence
```
