# design-soft-delete
Stratégie soft delete selon les besoins.

## Option 1 — deleted_at (simple, recommandé)
```sql
ALTER TABLE resources ADD COLUMN deleted_at TIMESTAMPTZ;
CREATE INDEX idx_resources_not_deleted ON resources(id) WHERE deleted_at IS NULL;

-- Toutes les requêtes filtrent
SELECT * FROM resources WHERE deleted_at IS NULL AND workspace_id = $1;
```

**Impact :** Ajouter `WHERE deleted_at IS NULL` partout + partial index.

## Option 2 — Table archive (volumineuse)
```sql
-- Copier puis supprimer
INSERT INTO resources_archive SELECT * FROM resources WHERE id = $1;
DELETE FROM resources WHERE id = $1;
```

**Usage :** tables > 1M lignes où les enregistrements supprimés polluent les index.

## Règle de choix
- < 1M lignes ou besoin de restauration fréquente → deleted_at
- > 1M lignes + suppression définitive après 90j → table archive + pg_cron
