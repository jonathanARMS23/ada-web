# design-time-series
Données temporelles : partitioning, agrégation, rétention.

## Table partitionnée par mois
```sql
CREATE TABLE metrics (
  id           UUID DEFAULT gen_random_uuid(),
  workspace_id UUID NOT NULL,
  metric_name  TEXT NOT NULL,
  value        NUMERIC NOT NULL,
  recorded_at  TIMESTAMPTZ NOT NULL
) PARTITION BY RANGE (recorded_at);

-- Partitions mensuelles
CREATE TABLE metrics_2024_01 PARTITION OF metrics
  FOR VALUES FROM ('2024-01-01') TO ('2024-02-01');
CREATE TABLE metrics_2024_02 PARTITION OF metrics
  FOR VALUES FROM ('2024-02-01') TO ('2024-03-01');

-- Index sur chaque partition
CREATE INDEX ON metrics_2024_01(workspace_id, recorded_at DESC);
```

## Rétention automatique (pg_cron)
```sql
-- Supprimer les données > 2 ans
SELECT cron.schedule('cleanup-old-metrics', '0 1 1 * *',
  $$ DELETE FROM metrics WHERE recorded_at < now() - INTERVAL '2 years' $$
);
```

## Agrégation en temps réel
```sql
-- Vue matérialisée pour les stats quotidiennes
CREATE MATERIALIZED VIEW daily_metrics AS
SELECT
  workspace_id,
  metric_name,
  date_trunc('day', recorded_at) AS day,
  AVG(value) AS avg_value,
  MAX(value) AS max_value,
  COUNT(*) AS count
FROM metrics
GROUP BY 1, 2, 3;
```
