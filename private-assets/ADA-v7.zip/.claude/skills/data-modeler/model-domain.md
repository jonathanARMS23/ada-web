# model-domain
Modélisation domaine métier — entités, relations, cardinalités.

## Processus
1. Identifier les concepts métier (noms dans les user stories)
2. Distinguer Entités (identité propre) vs Value Objects (décrits par leurs attributs)
3. Définir les Aggregates (frontières de cohérence)
4. Établir les relations et cardinalités
5. Identifier les invariants métier (contraintes toujours vraies)

## Template de sortie
```
## Domain Model — <domaine>

### Entités principales
| Entité | Identifiant | Attributs clés | Relations |
|--------|-------------|----------------|-----------|

### Aggregates
- [NomAggregate] : [entités incluses] — [invariant métier]

### Relations
- Workspace (1) ──< Resource (N) : un workspace a plusieurs ressources
- Resource (1) ──< LineItem (N) : cascade delete
- User (N) >──< Workspace (N) : via workspace_members

### Règles métier
- [liste des invariants à enforcer dans le code]
```
