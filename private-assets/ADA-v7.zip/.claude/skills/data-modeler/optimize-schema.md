# optimize-schema
Optimisation d'un schéma existant.

## Audit du schéma
```sql
-- Tables sans index sur les FK
SELECT tc.table_name, kcu.column_name
FROM information_schema.table_constraints tc
JOIN information_schema.key_column_usage kcu USING (constraint_name)
WHERE tc.constraint_type = 'FOREIGN KEY'
  AND NOT EXISTS (
    SELECT 1 FROM pg_indexes pi
    WHERE pi.tablename = tc.table_name
      AND pi.indexdef LIKE '%' || kcu.column_name || '%'
  );

-- Tables volumineuses sans index utile
SELECT schemaname, relname, n_live_tup, idx_scan
FROM pg_stat_user_tables
WHERE n_live_tup > 10000 AND idx_scan < 100
ORDER BY n_live_tup DESC;

-- Index inutilisés (à supprimer)
SELECT indexrelname, idx_scan, idx_tup_read
FROM pg_stat_user_indexes
WHERE idx_scan = 0 AND indexrelname NOT LIKE '%pkey%';
```

## Actions courantes
```sql
-- Ajouter index manquant (CONCURRENTLY pour ne pas locker)
CREATE INDEX CONCURRENTLY idx_resources_workspace ON resources(workspace_id);

-- Supprimer index inutilisé
DROP INDEX CONCURRENTLY idx_resources_unused;

-- Dénormaliser un champ très fréquemment joint
ALTER TABLE resources ADD COLUMN workspace_name TEXT;
UPDATE resources r SET workspace_name = w.name FROM workspaces w WHERE w.id = r.workspace_id;
```
