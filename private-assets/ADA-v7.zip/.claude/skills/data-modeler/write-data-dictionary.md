# write-data-dictionary
Dictionnaire de données : tables, colonnes, règles métier.

## Template
```markdown
## Data Dictionary — <projet>

### Table : resources

**Description :** Ressources métier du workspace

| Colonne | Type | Nullable | Défaut | Description |
|---------|------|----------|--------|-------------|
| id | UUID | NON | gen_random_uuid() | Identifiant unique |
| workspace_id | UUID | NON | — | FK → workspaces.id |
| name | TEXT | NON | — | Nom (1-255 chars) |
| status | TEXT | NON | 'draft' | Enum : draft, active, archived |
| metadata | JSONB | NON | '{}' | Données variables selon le type |
| deleted_at | TIMESTAMPTZ | OUI | NULL | Soft delete — NULL = actif |
| created_at | TIMESTAMPTZ | NON | now() | Date de création |
| updated_at | TIMESTAMPTZ | NON | now() | Dernière modification |

**Règles métier :**
- Une ressource archivée ne peut pas être réactivée
- deleted_at est mis à now() lors de la suppression (jamais DELETE)
- workspace_id est injecté par le backend depuis le JWT

**Index :**
- idx_resources_workspace (workspace_id) WHERE deleted_at IS NULL
- idx_resources_status (workspace_id, status) WHERE deleted_at IS NULL

**RLS :**
- authenticated : workspace_id = jwt.workspace_id
- service_role : accès total
```
