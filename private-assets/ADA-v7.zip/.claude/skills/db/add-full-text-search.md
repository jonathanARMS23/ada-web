# add-full-text-search
Full-text search PostgreSQL avec tsvector et ranking.

## Étapes
```sql
-- Ajouter colonne tsvector
ALTER TABLE resources ADD COLUMN search_vector tsvector;

-- Remplir avec données existantes
UPDATE resources SET search_vector =
  to_tsvector('french', coalesce(name,'') || ' ' || coalesce(description,''));

-- Index GIN
CREATE INDEX idx_resources_search ON resources USING GIN(search_vector);

-- Trigger de mise à jour automatique
CREATE OR REPLACE FUNCTION update_search_vector()
RETURNS TRIGGER AS $$
BEGIN
  NEW.search_vector := to_tsvector('french',
    coalesce(NEW.name,'') || ' ' || coalesce(NEW.description,''));
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER resources_search_vector_update
  BEFORE INSERT OR UPDATE ON resources
  FOR EACH ROW EXECUTE FUNCTION update_search_vector();
```

## Requête avec ranking
```sql
SELECT *, ts_rank(search_vector, query) AS rank
FROM resources, to_tsquery('french', 'terme:*') query
WHERE search_vector @@ query
  AND workspace_id = $1
ORDER BY rank DESC
LIMIT 20;
```
