# add-pg-cron
Job pg_cron pour maintenance planifiée.

```sql
-- Activer l'extension (requiert superuser)
CREATE EXTENSION IF NOT EXISTS pg_cron;

-- Archivage quotidien à 3h du matin
SELECT cron.schedule(
  'archive-old-resources',
  '0 3 * * *',
  $$ SELECT archive_old_resources() $$
);

-- Refresh vue matérialisée toutes les heures
SELECT cron.schedule(
  'refresh-workspace-stats',
  '0 * * * *',
  $$ REFRESH MATERIALIZED VIEW CONCURRENTLY workspace_stats $$
);

-- Voir les jobs
SELECT * FROM cron.job;

-- Voir les exécutions récentes
SELECT * FROM cron.job_run_details ORDER BY start_time DESC LIMIT 20;

-- Supprimer un job
SELECT cron.unschedule('archive-old-resources');
```
