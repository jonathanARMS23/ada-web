# add-pgvector
Extension pgvector pour recherche sémantique.

```sql
-- Activer l'extension
CREATE EXTENSION IF NOT EXISTS vector;

-- Table avec vecteur
ALTER TABLE resources ADD COLUMN embedding vector(1536);  -- OpenAI text-embedding-3-small

-- Index ivfflat (rapide, légèrement approximatif)
CREATE INDEX ON resources USING ivfflat (embedding vector_cosine_ops)
  WITH (lists = 100);  -- lists ≈ sqrt(nb_rows)

-- Fonction de recherche sémantique
CREATE OR REPLACE FUNCTION search_resources(
  query_embedding vector(1536),
  workspace_id UUID,
  match_count INT DEFAULT 10,
  match_threshold FLOAT DEFAULT 0.7
)
RETURNS TABLE(id UUID, name TEXT, similarity FLOAT) AS $$
  SELECT id, name, 1 - (embedding <=> query_embedding) AS similarity
  FROM resources
  WHERE workspace_id = workspace_id
    AND deleted_at IS NULL
    AND 1 - (embedding <=> query_embedding) > match_threshold
  ORDER BY embedding <=> query_embedding
  LIMIT match_count;
$$ LANGUAGE SQL STABLE;
```
