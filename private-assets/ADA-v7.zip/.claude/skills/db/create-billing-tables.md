# create-billing-tables
Tables billing Stripe : subscriptions, invoices, usage.

## Migration 002_billing.sql
```sql
BEGIN;

CREATE TABLE subscriptions (
  id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id         UUID NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  stripe_customer_id   TEXT NOT NULL UNIQUE,
  stripe_subscription_id TEXT UNIQUE,
  plan                 TEXT NOT NULL DEFAULT 'free'
                       CHECK (plan IN ('free', 'starter', 'pro', 'enterprise')),
  status               TEXT NOT NULL DEFAULT 'active'
                       CHECK (status IN ('active', 'trialing', 'past_due', 'canceled', 'unpaid')),
  trial_ends_at        TIMESTAMPTZ,
  current_period_start TIMESTAMPTZ,
  current_period_end   TIMESTAMPTZ,
  canceled_at          TIMESTAMPTZ,
  metadata             JSONB NOT NULL DEFAULT '{}',
  created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE invoices (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id        UUID NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  stripe_invoice_id   TEXT NOT NULL UNIQUE,
  amount_due          INTEGER NOT NULL,   -- en centimes
  amount_paid         INTEGER NOT NULL DEFAULT 0,
  currency            TEXT NOT NULL DEFAULT 'eur',
  status              TEXT NOT NULL CHECK (status IN ('draft','open','paid','void','uncollectible')),
  invoice_pdf_url     TEXT,
  period_start        TIMESTAMPTZ,
  period_end          TIMESTAMPTZ,
  paid_at             TIMESTAMPTZ,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Index
CREATE UNIQUE INDEX idx_subscriptions_workspace ON subscriptions(workspace_id);
CREATE INDEX idx_invoices_workspace ON invoices(workspace_id);
CREATE INDEX idx_subscriptions_status ON subscriptions(status) WHERE status != 'canceled';

CREATE TRIGGER set_updated_at BEFORE UPDATE ON subscriptions
  FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at();

COMMIT;
```

## Fonction helper — vérifier le plan
```sql
CREATE OR REPLACE FUNCTION workspace_plan(p_workspace_id UUID)
RETURNS TEXT AS $$
  SELECT COALESCE(
    (SELECT plan FROM subscriptions
     WHERE workspace_id = p_workspace_id
       AND status IN ('active', 'trialing')
     LIMIT 1),
    'free'
  );
$$ LANGUAGE SQL STABLE;
```
