# create-enum-type
Type enum PostgreSQL avec migration d'ajout de valeur.

```sql
-- Créer
CREATE TYPE resource_status AS ENUM ('draft', 'active', 'archived');
ALTER TABLE resources ALTER COLUMN status TYPE resource_status
  USING status::resource_status;

-- Ajouter une valeur (sans lock depuis PG 9.1)
ALTER TYPE resource_status ADD VALUE 'suspended' AFTER 'active';

-- Renommer une valeur (PG 10+)
ALTER TYPE resource_status RENAME VALUE 'draft' TO 'pending';
```

## Migration Prisma
```prisma
enum ResourceStatus {
  draft
  active
  archived
  suspended  // ajout
}
```
```bash
npx prisma migrate dev --name add_suspended_status
```
