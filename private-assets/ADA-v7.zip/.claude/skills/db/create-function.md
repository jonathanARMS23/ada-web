# create-function
Fonction SQL réutilisable (calcul, agrégat, validation).

```sql
-- Fonction de calcul
CREATE OR REPLACE FUNCTION workspace_resource_count(p_workspace_id UUID)
RETURNS BIGINT AS $$
  SELECT COUNT(*) FROM resources
  WHERE workspace_id = p_workspace_id AND deleted_at IS NULL;
$$ LANGUAGE SQL STABLE;

-- Usage : SELECT workspace_resource_count('uuid')

-- Fonction avec logique complexe
CREATE OR REPLACE FUNCTION get_workspace_stats(p_workspace_id UUID)
RETURNS TABLE(total BIGINT, active BIGINT, archived BIGINT) AS $$
BEGIN
  RETURN QUERY
  SELECT
    COUNT(*) FILTER (WHERE deleted_at IS NULL),
    COUNT(*) FILTER (WHERE status = 'active' AND deleted_at IS NULL),
    COUNT(*) FILTER (WHERE status = 'archived')
  FROM resources WHERE workspace_id = p_workspace_id;
END;
$$ LANGUAGE plpgsql STABLE;
```
