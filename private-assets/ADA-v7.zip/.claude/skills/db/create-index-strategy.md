# create-index-strategy
Stratégie d'index selon les patterns de requêtes.

## Index essentiels à créer systématiquement
```sql
-- FK toujours indexées
CREATE INDEX idx_<table>_workspace_id ON <table>(workspace_id);
CREATE INDEX idx_<table>_user_id ON <table>(user_id);

-- Colonnes filtrées fréquemment
CREATE INDEX idx_<table>_status ON <table>(status) WHERE deleted_at IS NULL;
CREATE INDEX idx_<table>_created_at ON <table>(created_at DESC);

-- Recherche texte
CREATE INDEX idx_<table>_name_trgm ON <table> USING GIN (name gin_trgm_ops);

-- JSONB
CREATE INDEX idx_<table>_metadata ON <table> USING GIN (metadata);

-- Composite (colonnes utilisées ensemble dans WHERE)
CREATE INDEX idx_<table>_workspace_status ON <table>(workspace_id, status)
  WHERE deleted_at IS NULL;
```

## Règles
- Partial index (WHERE deleted_at IS NULL) sur toutes les tables avec soft delete
- CREATE INDEX CONCURRENTLY en production (jamais CREATE INDEX seul)
- Vérifier avec EXPLAIN ANALYZE après création
