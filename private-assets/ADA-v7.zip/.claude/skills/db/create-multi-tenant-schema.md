# create-multi-tenant-schema
Isolation multi-tenant complète avec RLS et workspace.

```sql
-- 1. Toutes les tables métier ont workspace_id
CREATE TABLE resources (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  ...
);

-- 2. Index systématique sur workspace_id
CREATE INDEX idx_resources_workspace ON resources(workspace_id) WHERE deleted_at IS NULL;

-- 3. RLS — isolation stricte
ALTER TABLE resources ENABLE ROW LEVEL SECURITY;

CREATE POLICY "workspace_isolation" ON resources
  FOR ALL TO authenticated
  USING (workspace_id = auth.jwt() ->> 'workspace_id');

-- 4. Test d'isolation (à exécuter dans les migrations de test)
DO $$
DECLARE
  ws_a UUID := gen_random_uuid();
  ws_b UUID := gen_random_uuid();
BEGIN
  -- Insérer dans workspace A
  INSERT INTO resources(workspace_id, name) VALUES(ws_a, 'Resource A');
  -- Vérifier que workspace B ne voit pas les données de A
  -- (dans un contexte authentifié avec jwt workspace_id = ws_b)
  ASSERT (SELECT COUNT(*) FROM resources WHERE workspace_id = ws_a) = 1;
  RAISE NOTICE 'Isolation OK';
END $$;
```
