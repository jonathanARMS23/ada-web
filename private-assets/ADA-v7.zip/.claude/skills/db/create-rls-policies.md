# create-rls-policies
Policies RLS Supabase complètes.

## Template
```sql
ALTER TABLE resources ENABLE ROW LEVEL SECURITY;

-- service_role : accès total (backend)
CREATE POLICY "service_role_all" ON resources
  FOR ALL TO service_role USING (true) WITH CHECK (true);

-- authenticated : seulement son workspace
CREATE POLICY "user_select_own_workspace" ON resources
  FOR SELECT TO authenticated
  USING (
    workspace_id IN (
      SELECT workspace_id FROM workspace_members
      WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "user_insert_own_workspace" ON resources
  FOR INSERT TO authenticated
  WITH CHECK (
    workspace_id IN (
      SELECT workspace_id FROM workspace_members
      WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "user_update_own_workspace" ON resources
  FOR UPDATE TO authenticated
  USING (workspace_id IN (SELECT workspace_id FROM workspace_members WHERE user_id = auth.uid()))
  WITH CHECK (workspace_id IN (SELECT workspace_id FROM workspace_members WHERE user_id = auth.uid()));
```

## Test des policies
```sql
SET LOCAL role TO authenticated;
SET LOCAL "request.jwt.claims" TO '{"sub": "user-uuid"}';
SELECT * FROM resources; -- doit retourner seulement les ressources du workspace
```
