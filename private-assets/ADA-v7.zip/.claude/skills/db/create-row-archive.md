# create-row-archive
Archivage automatique vers table archive avec pg_cron.

```sql
-- Table archive (même structure + colonnes audit)
CREATE TABLE resources_archive (LIKE resources INCLUDING ALL);
ALTER TABLE resources_archive
  ADD COLUMN archived_at TIMESTAMPTZ DEFAULT now(),
  ADD COLUMN archive_reason TEXT;

-- Fonction d'archivage
CREATE OR REPLACE FUNCTION archive_old_resources()
RETURNS INTEGER AS $$
DECLARE archived_count INTEGER;
BEGIN
  WITH moved AS (
    DELETE FROM resources
    WHERE deleted_at < now() - INTERVAL '90 days'
    RETURNING *
  )
  INSERT INTO resources_archive
  SELECT *, now(), 'auto_cleanup_90d'
  FROM moved;
  GET DIAGNOSTICS archived_count = ROW_COUNT;
  RETURN archived_count;
END;
$$ LANGUAGE plpgsql;
```
