# create-table
Table PostgreSQL complète avec toutes les conventions.

## Template
```sql
CREATE TABLE resources (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id  UUID NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  created_by_id UUID NOT NULL REFERENCES users(id),
  name          TEXT NOT NULL CHECK (char_length(name) BETWEEN 1 AND 255),
  status        TEXT NOT NULL DEFAULT 'draft'
                CHECK (status IN ('draft', 'active', 'archived')),
  metadata      JSONB NOT NULL DEFAULT '{}',
  deleted_at    TIMESTAMPTZ,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Index essentiels
CREATE INDEX idx_resources_workspace ON resources(workspace_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_resources_status ON resources(workspace_id, status) WHERE deleted_at IS NULL;

-- updated_at automatique
CREATE TRIGGER set_updated_at
  BEFORE UPDATE ON resources
  FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at();
```
