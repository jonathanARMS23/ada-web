# create-trigger
Trigger PL/pgSQL — updated_at, audit, cascade custom.

```sql
-- Fonction updated_at (une seule fois, réutilisable)
CREATE OR REPLACE FUNCTION trigger_set_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

-- Appliquer sur chaque table
CREATE TRIGGER set_updated_at
  BEFORE UPDATE ON resources
  FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at();

-- Trigger de validation métier
CREATE OR REPLACE FUNCTION validate_resource_transition()
RETURNS TRIGGER AS $$
BEGIN
  IF OLD.status = 'archived' AND NEW.status != 'archived' THEN
    RAISE EXCEPTION 'Une ressource archivée ne peut pas être réactivée';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER check_resource_status
  BEFORE UPDATE OF status ON resources
  FOR EACH ROW EXECUTE FUNCTION validate_resource_transition();
```
