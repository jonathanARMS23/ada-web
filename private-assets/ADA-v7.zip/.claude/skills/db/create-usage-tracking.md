# create-usage-tracking
Tracking d'usage pour les plans limités (quotas, rate limits).

## Table usage_events
```sql
CREATE TABLE usage_events (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  feature      TEXT NOT NULL,   -- ex: 'api_calls', 'exports', 'members'
  quantity     INTEGER NOT NULL DEFAULT 1,
  metadata     JSONB DEFAULT '{}',
  recorded_at  TIMESTAMPTZ NOT NULL DEFAULT now()
) PARTITION BY RANGE (recorded_at);

-- Partitions mensuelles
CREATE TABLE usage_events_2024_01 PARTITION OF usage_events
  FOR VALUES FROM ('2024-01-01') TO ('2024-02-01');

-- Index
CREATE INDEX idx_usage_workspace_feature ON usage_events(workspace_id, feature, recorded_at DESC);
```

## Fonction d'agrégation mensuelle
```sql
CREATE OR REPLACE FUNCTION workspace_usage_this_month(
  p_workspace_id UUID,
  p_feature TEXT
) RETURNS BIGINT AS $$
  SELECT COALESCE(SUM(quantity), 0)
  FROM usage_events
  WHERE workspace_id = p_workspace_id
    AND feature = p_feature
    AND recorded_at >= date_trunc('month', now())
    AND recorded_at < date_trunc('month', now()) + INTERVAL '1 month';
$$ LANGUAGE SQL STABLE;
```

## Limites par plan (table de config)
```sql
CREATE TABLE plan_limits (
  plan         TEXT NOT NULL,
  feature      TEXT NOT NULL,
  monthly_limit INTEGER,   -- NULL = illimité
  PRIMARY KEY (plan, feature)
);

INSERT INTO plan_limits VALUES
  ('free',       'api_calls',   1000),
  ('free',       'members',     3),
  ('starter',    'api_calls',   50000),
  ('starter',    'members',     10),
  ('pro',        'api_calls',   NULL),
  ('pro',        'members',     NULL);
```
