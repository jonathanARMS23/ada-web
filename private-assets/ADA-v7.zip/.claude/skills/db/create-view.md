# create-view
Vue et vue matérialisée avec refresh strategy.

```sql
-- Vue simple
CREATE OR REPLACE VIEW active_resources AS
SELECT r.*, w.name AS workspace_name, u.email AS creator_email
FROM resources r
JOIN workspaces w ON w.id = r.workspace_id
JOIN users u ON u.id = r.created_by_id
WHERE r.deleted_at IS NULL AND r.status = 'active';

-- Vue matérialisée (pour les agrégats coûteux)
CREATE MATERIALIZED VIEW workspace_stats AS
SELECT
  workspace_id,
  COUNT(*) FILTER (WHERE deleted_at IS NULL) AS total,
  COUNT(*) FILTER (WHERE status = 'active') AS active,
  MAX(created_at) AS last_activity
FROM resources
GROUP BY workspace_id;

CREATE UNIQUE INDEX ON workspace_stats(workspace_id);

-- Refresh (via pg_cron ou après chaque écriture critique)
REFRESH MATERIALIZED VIEW CONCURRENTLY workspace_stats;
```
