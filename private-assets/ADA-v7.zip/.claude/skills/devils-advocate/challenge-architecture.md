# challenge-architecture
Contre-analyse d'une décision d'architecture.

## Questions à poser sur toute décision d'architecture

### Complexité
- Est-ce la solution la plus simple qui résout le problème ?
- Sommes-nous en train d'anticiper des besoins hypothétiques ? (YAGNI violation)
- L'équipe peut-elle maintenir cette architecture dans 12 mois ?

### Réversibilité
- Cette décision est-elle facile à annuler si elle s'avère mauvaise ?
- Quel est le coût de migration vers une autre approche dans 6 mois ?

### Opérationnel
- Comment déploie-t-on ça en production ?
- Comment débogue-t-on quand quelque chose ne va pas ?
- Qui est de garde si ça tombe à 3h du matin ?

## Patterns d'over-engineering à signaler
```
❌ Microservices pour < 10k users → monolithe modulaire suffit
❌ Event sourcing sans besoin d'audit trail → complexité gratuite
❌ Kubernetes pour 1 service → Docker Compose + Railway suffit
❌ Cache Redis pour < 1000 requêtes/jour → requêtes DB directes suffisent
❌ GraphQL quand il n'y a qu'un client → REST plus simple
```
