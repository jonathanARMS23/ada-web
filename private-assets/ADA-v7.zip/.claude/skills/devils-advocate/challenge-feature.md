# challenge-feature
Remise en question complète d'une feature avant implémentation.

## Questions systématiques
```
1. Ce besoin est-il réel ou supposé ?
   → Combien d'utilisateurs ont demandé cette feature ?
   → Avons-nous des données qui prouvent ce besoin ?

2. Peut-on résoudre ce problème sans coder ?
   → Workaround documenté possible ?
   → Outil existant non utilisé ?

3. Sommes-nous les bons pour résoudre ça ?
   → Compétence présente dans l'équipe ?
   → Pas mieux servi par un SaaS spécialisé ?

4. Est-ce le bon moment ?
   → Impact sur le sprint courant ?
   → Dépendances techniques bloquantes ?

5. Quels sont les effets de bord ?
   → Features existantes impactées ?
   → Complexité ajoutée pour les futures features ?
```

## Format de sortie
```
## Challenge — <feature>

### Verdict : ✅ Go | ⚠️ Go avec conditions | ❌ No-go

### Hypothèses critiques non validées
| Hypothèse | Si fausse → | Comment valider |
|-----------|-------------|-----------------|

### Alternatives non considérées
- [option + pourquoi potentiellement meilleure]

### Conditions pour approuver
- [ ] [condition 1]
- [ ] [condition 2]
```
