# identify-assumptions
Identifier les hypothèses non validées critiques.

## Catégories d'hypothèses

### Hypothèses sur le problème
- Les utilisateurs ont vraiment ce problème
- Le problème est fréquent (pas un edge case)
- Les utilisateurs sont prêts à payer pour le résoudre

### Hypothèses sur la solution
- La solution proposée résout bien le problème
- Les utilisateurs comprennent comment l'utiliser
- La solution est techniquement faisable dans le délai prévu

### Hypothèses sur le business
- Le marché est suffisamment grand
- Nous pouvons acquérir des clients à un coût acceptable
- Les concurrents ne vont pas répliquer rapidement

## Template
```markdown
## Hypothèses — <feature/décision>

| # | Hypothèse | Criticité | Validée ? | Comment valider |
|---|-----------|-----------|-----------|-----------------|
| 1 | Les users ont X problème | Haute | Non | 5 entretiens utilisateurs |
| 2 | Ils paieraient X€ pour la solution | Haute | Non | Test pricing page |
| 3 | L'intégration Stripe prend < 3j | Moyenne | Partiellement | PoC technique |

### Hypothèse la plus critique
[Si celle-là est fausse → tout le plan s'effondre]
Action : valider en [X jours] avant de commencer le dev
```
