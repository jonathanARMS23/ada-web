# pre-mortem
"Dans 6 mois cette feature a échoué — pourquoi ?"

## Exercice
Projeter dans le futur : la feature est en production depuis 6 mois et c'est un échec.
Travailler à rebours pour identifier ce qui a merdé.

## Template
```markdown
## Pre-mortem — <feature>

### Scénario : 6 mois post-lancement, la feature est un échec

**Symptômes observés (imaginés) :**
- Utilisation < X% des utilisateurs actifs
- Support inondé de questions sur la feature
- Reverted en production après un bug critique

**Causes racines potentielles :**

#### Problème de besoin
- [ ] Les utilisateurs n'avaient pas vraiment ce problème
- [ ] Le problème existait mais la solution proposée ne le résout pas
- [ ] Trop complexe à utiliser (friction d'adoption)

#### Problème technique
- [ ] Performance insuffisante sous charge
- [ ] Edge cases non couverts en prod
- [ ] Dépendance externe défaillante

#### Problème de timing
- [ ] Lancé avant que la base utilisateur soit prête
- [ ] Concurrent a sorti quelque chose de mieux entre-temps

### Actions préventives
[Pour chaque cause probable → action concrète avant de lancer]
```
