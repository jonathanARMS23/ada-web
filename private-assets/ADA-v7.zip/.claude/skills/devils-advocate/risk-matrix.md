# risk-matrix
Matrice des risques avec probabilité, impact et mitigation.

## Template
```markdown
## Risk Matrix — <feature/décision>

| # | Risque | Probabilité | Impact | Score | Mitigation |
|---|--------|-------------|--------|-------|------------|
| 1 | DB migration échoue en prod | Faible | Critique | 🔴 | Rollback plan + test staging |
| 2 | API tierce indisponible | Moyen | Élevé | 🟡 | Circuit breaker + fallback |
| 3 | Performance insuffisante | Moyen | Moyen | 🟡 | Load test avant prod |
| 4 | Adoption faible | Élevé | Moyen | 🟡 | Beta test avec 10 users |

### Légende
- 🔴 Score élevé : traiter avant de commencer
- 🟡 Score moyen : surveiller + plan si ça arrive
- 🟢 Score faible : accepté

### Top 3 risques à traiter maintenant
1. [risque] → [action immédiate]
2. [risque] → [action immédiate]
3. [risque] → [action immédiate]
```
