# stress-test-plan
Plan de stress test : scénarios de défaillance et recovery.

## Scénarios à tester

### Charge
```
Scénario 1 — Charge normale × 10
  Simuler 10x le volume actuel pendant 10 minutes
  Outils : k6, Locust
  Métriques : p95 latence, error rate, CPU, mémoire

Scénario 2 — Pic soudain
  0 → 100x le volume en 30 secondes
  Observer : rate limiting, auto-scaling, queues
```

### Défaillances
```
Scénario 3 — DB lente
  Injecter une latence de 500ms sur toutes les requêtes DB
  Observer : timeouts, retry, dégradation gracieuse

Scénario 4 — Service externe down
  Couper l'accès à Stripe / email / autre service tiers
  Observer : circuit breaker, fallback, message d'erreur utilisateur

Scénario 5 — Instance tombée en plein déploiement
  Tuer une instance pendant un déploiement rolling
  Observer : zéro downtime ou interruption ?
```

## Format de rapport
```markdown
| Scénario | Résultat attendu | Résultat réel | Statut |
|----------|-----------------|---------------|--------|
| Charge ×10 | p95 < 500ms | p95 = 1200ms | ❌ |
```
