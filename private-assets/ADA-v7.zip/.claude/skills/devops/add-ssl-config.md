# add-ssl-config
SSL/TLS avec Nginx et renouvellement automatique.

## Nginx + Certbot (Let's Encrypt)
```bash
# Installer
apt install nginx certbot python3-certbot-nginx

# Obtenir le certificat
certbot --nginx -d api.example.com -d www.example.com --non-interactive --agree-tos -m admin@example.com

# Renouvellement automatique (crontab)
0 0,12 * * * certbot renew --quiet --deploy-hook "systemctl reload nginx"
```

## Config Nginx SSL
```nginx
server {
    listen 443 ssl http2;
    server_name api.example.com;

    ssl_certificate /etc/letsencrypt/live/api.example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/api.example.com/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256;
    ssl_prefer_server_ciphers off;
    add_header Strict-Transport-Security "max-age=63072000" always;
}

server {
    listen 80;
    return 301 https://$host$request_uri;
}
```
