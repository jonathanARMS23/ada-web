# create-backup-strategy
Backup PostgreSQL automatisé avec rétention et test de restore.

## Script backup vers S3
```bash
#!/bin/bash
set -e
DB_URL="${DATABASE_URL}"
BUCKET="${BACKUP_S3_BUCKET}"
TIMESTAMP=$(date +%Y-%m-%d_%H%M%S)
FILENAME="backup_${TIMESTAMP}.sql.gz"

# Dump + compression
pg_dump "$DB_URL" | gzip > "/tmp/$FILENAME"

# Upload S3 avec chiffrement
aws s3 cp "/tmp/$FILENAME" "s3://${BUCKET}/postgres/${FILENAME}" \
  --server-side-encryption AES256

# Cleanup local
rm "/tmp/$FILENAME"

# Supprimer les backups > 30 jours
aws s3 ls "s3://${BUCKET}/postgres/" | awk '{print $4}' | \
  while read f; do
    date=$(echo $f | grep -oP '\d{4}-\d{2}-\d{2}')
    if [[ $(date -d "$date" +%s) -lt $(date -d "30 days ago" +%s) ]]; then
      aws s3 rm "s3://${BUCKET}/postgres/$f"
    fi
  done
echo "✓ Backup $FILENAME terminé"
```

## Cron GitHub Actions (quotidien)
```yaml
on:
  schedule:
    - cron: '0 2 * * *'  # 2h du matin UTC
```
