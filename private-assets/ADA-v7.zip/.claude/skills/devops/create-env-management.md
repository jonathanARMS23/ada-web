# create-env-management
Stratégie .env par environnement avec rotation des secrets.

## Structure
```
.env.example          # template commité (jamais de vraies valeurs)
.env.local            # dev local (gitignored)
.env.test             # tests (valeurs fictives OK)
# Staging/prod : variables dans GitHub Secrets + Railway/AWS
```

## .env.example annoté
```bash
# Base de données
DATABASE_URL=postgresql://user:password@localhost:5432/myapp
# JWT (générer : openssl rand -base64 32)
JWT_SECRET=CHANGE_ME_32_CHARS_MIN
JWT_EXPIRY=15m
REFRESH_TOKEN_EXPIRY=7d
# Externe
STRIPE_SECRET_KEY=sk_test_CHANGE_ME
STRIPE_WEBHOOK_SECRET=whsec_CHANGE_ME
```

## Rotation des secrets (script)
```bash
#!/bin/bash
# Générer un nouveau JWT_SECRET
NEW_SECRET=$(openssl rand -base64 32)
# Mettre à jour sur Railway
railway variables set JWT_SECRET="$NEW_SECRET"
# Mettre à jour dans GitHub Secrets via gh CLI
gh secret set JWT_SECRET --body "$NEW_SECRET"
echo "✓ JWT_SECRET rotated"
```
