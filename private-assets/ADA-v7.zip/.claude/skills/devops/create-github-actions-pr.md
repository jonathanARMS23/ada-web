# create-github-actions-pr
Workflow PR : checks automatiques, labels, reviewers.

```yaml
name: PR Checks

on:
  pull_request:
    types: [opened, synchronize, labeled]

jobs:
  validate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Validate PR title (Conventional Commits)
        uses: amannn/action-semantic-pull-request@v5
        with:
          types: [feat, fix, chore, docs, test, refactor, perf]

      - name: Check branch naming
        run: |
          BRANCH="${{ github.head_ref }}"
          if ! echo "$BRANCH" | grep -qE "^(feature|fix|chore|docs)/"; then
            echo "❌ Branch name must start with feature/, fix/, chore/, or docs/"
            exit 1
          fi

  auto-assign:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Auto-assign reviewers
        uses: kentaro-m/auto-assign-action@v1.2.5
        with:
          configuration-path: '.github/auto-assign.yml'
```
