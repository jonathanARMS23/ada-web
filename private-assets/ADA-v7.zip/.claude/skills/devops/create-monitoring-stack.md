# create-monitoring-stack
Setup Sentry + alertes basiques.

## Sentry NestJS
```typescript
// main.ts
import * as Sentry from '@sentry/node'

Sentry.init({
  dsn: process.env.SENTRY_DSN,
  environment: process.env.NODE_ENV,
  tracesSampleRate: process.env.NODE_ENV === 'production' ? 0.1 : 1.0,
  integrations: [new Sentry.Integrations.Http({ tracing: true })],
})
```

## Sentry Next.js
```bash
npx @sentry/wizard@latest -i nextjs
```

## Alertes GitHub Actions (notification Slack)
```yaml
- name: Notify on failure
  if: failure()
  uses: slackapi/slack-github-action@v1
  with:
    channel-id: 'alerts'
    slack-message: "❌ Deploy failed: ${{ github.workflow }} on ${{ github.ref }}"
  env:
    SLACK_BOT_TOKEN: ${{ secrets.SLACK_BOT_TOKEN }}
```

## Health check monitoring (UptimeRobot / BetterUptime)
- Surveiller : `GET /health` toutes les 60s
- Alerter si status != 200 pendant > 2 min
