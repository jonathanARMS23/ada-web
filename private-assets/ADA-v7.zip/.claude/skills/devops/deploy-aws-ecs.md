# deploy-aws-ecs
Task definition ECS Fargate avec ALB.

## task-definition.json
```json
{
  "family": "api",
  "networkMode": "awsvpc",
  "requiresCompatibilities": ["FARGATE"],
  "cpu": "512", "memory": "1024",
  "executionRoleArn": "arn:aws:iam::ACCOUNT:role/ecsTaskExecutionRole",
  "containerDefinitions": [{
    "name": "api",
    "image": "ghcr.io/org/api:latest",
    "portMappings": [{"containerPort": 3000}],
    "environment": [{"name": "NODE_ENV", "value": "production"}],
    "secrets": [
      {"name": "DATABASE_URL", "valueFrom": "arn:aws:secretsmanager:REGION:ACCOUNT:secret:db-url"}
    ],
    "healthCheck": {
      "command": ["CMD-SHELL", "curl -f http://localhost:3000/health || exit 1"],
      "interval": 30, "timeout": 5, "retries": 3
    },
    "logConfiguration": {
      "logDriver": "awslogs",
      "options": {"awslogs-group": "/ecs/api", "awslogs-region": "eu-west-3", "awslogs-stream-prefix": "ecs"}
    }
  }]
}
```

## Deploy via GitHub Actions
```yaml
- name: Deploy to ECS
  uses: aws-actions/amazon-ecs-deploy-task-definition@v1
  with:
    task-definition: task-definition.json
    service: api-service
    cluster: production
    wait-for-service-stability: true
```
