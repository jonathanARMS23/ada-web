# deploy-railway
Configuration Railway complète.

## railway.toml
```toml
[build]
builder = "dockerfile"
dockerfilePath = "Dockerfile"

[deploy]
startCommand = "node dist/main"
healthcheckPath = "/health"
healthcheckTimeout = 300
restartPolicyType = "ON_FAILURE"
restartPolicyMaxRetries = 3

[[services]]
name = "api"

[[services]]
name = "worker"
startCommand = "node dist/worker"
```

## Variables d'environnement Railway
```bash
railway variables set DATABASE_URL=$DATABASE_URL
railway variables set JWT_SECRET=$(openssl rand -base64 32)
railway variables set NODE_ENV=production
```

## GitHub Actions → Railway
```yaml
- name: Deploy to Railway
  uses: bervProject/railway-deploy@main
  with:
    railway_token: ${{ secrets.RAILWAY_TOKEN }}
    service: api
```
