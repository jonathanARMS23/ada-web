# deploy-vercel
Configuration Vercel pour Next.js.

## vercel.json
```json
{
  "framework": "nextjs",
  "buildCommand": "npm run build",
  "env": {
    "NEXT_PUBLIC_API_URL": "@api_url_production"
  },
  "headers": [
    {
      "source": "/(.*)",
      "headers": [
        { "key": "X-Frame-Options", "value": "DENY" },
        { "key": "X-Content-Type-Options", "value": "nosniff" },
        { "key": "Referrer-Policy", "value": "strict-origin-when-cross-origin" }
      ]
    }
  ]
}
```

## Règles
- Variables NEXT_PUBLIC_* : inoffensives côté client uniquement
- Variables sensibles : Vercel dashboard uniquement, jamais dans vercel.json commité
- Preview deployments sur chaque PR
- Domaine custom avec SSL auto
