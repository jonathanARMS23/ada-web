# write-adr
Architecture Decision Record (stocker dans docs/adr/).

## Template
```markdown
# ADR-XXX — <titre court>
**Date :** YYYY-MM-DD
**Status :** Proposed | Accepted | Deprecated | Superseded by ADR-YYY
**Décideurs :** [noms/rôles]
**Contexte technique :** [stack concernée]

## Contexte
[Situation actuelle. Quel problème doit être résolu ?
Quelles sont les contraintes ?]

## Options considérées

### Option A — [titre]
**Description :** [bref]
**Avantages :** [liste]
**Inconvénients :** [liste]
**Effort :** [estimation]

### Option B — [titre]
...

## Décision
**Option choisie : [X]**

## Justification
[Pourquoi cette option. Quels critères ont pesé.
Quels compromis sont acceptés.]

## Conséquences
**Positives :**
- [liste]

**Négatives / compromis acceptés :**
- [liste]

**Prochaines étapes :**
- [ ] [action] — [responsable] — [délai]
```
