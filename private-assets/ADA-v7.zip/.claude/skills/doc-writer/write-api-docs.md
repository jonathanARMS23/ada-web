# write-api-docs
Documentation API complète avec exemples curl.

## Template par endpoint
```markdown
## POST /api/v1/resources

Crée une nouvelle ressource dans le workspace.

**Auth :** Bearer JWT requis

### Request

```bash
curl -X POST https://api.example.com/api/v1/resources \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Ma ressource",
    "status": "draft"
  }'
```

### Body

| Champ | Type | Requis | Description |
|-------|------|--------|-------------|
| name | string | ✅ | Nom (1-255 chars) |
| status | string | ❌ | draft \| active (défaut: draft) |

### Réponse 201

```json
{
  "id": "550e8400-e29b-41d4-a716-446655440000",
  "name": "Ma ressource",
  "status": "draft",
  "workspaceId": "...",
  "createdAt": "2024-01-15T10:30:00Z"
}
```

### Erreurs

| Code | Status | Description |
|------|--------|-------------|
| VALIDATION_ERROR | 422 | Données invalides (voir details) |
| UNAUTHORIZED | 401 | Token manquant ou invalide |
```
