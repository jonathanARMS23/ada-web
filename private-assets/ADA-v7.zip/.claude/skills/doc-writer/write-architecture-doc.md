# write-architecture-doc
Document d'architecture global du projet.

## Template
```markdown
# Architecture — <projet>

## Vue d'ensemble

[Diagramme textuel de l'architecture]
```
Client → CDN → Load Balancer → API (NestJS) → PostgreSQL
                                            → Redis (cache)
                                            → Queue (BullMQ) → Worker
```

## Composants

### API (NestJS)
- **Rôle :** Servir les requêtes REST, authentification, validation
- **Fichiers clés :** `src/app.module.ts`, `src/main.ts`
- **Port :** 3000

### Base de données (PostgreSQL)
- **Rôle :** Stockage principal
- **Version :** 15
- **ORM :** Prisma 5.x
- **Schéma :** `prisma/schema.prisma`

### Cache (Redis)
- **Rôle :** Cache des requêtes fréquentes, sessions, rate limiting
- **TTL default :** 5 minutes
- **Pattern :** Cache-aside

## Décisions d'architecture (ADRs)

| ADR | Décision |
|-----|----------|
| [ADR-001](docs/adr/001-database.md) | PostgreSQL vs MongoDB |
| [ADR-002](docs/adr/002-auth.md) | JWT vs sessions |

## Flows principaux

### Authentification
[Diagramme textuel du flow auth]

### Traitement asynchrone
[Diagramme queue + worker]

## Points d'attention
- [Dette technique connue]
- [Limites actuelles de l'architecture]
- [Plan d'évolution]
```
