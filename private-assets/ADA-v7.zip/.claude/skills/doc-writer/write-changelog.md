# write-changelog
Changelog Keep a Changelog avec breaking changes.

## Format
```markdown
# Changelog

Toutes les modifications notables sont documentées ici.
Format : [Keep a Changelog](https://keepachangelog.com/fr/1.0.0/)
Versioning : [Semantic Versioning](https://semver.org/lang/fr/)

## [Unreleased]

## [1.2.0] — 2024-01-15

### ⚠️ Breaking Changes
- `GET /api/v1/resources` : le champ `data.items` est renommé `data.resources`
  **Migration :** mettre à jour les clients qui lisent `response.data.items`

### Added
- Pagination cursor sur `/resources` (plus performante pour > 10k items)
- Nouvel endpoint `POST /resources/batch` pour les créations en masse

### Changed
- Les tokens JWT expirent maintenant après 15min (était 24h)
- Rate limiting abaissé à 100 req/min (était 1000)

### Fixed
- Correction du bug où les ressources archivées apparaissaient dans les listes
- Fix de la validation email qui rejetait les domaines .io

### Deprecated
- `GET /api/v1/resources?page=N` : sera supprimé en v2.0, migrer vers cursor pagination

## [1.1.0] — 2024-01-01
...
```
