# write-onboarding-guide
Guide onboarding développeur : setup, conventions, workflow.

## Template
```markdown
# Guide Onboarding — <projet>

## Bienvenue

Ce guide te permettra de contribuer au projet en < 30 minutes.

## Prérequis

| Outil | Version | Installation |
|-------|---------|-------------|
| Node.js | >= 20 | [nodejs.org](https://nodejs.org) |
| Docker | >= 24 | [docker.com](https://www.docker.com) |

## Setup (5 minutes)

```bash
git clone https://github.com/org/repo
cd repo
cp .env.example .env
docker compose up -d          # PostgreSQL + Redis
npm install
npm run db:migrate
npm run dev
```

Vérifier : `curl http://localhost:3000/health` → `{"status":"ok"}`

## Architecture

[Diagramme textuel ou lien vers ADR]

## Conventions

### Code
- NestJS : module → controller → service → repository
- Pas de logique dans les controllers
- Toujours filtrer par workspaceId dans les services

### Git
- Branches : `feature/ticket-slug`
- Commits : `feat: add resource endpoint`
- PR vers `dev` uniquement

### Tests
- Écrire les specs AVANT le code (TDD)
- `npm test` doit passer avant tout commit

## Ton premier ticket

1. Choisir un ticket labellisé `good-first-issue`
2. Créer une branche : `git checkout -b feature/ton-ticket`
3. Implémenter avec tests
4. PR vers `dev` avec description

## Questions

Slack #dev ou ouvrir une issue GitHub
```
