# write-postmortem
Post-mortem incident — blameless, factuel, actionnable.

## Template
```markdown
# Post-mortem — <incident>
**Date :** YYYY-MM-DD
**Durée :** Xh Xmin
**Sévérité :** P0 / P1 / P2
**Auteur :** [nom]

## Résumé
[2-3 phrases décrivant l'incident et son impact]

## Timeline

| Heure | Événement |
|-------|-----------|
| HH:MM | Premier symptôme détecté |
| HH:MM | Alerte déclenchée |
| HH:MM | Cause identifiée |
| HH:MM | Mitigation appliquée |
| HH:MM | Service restauré |

## Cause racine
[Description technique précise de ce qui a causé l'incident]

## Impact
- Utilisateurs affectés : X
- Durée d'indisponibilité : Xh
- Transactions perdues : X
- Impact financier estimé : X€

## Ce qui a bien fonctionné
- [liste]

## Ce qui a mal fonctionné
- [liste]

## Actions correctives

| Action | Responsable | Délai | Status |
|--------|-------------|-------|--------|
| Ajouter alerte X | [nom] | Sprint N | TODO |
| Améliorer runbook | [nom] | Sprint N | TODO |

## Leçons apprises
[2-3 points clés pour l'équipe]
```

## Règles
- Blameless : décrire les systèmes et processus, pas les personnes
- Publier dans les 48-72h après l'incident
- Actions concrètes avec responsable + délai, jamais de vague "améliorer la monitoring"
