# write-readme
README complet et actionnable.

## Template
```markdown
# <Nom du Projet>

> Une ligne qui dit ce que fait le projet.

## Quick Start

```bash
git clone https://github.com/org/repo
cd repo
cp .env.example .env
npm install
npm run dev
```

## Configuration

| Variable | Description | Défaut |
|----------|-------------|--------|
| `DATABASE_URL` | URL PostgreSQL | — |
| `JWT_SECRET` | Clé secrète JWT (min 32 chars) | — |
| `PORT` | Port du serveur | `3000` |

## Architecture

```
src/
  modules/     # Modules NestJS (un par domaine)
  prisma/      # Schéma et migrations DB
  config/      # Configuration et validation
```

[Tech stack en 3 lignes max]

## Développement

```bash
npm run test          # Tests unitaires
npm run test:e2e      # Tests E2E
npm run lint          # Lint + typecheck
docker compose up     # Stack locale complète
```

## Déploiement

[2-3 commandes ou lien vers la doc de déploiement]

## Contributing

[Lien vers CONTRIBUTING.md ou 3 lignes max]
```

## Règles
- Quick start fonctionnel en < 5 minutes
- Pas de sections vides ou "coming soon"
- Examples de code testés et à jour
