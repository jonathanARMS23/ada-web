# write-runbook
Runbook opérationnel pour déploiement et incidents.

## Template
```markdown
# Runbook — <service>

## Déploiement standard

```bash
# 1. Vérifier que les tests passent
git checkout staging
git pull origin staging
npm test

# 2. Déployer en staging
git push origin staging
# Attendre le pipeline CI (~5min)

# 3. Vérifier staging
curl https://staging.api.example.com/health

# 4. Merger en production
git checkout main
git merge staging
git push origin main
```

## Rollback

```bash
# Identifier le SHA de la version stable
git log --oneline -10

# Rollback
git revert HEAD --no-edit
git push origin main
```

## Incidents courants

### Service DOWN (health check KO)
1. `docker ps` → vérifier que le container tourne
2. `docker logs api --tail 100` → lire les erreurs
3. `psql $DATABASE_URL -c "SELECT 1"` → vérifier la DB
4. Si DB down → redémarrer le service DB
5. Si code → rollback

### Migration échouée
1. Vérifier les logs : `npx prisma migrate status`
2. Rollback : `npx prisma migrate resolve --rolled-back <migration>`
3. Appliquer le fix → relancer

### Performance dégradée
1. `EXPLAIN ANALYZE <requête lente>`
2. Vérifier Redis : `redis-cli info stats`
3. Vérifier le pool DB : métriques Prisma
```
