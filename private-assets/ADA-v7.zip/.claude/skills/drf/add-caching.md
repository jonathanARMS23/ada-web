# add-caching
Cache Redis sur QuerySets et views DRF.

## Cache sur une view
```python
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page

@method_decorator(cache_page(60 * 15), name='list')  # 15 min
class ResourceViewSet(viewsets.ModelViewSet):
    pass
```

## Cache manuel sur queryset
```python
from django.core.cache import cache

class ResourceService:
    @staticmethod
    def get_active(workspace_id: str):
        cache_key = f"resources:active:{workspace_id}"
        result = cache.get(cache_key)
        if result is None:
            result = list(Resource.objects.filter(
                workspace_id=workspace_id, status='active', deleted_at__isnull=True
            ).values())
            cache.set(cache_key, result, timeout=300)  # 5 min
        return result

    @staticmethod
    def invalidate(workspace_id: str):
        cache.delete(f"resources:active:{workspace_id}")
```
