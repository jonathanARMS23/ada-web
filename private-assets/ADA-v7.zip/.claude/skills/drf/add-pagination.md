# add-pagination
Pagination cursor-based ou offset selon le volume.

## Cursor pagination (recommandé > 10k lignes)
```python
from rest_framework.pagination import CursorPagination

class ResourceCursorPagination(CursorPagination):
    page_size = 20
    max_page_size = 100
    ordering = '-created_at'
    cursor_query_param = 'cursor'

# Dans le ViewSet :
pagination_class = ResourceCursorPagination
```

## Page-number pagination
```python
from rest_framework.pagination import PageNumberPagination

class StandardPagination(PageNumberPagination):
    page_size = 20
    page_size_query_param = 'limit'
    max_page_size = 100

    def get_paginated_response(self, data):
        return Response({
            'total': self.page.paginator.count,
            'next': self.get_next_link(),
            'previous': self.get_previous_link(),
            'data': data,
        })
```
