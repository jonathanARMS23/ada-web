# create-app
Scaffolde une app Django complète.

## Étapes
```bash
python manage.py startapp <name>
```
Structure cible :
```
<name>/
  models.py       # modèles + managers custom
  serializers.py  # serializers DRF
  views.py        # ViewSets
  urls.py         # router
  permissions.py  # permissions custom
  filters.py      # django-filter
  tests/
    test_models.py
    test_views.py
  factories.py    # factory_boy
```

## Enregistrer
```python
# settings.py
INSTALLED_APPS = [..., '<name>']
# urls.py principal
router.register(r'<name>', <Name>ViewSet)
```
