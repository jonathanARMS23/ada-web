# create-celery-beat
Tâche planifiée avec django-celery-beat.

## Setup
```python
# settings.py
CELERY_BEAT_SCHEDULER = 'django_celery_beat.schedulers:DatabaseScheduler'
```

## Définir la tâche
```python
@shared_task(bind=True)
def cleanup_expired_resources(self):
    from django.utils import timezone
    deleted, _ = Resource.objects.filter(
        expires_at__lt=timezone.now(),
        deleted_at__isnull=True
    ).update(deleted_at=timezone.now())
    logger.info(f"Cleanup: {deleted} ressources expirées")
    return deleted
```

## Enregistrer via migration
```python
from django_celery_beat.models import PeriodicTask, CrontabSchedule
import json

schedule, _ = CrontabSchedule.objects.get_or_create(
    minute='0', hour='2', day_of_week='*',
    day_of_month='*', month_of_year='*',
)
PeriodicTask.objects.get_or_create(
    crontab=schedule, name='Cleanup expired resources',
    defaults={'task': 'myapp.tasks.cleanup_expired_resources', 'args': json.dumps([])}
)
```
