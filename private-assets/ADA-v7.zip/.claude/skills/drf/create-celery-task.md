# create-celery-task
Tâche Celery avec retry, logging, idempotence.

## Template
```python
from celery import shared_task
from celery.utils.log import get_task_logger

logger = get_task_logger(__name__)

@shared_task(
    bind=True,
    max_retries=3,
    default_retry_delay=60,
    autoretry_for=(Exception,),
    retry_backoff=True,
)
def process_resource(self, resource_id: str) -> dict:
    logger.info(f"Processing resource {resource_id}")
    try:
        resource = Resource.objects.get(id=resource_id)
        # traitement idempotent
        return {'status': 'ok', 'id': resource_id}
    except Resource.DoesNotExist:
        logger.warning(f"Resource {resource_id} not found — skipping")
        return {'status': 'skipped'}
    except Exception as exc:
        logger.error(f"Failed: {exc}")
        raise self.retry(exc=exc)
```

## Lancer
```python
process_resource.delay(resource_id)
process_resource.apply_async(args=[resource_id], countdown=30)
```
