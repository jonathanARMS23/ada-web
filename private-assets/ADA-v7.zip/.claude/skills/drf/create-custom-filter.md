# create-custom-filter
Filtre django-filter avec lookups custom.

## Filtre complet
```python
import django_filters
from django_filters import rest_framework as filters

class ResourceFilter(filters.FilterSet):
    name = filters.CharFilter(lookup_expr='icontains')
    status = filters.MultipleChoiceFilter(choices=Resource.STATUS_CHOICES)
    created_after = filters.DateTimeFilter(field_name='created_at', lookup_expr='gte')
    created_before = filters.DateTimeFilter(field_name='created_at', lookup_expr='lte')
    has_tags = filters.BooleanFilter(method='filter_has_tags')

    class Meta:
        model = Resource
        fields = ['name', 'status', 'created_after', 'created_before']

    def filter_has_tags(self, queryset, name, value):
        return queryset.filter(tags__isnull=not value).distinct()

# Dans le ViewSet :
filter_backends = [DjangoFilterBackend]
filterset_class = ResourceFilter
```
