# create-custom-permission
Permissions DRF custom — ownership, workspace, rôle.

## Permission IsWorkspaceMember
```python
class IsWorkspaceMember(permissions.BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and
                    hasattr(request.user, 'workspace'))

    def has_object_permission(self, request, view, obj):
        workspace = getattr(obj, 'workspace', None) or getattr(obj, 'workspace_id', None)
        return workspace == request.user.workspace

# Usage : permission_classes = [IsAuthenticated, IsWorkspaceMember]
```

## Permission IsOwnerOrReadOnly
```python
class IsOwnerOrReadOnly(permissions.BasePermission):
    def has_object_permission(self, request, view, obj):
        if request.method in permissions.SAFE_METHODS:
            return True
        return obj.created_by == request.user
```

## Permission IsAdmin
```python
class IsWorkspaceAdmin(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user.role in ['admin', 'owner']
```
