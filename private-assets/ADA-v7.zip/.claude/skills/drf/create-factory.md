# create-factory
Factories factory_boy pour les modèles.

## Template
```python
import factory
from factory.django import DjangoModelFactory
from faker import Faker

fake = Faker('fr_FR')

class WorkspaceFactory(DjangoModelFactory):
    class Meta:
        model = Workspace

    name = factory.LazyFunction(lambda: fake.company())
    slug = factory.LazyAttribute(lambda o: slugify(o.name))

class UserFactory(DjangoModelFactory):
    class Meta:
        model = User

    email = factory.Sequence(lambda n: f"user{n}@test.com")
    workspace = factory.SubFactory(WorkspaceFactory)

class ResourceFactory(DjangoModelFactory):
    class Meta:
        model = Resource

    name = factory.Faker('word')
    workspace = factory.SubFactory(WorkspaceFactory)
    created_by = factory.SubFactory(UserFactory)
    status = 'active'
```

## Usage dans les tests
```python
resource = ResourceFactory()
resources = ResourceFactory.create_batch(5, status='archived')
```
