# create-management-command
Commande manage.py avec dry-run et verbosité.

## Template
```python
# management/commands/sync_resources.py
from django.core.management.base import BaseCommand, CommandError

class Command(BaseCommand):
    help = 'Synchronise les ressources depuis la source externe'

    def add_arguments(self, parser):
        parser.add_argument('--workspace', type=str, help='ID workspace spécifique')
        parser.add_argument('--dry-run', action='store_true', help='Simuler sans sauvegarder')
        parser.add_argument('--batch-size', type=int, default=100)

    def handle(self, *args, **options):
        dry_run = options['dry_run']
        workspace_id = options.get('workspace')

        if dry_run:
            self.stdout.write(self.style.WARNING('Mode dry-run — aucune modification'))

        qs = Workspace.objects.all()
        if workspace_id:
            qs = qs.filter(id=workspace_id)

        for workspace in qs:
            try:
                count = self._sync_workspace(workspace, dry_run, options['batch_size'])
                self.stdout.write(self.style.SUCCESS(f'✓ {workspace.name}: {count} ressources'))
            except Exception as e:
                self.stderr.write(self.style.ERROR(f'✗ {workspace.name}: {e}'))

    def _sync_workspace(self, workspace, dry_run, batch_size):
        # logique métier
        return 0
```
