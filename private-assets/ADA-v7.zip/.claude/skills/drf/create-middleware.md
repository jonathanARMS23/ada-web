# create-middleware
Middleware Django (tenant, logging, perf).

## Middleware de workspace (multi-tenant)
```python
class WorkspaceMiddleware(MiddlewareMixin):
    def process_request(self, request):
        if request.user.is_authenticated and hasattr(request.user, 'workspace'):
            request.workspace = request.user.workspace
        else:
            request.workspace = None

# settings.py MIDDLEWARE : ajouter après AuthenticationMiddleware
```

## Middleware de logging des requêtes
```python
import time, logging
logger = logging.getLogger('api.requests')

class RequestLoggingMiddleware(MiddlewareMixin):
    def process_request(self, request):
        request._start_time = time.monotonic()

    def process_response(self, request, response):
        duration = (time.monotonic() - getattr(request, '_start_time', 0)) * 1000
        if duration > 500:  # log seulement les requêtes lentes
            logger.warning(f'SLOW {request.method} {request.path} {response.status_code} {duration:.0f}ms')
        return response
```
