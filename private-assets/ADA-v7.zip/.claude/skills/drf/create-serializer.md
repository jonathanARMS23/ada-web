# create-serializer
Serializer DRF avec validation métier et nested writable.

## Template basique
```python
class ResourceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Resource
        fields = ['id', 'name', 'status', 'created_at']
        read_only_fields = ['id', 'created_at']

    def validate_name(self, value):
        if len(value) < 3:
            raise serializers.ValidationError("Min 3 caractères")
        return value

    def validate(self, attrs):
        # validation cross-champs
        return attrs
```

## Nested writable
```python
class OrderSerializer(serializers.ModelSerializer):
    line_items = LineItemSerializer(many=True)

    def create(self, validated_data):
        items = validated_data.pop('line_items')
        order = Order.objects.create(**validated_data)
        for item in items:
            LineItem.objects.create(order=order, **item)
        return order
```
