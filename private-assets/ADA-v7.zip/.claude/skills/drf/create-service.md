# create-service
Service pur Python — logique métier hors des views.

## Template
```python
# services/resource_service.py
from django.db import transaction
from django.core.exceptions import ValidationError

class ResourceService:
    @staticmethod
    @transaction.atomic
    def create(workspace, user, data: dict) -> Resource:
        if Resource.objects.filter(workspace=workspace, name=data['name']).exists():
            raise ValidationError({"name": "Une ressource avec ce nom existe déjà"})
        resource = Resource.objects.create(
            workspace=workspace, created_by=user, **data
        )
        ResourceCreatedEvent.send(resource)
        return resource

    @staticmethod
    def archive(resource: Resource, user) -> Resource:
        if resource.status == 'archived':
            raise ValidationError("Ressource déjà archivée")
        resource.status = 'archived'
        resource.archived_by = user
        resource.save(update_fields=['status', 'archived_by', 'updated_at'])
        return resource
```

## Dans la view
```python
def perform_create(self, serializer):
    ResourceService.create(
        workspace=self.request.user.workspace,
        user=self.request.user,
        data=serializer.validated_data
    )
```
