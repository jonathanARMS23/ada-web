# create-signal
Signal Django avec découplage correct.

## Définir
```python
# signals.py
from django.db.models.signals import post_save, pre_delete
from django.dispatch import receiver

@receiver(post_save, sender=Resource)
def resource_post_save(sender, instance, created, **kwargs):
    if created:
        # Créer les ressources dérivées
        Notification.objects.create(
            user=instance.created_by,
            message=f"Ressource '{instance.name}' créée"
        )

@receiver(pre_delete, sender=Resource)
def resource_pre_delete(sender, instance, **kwargs):
    # Nettoyer avant suppression
    instance.attachments.all().delete()
```

## Connecter dans AppConfig
```python
class ResourceConfig(AppConfig):
    name = 'resource'
    def ready(self):
        import resource.signals  # noqa
```
