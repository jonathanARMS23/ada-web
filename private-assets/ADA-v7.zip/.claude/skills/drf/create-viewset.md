# create-viewset
ViewSet DRF avec permissions, filtres, pagination.

## Template
```python
class ResourceViewSet(viewsets.ModelViewSet):
    serializer_class = ResourceSerializer
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_fields = ['status', 'workspace']
    search_fields = ['name', 'description']
    ordering_fields = ['created_at', 'name']
    ordering = ['-created_at']

    def get_queryset(self):
        return Resource.objects.filter(
            workspace=self.request.user.workspace,
            deleted_at__isnull=True,
        ).select_related('created_by')

    def perform_create(self, serializer):
        serializer.save(
            workspace=self.request.user.workspace,
            created_by=self.request.user,
        )
```

## Règles
- get_queryset() TOUJOURS filtré par workspace
- select_related/prefetch_related pour éviter N+1
- perform_create() pour injecter workspace/user
