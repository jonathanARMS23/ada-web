# create-webhook-handler
Handler webhook entrant avec validation signature.

## View webhook
```python
import hmac, hashlib

class WebhookView(APIView):
    authentication_classes = []
    permission_classes = [AllowAny]

    def post(self, request, provider: str):
        if not self._verify_signature(request, provider):
            return Response({'error': 'Signature invalide'}, status=401)

        payload = request.data
        event_type = payload.get('type') or request.headers.get('X-Event-Type')

        # Idempotence : ignorer les doublons
        event_id = request.headers.get('X-Event-Id', '')
        if event_id and WebhookEvent.objects.filter(external_id=event_id).exists():
            return Response({'status': 'already_processed'})

        WebhookEvent.objects.create(provider=provider, external_id=event_id, payload=payload)
        process_webhook.delay(provider, event_type, payload)
        return Response({'status': 'ok'})

    def _verify_signature(self, request, provider: str) -> bool:
        secret = settings.WEBHOOK_SECRETS.get(provider, '')
        sig = request.headers.get('X-Signature', '').removeprefix('sha256=')
        expected = hmac.new(secret.encode(), request.body, hashlib.sha256).hexdigest()
        return hmac.compare_digest(sig, expected)
```
