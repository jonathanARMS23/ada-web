# design-feature
Concevoir l'architecture complète d'une feature.

## Template de sortie
```markdown
## Architecture — <nom feature>

### Contexte codebase
- Stack : [détectée]
- Patterns existants : [ex: repository pattern]
- Conventions : [nommage, structure]

### Impact sur l'existant
- Modules touchés : [liste]
- Tables modifiées : [liste]
- Breaking changes : [oui/non + détail]

### Schéma DB (si applicable)
[SQL ou description des tables/colonnes]

### Endpoints API
| Méthode | Route | Auth | Description |
|---------|-------|------|-------------|

### Composants frontend (si applicable)
[pages, composants, état, appels API]

### Plan de délégation
1. db → [migrations]
2. tester → [specs]
3. nestjs/drf → [modules]
4. nextjs → [pages/composants]
5. reviewer → [review finale]

### Complexité : simple / modérée / complexe
### Estimation : X j/h
```
