# estimate-complexity
Estimer complexité et effort d'une feature.

## Grille d'estimation

### Simple (0.5-1 j/h)
- 1 table, ≤ 3 endpoints CRUD basiques
- Pas de logique métier complexe
- Pas d'intégration tierce
- Composant frontend autonome

### Modérée (2-5 j/h)
- 2-3 tables liées
- Logique métier avec cas d'exception
- 1 intégration tierce simple
- Plusieurs composants interdépendants

### Complexe (5-10 j/h)
- Refonte de module existant
- Logique asynchrone (queues, events)
- Plusieurs intégrations tierces
- Impact cross-modules

## Format de sortie
```
Complexité : [simple/modérée/complexe]
Effort estimé :
  - DB : X h
  - Backend : X h
  - Frontend : X h
  - Tests : X h
  - Review : X h
  Total : X j/h
Risques : [liste]
Dépendances bloquantes : [liste]
```
