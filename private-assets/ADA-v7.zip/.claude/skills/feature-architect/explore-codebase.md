# explore-codebase
Exploration grep-first structurée — lire le moins possible.

## Protocole (ordre strict)
```bash
# Étape 1 — Structure (gratuit)
find . -maxdepth 3 -type d | grep -v "node_modules\|.git\|dist\|.next" | head -30

# Étape 2 — Modèles/Entités (grep, pas lecture)
grep -r "class\|interface\|@Entity\|@Table\|model " src/ --include="*.ts" -l | head -10
grep -r "models.Model\|class.*Model" . --include="*.py" -l | head -10

# Étape 3 — Routes/Endpoints (grep)
grep -r "@Controller\|@Get\|@Post\|router\." src/ --include="*.ts" | head -20
grep -r "path=\|url(" . --include="*.py" | grep -v "test\|migration" | head -20

# Étape 4 — Seulement si nécessaire : lire UN fichier clé
wc -l src/app.module.ts  # vérifier la taille avant
cat src/app.module.ts    # si < 150 lignes

# Ne jamais faire cat sur un fichier sans vérifier wc -l avant
```

## Rapport d'exploration
```
Stack : [détectée]
Patterns : [repository/service/viewset/etc]
Modules existants : [liste]
Points d'entrée : [fichiers clés]
Conventions : [nommage, structure]
```
