# identify-breaking-changes
Détecter les breaking changes avant implémentation.

## Types de breaking changes

### DB
- Suppression ou renommage d'une colonne utilisée par l'ORM
- Changement de type d'une colonne
- Ajout d'une contrainte NOT NULL sans valeur par défaut
- Suppression d'une table référencée

### API
- Suppression d'un champ de réponse
- Changement de type ou de format d'un champ
- Changement du comportement d'un endpoint (status code, pagination)
- Suppression d'un endpoint

### Code
- Changement de signature d'une fonction publique
- Changement de comportement d'un service partagé
- Renommage d'un export

## Détection grep
```bash
# Trouver toutes les utilisations d'un champ/méthode à changer
grep -rn "\.oldField\b\|oldMethodName(" src/ --include="*.ts"
grep -rn "old_field\|old_method" . --include="*.py"

# Vérifier si un endpoint est utilisé côté client
grep -rn "\/api\/v1\/old-route" src/ --include="*.ts" app/ --include="*.tsx"
```

## Format de sortie
```
## Breaking Changes — <feature>

🔴 BLOQUANTS (à gérer avant déploiement)
  - [changement] → [impact] → [migration nécessaire]

🟡 À PLANIFIER (expand/contract)
  - [changement] → [stratégie en N phases]
```
