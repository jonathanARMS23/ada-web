# map-dependencies
Cartographier les dépendances d'une feature sur l'existant.

## Étapes (grep-first)
```bash
# 1. Trouver les modules qui utilisent le concept ciblé
grep -r "ResourceService\|ResourceModule" src/ --include="*.ts" -l

# 2. Trouver les imports
grep -rn "import.*Resource" src/ --include="*.ts" | grep -v "spec\|test"

# 3. Trouver les références DB (Prisma)
grep -rn "prisma\.resource\b" src/ --include="*.ts"

# 4. Trouver les routes API existantes
grep -rn "@Controller\|@Get\|@Post" src/ --include="*.ts" | grep -i "resource"
```

## Carte de dépendances
```markdown
## Dépendances — <feature>

### Modules impactés
| Module | Type d'impact | Fichiers |
|--------|--------------|---------|
| OrderModule | Dépend de Resource | orders.service.ts:45 |

### Tables DB touchées
| Table | Opération | Raison |
|-------|-----------|--------|

### Endpoints existants affectés
| Route | Impact |
|-------|--------|

### Breaking changes potentiels
- [changement] → [modules impactés]
```
