# reverse-engineer-feature
Comprendre une feature existante à partir du code seul.

## Protocole (grep-first)
```bash
# 1. Trouver le point d'entrée (controller/view)
grep -rn "resourceName\|feature-keyword" src/ --include="*.ts" -l | head -5

# 2. Lire uniquement les signatures (pas les corps)
grep -n "async\|def \|function\|export" src/module/service.ts | head -30

# 3. Tracer le flux de données
grep -rn "service\.\|repository\.\|prisma\." src/controller.ts

# 4. Identifier les dépendances
grep -n "constructor.*private\|@Inject\|@Autowired" src/service.ts
```

## Rapport de reverse engineering
```markdown
## Feature Analysis — <nom>

### Ce que ça fait
[Description en langage métier]

### Flux de données
```
Request → Controller → Service → Repository → DB
                    → ExternalService
```

### Règles métier identifiées
[Liste des conditions et validations dans le code]

### Dépendances externes
[Services tiers, queues, events]

### Points obscurs
[Logique difficile à comprendre → documenter ou refactorer]
```
