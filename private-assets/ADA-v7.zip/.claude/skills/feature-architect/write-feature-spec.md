# write-feature-spec
Spécification fonctionnelle complète d'une feature.

## Template
```markdown
## Feature Spec — <nom>
**Date :** YYYY-MM-DD
**Status :** Draft | Approved
**Complexité :** Simple / Modérée / Complexe

### User Stories
- En tant que [rôle], je veux [action] afin de [bénéfice]
- En tant que [rôle], je veux [action] afin de [bénéfice]

### Acceptance Criteria
- [ ] Quand [condition], alors [comportement attendu]
- [ ] Quand [condition], alors [comportement attendu]
- [ ] Les erreurs de validation retournent [format attendu]
- [ ] L'accès est refusé si [condition de sécurité]

### Non-scope
[Ce que cette feature ne fait PAS — explicite]

### Données requises
[Tables, colonnes, relations]

### API endpoints
[Liste des endpoints à créer/modifier]

### UI/UX
[Lien vers wireframes ou description des écrans]

### Tests d'acceptance
[Scénarios E2E à implémenter]

### Plan de délégation
1. db → [migrations]
2. tester → [specs TDD]
3. backend → [implémentation]
4. frontend → [composants]
```
