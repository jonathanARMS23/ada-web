# build-vs-buy-analysis
Analyse build/buy/intégrer pour une fonctionnalité.

## Template
```markdown
## Build vs Buy — <fonctionnalité>

### Options

#### Option 1 — Build
- Coût dev : X€ (Y j/h)
- Temps livraison : X semaines
- Maintenance : X h/mois
- Différenciation : oui/non
- Contrôle total : oui

#### Option 2 — Buy/SaaS (ex: Stripe, Auth0, Algolia)
- Coût mensuel : X€/mois (X€/an)
- Intégration : X h dev
- Maintenance : quasi nulle
- Vendor lock-in : oui/non
- Fonctionnalités manquantes : [liste]

#### Option 3 — Open Source + héberger
- Coût initial : X h install
- Coût hébergement : X€/mois
- Maintenance : X h/mois
- Exemples : Meilisearch, Keycloak, Metabase

### Recommandation
[Option choisie + justification en 2 phrases]

### Règle générale
- Cœur de métier → toujours Build
- Infrastructure commune → Buy ou Open Source
- Commodité (email, paiement, auth) → Buy
```
