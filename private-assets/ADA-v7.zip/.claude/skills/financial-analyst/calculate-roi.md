# calculate-roi
Calculer le ROI d'une feature ou décision technique.

## Template
```markdown
## ROI Analysis — <feature>

### Investissement
- Coût développement : X€
- Coût maintenance annuel : X€
- **Total année 1 :** X€

### Revenus générés / coûts évités
| Source | Calcul | Valeur annuelle |
|--------|--------|-----------------|
| Nouveaux clients | X clients × Y€ MRR | Z€ |
| Rétention améliorée | X% churn réduit × Y clients × Z€ | W€ |
| Support réduit | X tickets évités × Y€/ticket | Z€ |
| **Total** | | **X€** |

### Métriques clés
- ROI année 1 : (revenus - coût) / coût × 100 = X%
- Payback period : X mois
- NPV 3 ans (taux 10%) : X€

### Scénarios
| Scénario | Hypothèse | ROI |
|----------|-----------|-----|
| Pessimiste | 50% des projections | X% |
| Base | projections actuelles | Y% |
| Optimiste | 150% des projections | Z% |
```
