# estimate-dev-cost
Estimer le coût de développement d'une feature.

## Grille de taux horaires (ajuster selon contexte)
```
Dev senior : 80-150€/h
Dev mid    : 50-80€/h
Dev junior : 30-50€/h
Claude Code (Sonnet) : ~0.003€/1k tokens → ~0.5-2€/h de dev assisté
```

## Template
```markdown
## Estimation coût — <feature>

| Phase | Agent | Effort (h) | Coût (€) |
|-------|-------|------------|----------|
| DB + migrations | db | 2h | 160€ |
| Specs TDD | tester | 1h | 80€ |
| Backend NestJS | nestjs | 4h | 320€ |
| Frontend Next.js | nextjs | 4h | 320€ |
| Tests + review | tester + reviewer | 2h | 160€ |
| **Total** | | **13h** | **1040€** |

### Coût d'opportunité
[Quelle feature ne sera pas faite à la place ?]
[Quelle est la valeur de cette feature non faite ?]

### Coût de maintenance estimé
[X h/mois pour maintenance, bugs, évolutions mineures]
[Coût mensuel : X€]

### ROI break-even
[À partir de X nouveaux clients ou X% réduction churn → rentabilisé en Y mois]
```
