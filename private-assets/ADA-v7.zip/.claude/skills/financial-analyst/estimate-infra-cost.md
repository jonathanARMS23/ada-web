# estimate-infra-cost
Estimation coût infrastructure mensuel et à l'échelle.

## Template
```markdown
## Coût Infrastructure — <service>

### Environnement staging
| Ressource | Spec | Coût/mois |
|-----------|------|-----------|
| API server | Railway Starter | 5€ |
| PostgreSQL | Railway + 1GB | 10€ |
| Redis | Upstash free | 0€ |
| **Total staging** | | **15€/mois** |

### Production — 100 users actifs
| Ressource | Spec | Coût/mois |
|-----------|------|-----------|
| API (2 instances) | Railway Pro × 2 | 40€ |
| PostgreSQL | Railway + 10GB | 25€ |
| Redis | Upstash 100k cmd | 10€ |
| CDN + Storage | Cloudflare R2 | 5€ |
| Monitoring | Sentry Team | 26€ |
| **Total prod** | | **106€/mois** |

### Scaling costs
| Volume | Coût infra/mois | Coût/user |
|--------|----------------|-----------|
| 100 users | 106€ | 1.06€ |
| 1000 users | 350€ | 0.35€ |
| 10000 users | 1200€ | 0.12€ |

### Break-even
Pour être rentable à [pricing €/user/mois] :
Seuil minimum : X users
```
