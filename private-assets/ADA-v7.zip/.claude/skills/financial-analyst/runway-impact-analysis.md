# runway-impact-analysis
Impact d'une décision technique sur le runway.

## Template
```markdown
## Runway Impact — <décision>

### État actuel
- Cash disponible : X€
- Burn rate mensuel : X€/mois
- Runway actuel : X mois

### Impact de la décision

#### Coût direct
- Développement : X€ (X j/h × X€/h)
- Infra supplémentaire : X€/mois
- Licences/SaaS : X€/mois

#### Impact sur le burn rate
Avant : X€/mois
Après : X€/mois (+X€/mois)

#### Nouveau runway
Cash / nouveau burn rate = X mois (vs X mois actuels)

#### Impact sur le runway : -X mois

### Justification
[La décision se justifie si elle génère X€ de revenus supplémentaires dans X mois]

### Alternative moins chère
[Option alternative avec 50% moins d'impact sur le runway]

### Recommandation
🟢 Go — impact runway acceptable (< 1 mois)
🟡 Go conditionnel — si revenue milestone X atteint
🔴 No-go — trop risqué avec le runway actuel
```
