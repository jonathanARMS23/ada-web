# saas-pricing-model
Modèle de pricing SaaS : tiers, métriques d'usage.

## Métriques de pricing courantes
- **Par siège** : X€/user/mois (simple, prévisible)
- **Par usage** : X€/1000 appels API (aligné avec la valeur)
- **Par ressource** : X€/projet/mois
- **Freemium** : gratuit jusqu'à X + payant au-delà

## Template tiers
```markdown
## Pricing Model — <produit>

### Tier Free
- Cible : acquisition + test
- Limites : X users, X ressources, X appels/mois
- Objectif : 10-20% de conversion vers payant

### Tier Starter — X€/mois
- Cible : petites équipes / indépendants
- Inclus : Y users, Y ressources, support email
- Cas d'usage : [description]

### Tier Pro — X€/mois
- Cible : équipes moyennes
- Inclus : illimité + features avancées + support prioritaire
- Différenciateurs : [liste]

### Tier Enterprise — sur devis
- Cible : grandes entreprises
- Inclus : SSO, SLA, onboarding dédié, contrat annuel

### Analyse de la concurrence
| Concurrent | Tier équivalent | Prix |
|------------|----------------|------|
```
