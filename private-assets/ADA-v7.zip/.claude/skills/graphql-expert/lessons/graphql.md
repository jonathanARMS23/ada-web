# GraphQL Expert — Micro-lessons

## L1 — DataLoader : éliminer le problème N+1

Le problème N+1 est le piège classique GraphQL : résoudre un champ par requête SQL séparée.

```typescript
// MAUVAIS — 1 requête par post
const resolvers = {
  Post: {
    author: (post) => db.users.findById(post.authorId) // N requêtes
  }
}

// BON — DataLoader batch les IDs et exécute 1 seule requête
import DataLoader from 'dataloader'
const userLoader = new DataLoader(async (ids: readonly string[]) => {
  const users = await db.users.findManyByIds([...ids])
  return ids.map(id => users.find(u => u.id === id) ?? null)
})

const resolvers = {
  Post: {
    author: (post) => userLoader.load(post.authorId) // batché automatiquement
  }
}
```

Règle : créer un DataLoader par request context (pas global), pour éviter les fuites de cache entre requêtes.

## L2 — N+1 avec Prisma : utiliser les relations include

```typescript
// MAUVAIS — résolution champ par champ
const posts = await prisma.post.findMany()
// puis pour chaque post : await prisma.user.findUnique({ where: { id: post.authorId } })

// BON — JOIN en une requête
const posts = await prisma.post.findMany({
  include: { author: true, comments: { include: { author: true } } }
})
```

Pour les requêtes dynamiques (champs sélectionnés par le client), combiner Prisma `select` avec l'analyse du `info` GraphQL ou utiliser `prisma-select`.

## L3 — Apollo Server 4 : configuration production

```typescript
import { ApolloServer } from '@apollo/server'
import { expressMiddleware } from '@apollo/server/express4'
import { ApolloServerPluginDrainHttpServer } from '@apollo/server/plugin/drainHttpServer'

const server = new ApolloServer({
  typeDefs,
  resolvers,
  plugins: [ApolloServerPluginDrainHttpServer({ httpServer })],
  formatError: (formattedError) => {
    // Ne jamais exposer les détails internes en production
    if (process.env.NODE_ENV === 'production') {
      return { message: formattedError.message, extensions: { code: formattedError.extensions?.code } }
    }
    return formattedError
  },
  introspection: process.env.NODE_ENV !== 'production',
})
```

Toujours désactiver l'introspection en production et masquer les stack traces.

## L4 — Subscriptions GraphQL avec graphql-ws

```typescript
import { useServer } from 'graphql-ws/lib/use/ws'
import { WebSocketServer } from 'ws'

const wsServer = new WebSocketServer({ server: httpServer, path: '/graphql' })
const serverCleanup = useServer(
  {
    schema,
    context: async (ctx) => {
      // Valider le token d'auth dans le handshake WebSocket
      const token = ctx.connectionParams?.authorization
      if (!token) throw new Error('Authentification requise')
      return { user: await verifyToken(token) }
    },
  },
  wsServer
)

// Resolver subscription
const resolvers = {
  Subscription: {
    messageAdded: {
      subscribe: (_, { roomId }, { pubsub }) =>
        pubsub.asyncIterator([`MESSAGE_ADDED_${roomId}`]),
    },
  },
}
```

Utiliser `graphql-ws` (pas `subscriptions-transport-ws` déprécié). Authentifier dans `connectionParams`, pas dans chaque message.

## L5 — Schema design : conventions et bonnes pratiques

```graphql
# Pagination Relay-style (curseur, pas offset)
type PostConnection {
  edges: [PostEdge!]!
  pageInfo: PageInfo!
}
type PostEdge {
  node: Post!
  cursor: String!
}
type PageInfo {
  hasNextPage: Boolean!
  endCursor: String
}

# Mutations avec input objects (extensibles sans breaking change)
input CreatePostInput {
  title: String!
  content: String!
  tags: [String!]
}
type CreatePostPayload {
  post: Post
  errors: [UserError!]!
}

# Erreurs métier distinctes des erreurs GraphQL
type UserError {
  field: String
  message: String!
  code: String!
}
```

Règles : nommer les mutations `verbNoun` (createPost, updateUser), toujours retourner les erreurs dans le payload (jamais throw pour erreurs métier), utiliser la pagination curseur pour les listes.
