# embedding-pipeline
sentence-transformers, batch encoding, normalize_embeddings, multilingual.

```python
from sentence_transformers import SentenceTransformer
import numpy as np

class EmbeddingPipeline:
    def __init__(self, model: str = "paraphrase-multilingual-MiniLM-L12-v2"):
        self.model = SentenceTransformer(model)
        self.dimension = self.model.get_sentence_embedding_dimension()

    def encode(self, texts: list[str]) -> list[list[float]]:
        embeddings = self.model.encode(
            texts,
            batch_size=32,
            normalize_embeddings=True,  # cosine similarity
            show_progress_bar=False,
        )
        return embeddings.tolist()

    def encode_one(self, text: str) -> list[float]:
        return self.encode([text])[0]

    def similarity(self, a: list[float], b: list[float]) -> float:
        return float(np.dot(a, b))  # déjà normalisé → cosine similarity
```
