# fact-extraction
Skill : fact-extraction — agent memory-engineer.
