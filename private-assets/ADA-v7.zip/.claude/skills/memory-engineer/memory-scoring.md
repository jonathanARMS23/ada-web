# memory-scoring
Score de pertinence : 0.4·cosine + 0.3·exp(-λΔt) + 0.2·importance + 0.1·log(count)

```python
import math, time

def score_memory(
    cosine_similarity: float,
    last_access_ts: float,
    importance: float,  # 0.0 - 1.0
    access_count: int,
    decay_lambda: float = 0.001,
) -> float:
    """
    Score composite pour le retrieval de mémoire.
    - cosine_similarity : pertinence sémantique (0-1)
    - last_access_ts    : timestamp UNIX du dernier accès
    - importance        : score d'importance assigné (0-1)
    - access_count      : nombre total d'accès
    """
    delta_t = time.time() - last_access_ts
    recency  = math.exp(-decay_lambda * delta_t)
    freq     = math.log1p(access_count) / math.log1p(100)  # normalisé sur 100 accès max

    return (
        0.4 * cosine_similarity +
        0.3 * recency +
        0.2 * importance +
        0.1 * freq
    )
```
