# qdrant-ltm
Collection setup, HNSW params, payload filters, upsert/search.

```python
from qdrant_client import AsyncQdrantClient
from qdrant_client.models import Distance, VectorParams, PointStruct, Filter, FieldCondition, MatchValue

class QdrantLTM:
    def __init__(self, url: str, collection: str = "memories"):
        self.client = AsyncQdrantClient(url=url)
        self.collection = collection

    async def setup(self, vector_size: int = 384):
        collections = await self.client.get_collections()
        names = [c.name for c in collections.collections]
        if self.collection not in names:
            await self.client.create_collection(
                collection_name=self.collection,
                vectors_config=VectorParams(size=vector_size, distance=Distance.COSINE),
                hnsw_config={"m": 16, "ef_construct": 100},  # qualité/vitesse
            )

    async def upsert(self, memory_id: str, vector: list[float], payload: dict):
        await self.client.upsert(self.collection, points=[
            PointStruct(id=memory_id, vector=vector, payload=payload)
        ])

    async def search(self, vector: list[float], workspace_id: str, limit: int = 5):
        return await self.client.search(
            self.collection,
            query_vector=vector,
            query_filter=Filter(must=[
                FieldCondition(key="workspace_id", match=MatchValue(value=workspace_id))
            ]),
            limit=limit,
            with_payload=True,
        )
```
