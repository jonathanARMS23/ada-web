# redis-stm
Redis client async, sliding window N messages, TTL par conversation, pub/sub invalidation.

```python
import redis.asyncio as aioredis
import json

class RedisSTM:
    def __init__(self, url: str, window_size: int = 20, ttl: int = 3600):
        self.redis = aioredis.from_url(url, decode_responses=True)
        self.window_size = window_size
        self.ttl = ttl

    def _key(self, conv_id: str) -> str:
        return f"stm:{conv_id}:messages"

    async def add_message(self, conv_id: str, role: str, content: str):
        key = self._key(conv_id)
        msg = json.dumps({"role": role, "content": content, "ts": time.time()})
        pipe = self.redis.pipeline()
        pipe.rpush(key, msg)
        pipe.ltrim(key, -self.window_size, -1)  # sliding window
        pipe.expire(key, self.ttl)
        await pipe.execute()

    async def get_messages(self, conv_id: str) -> list[dict]:
        raw = await self.redis.lrange(self._key(conv_id), 0, -1)
        return [json.loads(m) for m in raw]

    async def clear(self, conv_id: str):
        await self.redis.delete(self._key(conv_id))
```
