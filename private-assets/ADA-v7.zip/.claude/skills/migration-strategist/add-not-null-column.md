# add-not-null-column
Ajout colonne NOT NULL sur table volumineuse sans lock.

## ❌ Ce qui locke la table (à éviter en prod)
```sql
ALTER TABLE resources ADD COLUMN priority INTEGER NOT NULL DEFAULT 1;
-- Locke toute la table pendant la mise à jour de chaque ligne
```

## ✅ Stratégie sans lock

### Phase 1 — Ajouter nullable avec DEFAULT
```sql
-- Rapide : pas de réécriture des lignes existantes (PG 11+)
ALTER TABLE resources ADD COLUMN priority INTEGER DEFAULT 1;
```

### Phase 2 — Backfill par batches
```sql
DO $$
BEGIN
  LOOP
    UPDATE resources SET priority = 1 WHERE priority IS NULL LIMIT 5000;
    EXIT WHEN NOT FOUND;
    PERFORM pg_sleep(0.1);
  END LOOP;
END $$;
```

### Phase 3 — Ajouter la contrainte NOT NULL
```sql
-- Valider la contrainte (plus rapide que ALTER)
ALTER TABLE resources ADD CONSTRAINT resources_priority_not_null CHECK (priority IS NOT NULL) NOT VALID;
ALTER TABLE resources VALIDATE CONSTRAINT resources_priority_not_null;
-- Puis convertir
ALTER TABLE resources ALTER COLUMN priority SET NOT NULL;
ALTER TABLE resources DROP CONSTRAINT resources_priority_not_null;
```
