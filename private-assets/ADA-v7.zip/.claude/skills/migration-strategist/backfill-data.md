# backfill-data
Backfill par batches avec progression et reprise sur erreur.

## Script Python (DRF)
```python
from django.core.management.base import BaseCommand

class Command(BaseCommand):
    help = 'Backfill resource full_name'

    def add_arguments(self, parser):
        parser.add_argument('--batch-size', type=int, default=1000)
        parser.add_argument('--dry-run', action='store_true')

    def handle(self, *args, **options):
        batch_size = options['batch_size']
        dry_run = options['dry_run']
        total = Resource.objects.filter(full_name__isnull=True).count()
        self.stdout.write(f"À traiter : {total} ressources")

        processed = 0
        while True:
            batch = list(Resource.objects.filter(
                full_name__isnull=True
            ).only('id', 'name')[:batch_size])

            if not batch:
                break

            if not dry_run:
                for r in batch:
                    r.full_name = r.name
                Resource.objects.bulk_update(batch, ['full_name'])

            processed += len(batch)
            self.stdout.write(f"Traités : {processed}/{total} ({processed/total*100:.1f}%)")

        self.stdout.write(self.style.SUCCESS('Backfill terminé'))
```

## Commande
```bash
python manage.py backfill_full_name --batch-size=500 --dry-run  # test
python manage.py backfill_full_name --batch-size=1000            # prod
```
