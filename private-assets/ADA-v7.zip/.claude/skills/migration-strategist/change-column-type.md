# change-column-type
Changement de type avec nouvelle colonne + backfill + swap.

## Exemple : TEXT → INTEGER

## Phase 1 — Nouvelle colonne (déploiement N)
```sql
ALTER TABLE resources ADD COLUMN amount_int INTEGER;
-- Backfill par batches
DO $$
BEGIN
  LOOP
    UPDATE resources SET amount_int = amount_text::integer
    WHERE amount_int IS NULL AND amount_text ~ '^\d+$'
    LIMIT 1000;
    EXIT WHEN NOT FOUND;
    PERFORM pg_sleep(0.05);
  END LOOP;
END $$;
```
Code : lire depuis les deux, écrire dans les deux

## Phase 2 — Swap (déploiement N+1)
```sql
-- Ajouter contrainte NOT NULL après backfill complet
ALTER TABLE resources ALTER COLUMN amount_int SET NOT NULL;
-- Renommer en une transaction
BEGIN;
ALTER TABLE resources RENAME COLUMN amount_text TO amount_text_old;
ALTER TABLE resources RENAME COLUMN amount_int TO amount;
COMMIT;
```

## Phase 3 — Supprimer (déploiement N+2)
```sql
ALTER TABLE resources DROP COLUMN amount_text_old;
```
