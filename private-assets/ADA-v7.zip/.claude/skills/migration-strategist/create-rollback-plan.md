# create-rollback-plan
Plan de rollback testé pour chaque migration critique.

## Template
```markdown
## Rollback Plan — Migration <N>

### Fenêtre de rollback
[Combien de temps après le déploiement peut-on revenir en arrière ?]

### Trigger de rollback
- [ ] Erreurs 5xx > 1% pendant 5 minutes
- [ ] Temps de réponse API > 2s (p99)
- [ ] Alertes Sentry pour erreurs DB

### Procédure

#### Rollback applicatif (< 5 min)
```bash
# Redéployer la version précédente
git revert <sha>
# ou
railway rollback / ecs update --revision N-1
```

#### Rollback DB (si nécessaire)
```sql
-- Migration inverse
-- Toujours tester sur staging avant
<SQL de rollback>
```

### Vérification post-rollback
- [ ] /health retourne 200
- [ ] Test smoke : créer + lire + supprimer une ressource
- [ ] Vérifier les erreurs Sentry

### Données à risque
[Quelles données peuvent être perdues ou corrompues en cas de rollback]
```
