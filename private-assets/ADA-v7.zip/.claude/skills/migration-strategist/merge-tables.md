# merge-tables
Fusion de 2 tables en une.

## Scénario : fusionner `invoices` + `credit_notes` → `documents`

## Phase 1 — Créer la table cible
```sql
CREATE TABLE documents (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  type        TEXT NOT NULL CHECK (type IN ('invoice', 'credit_note')),
  workspace_id UUID NOT NULL,
  -- colonnes communes
  amount      NUMERIC NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  -- mapping d'origine pour la transition
  legacy_id   UUID,
  legacy_type TEXT
);
```

## Phase 2 — Migrer les données
```sql
INSERT INTO documents(type, workspace_id, amount, legacy_id, legacy_type)
SELECT 'invoice', workspace_id, amount, id, 'invoice' FROM invoices;

INSERT INTO documents(type, workspace_id, amount, legacy_id, legacy_type)
SELECT 'credit_note', workspace_id, amount, id, 'credit_note' FROM credit_notes;
```

## Phase 3 — Mettre à jour les FKs
```sql
-- Mettre à jour les tables qui référencent invoices/credit_notes
ALTER TABLE payments ADD COLUMN document_id UUID REFERENCES documents(id);
UPDATE payments p SET document_id = d.id
FROM documents d WHERE d.legacy_id = p.invoice_id AND d.legacy_type = 'invoice';
```

## Phase 4 — Supprimer les anciennes tables
```sql
DROP TABLE invoices, credit_notes;
```
