# plan-zero-downtime-migration
Plan expand/contract pour changements destructifs.

## Principe Expand / Contract

### Phase 1 — Expand (déploiement N)
Ajouter sans rien supprimer. L'ancienne et la nouvelle structure coexistent.
```sql
-- Ajouter la nouvelle colonne nullable
ALTER TABLE resources ADD COLUMN full_name TEXT;
```
```typescript
// Le code écrit dans les DEUX colonnes
await prisma.resource.update({
  where: { id },
  data: { name: data.name, full_name: data.name } // double écriture
})
```

### Phase 2 — Migrate (déploiement N ou N+1)
Backfill des données existantes par batches.
```sql
-- Backfill par batches de 1000 pour ne pas locker
DO $$
DECLARE batch_size INT := 1000; offset_val INT := 0; rows_updated INT;
BEGIN
  LOOP
    UPDATE resources SET full_name = name
    WHERE id IN (SELECT id FROM resources WHERE full_name IS NULL LIMIT batch_size);
    GET DIAGNOSTICS rows_updated = ROW_COUNT;
    EXIT WHEN rows_updated = 0;
    PERFORM pg_sleep(0.1); -- respirer
  END LOOP;
END $$;
```

### Phase 3 — Contract (déploiement N+2)
Le code n'utilise plus l'ancienne colonne → supprimer.
```sql
ALTER TABLE resources DROP COLUMN name;
```
