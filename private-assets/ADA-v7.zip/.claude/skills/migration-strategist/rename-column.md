# rename-column
Renommage de colonne en 3 phases sans downtime.

## Phase 1 — Ajouter (déploiement N)
```sql
ALTER TABLE resources ADD COLUMN full_name TEXT;
UPDATE resources SET full_name = name WHERE full_name IS NULL;
-- Index sur la nouvelle colonne
CREATE INDEX CONCURRENTLY idx_resources_full_name ON resources(full_name);
```
Code : écrire dans les DEUX colonnes

## Phase 2 — Migrer (même déploiement ou déploiement N)
```sql
-- Trigger de synchronisation pendant la transition
CREATE OR REPLACE FUNCTION sync_name_columns()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' OR NEW.name IS DISTINCT FROM OLD.name THEN
    NEW.full_name = NEW.name;
  ELSIF NEW.full_name IS DISTINCT FROM OLD.full_name THEN
    NEW.name = NEW.full_name;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER sync_names BEFORE INSERT OR UPDATE ON resources
  FOR EACH ROW EXECUTE FUNCTION sync_name_columns();
```

## Phase 3 — Nettoyer (déploiement N+1)
```sql
DROP TRIGGER sync_names ON resources;
DROP FUNCTION sync_name_columns();
ALTER TABLE resources DROP COLUMN name;
```
Code : ne plus lire/écrire dans l'ancienne colonne
