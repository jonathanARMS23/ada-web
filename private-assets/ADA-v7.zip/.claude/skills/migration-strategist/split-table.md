# split-table
Découpage d'une table volumineuse en 2.

## Scénario : séparer `resources` en `resources` + `resource_details`

## Phase 1 — Créer la nouvelle table
```sql
CREATE TABLE resource_details (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  resource_id UUID NOT NULL REFERENCES resources(id) ON DELETE CASCADE,
  description TEXT,
  metadata    JSONB NOT NULL DEFAULT '{}',
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX ON resource_details(resource_id);
```

## Phase 2 — Migrer les données
```sql
INSERT INTO resource_details(resource_id, description, metadata)
SELECT id, description, metadata FROM resources
ON CONFLICT (resource_id) DO NOTHING;
```

## Phase 3 — Double écriture dans le code
```typescript
// Écrire dans les deux tables pendant la transition
await prisma.$transaction([
  prisma.resource.update({ where: { id }, data: { description } }),
  prisma.resourceDetails.upsert({ where: { resourceId: id }, create: { resourceId: id, description }, update: { description } }),
])
```

## Phase 4 — Supprimer les anciennes colonnes
```sql
ALTER TABLE resources DROP COLUMN description, DROP COLUMN metadata;
```
