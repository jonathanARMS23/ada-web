# test-migration-staging
Protocole de test migration sur staging avec données réelles.

## Checklist pré-migration

### 1. Préparer staging
```bash
# Restaurer un backup récent de prod sur staging
pg_restore -U postgres -d staging_db prod_backup.dump

# Vérifier le volume de données
psql -c "SELECT relname, n_live_tup FROM pg_stat_user_tables ORDER BY n_live_tup DESC LIMIT 10"
```

### 2. Tester la migration
```bash
# Mesurer le temps d'exécution
time psql -f migration.sql

# Vérifier les erreurs
psql -f migration.sql 2>&1 | grep -i "error\|warning"
```

### 3. Vérifier les données
```sql
-- Avant/après : compter les lignes
SELECT COUNT(*) FROM resources;  -- doit être identique sauf si suppression intentionnelle

-- Vérifier l'intégrité référentielle
SELECT COUNT(*) FROM resources r LEFT JOIN workspaces w ON w.id = r.workspace_id WHERE w.id IS NULL;
-- doit retourner 0

-- Vérifier les contraintes NOT NULL
SELECT COUNT(*) FROM resources WHERE new_column IS NULL;  -- doit retourner 0 après backfill
```

### 4. Tester le rollback
```bash
# Exécuter le script de rollback
psql -f rollback.sql
# Vérifier que l'application fonctionne encore
curl https://staging.api.example.com/health
```

### 5. Mesurer l'impact sur les requêtes critiques
```sql
EXPLAIN ANALYZE SELECT ... FROM resources WHERE ...;  -- comparer avant/après
```
