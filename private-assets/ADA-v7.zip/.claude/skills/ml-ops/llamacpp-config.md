# llamacpp-config
Llama class, n_ctx/n_gpu_layers/n_batch/n_threads, verbose, seed, température.

```python
from llama_cpp import Llama

llm = Llama(
    model_path="./models/mistral-7b-q4_k_m.gguf",
    n_ctx=4096,           # taille context window
    n_gpu_layers=35,      # layers GPU (GPU offloading) — -1 = tout sur GPU
    n_batch=512,          # tokens traités en parallèle pour le prompt
    n_threads=8,          # threads CPU pour les layers sur CPU
    verbose=False,        # désactiver les logs de llama.cpp
    seed=42,              # reproducibilité
)

response = llm.create_chat_completion(
    messages=[{"role": "user", "content": "Bonjour"}],
    temperature=0.7,
    max_tokens=512,
    stream=False,
)
print(response["choices"][0]["message"]["content"])
```

## Streaming
```python
for chunk in llm.create_chat_completion(messages=[...], stream=True):
    delta = chunk["choices"][0]["delta"].get("content", "")
    print(delta, end="", flush=True)
```
