# model-quantization
Q4_K_M vs Q5_K_M vs Q8_0 — tradeoff qualité/VRAM/vitesse.

## Guide de sélection

| Format | VRAM (7B) | Vitesse | Qualité | Usage |
|--------|-----------|---------|---------|-------|
| Q4_K_M | ~4 GB     | ⚡⚡⚡   | ★★★☆   | Production CPU, VRAM limitée |
| Q5_K_M | ~5 GB     | ⚡⚡    | ★★★★   | Meilleur rapport qualité/vitesse |
| Q8_0   | ~8 GB     | ⚡     | ★★★★★  | Référence, si VRAM suffisante |
| F16    | ~14 GB    | ⚡     | ★★★★★  | Fine-tuning, évaluation |

## Règle pratique
- GPU 6GB → Q4_K_M
- GPU 8GB → Q5_K_M ou Q4_K_M (7B) + Q4_K_M (13B)
- GPU 16GB → Q8_0 (7B) ou Q5_K_M (13B)
- CPU only → Q4_K_M (vitesse > qualité)

## Download HuggingFace
```bash
# Chercher les fichiers GGUF sur HuggingFace
pip install huggingface_hub
python -c "
from huggingface_hub import hf_hub_download
path = hf_hub_download(
    repo_id='bartowski/Mistral-7B-Instruct-v0.3-GGUF',
    filename='Mistral-7B-Instruct-v0.3-Q4_K_M.gguf',
    local_dir='./models'
)
print(path)
"
```
