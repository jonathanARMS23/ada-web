# ollama-setup
Skill : ollama-setup — agent ml-ops.
