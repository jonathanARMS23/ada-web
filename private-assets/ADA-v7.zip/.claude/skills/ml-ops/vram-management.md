# vram-management
Calcul layers par GB VRAM, layer offloading, KV cache sizing, éviter OOM.

## Calcul n_gpu_layers
```python
def estimate_gpu_layers(model_size_b: float, vram_gb: float, quant: str = "Q4_K_M") -> int:
    """Estime le nombre de layers GPU selon la VRAM disponible."""
    vram_per_layer = {
        "Q4_K_M": 0.10,  # GB par layer pour un 7B
        "Q5_K_M": 0.13,
        "Q8_0":   0.20,
        "F16":    0.40,
    }
    layers_per_model = {7: 32, 13: 40, 34: 48, 70: 80}
    
    total_layers = layers_per_model.get(int(model_size_b), 32)
    gb_per_layer = vram_per_layer.get(quant, 0.10)
    usable_vram = vram_gb * 0.85  # 15% de marge sécurité
    
    return min(int(usable_vram / gb_per_layer), total_layers)
```

## KV cache (n_ctx vs VRAM)
- n_ctx 2048 → ~0.5 GB VRAM pour un 7B Q4
- n_ctx 4096 → ~1 GB VRAM
- n_ctx 8192 → ~2 GB VRAM
- Réduire n_ctx si OOM avec n_gpu_layers maximal
