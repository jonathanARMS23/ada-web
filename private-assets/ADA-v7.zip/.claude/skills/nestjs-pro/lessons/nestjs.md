# NestJS Pro — Micro-lessons

## L1 — Guards : authentification et autorisation

```typescript
// auth.guard.ts — JWT Guard
@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') {
  canActivate(context: ExecutionContext) {
    return super.canActivate(context)
  }
  handleRequest(err: any, user: any) {
    if (err || !user) throw err || new UnauthorizedException()
    return user
  }
}

// roles.guard.ts — RBAC
@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private reflector: Reflector) {}
  canActivate(context: ExecutionContext): boolean {
    const roles = this.reflector.getAllAndOverride<Role[]>('roles', [
      context.getHandler(),
      context.getClass(),
    ])
    if (!roles) return true
    const { user } = context.switchToHttp().getRequest()
    return roles.some(role => user.roles?.includes(role))
  }
}

// Utilisation
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles(Role.ADMIN)
@Get('admin')
adminEndpoint() { ... }
```

Ordre des guards : JwtAuthGuard doit passer avant RolesGuard. Utiliser `Reflector.getAllAndOverride` pour que le décorateur sur la méthode prenne priorité sur la classe.

## L2 — Pipes : validation et transformation

```typescript
// Toujours utiliser class-validator + ValidationPipe globale
// main.ts
app.useGlobalPipes(new ValidationPipe({
  whitelist: true,        // strip les champs non décorés
  forbidNonWhitelisted: true,
  transform: true,        // cast automatique string→number, string→boolean
  transformOptions: { enableImplicitConversion: true },
}))

// DTO
export class CreateUserDto {
  @IsEmail()
  email: string

  @IsString()
  @MinLength(8)
  @Matches(/^(?=.*[A-Z])(?=.*[0-9])/, { message: 'Mot de passe trop faible' })
  password: string

  @IsUUID()
  @IsOptional()
  workspaceId?: string
}

// Pipe personnalisé
@Injectable()
export class ParseUUIDPipe implements PipeTransform {
  transform(value: string) {
    if (!isUUID(value)) throw new BadRequestException(`UUID invalide : ${value}`)
    return value
  }
}
```

## L3 — Interceptors : logging, cache, transformation

```typescript
// logging.interceptor.ts
@Injectable()
export class LoggingInterceptor implements NestInterceptor {
  constructor(private logger: Logger) {}
  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
    const req    = context.switchToHttp().getRequest()
    const start  = Date.now()
    return next.handle().pipe(
      tap({ next: () => this.logger.log(`${req.method} ${req.url} ${Date.now() - start}ms`) }),
    )
  }
}

// cache.interceptor.ts — cache en mémoire par URL
@Injectable()
export class CacheInterceptor implements NestInterceptor {
  private cache = new Map<string, { data: any; expiresAt: number }>()
  intercept(context: ExecutionContext, next: CallHandler) {
    const req = context.switchToHttp().getRequest()
    if (req.method !== 'GET') return next.handle()
    const cached = this.cache.get(req.url)
    if (cached && cached.expiresAt > Date.now()) return of(cached.data)
    return next.handle().pipe(tap(data => this.cache.set(req.url, { data, expiresAt: Date.now() + 30_000 })))
  }
}
```

## L4 — Prisma avec NestJS : module et best practices

```typescript
// prisma.service.ts
@Injectable()
export class PrismaService extends PrismaClient implements OnModuleInit, OnModuleDestroy {
  async onModuleInit() { await this.$connect() }
  async onModuleDestroy() { await this.$disconnect() }
}

// prisma.module.ts — global pour éviter les imports répétés
@Global()
@Module({ providers: [PrismaService], exports: [PrismaService] })
export class PrismaModule {}

// Repository pattern avec Prisma
@Injectable()
export class UserRepository {
  constructor(private prisma: PrismaService) {}

  async findByWorkspace(workspaceId: string, pagination: PaginationDto) {
    const [data, total] = await this.prisma.$transaction([
      this.prisma.user.findMany({
        where: { workspaceId },
        skip: (pagination.page - 1) * pagination.limit,
        take: pagination.limit,
        orderBy: { createdAt: 'desc' },
      }),
      this.prisma.user.count({ where: { workspaceId } }),
    ])
    return { data, total, pages: Math.ceil(total / pagination.limit) }
  }
}
```

Toujours utiliser `$transaction` pour les opérations multi-tables. Ne jamais exposer les erreurs Prisma directement au client.

## L5 — Tests e2e avec supertest

```typescript
// app.e2e-spec.ts
describe('Users (e2e)', () => {
  let app: INestApplication
  let prisma: PrismaService
  let authToken: string

  beforeAll(async () => {
    const module = await Test.createTestingModule({ imports: [AppModule] })
      .overrideProvider(PrismaService).useValue(prismaMock)
      .compile()
    app = module.createNestApplication()
    app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }))
    await app.init()
    prisma = module.get<PrismaService>(PrismaService)
  })

  afterAll(async () => { await app.close() })

  it('POST /users — crée un utilisateur', async () => {
    const dto = { email: 'test@example.com', password: 'Password1!' }
    const res = await request(app.getHttpServer()).post('/users').send(dto).expect(201)
    expect(res.body).toMatchObject({ email: dto.email })
    expect(res.body.password).toBeUndefined() // ne jamais exposer le hash
  })

  it('GET /users — requiert auth', () =>
    request(app.getHttpServer()).get('/users').expect(401))
})
```

Pattern : un module de test par feature, un mock Prisma par suite, toujours tester les cas d'erreur (401, 403, 404, 422).
