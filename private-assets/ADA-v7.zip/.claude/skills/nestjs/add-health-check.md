# add-health-check
Endpoint /health avec checks DB, Redis, mémoire.

## Setup
```bash
npm i @nestjs/terminus
```

## Module
```typescript
@Module({
  imports: [TerminusModule, HttpModule],
  controllers: [HealthController],
})
export class HealthModule {}
```

## Controller
```typescript
@Controller('health')
export class HealthController {
  constructor(
    private health: HealthCheckService,
    private db: PrismaHealthIndicator,
    private mem: MemoryHealthIndicator,
    private http: HttpHealthIndicator,
  ) {}

  @Get()
  @HealthCheck()
  check() {
    return this.health.check([
      () => this.db.pingCheck('database'),
      () => this.mem.checkHeap('memory_heap', 300 * 1024 * 1024),  // 300MB
      () => this.mem.checkRSS('memory_rss', 300 * 1024 * 1024),
    ])
  }
}
```

## Réponse OK
```json
{
  "status": "ok",
  "info": {
    "database": { "status": "up" },
    "memory_heap": { "status": "up" }
  }
}
```

## Réponse KO → 503
```json
{
  "status": "error",
  "error": { "database": { "status": "down", "message": "..." } }
}
```
