# add-rate-limiting
Throttling sur endpoints avec @nestjs/throttler.

## Étapes
1. Installer : `npm i @nestjs/throttler`
2. Configurer dans `app.module.ts`
3. Appliquer globalement ou par route

## Config globale
```typescript
ThrottlerModule.forRoot([{
  name: 'short',
  ttl: 1000,
  limit: 10,
}, {
  name: 'long',
  ttl: 60000,
  limit: 100,
}])
```

## Par route
```typescript
@Throttle({ short: { limit: 3, ttl: 1000 } })
@Post('login')
async login() {}
```

## Avec Redis (production)
```typescript
ThrottlerModule.forRootAsync({
  useFactory: () => ({
    throttlers: [...],
    storage: new ThrottlerStorageRedisService(redis),
  }),
})
```
