# create-config-module
Configuration typée avec @nestjs/config et validation Zod.

## Étapes
1. Créer `src/config/config.schema.ts` avec Zod
2. Créer `src/config/config.service.ts`
3. Enregistrer dans app.module.ts

## Schema Zod
```typescript
const configSchema = z.object({
  DATABASE_URL: z.string().url(),
  JWT_SECRET: z.string().min(32),
  PORT: z.coerce.number().default(3000),
  NODE_ENV: z.enum(['development', 'staging', 'production']),
});

export type Config = z.infer<typeof configSchema>;
```

## Validation au démarrage
```typescript
ConfigModule.forRoot({
  validate: (config) => {
    const result = configSchema.safeParse(config);
    if (!result.success) throw new Error(result.error.message);
    return result.data;
  },
  isGlobal: true,
})
```
