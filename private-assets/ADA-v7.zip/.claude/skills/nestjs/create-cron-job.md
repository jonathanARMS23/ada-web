# create-cron-job
Job planifié NestJS avec gestion d'erreurs et idempotence.

## Setup
```typescript
// app.module.ts
import { ScheduleModule } from '@nestjs/schedule'
ScheduleModule.forRoot()
```

## Service avec cron
```typescript
@Injectable()
export class SchedulerService {
  private readonly logger = new Logger(SchedulerService.name)
  private isRunning = false  // éviter les chevauchements

  @Cron(CronExpression.EVERY_DAY_AT_MIDNIGHT, { name: 'cleanup-expired' })
  async cleanupExpired() {
    if (this.isRunning) { this.logger.warn('Job déjà en cours — skip'); return }
    this.isRunning = true
    try {
      const deleted = await this.resourceService.deleteExpired()
      this.logger.log(`Cleanup: ${deleted} ressources supprimées`)
    } catch (error) {
      this.logger.error('Cleanup échoué', error)
    } finally {
      this.isRunning = false
    }
  }
}
```

## Expressions cron utiles
```
EVERY_MINUTE          → * * * * *
EVERY_DAY_AT_MIDNIGHT → 0 0 * * *
EVERY_WEEK            → 0 0 * * 0
EVERY_1ST_DAY_OF_MONTH_AT_MIDNIGHT → 0 0 1 * *
```
