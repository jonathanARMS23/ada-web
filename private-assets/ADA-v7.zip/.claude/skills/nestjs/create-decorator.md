# create-decorator
Décorateur custom NestJS (user courant, rôles, API key).

## Décorateur @CurrentUser
```typescript
export const CurrentUser = createParamDecorator(
  (data: keyof User | undefined, ctx: ExecutionContext): User | User[keyof User] => {
    const request = ctx.switchToHttp().getRequest()
    const user = request.user
    return data ? user?.[data] : user
  }
)
// Usage : @CurrentUser() user: User | @CurrentUser('id') userId: string
```

## Décorateur @Roles + guard
```typescript
export const Roles = (...roles: string[]) => SetMetadata('roles', roles)

@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private reflector: Reflector) {}
  canActivate(ctx: ExecutionContext): boolean {
    const roles = this.reflector.getAllAndOverride<string[]>('roles', [ctx.getHandler(), ctx.getClass()])
    if (!roles?.length) return true
    const { user } = ctx.switchToHttp().getRequest()
    return roles.some(role => user.roles?.includes(role))
  }
}
// Usage : @Roles('admin') @UseGuards(JwtAuthGuard, RolesGuard)
```

## Décorateur @Public
```typescript
export const Public = () => SetMetadata('isPublic', true)
// Dans le guard : if (this.reflector.getAllAndOverride('isPublic', [...])) return true
```
