# create-event-emitter
Pattern event-driven interne avec @nestjs/event-emitter.

## Setup
```typescript
// app.module.ts
EventEmitterModule.forRoot({ wildcard: true, delimiter: '.', global: true })
```

## Événements typés
```typescript
// events/resource.events.ts
export class ResourceCreatedEvent {
  constructor(public readonly resource: Resource) {}
}
```

## Émettre
```typescript
@Injectable()
export class ResourceService {
  constructor(private eventEmitter: EventEmitter2) {}

  async create(dto: CreateResourceDto) {
    const resource = await this.prisma.resource.create({ data: dto })
    this.eventEmitter.emit('resource.created', new ResourceCreatedEvent(resource))
    return resource
  }
}
```

## Écouter
```typescript
@Injectable()
export class NotificationListener {
  @OnEvent('resource.created')
  async handleResourceCreated(event: ResourceCreatedEvent) {
    await this.notificationService.send(event.resource.userId, 'Ressource créée')
  }
}
```
