# create-file-upload
Upload fichier avec validation MIME, taille, stockage S3.

## Controller
```typescript
@Post('upload')
@UseInterceptors(FileInterceptor('file', {
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
  fileFilter: (req, file, cb) => {
    const allowed = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf']
    allowed.includes(file.mimetype) ? cb(null, true) : cb(new BadRequestException('Type MIME non autorisé'), false)
  },
}))
async uploadFile(@UploadedFile() file: Express.Multer.File, @CurrentUser() user: User) {
  if (!file) throw new BadRequestException('Fichier requis')
  return this.uploadService.save(file, user.workspaceId)
}
```

## Service S3
```typescript
@Injectable()
export class UploadService {
  private s3 = new S3Client({ region: process.env.AWS_REGION })

  async save(file: Express.Multer.File, workspaceId: string) {
    const key = `${workspaceId}/${randomUUID()}-${file.originalname.replace(/[^a-zA-Z0-9.-]/g, '_')}`
    await this.s3.send(new PutObjectCommand({
      Bucket: process.env.S3_BUCKET,
      Key: key, Body: file.buffer,
      ContentType: file.mimetype,
      ServerSideEncryption: 'AES256',
    }))
    return { url: `https://${process.env.S3_BUCKET}.s3.amazonaws.com/${key}`, key }
  }
}
```
