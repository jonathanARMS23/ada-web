# create-guard
Crée un guard JWT ou RBAC.

## Guard JWT
```typescript
@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') {
  canActivate(context: ExecutionContext) {
    return super.canActivate(context);
  }
  handleRequest(err: any, user: any) {
    if (err || !user) throw err || new UnauthorizedException();
    return user;
  }
}
```

## Guard RBAC
```typescript
@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private reflector: Reflector) {}
  canActivate(context: ExecutionContext): boolean {
    const roles = this.reflector.get<string[]>('roles', context.getHandler());
    if (!roles) return true;
    const { user } = context.switchToHttp().getRequest();
    return roles.includes(user.role);
  }
}
```

## Étapes
1. Créer le guard dans `src/auth/guards/`
2. Créer le décorateur associé si RBAC : `@Roles('admin')`
3. Appliquer globalement dans `main.ts` ou par module
4. Écrire les tests unitaires avec mock ExecutionContext
