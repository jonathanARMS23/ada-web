# create-health-check
Endpoint /health avec checks DB, Redis, services externes.

## Étapes
1. Installer : `npm i @nestjs/terminus`
2. Créer `src/health/health.controller.ts`
3. Vérifier DB, Redis, et services critiques

## Template
```typescript
@Controller('health')
export class HealthController {
  constructor(
    private health: HealthCheckService,
    private db: PrismaHealthIndicator,
    private http: HttpHealthIndicator,
  ) {}

  @Get()
  @HealthCheck()
  check() {
    return this.health.check([
      () => this.db.pingCheck('database'),
      () => this.http.pingCheck('api', 'http://localhost:3000/api'),
    ]);
  }
}
```
