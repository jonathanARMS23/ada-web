# create-interceptor
Intercepteur NestJS (logging, transform, cache).

## Intercepteur de logging
```typescript
@Injectable()
export class LoggingInterceptor implements NestInterceptor {
  private readonly logger = new Logger(LoggingInterceptor.name)

  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
    const req = context.switchToHttp().getRequest()
    const start = Date.now()
    return next.handle().pipe(
      tap(() => this.logger.log(`${req.method} ${req.url} — ${Date.now() - start}ms`)),
      catchError(err => { this.logger.error(`${req.method} ${req.url} — ${err.message}`); throw err })
    )
  }
}
```

## Intercepteur transform response
```typescript
@Injectable()
export class TransformInterceptor<T> implements NestInterceptor<T, Response<T>> {
  intercept(context: ExecutionContext, next: CallHandler): Observable<Response<T>> {
    return next.handle().pipe(map(data => ({ data, timestamp: new Date().toISOString() })))
  }
}
```

## Appliquer globalement
```typescript
app.useGlobalInterceptors(new LoggingInterceptor(), new TransformInterceptor())
```
