# create-module
Scaffolde un module NestJS complet.

## Étapes
1. Créer `src/<name>/<name>.module.ts`
2. Créer `src/<name>/<name>.controller.ts` — routes REST, DTOs en params
3. Créer `src/<name>/<name>.service.ts` — logique métier pure
4. Créer `src/<name>/dto/create-<name>.dto.ts` + `update-<name>.dto.ts`
5. Créer `src/<name>/<name>.repository.ts` si Prisma
6. Créer `src/<name>/<name>.service.spec.ts` + `<name>.controller.spec.ts`
7. Enregistrer dans `app.module.ts`

## Template service
```typescript
@Injectable()
export class <Name>Service {
  constructor(private readonly prisma: PrismaService) {}

  async findAll(workspaceId: string) {
    return this.prisma.<name>.findMany({
      where: { workspaceId, deletedAt: null },
    });
  }
}
```

## Règles
- Jamais de logique dans le controller
- DTOs avec class-validator sur tous les champs
- Toujours filtrer par workspaceId
