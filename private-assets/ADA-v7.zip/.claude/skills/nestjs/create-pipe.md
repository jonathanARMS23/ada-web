# create-pipe
Pipe de validation ou transformation NestJS.

## Pipe de parsing UUID
```typescript
@Injectable()
export class ParseUUIDPipe implements PipeTransform {
  transform(value: string, metadata: ArgumentMetadata) {
    if (!isUUID(value)) throw new BadRequestException(`${metadata.data} doit être un UUID valide`)
    return value
  }
}
```

## Pipe de trim string
```typescript
@Injectable()
export class TrimPipe implements PipeTransform {
  transform(value: any) {
    if (typeof value === 'string') return value.trim()
    if (typeof value === 'object' && value !== null) {
      return Object.fromEntries(
        Object.entries(value).map(([k, v]) => [k, typeof v === 'string' ? v.trim() : v])
      )
    }
    return value
  }
}
```

## Utilisation
```typescript
@Get(':id')
findOne(@Param('id', ParseUUIDPipe) id: string) {}

@Post()
create(@Body(TrimPipe) dto: CreateResourceDto) {}
```
