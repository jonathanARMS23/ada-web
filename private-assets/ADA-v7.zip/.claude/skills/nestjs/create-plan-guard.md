# create-plan-guard
Guard de limitation par plan Stripe — bloque les features premium.

## PlanGuard
```typescript
@Injectable()
export class PlanGuard implements CanActivate {
  constructor(
    private prisma: PrismaService,
    private reflector: Reflector,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const requiredPlans = this.reflector.get<string[]>('plans', context.getHandler())
    if (!requiredPlans?.length) return true  // pas de restriction

    const { user } = context.switchToHttp().getRequest()
    const subscription = await this.prisma.subscription.findFirst({
      where: { workspaceId: user.workspaceId, status: { in: ['active', 'trialing'] } },
    })

    if (!subscription) {
      throw new ForbiddenException({
        code: 'PLAN_REQUIRED',
        message: 'Cette fonctionnalité nécessite un abonnement.',
        requiredPlans,
      })
    }

    if (!requiredPlans.includes(subscription.plan)) {
      throw new ForbiddenException({
        code: 'PLAN_UPGRADE_REQUIRED',
        message: `Cette fonctionnalité nécessite le plan ${requiredPlans.join(' ou ')}.`,
        currentPlan: subscription.plan,
        requiredPlans,
      })
    }

    return true
  }
}
```

## Décorateur @RequiresPlan
```typescript
export const RequiresPlan = (...plans: string[]) => SetMetadata('plans', plans)

// Usage
@UseGuards(JwtAuthGuard, WorkspaceGuard, PlanGuard)
@RequiresPlan('starter', 'pro')
@Post('advanced-export')
async advancedExport() {}
```

## Vérification usage (rate limiting par plan)
```typescript
async checkUsageLimit(workspaceId: string, feature: string) {
  const limits = { free: 10, starter: 100, pro: Infinity }
  const subscription = await this.getActiveSubscription(workspaceId)
  const plan = subscription?.plan ?? 'free'
  const used = await this.getUsageCount(workspaceId, feature)
  if (used >= limits[plan]) throw new ForbiddenException({ code: 'USAGE_LIMIT_REACHED', plan })
}
```
