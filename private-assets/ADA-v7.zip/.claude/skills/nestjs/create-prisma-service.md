# create-prisma-service
PrismaService avec soft delete, transactions, health check.

## PrismaService
```typescript
@Injectable()
export class PrismaService extends PrismaClient implements OnModuleInit, OnModuleDestroy {
  async onModuleInit() {
    await this.$connect();
  }
  async onModuleDestroy() {
    await this.$disconnect();
  }

  async healthCheck(): Promise<boolean> {
    try {
      await this.$queryRaw`SELECT 1`;
      return true;
    } catch {
      return false;
    }
  }

  async softDelete(model: string, id: string): Promise<void> {
    await (this as any)[model].update({
      where: { id },
      data: { deletedAt: new Date() },
    });
  }
}
```

## Étapes
1. Créer `src/prisma/prisma.service.ts`
2. Créer `src/prisma/prisma.module.ts` (global: true)
3. Ajouter l'extension soft delete middleware dans onModuleInit
