# create-queue-worker
Crée un worker BullMQ avec retry et dead letter queue.

## Étapes
1. Installer : `npm i @nestjs/bullmq bullmq`
2. Créer `src/<name>/<name>.processor.ts`
3. Configurer retry et DLQ dans la définition du job
4. Créer le producer dans le service

## Template processor
```typescript
@Processor('<queue-name>')
export class <Name>Processor {
  private readonly logger = new Logger(<Name>Processor.name);

  @Process()
  async handle(job: Job<<JobData>>) {
    try {
      // traitement
    } catch (error) {
      this.logger.error(`Job ${job.id} failed`, error);
      throw error; // BullMQ gère le retry
    }
  }
}
```

## Config retry
```typescript
await this.queue.add('job-name', data, {
  attempts: 3,
  backoff: { type: 'exponential', delay: 1000 },
  removeOnComplete: 100,
  removeOnFail: 500,
});
```
