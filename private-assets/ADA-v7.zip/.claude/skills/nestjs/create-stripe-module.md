# create-stripe-module
Module Stripe complet : subscriptions, webhooks, portail client.

## Setup
```bash
npm i stripe @nestjs/config
```

## StripeModule
```typescript
@Module({
  providers: [StripeService, StripeWebhookService],
  exports: [StripeService],
})
export class StripeModule {}
```

## StripeService
```typescript
@Injectable()
export class StripeService {
  private stripe: Stripe

  constructor(private config: ConfigService) {
    this.stripe = new Stripe(config.get('STRIPE_SECRET_KEY'), {
      apiVersion: '2024-06-20',
    })
  }

  async createCheckoutSession(params: {
    customerId: string
    priceId: string
    workspaceId: string
    successUrl: string
    cancelUrl: string
    trialDays?: number
  }) {
    return this.stripe.checkout.sessions.create({
      customer: params.customerId,
      payment_method_types: ['card'],
      line_items: [{ price: params.priceId, quantity: 1 }],
      mode: 'subscription',
      success_url: params.successUrl,
      cancel_url: params.cancelUrl,
      subscription_data: {
        trial_period_days: params.trialDays,
        metadata: { workspaceId: params.workspaceId },
      },
    })
  }

  async createCustomer(email: string, name: string) {
    return this.stripe.customers.create({ email, name })
  }

  async createPortalSession(customerId: string, returnUrl: string) {
    return this.stripe.billingPortal.sessions.create({
      customer: customerId,
      return_url: returnUrl,
    })
  }

  constructEvent(payload: Buffer, signature: string) {
    return this.stripe.webhooks.constructEvent(
      payload,
      signature,
      this.config.get('STRIPE_WEBHOOK_SECRET'),
    )
  }
}
```

## StripeWebhookController
```typescript
@Controller('webhooks/stripe')
export class StripeWebhookController {
  constructor(private stripe: StripeService, private subscriptions: SubscriptionService) {}

  @Post()
  @HttpCode(200)
  async handleWebhook(
    @Headers('stripe-signature') sig: string,
    @RawBody() payload: Buffer,
  ) {
    const event = this.stripe.constructEvent(payload, sig)
    switch (event.type) {
      case 'checkout.session.completed':
        await this.subscriptions.activate(event.data.object)
        break
      case 'customer.subscription.updated':
        await this.subscriptions.update(event.data.object)
        break
      case 'customer.subscription.deleted':
        await this.subscriptions.cancel(event.data.object)
        break
      case 'invoice.payment_failed':
        await this.subscriptions.markPaymentFailed(event.data.object)
        break
    }
    return { received: true }
  }
}
```

## Règles
- Toujours valider la signature webhook (ne jamais faire confiance au body brut)
- Raw body middleware obligatoire sur la route webhook (pas de JSON parser)
- Idempotence : vérifier si l'event a déjà été traité avant d'agir
