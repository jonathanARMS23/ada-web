# create-swagger-module
Configuration Swagger complète avec auth et tags.

## Setup dans main.ts
```typescript
const config = new DocumentBuilder()
  .setTitle('API')
  .setDescription('Documentation API')
  .setVersion('1.0')
  .addBearerAuth({ type: 'http', scheme: 'bearer', bearerFormat: 'JWT' }, 'JWT')
  .addTag('Auth', 'Authentification')
  .addTag('Resources', 'Gestion des ressources')
  .build()

const document = SwaggerModule.createDocument(app, config)
SwaggerModule.setup('api/docs', app, document, {
  swaggerOptions: { persistAuthorization: true },
})
```

## Sur les controllers
```typescript
@ApiTags('Resources')
@ApiBearerAuth('JWT')
@Controller('resources')
export class ResourceController {
  @Post()
  @ApiOperation({ summary: 'Créer une ressource' })
  @ApiResponse({ status: 201, type: ResourceDto })
  @ApiResponse({ status: 422, description: 'Validation error' })
  create(@Body() dto: CreateResourceDto) {}
}
```
