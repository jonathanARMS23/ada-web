# create-websocket-gateway
Gateway WebSocket NestJS avec auth et rooms.

## Gateway
```typescript
@WebSocketGateway({ cors: { origin: process.env.FRONTEND_URL }, namespace: '/events' })
@UseGuards(WsJwtGuard)
export class EventsGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer() server: Server
  private readonly logger = new Logger(EventsGateway.name)

  async handleConnection(client: AuthenticatedSocket) {
    try {
      const user = await this.authService.verifyToken(client.handshake.auth.token)
      client.data.user = user
      client.join(`workspace:${user.workspaceId}`)
      this.logger.log(`Client connecté: ${user.id}`)
    } catch {
      client.disconnect()
    }
  }

  handleDisconnect(client: AuthenticatedSocket) {
    this.logger.log(`Client déconnecté: ${client.data.user?.id}`)
  }

  @SubscribeMessage('join-room')
  handleJoinRoom(client: AuthenticatedSocket, room: string) {
    client.join(room)
    return { event: 'joined', data: room }
  }

  // Émettre depuis un service
  emitToWorkspace(workspaceId: string, event: string, data: any) {
    this.server.to(`workspace:${workspaceId}`).emit(event, data)
  }
}
```
