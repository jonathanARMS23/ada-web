# create-workspace-guard
Guard d'isolation workspace — vérifie que la ressource appartient au workspace du JWT.

## WorkspaceGuard
```typescript
@Injectable()
export class WorkspaceGuard implements CanActivate {
  constructor(private prisma: PrismaService) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest()
    const user = request.user  // injecté par JwtAuthGuard
    if (!user?.workspaceId) throw new UnauthorizedException()

    // Injecter le workspaceId dans la request pour les controllers
    request.workspaceId = user.workspaceId
    return true
  }
}
```

## WorkspaceMemberGuard (vérifier le rôle)
```typescript
@Injectable()
export class WorkspaceMemberGuard implements CanActivate {
  constructor(private prisma: PrismaService, private reflector: Reflector) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const requiredRoles = this.reflector.get<string[]>('roles', context.getHandler()) ?? []
    const { user } = context.switchToHttp().getRequest()

    const member = await this.prisma.workspaceMember.findFirst({
      where: { workspaceId: user.workspaceId, userId: user.id },
    })
    if (!member) throw new ForbiddenException()
    if (requiredRoles.length && !requiredRoles.includes(member.role)) {
      throw new ForbiddenException(`Rôle requis : ${requiredRoles.join(' ou ')}`)
    }
    return true
  }
}
```

## Décorateur @WorkspaceRoles
```typescript
export const WorkspaceRoles = (...roles: string[]) => SetMetadata('roles', roles)

// Usage sur un endpoint
@UseGuards(JwtAuthGuard, WorkspaceGuard, WorkspaceMemberGuard)
@WorkspaceRoles('admin', 'owner')
@Delete(':id')
async delete(@Param('id') id: string) {}
```

## Règle absolue
- get_queryset / findMany TOUJOURS filtré par `workspaceId: request.workspaceId`
- Jamais accepter workspaceId depuis le body client
- 404 au lieu de 403 si la ressource n'appartient pas au workspace (anti-enumeration)
