# add-i18n
Internationalisation avec next-intl.

## Setup
```bash
npm i next-intl
```

```typescript
// middleware.ts
import createMiddleware from 'next-intl/middleware'
export default createMiddleware({ locales: ['fr', 'en'], defaultLocale: 'fr' })
export const config = { matcher: ['/((?!api|_next|.*\\..*).*)'] }

// messages/fr.json
{ "resources": { "title": "Ressources", "create": "Créer" } }

// app/[locale]/layout.tsx
import { NextIntlClientProvider } from 'next-intl'
import { getMessages } from 'next-intl/server'

export default async function LocaleLayout({ children, params: { locale } }) {
  const messages = await getMessages()
  return (
    <NextIntlClientProvider messages={messages}>
      {children}
    </NextIntlClientProvider>
  )
}
```

## Usage
```typescript
// Server Component
import { useTranslations } from 'next-intl'
const t = useTranslations('resources')
return <h1>{t('title')}</h1>
```
