# create-api-route
Route Handler App Router avec validation et auth.

```typescript
// app/api/resources/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { auth } from '@/lib/auth'

const createSchema = z.object({
  name: z.string().min(1).max(255),
  status: z.enum(['draft', 'active']).default('draft'),
})

export async function GET(request: NextRequest) {
  const session = await auth()
  if (!session) return NextResponse.json({ error: { code: 'UNAUTHORIZED' } }, { status: 401 })

  const { searchParams } = new URL(request.url)
  const page = Number(searchParams.get('page') ?? 1)

  const resources = await db.resource.findMany({
    where: { workspaceId: session.user.workspaceId },
    skip: (page - 1) * 20, take: 20,
  })
  return NextResponse.json({ data: resources })
}

export async function POST(request: NextRequest) {
  const session = await auth()
  if (!session) return NextResponse.json({ error: { code: 'UNAUTHORIZED' } }, { status: 401 })

  const body = await request.json()
  const parsed = createSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(
    { error: { code: 'VALIDATION_ERROR', details: parsed.error.flatten().fieldErrors } },
    { status: 422 }
  )

  const resource = await db.resource.create({
    data: { ...parsed.data, workspaceId: session.user.workspaceId },
  })
  return NextResponse.json(resource, { status: 201 })
}
```
