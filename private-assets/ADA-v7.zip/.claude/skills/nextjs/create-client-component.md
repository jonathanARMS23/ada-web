# create-client-component
Client Component optimisé — état local, events, browser APIs.

```typescript
'use client'
import { useState, useCallback, memo } from 'react'

interface Props {
  initialCount: number
  onCountChange?: (count: number) => void
}

// memo pour éviter les re-renders si props stables
export const Counter = memo(function Counter({ initialCount, onCountChange }: Props) {
  const [count, setCount] = useState(initialCount)

  const increment = useCallback(() => {
    setCount(prev => {
      const next = prev + 1
      onCountChange?.(next)
      return next
    })
  }, [onCountChange])

  return (
    <button onClick={increment} aria-label={`Compteur: ${count}`}>
      {count}
    </button>
  )
})

// Règle : 'use client' uniquement si besoin de :
// useState, useEffect, useRef, event handlers, browser APIs
// Sinon → Server Component
```
