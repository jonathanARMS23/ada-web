# create-dashboard-layout
Layout dashboard avec sidebar, header, breadcrumbs.

```typescript
// components/layout/dashboard-layout.tsx
export function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex flex-col flex-1 overflow-hidden">
        <Header />
        <main className="flex-1 overflow-y-auto p-6">
          <Breadcrumbs />
          {children}
        </main>
      </div>
    </div>
  )
}

// Sidebar avec navigation active
export function Sidebar() {
  const pathname = usePathname()
  const navItems = [
    { href: '/dashboard', icon: Home, label: 'Accueil' },
    { href: '/resources', icon: Box, label: 'Ressources' },
    { href: '/settings', icon: Settings, label: 'Paramètres' },
  ]
  return (
    <aside className="w-64 border-r flex flex-col">
      <nav className="flex-1 p-4 space-y-1">
        {navItems.map(item => (
          <Link key={item.href} href={item.href}
            className={cn('flex items-center gap-3 px-3 py-2 rounded-md text-sm',
              pathname.startsWith(item.href) ? 'bg-accent font-medium' : 'hover:bg-accent/50'
            )}>
            <item.icon className="h-4 w-4" />
            {item.label}
          </Link>
        ))}
      </nav>
    </aside>
  )
}
```
