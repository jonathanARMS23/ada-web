# create-data-table
Table TanStack Table avec tri, filtres, pagination, sélection.

## Colonnes
```typescript
const columns: ColumnDef<Resource>[] = [
  {
    id: 'select',
    header: ({ table }) => <Checkbox checked={table.getIsAllPageRowsSelected()}
      onCheckedChange={(v) => table.toggleAllPageRowsSelected(!!v)} />,
    cell: ({ row }) => <Checkbox checked={row.getIsSelected()}
      onCheckedChange={(v) => row.toggleSelected(!!v)} />,
  },
  { accessorKey: 'name', header: ({ column }) =>
    <Button variant="ghost" onClick={() => column.toggleSorting()}>
      Nom <ArrowUpDown className="ml-2 h-4 w-4" />
    </Button>
  },
  { accessorKey: 'status', header: 'Statut' },
  {
    id: 'actions',
    cell: ({ row }) => <DataTableRowActions row={row} />,
  },
]
```

## Table
```typescript
const table = useReactTable({
  data, columns,
  getCoreRowModel: getCoreRowModel(),
  getSortedRowModel: getSortedRowModel(),
  getFilteredRowModel: getFilteredRowModel(),
  getPaginationRowModel: getPaginationRowModel(),
  onSortingChange: setSorting,
  state: { sorting, columnFilters, pagination },
})
```
