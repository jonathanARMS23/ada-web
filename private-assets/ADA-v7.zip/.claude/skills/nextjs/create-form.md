# create-form
Formulaire React Hook Form + Zod + Server Action.

## Schema Zod
```typescript
const schema = z.object({
  name: z.string().min(2, 'Min 2 caractères'),
  email: z.string().email('Email invalide'),
})
type FormData = z.infer<typeof schema>
```

## Server Action
```typescript
'use server'
export async function createResource(data: FormData) {
  const parsed = schema.safeParse(data)
  if (!parsed.success) return { error: parsed.error.flatten() }
  try {
    await db.resource.create({ data: parsed.data })
    revalidatePath('/resources')
    return { success: true }
  } catch {
    return { error: 'Erreur serveur' }
  }
}
```

## Composant client
```typescript
'use client'
export function ResourceForm() {
  const { register, handleSubmit, formState: { errors, isSubmitting } } =
    useForm<FormData>({ resolver: zodResolver(schema) })

  async function onSubmit(data: FormData) {
    const result = await createResource(data)
    if (result.error) toast.error('Erreur')
    else toast.success('Créé')
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <input {...register('name')} />
      {errors.name && <p>{errors.name.message}</p>}
      <button disabled={isSubmitting}>Envoyer</button>
    </form>
  )
}
```
