# create-infinite-scroll
Scroll infini avec TanStack Query + Intersection Observer.

```typescript
'use client'
import { useInfiniteQuery } from '@tanstack/react-query'
import { useInView } from 'react-intersection-observer'

export function ResourceInfiniteList() {
  const { ref, inView } = useInView()

  const { data, fetchNextPage, hasNextPage, isFetchingNextPage } = useInfiniteQuery({
    queryKey: ['resources-infinite'],
    queryFn: ({ pageParam }) => api.resources.list({ cursor: pageParam, limit: 20 }),
    getNextPageParam: (lastPage) => lastPage.nextCursor ?? undefined,
    initialPageParam: undefined as string | undefined,
  })

  useEffect(() => {
    if (inView && hasNextPage && !isFetchingNextPage) fetchNextPage()
  }, [inView, hasNextPage, isFetchingNextPage, fetchNextPage])

  const items = data?.pages.flatMap(p => p.data) ?? []

  return (
    <div>
      {items.map(item => <ResourceCard key={item.id} resource={item} />)}
      <div ref={ref} className="h-4">
        {isFetchingNextPage && <Spinner />}
      </div>
    </div>
  )
}
```
