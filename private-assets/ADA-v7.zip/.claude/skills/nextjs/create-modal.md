# create-modal
Dialog shadcn/ui avec état, formulaire intégré, accessibilité.

```typescript
'use client'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'

interface Props {
  trigger: React.ReactNode
  onSuccess?: () => void
}

export function CreateResourceModal({ trigger, onSuccess }: Props) {
  const [open, setOpen] = useState(false)

  function handleSuccess() {
    setOpen(false)
    onSuccess?.()
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="sm:max-w-md" aria-describedby="modal-description">
        <DialogHeader>
          <DialogTitle>Créer une ressource</DialogTitle>
        </DialogHeader>
        <p id="modal-description" className="sr-only">
          Formulaire de création d'une nouvelle ressource
        </p>
        <CreateResourceForm onSuccess={handleSuccess} />
      </DialogContent>
    </Dialog>
  )
}
```
