# create-onboarding-flow
Flow onboarding post-inscription : workspace, équipe, première action.

## Structure (App Router)
```
app/(onboarding)/
  layout.tsx          # layout minimal sans sidebar
  onboarding/
    page.tsx           # redirect vers step 1
    workspace/page.tsx # Étape 1 — créer son workspace
    invite/page.tsx    # Étape 2 — inviter l'équipe (skippable)
    done/page.tsx      # Étape 3 — redirect vers dashboard
```

## OnboardingLayout avec progress bar
```typescript
export default function OnboardingLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6">
      <div className="w-full max-w-md">
        <OnboardingProgress />
        {children}
      </div>
    </div>
  )
}
```

## Étape workspace (Server Action)
```typescript
'use server'
export async function createWorkspace(formData: FormData) {
  const session = await auth()
  if (!session) redirect('/login')

  const name = formData.get('name') as string
  const slug = slugify(name)

  const workspace = await db.workspace.create({
    data: {
      name, slug,
      members: { create: { userId: session.user.id, role: 'owner' } },
    },
  })

  // Mettre à jour le JWT avec le nouveau workspaceId
  await updateSessionWorkspace(workspace.id)
  redirect('/onboarding/invite')
}
```

## Middleware de protection onboarding
```typescript
// Rediriger vers onboarding si le user n'a pas de workspace
if (!session.user.workspaceId && !pathname.startsWith('/onboarding')) {
  return NextResponse.redirect(new URL('/onboarding/workspace', request.url))
}
```
