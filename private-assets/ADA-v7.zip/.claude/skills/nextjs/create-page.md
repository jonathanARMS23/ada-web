# create-page
Page App Router complète avec loading, error, metadata.

## Structure
```
app/<route>/
  page.tsx        # Server Component principal
  loading.tsx     # Skeleton
  error.tsx       # Error boundary
  layout.tsx      # Layout si section dédiée
```

## Template page.tsx
```typescript
import { Metadata } from 'next'
import { notFound } from 'next/navigation'

export const metadata: Metadata = {
  title: '<Titre>',
  description: '<Description>',
}

interface Props {
  params: { id: string }
  searchParams: { [key: string]: string }
}

export default async function Page({ params, searchParams }: Props) {
  const data = await getData(params.id)
  if (!data) notFound()

  return (
    <main>
      {/* contenu */}
    </main>
  )
}

async function getData(id: string) {
  // fetch serveur — cache automatique Next.js
  const res = await fetch(`${process.env.API_URL}/resource/${id}`, {
    next: { revalidate: 60 },
  })
  if (!res.ok) return null
  return res.json()
}
```
