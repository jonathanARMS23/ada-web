# create-pricing-page
Page pricing avec plans, toggle mensuel/annuel, CTA Stripe Checkout.

## Structure
```
app/(marketing)/pricing/
  page.tsx          # Server Component — fetch les plans depuis l'API
  loading.tsx
  _components/
    PricingCard.tsx  # Client Component
    PlanToggle.tsx   # mensuel / annuel
```

## PricingCard
```typescript
'use client'
interface Plan {
  name: string
  price: { monthly: number; yearly: number }
  features: string[]
  priceId: { monthly: string; yearly: string }
  highlighted?: boolean
}

export function PricingCard({ plan, billing, currentPlan }: {
  plan: Plan
  billing: 'monthly' | 'yearly'
  currentPlan?: string
}) {
  const [loading, setLoading] = useState(false)
  const price = plan.price[billing]
  const priceId = plan.priceId[billing]

  async function handleCheckout() {
    setLoading(true)
    const res = await fetch('/api/billing/checkout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ priceId }),
    })
    const { url } = await res.json()
    window.location.href = url
  }

  return (
    <div className={cn('border rounded-xl p-6', plan.highlighted && 'border-primary ring-2 ring-primary')}>
      {plan.highlighted && <Badge>Populaire</Badge>}
      <h3 className="text-xl font-semibold">{plan.name}</h3>
      <div className="mt-4">
        <span className="text-4xl font-bold">{price}€</span>
        <span className="text-muted-foreground">/mois</span>
        {billing === 'yearly' && (
          <Badge variant="secondary" className="ml-2">-20%</Badge>
        )}
      </div>
      <ul className="mt-6 space-y-2">
        {plan.features.map(f => (
          <li key={f} className="flex items-center gap-2">
            <Check className="h-4 w-4 text-primary" /> {f}
          </li>
        ))}
      </ul>
      <Button
        className="w-full mt-8"
        onClick={handleCheckout}
        disabled={loading || currentPlan === plan.name}
        variant={plan.highlighted ? 'default' : 'outline'}
      >
        {currentPlan === plan.name ? 'Plan actuel' : loading ? 'Chargement...' : 'Commencer'}
      </Button>
    </div>
  )
}
```
