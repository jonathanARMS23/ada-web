# create-server-action
Server Action avec validation, revalidation, error boundary.

## Template
```typescript
'use server'

import { revalidatePath, revalidateTag } from 'next/cache'
import { redirect } from 'next/navigation'
import { z } from 'zod'
import { auth } from '@/lib/auth'

const schema = z.object({
  name: z.string().min(1),
})

export async function createResource(formData: FormData) {
  const session = await auth()
  if (!session) redirect('/login')

  const parsed = schema.safeParse(Object.fromEntries(formData))
  if (!parsed.success) {
    return { errors: parsed.error.flatten().fieldErrors }
  }

  try {
    await db.resource.create({
      data: { ...parsed.data, userId: session.user.id },
    })
  } catch {
    return { error: 'Erreur lors de la création' }
  }

  revalidatePath('/resources')
  redirect('/resources')
}
```
