# create-server-component
Server Component avec fetch, cache et streaming.

```typescript
// Fetch avec revalidation
async function getResources(workspaceId: string) {
  const res = await fetch(`${process.env.API_URL}/resources?workspace=${workspaceId}`, {
    next: { revalidate: 60, tags: [`resources-${workspaceId}`] },
    headers: { Authorization: `Bearer ${await getServerToken()}` },
  })
  if (!res.ok) throw new Error('Fetch failed')
  return res.json()
}

// Streaming avec Suspense
export default async function ResourcesPage() {
  return (
    <div>
      <h1>Ressources</h1>
      <Suspense fallback={<ResourceListSkeleton />}>
        <ResourceList />  {/* async SC — streame quand prêt */}
      </Suspense>
    </div>
  )
}

async function ResourceList() {
  const resources = await getResources(await getWorkspaceId())
  return <ul>{resources.map(r => <li key={r.id}>{r.name}</li>)}</ul>
}
```
