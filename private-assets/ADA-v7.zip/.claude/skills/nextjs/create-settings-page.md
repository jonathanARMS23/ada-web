# create-settings-page
Pages Settings workspace : membres, plan, profil, danger zone.

## Structure
```
app/(dashboard)/settings/
  layout.tsx        # sidebar settings
  page.tsx          # redirect → /settings/workspace
  workspace/        # infos workspace (nom, slug, logo)
  members/          # liste membres + invitations
  billing/          # plan actuel + upgrade + portail Stripe
  profile/          # profil utilisateur
  danger/           # supprimer workspace
```

## Page billing — fetch depuis l'API
```typescript
export default async function BillingPage() {
  const session = await auth()
  const [subscription, invoices] = await Promise.all([
    api.billing.getSubscription(session.user.workspaceId),
    api.billing.getInvoices(session.user.workspaceId),
  ])

  return (
    <div className="space-y-8">
      <CurrentPlanCard subscription={subscription} />
      <InvoicesList invoices={invoices} />
      <ManageBillingButton />  {/* → Stripe Portal */}
    </div>
  )
}
```

## Invitations membres (Server Action)
```typescript
'use server'
export async function inviteMember(formData: FormData) {
  const session = await auth()
  const email = formData.get('email') as string
  const role = formData.get('role') as string

  // Vérifier que l'appelant est admin/owner
  const caller = await getMember(session.user.id, session.user.workspaceId)
  if (!['admin', 'owner'].includes(caller.role)) throw new Error('Unauthorized')

  await db.invitation.create({
    data: {
      email, role,
      workspaceId: session.user.workspaceId,
      token: randomUUID(),
      expiresAt: addDays(new Date(), 7),
    },
  })
  await sendInvitationEmail(email, session.user.workspaceId)
  revalidatePath('/settings/members')
}
```

## Danger zone
```typescript
'use server'
export async function deleteWorkspace(workspaceId: string) {
  const session = await auth()
  const member = await getMember(session.user.id, workspaceId)
  if (member.role !== 'owner') throw new Error('Only the owner can delete the workspace')

  // Soft delete — les données restent 30 jours
  await db.workspace.update({
    where: { id: workspaceId },
    data: { deletedAt: new Date(), status: 'deleting' },
  })
  // Job de nettoyage planifié par pg_cron
  redirect('/goodbye')
}
```
