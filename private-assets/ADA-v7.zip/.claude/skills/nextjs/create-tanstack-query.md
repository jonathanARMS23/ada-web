# create-tanstack-query
Hook useQuery/useMutation avec optimistic updates.

## Setup
```typescript
// providers.tsx
'use client'
export function Providers({ children }: { children: React.ReactNode }) {
  const [queryClient] = useState(() => new QueryClient({
    defaultOptions: { queries: { staleTime: 60 * 1000 } },
  }))
  return <QueryClientProvider client={queryClient}>{children}</QueryClientProvider>
}
```

## useQuery
```typescript
export function useResources(workspaceId: string) {
  return useQuery({
    queryKey: ['resources', workspaceId],
    queryFn: () => api.resources.list(workspaceId),
    enabled: !!workspaceId,
  })
}
```

## useMutation avec optimistic update
```typescript
export function useCreateResource() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: api.resources.create,
    onMutate: async (newResource) => {
      await queryClient.cancelQueries({ queryKey: ['resources'] })
      const prev = queryClient.getQueryData(['resources'])
      queryClient.setQueryData(['resources'], (old: any[]) => [...old, newResource])
      return { prev }
    },
    onError: (_, __, context) => {
      queryClient.setQueryData(['resources'], context?.prev)
    },
    onSettled: () => queryClient.invalidateQueries({ queryKey: ['resources'] }),
  })
}
```
