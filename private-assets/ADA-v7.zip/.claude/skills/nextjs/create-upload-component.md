# create-upload-component
Upload avec drag-and-drop, preview, progress, validation.

```typescript
'use client'
import { useDropzone } from 'react-dropzone'

const ACCEPTED = { 'image/*': ['.jpg', '.png', '.webp'], 'application/pdf': ['.pdf'] }
const MAX_SIZE = 5 * 1024 * 1024  // 5MB

export function FileUpload({ onUpload }: { onUpload: (url: string) => void }) {
  const [progress, setProgress] = useState(0)
  const [preview, setPreview] = useState<string | null>(null)

  const { getRootProps, getInputProps, isDragActive, fileRejections } = useDropzone({
    accept: ACCEPTED, maxSize: MAX_SIZE, maxFiles: 1,
    onDrop: async ([file]) => {
      if (!file) return
      if (file.type.startsWith('image/')) setPreview(URL.createObjectURL(file))
      const formData = new FormData()
      formData.append('file', file)
      const xhr = new XMLHttpRequest()
      xhr.upload.onprogress = (e) => setProgress(Math.round((e.loaded / e.total) * 100))
      xhr.onload = () => { const { url } = JSON.parse(xhr.response); onUpload(url) }
      xhr.open('POST', '/api/upload')
      xhr.send(formData)
    },
  })

  return (
    <div {...getRootProps()} className={cn('border-2 border-dashed rounded-lg p-8 cursor-pointer',
      isDragActive ? 'border-primary bg-primary/5' : 'border-muted')}>
      <input {...getInputProps()} />
      {preview ? <img src={preview} className="max-h-40 mx-auto" alt="preview" /> :
        <p className="text-center text-muted-foreground">Glisser un fichier ou cliquer</p>}
      {progress > 0 && progress < 100 && <Progress value={progress} className="mt-4" />}
      {fileRejections[0] && <p className="text-destructive text-sm mt-2">
        {fileRejections[0].errors[0].message}
      </p>}
    </div>
  )
}
```
