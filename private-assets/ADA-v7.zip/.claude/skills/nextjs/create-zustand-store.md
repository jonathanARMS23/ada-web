# create-zustand-store
Store Zustand typé avec actions, selectors, persistance.

## Store typé
```typescript
interface ResourceStore {
  resources: Resource[]
  selectedId: string | null
  isLoading: boolean
  // actions
  setResources: (resources: Resource[]) => void
  selectResource: (id: string) => void
  reset: () => void
}

const initialState = { resources: [], selectedId: null, isLoading: false }

export const useResourceStore = create<ResourceStore>()(
  persist(
    (set) => ({
      ...initialState,
      setResources: (resources) => set({ resources }),
      selectResource: (id) => set({ selectedId: id }),
      reset: () => set(initialState),
    }),
    { name: 'resource-store', partialize: (s) => ({ selectedId: s.selectedId }) }
  )
)
```

## Selectors
```typescript
export const useSelectedResource = () =>
  useResourceStore(s => s.resources.find(r => r.id === s.selectedId))
```
