# llm-metrics
Compteurs tokens/min, coût estimé/appel, taux d'erreur, latence p50/p95/p99.

```python
from prometheus_client import Counter, Histogram, Gauge

# Métriques Prometheus
llm_tokens_total = Counter("llm_tokens_total", "Total tokens", ["model", "type"])
llm_latency = Histogram("llm_latency_seconds", "LLM latency", ["model"],
    buckets=[0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0])
llm_errors_total = Counter("llm_errors_total", "LLM errors", ["model", "error_type"])
llm_cost_total = Counter("llm_cost_usd_total", "LLM cost USD", ["model"])

PRICE_PER_TOKEN = {
    "deepseek-chat": 0.00000027,   # $0.27/1M tokens
    "gpt-4o": 0.000005,
    "local": 0.0,
}

def record_llm_call(result: LLMResponse):
    model = result.model
    llm_tokens_total.labels(model=model, type="prompt").inc(result.prompt_tokens)
    llm_tokens_total.labels(model=model, type="completion").inc(result.completion_tokens)
    llm_latency.labels(model=model).observe(result.latency_ms / 1000)
    
    price = PRICE_PER_TOKEN.get(model, 0)
    cost = (result.prompt_tokens + result.completion_tokens) * price
    llm_cost_total.labels(model=model).inc(cost)
```
