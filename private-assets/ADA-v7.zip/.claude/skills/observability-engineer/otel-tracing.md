# otel-tracing
OpenTelemetry SDK, spans par appel LLM, attributs (model, tokens, latency), exporters.

```python
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter

# Setup
provider = TracerProvider()
provider.add_span_processor(BatchSpanProcessor(OTLPSpanExporter(endpoint="http://tempo:4317")))
trace.set_tracer_provider(provider)
tracer = trace.get_tracer("ai-system")

# Wrapper LLM avec tracing
async def traced_llm_call(provider, messages, **kwargs):
    with tracer.start_as_current_span("llm.complete") as span:
        span.set_attribute("llm.model", provider.model)
        span.set_attribute("llm.messages.count", len(messages))
        
        try:
            result = await provider.complete(messages, **kwargs)
            span.set_attribute("llm.prompt_tokens", result.prompt_tokens)
            span.set_attribute("llm.completion_tokens", result.completion_tokens)
            span.set_attribute("llm.latency_ms", result.latency_ms)
            return result
        except Exception as e:
            span.record_exception(e)
            span.set_status(trace.StatusCode.ERROR, str(e))
            raise
```
