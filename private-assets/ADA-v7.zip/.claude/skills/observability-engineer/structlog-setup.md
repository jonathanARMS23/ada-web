# structlog-setup
structlog configuration, processors, contextvars (conversation_id), JSON output.

```python
import structlog
from contextvars import ContextVar

conversation_id_var: ContextVar[str] = ContextVar("conversation_id", default="")

def add_conversation_id(logger, method, event_dict):
    conv_id = conversation_id_var.get("")
    if conv_id:
        event_dict["conversation_id"] = conv_id
    return event_dict

structlog.configure(
    processors=[
        structlog.contextvars.merge_contextvars,
        add_conversation_id,
        structlog.stdlib.add_log_level,
        structlog.stdlib.add_logger_name,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.JSONRenderer(),  # JSON pur → Loki/ELK
    ],
    wrapper_class=structlog.make_filtering_bound_logger(logging.INFO),
    logger_factory=structlog.PrintLoggerFactory(),
)

log = structlog.get_logger()

# Usage avec contexte de conversation
async def handle_request(conv_id: str, messages: list):
    conversation_id_var.set(conv_id)
    log.info("llm.call.start", message_count=len(messages))
    result = await llm.complete(messages)
    log.info("llm.call.done", tokens=result.completion_tokens, latency_ms=result.latency_ms)
    return result
```
