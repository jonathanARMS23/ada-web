# assess-code-quality
Évaluation rapide de la qualité d'un codebase.

## Commandes d'évaluation rapide
```bash
# Tests et coverage
npm test -- --coverage --passWithNoTests 2>/dev/null | tail -20
python -m pytest --co -q 2>/dev/null | tail -5

# Linting
npm run lint 2>&1 | tail -10
flake8 . --count --statistics 2>/dev/null | tail -5

# Taille du codebase
find src -name "*.ts" -o -name "*.py" | xargs wc -l | tail -1
find src -name "*.ts" | wc -l  # nombre de fichiers

# Fichiers géants (> 300 lignes = signal)
find src -name "*.ts" -o -name "*.py" | xargs wc -l | sort -rn | head -10
```

## Grille d'évaluation
```
## Code Quality Assessment

### Tests
- Coverage : X%
- Nombre de tests : X
- Tests cassés : X
- Score : 🟢 > 70% | 🟡 40-70% | 🔴 < 40%

### Structure
- Fichiers > 300 lignes : X (🟢 0 | 🟡 1-5 | 🔴 > 5)
- Responsabilités mixtes : oui/non
- Conventions respectées : oui/partiellement/non

### Dette technique visible
- [liste des problèmes observés]

### Score global : 🟢 Sain | 🟡 Attention | 🔴 Critique
```
