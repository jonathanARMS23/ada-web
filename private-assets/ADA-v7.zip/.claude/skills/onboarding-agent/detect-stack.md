# detect-stack
Détecter la stack technique sans lire les fichiers en entier.

## Protocole grep-first
```bash
# Backend
ls package.json 2>/dev/null && node -e "const p=require('./package.json'); const deps={...p.dependencies,...p.devDependencies}; ['nestjs','express','fastify','hapi'].forEach(f=>Object.keys(deps).find(k=>k.includes(f))&&console.log('Backend:',f))" 2>/dev/null
ls requirements.txt 2>/dev/null && grep -E "django|fastapi|flask" requirements.txt | head -3
ls pyproject.toml 2>/dev/null && grep -E "django|fastapi|flask" pyproject.toml | head -3

# Frontend
ls package.json 2>/dev/null && node -e "const p=require('./package.json'); const deps={...p.dependencies,...p.devDependencies}; ['next','react','vue','svelte','nuxt'].forEach(f=>Object.keys(deps).find(k=>k.includes(f))&&console.log('Frontend:',f))" 2>/dev/null

# DB
grep -r "postgresql\|postgres\|mysql\|mongodb\|sqlite" . \
  --include="*.env*" --include="docker-compose*" --include="*.toml" \
  -l 2>/dev/null | head -3
grep -r "supabase\|prisma\|typeorm\|sequelize\|mongoose" package.json 2>/dev/null | head -3

# Infra
ls docker-compose.yml docker-compose.yaml 2>/dev/null && echo "Infra: Docker Compose"
ls .github/workflows/*.yml 2>/dev/null | head -2 && echo "CI: GitHub Actions"
ls railway.toml render.yaml fly.toml 2>/dev/null | head -1
```

## Rapport
```
Stack détectée :
  Backend  : NestJS 10 / Django 4.2 / [autre]
  Frontend : Next.js 15 / React 18 / [autre]
  DB       : PostgreSQL + Prisma / Supabase / [autre]
  Cache    : Redis / [aucun]
  CI/CD    : GitHub Actions → [Railway/AWS/Vercel]
  Test     : Jest / pytest / [autre]
```
