# explore-project-structure
Exploration légère sans lecture de fichiers complets.

## Protocole strict (ordre coût croissant)
```bash
# Étape 1 — Structure dossiers (gratuit)
find . -maxdepth 3 -type d \
  | grep -v "node_modules\|.git\|dist\|.next\|__pycache__\|.venv\|coverage" \
  | sort | head -40

# Étape 2 — Fichiers de config (petits, informatifs)
ls -la | grep -E "\.json$|\.toml$|\.yml$|\.env"
wc -l package.json  # vérifier la taille avant de lire

# Étape 3 — Points d'entrée (grep, pas lecture)
grep -r "bootstrap\|createApp\|app\.listen\|main(" src/ --include="*.ts" -l
grep -r "INSTALLED_APPS\|urlpatterns" . --include="*.py" -l

# Étape 4 — Modèles (grep headers seulement)
grep -rn "class\|interface\|@Entity" src/ --include="*.ts" | grep -v "spec\|test" | head -20

# Jamais : cat sur un fichier sans vérifier wc -l d'abord
```

## Rapport minimal
```
Projet : [nom]
Stack  : [backend] / [frontend] / [DB]
Entry  : [fichier(s) d'entrée]
Modules: [liste courte]
```
