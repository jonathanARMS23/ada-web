# find-entry-points
Trouver les points d'entrée principaux du projet.

## Backend
```bash
# NestJS
grep -rn "NestFactory\|bootstrap" src/ --include="*.ts" -l
cat src/main.ts 2>/dev/null | head -30

# Django
find . -name "wsgi.py" -o -name "asgi.py" | head -3
grep -rn "urlpatterns" . --include="urls.py" -l | head -5

# FastAPI
grep -rn "FastAPI()\|app = FastAPI" . --include="*.py" | head -3
```

## Frontend
```bash
# Next.js App Router
ls app/ 2>/dev/null | head -20
cat app/layout.tsx 2>/dev/null | head -30

# Routes API
find app/api -name "route.ts" 2>/dev/null | head -10
```

## Workers / Tâches planifiées
```bash
grep -rn "Cron\|@Process\|@Worker" src/ --include="*.ts" | head -5
find . -name "tasks.py" -o -name "worker.py" | head -5
```

## Résumé
```
Points d'entrée identifiés :
  API          : src/main.ts → AppModule → [modules]
  Frontend     : app/layout.tsx → app/page.tsx
  Workers      : src/workers/queue.processor.ts
  Scripts admin: manage.py [commandes personnalisées]
  CI/CD        : .github/workflows/deploy.yml

Ports :
  API  : 3000
  Web  : 3001
  DB   : 5432
```
