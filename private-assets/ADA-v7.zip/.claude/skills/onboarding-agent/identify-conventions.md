# identify-conventions
Détecter les conventions du projet sans les deviner.

## Conventions de nommage (grep)
```bash
# Nommage des fichiers
find src -name "*.ts" | head -20 | xargs -I{} basename {} | sort
# → kebab-case? camelCase? PascalCase?

# Nommage des classes
grep -rn "^export class\|^class " src/ --include="*.ts" | head -10

# Nommage des endpoints
grep -rn "@Get\|@Post\|@Put\|@Patch\|@Delete" src/ --include="*.ts" | head -10
```

## Structure et patterns (grep)
```bash
# Pattern utilisé (repository? service layer? direct prisma?)
grep -rn "Repository\|@InjectRepository\|@Injectable" src/ --include="*.ts" | wc -l

# Gestion des erreurs (exceptions custom ou standard?)
grep -rn "throw new\|HttpException\|NotFoundException" src/ --include="*.ts" | head -5

# Tests (describe/it ou describe/test?)
grep -rn "^  it(\|^  test(" src/ --include="*.spec.ts" | head -5
```

## Conventions détectées
```
Fichiers       : kebab-case (resource.service.ts)
Classes        : PascalCase (ResourceService)
Variables      : camelCase
DB columns     : snake_case
Erreurs        : NestJS HttpException standard
Tests          : describe/it, factories factory_boy
Commentaires   : français / anglais
DTOs           : suffixe Dto (CreateResourceDto)
```
