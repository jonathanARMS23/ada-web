# map-codebase
Cartographier la structure d'un projet en < 2 minutes.

## Commandes (ordre coût croissant)
```bash
# 1. Structure dossiers
find . -maxdepth 4 -type d \
  | grep -v "node_modules\|.git\|dist\|.next\|__pycache__\|.venv\|coverage\|.pytest_cache" \
  | sort | head -50

# 2. Fichiers de config clés (taille avant lecture)
for f in package.json tsconfig.json prisma/schema.prisma pyproject.toml settings.py; do
  [ -f "$f" ] && echo "--- $f ($(wc -l < $f) lignes) ---"
done

# 3. Points d'entrée
grep -rn "bootstrap\|app\.listen\|main(" src/ --include="*.ts" -l 2>/dev/null | head -5
find . -name "manage.py" -o -name "wsgi.py" -o -name "asgi.py" 2>/dev/null | head -3

# 4. Modules/apps (noms seulement)
ls src/ 2>/dev/null
python3 -c "import os; [print(d) for d in os.listdir('.') if os.path.isfile(f'{d}/models.py')]" 2>/dev/null
```

## Carte résultante
```
Projet : <nom>
├── API (<N> modules) : [liste des modules]
├── Frontend (<N> pages) : [routes principales]
├── DB (<N> tables) : [tables principales]
└── Workers : [présent/absent]

Complexité estimée : Simple / Modérée / Complexe
Taille : ~<N>k lignes de code
```
