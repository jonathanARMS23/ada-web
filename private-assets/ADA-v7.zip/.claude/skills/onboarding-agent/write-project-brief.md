# write-project-brief
Brief complet pour démarrer sur un projet inconnu.

## Template
```markdown
## Project Brief — <nom>

### En une phrase
[Ce que fait ce projet, pour qui, comment]

### Stack
| Couche | Technologie | Version |
|--------|-------------|---------|
| Backend | NestJS | 10.x |
| Frontend | Next.js | 15.x |
| DB | PostgreSQL + Prisma | 15 / 5.x |

### Architecture
[Diagramme textuel ou description en 3-5 lignes]

### Modules principaux
| Module | Rôle | Fichier clé |
|--------|------|-------------|

### Conventions détectées
- Nommage : [kebab-case fichiers, PascalCase classes]
- Patterns : [repository pattern, service layer]
- Tests : [Jest, coverage X%]
- Git : [conventional commits, feature branches]

### Pour démarrer
```bash
cp .env.example .env
npm install
npm run db:migrate
npm run dev
```

### Points d'attention
- [dette technique visible]
- [partie du code complexe à comprendre]
- [dépendances fragiles]
```
