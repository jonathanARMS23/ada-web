# consolidate-results
Fusionner les outputs de plusieurs agents en un résumé actionnable.

## Format de sortie obligatoire
```
## Résumé — [nom de la feature]
**Agents sollicités :** [liste]
**Fait :**
- [liste courte]
**Fichiers créés/modifiés :**
- [liste avec chemins]
**Décisions prises :**
- [liste]
**Prochaines étapes :**
- [liste ordonnée]
**Blockers :** [si présents]
```
