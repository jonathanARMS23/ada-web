# delegate-feature
Orchestrer une feature complète de bout en bout.

## Étapes
1. Analyser le prompt → identifier complexité (simple/modérée/complexe)
2. Lire `active-profile.txt` → confirmer ou ajuster le profil
3. Déléguer dans l'ordre : db → tester → backend → frontend → reviewer
4. Après chaque délégation : vérifier le résultat avant de passer au suivant
5. Consolider : résumé fait/décisions/fichiers/prochaines étapes

## Règles
- Max 3 agents par délégation
- Ne pas re-déléguer si l'agent précédent a produit une erreur — la traiter d'abord
- Si complexité = simple : 1 seul agent suffit
