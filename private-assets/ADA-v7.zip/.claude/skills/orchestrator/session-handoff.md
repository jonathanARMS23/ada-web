# session-handoff
Préparer un /compact structuré pour reprendre une session sans perte.

## Étapes
1. Extraire de la session courante :
   - Tâche principale (1 phrase)
   - Ce qui est fait (liste courte)
   - Décisions prises (liste courte)
   - Fichiers touchés
   - Prochaine étape immédiate (1 phrase précise)
   - Blockers actifs
2. Produire le bloc de continuation
3. Sauvegarder dans `memory/projects/<projet>/archive/`
4. Afficher les instructions /clear

## Bloc de continuation
```
Projet : [nom] | Profil : [X] | Suite de session
Fait : [liste]
Décisions : [liste]
Prochain : [action précise]
```
