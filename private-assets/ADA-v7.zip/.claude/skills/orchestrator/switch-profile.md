# switch-profile
Changer de profil en cours de session proprement.

## Étapes
1. Vérifier que la tâche courante est terminée ou en pause propre
2. Produire un résumé minimal de l'état actuel (2-3 lignes)
3. Écrire le nouveau profil dans `active-profile.txt`
4. Annoncer les nouveaux agents actifs
5. Continuer avec `[Profil: nouveau] [Échange N/7]`

## Exemple
```
Profil précédent : fullstack (nestjs · nextjs · db)
Tâche en cours : implémentation CRUD produits — backend terminé, frontend en cours

Passage en revue → profil activé : review (reviewer · security-auditor · performance-analyst)
Agents actifs : reviewer · security-auditor · performance-analyst
```
