# triage-task
Analyser un prompt et choisir le bon profil sans sur-déléguer.

## Étapes
1. Lire le prompt → extraire : domaine, action, périmètre
2. Matcher contre la table routing dans CLAUDE.md
3. Évaluer la complexité :
   - Simple (1 fichier, 1 concept) → 1 agent
   - Modérée (1 feature, plusieurs fichiers) → 2-3 agents
   - Complexe (feature cross-domain) → 3 agents max, plusieurs sessions
4. Annoncer : `[Profil: X] [Agents: a · b · c]`

## Anti-patterns
- Ne pas invoquer feature-architect pour un bug fix simple
- Ne pas invoquer reviewer si c'est une question, pas du code
