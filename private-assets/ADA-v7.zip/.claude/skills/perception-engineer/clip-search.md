# clip-search
Skill : clip-search — agent perception-engineer.
