# piper-tts
Piper installation, modèle FR, synthesis, output WAV, streaming WebSocket.

## Installation
```bash
pip install piper-tts
wget https://huggingface.co/rhasspy/piper-voices/resolve/main/fr/fr_FR/siwis/medium/fr_FR-siwis-medium.onnx
wget https://huggingface.co/rhasspy/piper-voices/resolve/main/fr/fr_FR/siwis/medium/fr_FR-siwis-medium.onnx.json
```

## Synthèse
```python
from piper import PiperVoice
import wave, io

voice = PiperVoice.load("fr_FR-siwis-medium.onnx")

def synthesize_to_bytes(text: str) -> bytes:
    buffer = io.BytesIO()
    with wave.open(buffer, "wb") as wav_file:
        wav_file.setnchannels(1)
        wav_file.setsampwidth(2)  # 16-bit
        wav_file.setframerate(voice.config.sample_rate)
        voice.synthesize(text, wav_file)
    return buffer.getvalue()
```

## Streaming WebSocket
```python
@ws_router.websocket("/tts/stream")
async def tts_stream(ws: WebSocket):
    await ws.accept()
    text = await ws.receive_text()
    audio_bytes = await asyncio.to_thread(synthesize_to_bytes, text)
    chunk_size = 4096
    for i in range(0, len(audio_bytes), chunk_size):
        await ws.send_bytes(audio_bytes[i:i+chunk_size])
    await ws.close()
```
