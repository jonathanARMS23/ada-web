# vad-chunking
silero-vad, threshold/min_silence_ms, buffer circulaire PyAudio, segmentation.

```python
import torch
import pyaudio
import numpy as np

class VADChunker:
    def __init__(self, threshold: float = 0.5, min_silence_ms: int = 300, sample_rate: int = 16000):
        model, utils = torch.hub.load("snakers4/silero-vad", "silero_vad", force_reload=False)
        self.model = model
        self.get_speech = utils[0]  # get_speech_timestamps
        self.threshold = threshold
        self.min_silence_ms = min_silence_ms
        self.sample_rate = sample_rate

    def is_speech(self, audio_chunk: np.ndarray) -> bool:
        tensor = torch.from_numpy(audio_chunk).float()
        confidence = self.model(tensor, self.sample_rate).item()
        return confidence > self.threshold

    def get_chunks(self, audio: np.ndarray) -> list[dict]:
        tensor = torch.from_numpy(audio).float()
        return self.get_speech(
            tensor, self.sample_rate,
            threshold=self.threshold,
            min_silence_duration_ms=self.min_silence_ms,
        )
```
