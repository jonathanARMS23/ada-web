# whisper-pipeline
faster-whisper WhisperModel, model_size, compute_type, transcription async.

```python
from faster_whisper import WhisperModel
import asyncio

class WhisperPipeline:
    def __init__(self, model_size: str = "medium", device: str = "cuda", compute_type: str = "float16"):
        self.model = WhisperModel(model_size, device=device, compute_type=compute_type)
        # compute_type : "float16" (GPU), "int8" (CPU rapide), "float32" (CPU précis)

    async def transcribe(self, audio_path: str, language: str = "fr") -> str:
        loop = asyncio.get_event_loop()
        segments, info = await loop.run_in_executor(
            None,
            lambda: self.model.transcribe(
                audio_path,
                language=language,
                beam_size=5,
                vad_filter=True,          # filtre silence automatique
                vad_parameters={"min_silence_duration_ms": 500},
            )
        )
        return " ".join(s.text.strip() for s in segments)
```
