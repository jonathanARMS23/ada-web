# add-caching-layer
Cache Redis multi-couche avec invalidation propre.

## Pattern cache-aside NestJS
```typescript
@Injectable()
export class CacheService {
  constructor(@InjectRedis() private redis: Redis) {}

  async getOrSet<T>(key: string, ttl: number, factory: () => Promise<T>): Promise<T> {
    const cached = await this.redis.get(key)
    if (cached) return JSON.parse(cached)
    const value = await factory()
    await this.redis.setex(key, ttl, JSON.stringify(value))
    return value
  }

  async invalidate(pattern: string) {
    const keys = await this.redis.keys(pattern)
    if (keys.length) await this.redis.del(...keys)
  }
}

// Usage dans un service
async getResources(workspaceId: string) {
  return this.cache.getOrSet(
    `resources:${workspaceId}`,
    300,  // 5 min
    () => this.prisma.resource.findMany({ where: { workspaceId } })
  )
}

async updateResource(id: string, data: any) {
  const result = await this.prisma.resource.update({ where: { id }, data })
  await this.cache.invalidate(`resources:${result.workspaceId}*`)
  return result
}
```
