# add-cdn-strategy
Stratégie CDN : assets statiques, cache headers, invalidation.

## Cloudflare (le plus simple)
```
1. Pointer le DNS vers Cloudflare
2. Activer le proxying (nuage orange)
3. Cache Rule : assets statiques → 1 an
4. Cache Rule : /api/* → bypass cache
```

## Cache headers Next.js
```typescript
// next.config.js
async headers() {
  return [{
    source: '/_next/static/:path*',
    headers: [{ key: 'Cache-Control', value: 'public, max-age=31536000, immutable' }],
  }, {
    source: '/api/:path*',
    headers: [{ key: 'Cache-Control', value: 'no-store' }],
  }, {
    source: '/:path*.jpg',
    headers: [{ key: 'Cache-Control', value: 'public, max-age=86400, stale-while-revalidate=3600' }],
  }]
}
```

## Invalidation Cloudflare
```bash
# Via API Cloudflare
curl -X POST "https://api.cloudflare.com/client/v4/zones/$ZONE_ID/purge_cache" \
  -H "Authorization: Bearer $CF_TOKEN" \
  -d '{"files": ["https://example.com/path/to/file"]}'
```
