# add-pagination-strategy
Migration offset → cursor pour grandes tables.

## Pourquoi migrer
- Offset pagination : OFFSET 10000 → PostgreSQL parcourt 10000 lignes pour les ignorer
- Cursor pagination : reprend exactement là où on s'est arrêté, O(1)

## Migration en 2 phases

### Phase 1 — Supporter les deux
```typescript
async findAll(params: { page?: number; cursor?: string; limit: number }) {
  if (params.cursor) {
    return this.findByCursor(params.cursor, params.limit)
  }
  return this.findByOffset(params.page ?? 1, params.limit)
}
```

### Phase 2 — Cursor seulement
```typescript
async findByCursor(cursor: string | undefined, limit: number) {
  const where = cursor ? {
    AND: [
      { createdAt: { lt: decodeCursor(cursor).createdAt } },
    ]
  } : {}

  const items = await this.prisma.resource.findMany({
    where, take: limit + 1, orderBy: { createdAt: 'desc' },
  })

  const hasNext = items.length > limit
  if (hasNext) items.pop()

  return {
    data: items,
    nextCursor: hasNext ? encodeCursor(items[items.length - 1]) : null,
    hasNext,
  }
}
```
