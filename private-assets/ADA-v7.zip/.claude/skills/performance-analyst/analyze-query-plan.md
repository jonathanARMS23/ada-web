# analyze-query-plan
EXPLAIN ANALYZE — lire et corriger un plan d'exécution.

## Commande
```sql
EXPLAIN (ANALYZE, BUFFERS, FORMAT TEXT)
SELECT r.*, w.name as workspace_name
FROM resources r
JOIN workspaces w ON w.id = r.workspace_id
WHERE r.workspace_id = 'uuid' AND r.deleted_at IS NULL
ORDER BY r.created_at DESC
LIMIT 20;
```

## Signaux d'alarme
```
Seq Scan sur grande table → INDEX MANQUANT
Rows Removed by Filter: X (élevé) → INDEX MAL CIBLÉ
Hash Join avec rows estimées très différentes de l'actuel → VACUUM + ANALYZE
Nested Loop avec N élevé → REQUÊTE N+1
Actual time > 100ms → OPTIMISATION REQUISE
Buffers: shared hit=0 read=élevé → DONNÉES PAS EN CACHE
```

## Fix type
```sql
-- Seq Scan → créer l'index manquant
CREATE INDEX CONCURRENTLY idx_resources_workspace_active
ON resources(workspace_id, created_at DESC)
WHERE deleted_at IS NULL;

-- Statistiques périmées
ANALYZE resources;
```
