# benchmark-comparison
Benchmark avant/après optimisation.

## Outils

### k6 (charge API)
```javascript
// benchmark.js
import http from 'k6/http'
import { check, sleep } from 'k6'

export const options = {
  stages: [
    { duration: '30s', target: 10 },   // ramp up
    { duration: '1m', target: 50 },    // charge normale
    { duration: '30s', target: 100 },  // pic
    { duration: '30s', target: 0 },    // ramp down
  ],
  thresholds: {
    'http_req_duration': ['p(95)<500'],  // 95% des requêtes < 500ms
    'http_req_failed': ['rate<0.01'],    // < 1% d'erreurs
  },
}

export default function () {
  const res = http.get('http://api.example.com/api/v1/resources', {
    headers: { Authorization: `Bearer ${__ENV.TOKEN}` },
  })
  check(res, { 'status 200': r => r.status === 200 })
  sleep(0.1)
}
```
```bash
k6 run benchmark.js --env TOKEN=xxx
```

## Format de rapport
```markdown
## Benchmark — <endpoint> — <date>

| Métrique | Avant | Après | Amélioration |
|----------|-------|-------|-------------|
| p50 | 250ms | 45ms | -82% |
| p95 | 800ms | 120ms | -85% |
| p99 | 2000ms | 350ms | -82% |
| RPS max | 50 | 280 | +460% |
| Error rate | 2.1% | 0% | ✅ |

**Changements appliqués :**
- Ajout index sur workspace_id
- Eager loading des relations
- Cache Redis 5min
```
