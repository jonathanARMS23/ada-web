# fix-n-plus-one
Détecter et corriger les requêtes N+1.

## Détection
```typescript
// NestJS — activer le logging Prisma
prisma.$on('query', (e) => {
  if (process.env.NODE_ENV === 'development') {
    console.log(`Query: ${e.query} (${e.duration}ms)`)
  }
})
// Chercher des patterns répétitifs dans les logs
```

```python
# Django — django-debug-toolbar ou logging
import logging
logger = logging.getLogger('django.db.backends')
logger.setLevel(logging.DEBUG)
```

## Correction NestJS/Prisma
```typescript
// ❌ N+1
const orders = await prisma.order.findMany()
for (const order of orders) {
  order.lineItems = await prisma.lineItem.findMany({ where: { orderId: order.id } })
}

// ✅ Eager loading
const orders = await prisma.order.findMany({
  include: { lineItems: true }
})
```

## Correction DRF
```python
# ❌ N+1
queryset = Order.objects.filter(workspace=workspace)
# Dans le serializer : self.context['request'].user → N requêtes

# ✅ select_related + prefetch_related
queryset = Order.objects.filter(workspace=workspace)\
    .select_related('created_by', 'workspace')\
    .prefetch_related('line_items__product')
```
