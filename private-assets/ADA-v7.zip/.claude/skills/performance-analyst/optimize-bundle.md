# optimize-bundle
Analyser et réduire le bundle JavaScript Next.js.

## Analyser
```bash
# Next.js bundle analyzer
npm i @next/bundle-analyzer
# next.config.js :
const withBundleAnalyzer = require('@next/bundle-analyzer')({ enabled: true })
module.exports = withBundleAnalyzer({})

npm run build  # génère .next/analyze/
```

## Causes fréquentes et fixes
```typescript
// ❌ Import de toute une librairie
import _ from 'lodash'
import { format } from 'date-fns'  // OK si tree-shaking actif

// ✅ Import ciblé
import debounce from 'lodash/debounce'

// ❌ Chargement synchrone d'un composant lourd
import { HeavyChart } from './HeavyChart'

// ✅ Lazy loading
const HeavyChart = dynamic(() => import('./HeavyChart'), {
  loading: () => <Skeleton />,
  ssr: false,
})

// ❌ Icônes importées en masse
import * as Icons from 'lucide-react'

// ✅ Import ciblé
import { Home, Settings } from 'lucide-react'
```

## Objectifs
- Bundle initial (First Load JS) : < 200KB
- Chaque route lazy : < 100KB
- LCP : < 2.5s
