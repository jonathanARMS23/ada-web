# optimize-images
Optimisation images : formats, lazy loading, CDN.

## Next.js — next/image
```typescript
import Image from 'next/image'

// ✅ Toujours utiliser next/image au lieu de <img>
<Image
  src="/hero.jpg"
  alt="Description précise"
  width={800}
  height={400}
  priority={isAboveFold}  // true pour les images above the fold
  placeholder="blur"
  blurDataURL={blurUrl}
  sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 800px"
/>
```

## Formats modernes
```bash
# Convertir en WebP (80% plus léger que JPEG)
cwebp -q 80 image.jpg -o image.webp
# Ou via sharp (Node.js)
sharp('image.jpg').webp({ quality: 80 }).toFile('image.webp')
```

## Objectifs
- Images JPEG/PNG → WebP ou AVIF
- Lazy loading sur toutes les images below the fold
- Dimensions explicites (évite le layout shift)
- CDN pour les assets statiques (Cloudflare, CloudFront)
