# optimize-react-renders
Réduire les re-renders inutiles.

## Diagnostiquer
```typescript
// React DevTools Profiler ou :
import { Profiler } from 'react'
<Profiler id="List" onRender={(id, phase, actualDuration) => {
  if (actualDuration > 16) console.warn(`${id} slow render: ${actualDuration}ms`)
}}>
  <MyList />
</Profiler>
```

## Fixes communs
```typescript
// ❌ Nouvel objet à chaque render
<Component options={{ limit: 20 }} />

// ✅ Mémoïsé
const options = useMemo(() => ({ limit: 20 }), [])
<Component options={options} />

// ❌ Callback recréé à chaque render
<Button onClick={() => handleClick(id)} />

// ✅ useCallback
const handleClick = useCallback((id: string) => { ... }, [])
<Button onClick={() => handleClick(id)} />

// ❌ Composant parent re-render = enfant re-render
const ChildComponent = ({ data }) => <div>{data.name}</div>

// ✅ memo si props stables
const ChildComponent = memo(({ data }) => <div>{data.name}</div>)

// ❌ Context qui re-render tout
const AppContext = createContext({ user, theme, settings })

// ✅ Contextes séparés par fréquence de changement
const UserContext = createContext(user)
const ThemeContext = createContext(theme)
```
