# profile-api-endpoint
Profiler un endpoint lent : DB, compute, sérialisation.

## Outils de profiling

### NestJS — intercepteur de mesure
```typescript
@Injectable()
export class ProfilingInterceptor implements NestInterceptor {
  intercept(ctx: ExecutionContext, next: CallHandler): Observable<any> {
    const req = ctx.switchToHttp().getRequest()
    const start = performance.now()
    return next.handle().pipe(
      tap(() => {
        const duration = performance.now() - start
        if (duration > 200) {
          console.warn(`[SLOW] ${req.method} ${req.url}: ${duration.toFixed(1)}ms`)
        }
      })
    )
  }
}
```

### Décomposer le temps
```typescript
async getResources(workspaceId: string) {
  const t0 = performance.now()
  const resources = await this.prisma.resource.findMany(...)
  console.log(`DB query: ${(performance.now() - t0).toFixed(1)}ms`)

  const t1 = performance.now()
  const result = this.transformer.transform(resources)
  console.log(`Transform: ${(performance.now() - t1).toFixed(1)}ms`)

  return result
}
```

## Checklist de profiling
1. Mesurer d'abord (ne pas optimiser à l'aveugle)
2. Identifier le goulot : DB > compute > sérialisation > réseau
3. Optimiser le goulot en premier
4. Mesurer à nouveau pour valider
