# asyncio-patterns
asyncio.gather, TaskGroup, Queue, Event, Semaphore, timeout, race conditions.

## gather — tâches parallèles
```python
results = await asyncio.gather(
    fetch_user(user_id),
    fetch_subscription(workspace_id),
    fetch_usage_stats(workspace_id),
    return_exceptions=True  # ne pas annuler si l'un échoue
)
```

## TaskGroup (Python 3.11+)
```python
async with asyncio.TaskGroup() as tg:
    t1 = tg.create_task(db_agent(context))
    t2 = tg.create_task(tester_agent(context))
# attendre les deux avant de continuer
results = [t1.result(), t2.result()]
```

## Semaphore — limiter la concurrence
```python
sem = asyncio.Semaphore(5)  # max 5 appels LLM simultanés

async def limited_llm_call(messages):
    async with sem:
        return await llm.complete(messages)
```

## Timeout
```python
try:
    result = await asyncio.wait_for(llm.complete(messages), timeout=30.0)
except asyncio.TimeoutError:
    raise HTTPException(status_code=504, detail="LLM timeout")
```
