# fastapi-router
APIRouter, prefix, tags, response_model, status_code, exception handlers.

```python
from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel

router = APIRouter(prefix="/api/v1/conversations", tags=["conversations"])

class MessageIn(BaseModel):
    content: str
    role: str = "user"

class MessageOut(BaseModel):
    id: str
    content: str
    role: str
    created_at: str

@router.post("/", response_model=MessageOut, status_code=status.HTTP_201_CREATED)
async def create_message(body: MessageIn, db=Depends(get_db)):
    msg = await db.messages.create(body.model_dump())
    return MessageOut.model_validate(msg)

@router.get("/{id}", response_model=MessageOut)
async def get_message(id: str, db=Depends(get_db)):
    msg = await db.messages.find_by_id(id)
    if not msg:
        raise HTTPException(status_code=404, detail="Message not found")
    return msg
```

## Exception handler global
```python
from fastapi import Request
from fastapi.responses import JSONResponse

@app.exception_handler(ValueError)
async def value_error_handler(request: Request, exc: ValueError):
    return JSONResponse(status_code=422, content={"detail": str(exc)})
```
