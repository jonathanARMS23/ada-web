# sse-streaming
EventSourceResponse, StreamingResponse, token-by-token LLM → client SSE.

```python
from fastapi import APIRouter
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
import json, asyncio

router = APIRouter()

class ChatRequest(BaseModel):
    messages: list[dict]
    model: str = "deepseek-chat"

@router.post("/chat/stream")
async def chat_stream(request: ChatRequest):
    async def event_generator():
        try:
            async for token in llm_provider.stream(request.messages):
                data = json.dumps({"token": token, "done": False})
                yield f"data: {data}\n\n"
            yield f"data: {json.dumps({'token': '', 'done': True})}\n\n"
        except asyncio.CancelledError:
            # Client a coupé la connexion
            return

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",      # nginx : pas de buffering
            "Connection": "keep-alive",
        }
    )
```
