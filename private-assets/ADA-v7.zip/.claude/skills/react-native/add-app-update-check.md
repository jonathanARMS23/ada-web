# add-app-update-check
Vérification et prompt mise à jour OTA avec expo-updates.

```typescript
import * as Updates from 'expo-updates'

export function useAppUpdate() {
  const [updateAvailable, setUpdateAvailable] = useState(false)

  useEffect(() => {
    checkForUpdate()
  }, [])

  async function checkForUpdate() {
    if (__DEV__) return
    try {
      const update = await Updates.checkForUpdateAsync()
      if (update.isAvailable) {
        setUpdateAvailable(true)
      }
    } catch (error) {
      console.error('Update check failed:', error)
    }
  }

  async function applyUpdate() {
    try {
      await Updates.fetchUpdateAsync()
      await Updates.reloadAsync()  // redémarre l'app avec la nouvelle version
    } catch (error) {
      Alert.alert('Erreur', 'Impossible de mettre à jour. Réessayez.')
    }
  }

  return { updateAvailable, applyUpdate }
}

// Afficher dans l'app
const { updateAvailable, applyUpdate } = useAppUpdate()
if (updateAvailable) {
  Alert.alert('Mise à jour disponible', 'Voulez-vous mettre à jour maintenant ?',
    [{ text: 'Plus tard' }, { text: 'Mettre à jour', onPress: applyUpdate }])
}
```
