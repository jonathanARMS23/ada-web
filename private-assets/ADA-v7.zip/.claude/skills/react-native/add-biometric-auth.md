# add-biometric-auth
Auth biométrique avec expo-local-authentication.

```bash
npx expo install expo-local-authentication
```

```typescript
import * as LocalAuthentication from 'expo-local-authentication'

export async function authenticateWithBiometrics(): Promise<boolean> {
  const hasHardware = await LocalAuthentication.hasHardwareAsync()
  if (!hasHardware) return false

  const isEnrolled = await LocalAuthentication.isEnrolledAsync()
  if (!isEnrolled) return false

  const result = await LocalAuthentication.authenticateAsync({
    promptMessage: 'Authentification requise',
    fallbackLabel: 'Utiliser le code PIN',
    cancelLabel: 'Annuler',
    disableDeviceFallback: false,
  })

  return result.success
}

// Hook
export function useBiometricAuth() {
  const authenticate = useCallback(async (onSuccess: () => void) => {
    const ok = await authenticateWithBiometrics()
    if (ok) onSuccess()
    else Alert.alert('Authentification échouée', 'Réessayez')
  }, [])

  return { authenticate }
}
```
