# add-offline-support
Support offline : détection, queue, sync.

## Détection réseau
```typescript
import NetInfo from '@react-native-community/netinfo'
import { useEffect, useState } from 'react'

export function useNetworkStatus() {
  const [isOnline, setIsOnline] = useState(true)

  useEffect(() => {
    return NetInfo.addEventListener(state => {
      setIsOnline(!!state.isConnected && !!state.isInternetReachable)
    })
  }, [])

  return isOnline
}
```

## Queue d'actions offline (avec MMKV)
```typescript
import { MMKV } from 'react-native-mmkv'

const storage = new MMKV()

export const offlineQueue = {
  push: (action: OfflineAction) => {
    const queue = offlineQueue.get()
    storage.set('offline_queue', JSON.stringify([...queue, action]))
  },
  get: (): OfflineAction[] => {
    const raw = storage.getString('offline_queue')
    return raw ? JSON.parse(raw) : []
  },
  clear: () => storage.delete('offline_queue'),
}

// Sync au retour en ligne
export function useSyncOnReconnect() {
  const isOnline = useNetworkStatus()
  useEffect(() => {
    if (isOnline) syncOfflineQueue()
  }, [isOnline])
}
```
