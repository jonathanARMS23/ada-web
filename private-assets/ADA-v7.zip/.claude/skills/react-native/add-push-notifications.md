# add-push-notifications
Push notifications Expo avec permissions et handlers.

## Setup
```bash
npx expo install expo-notifications expo-device
```

## Service de notifications
```typescript
import * as Notifications from 'expo-notifications'
import * as Device from 'expo-device'

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
})

export async function registerForPushNotifications(): Promise<string | null> {
  if (!Device.isDevice) return null

  const { status: existing } = await Notifications.getPermissionsAsync()
  let finalStatus = existing
  if (existing !== 'granted') {
    const { status } = await Notifications.requestPermissionsAsync()
    finalStatus = status
  }
  if (finalStatus !== 'granted') return null

  const token = (await Notifications.getExpoPushTokenAsync({
    projectId: Constants.expoConfig?.extra?.eas?.projectId,
  })).data

  // Sauvegarder le token sur le backend
  await api.users.savePushToken(token)
  return token
}
```

## Handlers
```typescript
useEffect(() => {
  const sub1 = Notifications.addNotificationReceivedListener(notif => {
    console.log('Notification reçue:', notif)
  })
  const sub2 = Notifications.addNotificationResponseReceivedListener(response => {
    const url = response.notification.request.content.data?.url
    if (url) router.push(url)  // deep link
  })
  return () => { sub1.remove(); sub2.remove() }
}, [])
```
