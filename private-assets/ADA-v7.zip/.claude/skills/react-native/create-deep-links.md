# create-deep-links
Deep links et universal links avec Expo Router.

## Configuration
```json
// app.json
{
  "expo": {
    "scheme": "myapp",
    "ios": { "associatedDomains": ["applinks:example.com"] },
    "android": { "intentFilters": [{
      "action": "VIEW",
      "data": [{ "scheme": "https", "host": "example.com" }],
      "category": ["BROWSABLE", "DEFAULT"]
    }]}
  }
}
```

## Expo Router (automatique)
```
myapp://resources/123    → app/(tabs)/resources/[id].tsx
https://example.com/resources/123  → même fichier
```

## Tester
```bash
# iOS Simulator
xcrun simctl openurl booted "myapp://resources/123"

# Android
adb shell am start -a android.intent.action.VIEW -d "myapp://resources/123"
```
