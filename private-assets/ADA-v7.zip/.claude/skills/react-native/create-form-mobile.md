# create-form-mobile
Formulaire mobile avec keyboard handling.

```typescript
import { KeyboardAvoidingView, ScrollView, Platform } from 'react-native'
import { useForm, Controller } from 'react-hook-form'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'

const schema = z.object({
  name: z.string().min(1, 'Requis').max(255),
  description: z.string().optional(),
})

export function ResourceForm({ onSuccess }: { onSuccess: () => void }) {
  const { control, handleSubmit, formState: { errors, isSubmitting } } = useForm({
    resolver: zodResolver(schema),
  })

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={{ flex: 1 }}>
      <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ padding: 16 }}>
        <Controller
          control={control} name="name"
          render={({ field: { onChange, value, onBlur } }) => (
            <TextInput
              value={value} onChangeText={onChange} onBlur={onBlur}
              placeholder="Nom de la ressource"
              style={[styles.input, errors.name && styles.inputError]}
              returnKeyType="next"
            />
          )}
        />
        {errors.name && <Text style={styles.error}>{errors.name.message}</Text>}

        <TouchableOpacity
          onPress={handleSubmit(onSuccess)}
          disabled={isSubmitting}
          style={styles.button}>
          <Text>{isSubmitting ? 'Création...' : 'Créer'}</Text>
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  )
}
```
