# create-list-screen
Liste performante FlashList avec pagination et pull-to-refresh.

## Template
```typescript
import { FlashList } from '@shopify/flash-list'
import { useInfiniteQuery } from '@tanstack/react-query'

export function ResourceListScreen() {
  const { data, fetchNextPage, hasNextPage, isFetchingNextPage, refetch } =
    useInfiniteQuery({
      queryKey: ['resources'],
      queryFn: ({ pageParam }) => api.resources.list({ cursor: pageParam }),
      getNextPageParam: (last) => last.nextCursor,
    })

  const items = data?.pages.flatMap(p => p.data) ?? []

  return (
    <FlashList
      data={items}
      renderItem={({ item }) => <ResourceItem resource={item} />}
      estimatedItemSize={80}
      onEndReached={() => hasNextPage && fetchNextPage()}
      onEndReachedThreshold={0.3}
      onRefresh={refetch}
      refreshing={false}
      ListEmptyComponent={<EmptyState />}
      ListFooterComponent={isFetchingNextPage ? <ActivityIndicator /> : null}
    />
  )
}
```
