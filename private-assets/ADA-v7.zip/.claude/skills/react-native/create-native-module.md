# create-native-module
Module natif simple avec expo-modules-core.

```typescript
// modules/my-module/index.ts
import { NativeModule, requireNativeModule } from 'expo-modules-core'

type MyModuleEvents = { onChange: (value: string) => void }

declare class MyModuleType extends NativeModule<MyModuleEvents> {
  getValue(): string
  setValue(value: string): void
}

export default requireNativeModule<MyModuleType>('MyModule')
```

```swift
// iOS — MyModule.swift
import ExpoModulesCore

public class MyModule: Module {
  public func definition() -> ModuleDefinition {
    Name("MyModule")
    Function("getValue") { return "hello" }
    Function("setValue") { (value: String) in
      self.sendEvent("onChange", ["value": value])
    }
  }
}
```

```kotlin
// Android — MyModule.kt
class MyModule : Module() {
  override fun definition() = ModuleDefinition {
    Name("MyModule")
    Function("getValue") { "hello" }
    Function("setValue") { value: String -> sendEvent("onChange", mapOf("value" to value)) }
  }
}
```
