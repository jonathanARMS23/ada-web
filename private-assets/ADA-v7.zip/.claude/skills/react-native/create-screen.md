# create-screen
Screen Expo Router avec navigation, params, loading, error.

## Structure
```typescript
// app/(tabs)/resources/[id].tsx
import { Stack, useLocalSearchParams } from 'expo-router'
import { useQuery } from '@tanstack/react-query'

export default function ResourceScreen() {
  const { id } = useLocalSearchParams<{ id: string }>()
  const { data, isLoading, error } = useQuery({
    queryKey: ['resource', id],
    queryFn: () => api.resources.get(id),
  })

  if (isLoading) return <LoadingSkeleton />
  if (error) return <ErrorState error={error} onRetry={refetch} />
  if (!data) return <NotFound />

  return (
    <>
      <Stack.Screen options={{ title: data.name }} />
      <ScrollView contentContainerStyle={styles.container}>
        {/* contenu */}
      </ScrollView>
    </>
  )
}
```
