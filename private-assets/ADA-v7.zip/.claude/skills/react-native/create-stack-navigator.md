# create-stack-navigator
Stack navigation avec headers custom et animations.

```typescript
// app/(tabs)/resources/_layout.tsx
import { Stack } from 'expo-router'

export default function ResourcesLayout() {
  return (
    <Stack screenOptions={{
      headerStyle: { backgroundColor: '#fff' },
      headerTintColor: '#0070f3',
      animation: 'slide_from_right',
    }}>
      <Stack.Screen name="index" options={{ title: 'Ressources' }} />
      <Stack.Screen name="[id]" options={{ title: 'Détail', presentation: 'card' }} />
      <Stack.Screen name="create" options={{ title: 'Créer', presentation: 'modal' }} />
    </Stack>
  )
}

// Naviguer vers le détail
import { router } from 'expo-router'
router.push(`/resources/${resource.id}`)

// Modale
router.push('/resources/create')
```
