# create-tab-navigator
Navigation tabs avec Expo Router et badges.

```typescript
// app/(tabs)/_layout.tsx
import { Tabs } from 'expo-router'
import { Home, Box, Settings, Bell } from 'lucide-react-native'
import { useNotificationCount } from '@/hooks/useNotifications'

export default function TabLayout() {
  const notifCount = useNotificationCount()

  return (
    <Tabs screenOptions={{
      tabBarActiveTintColor: '#0070f3',
      tabBarInactiveTintColor: '#6b7280',
      tabBarStyle: { paddingBottom: 8, height: 60 },
    }}>
      <Tabs.Screen name="index"
        options={{ title: 'Accueil', tabBarIcon: ({ color }) => <Home size={24} color={color} /> }} />
      <Tabs.Screen name="resources"
        options={{ title: 'Ressources', tabBarIcon: ({ color }) => <Box size={24} color={color} /> }} />
      <Tabs.Screen name="notifications"
        options={{
          title: 'Alertes',
          tabBarIcon: ({ color }) => <Bell size={24} color={color} />,
          tabBarBadge: notifCount > 0 ? notifCount : undefined,
        }} />
      <Tabs.Screen name="settings"
        options={{ title: 'Réglages', tabBarIcon: ({ color }) => <Settings size={24} color={color} /> }} />
    </Tabs>
  )
}
```
