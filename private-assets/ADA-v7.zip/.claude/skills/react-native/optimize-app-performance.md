# optimize-app-performance
Profiling React Native : JS thread, bridge, renders.

## Diagnostiquer avec Flipper / React DevTools
```
Problèmes courants :
- JS thread bloqué > 16ms → UI freeze
- Too many re-renders → memo/useCallback
- Liste non virtualisée → FlatList/FlashList
- Images non optimisées → expo-image
```

## Fixes courants
```typescript
// ❌ Rendu non virtualisé
<ScrollView>
  {items.map(item => <Item key={item.id} data={item} />)}
</ScrollView>

// ✅ FlashList virtualisé (10x plus rapide que FlatList)
<FlashList
  data={items}
  renderItem={({ item }) => <Item data={item} />}
  estimatedItemSize={80}
  keyExtractor={item => item.id}
/>

// ❌ Image React Native basique
<Image source={{ uri: url }} />

// ✅ expo-image avec cache
import { Image } from 'expo-image'
<Image source={url} cachePolicy="memory-disk" contentFit="cover" />
```

## Hermes (moteur JS optimisé)
```json
// app.json
{ "expo": { "jsEngine": "hermes" } }
```
