# generate-review-checklist
Checklist adaptée au type de changement.

## Détection du type
- Contient `auth/` ou `guard` → activer checklist auth
- Contient `.sql` ou `migration` → activer checklist DB
- Contient `upload` ou `file` → activer checklist upload
- Contient `payment` → activer checklist paiement

## Checklists par type

### Feature CRUD standard
- [ ] Guard sur tous les endpoints
- [ ] Filtre workspace dans get_queryset/findAll
- [ ] DTOs validés
- [ ] Tests unitaires + intégration
- [ ] Pas de N+1

### Migration DB
- [ ] Migration réversible (down inclus)
- [ ] Index ajoutés
- [ ] RLS policies mises à jour
- [ ] Testée sur staging

### Upload fichier
- [ ] Validation MIME type whitelist
- [ ] Taille maximale configurée
- [ ] Stockage hors du répertoire public
- [ ] Nom de fichier sanitisé
