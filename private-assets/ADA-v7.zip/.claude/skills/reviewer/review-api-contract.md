# review-api-contract
Review contrat API : cohérence, versioning, breaking changes.

## Checklist
```
□ Routes en kebab-case pluriel (/user-profiles, pas /userProfile)
□ Versioning explicite (/api/v1/)
□ Méthodes HTTP correctes (GET=lecture, POST=création, PUT=remplacement, PATCH=partiel)
□ Status codes cohérents (201 création, 204 suppression, 422 validation)
□ Format d'erreur uniforme { error: { code, message, details } }
□ Pagination cohérente sur tous les endpoints de liste
□ Pas d'IDs séquentiels dans les URLs (→ UUIDs)
□ Auth requise documentée (Bearer JWT)
□ Breaking changes identifiés et versionnés
□ Réponses nullables documentées
```

## Breaking changes à signaler
- Suppression d'un champ de réponse
- Changement de type d'un champ
- Changement de nom d'un paramètre
- Changement de comportement d'un endpoint existant
