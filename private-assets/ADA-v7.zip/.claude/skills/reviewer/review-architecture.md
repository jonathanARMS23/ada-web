# review-architecture
Review architecture : couplage, responsabilités, évolutivité.

## Checklist
```
□ Chaque module/service a une responsabilité unique (SRP)
□ Pas de logique métier dans les controllers/views
□ Pas de couplage direct entre modules non liés
□ Les interfaces définissent les contrats (pas les implémentations)
□ Les dépendances vont dans un seul sens (pas de cycles)
□ Pas de God object (classe > 500 lignes avec trop de responsabilités)
□ Les erreurs sont traitées à la bonne couche
□ Pas de business logic dans les migrations DB
```

## Format
```
## Architecture Review

### Structure
[Observations sur l'organisation du code]

### Problèmes identifiés
[SRP violations, couplage, anti-patterns]

### Recommandations
[Refactoring suggéré avec justification]
```
