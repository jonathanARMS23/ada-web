# review-database-schema
Review schéma DB : normalisation, index, RLS.

## Checklist
```
□ PK en UUID (pas bigserial exposé dans l'API)
□ created_at + updated_at sur toutes les tables métier
□ workspace_id sur toutes les tables multi-tenant
□ ON DELETE CASCADE sur les FK enfants
□ NOT NULL sur les colonnes obligatoires (pas de null implicite)
□ Index sur toutes les FK
□ Index sur les colonnes de filtre fréquent
□ CREATE INDEX CONCURRENTLY en migration (pas CREATE INDEX)
□ RLS activé + policies testées
□ Pas de données sensibles en clair (tokens, passwords)
□ Soft delete cohérent (deleted_at partout ou nulle part)
```
