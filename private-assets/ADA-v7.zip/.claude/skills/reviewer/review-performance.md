# review-performance
Review perf : N+1, index, bundle, re-renders.

## Checklist
```
Backend :
□ Pas de requête dans une boucle (N+1)
□ select_related/prefetch_related ou include Prisma sur les relations
□ Pas de SELECT * sur grandes tables
□ LIMIT sur toutes les requêtes de liste
□ Index sur colonnes filtrées/triées

Frontend :
□ Pas d'import de librairie entière (lodash, date-fns)
□ Dynamic import sur composants lourds (graphes, éditeurs)
□ memo/useMemo/useCallback sur composants coûteux
□ Pas de création d'objet/array dans le render (→ useMemo)
□ Images avec next/image ou optimisées
```

## Format
```
## Performance Review

🔴 CRITIQUE (> 500ms impact)
  [fichier:ligne] — [problème] — [fix]

🟡 IMPORTANT (> 100ms impact)
  [liste]

✅ Optimisations déjà présentes
  [liste]
```
