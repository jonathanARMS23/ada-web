# review-pr
Review complète d'une PR avec verdict.

## Ordre de priorité
1. Sécurité (bloquant si trouvé)
2. Correctness (bugs, edge cases)
3. Performance (N+1, index, bundle)
4. Architecture (couplage, responsabilités)
5. Conventions (nommage, style)

## Format de sortie
```
## Code Review — PR #<N> : <titre>

### Verdict : ✅ Approuvé | ⚠️ Réserves | ❌ Bloquant

### 🔴 Bloquant
**Fichier :** `src/...ts:L45`
**Problème :** [description précise]
**Fix :**
```code```

### 🟡 Réserves (non bloquant)
- [liste]

### ✅ Points positifs
- [liste]

### 📋 Checklist
- [ ] Tests présents et pertinents
- [ ] Pas de secrets dans le code
- [ ] Types stricts (pas de `any`)
- [ ] RLS ou guard sur les endpoints
- [ ] Pas de N+1 évident
```

## Règle absolue
Jamais approuver si : secrets exposés, endpoint sans auth, injection SQL possible.
