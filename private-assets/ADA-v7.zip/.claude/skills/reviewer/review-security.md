# review-security
Audit sécurité ciblé sur un diff ou un fichier.

## Checklist systématique
```
□ Tous les endpoints ont un guard ou permission
□ Pas de données d'autres workspaces accessibles (IDOR)
□ Inputs validés côté serveur (pas seulement client)
□ Pas de SQL brut sans paramétrage
□ Secrets dans .env, pas dans le code
□ JWT : expiry vérifié, signature vérifiée
□ Rate limiting sur les endpoints publics
□ CORS restrictif (pas de *)
□ Headers sécurité présents (Helmet)
□ Upload : validation MIME + taille + virus scan
```

## Format de sortie
```
## Security Review

🔴 CRITIQUE — À corriger avant merge
🟡 IMPORTANT — À corriger dans le sprint
🟢 INFO — Amélioration future
```
