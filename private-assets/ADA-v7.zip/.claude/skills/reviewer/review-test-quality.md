# review-test-quality
Évaluer la vraie qualité des tests (pas juste le coverage).

## Questions à se poser
1. Les tests testent-ils le comportement ou l'implémentation ?
2. Les mocks sont-ils trop permissifs ? (mockResolvedValue sans vérifier les args)
3. Y a-t-il des tests qui passent même si la logique est cassée ?
4. Les edge cases sont-ils couverts ?
5. Les erreurs sont-elles testées ?

## Signaux d'alerte
```typescript
// ❌ Test qui ne teste rien
it('should work', () => {
  expect(true).toBe(true)
})

// ❌ Mock trop permissif
repository.findById.mockResolvedValue(anything)
// Mieux :
repository.findById.mockResolvedValue({ id: 'uuid', name: 'Test' })
expect(repository.findById).toHaveBeenCalledWith('uuid')

// ❌ Pas d'assertion sur le résultat
await service.create(dto)
// Mieux :
const result = await service.create(dto)
expect(result.id).toBeDefined()
expect(result.name).toBe(dto.name)
```
