# ast-static-analysis
ast.parse avant exécution, visitor patterns, détection os/sys/eval/exec/import.

```python
import ast

FORBIDDEN_NODES = {
    ast.Import, ast.ImportFrom,    # aucun import
}
FORBIDDEN_NAMES = {
    "os", "sys", "subprocess", "eval", "exec", "open", "compile",
    "__import__", "getattr", "setattr", "delattr", "__builtins__",
    "ctypes", "socket", "pickle", "marshal", "shelve",
}

class SecurityVisitor(ast.NodeVisitor):
    def __init__(self):
        self.violations: list[str] = []

    def visit_Import(self, node):
        for alias in node.names:
            self.violations.append(f"Import interdit : {alias.name}")
        self.generic_visit(node)

    def visit_ImportFrom(self, node):
        self.violations.append(f"Import from interdit : {node.module}")
        self.generic_visit(node)

    def visit_Name(self, node):
        if node.id in FORBIDDEN_NAMES:
            self.violations.append(f"Nom interdit : {node.id}")
        self.generic_visit(node)

    def visit_Call(self, node):
        if isinstance(node.func, ast.Name) and node.func.id in {"eval", "exec", "compile"}:
            self.violations.append(f"Appel interdit : {node.func.id}()")
        self.generic_visit(node)

def analyze_code(code: str) -> list[str]:
    """Retourne la liste des violations. Vide = code accepté."""
    try:
        tree = ast.parse(code)
    except SyntaxError as e:
        return [f"SyntaxError : {e}"]
    
    visitor = SecurityVisitor()
    visitor.visit(tree)
    return visitor.violations
```
