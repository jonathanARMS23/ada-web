# docker-ephemeral-sandbox
Conteneur éphémère par exécution, gVisor runtime, réseau désactivé, cleanup.

```python
import docker, asyncio, uuid

client = docker.from_env()

async def run_in_sandbox(code: str, timeout: int = 10) -> dict:
    container_id = f"sandbox-{uuid.uuid4().hex[:8]}"
    
    try:
        container = client.containers.run(
            image="python:3.11-slim",
            command=["python3", "-c", code],
            name=container_id,
            detach=True,
            network_disabled=True,          # pas de réseau
            read_only=True,                 # filesystem read-only
            runtime="runsc",                # gVisor si disponible
            mem_limit="64m",                # 64 MB RAM max
            cpu_period=100000,
            cpu_quota=50000,                # 50% d'un CPU
            security_opt=["no-new-privileges"],
        )
        
        try:
            result = await asyncio.wait_for(
                asyncio.to_thread(container.wait),
                timeout=timeout
            )
            stdout = container.logs(stdout=True, stderr=False).decode()
            stderr = container.logs(stdout=False, stderr=True).decode()
            return {"stdout": stdout, "stderr": stderr, "exit_code": result["StatusCode"]}
        except asyncio.TimeoutError:
            container.kill()
            return {"error": "timeout", "stdout": "", "stderr": ""}
    finally:
        try:
            container.remove(force=True)
        except Exception:
            pass
```
