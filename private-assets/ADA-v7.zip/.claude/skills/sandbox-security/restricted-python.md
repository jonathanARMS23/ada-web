# restricted-python
safe_globals, safe_builtins, write restrictions, whitelisting modules.

```python
from RestrictedPython import compile_restricted, safe_globals, safe_builtins, limited_builtins

def execute_restricted(code: str, extra_globals: dict = None) -> dict:
    compiled = compile_restricted(code, filename="<sandbox>", mode="exec")
    if compiled is None:
        raise ValueError("Code refusé par RestrictedPython")
    
    local_vars = {}
    globs = {
        **safe_globals,
        "__builtins__": safe_builtins,  # builtins sécurisés
        "_getiter_": iter,              # for loops autorisées
        "_getattr_": getattr,           # accès attributs
        "_write_": lambda x: x,         # écriture sur objets
        # Modules autorisés explicitement
        "json": __import__("json"),
        "math": __import__("math"),
        "re": __import__("re"),
    }
    if extra_globals:
        globs.update(extra_globals)
    
    exec(compiled, globs, local_vars)
    return local_vars
```
