# add-input-sanitization
Sanitization inputs : XSS, HTML injection, file upload.

## NestJS — class-validator + sanitize-html
```typescript
import { Transform } from 'class-transformer'
import sanitizeHtml from 'sanitize-html'

export class CreateResourceDto {
  @IsString() @MinLength(1) @MaxLength(255)
  @Transform(({ value }) => value?.trim())  // trim automatique
  name: string

  @IsOptional() @IsString()
  @Transform(({ value }) => sanitizeHtml(value, {
    allowedTags: ['b', 'i', 'em', 'strong', 'p', 'br'],
    allowedAttributes: {},
  }))
  description?: string  // HTML limité autorisé

  // Dans main.ts : app.useGlobalPipes(new ValidationPipe({ transform: true }))
}
```

## DRF — bleach
```python
import bleach

class ResourceSerializer(serializers.ModelSerializer):
    def validate_description(self, value):
        return bleach.clean(value, tags=['b', 'i', 'em', 'strong', 'p'], strip=True)

    def validate_name(self, value):
        return value.strip()  # trim
```
