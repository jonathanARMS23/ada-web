# audit-api-security
Audit API : rate limiting, CORS, headers, exposition données.

## Checklist
```
□ Rate limiting sur tous les endpoints publics
□ Rate limiting strict sur /login, /register, /reset-password
□ CORS : origines whitelistées (pas de *)
□ Helmet.js ou équivalent configuré
□ Pas de stack trace dans les réponses d'erreur
□ Pas de version serveur dans les headers (X-Powered-By supprimé)
□ Content-Type validé sur les endpoints POST/PUT
□ Pagination obligatoire sur les endpoints de liste
□ Pas de données sensibles dans les query params (→ logs serveur)
□ HTTPS forcé (redirect 80→443)
```

## Headers à vérifier
```bash
curl -I https://api.example.com/health | grep -E "X-Powered-By|Server:|X-Frame|X-Content|Strict-Transport"
# X-Powered-By: Express → SUPPRIMER
# Server: nginx/1.x → masquer la version
```
