# audit-authentication
Audit complet du système d'authentification.

## Checklist
```
JWT :
□ Algorithme : RS256 ou ES256 (jamais HS256 en production multi-service)
□ Expiry : access token ≤ 15min, refresh token ≤ 7j
□ Signature vérifiée sur chaque requête (pas de trust implicite)
□ Refresh token rotation activée
□ Invalidation sur logout (blacklist Redis ou version dans DB)

Sessions :
□ httpOnly + Secure + SameSite=Strict sur les cookies
□ Régénération d'ID après login
□ Timeout inactivité configuré

Mots de passe :
□ bcrypt avec cost ≥ 12 (ou argon2id)
□ Politique de complexité enforced côté serveur
□ Rate limiting sur /login (max 5 tentatives/15min)
□ Pas de messages d'erreur différenciant email/password
```
