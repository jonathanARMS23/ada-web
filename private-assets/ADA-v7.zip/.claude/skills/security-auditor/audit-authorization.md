# audit-authorization
Audit autorisation : IDOR, privilege escalation.

## Test IDOR systématique
```bash
# 1. Créer une ressource avec user A → récupérer l'ID
# 2. Requêter avec user B → doit retourner 403/404

# Pattern à vérifier dans le code :
grep -r "findOne\|findById\|getById" src/ --include="*.ts" | grep -v "workspaceId\|userId"
# Chaque findOne sans filtre workspace/user est suspect
```

## Checklist
```
□ Chaque endpoint vérifie l'ownership ou le workspace
□ Les IDs de DB ne sont pas séquentiels (uuid obligatoire)
□ Les actions admin vérifient le rôle côté serveur
□ Pas de paramètre user_id accepté depuis le client
□ Les tokens ne contiennent pas de données sensibles
□ Les erreurs ne révèlent pas l'existence d'une ressource (403 vs 404)
```
