# audit-dependencies
Scan CVE dépendances avec priorisation.

## Commandes
```bash
# npm
npm audit --json | python3 -c "
import json, sys
data = json.load(sys.stdin)
vulns = data.get('vulnerabilities', {})
critical = {k:v for k,v in vulns.items() if v['severity'] in ['critical','high']}
for name, info in critical.items():
    print(f'[{info[\"severity\"].upper()}] {name}: {info.get(\"fixAvailable\", \"no fix\")}')
"

# Python
pip-audit --json | python3 -c "import json,sys; [print(f'[{v[\"fix_versions\"]}] {v[\"name\"]} {v[\"version\"]}') for v in json.load(sys.stdin)['dependencies'] if v['vulns']]"

# Mise à jour safe
npm audit fix --only=prod  # uniquement prod, pas breaking
```

## Priorisation
- CRITICAL + exploitable en remote → fix immédiat
- HIGH → fix dans le sprint
- MEDIUM → planifier
- LOW → backlog
