# audit-injection
Détection injections SQL, NoSQL, command, SSTI.

## SQL Injection
```bash
# Grep pour raw SQL sans paramétrage
grep -rn "executeRaw\|queryRaw\|raw(" src/ --include="*.ts" | grep -v "executeRawUnsafe"
grep -rn "cursor.execute\|raw_query\|extra(" . --include="*.py"
# Chercher les f-strings ou concaténations dans les requêtes
grep -rn 'f".*SELECT\|f".*INSERT\|f".*UPDATE' . --include="*.py"
```

## Command Injection
```bash
grep -rn "exec(\|execSync(\|spawn(" src/ --include="*.ts"
grep -rn "os.system\|subprocess.call\|subprocess.run" . --include="*.py"
# Vérifier que les inputs utilisateur ne sont pas passés directement
```

## Fixes
```typescript
// ❌ SQL injection
await prisma.$executeRaw(`SELECT * FROM users WHERE email = '${email}'`)
// ✅ Paramétré
await prisma.$executeRaw`SELECT * FROM users WHERE email = ${email}`

// ❌ Command injection
exec(`convert ${userInput} output.pdf`)
// ✅ Arguments séparés
execFile('convert', [sanitizedInput, 'output.pdf'])
```
