# audit-rls-supabase
Audit policies RLS Supabase : gaps et bypass potentiels.

## Tests d'isolation
```sql
-- Tester qu'un user ne voit pas les données d'un autre workspace
SET LOCAL role TO authenticated;
SET LOCAL "request.jwt.claims" TO '{"sub": "user-a-uuid", "workspace_id": "ws-a-uuid"}';

-- Ce SELECT ne doit retourner QUE les ressources de ws-a
SELECT COUNT(*) FROM resources;  -- doit correspondre aux ressources de ws-a uniquement

-- Tentative d'accès cross-workspace (doit retourner 0)
SELECT * FROM resources WHERE workspace_id = 'ws-b-uuid';  -- doit retourner 0 lignes
```

## Checklist RLS
```
□ RLS activé sur TOUTES les tables métier (pas juste certaines)
□ Policy SELECT filtre par workspace_id
□ Policy INSERT WITH CHECK (pas de workspace_id arbitraire)
□ Policy UPDATE : USING + WITH CHECK
□ Policy DELETE : USING pour vérifier ownership
□ service_role policy séparée pour le backend
□ anon role ne peut accéder à rien (sauf tables publiques explicites)
□ Pas de bypass via les fonctions SQL (SECURITY DEFINER mal utilisé)
```
