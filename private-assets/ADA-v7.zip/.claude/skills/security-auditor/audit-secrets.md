# audit-secrets
Détection de secrets dans le code et l'historique git.

## Scan du code actuel
```bash
# Patterns de secrets communs
grep -rn "password\s*=\s*['\"][^'\"]\|secret\s*=\s*['\"][^'\"]\|api_key\s*=\s*['\"][^'\"]" \
  --include="*.ts" --include="*.py" --include="*.js" \
  --exclude-dir=node_modules --exclude-dir=.git .

# Tokens connus
grep -rn "ghp_\|sk_live_\|sk_test_\|AKIA\|eyJhb" \
  --include="*.ts" --include="*.py" --include="*.env" .
```

## Scan de l'historique git
```bash
# Installer truffleHog
pip install trufflehog
trufflehog git file://. --only-verified

# Ou git-secrets
git log --all --full-history -- "*.env" | head -20
git log -S "password" --all --oneline | head -20
```

## En cas de secret trouvé
1. Invalider immédiatement le secret (API key, token)
2. Supprimer du code + commit
3. Nettoyer l'historique git : `git filter-branch` ou BFG Repo Cleaner
4. Forcer le push sur toutes les branches
5. Auditer les accès avec l'ancien secret
