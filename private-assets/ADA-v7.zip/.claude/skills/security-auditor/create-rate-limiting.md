# create-rate-limiting
Rate limiting par IP, user, endpoint avec Redis.

## NestJS avec Redis
```typescript
// Rate limiting global
ThrottlerModule.forRootAsync({
  imports: [ConfigModule],
  inject: [ConfigService],
  useFactory: (config: ConfigService) => ({
    throttlers: [
      { name: 'short', ttl: 1000, limit: 10 },    // 10 req/s
      { name: 'medium', ttl: 60000, limit: 100 },  // 100 req/min
      { name: 'long', ttl: 3600000, limit: 1000 }, // 1000 req/h
    ],
    storage: new ThrottlerStorageRedisService(
      new Redis(config.get('REDIS_URL'))
    ),
  }),
})

// Strict sur les endpoints sensibles
@Throttle({ short: { limit: 3, ttl: 60000 } }) // 3/min
@Post('auth/login')
async login() {}
```

## DRF
```python
REST_FRAMEWORK = {
    'DEFAULT_THROTTLE_CLASSES': [
        'rest_framework.throttling.AnonRateThrottle',
        'rest_framework.throttling.UserRateThrottle',
    ],
    'DEFAULT_THROTTLE_RATES': {
        'anon': '20/hour',
        'user': '1000/hour',
        'login': '5/min',
    }
}
```
