# Security Pro — Micro-lessons

## L1 — OWASP Top 10 : A01-A05

**A01 — Broken Access Control** : vérifier les permissions à chaque couche (Controller, Service, DB). Ne jamais se fier au frontend pour filtrer les données. Implémenter ABAC (attribute-based) plutôt que RBAC simple pour les SaaS multi-tenant.

```typescript
// Mauvais : trust the client
async getPost(postId: string) { return prisma.post.findUnique({ where: { id: postId } }) }

// Bon : scope by workspace
async getPost(postId: string, userId: string) {
  const post = await prisma.post.findFirst({ where: { id: postId, workspace: { members: { some: { userId } } } } })
  if (!post) throw new NotFoundException()
  return post
}
```

**A02 — Cryptographic Failures** : bcrypt (cost≥12) pour les mots de passe, AES-256-GCM pour les données sensibles au repos, TLS 1.2+ minimum. Ne jamais stocker les secrets en clair.

**A03 — Injection** : toujours utiliser des requêtes paramétrées (Prisma ORM couvre cela). Pour les requêtes brutes : `prisma.$queryRaw\`SELECT * FROM users WHERE id = ${Prisma.sql\`${id}\`}\``.

**A04 — Insecure Design** : rate limiting sur les endpoints auth (ex: 5 tentatives/15min), tokens à usage unique pour reset password, validation serveur de toutes les entrées.

**A05 — Security Misconfiguration** : désactiver l'introspection GraphQL en prod, supprimer les headers X-Powered-By, configurer CORS strictement.

## L2 — OWASP A06-A10

**A06 — Vulnerable Components** : `npm audit` dans CI, Dependabot activé, `npm audit --audit-level=high` bloque le build.

**A07 — Auth Failures** : session fixation, timing attacks sur la comparaison de tokens. Utiliser `crypto.timingSafeEqual` pour comparer les tokens.

```typescript
import { timingSafeEqual } from 'crypto'
function safeCompare(a: string, b: string): boolean {
  const bufA = Buffer.from(a.padEnd(64))
  const bufB = Buffer.from(b.padEnd(64))
  return timingSafeEqual(bufA, bufB) && a.length === b.length
}
```

**A08 — Software Integrity** : vérifier les checksums des dépendances critiques, utiliser `npm ci` (pas `npm install`) en CI pour reproducibilité.

**A09 — Logging Failures** : logger les tentatives d'auth échouées, les changements de permission, les accès aux données sensibles. Ne jamais logger les mots de passe, tokens ou PII bruts.

**A10 — SSRF** : valider toutes les URLs fournies par l'utilisateur, bloquer les requêtes vers les IP privées (169.254.0.0/16, 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16).

## L3 — RLS Supabase : Row Level Security

```sql
-- Activer RLS sur toutes les tables métier
ALTER TABLE posts ENABLE ROW LEVEL SECURITY;

-- Policy : un user ne voit que les posts de son workspace
CREATE POLICY "workspace_isolation" ON posts
  USING (workspace_id IN (
    SELECT workspace_id FROM workspace_members WHERE user_id = auth.uid()
  ));

-- Policy INSERT : l'utilisateur peut seulement créer dans ses workspaces
CREATE POLICY "workspace_insert" ON posts
  FOR INSERT WITH CHECK (
    workspace_id IN (
      SELECT workspace_id FROM workspace_members WHERE user_id = auth.uid()
    )
  );

-- Ne jamais bypasser avec service_role en frontend
-- service_role contourne toutes les policies — réserver au backend uniquement
```

Règle d'or : tester les policies avec `SET ROLE authenticated; SET request.jwt.claims = '{"sub": "user-id"}';` puis tenter des SELECT/INSERT cross-workspace.

## L4 — JWT : pièges et bonnes pratiques

```typescript
// MAUVAIS — algorithm confusion attack
jwt.verify(token, publicKey) // si l'attaquant envoie alg:HS256, il peut forger avec publicKey

// BON — toujours spécifier l'algorithme
jwt.verify(token, publicKey, { algorithms: ['RS256'] })

// MAUVAIS — payload non chiffré exposé
const token = jwt.sign({ userId, email, role }, secret)

// BON — payload minimal, claims standards
const token = jwt.sign(
  { sub: userId, iss: 'your-api', aud: 'your-app', jti: crypto.randomUUID() },
  secret,
  { expiresIn: '15m', algorithm: 'HS256' }
)

// Rotation des refresh tokens
// À chaque usage du refresh token : invalider l'ancien, émettre un nouveau
// Stocker le hash (SHA256) du refresh token en DB, pas le token brut
```

Pièges : `exp` absent = token éternel, `alg:none` accepté si non vérifié, secret partagé entre services = compromission totale.

## L5 — CSP et SSRF

**Content Security Policy :**

```typescript
// helmet.js dans NestJS/Express
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'nonce-{RANDOM}'"],  // nonce par requête, jamais 'unsafe-inline'
      styleSrc: ["'self'", "'unsafe-inline'"],      // acceptable si pas de XSS vectors
      imgSrc: ["'self'", 'data:', 'https:'],
      connectSrc: ["'self'", 'https://api.votre-domaine.com'],
      frameAncestors: ["'none'"],  // anti-clickjacking
      upgradeInsecureRequests: [],
    },
  },
  hsts: { maxAge: 31536000, includeSubDomains: true, preload: true },
}))
```

**SSRF — Server-Side Request Forgery :**

```typescript
const BLOCKED_RANGES = [
  /^127\./, /^10\./, /^172\.(1[6-9]|2\d|3[01])\./, /^192\.168\./,
  /^169\.254\./, /^::1$/, /^fc00:/, /^fe80:/,
]

function isSafeUrl(url: string): boolean {
  try {
    const parsed = new URL(url)
    if (parsed.protocol !== 'https:') return false
    return !BLOCKED_RANGES.some(re => re.test(parsed.hostname))
  } catch { return false }
}

// Toujours résoudre le DNS et revérifier l'IP finale (DNS rebinding)
```

SSRF permet d'accéder aux métadonnées cloud (AWS: 169.254.169.254), services internes, bases de données. Valider ET rebloquer après résolution DNS.
