# add-app-store-submission
Checklist App Store : privacy manifest, screenshots, metadata.

## Privacy Manifest (iOS 17+ — obligatoire)
```xml
<!-- PrivacyInfo.xcprivacy -->
<dict>
    <key>NSPrivacyTracking</key><false/>
    <key>NSPrivacyCollectedDataTypes</key>
    <array>
        <dict>
            <key>NSPrivacyCollectedDataType</key>
            <string>NSPrivacyCollectedDataTypeEmailAddress</string>
            <key>NSPrivacyCollectedDataTypeLinked</key><true/>
            <key>NSPrivacyCollectedDataTypePurposes</key>
            <array><string>NSPrivacyCollectedDataTypePurposeAppFunctionality</string></array>
        </dict>
    </array>
    <key>NSPrivacyAccessedAPITypes</key>
    <array>
        <dict>
            <key>NSPrivacyAccessedAPIType</key>
            <string>NSPrivacyAccessedAPICategoryUserDefaults</string>
            <key>NSPrivacyAccessedAPITypeReasons</key>
            <array><string>CA92.1</string></array>
        </dict>
    </array>
</dict>
```

## Checklist pré-soumission
```
□ Version + build number incrémentés
□ Icône 1024x1024 (pas de transparence)
□ Screenshots : iPhone 6.7", iPad 12.9" (si universel)
□ Description < 4000 chars, mots-clés < 100 chars
□ Privacy policy URL valide et accessible
□ Privacy Manifest présent
□ TestFlight beta testé sur devices réels
□ Aucun appel d'API en dur (sandbox vs prod)
□ App Review Information remplie
```
