# add-swiftdata-model
Modèle SwiftData avec relations et migrations.

```swift
import SwiftData

@Model
final class Resource {
    @Attribute(.unique) var id: String
    var name: String
    var status: String
    var createdAt: Date

    @Relationship(deleteRule: .cascade)
    var lineItems: [LineItem] = []

    init(id: String, name: String, status: String = "draft") {
        self.id = id
        self.name = name
        self.status = status
        self.createdAt = .now
    }
}

@Model
final class LineItem {
    var id: String
    var quantity: Int
    var resource: Resource?

    init(id: String, quantity: Int) {
        self.id = id
        self.quantity = quantity
    }
}

// Configurer dans l'App
@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
            .modelContainer(for: [Resource.self, LineItem.self])
    }
}

// Queries
@Query(sort: \Resource.createdAt, order: .reverse) var resources: [Resource]
@Query(filter: #Predicate { $0.status == "active" }) var activeResources: [Resource]
```
