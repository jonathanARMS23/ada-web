# create-async-viewmodel
ViewModel async/await avec @MainActor et error handling.

```swift
@MainActor
final class ResourceViewModel: ObservableObject {
    @Published private(set) var resources: [Resource] = []
    @Published private(set) var isLoading = false
    @Published private(set) var error: String?

    private let repository: ResourceRepository

    init(repository: ResourceRepository = DIContainer.shared.resourceRepository) {
        self.repository = repository
    }

    func loadResources() async {
        isLoading = true
        error = nil
        do {
            resources = try await repository.getAll()
        } catch let apiError as APIError {
            error = apiError.localizedDescription
        } catch {
            self.error = "Erreur inattendue"
        }
        isLoading = false
    }

    func deleteResource(id: String) async {
        do {
            try await repository.delete(id: id)
            resources.removeAll { $0.id == id }
        } catch {
            self.error = "Suppression impossible"
        }
    }
}
```
