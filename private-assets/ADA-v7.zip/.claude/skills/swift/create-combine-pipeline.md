# create-combine-pipeline
Pipeline Combine pour data flow réactif.

```swift
import Combine

final class SearchViewModel: ObservableObject {
    @Published var searchQuery = ""
    @Published private(set) var results: [Resource] = []
    @Published private(set) var isLoading = false

    private var cancellables = Set<AnyCancellable>()
    private let api: APIClient

    init(api: APIClient = .shared) {
        self.api = api
        setupSearch()
    }

    private func setupSearch() {
        $searchQuery
            .debounce(for: .milliseconds(300), scheduler: RunLoop.main)
            .removeDuplicates()
            .filter { $0.count >= 2 }
            .handleEvents(receiveOutput: { [weak self] _ in self?.isLoading = true })
            .flatMap { [weak self] query -> AnyPublisher<[Resource], Never> in
                guard let self else { return Just([]).eraseToAnyPublisher() }
                return Future { promise in
                    Task { promise(.success((try? await self.api.search(query: query)) ?? [])) }
                }.eraseToAnyPublisher()
            }
            .receive(on: RunLoop.main)
            .sink { [weak self] results in
                self?.results = results
                self?.isLoading = false
            }
            .store(in: &cancellables)
    }
}
```
