# create-feature-module
Module feature iOS MVVM complet.

## Structure
```
Features/<n>/
  Domain/
    Models/<n>.swift
    Repository/<n>Repository.swift   # Protocol
    UseCases/Get<n>UseCase.swift
  Data/
    Repository/<n>RepositoryImpl.swift
    Remote/<n>APIClient.swift
    Local/<n>Store.swift
  Presentation/
    <n>ViewModel.swift
    <n>View.swift
    <n>UiState.swift
```

## ViewModel async/await
```swift
@MainActor
final class ResourceViewModel: ObservableObject {
    @Published var uiState: ResourceUiState = .loading
    private let getResources: GetResourcesUseCase

    init(getResources: GetResourcesUseCase) {
        self.getResources = getResources
    }

    func loadResources() async {
        uiState = .loading
        do {
            let resources = try await getResources.execute()
            uiState = .success(resources)
        } catch {
            uiState = .error(error.localizedDescription)
        }
    }
}

enum ResourceUiState {
    case loading
    case success([Resource])
    case error(String)
}
```
