# create-swiftui-view
View SwiftUI avec états, bindings, previews.

## Template
```swift
struct ResourceListView: View {
    @StateObject private var viewModel = ResourceViewModel(
        getResources: DIContainer.shared.getResourcesUseCase
    )

    var body: some View {
        Group {
            switch viewModel.uiState {
            case .loading:
                ProgressView()
            case .success(let resources):
                List(resources, id: \.id) { resource in
                    ResourceRowView(resource: resource)
                }
                .refreshable { await viewModel.loadResources() }
            case .error(let message):
                ErrorView(message: message) {
                    Task { await viewModel.loadResources() }
                }
            }
        }
        .navigationTitle("Ressources")
        .task { await viewModel.loadResources() }
    }
}

// Previews multiples
#Preview("Loading") {
    ResourceListView()
}
#Preview("Success") {
    ResourceListView()
}
```
