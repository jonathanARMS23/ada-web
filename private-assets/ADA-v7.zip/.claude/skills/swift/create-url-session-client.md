# create-url-session-client
Client réseau URLSession avec auth, retry et error handling.

```swift
enum APIError: LocalizedError {
    case unauthorized, notFound, serverError(Int), networkError(Error), decodingError(Error)
    var errorDescription: String? {
        switch self {
        case .unauthorized: return "Session expirée"
        case .notFound: return "Ressource introuvable"
        case .serverError(let code): return "Erreur serveur (\(code))"
        case .networkError: return "Problème de connexion"
        case .decodingError: return "Erreur de données"
        }
    }
}

final class APIClient {
    static let shared = APIClient()
    private let session = URLSession.shared
    private let decoder: JSONDecoder = { let d = JSONDecoder(); d.keyDecodingStrategy = .convertFromSnakeCase; d.dateDecodingStrategy = .iso8601; return d }()

    func request<T: Decodable>(_ endpoint: Endpoint) async throws -> T {
        var request = URLRequest(url: endpoint.url)
        request.httpMethod = endpoint.method
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if let token = KeychainService.shared.get(forKey: "access_token") {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        if let body = endpoint.body { request.httpBody = try JSONEncoder().encode(body) }

        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw APIError.networkError(URLError(.badServerResponse)) }

        switch http.statusCode {
        case 200...299: return try decoder.decode(T.self, from: data)
        case 401: throw APIError.unauthorized
        case 404: throw APIError.notFound
        default: throw APIError.serverError(http.statusCode)
        }
    }
}
```
