# create-widget-extension
Widget iOS avec entry, timeline et configuration.

```swift
import WidgetKit
import SwiftUI

// Entry
struct ResourceEntry: TimelineEntry {
    let date: Date
    let resources: [Resource]
}

// Provider
struct ResourceProvider: TimelineProvider {
    func placeholder(in context: Context) -> ResourceEntry {
        ResourceEntry(date: .now, resources: Resource.placeholders)
    }

    func getSnapshot(in context: Context, completion: @escaping (ResourceEntry) -> Void) {
        completion(ResourceEntry(date: .now, resources: Resource.placeholders))
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<ResourceEntry>) -> Void) {
        Task {
            let resources = (try? await APIClient.shared.getRecentResources()) ?? []
            let entry = ResourceEntry(date: .now, resources: resources)
            let nextUpdate = Calendar.current.date(byAdding: .hour, value: 1, to: .now)!
            completion(Timeline(entries: [entry], policy: .after(nextUpdate)))
        }
    }
}

// Vue
struct ResourceWidgetView: View {
    var entry: ResourceEntry
    var body: some View {
        VStack(alignment: .leading) {
            Text("\(entry.resources.count) ressources")
                .font(.headline)
            ForEach(entry.resources.prefix(3)) { r in
                Text(r.name).font(.caption)
            }
        }
        .padding()
    }
}

// Widget
@main
struct ResourceWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "ResourceWidget", provider: ResourceProvider()) { entry in
            ResourceWidgetView(entry: entry)
        }
        .configurationDisplayName("Ressources")
        .supportedFamilies([.systemSmall, .systemMedium])
    }
}
```
