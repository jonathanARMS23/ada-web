# write-xctest-unit
Tests XCTest async avec mocks protocols.

## Template
```swift
@MainActor
final class ResourceViewModelTests: XCTestCase {
    var viewModel: ResourceViewModel!
    var mockUseCase: MockGetResourcesUseCase!

    override func setUp() {
        super.setUp()
        mockUseCase = MockGetResourcesUseCase()
        viewModel = ResourceViewModel(getResources: mockUseCase)
    }

    func testLoadResourcesSuccess() async {
        // Given
        let expected = [Resource(id: "1", name: "Test")]
        mockUseCase.result = .success(expected)

        // When
        await viewModel.loadResources()

        // Then
        if case .success(let resources) = viewModel.uiState {
            XCTAssertEqual(resources, expected)
        } else {
            XCTFail("Expected success state")
        }
    }

    func testLoadResourcesError() async {
        // Given
        mockUseCase.result = .failure(APIError.networkError)

        // When
        await viewModel.loadResources()

        // Then
        if case .error = viewModel.uiState {
            // OK
        } else {
            XCTFail("Expected error state")
        }
    }
}

// Mock
final class MockGetResourcesUseCase: GetResourcesUseCase {
    var result: Result<[Resource], Error> = .success([])
    func execute() async throws -> [Resource] {
        try result.get()
    }
}
```
