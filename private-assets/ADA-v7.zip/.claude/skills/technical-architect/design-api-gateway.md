# design-api-gateway
Pattern API Gateway : routing, auth centralisée, rate limiting.

## Responsabilités du gateway
```
Client → [API Gateway] → Service A
                      → Service B
                      → Service C

Gateway gère :
- Authentification (valider JWT une seule fois)
- Rate limiting global
- Logging centralisé
- CORS
- SSL termination
- Request/Response transformation
```

## Quand NE PAS utiliser
- Monolithe modulaire → gateway inutile
- < 3 services → sur-ingénierie
- Équipe < 5 devs → overhead trop élevé

## Options selon le contexte
| Option | Usage |
|--------|-------|
| Nginx (simple) | Reverse proxy + rate limiting |
| Kong | Gateway complet open source |
| AWS API Gateway | Si déjà sur AWS |
| NestJS + @nestjs/microservices | Si stack NestJS existante |
