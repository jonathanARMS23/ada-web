# design-caching-strategy
Stratégie cache multi-couche avec invalidation.

## Couches de cache
```
L1 — In-memory (NestJS/Django process)
  Durée de vie : secondes à minutes
  Usage : données très fréquentes, non personnalisées

L2 — Redis
  Durée de vie : minutes à heures
  Usage : résultats de requêtes, sessions, rate limiting

L3 — CDN (Cloudflare/Vercel Edge)
  Durée de vie : heures à jours
  Usage : assets statiques, pages publiques

L4 — HTTP Cache headers
  Cache-Control: public, max-age=3600
  Usage : ressources statiques, APIs publiques
```

## Pattern cache-aside (Redis)
```typescript
async getResource(id: string) {
  const cached = await redis.get(`resource:${id}`)
  if (cached) return JSON.parse(cached)

  const resource = await db.resource.findUnique({ where: { id } })
  await redis.setex(`resource:${id}`, 3600, JSON.stringify(resource))
  return resource
}

async updateResource(id: string, data: any) {
  const resource = await db.resource.update({ where: { id }, data })
  await redis.del(`resource:${id}`)  // invalidation
  return resource
}
```
