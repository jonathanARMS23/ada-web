# design-event-driven
Architecture event-driven : events, handlers, saga.

## Quand utiliser
- Découplage entre services
- Opérations asynchrones (email, notifications, analytics)
- Patterns de saga (transactions distribuées)

## Events typés
```typescript
// events/index.ts
export abstract class DomainEvent {
  readonly occurredAt = new Date()
  abstract readonly eventType: string
}

export class ResourceCreatedEvent extends DomainEvent {
  readonly eventType = 'resource.created'
  constructor(public readonly resource: Resource) { super() }
}
```

## Saga pattern (compensation)
```
Commande → [ReserveStock] → [ProcessPayment] → [SendConfirmation]
                ↓ échec         ↓ échec
           [Compensate]    [RefundPayment]
```

## Règles
- Events immutables — jamais modifier un event émis
- Idempotence sur les handlers — gérer les doublons
- Dead letter queue pour les events non traités
- Monitoring des events non consommés
