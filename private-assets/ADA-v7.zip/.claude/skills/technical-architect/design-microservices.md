# design-microservices
Découpage services avec frontières domaine DDD.

## Questions à répondre avant de découper
1. Le monolithe a-t-il réellement des problèmes de scalabilité ?
2. L'équipe est-elle > 10 personnes ?
3. Les domaines ont-ils des cycles de déploiement différents ?

Si non aux 3 → garder le monolithe modulaire.

## Template de découpage
```
Domaine [Nom]
  Entities : [liste]
  Aggregates : [liste]
  Commands : [CreateX, UpdateX, DeleteX]
  Events : [XCreated, XUpdated]
  Boundaries : [ce qui ne peut pas venir d'un autre service]
  Communication : [sync REST | async event]
```

## Patterns de communication
- Sync (REST/gRPC) : lecture temps réel, opérations critiques
- Async (queues) : notifications, logs, traitement différé
- Event sourcing : si audit trail complet requis
