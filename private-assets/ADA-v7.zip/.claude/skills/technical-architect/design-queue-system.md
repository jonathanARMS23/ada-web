# design-queue-system
Système de queues : priorisation, retry, DLQ, monitoring.

## Choisir la queue
| Besoin | Outil |
|--------|-------|
| NestJS + Redis | BullMQ (recommandé) |
| Django + Redis | Celery |
| Multi-langue | RabbitMQ ou SQS |
| Simple + Postgres | pg-boss |

## Architecture BullMQ
```typescript
// Queues par priorité métier
const queues = {
  critical: new Queue('critical', { redis }),       // paiements, auth
  high: new Queue('high', { redis }),               // emails, notifications
  default: new Queue('default', { redis }),         // traitement normal
  low: new Queue('low', { redis }),                 // analytics, logs
}

// Config retry + DLQ
const jobOptions = {
  attempts: 3,
  backoff: { type: 'exponential', delay: 2000 },
  removeOnComplete: { count: 1000 },
  removeOnFail: { count: 5000 },  // garder les failed pour audit
}
```

## Monitoring
- Bull Board pour visualiser les queues
- Alerter si DLQ > 0
- Alerter si queue size > seuil
- Métriques : throughput, latence, error rate
