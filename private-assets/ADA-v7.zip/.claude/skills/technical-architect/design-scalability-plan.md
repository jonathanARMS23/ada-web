# design-scalability-plan
Plan de montée en charge : bottlenecks et horizontal scaling.

## Identifier les bottlenecks
```
1. DB (le plus fréquent) :
   - Connexions max atteintes → connection pooling (PgBouncer)
   - Requêtes lentes → index, query optimization
   - Volume de données → partitioning, archivage

2. Application :
   - CPU-bound → horizontal scaling (plusieurs instances)
   - Memory-bound → optimisation, cache
   - I/O-bound → async, queues

3. Réseau :
   - Latence API → CDN, Edge functions
   - Bandwidth → compression, pagination
```

## Plan par palier
```
0-100 users    : 1 instance, DB partagée, pas de cache
100-1k users   : +Redis cache, connection pooling
1k-10k users   : +Read replica, CDN assets, queues pour async
10k-100k users : +Sharding ou multi-région, cache distribué
> 100k users   : Architecture distribuée, microservices ciblés
```

## Règle YAGNI
Ne pas architecturer pour 1M users si on en a 100.
Construire pour 10x le volume actuel, pas pour 1000x.
