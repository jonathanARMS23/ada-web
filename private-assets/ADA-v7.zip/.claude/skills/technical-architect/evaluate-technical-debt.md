# evaluate-technical-debt
Évaluer la dette technique : impact, coût, plan.

## Inventaire de la dette

### Types
- **Code debt** : code difficile à maintenir, trop complexe, non testé
- **Architecture debt** : couplage, responsabilités mélangées
- **DB debt** : migrations non appliquées, index manquants, schéma incohérent
- **Test debt** : coverage insuffisant, tests fragiles
- **Dependency debt** : dépendances obsolètes ou vulnérables

## Scoring par item
```
Impact sur la vélocité (1-5) : ralentit combien les nouvelles features ?
Risque production (1-5) : risque de bug ou panne ?
Coût de remboursement (1-5, inversé) : effort pour corriger ?
Score = Impact × Risque × (6 - Coût)
```

## Format de sortie
```markdown
## Dette Technique — <projet>

| Item | Impact | Risque | Coût | Score | Priorité |
|------|--------|--------|------|-------|----------|
| Tests coverage < 30% | 4 | 3 | 3 | 36 | P0 |

### Plan de remboursement
Sprint N : [items P0]
Sprint N+1 : [items P1]
Backlog : [items P2]

### Coût mensuel estimé si non traité
[Impact sur la vélocité en j/h par sprint]
```
