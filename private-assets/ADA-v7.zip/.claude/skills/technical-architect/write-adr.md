# write-adr
Architecture Decision Record complet.

## Template
```markdown
# ADR-XXX — <titre>
**Date :** YYYY-MM-DD
**Status :** Proposed | Accepted | Deprecated | Superseded by ADR-YYY
**Décideurs :** [noms/rôles]

## Contexte
[Situation actuelle + problème à résoudre]

## Options considérées

### Option A — [titre]
**Avantages :** [liste]
**Inconvénients :** [liste]
**Coût :** [estimation]

### Option B — [titre]
...

## Décision
Option [X] choisie.

## Justification
[Pourquoi cette option, quels critères ont pesé]

## Conséquences
**Positives :**
- [liste]
**Négatives / compromis :**
- [liste]
**Prochaines étapes :**
- [liste]
```

## Règle
Un ADR par décision irréversible ou difficile à changer.
Stocker dans `docs/adr/` du projet.
