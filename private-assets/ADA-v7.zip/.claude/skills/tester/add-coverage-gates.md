# add-coverage-gates
Seuils de coverage minimum avec blocage CI.

## Jest (NestJS)
```typescript
// jest.config.ts
coverageThresholds: {
  global: { branches: 70, functions: 80, lines: 80 },
  './src/services/**': { lines: 90 },  // seuil plus élevé sur les services
}
```

## pytest (DRF)
```ini
# pytest.ini
addopts = --cov-fail-under=75
```

## GitHub Actions — bloquer le merge si coverage baisse
```yaml
- name: Check coverage
  run: |
    COVERAGE=$(npm test -- --coverage --json 2>/dev/null | python3 -c "
    import json,sys
    data=json.load(sys.stdin)
    print(data['coverageMap']['total']['lines']['pct'])
    ")
    echo "Coverage: $COVERAGE%"
    if (( $(echo "$COVERAGE < 75" | bc -l) )); then
      echo "❌ Coverage $COVERAGE% < 75%"
      exit 1
    fi
```
