# add-mutation-testing
Mutation testing avec Stryker pour valider la qualité des tests.

## Setup (NestJS/Jest)
```bash
npm i -D @stryker-mutator/core @stryker-mutator/jest-runner
```

```json
// stryker.config.json
{
  "mutate": ["src/**/*.ts", "!src/**/*.spec.ts", "!src/**/*.module.ts"],
  "testRunner": "jest",
  "reporters": ["html", "clear-text"],
  "thresholds": { "high": 80, "low": 60, "break": 50 },
  "coverageAnalysis": "perTest",
  "jest": { "config": { "testTimeout": 10000 } }
}
```

```bash
npx stryker run  # génère stryker-tmp/reports/mutation/mutation.html
```

## Interpréter les résultats
- **Killed** (✓) : le mutant a été détecté → test solide
- **Survived** (✗) : le mutant n'a pas été détecté → test manquant ou insuffisant
- **Score > 80%** : bonne couverture de mutation
