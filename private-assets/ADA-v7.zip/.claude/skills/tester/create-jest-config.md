# create-jest-config
Config Jest NestJS optimisée.

```typescript
// jest.config.ts
export default {
  moduleFileExtensions: ['js', 'json', 'ts'],
  rootDir: 'src',
  testRegex: '.*\\.spec\\.ts$',
  transform: { '^.+\\.(t|j)s$': 'ts-jest' },
  collectCoverageFrom: ['**/*.(t|j)s', '!**/*.module.ts', '!**/main.ts'],
  coverageDirectory: '../coverage',
  coverageThresholds: {
    global: { branches: 70, functions: 80, lines: 80, statements: 80 },
  },
  testEnvironment: 'node',
  moduleNameMapper: {
    '^@/(.*)$': '<rootDir>/$1',
  },
  setupFilesAfterFramework: ['<rootDir>/../test/setup.ts'],
}
```

```typescript
// test/setup.ts
import { PrismaClient } from '@prisma/client'
const prisma = new PrismaClient()

beforeAll(async () => { await prisma.$connect() })
afterAll(async () => { await prisma.$disconnect() })
afterEach(async () => {
  // Nettoyer la DB de test après chaque test
  const tables = ['resources', 'workspaces', 'users']
  for (const t of tables) await prisma.$executeRawUnsafe(`TRUNCATE TABLE ${t} CASCADE`)
})
```
