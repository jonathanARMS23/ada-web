# create-pytest-config
Config pytest DRF optimisée.

```ini
# pytest.ini
[pytest]
DJANGO_SETTINGS_MODULE = config.settings.test
python_files = tests.py test_*.py *_tests.py
python_classes = Test*
python_functions = test_*
addopts =
    --reuse-db
    --cov=.
    --cov-report=term-missing
    --cov-fail-under=75
    -x
markers =
    slow: marks tests as slow
    integration: marks integration tests
```

```python
# conftest.py
import pytest
from pytest_factoryboy import register
from .factories import UserFactory, WorkspaceFactory, ResourceFactory

register(UserFactory)
register(WorkspaceFactory)
register(ResourceFactory)

@pytest.fixture
def api_client():
    from rest_framework.test import APIClient
    return APIClient()

@pytest.fixture
def auth_client(api_client, user):
    api_client.force_authenticate(user=user)
    return api_client
```
