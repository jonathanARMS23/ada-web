# create-test-factories
Factories réutilisables avec faker.

## TypeScript (NestJS/Jest)
```typescript
import { faker } from '@faker-js/faker/locale/fr'

export const createUser = (overrides = {}) => ({
  id: faker.string.uuid(),
  email: faker.internet.email(),
  name: faker.person.fullName(),
  workspaceId: faker.string.uuid(),
  createdAt: faker.date.past(),
  ...overrides,
})

export const createResource = (overrides = {}) => ({
  id: faker.string.uuid(),
  name: faker.commerce.productName(),
  status: 'active' as const,
  workspaceId: faker.string.uuid(),
  deletedAt: null,
  createdAt: faker.date.past(),
  ...overrides,
})

// Builder pattern
export class ResourceBuilder {
  private resource = createResource()
  withStatus(status: string) { this.resource.status = status; return this }
  deleted() { this.resource.deletedAt = new Date(); return this }
  build() { return this.resource }
}
```
