# write-component-tests
Tests React Testing Library : render, interactions, accessibilité.

## Template
```typescript
import { render, screen, userEvent } from '@testing-library/react'
import { ResourceForm } from './ResourceForm'

const setup = (props = {}) => {
  const onSubmit = jest.fn()
  const user = userEvent.setup()
  render(<ResourceForm onSubmit={onSubmit} {...props} />)
  return { onSubmit, user }
}

describe('ResourceForm', () => {
  it('renders all fields', () => {
    setup()
    expect(screen.getByLabelText('Nom')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Créer' })).toBeInTheDocument()
  })

  it('shows validation error when name is empty', async () => {
    const { user } = setup()
    await user.click(screen.getByRole('button', { name: 'Créer' }))
    expect(screen.getByText('Min 2 caractères')).toBeInTheDocument()
  })

  it('calls onSubmit with form data', async () => {
    const { user, onSubmit } = setup()
    await user.type(screen.getByLabelText('Nom'), 'Test')
    await user.click(screen.getByRole('button', { name: 'Créer' }))
    expect(onSubmit).toHaveBeenCalledWith({ name: 'Test' })
  })

  it('has no accessibility violations', async () => {
    const { container } = render(<ResourceForm onSubmit={jest.fn()} />)
    const results = await axe(container)
    expect(results).toHaveNoViolations()
  })
})
```
