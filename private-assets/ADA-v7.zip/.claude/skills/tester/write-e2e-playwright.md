# write-e2e-playwright
Tests E2E Playwright sur les flows critiques.

## Config
```typescript
// playwright.config.ts
export default defineConfig({
  testDir: './e2e',
  fullyParallel: true,
  retries: process.env.CI ? 2 : 0,
  use: {
    baseURL: 'http://localhost:3000',
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
  },
  projects: [
    { name: 'chromium', use: { ...devices['Desktop Chrome'] } },
    { name: 'Mobile Safari', use: { ...devices['iPhone 14'] } },
  ],
})
```

## Test d'authentification
```typescript
test('user can login and access dashboard', async ({ page }) => {
  await page.goto('/login')
  await page.getByLabel('Email').fill('test@example.com')
  await page.getByLabel('Mot de passe').fill('password123')
  await page.getByRole('button', { name: 'Se connecter' }).click()
  await expect(page).toHaveURL('/dashboard')
  await expect(page.getByText('Tableau de bord')).toBeVisible()
})
```

## Test CRUD
```typescript
test('user can create and delete a resource', async ({ page }) => {
  await loginAs(page, 'user@test.com')
  await page.goto('/resources')
  await page.getByRole('button', { name: 'Nouveau' }).click()
  await page.getByLabel('Nom').fill('Test Resource')
  await page.getByRole('button', { name: 'Créer' }).click()
  await expect(page.getByText('Test Resource')).toBeVisible()
})
```
