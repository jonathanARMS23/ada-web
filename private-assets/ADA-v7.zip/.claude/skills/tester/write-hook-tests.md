# write-hook-tests
Tests custom hooks avec renderHook et act.

```typescript
import { renderHook, act, waitFor } from '@testing-library/react'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { useResources } from './useResources'

const createWrapper = () => {
  const queryClient = new QueryClient({
    defaultOptions: { queries: { retry: false } },
  })
  return ({ children }: { children: React.ReactNode }) => (
    <QueryClientProvider client={queryClient}>{children}</QueryClientProvider>
  )
}

vi.mock('@/lib/api', () => ({
  api: { resources: { list: vi.fn() } },
}))

describe('useResources', () => {
  it('returns resources on success', async () => {
    const mockResources = [{ id: '1', name: 'Test' }]
    vi.mocked(api.resources.list).mockResolvedValue({ data: mockResources })

    const { result } = renderHook(() => useResources('ws-1'), { wrapper: createWrapper() })

    await waitFor(() => expect(result.current.isSuccess).toBe(true))
    expect(result.current.data).toEqual(mockResources)
  })

  it('handles error state', async () => {
    vi.mocked(api.resources.list).mockRejectedValue(new Error('Network error'))

    const { result } = renderHook(() => useResources('ws-1'), { wrapper: createWrapper() })

    await waitFor(() => expect(result.current.isError).toBe(true))
  })
})
```
