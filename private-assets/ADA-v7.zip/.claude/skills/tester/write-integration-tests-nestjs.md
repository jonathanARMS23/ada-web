# write-integration-tests-nestjs
Tests intégration Supertest.

```typescript
describe('ResourceController (e2e)', () => {
  let app: INestApplication;
  let token: string;

  beforeAll(async () => {
    const module = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();
    app = module.createNestApplication();
    app.useGlobalPipes(new ValidationPipe({ whitelist: true }));
    await app.init();
    token = await getTestToken(app);
  });

  afterAll(() => app.close());

  describe('POST /resources', () => {
    it('201 — crée une ressource', async () => {
      const res = await request(app.getHttpServer())
        .post('/resources')
        .set('Authorization', `Bearer ${token}`)
        .send({ name: 'Test Resource' })
        .expect(201);

      expect(res.body).toMatchObject({ name: 'Test Resource', status: 'draft' });
      expect(res.body.id).toMatch(/^[0-9a-f-]{36}$/);
    });

    it('422 — nom trop court', async () => {
      await request(app.getHttpServer())
        .post('/resources')
        .set('Authorization', `Bearer ${token}`)
        .send({ name: 'x' })
        .expect(422);
    });

    it('401 — sans token', async () => {
      await request(app.getHttpServer())
        .post('/resources')
        .send({ name: 'Test' })
        .expect(401);
    });
  });
});
```
