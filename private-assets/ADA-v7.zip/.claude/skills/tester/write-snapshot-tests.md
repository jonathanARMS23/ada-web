# write-snapshot-tests
Tests snapshot pour composants stables.

## Vitest + React Testing Library
```typescript
import { render } from '@testing-library/react'
import { ResourceCard } from './ResourceCard'

const mockResource = { id: '1', name: 'Test', status: 'active', createdAt: '2024-01-01' }

describe('ResourceCard', () => {
  it('matches snapshot', () => {
    const { container } = render(<ResourceCard resource={mockResource} />)
    expect(container).toMatchSnapshot()
  })
})
```

## Mise à jour des snapshots
```bash
# Mettre à jour tous les snapshots
npm test -- --update-snapshots

# Mettre à jour un fichier spécifique
npm test -- --update-snapshots ResourceCard
```

## Règles
- Snapshots uniquement pour les composants purement présentationnels
- Jamais de snapshot sur des composants avec état complexe → préférer les assertions
- Versionner les snapshots dans git
- Mettre à jour les snapshots intentionnellement, jamais en aveugle
