# write-tdd-specs
Rédiger les specs AVANT l'implémentation (phase RED).

## Format de sortie
```
## Specs — <nom de la feature>

### Comportements attendus
- [ ] Crée une ressource avec les données valides → retourne 201 + objet créé
- [ ] Rejette si name manquant → retourne 422 + message d'erreur
- [ ] Rejette si utilisateur non authentifié → retourne 401
- [ ] Filtre par workspace de l'utilisateur → ne retourne pas les ressources d'autres workspaces
- [ ] Soft delete : la ressource n'apparaît plus dans les listes après suppression

### Tests à écrire
1. `should create resource with valid data`
2. `should return 422 when name is missing`
3. `should return 401 when not authenticated`
4. `should only return resources from user workspace`
5. `should not return soft-deleted resources`
```

## Règle
Écrire les specs AVANT de demander l'implémentation à l'agent backend.
RED → GREEN → REFACTOR — jamais dans l'autre sens.
