# write-unit-tests-drf
Tests unitaires DRF avec pytest et APIClient.

```python
import pytest
from rest_framework.test import APIClient
from .factories import ResourceFactory, UserFactory, WorkspaceFactory

@pytest.fixture
def api_client(): return APIClient()

@pytest.fixture
def workspace(): return WorkspaceFactory()

@pytest.fixture
def user(workspace): return UserFactory(workspace=workspace)

@pytest.fixture
def auth_client(api_client, user):
    api_client.force_authenticate(user=user)
    return api_client

@pytest.mark.django_db
class TestResourceViewSet:
    def test_list_only_own_workspace(self, auth_client, user, workspace):
        ResourceFactory.create_batch(3, workspace=workspace)
        ResourceFactory(workspace=WorkspaceFactory())  # autre workspace
        response = auth_client.get('/api/v1/resources/')
        assert response.status_code == 200
        assert len(response.data['data']) == 3

    def test_create_resource(self, auth_client, workspace):
        data = {'name': 'Test Resource', 'status': 'draft'}
        response = auth_client.post('/api/v1/resources/', data)
        assert response.status_code == 201
        assert response.data['name'] == 'Test Resource'

    def test_cannot_access_other_workspace(self, auth_client):
        other = ResourceFactory(workspace=WorkspaceFactory())
        response = auth_client.get(f'/api/v1/resources/{other.id}/')
        assert response.status_code == 404  # pas 403

    def test_requires_authentication(self, api_client):
        response = api_client.get('/api/v1/resources/')
        assert response.status_code == 401
```
