# write-unit-tests-nestjs
Tests unitaires service NestJS avec mock repository.

## Template
```typescript
describe('ResourceService', () => {
  let service: ResourceService
  let prisma: DeepMockProxy<PrismaService>

  beforeEach(async () => {
    const module = await Test.createTestingModule({
      providers: [
        ResourceService,
        { provide: PrismaService, useValue: mockDeep<PrismaService>() },
      ],
    }).compile()

    service = module.get(ResourceService)
    prisma = module.get(PrismaService)
  })

  describe('create', () => {
    it('should create a resource', async () => {
      const dto = { name: 'Test', workspaceId: 'ws-1' }
      prisma.resource.create.mockResolvedValue({ id: 'uuid', ...dto })

      const result = await service.create(dto)

      expect(prisma.resource.create).toHaveBeenCalledWith({ data: dto })
      expect(result.id).toBeDefined()
    })

    it('should throw if workspace not found', async () => {
      prisma.resource.create.mockRejectedValue(new PrismaClientKnownRequestError(
        'Foreign key constraint failed', { code: 'P2003', clientVersion: '' }
      ))
      await expect(service.create({ name: 'x', workspaceId: 'bad' }))
        .rejects.toThrow(NotFoundException)
    })
  })
})
```
