# audit-accessibility
Audit accessibilité WCAG AA.

## Checklist rapide
```
Structure :
□ Un seul <h1> par page
□ Hiérarchie des titres logique (h1 > h2 > h3)
□ Landmark roles : <main>, <nav>, <header>, <footer>

Formulaires :
□ Chaque <input> a un <label> associé (htmlFor/for)
□ Les erreurs sont annoncées via aria-describedby
□ aria-required sur les champs obligatoires

Images :
□ alt non vide sur toutes les images significatives
□ alt="" sur les images décoratives

Interactivité :
□ Tous les éléments interactifs accessibles au clavier
□ Focus visible (pas de outline: none sans alternative)
□ Ordre de tabulation logique

Couleurs :
□ Contraste texte normal ≥ 4.5:1
□ Contraste texte large ≥ 3:1
□ Information jamais véhiculée uniquement par la couleur
```

## Outil de test rapide
```bash
npx axe-cli http://localhost:3000 --tags wcag2aa
```
