# design-dashboard-layout
Layout dashboard : hiérarchie info, navigation, densité.

## Wireframe standard
```
┌──────────────────────────────────────────────────────┐
│ [Logo] [Nav: Accueil | Ressources | Settings] [User] │
├────────────────┬─────────────────────────────────────┤
│                │  [Titre page]     [Action primaire]  │
│  Sidebar nav   │  ─────────────────────────────────  │
│  ─────────     │                                     │
│  • Accueil     │  [KPI Cards — 4 max en ligne]       │
│  • Ressources  │  ─────────────────────────────────  │
│  • Analytics   │                                     │
│  • Settings    │  [Tableau principal]                │
│                │                                     │
│  ─────────     │  [Pagination]                       │
│  [User info]   │                                     │
└────────────────┴─────────────────────────────────────┘
```

## Règles
- KPI cards en haut : max 4, les plus importants
- Action primaire : un seul bouton CTA par page
- Sidebar : max 7 items (Miller's Law)
- Densité des données : configurable (compact/normal)
