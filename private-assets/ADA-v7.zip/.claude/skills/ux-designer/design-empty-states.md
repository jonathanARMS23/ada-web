# design-empty-states
États vides avec message, illustration et call-to-action.

## Types d'états vides

### Premier usage (no data yet)
```
[Illustration simple]
Titre : "Aucune ressource pour l'instant"
Sous-titre : "Créez votre première ressource pour commencer"
[Bouton CTA : "Créer une ressource"]
```

### Recherche sans résultat
```
[Icône loupe]
Titre : "Aucun résultat pour « {terme} »"
Suggestions :
  • Vérifier l'orthographe
  • Essayer des termes plus généraux
[Effacer la recherche]
```

### Filtre actif sans résultat
```
[Icône filtre]
Titre : "Aucune ressource avec ces filtres"
[Réinitialiser les filtres]
```

### Règles
- Toujours un CTA clair (ne pas laisser l'utilisateur bloqué)
- Illustration simple, pas trop grande
- Message en langage naturel, pas d'erreur technique
- Ne jamais afficher "null" ou "undefined"
