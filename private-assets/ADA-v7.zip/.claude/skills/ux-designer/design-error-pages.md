# design-error-pages
Pages d'erreur : 404, 500, accès refusé.

## 404 — Page non trouvée
```
[Illustration légère]
Titre : "Page introuvable"
Sous-titre : "La page que vous recherchez n'existe plus ou a été déplacée."
Actions :
  [← Retour]   [Aller à l'accueil]
```

## 500 — Erreur serveur
```
[Illustration]
Titre : "Une erreur est survenue"
Sous-titre : "Nous travaillons à résoudre le problème. Réessayez dans quelques instants."
Actions :
  [Réessayer]   [Contacter le support]
```
Ne jamais afficher le stack trace ou les détails techniques.

## 403 — Accès refusé
```
[Illustration cadenas]
Titre : "Accès non autorisé"
Sous-titre : "Vous n'avez pas les permissions pour accéder à cette page."
Actions :
  [← Retour]   [Demander l'accès]
```

## Règles
- Conserver la navigation principale (l'utilisateur peut s'en sortir)
- Action principale claire et visible
- Pas d'humour forcé qui peut énerver un utilisateur frustré
