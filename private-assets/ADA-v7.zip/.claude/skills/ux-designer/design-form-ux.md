# design-form-ux
UX formulaire optimale — labels, validation, erreurs.

## Règles UX formulaire
1. Labels toujours visibles (jamais seulement placeholder)
2. Indication des champs obligatoires : `*` avec légende
3. Validation en temps réel après premier blur (pas à la saisie)
4. Erreurs inline sous le champ, pas en haut du formulaire
5. Message d'erreur précis : "Email invalide" > "Champ requis"
6. Bouton submit désactivé pendant la soumission
7. Focus automatique sur le premier champ en erreur après soumission

## Messages d'erreur standards
```
Champ vide      → "Ce champ est requis"
Email invalide  → "Entrez une adresse email valide (ex: nom@domaine.com)"
Trop court      → "Minimum X caractères (actuel: Y)"
Trop long       → "Maximum X caractères"
Doublon         → "Cette valeur est déjà utilisée"
Format invalide → "Format attendu : [exemple]"
```

## États bouton submit
```
Défaut  : [Créer]
Loading : [⟳ Création en cours...]
Succès  : [✓ Créé] (puis redirect)
Erreur  : [Créer] (réactivé avec erreurs affichées)
```
