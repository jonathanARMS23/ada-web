# design-mobile-ux
Adaptation mobile : touch targets, gestes, clavier.

## Touch targets
- Taille minimum : 44×44px (Apple) / 48×48dp (Material)
- Espacement minimum entre cibles interactives : 8px
- Pas d'éléments cliquables trop proches (doigt ≠ souris)

## Clavier virtuel
```
[Problème] : le clavier virtuel masque les inputs en bas d'écran
[Fix] : ScrollView + keyboardShouldPersistTaps="handled"
      + padding bottom = hauteur du clavier

// React Native
<KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
  <ScrollView keyboardShouldPersistTaps="handled">
    ...
  </ScrollView>
</KeyboardAvoidingView>
```

## Gestes standards
- Swipe gauche sur un item → actions rapides (supprimer, archiver)
- Pull-to-refresh → recharger la liste
- Long press → mode sélection
- Pinch-to-zoom → images uniquement

## Navigation
- Tab bar max 5 items (en bas sur iOS, en bas ou haut sur Android)
- Back button toujours accessible
- Pas de hover states (n'existe pas sur mobile)
