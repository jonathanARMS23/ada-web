# design-onboarding-flow
Flow onboarding : étapes, progression, valeur immédiate.

## Principes
- Max 5 étapes (au-delà = abandon)
- Valeur perçue avant de demander des infos
- Progress bar visible
- Chaque étape = une seule question/action
- Skip possible sur les étapes optionnelles

## Template flow
```
Étape 1 — Bienvenue (10s)
  Titre : "Bienvenue sur [Produit]"
  Action : [Commencer] → pas de formulaire

Étape 2 — Info essentielle (30s)
  1 seul champ obligatoire
  Action : [Continuer]

Étape 3 — Personnalisation (optionnel)
  2-3 choix visuels
  [Passer cette étape] visible

Étape 4 — Premier succès (30s)
  Première valeur démontrée
  Action : "Créer votre premier X"

Étape 5 — Invitation (optionnel)
  Inviter l'équipe
  [Faire ça plus tard]
```
