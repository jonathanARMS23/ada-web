# design-user-flow
Flow utilisateur complet avec tous les chemins.

## Template
```
## User Flow — <feature>

### Point d'entrée
[URL ou action qui déclenche le flow]

### Flow principal
[Action] → [Étape 1] → [Étape 2] → [Succès]
                ↓
           [Validation]
                ↓ échec
           [Message erreur + retry]

### Chemins alternatifs
- Annulation → [où ça redirige]
- Erreur réseau → [message + retry automatique]
- Session expirée → [redirect login + retour après auth]
- Données manquantes → [état vide + call to action]

### État de succès
[Ce que l'utilisateur voit/reçoit comme feedback]
```
