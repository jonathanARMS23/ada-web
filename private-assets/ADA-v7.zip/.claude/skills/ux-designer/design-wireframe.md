# design-wireframe
Wireframes ASCII détaillés avec tous les états.

## Template
```
┌─────────────────────────────────────────┐
│ [Header — Titre de la page]      [Menu] │
├─────────────────────────────────────────┤
│                                         │
│  [Section principale]                   │
│  ┌───────────────────────────────────┐  │
│  │ Label champ *                     │  │
│  │ ┌─────────────────────────────┐  │  │
│  │ │ Placeholder...              │  │  │
│  │ └─────────────────────────────┘  │  │
│  │ ⚠ Message d'erreur inline        │  │  
│  └───────────────────────────────────┘  │
│                                         │
│  ┌──────────┐  ┌──────────────────┐    │
│  │ Annuler  │  │ ✓ Enregistrer    │    │
│  └──────────┘  └──────────────────┘    │
└─────────────────────────────────────────┘

États :
- Loading : [skeleton ou spinner position]
- Succès : [toast + redirection]
- Erreur : [inline sous chaque champ]
- Vide : [illustration + CTA]
```
