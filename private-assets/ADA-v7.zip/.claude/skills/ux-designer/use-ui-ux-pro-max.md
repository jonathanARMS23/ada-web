# use-ui-ux-pro-max
Skill bridge — Accéder à la base de données de design intelligence ui-ux-pro-max.

## Prérequis — Installation du skill externe
```bash
# Cloner le repo dans le répertoire du projet
git clone https://github.com/nextlevelbuilder/ui-ux-pro-max-skill.git .tmp-skill
cp -r .tmp-skill/.claude/skills/ui-ux-pro-max "${CLAUDE_CONFIG_DIR}/.claude/skills/ui-ux-pro-max"
cp -r .tmp-skill/src "${CLAUDE_CONFIG_DIR}/src"
rm -rf .tmp-skill

# Ou via la CLI si disponible
# npx @21st-dev/cli@latest install-skill ui-ux-pro-max
```

## Vérifier si le skill est installé
```bash
[ -f "${CLAUDE_CONFIG_DIR}/.claude/skills/ui-ux-pro-max/SKILL.md" ] \
  && echo "INSTALLÉ" || echo "NON INSTALLÉ — utiliser les skills intégrés"
```

## Si installé — Lire le skill externe
```
Lire : skills/ui-ux-pro-max/SKILL.md
```

Ce skill fournit :
- 50+ styles visuels (glassmorphism, claymorphism, brutalism, bento grid...)
- 161 palettes de couleurs avec règles de sélection par type de produit
- 57 font pairings
- 161 types de produits avec patterns de design recommandés
- 99 guidelines UX prioritisées (accessibilité, touch, perf, layout...)
- 25 types de charts
- Support : React, Next.js, Vue, Svelte, SwiftUI, React Native, Flutter, Tailwind, shadcn/ui, HTML/CSS

## Recherche dans la base de données (si scripts Python disponibles)
```bash
# Générer un design system complet pour un type de produit
python3 "${CLAUDE_CONFIG_DIR}/src/ui-ux-pro-max/scripts/search.py" \
  "<product_type> <industry> <keywords>" \
  --design-system \
  -p "Nom du Projet"

# Exemples
python3 ... "saas dashboard analytics fintech" --design-system -p "MonSaaS"
python3 ... "ecommerce fashion luxury" --design-system -p "BoutiqueApp"
python3 ... "healthcare mobile patient" --design-system -p "MedApp"

# Avec persistance (réutilisable entre sessions)
python3 ... "saas b2b workspace" --design-system --persist -p "MonSaaS"
```

## Si NON installé — Fallback intégré
Utiliser les skills natifs de l'agent selon le besoin :
- Style et couleurs → `skills/ux-designer/design-wireframe.md`
- Flow et navigation → `skills/ux-designer/design-user-flow.md`
- Accessibilité → `skills/ux-designer/audit-accessibility.md`
