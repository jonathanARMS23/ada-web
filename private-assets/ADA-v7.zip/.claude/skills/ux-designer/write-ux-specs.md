# write-ux-specs
Spécifications UX complètes pour un composant ou une page.

## Template
```markdown
## UX Specs — <composant/page>

### Contexte
[Dans quel contexte ce composant est-il utilisé ?]

### États à implémenter
| État | Déclencheur | Comportement visuel |
|------|-------------|---------------------|
| Default | — | [description] |
| Loading | Action en cours | Skeleton ou spinner |
| Success | Action réussie | Toast + [transition] |
| Error | Erreur validation | Inline sous le champ |
| Empty | Aucune donnée | [voir design-empty-states] |
| Disabled | [condition] | Grisé, non interactif |

### Interactions
| Action | Résultat |
|--------|----------|
| Clic sur [bouton] | [comportement précis] |
| Survol [élément] | [tooltip ou highlight] |

### Messages utilisateur
| Situation | Message exact |
|-----------|---------------|

### Accessibilité
- Role ARIA : [role]
- Label : [texte accessible]
- Ordre de focus : [description]
- Annonces screen reader : [ce qui est annoncé]

### Responsive
| Breakpoint | Adaptations |
|------------|-------------|
| Mobile < 768px | [description] |
| Tablet 768-1024 | [description] |
| Desktop > 1024 | [layout standard] |
```
