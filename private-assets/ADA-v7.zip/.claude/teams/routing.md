# Routing — Team Profiles

## Auto-switch obligatoire à chaque prompt

| Mots-clés dans le prompt | Profil activé | Agents |
|--------------------------|---------------|--------|
| nestjs + next / fullstack frontend+backend | `fullstack` | nestjs · nextjs · db |
| drf + next / django + frontend | `fullstack-drf` | drf · nextjs · db |
| frontend / next / react / tailwind / ui | `frontend` | nextjs · ux-designer · reviewer |
| nestjs / nest / backend ts | `backend-nestjs` | nestjs · db · tester |
| drf / django / python / backend py | `backend-drf` | drf · db · tester |
| react native / expo / mobile rn | `mobile-rn` | react-native · api-designer · reviewer |
| android / kotlin / ios / swift | `mobile-native` | android · swift · api-designer |
| docker / ci cd / deploy / infra / pipeline | `devops` | devops · security-auditor · reviewer |
| review / audit / sécurité / perf | `review` | reviewer · security-auditor · performance-analyst |
| architecture / conception / design système | `strategy` | feature-architect · devils-advocate · api-designer |
| ux / wireframe / user flow / maquette | `design` | ux-designer · technical-architect · data-modeler |
| business / roi / coût / marché / produit | `business` | business-researcher · financial-analyst · devils-advocate |
| migration / schéma / db / sql / postgres | `data` | data-modeler · db · migration-strategist |
| nouveau projet / onboarding / découverte | `onboarding` | onboarding-agent · feature-architect · technical-architect |

## Règles universelles (injectées une fois)

- TDD : tester écrit specs AVANT implémentation
- Conventional Commits : feat/fix/chore/docs/test
- Git flow : feature → dev → staging → main
- Jamais de secrets dans le code
- RLS sur toutes les tables Supabase
- Pas de `any` TypeScript
- uuid PK + timestamps sur toutes les tables DB

## Auto-compact
```
échange 6/7 → ⚠️ avertir
échange 7/7 → 🔄 compact automatique + résumé + remettre compteur à 0
```

## Commandes disponibles
/feature /review /deploy /push-staging /revert-staging
/test /db-migrate /summarize /fetch-sprint /memory
/reset /compact /team
