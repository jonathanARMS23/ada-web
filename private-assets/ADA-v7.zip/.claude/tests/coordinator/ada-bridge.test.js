#!/usr/bin/env node
'use strict'
const { describe, it, before, after } = require('node:test')
const assert = require('node:assert/strict')
const { mkdirSync, writeFileSync, existsSync, rmSync, readdirSync } = require('node:fs')
const { join } = require('node:path')
const os = require('node:os')

// Chaque suite utilise un TMP_DIR isolé passé via env CLAUDE_CONFIG_DIR et ADA_BRIDGE_DIR
const BASE = join(os.tmpdir(), `ada-bridge-test-${Date.now()}`)
const CONFIG_DIR  = join(BASE, 'config')
const BRIDGE_DIR  = join(BASE, 'bridge')

// Nom de profil courant calculé à partir de CONFIG_DIR
// currentProfileName() renvoie 'default' si le dernier segment ne commence pas par '.claude-'
// On crée donc un CONFIG_DIR dont le dernier segment est '.claude-test' pour avoir profile='test'
const CONFIG_DIR_NAMED = join(BASE, '.claude-test')
const MY_INBOX = join(BRIDGE_DIR, 'test', 'inbox')

let cmdReceive

before(() => {
  mkdirSync(CONFIG_DIR_NAMED, { recursive: true })
  mkdirSync(BRIDGE_DIR,       { recursive: true })
  mkdirSync(MY_INBOX,         { recursive: true })

  // Charger le module avec les variables d'env injectées
  process.env.CLAUDE_CONFIG_DIR = CONFIG_DIR_NAMED
  process.env.ADA_BRIDGE_DIR    = BRIDGE_DIR

  // Purger le cache require pour que le module recharge les consts
  const bridgePath = require.resolve('../../coordinator/ada-bridge.js')
  delete require.cache[bridgePath]
  cmdReceive = require('../../coordinator/ada-bridge.js').cmdReceive
})

after(() => {
  try { rmSync(BASE, { recursive: true, force: true }) } catch {}
  delete process.env.CLAUDE_CONFIG_DIR
  delete process.env.ADA_BRIDGE_DIR
})

// Helper : écrit un fichier JSON dans l'inbox du profil courant
function writeInbox(filename, content) {
  const dest = join(MY_INBOX, filename)
  writeFileSync(dest, typeof content === 'string' ? content : JSON.stringify(content))
  return dest
}

// Helper : liste les runs importés dans CONFIG_DIR_NAMED/runs/
function listImportedRuns() {
  const runsDir = join(CONFIG_DIR_NAMED, 'runs')
  if (!existsSync(runsDir)) return []
  return readdirSync(runsDir)
}

// ─── id traversal : "../../.claude/coordinator/settings" ─────────────────────

describe('cmdReceive — id traversal détecté', () => {
  it("ignore un fichier inbox dont l'id contient des séquences de path traversal", () => {
    writeInbox('traversal.json', {
      id: '../../.claude/coordinator/settings',
      pipeline: 'feature',
      _bridgedFrom: '/tmp/other-profile',
      _bridgedAt: new Date().toISOString(),
    })

    // Capturer stderr pour vérifier le log d'erreur
    const errors = []
    const origErr = console.error
    console.error = (...args) => errors.push(args.join(' '))

    cmdReceive([])

    console.error = origErr

    // Aucun run importé
    const runs = listImportedRuns()
    assert.equal(runs.length, 0, `Aucun run ne doit être importé, trouvé : ${runs.join(', ')}`)

    // Un message d'erreur doit mentionner l'id invalide
    const hasErrorMsg = errors.some(m => m.includes('invalide') || m.includes('invalid') || m.includes('ignoré') || m.includes('ignored'))
    assert.ok(hasErrorMsg, `Un log d'erreur sur l'id invalide attendu, reçu : ${JSON.stringify(errors)}`)
  })

  it("refuse un id contenant des slashes malgré un format presque valide", () => {
    writeInbox('slash-id.json', {
      id: 'valid-run/../../etc/passwd',
      pipeline: 'feature',
      _bridgedFrom: '/tmp/other',
      _bridgedAt: new Date().toISOString(),
    })

    cmdReceive([])
    const runs = listImportedRuns()
    assert.equal(runs.filter(r => r.includes('etc')).length, 0)
  })

  it("refuse un id commencant par un tiret (SAFE_RUN_ID_RE exige [a-z0-9] en premier)", () => {
    writeInbox('dash-start.json', {
      id: '-invalid-run-id',
      pipeline: 'feature',
      _bridgedFrom: '/tmp/other',
      _bridgedAt: new Date().toISOString(),
    })

    cmdReceive([])
    const runs = listImportedRuns()
    assert.equal(runs.length, 0, 'id commençant par tiret doit être rejeté')
  })
})

// ─── id valide : import correct dans runs/ ───────────────────────────────────

describe('cmdReceive — id valide importé dans runs/', () => {
  before(() => {
    // Nettoyer l'inbox des tests précédents
    try {
      for (const f of readdirSync(MY_INBOX)) rmSync(join(MY_INBOX, f))
    } catch {}
    // Nettoyer les runs importés
    try { rmSync(join(CONFIG_DIR_NAMED, 'runs'), { recursive: true, force: true }) } catch {}
  })

  it("importe un run avec un id valide dans CONFIG_DIR/runs/<id>/state.json", () => {
    const validId = 'feature-my-test-fix-20260522-1312'
    writeInbox(`${validId}.json`, {
      id: validId,
      pipeline: 'feature',
      status: 'running',
      _bridgedFrom: '/home/user/.claude-pro',
      _bridgedAt: new Date().toISOString(),
    })

    cmdReceive([])

    const stateFile = join(CONFIG_DIR_NAMED, 'runs', validId, 'state.json')
    assert.ok(existsSync(stateFile), `state.json attendu à : ${stateFile}`)

    const state = JSON.parse(require('fs').readFileSync(stateFile, 'utf8'))
    assert.equal(state.id, validId)
    assert.equal(state.pipeline, 'feature')
    // cmdReceive nettoie les métadonnées de bridge avant d'écrire (cleanState) :
    // _bridgedFrom / _bridgedAt ne doivent PAS persister dans le run importé.
    assert.equal(state._bridgedFrom, undefined)
    assert.equal(state._bridgedAt, undefined)
  })

  it("accepte un id au format minimum valide (3 caractères alphanum)", () => {
    const shortId = 'abc'
    writeInbox(`${shortId}.json`, {
      id: shortId,
      pipeline: 'feature',
      _bridgedFrom: '/tmp/other',
      _bridgedAt: new Date().toISOString(),
    })

    cmdReceive([])

    const stateFile = join(CONFIG_DIR_NAMED, 'runs', shortId, 'state.json')
    assert.ok(existsSync(stateFile), `state.json attendu pour id court "${shortId}"`)
  })

  it("filtre par --from quand le profil ne correspond pas", () => {
    // Nettoyer
    try { rmSync(join(CONFIG_DIR_NAMED, 'runs'), { recursive: true, force: true }) } catch {}
    try { for (const f of readdirSync(MY_INBOX)) rmSync(join(MY_INBOX, f)) } catch {}

    const runId = 'feature-from-filter-20260522-1000'
    writeInbox(`${runId}.json`, {
      id: runId,
      pipeline: 'feature',
      _bridgedFrom: '/home/user/.claude-pro',
      _bridgedAt: new Date().toISOString(),
    })

    // --from 'staging' ne correspond pas à 'pro' dans _bridgedFrom
    cmdReceive(['--from', 'staging'])

    const runs = listImportedRuns()
    assert.equal(runs.length, 0, 'Run ne doit pas être importé si --from ne correspond pas')
  })
})

// ─── fichier inbox corrompu (JSON invalide) ───────────────────────────────────

describe('cmdReceive — fichier JSON corrompu ignoré sans crash', () => {
  before(() => {
    try { for (const f of readdirSync(MY_INBOX)) rmSync(join(MY_INBOX, f)) } catch {}
    try { rmSync(join(CONFIG_DIR_NAMED, 'runs'), { recursive: true, force: true }) } catch {}
  })

  it("ne crashe pas sur un fichier JSON invalide et log l'erreur", () => {
    writeInbox('corrupted.json', '{ this is not valid JSON :::')

    const errors = []
    const origErr = console.error
    console.error = (...args) => errors.push(args.join(' '))

    let threw = false
    try { cmdReceive([]) }
    catch { threw = true }

    console.error = origErr

    assert.equal(threw, false, 'cmdReceive ne doit pas lever une exception sur un JSON corrompu')

    const hasErrorLog = errors.some(m => m.includes('illisible') || m.includes('corrompu') || m.includes('inbox'))
    assert.ok(hasErrorLog, `Un log d'erreur sur fichier illisible attendu, reçu : ${JSON.stringify(errors)}`)
  })

  it("continue à traiter les fichiers suivants après un fichier corrompu", () => {
    // Deux fichiers : un corrompu et un valide
    try { for (const f of readdirSync(MY_INBOX)) rmSync(join(MY_INBOX, f)) } catch {}

    writeInbox('bad.json', 'NOT_JSON')
    const goodId = 'feature-after-corrupt-20260522-1400'
    writeInbox(`${goodId}.json`, {
      id: goodId,
      pipeline: 'feature',
      _bridgedFrom: '/home/.claude-pro',
      _bridgedAt: new Date().toISOString(),
    })

    const origErr = console.error
    console.error = () => {}
    cmdReceive([])
    console.error = origErr

    const stateFile = join(CONFIG_DIR_NAMED, 'runs', goodId, 'state.json')
    assert.ok(existsSync(stateFile), `Le run valide doit être importé même après un fichier corrompu`)
  })
})
