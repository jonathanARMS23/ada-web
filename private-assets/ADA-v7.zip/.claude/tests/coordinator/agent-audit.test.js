'use strict'
/**
 * tests/coordinator/agent-audit.test.js
 *
 * TDD — écrit AVANT l'implémentation finale de agent-audit.js (cf. CLAUDE.md :
 * "tester écrit les specs AVANT l'implémentation"). Fixtures d'agents factices
 * dans un tmpdir isolé — ne touche jamais aux vrais .claude/agents/*.md.
 */
const { test, describe, before, after } = require('node:test')
const assert = require('node:assert/strict')
const { mkdtempSync, mkdirSync, writeFileSync, rmSync, existsSync, readFileSync } = require('fs')
const { join } = require('path')
const { tmpdir } = require('os')

const {
  parseFrontmatter,
  normalizeTokens,
  jaccard,
  hasWhenToUseSignal,
  listAgentFiles,
  runAudit,
  loadBaseline,
  saveBaseline,
  checkBaseline,
  MIN_DESCRIPTION_LENGTH,
} = require(join(__dirname, '../../coordinator/agent-audit.js'))

function agentMd(name, description, body = `# ${name}\n\nCorps de l'agent.\n`) {
  return `---\nname: ${name}\ndescription: ${description}\n---\n\n${body}`
}

// ── parseFrontmatter ───────────────────────────────────────────────────────────

describe('parseFrontmatter', () => {
  test('extrait name et description du frontmatter', () => {
    const fm = parseFrontmatter(agentMd('foo', 'Un agent de test.'))
    assert.equal(fm.name, 'foo')
    assert.equal(fm.description, 'Un agent de test.')
  })

  test('renvoie null si aucun frontmatter (pas de --- en tête)', () => {
    assert.equal(parseFrontmatter('# Juste un titre\n\nDu texte.'), null)
  })

  test('renvoie null si le bloc --- ne se referme jamais', () => {
    assert.equal(parseFrontmatter('---\nname: foo\ndescription: bar'), null)
  })

  test('champ description vide → chaîne vide, pas une erreur', () => {
    const fm = parseFrontmatter('---\nname: foo\ndescription:\n---\n\nCorps.')
    assert.equal(fm.description, '')
  })
})

// ── normalizeTokens / jaccard ───────────────────────────────────────────────────

describe('normalizeTokens / jaccard', () => {
  test('normalise casse, accents et ponctuation', () => {
    const tokens = normalizeTokens('Expert Sécurité — Audit OWASP !')
    assert.deepEqual(tokens, ['expert', 'securite', 'audit', 'owasp'])
  })

  test('jaccard === 1 pour deux ensembles identiques', () => {
    const t = normalizeTokens('expert nestjs typescript')
    assert.equal(jaccard(t, t), 1)
  })

  test('jaccard === 0 pour deux ensembles disjoints', () => {
    assert.equal(jaccard(['a', 'b'], ['c', 'd']), 0)
  })

  test('jaccard === 1 pour deux ensembles vides (cas limite, pas de division par zéro)', () => {
    assert.equal(jaccard([], []), 1)
  })

  test('jaccard partiel entre deux descriptions proches', () => {
    const a = normalizeTokens('Coordinateur de consensus byzantin avec détection')
    const b = normalizeTokens('Coordinateur de consensus byzantin avec mitigation')
    const sim = jaccard(a, b)
    assert.ok(sim > 0.5 && sim < 1, `similarité attendue entre 0.5 et 1, reçu ${sim}`)
  })
})

// ── hasWhenToUseSignal ─────────────────────────────────────────────────────────

describe('hasWhenToUseSignal', () => {
  test('description avec mot-clé technique discriminant → true', () => {
    assert.equal(hasWhenToUseSignal('Expert NestJS pour la conception d\'API REST.'), true)
  })

  test('description avec marqueur contextuel explicite → true', () => {
    assert.equal(hasWhenToUseSignal('À utiliser quand une tâche générique se présente.'), true)
  })

  test('description sans mot-clé ni marqueur → false', () => {
    assert.equal(hasWhenToUseSignal('Agent polyvalent pour diverses tâches variées du quotidien.'), false)
  })

  test('description vide → false', () => {
    assert.equal(hasWhenToUseSignal(''), false)
  })
})

// ── runAudit (fixtures sur disque) ──────────────────────────────────────────────

describe('runAudit', () => {
  let dir

  before(() => {
    dir = mkdtempSync(join(tmpdir(), 'ada-agent-audit-'))
    writeFileSync(join(dir, 'README.md'), '# Pas un agent\n\nJuste une note.\n')
    writeFileSync(join(dir, 'good-agent.md'), agentMd(
      'good-agent',
      'Expert NestJS/TypeScript pour la conception et l\'implémentation d\'API REST robustes.'
    ))
    writeFileSync(join(dir, 'short-agent.md'), agentMd('short-agent', 'Trop court.'))
    writeFileSync(join(dir, 'vague-agent.md'), agentMd(
      'vague-agent',
      'Agent polyvalent pour diverses tâches variées et missions générales du quotidien.'
    ))
    writeFileSync(join(dir, 'dup-agent-a.md'), agentMd(
      'dup-agent-a',
      'Coordinateur de consensus byzantin avec détection des acteurs malveillants et mitigation des attaques réseau distribué complet.'
    ))
    writeFileSync(join(dir, 'dup-agent-b.md'), agentMd(
      'dup-agent-b',
      'Coordinateur de consensus byzantin avec détection des acteurs malveillants et mitigation des attaques système distribué complet.'
    ))
  })

  after(() => { rmSync(dir, { recursive: true, force: true }) })

  test('listAgentFiles ignore les non-.md et liste triée', () => {
    const files = listAgentFiles(dir)
    assert.deepEqual(files, [...files].sort())
    assert.ok(files.includes('good-agent.md'))
  })

  test('listAgentFiles renvoie [] si le répertoire n\'existe pas', () => {
    assert.deepEqual(listAgentFiles(join(dir, 'nope')), [])
  })

  test('README.md (sans frontmatter) est ignoré, pas compté comme agent', () => {
    const report = runAudit(dir)
    assert.ok(report.totalAgents < listAgentFiles(dir).length)
  })

  test('détecte une description trop courte', () => {
    const report = runAudit(dir)
    const found = report.issues.find(i => i.agent === 'short-agent' && i.type === 'short-description')
    assert.ok(found, 'short-agent doit être signalé short-description')
  })

  test('détecte une description qui ne dit pas quand l\'utiliser', () => {
    const report = runAudit(dir)
    const found = report.issues.find(i => i.agent === 'vague-agent' && i.type === 'no-when-to-use')
    assert.ok(found, 'vague-agent doit être signalé no-when-to-use')
  })

  test('détecte une paire de descriptions quasi-dupliquées', () => {
    const report = runAudit(dir)
    const dups = report.issues.filter(i => i.type === 'duplicate-description')
    const names = dups.map(i => i.agent)
    assert.ok(names.includes('dup-agent-a') || names.includes('dup-agent-b'), `duplicate-description attendu, reçu: ${JSON.stringify(dups)}`)
  })

  test('good-agent ne déclenche aucune issue', () => {
    const report = runAudit(dir)
    const goodIssues = report.issues.filter(i => i.agent === 'good-agent')
    assert.deepEqual(goodIssues, [])
  })

  test('countsByType et totalIssues cohérents avec issues.length', () => {
    const report = runAudit(dir)
    const sum = Object.values(report.countsByType).reduce((a, b) => a + b, 0)
    assert.equal(sum, report.totalIssues)
    assert.equal(report.totalIssues, report.issues.length)
  })

  test('MIN_DESCRIPTION_LENGTH est exporté et vaut 60', () => {
    assert.equal(MIN_DESCRIPTION_LENGTH, 60)
  })
})

// ── Baseline monotone-décroissante ──────────────────────────────────────────────

describe('checkBaseline — monotone-décroissante', () => {
  let baselineFile

  before(() => {
    const dir = mkdtempSync(join(tmpdir(), 'ada-agent-audit-baseline-'))
    baselineFile = join(dir, 'agent-audit-baseline.json')
  })

  after(() => {
    try { rmSync(baselineFile, { force: true }) } catch {}
  })

  test('premier run (pas de baseline) → created, écrit le fichier', () => {
    assert.equal(existsSync(baselineFile), false)
    const result = checkBaseline(15, baselineFile)
    assert.equal(result.status, 'created')
    assert.equal(result.maxIssues, 15)
    assert.equal(existsSync(baselineFile), true)
    const saved = JSON.parse(readFileSync(baselineFile, 'utf8'))
    assert.equal(saved.maxIssues, 15)
  })

  test('même nombre d\'issues → stable, baseline inchangée', () => {
    const result = checkBaseline(15, baselineFile)
    assert.equal(result.status, 'stable')
    assert.equal(result.maxIssues, 15)
  })

  test('moins d\'issues → improved, baseline abaissée', () => {
    const result = checkBaseline(10, baselineFile)
    assert.equal(result.status, 'improved')
    assert.equal(result.maxIssues, 10)
    assert.equal(loadBaseline(baselineFile).maxIssues, 10)
  })

  test('plus d\'issues que la baseline abaissée → regression, PAS de ré-augmentation', () => {
    const result = checkBaseline(12, baselineFile)
    assert.equal(result.status, 'regression')
    // La baseline ne remonte JAMAIS : elle reste à 10 malgré la régression détectée.
    assert.equal(loadBaseline(baselineFile).maxIssues, 10)
  })

  test('regression répétée ne corrompt jamais la baseline (idempotent)', () => {
    checkBaseline(20, baselineFile)
    checkBaseline(18, baselineFile)
    assert.equal(loadBaseline(baselineFile).maxIssues, 10)
  })

  test('saveBaseline direct est lisible par loadBaseline', () => {
    const dir = mkdtempSync(join(tmpdir(), 'ada-agent-audit-baseline2-'))
    const f = join(dir, 'b.json')
    saveBaseline(3, f)
    assert.equal(loadBaseline(f).maxIssues, 3)
    rmSync(dir, { recursive: true, force: true })
  })

  test('loadBaseline renvoie null si le fichier n\'existe pas', () => {
    assert.equal(loadBaseline(join(tmpdir(), 'ada-agent-audit-does-not-exist.json')), null)
  })
})
