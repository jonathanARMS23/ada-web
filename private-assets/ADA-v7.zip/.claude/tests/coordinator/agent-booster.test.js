#!/usr/bin/env node
'use strict'
const { test, describe } = require('node:test')
const assert = require('node:assert/strict')
const { join } = require('path')

const BOOSTER_JS = join(__dirname, '../../coordinator/agent-booster.js')

// Charger sans cache pour avoir un état propre
delete require.cache[require.resolve(BOOSTER_JS)]
const { canBoost, applyRule, detectRules, RULES } = require(BOOSTER_JS)

// ─── RULES.var-to-const ───────────────────────────────────────────────────────

describe('var-to-const', () => {
  test('detect : vrai si code contient var', () => {
    assert.ok(RULES['var-to-const'].detect('var x = 1'))
    assert.ok(RULES['var-to-const'].detect('function f() { var y = 2 }'))
  })

  test('detect : faux si code sans var', () => {
    assert.ok(!RULES['var-to-const'].detect('const x = 1'))
    assert.ok(!RULES['var-to-const'].detect('let y = 2; const z = 3'))
  })

  test('apply : transforme var non-réassigné en const', () => {
    const code = 'var x = 1\nconsole.log(x)'
    const result = applyRule(code, 'var-to-const')
    assert.ok(result.includes('const x ='), `résultat: ${result}`)
    assert.ok(!result.includes('var x'))
  })

  test('apply : transforme var réassigné en let', () => {
    const code = 'var count = 0\ncount = count + 1'
    const result = applyRule(code, 'var-to-const')
    assert.ok(result.includes('let count ='), `résultat: ${result}`)
    assert.ok(!result.includes('var count'))
  })
})

// ─── RULES.remove-console ─────────────────────────────────────────────────────

describe('remove-console', () => {
  test('detect : vrai si console.log présent', () => {
    assert.ok(RULES['remove-console'].detect('console.log("test")'))
    assert.ok(RULES['remove-console'].detect('function f() { console.debug("x") }'))
  })

  test('detect : faux si pas de console.log/debug/warn', () => {
    assert.ok(!RULES['remove-console'].detect('const x = 1'))
    assert.ok(!RULES['remove-console'].detect('console.error("err")'))
  })

  test('apply : supprime les lignes console.log', () => {
    const code = 'const x = 1\nconsole.log(x)\nreturn x'
    const result = applyRule(code, 'remove-console')
    assert.ok(!result.includes('console.log'), `résultat: ${result}`)
    assert.ok(result.includes('const x = 1'))
    assert.ok(result.includes('return x'))
  })

  test('apply : supprime console.debug et console.warn aussi', () => {
    const code = 'console.debug("d")\nconsole.warn("w")\nconst ok = true'
    const result = applyRule(code, 'remove-console')
    assert.ok(!result.includes('console.debug'))
    assert.ok(!result.includes('console.warn'))
    assert.ok(result.includes('const ok'))
  })
})

// ─── RULES.add-strict ─────────────────────────────────────────────────────────

describe('add-strict', () => {
  test("detect : vrai si 'use strict' absent", () => {
    assert.ok(RULES['add-strict'].detect('const x = 1'))
    assert.ok(RULES['add-strict'].detect('function f() {}'))
  })

  test("detect : faux si 'use strict' présent", () => {
    assert.ok(!RULES['add-strict'].detect("'use strict'\nconst x = 1"))
    assert.ok(!RULES['add-strict'].detect('"use strict"\nconst x = 1'))
  })

  test("apply : ajoute 'use strict' en tête", () => {
    const code = 'const x = 1'
    const result = applyRule(code, 'add-strict')
    assert.ok(result.startsWith("'use strict'"), `résultat: ${result}`)
    assert.ok(result.includes('const x = 1'))
  })
})

// ─── RULES.normalize-quotes ───────────────────────────────────────────────────

describe('normalize-quotes', () => {
  test('apply : double quotes → single quotes', () => {
    const code = 'const name = "hello"'
    const result = applyRule(code, 'normalize-quotes')
    assert.ok(result.includes("'hello'"), `résultat: ${result}`)
    assert.ok(!result.includes('"hello"'))
  })

  test('detect : faux si template literals présents', () => {
    // Avec template literal → ne pas normaliser (risque de casser)
    assert.ok(!RULES['normalize-quotes'].detect('const s = `hello ${name}`'))
  })
})

// ─── RULES.trim-trailing-whitespace ──────────────────────────────────────────

describe('trim-trailing-whitespace', () => {
  test('detect : vrai si espaces en fin de ligne', () => {
    assert.ok(RULES['trim-trailing-whitespace'].detect('const x = 1   \nconst y = 2'))
  })

  test('detect : faux si pas d\'espaces de fin', () => {
    assert.ok(!RULES['trim-trailing-whitespace'].detect('const x = 1\nconst y = 2'))
  })

  test('apply : supprime les espaces de fin', () => {
    const code = 'const x = 1   \nconst y = 2  \nreturn x'
    const result = applyRule(code, 'trim-trailing-whitespace')
    for (const line of result.split('\n')) {
      assert.ok(!line.endsWith(' '), `Ligne avec espace de fin : "${line}"`)
    }
  })
})

// ─── RULES.add-semicolons ─────────────────────────────────────────────────────

describe('add-semicolons', () => {
  test('detect : vrai si statement sans point-virgule', () => {
    assert.ok(RULES['add-semicolons'].detect('const x = 1'))
    assert.ok(RULES['add-semicolons'].detect('return value'))
  })

  test('apply : ajoute point-virgule manquant', () => {
    const code = 'const x = 1\nreturn x'
    const result = applyRule(code, 'add-semicolons')
    assert.ok(result.includes('const x = 1;'), `résultat: ${result}`)
  })
})

// ─── canBoost ─────────────────────────────────────────────────────────────────

describe('canBoost', () => {
  test('code avec var → boosted:true, rule:var-to-const', () => {
    const result = canBoost({ type: 'backend', content: 'var x = 1\nvar y = 2\nreturn x + y' })
    assert.ok(result.boosted, `boosted devrait être true, confidence=${result.confidence}`)
    assert.equal(result.rule, 'var-to-const')
    assert.ok(result.confidence > 0)
  })

  test('code propre → boosted:false', () => {
    // Code avec 'use strict', const, semicolons, single quotes → aucune règle applicable
    const cleanCode = "'use strict';\nconst x = 1;\nconst y = 2;\nreturn x + y;"
    const result = canBoost({ type: 'backend', content: cleanCode })
    assert.ok(!result.boosted, `boosted devrait être false pour code propre, confidence=${result.confidence}`)
  })

  test('content vide → boosted:false, confidence:0', () => {
    const result = canBoost({ type: 'backend', content: '' })
    assert.equal(result.boosted, false)
    assert.equal(result.confidence, 0)
  })

  test('content undefined → boosted:false, confidence:0', () => {
    const result = canBoost({ type: 'backend' })
    assert.equal(result.boosted, false)
    assert.equal(result.confidence, 0)
  })

  test('code avec plusieurs règles applicables booste la confidence', () => {
    // var + console.log + pas de 'use strict' → 3 règles applicables
    const code = "var x = 1\nconsole.log(x)\nreturn x"
    const result = canBoost({ type: 'backend', content: code })
    assert.ok(result.boosted, `Plusieurs règles applicables → boosted devrait être true`)
    assert.ok(result.confidence > 0)
  })
})

// ─── detectRules ─────────────────────────────────────────────────────────────

describe('detectRules', () => {
  test('retourne les règles applicables', () => {
    const code = "var x = 1\nconsole.log(x)"
    const rules = detectRules(code)
    const names = rules.map(r => r.name)
    assert.ok(names.includes('var-to-const'))
    assert.ok(names.includes('remove-console'))
  })

  test('retourne [] si aucune règle applicable', () => {
    // Code complet : use strict, const, semicolons, single quotes, pas d'espaces de fin
    const code = "'use strict';\nconst x = 1;\nconst y = 'hello';\nreturn x;"
    const rules = detectRules(code)
    assert.equal(rules.length, 0, `Règles détectées (inattendues): ${rules.map(r => r.name).join(', ')}`)
  })
})

// ─── applyRule erreur ─────────────────────────────────────────────────────────

describe('applyRule', () => {
  test('lève une erreur pour règle inconnue', () => {
    assert.throws(() => applyRule('const x = 1', 'unknown-rule'), /Règle inconnue/)
  })
})
