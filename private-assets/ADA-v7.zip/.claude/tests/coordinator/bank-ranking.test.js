#!/usr/bin/env node
'use strict'
/**
 * tests/coordinator/bank-ranking.test.js — non-régression sur 2 bugs de ranking
 * trouvés et corrigés le 2026-08-28 (session de reprise ADR-023 étape 6, régression
 * flywheel `tdd-specs`/`stripe-webhook`). Voir bank.js:retrieve() et
 * bank-ranking.js:scoreTrajectory() pour le détail des fixes.
 *
 * Bug 1 — mélange d'échelles TF-IDF/overlap : `idx.search(query, limit)` ne
 * retournait un vrai score TF-IDF que pour le top-`limit` déjà trouvé par TF-IDF ;
 * tout candidat hors de ce sous-ensemble retombait sur un score de secours non
 * normalisé (comptage entier de tokens/tags partagés) qui écrase systématiquement
 * un vrai score TF-IDF (fraction < 1). Fix : interroger l'index avec la taille du
 * pool entier (coût identique, `idx.search` scanne déjà tout en interne).
 *
 * Bug 2 — items `phase=topic` sans aucune pertinence de contenu (content=0) qui
 * gardaient un score positif via le seul bonus de récence/verdict (×0.7 sur le
 * score composite), assez pour battre une trajectoire spécifique moins récente
 * mais réellement pertinente. Fix : un topic à content=0 ne garde qu'un plancher
 * minimal (0.05), jamais assez pour battre un vrai match de contenu.
 */

const { test, describe, before, after, beforeEach } = require('node:test')
const assert = require('node:assert/strict')
const { mkdirSync, rmSync, existsSync, unlinkSync } = require('fs')
const { join } = require('path')

const TMP = join(__dirname, '../../..', '.test-tmp-bank-ranking')
const BANK_JS = join(__dirname, '../../coordinator/bank.js')

let bank
function loadBank() {
  delete require.cache[require.resolve(BANK_JS)]
  process.env.CLAUDE_CONFIG_DIR = TMP
  const mod = require(BANK_JS)
  mod._resetDB()
  return mod
}

function cleanDB() {
  const dbPath = join(TMP, 'coordinator', 'bank.db')
  for (const suffix of ['', '-wal', '-shm']) {
    try { unlinkSync(dbPath + suffix) } catch {}
  }
}

before(() => { mkdirSync(join(TMP, 'coordinator'), { recursive: true }) })
after(() => { try { rmSync(TMP, { recursive: true }) } catch {} })
beforeEach(() => {
  cleanDB()
  bank = loadBank()
})

// ─── Bug 1 — mélange d'échelles TF-IDF/overlap ────────────────────────────────

describe('retrieve() — TF-IDF sur tout le pool, pas seulement le top-limit', () => {
  test('une trajectoire pertinente au-delà du top-limit brut garde un vrai score TF-IDF, pas le fallback overlap', () => {
    // Un candidat spécifique et pertinent ("webhook stripe") noyé derrière plusieurs
    // candidats génériques qui partagent des tags larges avec la requête (backend) —
    // exactement le scénario qui faisait perdre l'ancre flywheel stripe-webhook.
    bank.store('backend', 'nestjs', 'success', 'pagination keyset cursor implémentée')
    bank.store('backend', 'nestjs', 'success', 'montants stockés en cents bigint')
    bank.store('backend', 'nestjs', 'success', 'soft-delete via deleted_at')
    bank.store('backend', 'nestjs', 'success', 'outbox transactionnel sur mutation')
    bank.store('backend', 'nestjs', 'success', 'stripe service + webhook controller')

    const results = bank.retrieve('webhook stripe service backend nestjs paiement', { limit: 5 })
    const target = results.find(r => r.summary.includes('stripe service + webhook'))
    assert.ok(target, 'la trajectoire stripe doit apparaître dans le top-5')
    assert.ok(target._content > 0.3,
      `content doit refléter un vrai match TF-IDF (>0.3), pas un fallback overlap écrasé — reçu ${target._content}`)
  })
})

// ─── Bug 2 — topic à content=0 ne doit jamais battre un match de contenu réel ──

describe('scoreTrajectory() — un topic sans pertinence de contenu ne bat jamais un match réel', () => {
  test('topic avec content=0 (queryTokens sans overlap) → score plancher, jamais > un match de contenu positif', () => {
    const topicZeroContent = {
      phase: 'topic', agent: 'system', verdict: 'success',
      summary: 'Domaine récurrent: React — 42 sessions, cohérence 100%.',
      tags: [], ts: new Date().toISOString(), // très récent → bonus d'âge max
    }
    const relevantOld = {
      phase: 'specs', agent: 'tester', verdict: 'success',
      summary: 'specs TDD pour auth stripe',
      tags: [], ts: new Date(Date.now() - 60 * 24 * 3600 * 1000).toISOString(), // 60j — bonus d'âge nul
    }
    const queryTokens = ['ecrire', 'specs', 'tdd', 'avant', 'implementation']

    const scoreTopic    = bank.scoreTrajectory(topicZeroContent, queryTokens, null, null, null, null)
    const scoreRelevant = bank.scoreTrajectory(relevantOld, queryTokens, null, null, null, null)

    assert.ok(topicZeroContent._content === 0, 'ce topic ne doit partager aucun token avec la requête (fixture)')
    assert.ok(relevantOld._content > 0, 'la trajectoire "specs TDD" doit avoir un content > 0 (fixture)')
    assert.ok(scoreTopic <= 0.05, `topic hors-sujet doit avoir un score plancher (≤0.05) — reçu ${scoreTopic}`)
    assert.ok(scoreRelevant > scoreTopic,
      `un match de contenu réel doit battre un topic hors-sujet même très récent — relevant=${scoreRelevant} topic=${scoreTopic}`)
  })

  test('topic AVEC pertinence de contenu (content > 0) garde le comportement ×0.7 existant', () => {
    const topicWithContent = {
      phase: 'topic', agent: 'system', verdict: 'success',
      summary: 'Domaine récurrent: Stripe Webhooks — 5 sessions.',
      tags: [], ts: new Date().toISOString(),
    }
    const queryTokens = ['stripe', 'webhook']
    const score = bank.scoreTrajectory(topicWithContent, queryTokens, null, null, null, null)
    assert.ok(topicWithContent._content > 0, 'fixture doit partager des tokens avec la requête')
    // content(2, overlap brut "stripe"+"webhook") + age(~2) + verdict(0.5) = 4.5, ×0.7 = 3.15
    assert.ok(score > 1, `un topic pertinent garde un score substantiel (×0.7, pas le plancher 0.05) — reçu ${score}`)
  })
})
