#!/usr/bin/env node
'use strict'
/**
 * bank-recall-bench.test.js — Preuve "bench-v2" du ROI mémoire en config mesurable :
 * specs IMPLICITES + distracteurs + assertions sur conventions tacites.
 *
 * Au lieu de scorer la banque runtime (non déterministe), on isole un
 * CLAUDE_CONFIG_DIR temporaire, on seede des conventions (cibles + distracteurs),
 * on appelle le VRAI `bank.js recall` en sous-processus, puis on score
 * precision/recall/F1 avec les MÊMES fonctions pures que bench-v2
 * (recallPrecision, parseRecallConventions). C'est la config décrite dans la
 * mémoire ada_bench_v2 (seule où le ROI mémoire est mesurable).
 *
 * Chaque correctif P0/P1 ajoute ici un cas avec un SEUIL d'amélioration prouvé.
 */

const { test, describe, before, after, beforeEach } = require('node:test')
const assert = require('node:assert/strict')
const { mkdirSync, rmSync, existsSync } = require('fs')
const { join } = require('path')
const { spawnSync } = require('child_process')

const ROOT = join(__dirname, '../../..')
const BANK_JS = join(__dirname, '../../coordinator/bank.js')
const { recallPrecision, parseRecallConventions } = require(join(__dirname, '../../coordinator/bench-v2.js'))

const TMP = join(ROOT, '.test-tmp-recall-bench')

/** Exécute le CLI bank.js dans un CLAUDE_CONFIG_DIR isolé, Ollama forcé down. */
function bankCli(args, env = {}) {
  return spawnSync('node', [BANK_JS, ...args], {
    encoding: 'utf8',
    timeout: 30000,
    env: { ...process.env, CLAUDE_CONFIG_DIR: TMP, OLLAMA_URL: 'http://127.0.0.1:1', ...env },
  })
}

/** Seede une liste de conventions (texte + opts.tags/scope). */
function seed(conventions) {
  for (const c of conventions) {
    const tags = ['convention', ...(c.tags || [])].join(',')
    bankCli(['store', 'convention', 'project', 'success', c.text, '--tags', tags])
  }
}

/** Recall + parse + score F1 vs groundTruth. */
function recallScore(query, groundTruth) {
  const r = bankCli(['recall', query])
  const conventions = parseRecallConventions(r.stdout || '')
  const m = recallPrecision(conventions, groundTruth, [])
  return { ...m, retrieved: conventions }
}

before(() => { mkdirSync(join(TMP, 'coordinator'), { recursive: true }) })
after(() => { try { rmSync(TMP, { recursive: true }) } catch {} })
beforeEach(() => {
  try { rmSync(TMP, { recursive: true }) } catch {}
  mkdirSync(join(TMP, 'coordinator'), { recursive: true })
})

describe('bench-recall — config mesurable (specs implicites + distracteurs)', () => {
  test('P1-2 — recall reste fonctionnel en mode dégradé (Ollama down) : recall des cibles = 1.0', () => {
    // Specs IMPLICITES : le prompt parle d'un schéma de table SaaS sans nommer les conventions.
    seed([
      { text: 'uuid primary key sur toutes les tables métier' },
      { text: 'workspace_id obligatoire pour le multi-tenant' },
      { text: 'timestamps created_at updated_at sur chaque table' },
    ])
    const m = recallScore('crée le schéma de la table invoices multi-tenant', ['uuid', 'workspace_id', 'timestamps'])
    // P1-2 ne change pas la pertinence ; il garantit juste que le mode dégradé reste fonctionnel.
    assert.equal(m.recall, 1, `recall des conventions cibles attendu 1.0, obtenu ${m.recall} (retrieved=${JSON.stringify(m.retrieved)})`)
  })

  test('P1-1 — convention exprimée en acronyme ("TS") récupérée par prompt en toutes lettres ("typescript")', () => {
    // Specs IMPLICITES : le prompt parle de typage TypeScript sans dire "TS".
    // Avant P1-1, "TS" était tokenisé en [] → recall = 0 sur cette convention.
    seed([
      { text: 'Pas de any TS, préfère unknown puis narrow' },          // cible (en acronyme)
      { text: 'Conventional Commits obligatoires' },                    // distracteur
    ])
    const m = recallScore('ajoute le typage typescript strict sur le module de paiement', ['any ts'])
    assert.equal(m.recall, 1, `la convention TS doit être récupérée via "typescript" (retrieved=${JSON.stringify(m.retrieved)})`)
  })

  test('P0-2 — leçons hors-sujet exclues : precision élevée malgré des distracteurs récents', () => {
    // 2 conventions cibles + plusieurs LEÇONS récentes hors-sujet (distracteurs).
    seed([
      { text: 'API REST versionnée /v1 obligatoire' },
      { text: 'API retourne les erreurs au format RFC7807' },
    ])
    // Distracteurs : leçons récentes mais sans rapport avec une API.
    bankCli(['store', 'frontend', 'nextjs', 'success', 'Ajouté des skeleton loaders au dashboard'])
    bankCli(['store', 'devops', 'devops', 'success', 'Configuré le healthcheck docker compose postgres'])

    const m = recallScore('conçois le contrat de l’API REST du service de facturation', ['api rest', 'rfc7807'])
    // Les distracteurs ne doivent PAS gonfler les faux positifs : precision haute.
    assert.ok(m.precision >= 0.66, `precision attendue ≥ 0.66, obtenue ${m.precision} (retrieved=${JSON.stringify(m.retrieved)})`)
    assert.equal(m.recall, 1, `les 2 conventions API doivent être récupérées (retrieved=${JSON.stringify(m.retrieved)})`)
  })
})
