#!/usr/bin/env node
'use strict'
/**
 * bank-recall.test.js — Tests de non-régression de la couche recall/injection.
 *
 * Chaque test correspond à une repro d'audit transformée en garde-fou permanent :
 *   P1-2 — pas de fallback TF-IDF silencieux : health() observable + signal dégradé
 *   P1-1 — tokenizer : acronymes techniques préservés + normalisation indexation
 *   P0-2 — pertinence-contenu seuillée ; récence/verdict = tie-breakers seulement
 *   P0-1 — conventions typées par portée (global injecté ; domaine gaté sémantique)
 *   P0-3 — dédup/supersede sémantique au store
 */

const { test, describe, before, after, beforeEach } = require('node:test')
const assert = require('node:assert/strict')
const { mkdirSync, rmSync, existsSync, writeFileSync, unlinkSync } = require('fs')
const { join } = require('path')

const TMP = join(__dirname, '../../..', '.test-tmp-bank-recall')
const BANK_JS = join(__dirname, '../../coordinator/bank.js')

let bank
function loadBank() {
  delete require.cache[require.resolve(BANK_JS)]
  process.env.CLAUDE_CONFIG_DIR = TMP
  // Force Ollama indisponible de façon déterministe (port loopback fermé).
  process.env.OLLAMA_URL = 'http://127.0.0.1:1'
  const mod = require(BANK_JS)
  mod._resetDB()
  return mod
}

function cleanDB() {
  const dbPath = join(TMP, 'coordinator', 'bank.db')
  for (const f of [dbPath, dbPath + '-wal', dbPath + '-shm']) {
    if (existsSync(f)) { try { unlinkSync(f) } catch {} }
  }
}

before(() => { mkdirSync(join(TMP, 'coordinator'), { recursive: true }) })
after(() => { try { rmSync(TMP, { recursive: true }) } catch {} })
beforeEach(() => {
  const f = join(TMP, 'coordinator', 'bank-state.json')
  writeFileSync(f, JSON.stringify({ version: 1, trajectories: [], insights: null, updatedAt: new Date().toISOString() }, null, 2))
  cleanDB()
  bank = loadBank()
})

// ─── P1-2 — pas de fallback silencieux ─────────────────────────────────────────

describe('P1-2 — recall observable (pas de fallback TF-IDF silencieux)', () => {
  test('health() reporte Ollama DOWN quand le port loopback est fermé', async () => {
    const h = await bank.health()
    assert.equal(h.ollama, false, 'Ollama doit être détecté down (port 1 fermé)')
    assert.ok('coverage' in h, 'health doit exposer coverage')
    assert.ok('embedModel' in h, 'health doit exposer le modèle')
  })

  test('buildRecallBlockAsync signale le mode dégradé (degraded=true) sans Ollama', async () => {
    bank.store('convention', 'project', 'success', 'RLS Supabase obligatoire sur toutes les tables', { tags: ['convention'] })
    const { block, degraded } = await bank.buildRecallBlockAsync('rls supabase tables sécurité')
    assert.equal(degraded, true, 'le mode dégradé doit être signalé explicitement')
    assert.match(block, /RLS Supabase/, 'le bloc doit rester fonctionnel en mode dégradé')
  })

  test('health() trace lastRecallDegraded après un recall dégradé', async () => {
    bank.store('convention', 'project', 'success', 'Conventional Commits obligatoires', { tags: ['convention'] })
    await bank.buildRecallBlockAsync('commits conventional format')
    const h = await bank.health()
    assert.ok(h.lastRecallDegraded, 'lastRecallDegraded doit être renseigné')
  })

  test('_assembleRecallBlock est pur : même sortie sync/async pour les mêmes résultats', () => {
    const results = [
      { phase: 'convention', summary: 'RLS Supabase obligatoire', tags: ['convention'] },
      { phase: 'backend', summary: 'rls policy ajoutée au schema', tags: ['backend', 'rls'] },
    ]
    const block = bank._assembleRecallBlock(results, 'rls schema')
    assert.match(block, /Conventions:/)
    assert.match(block, /RLS Supabase/)
  })
})

// ─── P1-1 — tokenizer : acronymes + normalisation ──────────────────────────────

describe('P1-1 — tokenizer (acronymes techniques + normalisation)', () => {
  const { tokenize, normalizeToken } = require(join(__dirname, '../../coordinator/embeddings.js'))

  test('acronymes techniques courts ne sont PLUS jetés (repro : "TS" → [])', () => {
    // Avant le fix : tokenize("TS") === []  →  convention "Pas de any TS" invisible.
    assert.deepEqual(tokenize('TS'), ['typescript'], 'TS doit survivre et se normaliser')
    assert.ok(tokenize('db ci ui').length === 3, 'db/ci/ui préservés')
  })

  test('formes équivalentes unifiées en indexation ET requête (ts ≡ typescript)', () => {
    assert.equal(normalizeToken('ts'), 'typescript')
    // Le prompt "typescript" et la convention "TS" partagent désormais un token.
    const convTokens = new Set(tokenize('Pas de any TS prefere unknown'))
    const queryTokens = tokenize('typescript any typing')
    assert.ok(queryTokens.some(q => convTokens.has(q)), 'overlap ts↔typescript attendu')
  })

  test('auth ≡ authentication (repro audit : non unifiés avant fix)', () => {
    assert.equal(normalizeToken('auth'), 'authentication')
    const a = new Set(tokenize('auth jwt flow'))
    const b = tokenize('authentication strategy')
    assert.ok(b.some(t => a.has(t)), 'auth et authentication doivent matcher')
  })

  test('regression : convention "TS" récupérable par une requête "typescript"', () => {
    bank.store('convention', 'project', 'success', 'Pas de any TS, préfère unknown puis narrow', { tags: ['convention'] })
    const block = bank.buildRecallBlock('typescript typing rules any')
    assert.match(block, /Pas de any TS/, 'la convention TS doit ressortir sur une requête typescript')
  })
})

// ─── P0-2 — pertinence-contenu vs bruit récence/verdict ────────────────────────

describe('P0-2 — seuillage contenu (récence/verdict = tie-breakers seulement)', () => {
  test('contentRelevance ignore récence/verdict : entrée hors-sujet → contenu 0', () => {
    const now = new Date().toISOString()
    const offTopic = { summary: 'RLS Supabase obligatoire', tags: ['convention'], ts: now, verdict: 'success' }
    const onTopic  = { summary: 'typescript any unknown narrow', tags: ['convention'], ts: now, verdict: 'success' }
    const qt = ['typescript', 'any']
    assert.equal(bank.contentRelevance(offTopic, qt, null, null), 0, 'hors-sujet → contenu nul (pas de plancher récence)')
    assert.ok(bank.contentRelevance(onTopic, qt, null, null) > 0, 'on-topic → contenu > 0')
  })

  test('repro audit : une LEÇON hors-sujet ne survit PAS sur récence seule', () => {
    // Leçon récente mais hors-sujet : avant P0-2 elle franchissait score>0 via récence(2)+verdict(0.5).
    bank.store('backend', 'nestjs', 'success', 'Configuré le healthcheck docker compose postgres', {})
    bank.store('convention', 'project', 'success', 'Pas de any TS prefere unknown', { tags: ['convention'] })
    const block = bank.buildRecallBlock('typescript typing any')
    assert.doesNotMatch(block, /healthcheck docker/, 'la leçon docker hors-sujet ne doit pas être injectée')
    assert.match(block, /Pas de any TS/, 'la convention pertinente reste injectée')
  })

  test('repro audit : conventions globales NON tronquées par le limit (8 conv, limit défaut)', () => {
    const convs = [
      'API REST versionnee /v1 obligatoire',
      'API doit valider les inputs avec zod',
      'API retourne erreurs au format RFC7807',
      'Pas de any TS',
      'RLS Supabase obligatoire sur toutes les tables',
      'Conventional commits obligatoires',
      'Tests avant implementation TDD',
      'uuid PK sur toutes les tables',
    ]
    for (const c of convs) bank.store('convention', 'project', 'success', c, { tags: ['convention'] })
    // Query "api" → on-topic. Avant P0-2 : limit=6 tronquait, perdait RLS/any.
    const block = bank.buildRecallBlock('api endpoint design rest')
    const injected = (block.match(/^- /gm) || []).length
    assert.ok(injected >= 8, `les 8 conventions doivent survivre au limit (injectées=${injected})`)
    assert.match(block, /RLS Supabase/, 'RLS (convention globale) ne doit pas être évincée par le volume')
  })
})

// ─── P0-3 — dédup / supersession sémantique des conventions ────────────────────
//
// Matrice de calibration des seuils (Jaccard/overlap sur tokens-SUJET, polarité
// retirée — voir _convSimilarity / _polarity dans bank.js) :
//   "Jamais de any en TS" vs "Pas de any en TS"            → jac=1.00          → DEDUP
//   "RLS … toutes les tables" vs "RLS activé … Supabase"   → jac=0.67          → DEDUP
//   "Conventional Commits" vs "Utiliser des Conv. Commits" → jac=0.50          → DEDUP
//   "RLS … tables" vs "uuid PK … tables"                   → jac=0.25          → distinct
//   "Jamais any" vs "Utilise any si build bloque"          → ovl=0.50 neg↔pos  → CONTRADICTION
// DEDUP_TAU=0.5 sépare les reformulations des conventions distinctes ; CONTRA_OVL_TAU=0.5
// + polarité opposée capte les contradictions robustement à l'écart de longueur.

describe('P0-3 — dédup/supersession sémantique au store', () => {
  test('(a) deux conventions quasi-identiques → une seule survit (ancienne archivée)', () => {
    const r1 = bank.storeConvention('Jamais de any en TypeScript')
    const r2 = bank.storeConvention('Pas de any en TypeScript')

    assert.equal(r1.skipped, false, 'la 1re convention est stockée')
    assert.equal(r2.skipped, false, 'la 2e (reformulation) est stockée')
    assert.equal(r2.superseded, r1.id, 'la 2e doit superséder la 1re (last-write-wins)')

    // Le recall ne doit injecter QU'UNE seule règle "any" — la plus récente.
    const block = bank.buildRecallBlock('typescript any typing')
    const anyLines = (block.match(/any/gi) || []).length
    assert.match(block, /Pas de any en TypeScript/, 'la nouvelle convention est injectée')
    assert.doesNotMatch(block, /Jamais de any en TypeScript/, 'l’ancienne (archivée) n’est PLUS injectée')
    assert.equal(anyLines, 1, `une seule règle "any" doit subsister (trouvé ${anyLines})`)
  })

  test('(b) deux conventions contradictoires → warning émis, aucune archivée', () => {
    const stderr = []
    const orig = process.stderr.write.bind(process.stderr)
    process.stderr.write = (s) => { stderr.push(String(s)); return true }
    let r1, r2
    try {
      r1 = bank.storeConvention('Jamais de any en TypeScript')
      r2 = bank.storeConvention('Utilise any temporairement si le typage bloque le build')
    } finally {
      process.stderr.write = orig
    }

    assert.equal(r2.superseded, null, 'une contradiction ne doit PAS superséder automatiquement')
    assert.ok(Array.isArray(r2.warnings) && r2.warnings.length >= 1, 'un warning de contradiction doit être retourné')
    assert.equal(r2.warnings[0].conflictId, r1.id, 'le warning pointe la convention en conflit')
    assert.ok(stderr.some(l => /CONTRADICTOIRE/.test(l)), 'un warning doit être émis sur stderr')

    // Les DEUX restent en base (non archivées) — arbitrage humain, pas de perte.
    const block = bank.buildRecallBlock('typescript any typing build')
    assert.match(block, /Jamais de any/, 'la règle existante reste injectée (non archivée)')
    assert.match(block, /Utilise any temporairement/, 'la nouvelle règle est aussi injectée')
  })

  test('(c) une convention archivée n’est PLUS injectée au recall', () => {
    const r1 = bank.storeConvention('RLS Supabase obligatoire sur toutes les tables')
    const r2 = bank.storeConvention('RLS activé sur toutes les tables Supabase')
    assert.equal(r2.superseded, r1.id, 'la reformulation RLS supersède l’originale')

    const block = bank.buildRecallBlock('rls supabase tables securite')
    assert.match(block, /RLS activé sur toutes les tables Supabase/, 'la version récente est injectée')
    assert.doesNotMatch(block, /RLS Supabase obligatoire/, 'la version archivée est exclue du recall')

    // _recallConventions exclut aussi l’archivée (voie conventions complètes).
    const blockAlt = bank.buildRecallBlock('database tables')
    assert.doesNotMatch(blockAlt, /RLS Supabase obligatoire/, 'archivée jamais injectée, quel que soit le query')
  })

  test('(d) deux conventions DISTINCTES on-topic coexistent (pas de faux supersede)', () => {
    const r1 = bank.storeConvention('RLS Supabase obligatoire sur toutes les tables')
    const r2 = bank.storeConvention('uuid PK + timestamps sur toutes les tables métier')
    assert.equal(r2.superseded, null, 'deux règles distinctes ne se supersèdent pas (jaccard < τ)')
    assert.equal(r2.warnings, undefined, 'pas de contradiction entre règles distinctes')

    const block = bank.buildRecallBlock('database schema tables')
    assert.match(block, /RLS Supabase/, 'RLS reste injectée')
    assert.match(block, /uuid PK/, 'uuid reste injectée')
  })

  test('(e) idempotence : re-seeder les MÊMES conventions = no-op (aucun archivage en boucle)', () => {
    const a1 = bank.storeConvention('Jamais de any en TypeScript')
    const b1 = bank.storeConvention('RLS Supabase obligatoire sur toutes les tables')

    // Second passage identique → skip exact, pas de supersede, pas d’archivage.
    const a2 = bank.storeConvention('Jamais de any en TypeScript')
    const b2 = bank.storeConvention('RLS Supabase obligatoire sur toutes les tables')

    assert.equal(a2.skipped, true, 'doublon exact → skip')
    assert.equal(b2.skipped, true, 'doublon exact → skip')
    assert.equal(a2.id, a1.id, 'skip renvoie l’id existant (idempotent)')
    assert.equal(b2.id, b1.id, 'skip renvoie l’id existant (idempotent)')

    // Le recall reste cohérent : exactement 2 conventions, aucune archivée.
    const block = bank.buildRecallBlock('typescript any rls supabase tables')
    assert.match(block, /Jamais de any/, 'any toujours injectée après re-seed')
    assert.match(block, /RLS Supabase/, 'rls toujours injectée après re-seed')
  })
})
