#!/usr/bin/env node
'use strict'
/**
 * tests/coordinator/bank-stream.test.js — Tests retrieveStream + collectStream
 */
const { test, describe, before, after, beforeEach } = require('node:test')
const assert = require('node:assert/strict')
const { EventEmitter } = require('node:events')
const { mkdirSync, rmSync, existsSync, writeFileSync, unlinkSync } = require('fs')
const { join } = require('path')

const TMP = join(__dirname, '../../..', '.test-tmp-bank-stream')
const BANK_JS = join(__dirname, '../../coordinator/bank.js')

let bank

function loadBank() {
  delete require.cache[require.resolve(BANK_JS)]
  process.env.CLAUDE_CONFIG_DIR = TMP
  const mod = require(BANK_JS)
  mod._resetDB()
  return mod
}

function cleanDB() {
  const dbPath = join(TMP, 'coordinator', 'bank.db')
  if (existsSync(dbPath)) {
    try { unlinkSync(dbPath) } catch {}
    try { unlinkSync(dbPath + '-wal') } catch {}
    try { unlinkSync(dbPath + '-shm') } catch {}
  }
}

before(() => { mkdirSync(join(TMP, 'coordinator'), { recursive: true }) })
after(() => { try { rmSync(TMP, { recursive: true }) } catch {} })

beforeEach(() => {
  const f = join(TMP, 'coordinator', 'bank-state.json')
  writeFileSync(f, JSON.stringify({
    version: 1, trajectories: [], insights: null, updatedAt: new Date().toISOString()
  }, null, 2))
  cleanDB()
  bank = loadBank()
})

// ── Helper : attend la résolution d'un stream ─────────────────────────────────

function drainStream(stream) {
  return new Promise((resolve, reject) => {
    const items = []
    stream.on('data', r => items.push(r))
    stream.on('end', total => resolve({ items, total }))
    stream.on('error', reject)
  })
}

// ── retrieveStream — interface ────────────────────────────────────────────────

describe('retrieveStream — interface', () => {
  test('retourne un EventEmitter', () => {
    const stream = bank.retrieveStream('test')
    assert.ok(stream instanceof EventEmitter)
    // Nettoyer pour éviter l'erreur "pas de listener"
    stream.on('data', () => {})
    stream.on('end', () => {})
  })

  test('corpus vide → end émis avec total=0', async () => {
    const stream = bank.retrieveStream('anything')
    const { items, total } = await drainStream(stream)
    assert.equal(items.length, 0)
    assert.equal(total, 0)
  })

  test('émet data pour chaque résultat scoré', async () => {
    bank.store('backend', 'nestjs', 'success', 'JWT authentication nestjs guards')
    bank.store('backend', 'nestjs', 'success', 'nestjs error handling middleware')
    bank.store('frontend', 'nextjs', 'failure', 'nextjs routing issue')

    const stream = bank.retrieveStream('nestjs backend')
    const { items } = await drainStream(stream)
    assert.ok(items.length >= 1, `Attendu >= 1 résultat, obtenu ${items.length}`)
    for (const item of items) {
      assert.ok(typeof item.score === 'number', 'score doit être un nombre')
      assert.ok(item.score > 0, 'score doit être > 0')
    }
  })

  test('émet end avec le total des trajectoires scorées', async () => {
    bank.store('backend', 'nestjs', 'success', 'nestjs jwt guards success')
    bank.store('backend', 'nestjs', 'success', 'nestjs prisma integration success')
    bank.store('frontend', 'nextjs', 'failure', 'completely unrelated topic')

    const stream = bank.retrieveStream('nestjs backend')
    const { items, total } = await drainStream(stream)
    assert.equal(total, items.length, 'total doit correspondre au nombre de data émis')
  })

  test('émet error si exception interne (DB corrompue simulée)', async () => {
    // On force une erreur en passant une phase invalide qui déclenche une exception
    // via monkey-patch de getDB — plus simple : supprimer bank.db après chargement
    const dbPath = join(TMP, 'coordinator', 'bank.db')
    // Écrire un fichier DB invalide (non SQLite)
    writeFileSync(dbPath, 'CORRUPTED DATA NOT SQLITE FORMAT AT ALL!!!')

    const stream = bank.retrieveStream('test')
    await new Promise((resolve) => {
      stream.on('error', err => {
        assert.ok(err instanceof Error)
        resolve()
      })
      stream.on('end', () => {
        // Dégradation gracieuse acceptable : corpus vide → end(0)
        resolve()
      })
    })
  })
})

// ── retrieveStream — filtrage et scoring ─────────────────────────────────────

describe('retrieveStream — filtrage et scoring', () => {
  test('filtre par phase via opts.phase', async () => {
    bank.store('backend',  'nestjs', 'success', 'backend nestjs authentication success')
    bank.store('frontend', 'nextjs', 'success', 'frontend nextjs routing success')

    const stream = bank.retrieveStream('success', { phase: 'backend' })
    const { items } = await drainStream(stream)
    for (const item of items) {
      assert.equal(item.phase, 'backend')
    }
  })

  test('batchSize=1 → data émis une trajectoire à la fois', async () => {
    bank.store('backend', 'nestjs', 'success', 'nestjs guards jwt implementation')
    bank.store('backend', 'nestjs', 'success', 'nestjs prisma database integration')
    bank.store('backend', 'nestjs', 'partial', 'nestjs websocket partial setup')

    const stream = bank.retrieveStream('nestjs', { batchSize: 1 })
    const emitOrder = []
    await new Promise((resolve, reject) => {
      stream.on('data', r => emitOrder.push(r.id))
      stream.on('end', () => resolve())
      stream.on('error', reject)
    })
    assert.ok(emitOrder.length >= 1, 'au moins un résultat attendu')
  })

  test('batchSize=100 → fonctionne sur petit corpus', async () => {
    bank.store('backend', 'nestjs', 'success', 'nestjs crud service implementation')
    bank.store('schema',  'db',     'success', 'postgresql schema design success')

    const stream = bank.retrieveStream('nestjs', { batchSize: 100 })
    const { items } = await drainStream(stream)
    assert.ok(items.length >= 1)
  })

  test('chaque résultat a une propriété score > 0', async () => {
    bank.store('backend', 'nestjs', 'success', 'nestjs authentication jwt success')

    const stream = bank.retrieveStream('nestjs backend authentication')
    const { items } = await drainStream(stream)
    assert.ok(items.length >= 1)
    for (const item of items) {
      assert.ok(typeof item.score === 'number')
      assert.ok(item.score > 0)
    }
  })

  test('les résultats contiennent les champs de la trajectoire originale', async () => {
    bank.store('backend', 'nestjs', 'success', 'nestjs prisma integration')

    const stream = bank.retrieveStream('nestjs')
    const { items } = await drainStream(stream)
    assert.ok(items.length >= 1)
    const item = items[0]
    assert.ok(typeof item.id === 'string')
    assert.ok(typeof item.phase === 'string')
    assert.ok(typeof item.agent === 'string')
    assert.ok(typeof item.verdict === 'string')
    assert.ok(typeof item.summary === 'string')
    assert.ok(typeof item.ts === 'string')
  })
})

// ── collectStream ─────────────────────────────────────────────────────────────

describe('collectStream', () => {
  test('retourne une Promise', () => {
    const stream = bank.retrieveStream('test')
    const result = bank.collectStream(stream, 5)
    assert.ok(result instanceof Promise)
  })

  test('résout avec un tableau de résultats', async () => {
    bank.store('backend', 'nestjs', 'success', 'nestjs error handling middleware')

    const stream = bank.retrieveStream('nestjs backend')
    const results = await bank.collectStream(stream, 5)
    assert.ok(Array.isArray(results))
  })

  test('retourne au plus limit résultats', async () => {
    // Stocker 10 trajectoires pertinentes
    for (let i = 0; i < 10; i++) {
      bank.store('backend', 'nestjs', 'success', `nestjs service implementation number ${i}`)
    }

    const stream = bank.retrieveStream('nestjs backend implementation')
    const results = await bank.collectStream(stream, 3)
    assert.ok(results.length <= 3, `Attendu <= 3, obtenu ${results.length}`)
  })

  test('trie les résultats par score décroissant', async () => {
    bank.store('backend', 'nestjs', 'success', 'nestjs authentication jwt guards success')
    bank.store('backend', 'nestjs', 'success', 'nestjs prisma integration success backend')
    bank.store('backend', 'nestjs', 'failure', 'nestjs error failure partial')

    const stream = bank.retrieveStream('nestjs backend authentication success')
    const results = await bank.collectStream(stream, 10)
    for (let i = 1; i < results.length; i++) {
      assert.ok(
        results[i - 1].score >= results[i].score,
        `Résultats non triés : score[${i-1}]=${results[i-1].score} < score[${i}]=${results[i].score}`
      )
    }
  })

  test('corpus vide → résout avec tableau vide', async () => {
    const stream = bank.retrieveStream('anything at all')
    const results = await bank.collectStream(stream, 5)
    assert.ok(Array.isArray(results))
    assert.equal(results.length, 0)
  })

  test('rejette si le stream émet une erreur', async () => {
    const fakeStream = new EventEmitter()
    const p = bank.collectStream(fakeStream, 5)
    setImmediate(() => fakeStream.emit('error', new Error('test error')))
    await assert.rejects(p, /test error/)
  })
})

// ── Cas limites ───────────────────────────────────────────────────────────────

describe('cas limites', () => {
  test('query vide → end immédiat si corpus vide', async () => {
    const stream = bank.retrieveStream('')
    const { items, total } = await drainStream(stream)
    assert.equal(items.length, 0)
    assert.equal(total, 0)
  })

  test('query vide avec trajectoires → fonctionne sans crash', async () => {
    bank.store('backend', 'nestjs', 'success', 'some summary here')
    const stream = bank.retrieveStream('')
    const { total } = await drainStream(stream)
    assert.ok(typeof total === 'number')
  })

  test('opts non fournis → utilise les défauts', async () => {
    bank.store('backend', 'nestjs', 'success', 'nestjs implementation success')
    const stream = bank.retrieveStream('nestjs')
    const { items } = await drainStream(stream)
    assert.ok(Array.isArray(items))
  })
})
