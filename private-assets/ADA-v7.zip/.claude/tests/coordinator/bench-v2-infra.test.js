#!/usr/bin/env node
'use strict'
/**
 * bench-v2-infra.test.js — Scorer infra (Docker) de bench-v2 (ADR-021 Action 3,
 * finding G8 : corpus 100% SQL).
 *
 * Teste les fonctions PURES (extraction, calcul de score, sanitization de tag)
 * sans dépendre de Docker. Un bloc de tests end-to-end RÉELS (build + inspect +
 * export/tar réels) est guardé derrière dockerAvailable() — même pattern que la
 * garde postgresAvailable() de bench-v2.test.js / typescriptAvailable() de
 * bench-v2-ts.test.js.
 */
const { test, describe } = require('node:test')
const assert = require('node:assert/strict')

const INFRA = require('../../coordinator/bench-v2-infra.js')

// ── extractDockerBlocks ────────────────────────────────────────────────────────
describe('extractDockerBlocks', () => {
  test('un bloc dockerfile simple', () => {
    const txt = 'blabla\n```dockerfile\nFROM node:20-alpine\n```\nfin'
    const blocks = INFRA.extractDockerBlocks(txt)
    assert.equal(blocks.length, 1)
    assert.equal(blocks[0], 'FROM node:20-alpine')
  })

  test('alias ```docker reconnu', () => {
    const txt = '```docker\nFROM alpine\n```'
    assert.deepEqual(INFRA.extractDockerBlocks(txt), ['FROM alpine'])
  })

  test('plusieurs blocs dockerfile', () => {
    const txt = '```dockerfile\nA\n```\ntexte\n```docker\nB\n```'
    assert.deepEqual(INFRA.extractDockerBlocks(txt), ['A', 'B'])
  })

  test('aucun bloc', () => {
    assert.deepEqual(INFRA.extractDockerBlocks('pas de code ici'), [])
    assert.deepEqual(INFRA.extractDockerBlocks(''), [])
    assert.deepEqual(INFRA.extractDockerBlocks(null), [])
    assert.deepEqual(INFRA.extractDockerBlocks(undefined), [])
  })

  test('langages mixtes : ignore js/sql/yaml, garde dockerfile/docker', () => {
    const txt = '```js\nconst x=1\n```\n```dockerfile\nFROM a\n```\n```sql\nSELECT 1;\n```\n```yaml\nkey: 1\n```\n```docker\nFROM b\n```'
    assert.deepEqual(INFRA.extractDockerBlocks(txt), ['FROM a', 'FROM b'])
  })

  test('bloc sans langage est ignoré (pas implicitement dockerfile)', () => {
    assert.deepEqual(INFRA.extractDockerBlocks('```\nFROM node:20-alpine\n```'), [])
  })

  test('bloc vide (après trim) est ignoré', () => {
    assert.deepEqual(INFRA.extractDockerBlocks('```dockerfile\n   \n```'), [])
  })
})

// ── computeCheckScore ───────────────────────────────────────────────────────────
describe('computeCheckScore', () => {
  test('tous les checks passent => 100', () => {
    assert.deepEqual(INFRA.computeCheckScore([{ ok: true }, { ok: true }]), { score: 100, passed: 2, total: 2 })
  })
  test('aucun check => score 0, total 0', () => {
    assert.deepEqual(INFRA.computeCheckScore([]), { score: 0, passed: 0, total: 0 })
  })
  test('partiel arrondi au plus proche (5/6 = 83)', () => {
    const results = [true, true, true, true, true, false].map(ok => ({ ok }))
    assert.equal(INFRA.computeCheckScore(results).score, 83)
  })
  test('un seul check en échec => score 0', () => {
    assert.deepEqual(INFRA.computeCheckScore([{ ok: false }]), { score: 0, passed: 0, total: 1 })
  })
})

// ── safeTagPart ─────────────────────────────────────────────────────────────────
describe('safeTagPart', () => {
  test('minuscule et remplace les caractères invalides', () => {
    assert.equal(INFRA.safeTagPart('Docker_Node MultiStage!', 40), 'docker_node-multistage-')
  })
  test('tronque à la longueur max', () => {
    assert.equal(INFRA.safeTagPart('abcdefghij', 5), 'abcde')
  })
  test('chaîne vide => repli sur "x"', () => {
    assert.equal(INFRA.safeTagPart('', 10), 'x')
    assert.equal(INFRA.safeTagPart(null, 10), 'x')
  })
  test('ne commence jamais par un séparateur', () => {
    assert.equal(INFRA.safeTagPart('---abc', 10), 'abc')
  })
})

// ── scoreDockerDeliverable : garde-fous PURS (sans Docker) ─────────────────────
describe('scoreDockerDeliverable — garde-fous', () => {
  test('docker indisponible => score null (simulé via dockerAvailable mocké impossible ici, cf. skip e2e)', () => {
    // Pas de mock de dockerAvailable() ici (fonction non injectable sans refactor) :
    // le garde-fou réel est couvert par les tests end-to-end guardés ci-dessous
    // (si docker est indisponible sur la machine de CI, TOUT ce describe skip et
    // documente pourquoi plutôt que de faire semblant de le tester).
    assert.equal(typeof INFRA.dockerAvailable, 'function')
  })

  test('aucune vérification définie pour la tâche => score null (si docker dispo)', { skip: !dockerUp() && 'docker indisponible' }, () => {
    const task = { id: 'x', assets: {} }
    const r = INFRA.scoreDockerDeliverable(task, '```dockerfile\nFROM node:20-alpine\n```', 'abc123')
    assert.equal(r.score, null)
    assert.match(r.detail, /aucune vérification définie/)
  })

  test('aucun bloc dockerfile => score 0 (si docker dispo)', { skip: !dockerUp() && 'docker indisponible' }, () => {
    const task = { id: 'x', assets: { dockerChecks: ['image construite avec succès'] } }
    const r = INFRA.scoreDockerDeliverable(task, 'pas de bloc ici', 'abc123')
    assert.equal(r.score, 0)
    assert.match(r.detail, /aucun bloc/)
  })
})

// ── Intégration Docker (guardée, skip si indisponible) ─────────────────────────
function dockerUp() {
  return INFRA.dockerAvailable()
}

describe('scoreDockerDeliverable (intégration Docker réelle)', () => {
  const tasks = require('../../benchmarks/v2/tasks-v2.json').tasks
  const task = tasks.find(t => t.id === 'docker-node-multistage-nonroot')

  test('tâche docker-node-multistage-nonroot déclarée avec ses dockerChecks', () => {
    assert.ok(task, 'tâche manquante dans tasks-v2.json')
    assert.equal(task.stack, 'docker')
    assert.ok(Array.isArray(task.assets.dockerChecks) && task.assets.dockerChecks.length >= 5)
  })

  test('end-to-end : Dockerfile correct (multi-stage, non-root, healthcheck, pas de secret) → 100',
    { skip: !dockerUp() && 'docker indisponible', timeout: 120000 }, () => {
      const deliverable = '```dockerfile\n' +
        'FROM node:20-alpine AS build\n' +
        'WORKDIR /app\n' +
        'COPY package*.json ./\n' +
        'RUN npm install --omit=dev\n' +
        'COPY server.js ./\n' +
        'RUN npm run build\n' +
        '\n' +
        'FROM node:20-alpine AS runtime\n' +
        'WORKDIR /app\n' +
        'RUN addgroup -S appgrp && adduser -S appuser -G appgrp\n' +
        'COPY --from=build /app/dist ./dist\n' +
        'COPY --from=build /app/package.json ./package.json\n' +
        'USER appuser\n' +
        'HEALTHCHECK --interval=30s --timeout=3s CMD wget -qO- http://127.0.0.1:3000/health || exit 1\n' +
        'EXPOSE 3000\n' +
        'CMD ["node", "dist/server.js"]\n' +
        '```'
      const r = INFRA.scoreDockerDeliverable(task, deliverable, 'e2egood01')
      assert.equal(r.score, 100, JSON.stringify(r.detail))
      assert.equal(r.detail.assertions.length, 6)
      assert.ok(r.detail.assertions.every(a => a.ok))
    })

  test('end-to-end : Dockerfile avec secret qui fuit (COPY --from=build /app .) → détecté par inspection réelle',
    { skip: !dockerUp() && 'docker indisponible', timeout: 120000 }, () => {
      const deliverable = '```dockerfile\n' +
        'FROM node:20-alpine AS build\n' +
        'WORKDIR /app\n' +
        'COPY . .\n' +
        'RUN npm install --omit=dev\n' +
        'RUN npm run build\n' +
        '\n' +
        'FROM node:20-alpine AS runtime\n' +
        'WORKDIR /app\n' +
        'RUN addgroup -S appgrp && adduser -S appuser -G appgrp\n' +
        'COPY --from=build /app .\n' +
        'USER appuser\n' +
        'HEALTHCHECK --interval=30s --timeout=3s CMD wget -qO- http://127.0.0.1:3000/health || exit 1\n' +
        'EXPOSE 3000\n' +
        'CMD ["node", "dist/server.js"]\n' +
        '```'
      const r = INFRA.scoreDockerDeliverable(task, deliverable, 'e2eleak01')
      const leakCheck = r.detail.assertions.find(a => a.name === 'aucun secret .env dans l\'image finale')
      assert.ok(leakCheck, 'assertion de fuite de secret introuvable')
      assert.equal(leakCheck.ok, false)
      assert.ok(r.score < 100)
    })

  test('nettoyage garanti : aucune image/conteneur benchv2-* résiduel après scoring',
    { skip: !dockerUp() && 'docker indisponible', timeout: 60000 }, () => {
      const { spawnSync } = require('child_process')
      const images = spawnSync('docker', ['images', '--format', '{{.Repository}}'], { encoding: 'utf8' })
      const containers = spawnSync('docker', ['ps', '-a', '--format', '{{.Names}}'], { encoding: 'utf8' })
      const leftoverImages = (images.stdout || '').split('\n').filter(l => l.startsWith('benchv2-'))
      const leftoverContainers = (containers.stdout || '').split('\n').filter(l => l.startsWith('benchv2-'))
      assert.deepEqual(leftoverImages, [], 'images benchv2-* orphelines détectées')
      assert.deepEqual(leftoverContainers, [], 'conteneurs benchv2-* orphelins détectés')
    })
})
