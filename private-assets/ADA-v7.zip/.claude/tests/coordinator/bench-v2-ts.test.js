#!/usr/bin/env node
'use strict'
/**
 * bench-v2-ts.test.js — Scorer TypeScript de bench-v2 (ADR-021 Action 3).
 *
 * Teste les fonctions PURES (extraction, génération du harnais, calcul du
 * score) sans dépendre de tsc/node_modules. Un bloc de tests end-to-end RÉELS
 * (compilation + exécution node:test) est guardé derrière typescriptAvailable()
 * — même pattern que la garde postgresAvailable() de bench-v2.test.js.
 */
const { test, describe } = require('node:test')
const assert = require('node:assert/strict')
const vm = require('node:vm')

const TS = require('../../coordinator/bench-v2-ts.js')

// ── extractTsBlocks ───────────────────────────────────────────────────────────
describe('extractTsBlocks', () => {
  test('un bloc typescript simple', () => {
    const txt = 'blabla\n```typescript\nexport const x = 1\n```\nfin'
    const blocks = TS.extractTsBlocks(txt)
    assert.equal(blocks.length, 1)
    assert.equal(blocks[0], 'export const x = 1')
  })

  test('alias ```ts reconnu', () => {
    const txt = '```ts\nexport const y = 2\n```'
    assert.deepEqual(TS.extractTsBlocks(txt), ['export const y = 2'])
  })

  test('plusieurs blocs typescript', () => {
    const txt = '```typescript\nA\n```\ntexte\n```ts\nB\n```'
    assert.deepEqual(TS.extractTsBlocks(txt), ['A', 'B'])
  })

  test('aucun bloc', () => {
    assert.deepEqual(TS.extractTsBlocks('pas de code ici'), [])
    assert.deepEqual(TS.extractTsBlocks(''), [])
    assert.deepEqual(TS.extractTsBlocks(null), [])
    assert.deepEqual(TS.extractTsBlocks(undefined), [])
  })

  test('langages mixtes : ignore js/python/sql, garde typescript/ts', () => {
    const txt = '```js\nconst x=1\n```\n```typescript\nexport const a=1\n```\n```python\nprint(1)\n```\n```sql\nSELECT 1;\n```\n```ts\nexport const b=2\n```'
    assert.deepEqual(TS.extractTsBlocks(txt), ['export const a=1', 'export const b=2'])
  })

  test('bloc sans langage est ignoré (pas implicitement typescript)', () => {
    assert.deepEqual(TS.extractTsBlocks('```\nexport const x = 1\n```'), [])
  })

  test('bloc vide (après trim) est ignoré', () => {
    assert.deepEqual(TS.extractTsBlocks('```typescript\n   \n```'), [])
  })
})

// ── computeScore ──────────────────────────────────────────────────────────────
describe('computeScore', () => {
  test('toutes les assertions passent => 100', () => {
    const r = TS.computeScore([{ ok: true }, { ok: true }])
    assert.deepEqual(r, { score: 100, passed: 2, total: 2 })
  })
  test('aucune assertion => score 0, total 0', () => {
    assert.deepEqual(TS.computeScore([]), { score: 0, passed: 0, total: 0 })
  })
  test('partiel arrondi au plus proche', () => {
    // 13/14 = 92.857... → arrondi à 93
    const results = Array.from({ length: 14 }, (_, i) => ({ ok: i !== 0 }))
    assert.equal(TS.computeScore(results).score, 93)
  })
})

// ── buildHarnessSource (PURE — génère du texte, syntaxe validée sans exécution) ─
describe('buildHarnessSource', () => {
  const assertions = [
    { name: 'valeur simple', type: 'value', expect: 42, expr: 'mod.answer()' },
    { name: 'lève une erreur', type: 'throws', throwsInstanceOf: 'RangeError', expr: 'mod.boom()' },
    { name: 'lève sans type précis', type: 'throws', expr: 'mod.boomAny()' },
  ]

  test('produit un JS syntaxiquement valide (vm.Script, sans exécuter)', () => {
    const src = TS.buildHarnessSource(assertions, '/tmp/fake/dist/deliverable.js')
    assert.doesNotThrow(() => new vm.Script(src, { filename: 'harness.test.js' }))
  })

  test('contient un test() par assertion, nommé, et le marqueur de résultats', () => {
    const src = TS.buildHarnessSource(assertions, '/tmp/fake/dist/deliverable.js')
    for (const a of assertions) {
      assert.ok(src.includes(JSON.stringify(a.name)), `nom manquant: ${a.name}`)
    }
    assert.ok(src.includes(TS.RESULTS_MARKER))
    assert.ok(src.includes(JSON.stringify('/tmp/fake/dist/deliverable.js')))
  })

  test('assertion throws avec throwsInstanceOf vérifie le type de l\'exception', () => {
    const src = TS.buildHarnessSource(assertions, '/x/dist/deliverable.js')
    assert.ok(src.includes("e.constructor.name === \"RangeError\""))
  })

  test('assertion throws SANS throwsInstanceOf accepte tout type d\'exception', () => {
    const src = TS.buildHarnessSource([{ name: 'x', type: 'throws', expr: 'mod.f()' }], '/x/dist/deliverable.js')
    assert.ok(src.includes('record.ok = true'))
  })

  test('liste vide d\'assertions reste un harnais valide (aucun test généré)', () => {
    const src = TS.buildHarnessSource([], '/x/dist/deliverable.js')
    assert.doesNotThrow(() => new vm.Script(src))
    assert.ok(src.includes(TS.RESULTS_MARKER))
  })
})

// ── typescriptAvailable ───────────────────────────────────────────────────────
describe('typescriptAvailable', () => {
  test('renvoie un booléen (jamais une exception)', () => {
    assert.equal(typeof TS.typescriptAvailable(), 'boolean')
  })
})

// ── scoreTsDeliverable — end-to-end (guardé, skip si tsc/class-validator indispo) ─
describe('scoreTsDeliverable (intégration tsc réelle)', () => {
  const available = TS.typescriptAvailable()
  const skipReason = available ? false : 'typescript/class-validator indisponible (voir ada-api-nest/node_modules)'

  const tasks = require('../../benchmarks/v2/tasks-v2.json').tasks
  const task = tasks.find(t => t.id === 'ts-invoice-total-banker-rounding')

  test('la tâche ts-invoice-total-banker-rounding est bien câblée', () => {
    assert.ok(task, 'tâche introuvable dans tasks-v2.json')
    assert.deepEqual(task.categories, ['correction-reelle-ts'])
    assert.ok(task.assets.assertions.length >= 10)
  })

  test('aucun bloc ```typescript => score 0, jamais null', { skip: skipReason }, () => {
    const r = TS.scoreTsDeliverable(task, 'juste du texte, aucun bloc de code', 'test1')
    assert.equal(r.score, 0)
  })

  test('livrable correct (référence) => 100/100, toutes assertions ok', { skip: skipReason }, () => {
    const deliverable = '```typescript\n' + [
      "import { IsInt, Min } from 'class-validator'",
      '',
      'interface InvoiceLine { qty: number; unitPriceCents: number }',
      '',
      'function bankersRound(x: number): number {',
      '  const floor = Math.floor(x)',
      '  const diff = x - floor',
      '  if (diff < 0.5) return floor',
      '  if (diff > 0.5) return floor + 1',
      '  return floor % 2 === 0 ? floor : floor + 1',
      '}',
      '',
      'export function computeInvoiceTotal(lines: InvoiceLine[], discountPercent = 0): number {',
      '  if (discountPercent < 0 || discountPercent > 100) throw new RangeError("discountPercent hors bornes")',
      '  let subtotal = 0',
      '  for (const l of lines) {',
      '    if (!Number.isInteger(l.qty) || l.qty < 0) throw new RangeError("qty invalide")',
      '    if (!Number.isInteger(l.unitPriceCents) || l.unitPriceCents < 0) throw new RangeError("unitPriceCents invalide")',
      '    subtotal += l.qty * l.unitPriceCents',
      '  }',
      '  const exact = subtotal * (100 - discountPercent) / 100',
      '  return bankersRound(exact)',
      '}',
      '',
      'export class CreateInvoiceDto {',
      '  @IsInt()',
      '  @Min(0)',
      '  amountCents!: number',
      '}',
    ].join('\n') + '\n```'

    const result = TS.scoreTsDeliverable(task, deliverable, 'test2')
    assert.equal(result.score, 100, JSON.stringify(result.detail))
    assert.equal(result.detail.passed, result.detail.total)
    assert.ok(result.detail.assertions.every(a => a.ok))
  })

  test('erreur de compilation réelle => score 0, erreur du compilateur capturée', { skip: skipReason }, () => {
    const deliverable = '```typescript\nexport function computeInvoiceTotal(lines: number: string): number { return 1 }\n```'
    const result = TS.scoreTsDeliverable(task, deliverable, 'test3')
    assert.equal(result.score, 0)
    assert.ok(result.detail && typeof result.detail.compileError === 'string' && result.detail.compileError.length > 0)
  })

  test('livrable cassé (arrondi naïf) => échoue exactement 1 assertion', { skip: skipReason }, () => {
    const deliverable = '```typescript\n' + [
      "import { IsInt, Min } from 'class-validator'",
      'interface InvoiceLine { qty: number; unitPriceCents: number }',
      'export function computeInvoiceTotal(lines: InvoiceLine[], discountPercent = 0): number {',
      '  if (discountPercent < 0 || discountPercent > 100) throw new RangeError("discountPercent hors bornes")',
      '  let subtotal = 0',
      '  for (const l of lines) {',
      '    if (!Number.isInteger(l.qty) || l.qty < 0) throw new RangeError("qty invalide")',
      '    if (!Number.isInteger(l.unitPriceCents) || l.unitPriceCents < 0) throw new RangeError("unitPriceCents invalide")',
      '    subtotal += l.qty * l.unitPriceCents',
      '  }',
      '  const exact = subtotal * (100 - discountPercent) / 100',
      '  return Math.round(exact)',
      '}',
      'export class CreateInvoiceDto {',
      '  @IsInt()',
      '  @Min(0)',
      '  amountCents!: number',
      '}',
    ].join('\n') + '\n```'

    const result = TS.scoreTsDeliverable(task, deliverable, 'test4')
    const failed = result.detail.assertions.filter(a => !a.ok).map(a => a.name)
    assert.deepEqual(failed, ['arrondi bancaire 2.5 -> 2 (pair du bas, PAS Math.round qui donnerait 3)'])
  })
})

// ── Dispatch via bench-v2.runScorer (câblage catégorie → scorer) ──────────────
describe('bench-v2.js — dispatch correction-reelle-ts', () => {
  test('la catégorie correction-reelle-ts est wired avec le scorer ts', () => {
    const B = require('../../coordinator/bench-v2.js')
    assert.equal(B.CATEGORY_REGISTRY['correction-reelle-ts'].status, 'wired')
    assert.equal(B.CATEGORY_REGISTRY['correction-reelle-ts'].scorer, 'ts')
  })

  test('runScorer(\'correction-reelle-ts\', …) délègue à scoreTsDeliverable', { skip: TS.typescriptAvailable() ? false : 'typescript indisponible' }, () => {
    const B = require('../../coordinator/bench-v2.js')
    const tasks = require('../../benchmarks/v2/tasks-v2.json').tasks
    const task = tasks.find(t => t.id === 'ts-invoice-total-banker-rounding')
    const r = B.runScorer('correction-reelle-ts', task, 'aucun bloc', 'dispatch1')
    assert.equal(r.score, 0)
  })
})
