#!/usr/bin/env node
'use strict'
/**
 * bench-v2.test.js — Benchmark v2 : framework d'ablation.
 * Teste les fonctions PURES (extraction SQL, F1 recall, plan, deltas report,
 * parsing assertion). N'exécute PAS psql dans les tests unitaires : un seul test
 * d'intégration est guardé derrière la détection de disponibilité Postgres.
 */
const { test, describe } = require('node:test')
const assert = require('node:assert/strict')
const { spawnSync } = require('child_process')
const { join } = require('path')

const B = require('../../coordinator/bench-v2.js')

// ── extractSqlBlocks ──────────────────────────────────────────────────────────
describe('extractSqlBlocks', () => {
  test('un bloc sql simple', () => {
    const txt = 'blabla\n```sql\nCREATE TABLE t (id int);\n```\nfin'
    const blocks = B.extractSqlBlocks(txt)
    assert.equal(blocks.length, 1)
    assert.equal(blocks[0], 'CREATE TABLE t (id int);')
  })

  test('plusieurs blocs sql', () => {
    const txt = '```sql\nA;\n```\ntexte\n```sql\nB;\n```'
    const blocks = B.extractSqlBlocks(txt)
    assert.deepEqual(blocks, ['A;', 'B;'])
  })

  test('aucun bloc sql', () => {
    assert.deepEqual(B.extractSqlBlocks('pas de code ici'), [])
    assert.deepEqual(B.extractSqlBlocks(''), [])
    assert.deepEqual(B.extractSqlBlocks(null), [])
  })

  test('langages mixtes : ignore js/python, garde sql/postgres', () => {
    const txt = '```js\nconst x=1\n```\n```sql\nSELECT 1;\n```\n```python\nprint(1)\n```\n```postgres\nSELECT 2;\n```'
    const blocks = B.extractSqlBlocks(txt)
    assert.deepEqual(blocks, ['SELECT 1;', 'SELECT 2;'])
  })

  test('bloc sans langage est ignoré (pas implicitement sql)', () => {
    const txt = '```\nSELECT 1;\n```'
    assert.deepEqual(B.extractSqlBlocks(txt), [])
  })
})

// ── extractReferencedTables ───────────────────────────────────────────────────
describe('extractReferencedTables', () => {
  test('extrait les tables référencées par FK', () => {
    const sql = 'CREATE TABLE projects (id uuid, workspace_id uuid REFERENCES workspaces(id), owner_id uuid REFERENCES users(id));'
    assert.deepEqual(B.extractReferencedTables(sql).sort(), ['users', 'workspaces'])
  })
  test('exclut les tables créées par le livrable lui-même', () => {
    const sql = 'CREATE TABLE orders (id uuid);\nCREATE TABLE order_items (id uuid, order_id uuid REFERENCES orders(id));'
    assert.deepEqual(B.extractReferencedTables(sql), [])
  })
  test('dédoublonne et gère IF NOT EXISTS / guillemets', () => {
    const sql = 'CREATE TABLE IF NOT EXISTS a (x uuid REFERENCES "t"(id), y uuid REFERENCES t(id));'
    assert.deepEqual(B.extractReferencedTables(sql), ['t'])
  })
  test('vide / non-string → []', () => {
    assert.deepEqual(B.extractReferencedTables(''), [])
    assert.deepEqual(B.extractReferencedTables(null), [])
  })

  // ── qualification de schéma (pratique standard Supabase : public.<table>) ────
  test('CREATE TABLE non qualifié → nom de table', () => {
    const sql = 'create table invoices (id uuid REFERENCES workspaces(id));'
    assert.deepEqual(B.extractReferencedTables(sql), ['workspaces'])
  })
  test('CREATE TABLE IF NOT EXISTS schéma-qualifié → dernier segment, pas "public"', () => {
    const sql = 'create table if not exists public.invoices (id uuid, x uuid REFERENCES invoices(id));'
    // "invoices" est créé par le livrable (malgré le préfixe public.) → pas de stub
    assert.deepEqual(B.extractReferencedTables(sql), [])
  })
  test('CREATE TABLE avec segments entre guillemets → dernier segment', () => {
    const sql = 'create table "public"."invoices" (id uuid, x uuid REFERENCES invoices(id));'
    assert.deepEqual(B.extractReferencedTables(sql), [])
  })
  test('REFERENCES schéma-qualifié → nom de table, pas "public"', () => {
    const sql = 'create table invoices (workspace_id uuid REFERENCES public.workspaces(id));'
    assert.deepEqual(B.extractReferencedTables(sql), ['workspaces'])
  })
  test('REFERENCES avec segments entre guillemets → nom de table', () => {
    const sql = 'create table invoices (workspace_id uuid REFERENCES "public"."workspaces"(id));'
    assert.deepEqual(B.extractReferencedTables(sql), ['workspaces'])
  })
  test('formes qualifiée et non qualifiée dédoublonnées vers la même table', () => {
    const sql = 'create table t1 (a uuid REFERENCES workspaces(id), b uuid REFERENCES public.workspaces(id), c uuid REFERENCES "public"."workspaces"(id));'
    assert.deepEqual(B.extractReferencedTables(sql), ['workspaces'])
  })
  test('cas régressif complet : livrable qualifié public.* → seul le stub externe est demandé', () => {
    const sql = [
      'CREATE TABLE IF NOT EXISTS public.invoices (',
      '  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),',
      '  workspace_id uuid NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,',
      '  created_at timestamptz NOT NULL DEFAULT now()',
      ');',
      'CREATE TABLE public.invoice_items (',
      '  id uuid PRIMARY KEY,',
      '  invoice_id uuid NOT NULL REFERENCES public.invoices(id) ON DELETE CASCADE',
      ');'
    ].join('\n')
    assert.deepEqual(B.extractReferencedTables(sql), ['workspaces'])
  })

  // ── schéma explicite ≠ public (auth.users natif Supabase) ───────────────────
  test('REFERENCES auth.users → entrée qualifiée "auth.users"', () => {
    const sql = 'create table profiles (id uuid REFERENCES auth.users(id));'
    assert.deepEqual(B.extractReferencedTables(sql), ['auth.users'])
  })
  test('auth.users et users nu sont deux entrées distinctes', () => {
    const sql = 'create table t (a uuid REFERENCES auth.users(id), b uuid REFERENCES users(id));'
    assert.deepEqual(B.extractReferencedTables(sql).sort(), ['auth.users', 'users'])
  })
  test('auth.users entre guillemets → même entrée qualifiée (dédoublonnée)', () => {
    const sql = 'create table t (a uuid REFERENCES "auth"."users"(id), b uuid REFERENCES auth.users(id));'
    assert.deepEqual(B.extractReferencedTables(sql), ['auth.users'])
  })
  test('table créée public.users ≠ référence auth.users → stub qualifié demandé', () => {
    const sql = 'create table public.users (id uuid);\ncreate table profiles (uid uuid REFERENCES auth.users(id));'
    assert.deepEqual(B.extractReferencedTables(sql), ['auth.users'])
  })
  test('livrable créant auth.users lui-même → pas de stub', () => {
    const sql = 'create table if not exists auth.users (id uuid);\ncreate table p (u uuid REFERENCES auth.users(id));'
    assert.deepEqual(B.extractReferencedTables(sql), [])
  })
})

// ── buildStubSql ──────────────────────────────────────────────────────────────
// Chaque stub est peuplé des identités déterministes BENCH_IDS (WS1/WS2/U1/U2/C1/C2) :
// sinon une FK vers la table-souche casse silencieusement toute assertion
// `role:'authenticated'` (INSERT sous une identité simulée) — l'apply seul réussirait,
// l'échec se déplacerait à l'assertion, indistinguable d'un défaut du livrable.
const SEED_IDS = Object.values(B.BENCH_IDS)
const seedLines = (table) => SEED_IDS.map(id => `INSERT INTO ${table} (id) VALUES ('${id}') ON CONFLICT (id) DO NOTHING;`)

describe('buildStubSql', () => {
  test('table nue → CREATE TABLE + seed des identités BENCH_IDS', () => {
    assert.equal(
      B.buildStubSql(['workspaces']),
      [
        'CREATE TABLE IF NOT EXISTS workspaces (id uuid PRIMARY KEY DEFAULT gen_random_uuid());',
        ...seedLines('workspaces'),
      ].join('\n')
    )
  })
  test('table qualifiée non-public → CREATE SCHEMA puis CREATE TABLE qualifié + seed', () => {
    assert.equal(
      B.buildStubSql(['auth.users']),
      [
        'CREATE SCHEMA IF NOT EXISTS auth;',
        'CREATE TABLE IF NOT EXISTS auth.users (id uuid PRIMARY KEY DEFAULT gen_random_uuid());',
        ...seedLines('auth.users'),
      ].join('\n')
    )
  })
  test('mélange : schémas dédoublonnés et créés avant les tables, chacune seedée', () => {
    const out = B.buildStubSql(['workspaces', 'auth.users', 'auth.sessions'])
    assert.equal(out, [
      'CREATE SCHEMA IF NOT EXISTS auth;',
      'CREATE TABLE IF NOT EXISTS workspaces (id uuid PRIMARY KEY DEFAULT gen_random_uuid());',
      ...seedLines('workspaces'),
      'CREATE TABLE IF NOT EXISTS auth.users (id uuid PRIMARY KEY DEFAULT gen_random_uuid());',
      ...seedLines('auth.users'),
      'CREATE TABLE IF NOT EXISTS auth.sessions (id uuid PRIMARY KEY DEFAULT gen_random_uuid());',
      ...seedLines('auth.sessions'),
    ].join('\n'))
  })
  test('liste vide / nulle → chaîne vide', () => {
    assert.equal(B.buildStubSql([]), '')
    assert.equal(B.buildStubSql(null), '')
  })
  test('seed couvre bien les 6 identités BENCH_IDS (WS1/WS2/U1/U2/C1/C2)', () => {
    const out = B.buildStubSql(['workspaces'])
    for (const id of Object.values(B.BENCH_IDS)) {
      assert.ok(out.includes(`'${id}'`), `id manquant dans le seed: ${id}`)
    }
  })
  test('bout-en-bout : REFERENCES auth.users produit un stub qualifié applicable', () => {
    const deliverable = [
      'CREATE TABLE IF NOT EXISTS public.profiles (',
      '  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),',
      '  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,',
      '  workspace_id uuid NOT NULL REFERENCES public.workspaces(id)',
      ');',
    ].join('\n')
    const stubs = B.extractReferencedTables(deliverable)
    assert.deepEqual(stubs.sort(), ['auth.users', 'workspaces'])
    const stubSql = B.buildStubSql(stubs)
    assert.ok(stubSql.includes('CREATE SCHEMA IF NOT EXISTS auth;'))
    assert.ok(stubSql.includes('CREATE TABLE IF NOT EXISTS auth.users ('))
    assert.ok(stubSql.includes('CREATE TABLE IF NOT EXISTS workspaces ('))
    assert.ok(!stubSql.includes('CREATE TABLE IF NOT EXISTS users ('))
  })
})

// ── parsePsqlScalar ───────────────────────────────────────────────────────────
describe('parsePsqlScalar', () => {
  test('valeur scalaire trimée', () => {
    assert.equal(B.parsePsqlScalar(' uuid \n'), 'uuid')
  })
  test('première ligne non vide', () => {
    assert.equal(B.parsePsqlScalar('\n\n1\n2\n'), '1')
  })
  test('vide', () => {
    assert.equal(B.parsePsqlScalar(''), '')
    assert.equal(B.parsePsqlScalar('\n\n'), '')
  })
  test('ignore le tag DO précédant le scalaire (DO $$..$$; SELECT)', () => {
    assert.equal(B.parsePsqlScalar('DO\n1\n'), '1')
  })
  test('ignore les tags INSERT/UPDATE avant la donnée', () => {
    assert.equal(B.parsePsqlScalar('DO\nINSERT 0 1\nuuid\n'), 'uuid')
  })
  test('valeurs de données jamais confondues avec un tag (NO, t, bigint)', () => {
    assert.equal(B.parsePsqlScalar('NO'), 'NO')
    assert.equal(B.parsePsqlScalar('t'), 't')
    assert.equal(B.parsePsqlScalar('bigint'), 'bigint')
  })
  test('que des tags → fallback 1re ligne (jamais vide à tort)', () => {
    assert.equal(B.parsePsqlScalar('DO'), 'DO')
  })
})

// ── evalAssertion / computeAssertionScore ─────────────────────────────────────
describe('evalAssertion', () => {
  test('match exact (case-insensitive, trim)', () => {
    const r = B.evalAssertion({ name: 'x', expect: 'UUID' }, ' uuid ')
    assert.equal(r.ok, true)
  })
  test('mismatch', () => {
    const r = B.evalAssertion({ name: 'x', expect: '1' }, '0')
    assert.equal(r.ok, false)
    assert.equal(r.got, '0')
  })
  test('erreur psql ne matche pas', () => {
    const r = B.evalAssertion({ name: 'x', expect: '1' }, '__error__:boom')
    assert.equal(r.ok, false)
  })
})

// ── Contexte de requête simulé / rôle réel (F3, ADR-021) ──────────────────────
describe('resolveBenchPlaceholders', () => {
  test('substitue les placeholders d\'identité par des uuid déterministes', () => {
    const out = B.resolveBenchPlaceholders("SELECT '$WS1'::uuid, '$WS2'::uuid, '$U1'::uuid, '$C1'::uuid")
    assert.equal(out, `SELECT '${B.BENCH_IDS.$WS1}'::uuid, '${B.BENCH_IDS.$WS2}'::uuid, '${B.BENCH_IDS.$U1}'::uuid, '${B.BENCH_IDS.$C1}'::uuid`)
  })
  test('déterministe (aucun aléa) — même entrée, même sortie', () => {
    const s = "SELECT '$WS1'"
    assert.equal(B.resolveBenchPlaceholders(s), B.resolveBenchPlaceholders(s))
  })
  test('les uuid sont distincts entre eux', () => {
    const vals = Object.values(B.BENCH_IDS)
    assert.equal(new Set(vals).size, vals.length)
  })
  test('SQL sans placeholder inchangé', () => {
    assert.equal(B.resolveBenchPlaceholders('SELECT 1;'), 'SELECT 1;')
  })
})

describe('buildAuthPreamble', () => {
  test('régime owner (champ role absent) → aucun préambule, compatibilité totale', () => {
    assert.equal(B.buildAuthPreamble({ name: 'x', sql: 'SELECT 1' }), '')
    assert.equal(B.buildAuthPreamble({ role: 'owner' }), '')
  })
  test('role authenticated → act_as + SET ROLE', () => {
    const p = B.buildAuthPreamble({ role: 'authenticated' })
    assert.match(p, /bench\.act_as\('\$WS1'::uuid, '\$U1'::uuid, 'authenticated'/)
    assert.match(p, /SET ROLE authenticated;/)
  })
  test('`as` et `userId` surchargent l\'identité simulée', () => {
    const p = B.buildAuthPreamble({ role: 'authenticated', as: '$WS2', userId: '$U2' })
    assert.match(p, /act_as\('\$WS2'::uuid, '\$U2'::uuid/)
  })
  test('claims additionnels injectés (test adversarial de claim falsifié)', () => {
    const p = B.buildAuthPreamble({ role: 'authenticated', claims: { user_metadata: { workspace_id: '$WS2' } } })
    assert.match(p, /'\{"user_metadata":\{"workspace_id":"\$WS2"\}\}'::jsonb/)
  })
  test('rôle inconnu → throw explicite (jamais un silencieux régime owner)', () => {
    assert.throws(() => B.buildAuthPreamble({ role: 'postgres' }), /rôle d'assertion invalide/)
    assert.throws(() => B.buildAuthPreamble({ role: 'authenticated; DROP DATABASE x' }), /rôle d'assertion invalide/)
  })
  test('`as`/`userId` inconnus → throw (pas d\'interpolation SQL arbitraire)', () => {
    assert.throws(() => B.buildAuthPreamble({ role: 'authenticated', as: '$WS9' }), /as d'assertion invalide/)
    assert.throws(() => B.buildAuthPreamble({ role: 'authenticated', as: "x'); DROP TABLE t; --" }), /as d'assertion invalide/)
    assert.throws(() => B.buildAuthPreamble({ role: 'authenticated', userId: 'bob' }), /userId d'assertion invalide/)
  })
  test('uuid littéral accepté pour `as`', () => {
    const p = B.buildAuthPreamble({ role: 'authenticated', as: '00000000-0000-4000-8000-000000000009' })
    assert.match(p, /act_as\('00000000-0000-4000-8000-000000000009'::uuid/)
  })
  test('anon et service_role acceptés', () => {
    assert.match(B.buildAuthPreamble({ role: 'anon' }), /SET ROLE anon;/)
    assert.match(B.buildAuthPreamble({ role: 'service_role' }), /SET ROLE service_role;/)
  })
})

describe('buildAssertionSql', () => {
  test('owner : SQL rendu tel quel (placeholders résolus)', () => {
    const sql = B.buildAssertionSql({ sql: "SELECT '$WS1'::uuid;" })
    assert.equal(sql, `SELECT '${B.BENCH_IDS.$WS1}'::uuid;`)
  })
  test('authenticated : préambule AVANT le SQL, placeholders résolus partout', () => {
    const sql = B.buildAssertionSql({ role: 'authenticated', sql: "SELECT '$WS1'::uuid;" })
    assert.ok(sql.indexOf('SET ROLE authenticated;') < sql.indexOf('SELECT'))
    assert.ok(!sql.includes('$WS1'))
    assert.ok(sql.includes(B.BENCH_IDS.$WS1))
  })
  test('les tags du préambule (DO/SET) sont filtrés par parsePsqlScalar', () => {
    // Le préambule émet `DO` puis `SET` sur stdout AVANT le scalaire de données :
    // sans filtrage, le scorer lirait « DO » au lieu du résultat.
    assert.equal(B.parsePsqlScalar('DO\nSET\nRESET\n1\n'), '1')
  })
})

// ── Contrat du scaffold : régime d'auth réel ──────────────────────────────────
describe('SUPABASE_SCAFFOLD_SQL — harnais de rôle réel', () => {
  test('auth.jwt() est configurable par session (plus de stub statique)', () => {
    assert.ok(B.SUPABASE_AUTH_STUB_SQL.includes("current_setting('request.jwt.claims', true)"))
    assert.ok(!/auth\.jwt\(\)[\s\S]{0,120}SELECT '\{\}'::jsonb/.test(B.SUPABASE_AUTH_STUB_SQL))
  })
  test('auth.uid()/auth.role() lisent aussi les GUC legacy request.jwt.claim.*', () => {
    assert.ok(B.SUPABASE_AUTH_STUB_SQL.includes("request.jwt.claim.sub"))
    assert.ok(B.SUPABASE_AUTH_STUB_SQL.includes("request.jwt.claim.role"))
  })
  test('act_as pose TOUS les canaux d\'autz légitimes (GUC applicatif + claims)', () => {
    for (const guc of ['app.workspace_id', 'app.current_workspace_id', 'app.tenant_id', 'request.jwt.claims']) {
      assert.ok(B.SUPABASE_SCAFFOLD_SQL.includes(guc), `canal manquant: ${guc}`)
    }
  })
  test('user_metadata reste vide par défaut (claim modifiable par le client, jamais une autz valide)', () => {
    assert.ok(B.SUPABASE_SCAFFOLD_SQL.includes("'user_metadata', '{}'::jsonb"))
  })
  test('default privileges Supabase posées (sinon un GRANT omis serait un échec d\'environnement)', () => {
    assert.ok(/ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES\s+TO anon, authenticated, service_role/.test(B.SUPABASE_SCAFFOLD_SQL))
  })
  test('bench.seed introspecte les colonnes (agnostique au schéma exact du livrable)', () => {
    assert.ok(B.SUPABASE_SCAFFOLD_SQL.includes('FUNCTION bench.seed'))
    assert.ok(B.SUPABASE_SCAFFOLD_SQL.includes('pg_attribute'))
  })
})

// ── Assertions above-threshold : couverture du régime réel ────────────────────
describe('tasks-v2 above-threshold — régime d\'exécution des assertions', () => {
  const tasks = require('../../benchmarks/v2/tasks-v2.json').tasks
  test('les tâches RLS/audit ont des assertions sous rôle authenticated', () => {
    for (const id of ['at-rls-cross-tenant-isolation', 'at-audit-soft-delete-trigger']) {
      const t = tasks.find(x => x.id === id)
      const underRole = t.assets.assertions.filter(a => a.role === 'authenticated')
      assert.ok(underRole.length >= 5, `${id}: seulement ${underRole.length} assertion(s) sous rôle réel`)
    }
  })
  test('tout `role` déclaré est un rôle connu (aucune coquille silencieuse)', () => {
    for (const t of tasks) {
      for (const a of (t.assets && t.assets.assertions) || []) {
        if (a.role) assert.ok(B.ASSERTION_ROLES.has(a.role), `${t.id}: rôle inconnu ${a.role}`)
        assert.doesNotThrow(() => B.buildAssertionSql(a), `${t.id}/${a.name}`)
      }
    }
  })
  test('aucune assertion ne laisse de placeholder non résolu', () => {
    for (const t of tasks) {
      for (const a of (t.assets && t.assets.assertions) || []) {
        assert.ok(!/\$(WS|U|C)\d/.test(B.buildAssertionSql(a)), `${t.id}/${a.name}`)
      }
    }
  })
})

describe('computeAssertionScore', () => {
  test('toutes OK = 100', () => {
    const s = B.computeAssertionScore([{ ok: true }, { ok: true }])
    assert.deepEqual(s, { score: 100, passed: 2, total: 2 })
  })
  test('moitié = 50', () => {
    const s = B.computeAssertionScore([{ ok: true }, { ok: false }])
    assert.equal(s.score, 50)
  })
  test('aucune assertion = 0', () => {
    assert.deepEqual(B.computeAssertionScore([]), { score: 0, passed: 0, total: 0 })
  })
  test('arrondi (1/3)', () => {
    const s = B.computeAssertionScore([{ ok: true }, { ok: false }, { ok: false }])
    assert.equal(s.score, 33)
  })
})

// ── recallPrecision ───────────────────────────────────────────────────────────
describe('recallPrecision', () => {
  test('tous bons → P=R=F1=1', () => {
    const m = B.recallPrecision(['uuid', 'workspace_id'], ['uuid', 'workspace_id'])
    assert.equal(m.precision, 1)
    assert.equal(m.recall, 1)
    assert.equal(m.f1, 1)
  })

  test('manque une clé (rappel partiel)', () => {
    const m = B.recallPrecision(['uuid'], ['uuid', 'workspace_id'])
    assert.equal(m.precision, 1)
    assert.equal(m.recall, 0.5)
    assert.equal(m.f1, round3((2 * 1 * 0.5) / 1.5))
    assert.equal(m.fn, 1)
  })

  test('faux positifs (distracteurs récupérés)', () => {
    const m = B.recallPrecision(['uuid', 'distracteur-xyz'], ['uuid'])
    assert.equal(m.precision, 0.5)
    assert.equal(m.recall, 1)
    assert.equal(m.fp, 1)
  })

  test('vide récupéré → tout en faux négatif', () => {
    const m = B.recallPrecision([], ['uuid', 'workspace_id'])
    assert.equal(m.precision, 0)
    assert.equal(m.recall, 0)
    assert.equal(m.f1, 0)
    assert.equal(m.fn, 2)
  })

  test('vide ground-truth ET vide récupéré → 0 (pas NaN)', () => {
    const m = B.recallPrecision([], [])
    assert.equal(m.precision, 0)
    assert.equal(m.recall, 0)
    assert.equal(m.f1, 0)
  })

  test('matching sous-chaîne (clé courte ⊂ convention longue)', () => {
    const m = B.recallPrecision(['uuid PK + timestamps + workspace_id'], ['uuid', 'workspace_id', 'timestamps'])
    assert.equal(m.recall, 1)
    assert.equal(m.tp >= 1, true)
  })

  test('normalisation accents/casse', () => {
    const m = B.recallPrecision(['RLS Supabase'], ['rls supabase'])
    assert.equal(m.precision, 1)
    assert.equal(m.recall, 1)
  })
})
function round3(n) { return Math.round(n * 1000) / 1000 }

// ── parseRecallConventions ────────────────────────────────────────────────────
describe('parseRecallConventions', () => {
  test('parse les bullets', () => {
    const out = `[CONNAISSANCE PROJET]\nConventions:\n- uuid PK + timestamps\n- RLS Supabase\n`
    assert.deepEqual(B.parseRecallConventions(out), ['uuid PK + timestamps', 'RLS Supabase'])
  })
  test('vide', () => {
    assert.deepEqual(B.parseRecallConventions(''), [])
    assert.deepEqual(B.parseRecallConventions('aucune convention'), [])
  })
})

// ── buildPlan / planRun ───────────────────────────────────────────────────────
const FIXTURE_TASKS = [
  { id: 't-sql', profile: 'data', stack: 'sql', prompt: 'crée une table users', categories: ['correction-reelle'] },
  { id: 't-rec', profile: 'review', stack: 'plan', prompt: 'liste les conventions', categories: ['precision-recuperation'] },
  { id: 't-unknown', profile: 'mystere', stack: 'plan', categories: ['precision-recuperation'] },
  { id: 't-complex', profile: 'review', stack: 'plan', prompt: 'audit de sécurité et review des migrations concurrentes', categories: ['conventions-tacites'] },
]

describe('buildPlan', () => {
  test('4 bras par (tâche, catégorie) par défaut', () => {
    const plan = B.buildPlan(FIXTURE_TASKS, { taskIds: ['t-sql'] })
    assert.equal(plan.length, 4)
    assert.deepEqual(plan.map(p => p.arm), ['A', 'B', 'C', 'D'])
  })

  test('filtre par catégorie', () => {
    const plan = B.buildPlan(FIXTURE_TASKS, { categories: ['correction-reelle'] })
    assert.equal(plan.length, 4)
    assert.ok(plan.every(p => p.category === 'correction-reelle'))
  })

  test('filtre par bras', () => {
    const plan = B.buildPlan(FIXTURE_TASKS, { taskIds: ['t-sql'], arms: ['A', 'B'] })
    assert.equal(plan.length, 2)
    assert.deepEqual(plan.map(p => p.arm), ['A', 'B'])
  })

  test('A/B = general-purpose, false/true inject, decompose false', () => {
    const plan = B.buildPlan(FIXTURE_TASKS, { taskIds: ['t-sql'] })
    const a = plan.find(p => p.arm === 'A')
    const b = plan.find(p => p.arm === 'B')
    assert.equal(a.agentType, 'general-purpose')
    assert.equal(a.injectConventions, false)
    assert.equal(a.decompose, false)
    assert.equal(b.agentType, 'general-purpose')
    assert.equal(b.injectConventions, true)
    assert.equal(b.decompose, false)
  })

  test('C = agent spécialisé (profil data → data-modeler), inject true, decompose false', () => {
    const plan = B.buildPlan(FIXTURE_TASKS, { taskIds: ['t-sql'] })
    const c = plan.find(p => p.arm === 'C')
    assert.equal(c.agentType, 'data-modeler')
    assert.equal(c.injectConventions, true)
    assert.equal(c.decompose, false)
  })

  test('D = spécialisé + decompose true', () => {
    const plan = B.buildPlan(FIXTURE_TASKS, { taskIds: ['t-sql'] })
    const d = plan.find(p => p.arm === 'D')
    assert.equal(d.agentType, 'data-modeler')
    assert.equal(d.decompose, true)
  })

  test('profil inconnu → general-purpose en C/D', () => {
    const plan = B.buildPlan(FIXTURE_TASKS, { taskIds: ['t-unknown'] })
    const c = plan.find(p => p.arm === 'C')
    assert.equal(c.agentType, 'general-purpose')
  })

  test('A/B = sonnet baseline ; C/D = modèle routé par tier', () => {
    const plan = B.buildPlan(FIXTURE_TASKS, { taskIds: ['t-sql'] })
    const a = plan.find(p => p.arm === 'A'), b = plan.find(p => p.arm === 'B')
    const c = plan.find(p => p.arm === 'C'), d = plan.find(p => p.arm === 'D')
    assert.equal(a.model, 'claude-sonnet-5')
    assert.equal(b.model, 'claude-sonnet-5')
    // 'crée une table users' = tier 2 → sonnet
    assert.equal(c.model, 'claude-sonnet-5')
    assert.equal(d.model, 'claude-sonnet-5')
  })

  test('C/D routent vers opus sur une tâche tier 3 (sécurité/migrations)', () => {
    const plan = B.buildPlan(FIXTURE_TASKS, { taskIds: ['t-complex'] })
    const c = plan.find(p => p.arm === 'C'), d = plan.find(p => p.arm === 'D')
    assert.equal(c.model, 'claude-opus-4-8')
    assert.equal(d.model, 'claude-opus-4-8')
  })

  test('routedModel : tier-mapping déterministe', () => {
    assert.equal(B.routedModel('renomme cette variable'), 'claude-haiku-4-5-20251001')
    assert.equal(B.routedModel('crée une table'), 'claude-sonnet-5')
    assert.equal(B.routedModel('audit de sécurité performance'), 'claude-opus-4-8')
    assert.equal(B.routedModel(''), 'claude-sonnet-5')
  })

  // B5 — une tâche classée tier 0 (codemod, 0 appel LLM) ne doit JAMAIS traverser
  // `recommendModel(0)` : TIER_MODELS[0] n'existe pas et le `|| TIER_MODELS[2]`
  // interne facturait Sonnet en silence, sans trace exploitable dans le plan.
  test('B5 — tier 0 (codemod) : repli explicite sur le tier 2 + bypass signalé', () => {
    const { classifyTask } = require('../../coordinator/task-classifier.js')
    // Prompt choisi dynamiquement : le test reste valide même si le périmètre de
    // détection codemod du classifieur évolue.
    const CANDIDATES = [
      'remplace var par const dans src/a.js',
      'convertis var en const dans src/a.js',
      'remplace les var par const dans lib/b.js',
    ]
    const codemodPrompt = CANDIDATES.find(p => (classifyTask(p) || {}).tier === 0)
    assert.ok(codemodPrompt,
      `aucun prompt tier 0 trouvé — la garde B5 n'est plus testable, mettre à jour CANDIDATES : ${CANDIDATES.join(' | ')}`)

    const routed = B.routedTier(codemodPrompt)
    assert.equal(routed.tier, 2, 'le tier doit être ramené à 2 EXPLICITEMENT (comme ada.js)')
    assert.equal(routed.codemodBypassed, true, 'le bypass du codemod doit être visible')
    assert.equal(routed.model, 'claude-sonnet-5')
  })

  test('B5 — routedTier n\'invente jamais un tier hors [1,3]', () => {
    for (const p of ['', 'renomme cette variable', 'audit de sécurité performance', 'remplace var par const dans a.js']) {
      const r = B.routedTier(p)
      assert.ok(r.tier >= 1 && r.tier <= 3, `tier ${r.tier} hors [1,3] pour ${JSON.stringify(p)}`)
      assert.ok(r.model && r.model !== 'undefined', `modèle invalide pour ${JSON.stringify(p)}`)
    }
  })

  test('B5 — les lignes de plan portent tier et codemodBypassed', () => {
    const plan = B.buildPlan(FIXTURE_TASKS, { taskIds: ['t-sql'] })
    for (const row of plan) {
      assert.ok(row.tier >= 1 && row.tier <= 3, `tier ${row.tier} invalide`)
      assert.equal(typeof row.codemodBypassed, 'boolean')
    }
  })

  test('outputFile suit la convention /tmp/benchv2-<task>-<arm>.txt', () => {
    const plan = B.buildPlan(FIXTURE_TASKS, { taskIds: ['t-sql'], arms: ['A'] })
    assert.equal(plan[0].outputFile, '/tmp/benchv2-t-sql-A.txt')
  })
})

// ── buildReport (math des deltas) ─────────────────────────────────────────────
describe('buildReport', () => {
  test('moyenne par bras + deltas B−A/C−B/D−C', () => {
    const results = [
      { taskId: 't', category: 'correction-reelle', arm: 'A', score: 40 },
      { taskId: 't', category: 'correction-reelle', arm: 'B', score: 60 },
      { taskId: 't', category: 'correction-reelle', arm: 'C', score: 90 },
      { taskId: 't', category: 'correction-reelle', arm: 'D', score: 90 },
    ]
    const rep = B.buildReport(results)
    const r = rep['correction-reelle']
    assert.equal(r.A, 40); assert.equal(r.B, 60); assert.equal(r.C, 90); assert.equal(r.D, 90)
    assert.equal(r.dBA, 20)  // mémoire
    assert.equal(r.dCB, 30)  // routing/spécialisation
    assert.equal(r.dDC, 0)   // ROI décomposition (nul ici)
  })

  test('moyenne de plusieurs runs du même bras', () => {
    const results = [
      { taskId: 't1', category: 'c', arm: 'A', score: 40 },
      { taskId: 't2', category: 'c', arm: 'A', score: 60 },
    ]
    assert.equal(B.buildReport(results).c.A, 50)
  })

  test('skips (score null) ignorés dans la moyenne', () => {
    const results = [
      { taskId: 't1', category: 'c', arm: 'A', score: null },
      { taskId: 't2', category: 'c', arm: 'A', score: 80 },
    ]
    assert.equal(B.buildReport(results).c.A, 80)
  })

  test('delta null si une borne manque', () => {
    const results = [{ taskId: 't', category: 'c', arm: 'A', score: 50 }]
    const r = B.buildReport(results).c
    assert.equal(r.A, 50)
    assert.equal(r.B, null)
    assert.equal(r.dBA, null)
  })

  test('filtre par catégorie', () => {
    const results = [
      { taskId: 't', category: 'c1', arm: 'A', score: 10 },
      { taskId: 't', category: 'c2', arm: 'A', score: 20 },
    ]
    const rep = B.buildReport(results, 'c2')
    assert.ok(!rep.c1)
    assert.equal(rep.c2.A, 20)
  })
})

// ── Vocabulaire des bras non figé (ADR-021 I3) ────────────────────────────────
// Régression corrigée : `ARMS = ['A','B','C','D']` filtrait buildReport, donc toute
// entrée d'un bras hors ablation (NATIVE/PIPELINE des runs 2026-08-04/06)
// DISPARAISSAIT du rapport agrégé, sans erreur ni avertissement.
describe('buildReport — bras hors A-D', () => {
  const NATIVE_VS_PIPELINE = [
    { taskId: 't1', category: 'above-threshold', arm: 'NATIVE', score: 92 },
    { taskId: 't1', category: 'above-threshold', arm: 'PIPELINE', score: 100 },
    { taskId: 't2', category: 'above-threshold', arm: 'NATIVE', score: 100 },
    { taskId: 't2', category: 'above-threshold', arm: 'PIPELINE', score: 100 },
  ]

  test('un bras hors A-D est agrégé (plus effacé en silence)', () => {
    const r = B.buildReport(NATIVE_VS_PIPELINE)['above-threshold']
    assert.equal(r.arms.NATIVE, 96)
    assert.equal(r.arms.PIPELINE, 100)
    assert.equal(r.runs.NATIVE, 2)
    assert.equal(r.n.PIPELINE, 2)
    // Delta calculé sur la paire non-ablation, dans l'ordre du périmètre.
    assert.equal(r.deltas['PIPELINE-NATIVE'], 4)
    // Les alias d'ablation restent présents et nuls (aucun bras A-D ici).
    assert.equal(r.A, null); assert.equal(r.dBA, null)
  })

  test('périmètre explicite : n\'agrège QUE les bras demandés', () => {
    const rows = [...NATIVE_VS_PIPELINE, { taskId: 't1', category: 'above-threshold', arm: 'A', score: 10 }]
    const r = B.buildReport(rows, { arms: ['NATIVE', 'PIPELINE'] })['above-threshold']
    assert.deepEqual(Object.keys(r.arms), ['NATIVE', 'PIPELINE'])
    assert.equal(r.A, null)
    assert.equal(r.deltas['PIPELINE-NATIVE'], 4)
  })

  test('resolveArms : A-D en tête dans l\'ordre canonique, puis les autres triées', () => {
    const rows = [{ arm: 'PIPELINE' }, { arm: 'C' }, { arm: 'NATIVE' }, { arm: 'A' }]
    assert.deepEqual(B.resolveArms(rows), ['A', 'C', 'NATIVE', 'PIPELINE'])
  })

  test('defaultDeltaPairs : paires historiques d\'ablation, pas de paire inventée', () => {
    assert.deepEqual(B.defaultDeltaPairs(['A', 'C']), [])            // pas de C−A
    assert.deepEqual(B.defaultDeltaPairs(['A', 'B']), [['B', 'A']])
    assert.deepEqual(B.defaultDeltaPairs(['NATIVE', 'PIPELINE']), [['PIPELINE', 'NATIVE']])
  })

  test('≥3 bras hors ablation : aucun appariement deviné, bras signalés comme non comparés', () => {
    const rows = [
      { taskId: 't1', category: 'above-threshold', arm: 'NATIVE', score: 92 },
      { taskId: 't1', category: 'above-threshold', arm: 'NATIVE-T2', score: 92 },
      { taskId: 't1', category: 'above-threshold', arm: 'PIPELINE', score: 100 },
    ]
    assert.deepEqual(B.defaultDeltaPairs(['NATIVE', 'NATIVE-T2', 'PIPELINE']), [])
    const r = B.buildReport(rows)['above-threshold']
    assert.deepEqual(r.deltas, {})
    assert.deepEqual(r.armsUnpaired, ['NATIVE', 'NATIVE-T2', 'PIPELINE'])
    // La comparaison reste possible, mais EXPLICITEMENT demandée.
    const scoped = B.buildReport(rows, { arms: ['NATIVE', 'PIPELINE'] })['above-threshold']
    assert.equal(scoped.deltas['PIPELINE-NATIVE'], 8)
    assert.deepEqual(scoped.armsUnpaired, [])
  })
})

// ── Garde de comparabilité : un delta illégitime ÉCHOUE (ADR-021 I3) ──────────
describe('buildReport — refus explicite des deltas illégitimes', () => {
  test('plan déséquilibré (tâche absente d\'un bras) → erreur claire', () => {
    const results = [
      { taskId: 't1', category: 'c', arm: 'A', score: 50 },
      { taskId: 't2', category: 'c', arm: 'A', score: 90 },
      { taskId: 't1', category: 'c', arm: 'B', score: 60 },
    ]
    assert.throws(() => B.buildReport(results), /plan déséquilibré.*t2/s)
  })

  test('plan déséquilibré (nombre de runs différent pour la même tâche) → erreur', () => {
    const results = [
      { taskId: 't1', category: 'c', arm: 'A', score: 50 },
      { taskId: 't1', category: 'c', arm: 'A', score: 50 },
      { taskId: 't1', category: 'c', arm: 'B', score: 60 },
    ]
    assert.throws(() => B.buildReport(results), /plan déséquilibré.*1 run\(s\) en B contre 2 en A/s)
  })

  test('scorerSha mélangés pour la même tâche → erreur (deux instruments, pas deux bras)', () => {
    const results = [
      { taskId: 't1', category: 'c', arm: 'A', score: 73, scorerSha: 'git:aaa' },
      { taskId: 't1', category: 'c', arm: 'B', score: 100, scorerSha: 'git:bbb' },
    ]
    assert.throws(() => B.buildReport(results), /scorerSha mélangés pour la tâche t1/)
  })

  test('cellule ambiguë (2 scores différents pour un même couple tâche/bras) → erreur', () => {
    const results = [
      { taskId: 't1', category: 'c', arm: 'NATIVE', score: 73 },
      { taskId: 't1', category: 'c', arm: 'NATIVE', score: 100 },
      { taskId: 't1', category: 'c', arm: 'PIPELINE', score: 100 },
      { taskId: 't1', category: 'c', arm: 'PIPELINE', score: 100 },
    ]
    assert.throws(() => B.buildReport(results), /cellule \(t1, NATIVE\) porte 2 scores différents \(73\/100\)/)
  })

  test('scorerSha identiques → aucun refus', () => {
    const results = [
      { taskId: 't1', category: 'c', arm: 'A', score: 80, scorerSha: 'git:aaa' },
      { taskId: 't1', category: 'c', arm: 'B', score: 100, scorerSha: 'git:aaa' },
    ]
    assert.equal(B.buildReport(results).c.dBA, 20)
  })

  test('deltas:false → moyennes rendues, aucun delta, aucune erreur', () => {
    const results = [
      { taskId: 't1', category: 'c', arm: 'A', score: 50, scorerSha: 'git:aaa' },
      { taskId: 't1', category: 'c', arm: 'B', score: 60, scorerSha: 'git:bbb' },
    ]
    const r = B.buildReport(results, { deltas: false }).c
    assert.equal(r.A, 50); assert.equal(r.B, 60)
    assert.equal(r.dBA, null)
  })

  test('delta manquant d\'une borne : null, jamais une erreur', () => {
    const results = [{ taskId: 't1', category: 'c', arm: 'A', score: 50 }, { taskId: 't2', category: 'c', arm: 'A', score: 50 }]
    assert.equal(B.buildReport(results, { arms: ['A', 'B'] }).c.dBA, null)
  })
})

// ── Provenance des enregistrements (ADR-021 I3) ───────────────────────────────
describe('provenance', () => {
  test('normalizeArm accepte toute étiquette plausible, rejette l\'absurde', () => {
    assert.equal(B.normalizeArm('a'), 'A')
    assert.equal(B.normalizeArm(' native '), 'NATIVE')
    assert.equal(B.normalizeArm('B2-safety'), 'B2-SAFETY')
    for (const bad of ['', '   ', null, undefined, '-x', 'a b', 'A;DROP']) {
      assert.throws(() => B.normalizeArm(bad), /étiquette de bras invalide/)
    }
  })

  test('newRunId : unique et horodaté', () => {
    const a = B.newRunId(), b = B.newRunId()
    assert.match(a, /^\d{8}T\d{6}-[a-z0-9]{1,6}$/)
    assert.notEqual(a, b)
  })

  test('provenanceSha : préfixe explicite git: ou sha256:', () => {
    const sha = B.provenanceSha(join(__dirname, '../../coordinator/bench-v2.js'))
    assert.match(sha, /^(git:[0-9a-f]{40}|sha256:[0-9a-f]{16})$/)
  })

  test('contentSha : déterministe, null si fichier absent', () => {
    const p = join(__dirname, '../../coordinator/bench-v2.js')
    assert.equal(B.contentSha(p), B.contentSha(p))
    assert.equal(B.contentSha(join(__dirname, 'fichier-inexistant-xyz')), null)
  })

  test('CLI score écrit runId/scorerSha/tasksSha/model, y compris pour un bras hors A-D', () => {
    const { mkdtempSync, readFileSync, rmSync } = require('fs')
    const dir = mkdtempSync(join(require('os').tmpdir(), 'benchv2-prov-'))
    const resultsFile = join(dir, 'results.json')
    try {
      const cli = join(__dirname, '../../coordinator/bench-v2.js')
      const tasks = require('../../benchmarks/v2/tasks-v2.json').tasks
      // Catégorie 'planned' → skip explicite (score null), aucun psql requis.
      const r = spawnSync('node', [cli, 'score', tasks[0].id, 'native', '--category', 'qualite', '--model', 'claude-sonnet-4-6'],
        { encoding: 'utf8', timeout: 30000, env: { ...process.env, BENCH_V2_RESULTS_FILE: resultsFile } })
      assert.equal(r.status, 0, r.stderr)
      const entries = JSON.parse(readFileSync(resultsFile, 'utf8')).results
      assert.equal(entries.length, 1)
      const e = entries[0]
      assert.equal(e.arm, 'NATIVE')          // bras hors A-D enregistré, pas rejeté
      assert.equal(e.score, null)
      assert.equal(e.model, 'claude-sonnet-4-6')
      assert.match(e.runId, /^\d{8}T\d{6}-[a-z0-9]{1,6}$/)
      assert.match(e.scorerSha, /^(git:[0-9a-f]{40}|sha256:[0-9a-f]{16})$/)
      assert.match(e.tasksSha, /^(git:[0-9a-f]{40}|sha256:[0-9a-f]{16})$/)
      assert.ok(e.ts)
    } finally {
      rmSync(dir, { recursive: true, force: true })
    }
  })

  test('CLI score : deux scores d\'une même invocation partagent le runId, deux invocations non', () => {
    const { mkdtempSync, readFileSync, rmSync } = require('fs')
    const dir = mkdtempSync(join(require('os').tmpdir(), 'benchv2-prov2-'))
    const resultsFile = join(dir, 'results.json')
    try {
      const cli = join(__dirname, '../../coordinator/bench-v2.js')
      const tasks = require('../../benchmarks/v2/tasks-v2.json').tasks
      const env = { ...process.env, BENCH_V2_RESULTS_FILE: resultsFile }
      for (const arm of ['NATIVE', 'PIPELINE']) {
        const r = spawnSync('node', [cli, 'score', tasks[0].id, arm, '--category', 'qualite'], { encoding: 'utf8', timeout: 30000, env })
        assert.equal(r.status, 0, r.stderr)
      }
      const entries = JSON.parse(readFileSync(resultsFile, 'utf8')).results
      assert.equal(entries.length, 2)
      assert.notEqual(entries[0].runId, entries[1].runId)  // 2 process = 2 runId
      assert.equal(entries[0].scorerSha, entries[1].scorerSha)
    } finally {
      rmSync(dir, { recursive: true, force: true })
    }
  })
})

// ── Registre des catégories ───────────────────────────────────────────────────
describe('CATEGORY_REGISTRY', () => {
  test('les 9 catégories sont déclarées', () => {
    const expected = ['qualite', 'exec-time', 'conventions-tacites', 'token-efficiency',
      'correction-reelle', 'valeur-multi-tours', 'precision-recuperation', 'roi-decomposition-routing',
      'above-threshold']
    for (const c of expected) assert.ok(B.CATEGORY_REGISTRY[c], `manque ${c}`)
  })
  test('6 sont câblées (wired)', () => {
    const wired = Object.entries(B.CATEGORY_REGISTRY).filter(([, r]) => r.status === 'wired').map(([k]) => k)
    assert.deepEqual(wired.sort(), ['above-threshold', 'conventions-tacites', 'correction-reelle', 'correction-reelle-docker', 'correction-reelle-ts', 'precision-recuperation'])
  })
  test('correction-reelle-ts utilise le scorer ts (ADR-021 Action 3, hors mono-domaine SQL)', () => {
    assert.equal(B.CATEGORY_REGISTRY['correction-reelle-ts'].scorer, 'ts')
  })
  test('correction-reelle-docker utilise le scorer docker (ADR-021 Action 3, finding G8)', () => {
    assert.equal(B.CATEGORY_REGISTRY['correction-reelle-docker'].scorer, 'docker')
  })
  test('les 5 autres sont planned', () => {
    const planned = Object.entries(B.CATEGORY_REGISTRY).filter(([, r]) => r.status === 'planned')
    assert.equal(planned.length, 5)
  })
  test('conventions-tacites utilise le scorer SQL', () => {
    assert.equal(B.CATEGORY_REGISTRY['conventions-tacites'].scorer, 'sql')
  })
})

// ── Intégration Postgres (guardée, skip si indisponible) ──────────────────────
function pgUp() {
  try {
    const r = spawnSync('psql', ['postgres', '-tAc', 'SELECT 1'], { encoding: 'utf8', timeout: 8000 })
    return r.status === 0 && (r.stdout || '').trim() === '1'
  } catch { return false }
}

describe('scorer SQL (intégration Postgres)', () => {
  test('end-to-end : livrable correct → 100% des assertions', { skip: !pgUp() && 'postgres indisponible' }, () => {
    const tasks = require('../../benchmarks/v2/tasks-v2.json').tasks
    const task = tasks.find(t => t.id === 'sql-amounts-cents-bigint')
    const deliverable = '```sql\n' +
      'CREATE TABLE payments (\n' +
      "  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),\n" +
      '  amount_cents BIGINT NOT NULL,\n' +
      "  currency char(3) NOT NULL DEFAULT 'EUR',\n" +
      '  CONSTRAINT amount_positive CHECK (amount_cents >= 0)\n' +
      ');\n```'
    // scoreSqlDeliverable n'est pas exporté (impur) ; on passe par le CLI score.
    // Ici on valide juste les briques pures sur ce livrable.
    const blocks = B.extractSqlBlocks(deliverable)
    assert.equal(blocks.length, 1)
    assert.ok(task.assets.assertions.length >= 4)
  })
})

// ── Télémétrie d'efficience (G6, ADR-021 principe #9 ; ADR-023 étape 1) ───────
// bench-v2.js ne spawn PAS d'agents (ADR-021 finding F7) : ces métriques ne
// peuvent pas être mesurées automatiquement par le scorer, seulement fournies
// par l'appelant via des flags optionnels puis PERSISTÉES telles quelles.
describe('parseNumericFlag (G6)', () => {
  test('flag absent → null (jamais 0)', () => {
    assert.equal(B.parseNumericFlag({}, 'tokens-input'), null)
    assert.equal(B.parseNumericFlag({ 'cost-usd': undefined }, 'cost-usd'), null)
  })

  test('flag numérique (entier ou décimal) → Number', () => {
    assert.equal(B.parseNumericFlag({ 'tokens-input': '1234' }, 'tokens-input'), 1234)
    assert.equal(B.parseNumericFlag({ 'cost-usd': '0.0042' }, 'cost-usd'), 0.0042)
    assert.equal(B.parseNumericFlag({ 'agent-calls': '0' }, 'agent-calls'), 0) // 0 explicite ≠ absent
  })

  test('flag booléen (aucune valeur suivante, cf. parseFlags) → erreur explicite', () => {
    assert.throws(() => B.parseNumericFlag({ 'tokens-input': true }, 'tokens-input'), /--tokens-input attend une valeur numérique/)
  })

  test('flag non numérique ou vide → erreur explicite, jamais une coercition silencieuse', () => {
    assert.throws(() => B.parseNumericFlag({ 'cost-usd': 'abc' }, 'cost-usd'), /--cost-usd attend une valeur numérique/)
    assert.throws(() => B.parseNumericFlag({ 'cost-usd': '   ' }, 'cost-usd'), /attend une valeur numérique/)
    assert.throws(() => B.parseNumericFlag({ 'cost-usd': 'NaN' }, 'cost-usd'), /attend une valeur numérique/)
  })
})

describe('buildReport — télémétrie d\'efficience (G6)', () => {
  test('moyennes coût/tokens/wallClock/agentCalls par bras, quand fournies', () => {
    const results = [
      { taskId: 't1', category: 'c', arm: 'A', score: 50, costUsd: 0.10, wallClockMs: 4000, agentCalls: 1,
        tokens: { input: 1000, output: 500, cacheRead: 0, cacheWrite: 0 } },
      { taskId: 't2', category: 'c', arm: 'A', score: 90, costUsd: 0.30, wallClockMs: 8000, agentCalls: 1,
        tokens: { input: 2000, output: 1000, cacheRead: 100, cacheWrite: 0 } },
    ]
    const tel = B.buildReport(results).c.telemetry.A
    assert.equal(tel.avgCostUsd, 0.2)
    assert.equal(tel.avgTokensTotal, 2300) // (1500+3100)/2
    assert.equal(tel.avgWallClockMs, 6000)
    assert.equal(tel.avgAgentCalls, 1)
    assert.equal(tel.nCostUsd, 2)
    assert.equal(tel.nTokensTotal, 2)
    assert.equal(tel.nWallClockMs, 2)
    assert.equal(tel.nAgentCalls, 2)
  })

  test('champs de télémétrie absents (results-v2.json pré-G6) → moyennes null, n=0, rien ne casse', () => {
    const results = [{ taskId: 't', category: 'c', arm: 'A', score: 50 }]
    const tel = B.buildReport(results).c.telemetry.A
    assert.deepEqual(tel, {
      avgCostUsd: null, avgTokensTotal: null, avgWallClockMs: null, avgAgentCalls: null,
      nCostUsd: 0, nTokensTotal: 0, nWallClockMs: 0, nAgentCalls: 0,
    })
    // Le reste du rapport (moyennes de score, deltas) reste inchangé.
    assert.equal(B.buildReport(results).c.A, 50)
  })

  test('mélange d\'entrées avec et sans télémétrie → moyenne calculée seulement sur les entrées mesurées', () => {
    const results = [
      { taskId: 't1', category: 'c', arm: 'A', score: 50, costUsd: 0.10 },
      { taskId: 't2', category: 'c', arm: 'A', score: 90 }, // pas de costUsd
    ]
    const tel = B.buildReport(results).c.telemetry.A
    assert.equal(tel.avgCostUsd, 0.10)
    assert.equal(tel.nCostUsd, 1)
  })

  test('télémétrie d\'un trial skip (score null) n\'est pas perdue', () => {
    const results = [{ taskId: 't1', category: 'c', arm: 'A', score: null, costUsd: 0.50, agentCalls: 2 }]
    const tel = B.buildReport(results).c.telemetry.A
    assert.equal(tel.avgCostUsd, 0.50)
    assert.equal(tel.avgAgentCalls, 2)
  })

  test('total de tokens partiel (sous-champs manquants) : somme des sous-champs présents seulement', () => {
    const results = [{ taskId: 't1', category: 'c', arm: 'A', score: 50, tokens: { input: 100, output: null, cacheRead: null, cacheWrite: null } }]
    assert.equal(B.buildReport(results).c.telemetry.A.avgTokensTotal, 100)
  })
})

describe('CLI score — télémétrie d\'efficience (G6)', () => {
  test('flags de télémétrie acceptés et persistés tels quels', () => {
    const { mkdtempSync, readFileSync, rmSync } = require('fs')
    const dir = mkdtempSync(join(require('os').tmpdir(), 'benchv2-tel-'))
    const resultsFile = join(dir, 'results.json')
    try {
      const cli = join(__dirname, '../../coordinator/bench-v2.js')
      const tasks = require('../../benchmarks/v2/tasks-v2.json').tasks
      const r = spawnSync('node', [cli, 'score', tasks[0].id, 'native', '--category', 'qualite',
        '--tokens-input', '1200', '--tokens-output', '340', '--tokens-cache-read', '0', '--tokens-cache-write', '0',
        '--cost-usd', '0.0087', '--wall-clock-ms', '54000', '--agent-calls', '2'],
        { encoding: 'utf8', timeout: 30000, env: { ...process.env, BENCH_V2_RESULTS_FILE: resultsFile } })
      assert.equal(r.status, 0, r.stderr)
      const e = JSON.parse(readFileSync(resultsFile, 'utf8')).results[0]
      assert.deepEqual(e.tokens, { input: 1200, output: 340, cacheRead: 0, cacheWrite: 0 })
      assert.equal(e.costUsd, 0.0087)
      assert.equal(e.wallClockMs, 54000)
      assert.equal(e.agentCalls, 2)
    } finally {
      rmSync(dir, { recursive: true, force: true })
    }
  })

  test('absence de flags de télémétrie → tous les champs null, jamais 0', () => {
    const { mkdtempSync, readFileSync, rmSync } = require('fs')
    const dir = mkdtempSync(join(require('os').tmpdir(), 'benchv2-tel2-'))
    const resultsFile = join(dir, 'results.json')
    try {
      const cli = join(__dirname, '../../coordinator/bench-v2.js')
      const tasks = require('../../benchmarks/v2/tasks-v2.json').tasks
      const r = spawnSync('node', [cli, 'score', tasks[0].id, 'native', '--category', 'qualite'],
        { encoding: 'utf8', timeout: 30000, env: { ...process.env, BENCH_V2_RESULTS_FILE: resultsFile } })
      assert.equal(r.status, 0, r.stderr)
      const e = JSON.parse(readFileSync(resultsFile, 'utf8')).results[0]
      assert.equal(e.tokens, null)
      assert.equal(e.costUsd, null)
      assert.equal(e.wallClockMs, null)
      assert.equal(e.agentCalls, null)
    } finally {
      rmSync(dir, { recursive: true, force: true })
    }
  })

  test('flag numérique invalide → erreur claire, exit non-zéro, aucune entrée écrite', () => {
    const { mkdtempSync, existsSync, rmSync } = require('fs')
    const dir = mkdtempSync(join(require('os').tmpdir(), 'benchv2-tel3-'))
    const resultsFile = join(dir, 'results.json')
    try {
      const cli = join(__dirname, '../../coordinator/bench-v2.js')
      const tasks = require('../../benchmarks/v2/tasks-v2.json').tasks
      const r = spawnSync('node', [cli, 'score', tasks[0].id, 'native', '--category', 'qualite', '--cost-usd', 'abc'],
        { encoding: 'utf8', timeout: 30000, env: { ...process.env, BENCH_V2_RESULTS_FILE: resultsFile } })
      assert.notEqual(r.status, 0)
      assert.match(r.stderr, /cost-usd.*valeur numérique/)
      assert.equal(existsSync(resultsFile), false)
    } finally {
      rmSync(dir, { recursive: true, force: true })
    }
  })

  test('report (texte et --json) ne casse pas sur un mélange d\'entrées avec et sans télémétrie', () => {
    const { mkdtempSync, writeFileSync, rmSync } = require('fs')
    const dir = mkdtempSync(join(require('os').tmpdir(), 'benchv2-tel4-'))
    const resultsFile = join(dir, 'results.json')
    try {
      const cli = join(__dirname, '../../coordinator/bench-v2.js')
      // Écrit directement le fichier de résultats (pas besoin de Postgres/tsc/docker
      // pour ce test : on vérifie le rendu de `report`, pas le scorer).
      const seeded = {
        version: 2,
        results: [
          {
            taskId: 't1', category: 'correction-reelle', arm: 'A', score: 80,
            tokens: { input: 1000, output: 200, cacheRead: 0, cacheWrite: 0 },
            costUsd: 0.02, wallClockMs: 5000, agentCalls: 1,
          },
          { taskId: 't1', category: 'correction-reelle', arm: 'B', score: 100 }, // aucune télémétrie
        ],
      }
      writeFileSync(resultsFile, JSON.stringify(seeded, null, 2))
      const env = { ...process.env, BENCH_V2_RESULTS_FILE: resultsFile }

      const rText = spawnSync('node', [cli, 'report'], { encoding: 'utf8', timeout: 30000, env })
      assert.equal(rText.status, 0, rText.stderr)
      assert.match(rText.stdout, /Télémétrie d'efficience/)
      assert.match(rText.stdout, /correction-reelle/)
      assert.match(rText.stdout, /coût=\$0\.02/)

      const rJson = spawnSync('node', [cli, 'report', '--json'], { encoding: 'utf8', timeout: 30000, env })
      assert.equal(rJson.status, 0, rJson.stderr)
      const parsed = JSON.parse(rJson.stdout)
      const tel = parsed['correction-reelle'].telemetry
      assert.equal(tel.A.avgCostUsd, 0.02)
      assert.equal(tel.A.avgAgentCalls, 1)
      assert.deepEqual(tel.B, {
        avgCostUsd: null, avgTokensTotal: null, avgWallClockMs: null, avgAgentCalls: null,
        nCostUsd: 0, nTokensTotal: 0, nWallClockMs: 0, nAgentCalls: 0,
      })
      // Le score et son delta restent calculés normalement : la télémétrie
      // n'interfère pas avec le format existant.
      assert.equal(parsed['correction-reelle'].A, 80)
      assert.equal(parsed['correction-reelle'].B, 100)
    } finally {
      rmSync(dir, { recursive: true, force: true })
    }
  })

  test('report sur les 46 entrées historiques (sans télémétrie) ne régresse pas', () => {
    const cli = join(__dirname, '../../coordinator/bench-v2.js')
    const r = spawnSync('node', [cli, 'report', '--json'], { encoding: 'utf8', timeout: 30000 })
    assert.equal(r.status, 0, r.stderr)
    const parsed = JSON.parse(r.stdout)
    // Chaque catégorie présente a désormais une clé `telemetry`, cohérente
    // avec les bras présents — mais rien n'est cassé par son absence de valeur.
    for (const cat of Object.values(parsed)) {
      assert.ok(cat.telemetry && typeof cat.telemetry === 'object')
      for (const arm of Object.keys(cat.arms || {})) {
        assert.ok(cat.telemetry[arm], `bras ${arm} manquant dans telemetry`)
      }
    }
  })
})
