#!/usr/bin/env node
'use strict'
/**
 * benchmark.test.js — Axe D : verifyOutput.conventionScore (savoir tacite) +
 * sélection du bon baseline (naive par défaut, sinon naked, --baseline respecté).
 * Fonctions pures, déterministes — pas d'I/O ni de réseau.
 */
const { test, describe } = require('node:test')
const assert = require('node:assert/strict')

const { verifyOutput, selectBaseline } = require('../../coordinator/benchmark.js')

// Tâche avec conventions tacites (les patterns ne sont PAS dans le prompt).
const taskWithConventions = {
  id: 'demo',
  checks: [
    { name: 'workspace', pattern: 'workspace_id', required: true },
    { name: 'create', pattern: 'create', required: true },
  ],
  tacitConventions: [
    { name: 'cents', pattern: '_cents|amount_cents|centimes' },
    { name: 'soft-delete', pattern: 'deleted_at' },
    { name: 'keyset', pattern: 'cursor|keyset|nextCursor' },
    { name: 'outbox', pattern: 'outbox' },
  ],
}

// Tâche sans conventions tacites (forme existante) — rétro-compat.
const legacyTask = {
  id: 'legacy',
  checks: [
    { name: 'workspace', pattern: 'workspace_id', required: true },
    { name: 'uuid', pattern: 'uuid', required: true },
  ],
}

describe('verifyOutput — conventionScore (savoir tacite)', () => {
  test('toutes les conventions matchées → 100', () => {
    const out = 'workspace_id, create(), amount_cents, deleted_at, nextCursor, outbox_table'
    const v = verifyOutput(taskWithConventions, out)
    assert.equal(v.conventionScore, 100)
    assert.deepEqual(v.conventionsFailed, [])
    assert.equal(v.conventionsPassed.length, 4)
  })

  test('conventions partielles → pourcentage arrondi (2/4 = 50)', () => {
    const out = 'workspace_id, create(), amount_cents, deleted_at' // cents + soft-delete only
    const v = verifyOutput(taskWithConventions, out)
    assert.equal(v.conventionScore, 50)
    assert.deepEqual(v.conventionsPassed.sort(), ['cents', 'soft-delete'])
    assert.deepEqual(v.conventionsFailed.sort(), ['keyset', 'outbox'])
  })

  test('aucune convention matchée → 0', () => {
    const out = 'workspace_id, create()' // checks OK mais zéro convention
    const v = verifyOutput(taskWithConventions, out)
    assert.equal(v.conventionScore, 0)
    assert.equal(v.conventionsPassed.length, 0)
    assert.equal(v.conventionsFailed.length, 4)
  })

  test('insensible à la casse', () => {
    const out = 'AMOUNT_CENTS DELETED_AT KEYSET OUTBOX'
    const v = verifyOutput(taskWithConventions, out)
    assert.equal(v.conventionScore, 100)
  })

  test('conventionScore null si la tâche n\'a pas de tacitConventions (rétro-compat)', () => {
    const v = verifyOutput(legacyTask, 'workspace_id et uuid présents')
    assert.equal(v.conventionScore, null)
    assert.equal(v.conventionsPassed.length, 0)
    assert.equal(v.conventionsFailed.length, 0)
  })

  test('score fonctionnel inchangé sur une tâche legacy (rétro-compat)', () => {
    const full = verifyOutput(legacyTask, 'workspace_id uuid')
    assert.equal(full.score, 100)
    assert.equal(full.pass, true)
    const half = verifyOutput(legacyTask, 'workspace_id seulement')
    assert.equal(half.score, 50)
    assert.equal(half.pass, false)
  })

  test('le score fonctionnel est indépendant du conventionScore', () => {
    // checks OK (100) mais conventions absentes (0) — deux dimensions séparées.
    const v = verifyOutput(taskWithConventions, 'workspace_id create()')
    assert.equal(v.score, 100)
    assert.equal(v.conventionScore, 0)
  })

  test('null si ni checks ni tacitConventions', () => {
    assert.equal(verifyOutput({ id: 'empty' }, 'peu importe'), null)
  })
})

describe('selectBaseline — le bon témoin', () => {
  const withNaive = [
    { arm: 'ada' }, { arm: 'naive' }, { arm: 'naked' },
  ]
  const withoutNaive = [
    { arm: 'ada' }, { arm: 'naked' },
  ]

  test('défaut → naive si des runs naive existent', () => {
    assert.equal(selectBaseline(withNaive, undefined), 'naive')
    assert.equal(selectBaseline(withNaive, null), 'naive')
  })

  test('défaut → naked si aucun run naive (rétro-compat)', () => {
    assert.equal(selectBaseline(withoutNaive, undefined), 'naked')
    assert.equal(selectBaseline([{ arm: 'ada' }], null), 'naked')
  })

  test('--baseline naked explicite respecté même si naive présent', () => {
    assert.equal(selectBaseline(withNaive, 'naked'), 'naked')
  })

  test('--baseline naive explicite respecté même sans run naive', () => {
    assert.equal(selectBaseline(withoutNaive, 'naive'), 'naive')
  })

  test('valeur invalide ignorée → repli sur le défaut', () => {
    assert.equal(selectBaseline(withNaive, 'bogus'), 'naive')
    assert.equal(selectBaseline(withoutNaive, 'bogus'), 'naked')
  })
})
