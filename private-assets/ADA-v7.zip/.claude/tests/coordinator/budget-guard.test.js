#!/usr/bin/env node
'use strict'
const { test, describe, before, after, beforeEach } = require('node:test')
const assert = require('node:assert/strict')
const { mkdirSync, rmSync, existsSync, readFileSync, writeFileSync, mkdtempSync, appendFileSync } = require('fs')
const { join, basename } = require('path')
const { homedir, tmpdir } = require('os')
const { spawn } = require('child_process')

// ── Isolation GLOBALE du journal réel ────────────────────────────────────────
// budget-guard.js résout LOG_DIR au chargement du module : `process.env
// .ADA_LOG_DIR || ~/.ada/logs`. Sans cette surcharge, le bloc « recordCost +
// getDailyCost + getSessionCost » plus bas écrivait dans le VRAI journal
// budgétaire de la machine qui exécute les tests. Un journal budgétaire réel
// a déjà été perdu en masse sur ce projet ; aucun test ne doit pouvoir y
// toucher. Doit rester AVANT tout require() de budget-guard.js.
process.env.ADA_LOG_DIR = mkdtempSync(join(tmpdir(), 'ada-budget-suite-'))

const TMP         = join(__dirname, '../../..', '.test-tmp-budget')
const ADA_JSON    = join(TMP, '.ada.json')
const LOG_DIR     = join(TMP, '.ada', 'logs')
const LOG_FILE    = join(LOG_DIR, 'budget-log.json')
const BG_JS       = join(__dirname, '../../coordinator/budget-guard.js')
const MIGRATE_JS  = join(__dirname, '../../coordinator/migrate-budget-log.js')

/** Nom du shard NDJSON attendu pour une date donnée (miroir de budget-guard). */
function shardName(prefix, date) {
  return `${prefix}-${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, '0')}.ndjson`
}

/** Recharge budget-guard (et le script de migration) avec un LOG_DIR neuf. */
function loadWith(logDir) {
  process.env.ADA_LOG_DIR = logDir
  Object.keys(require.cache).forEach(k => {
    if (k.includes('budget-guard') || k.includes('migrate-budget-log')) delete require.cache[k]
  })
  return { bg: require(BG_JS), mig: require(MIGRATE_JS) }
}

/** Compte les lignes non vides de tous les shards NDJSON d'un répertoire. */
function countNdjsonLines(dir, prefix) {
  if (!existsSync(dir)) return 0
  return require('fs').readdirSync(dir)
    .filter(f => f.startsWith(prefix + '-') && f.endsWith('.ndjson'))
    .reduce((n, f) => n + readFileSync(join(dir, f), 'utf8').split('\n').filter(Boolean).length, 0)
}

let bg

function loadModule() {
  // Vider le cache pour isoler chaque test
  Object.keys(require.cache).forEach(k => { if (k.includes('budget-guard')) delete require.cache[k] })
  // Patcher le chemin vers ~/.ada.json et ~/.ada/logs via monkey-patching interne
  // budget-guard.js utilise homedir() au niveau module → on remplace via surcharge de 'os'
  // Alternative : on exporte les paths pour les tests, mais ici on patch via env
  return require(BG_JS)
}

// Patch : budget-guard.js calcule ses chemins depuis homedir() au load-time
// On va directement manipuler les fichiers au même endroit que le module les attend
// (les tests écrivent dans le vrai home mais sous des noms de tests)
// Pour l'isolation, on réimplémente les fonctions core en leur injectant les chemins.

/**
 * Fonctions utilitaires réimplantées avec chemins TMP pour les tests.
 * On valide la LOGIQUE métier, pas l'I/O (déjà testé par l'écriture atomique).
 */
const { checkBudget } = (() => {
  // Chargement direct pour les tests unitaires purs
  const module = require(BG_JS)
  return module
})()

// ── Tests unitaires purs (sans I/O) ──────────────────────────────────────────

describe('checkBudget — logique pure', () => {
  const baseConfig = {
    perRun: 5,
    perSession: 20,
    perDay: 50,
    onExceed: 'warn',
    alertAt: 0.8,
  }

  test('retourne continue si bien en dessous du seuil', () => {
    const result = checkBudget('run-1', 0.10, 0.50, baseConfig)
    assert.equal(result.action, 'continue')
    assert.equal(result.ok, true)
    assert.equal(result.message, '')
  })

  test('retourne warn quand ratio >= alertAt mais pas encore dépassé', () => {
    // 4.10 / 5.00 = 82% >= 80% (alertAt)
    const result = checkBudget('run-1', 0.10, 4.10, baseConfig)
    assert.equal(result.action, 'warn')
    assert.equal(result.ok, true)
    assert.match(result.message, /82%|80%|81%/)
  })

  test('retourne warn quand onExceed=warn et budget dépassé', () => {
    const config = { ...baseConfig, onExceed: 'warn' }
    const result = checkBudget('run-1', 0.50, 5.50, config)
    assert.equal(result.action, 'warn')
    assert.equal(result.ok, false)
    assert.match(result.message, /dépassé|Budget/)
  })

  test('retourne stop quand onExceed=stop et budget dépassé', () => {
    const config = { ...baseConfig, onExceed: 'stop' }
    const result = checkBudget('run-1', 0.50, 5.50, config)
    assert.equal(result.action, 'stop')
    assert.equal(result.ok, false)
    assert.match(result.message, /dépassé|Budget/)
  })

  test('retourne downgrade_tier quand onExceed=downgrade et budget dépassé', () => {
    const config = { ...baseConfig, onExceed: 'downgrade' }
    const result = checkBudget('run-1', 0.50, 5.50, config)
    assert.equal(result.action, 'downgrade_tier')
    assert.equal(result.ok, false)
  })

  test('retourne continue exactement au seuil alertAt (limite basse)', () => {
    // 3.99 / 5 = 79.8% < 80% → continue
    const result = checkBudget('run-1', 0.10, 3.99, baseConfig)
    assert.equal(result.action, 'continue')
  })

  test('retourne continue quand perRun=0 (budget désactivé)', () => {
    const config = { ...baseConfig, perRun: 0 }
    // ratio = 0/0 → pas de dépassement (cumulCost 0 < 0 n'est jamais vrai)
    const result = checkBudget('run-1', 0, 0, config)
    // cumulCost (0) >= perRun (0) → dépassement mais géré
    // On accepte warn ou continue selon l'implémentation
    assert.ok(['continue', 'warn'].includes(result.action))
  })

  test('message inclut le montant formaté', () => {
    const config = { ...baseConfig, onExceed: 'stop' }
    const result = checkBudget('run-1', 1.00, 6.00, config)
    assert.match(result.message, /\$6\.00/)
  })
})

// ── Tests d'interface (avec I/O dans home réel) ───────────────────────────────
// Ces tests utilisent les vraies fonctions avec des runId uniques pour éviter
// les collisions avec les données de production.

describe('loadBudgetConfig — valeurs par défaut', () => {
  test('retourne les valeurs par défaut si budget absent de .ada.json', () => {
    const bg = require(BG_JS)
    const config = bg.loadBudgetConfig()
    // Valider la structure (les valeurs exactes dépendent du fichier home)
    assert.ok(typeof config.perRun === 'number')
    assert.ok(typeof config.perSession === 'number')
    assert.ok(typeof config.perDay === 'number')
    assert.ok(['warn', 'stop', 'downgrade'].includes(config.onExceed))
    assert.ok(config.alertAt >= 0 && config.alertAt <= 1)
  })
})

describe('recordCost + getDailyCost + getSessionCost', () => {
  const TEST_RUN_ID = `test-budget-${Date.now()}`

  test('recordCost ajoute une entrée, getSessionCost la restitue', () => {
    const bg = require(BG_JS)
    const before = bg.getSessionCost(TEST_RUN_ID)
    bg.recordCost(TEST_RUN_ID, 1.23, 'claude-sonnet-4-6')
    const after = bg.getSessionCost(TEST_RUN_ID)
    assert.ok(after - before >= 1.23 - 0.001)
  })

  test('getDailyCost inclut le coût enregistré aujourd\'hui', () => {
    const bg = require(BG_JS)
    const before = bg.getDailyCost()
    bg.recordCost(TEST_RUN_ID, 0.55)
    const after = bg.getDailyCost()
    assert.ok(after - before >= 0.55 - 0.001)
  })

  test('getSessionCost filtre par runId', () => {
    const bg = require(BG_JS)
    const otherRun = `test-other-${Date.now()}`
    const before = bg.getSessionCost(TEST_RUN_ID + '-b')
    bg.recordCost(otherRun, 99.99)
    const after = bg.getSessionCost(TEST_RUN_ID + '-b')
    // Ne doit pas avoir augmenté
    assert.equal(before, after)
  })
})

// ── F1a — collision du nom de fichier temporaire dans atomicWriteJson ────────
// Audit 2026-09-09 (docs/AUDIT-ADA-2026-09-09.md, F1a) : atomicWriteJson()
// utilise le MÊME chemin `<filePath>.tmp` pour tous les process. Plusieurs
// process Node concurrents qui appellent recordCost() sur le même LOG_FILE se
// marchent dessus sur ce fichier tmp partagé : writeFileSync/renameSync de
// l'un écrase ou fait disparaître le tmp de l'autre → exceptions (ENOENT) au
// renameSync. Repro basée sur docs/audit-evidence-2026-09-09/budget-concurrency.cjs
// (8 process concurrents, journal partagé via ADA_LOG_DIR).
//
// F1b (ce fix) ÉLARGIT la promesse : le test n'exige plus seulement zéro
// exception, il exige zéro PERTE — chaque écriture tentée doit se retrouver
// exactement une fois dans le journal. C'est la course lecture-modification-
// écriture elle-même qui est visée, pas seulement la collision de nom de
// fichier temporaire. L'assertion F1a d'origine (0 exception) est conservée
// telle quelle dans le même test : elle reste une régression valable.
describe('journal budgétaire — écritures concurrentes sans perte (F1a + F1b)', () => {
  const N_PROCS = 6
  const WRITES_PER_PROC = 20

  function runConcurrentWriters(sharedLogDir) {
    return new Promise((resolve, reject) => {
      const workerSrc = `
        const bg = require(${JSON.stringify(BG_JS)});
        process.send('ready');
        process.on('message', () => {
          let errors = 0;
          // Même runId pour tous les process : getSessionCost() doit retrouver
          // la somme EXACTE de toutes les écritures tentées.
          for (let i = 0; i < ${WRITES_PER_PROC}; i++) {
            try { bg.recordCost('f1b-shared-run', 0.01, 'f1b-test'); }
            catch { errors++; }
          }
          process.send({ errors });
          process.exit(0);
        });
      `
      const workerFile = join(sharedLogDir, `worker-${process.pid}-${Math.random().toString(36).slice(2)}.js`)
      writeFileSync(workerFile, workerSrc, 'utf8')

      const children = []
      let ready = 0
      let done = 0
      let totalErrors = 0
      const timeout = setTimeout(() => {
        children.forEach(c => { try { c.kill() } catch { /* noop */ } })
        reject(new Error('timeout: les process concurrents ne se sont pas terminés à temps'))
      }, 20000)

      for (let i = 0; i < N_PROCS; i++) {
        const child = spawn(process.execPath, [workerFile], {
          env: { ...process.env, ADA_LOG_DIR: sharedLogDir },
          stdio: ['ignore', 'ignore', 'ignore', 'ipc'],
        })
        children.push(child)
        child.on('message', (m) => {
          if (m === 'ready') {
            if (++ready === N_PROCS) children.forEach(c => c.send('go'))
          } else {
            totalErrors += m.errors
            if (++done === N_PROCS) {
              clearTimeout(timeout)
              resolve({ totalErrors })
            }
          }
        })
        child.on('error', (err) => { clearTimeout(timeout); reject(err) })
      }
    })
  }

  let sharedDir

  beforeEach(() => {
    sharedDir = mkdtempSync(join(tmpdir(), 'ada-budget-f1a-'))
  })

  after(() => {
    // Nettoyage best-effort ; les dossiers sont uniques par test donc pas de collision.
  })

  test(`${N_PROCS} process concurrents : 0 exception (F1a) ET 0 entrée perdue (F1b)`, async () => {
    const attempted = N_PROCS * WRITES_PER_PROC
    const { totalErrors } = await runConcurrentWriters(sharedDir)

    // F1a — assertion d'origine conservée : pas de collision de nom de tmp.
    assert.equal(
      totalErrors,
      0,
      `attendu 0 exception (collision de nom de fichier tmp partagé), obtenu ${totalErrors}`
    )

    // F1b — la vraie promesse : chaque écriture tentée est présente une fois.
    const recorded = countNdjsonLines(sharedDir, 'budget-log')
    assert.equal(
      recorded,
      attempted,
      `perte d'écriture concurrente : ${attempted} tentées, ${recorded} conservées`
    )

    // Et l'agrégat lu par les appelants (run.js, control-handlers.js) reflète
    // bien le total — pas seulement le fichier brut.
    const { bg } = loadWith(sharedDir)
    assert.ok(
      Math.abs(bg.getSessionCost('f1b-shared-run') - attempted * 0.01) < 1e-6,
      `getSessionCost incohérent avec ${attempted} écritures de 0.01`
    )

    try { rmSync(sharedDir, { recursive: true, force: true }) } catch { /* noop */ }
  })
})

// ── F1a — atomicWriteJson toujours exercée via saveBudgetConfig ─────────────
// Depuis F1b/F1c, atomicWriteJson() n'est plus appelée QUE par
// saveBudgetConfig() : le journal budgétaire est passé en NDJSON append-only
// (cf. describe précédent), donc recordCost() ne passe plus du tout par
// atomicWriteJson. Le test F1a+F1b ci-dessus n'exerce donc plus l'objet réel
// du correctif F1a. Ce test dédié restaure cette couverture : plusieurs
// process concurrents qui appellent saveBudgetConfig() sur le MÊME
// ~/.ada.json ne doivent jamais se marcher dessus sur le nom de fichier
// temporaire partagé (avant F1a : ENOENT au renameSync quand un autre process
// avait déjà consommé/écrasé le même `<filePath>.tmp`).
describe('saveBudgetConfig — atomicWriteJson sans collision de tmp concurrent (F1a)', () => {
  const N_PROCS = 6
  const WRITES_PER_PROC = 20

  function runConcurrentConfigWriters(configPath, sharedDir) {
    return new Promise((resolve, reject) => {
      const workerSrc = `
        process.env.ADA_CONFIG_PATH = ${JSON.stringify(configPath)};
        const bg = require(${JSON.stringify(BG_JS)});
        process.send('ready');
        process.on('message', () => {
          let errors = 0;
          for (let i = 0; i < ${WRITES_PER_PROC}; i++) {
            try {
              bg.saveBudgetConfig({
                perRun: i, perSession: 20, perDay: 50, onExceed: 'warn', alertAt: 0.8,
                maxDelegationsPerRun: 3, adaptiveOnExceed: 'stop',
              });
            } catch { errors++; }
          }
          process.send({ errors });
          process.exit(0);
        });
      `
      const workerFile = join(sharedDir, `cfg-worker-${process.pid}-${Math.random().toString(36).slice(2)}.js`)
      writeFileSync(workerFile, workerSrc, 'utf8')

      const children = []
      let ready = 0
      let done = 0
      let totalErrors = 0
      const timeout = setTimeout(() => {
        children.forEach(c => { try { c.kill() } catch { /* noop */ } })
        reject(new Error('timeout: les process concurrents ne se sont pas terminés à temps'))
      }, 20000)

      for (let i = 0; i < N_PROCS; i++) {
        const child = spawn(process.execPath, [workerFile], {
          env: { ...process.env },
          stdio: ['ignore', 'ignore', 'ignore', 'ipc'],
        })
        children.push(child)
        child.on('message', (m) => {
          if (m === 'ready') {
            if (++ready === N_PROCS) children.forEach(c => c.send('go'))
          } else {
            totalErrors += m.errors
            if (++done === N_PROCS) {
              clearTimeout(timeout)
              resolve({ totalErrors })
            }
          }
        })
        child.on('error', (err) => { clearTimeout(timeout); reject(err) })
      }
    })
  }

  test(`${N_PROCS} process concurrents appellent saveBudgetConfig sur le même fichier : 0 exception, JSON final valide`, async () => {
    const dir = mkdtempSync(join(tmpdir(), 'ada-budget-cfg-f1a-'))
    const configPath = join(dir, '.ada.json')

    const { totalErrors } = await runConcurrentConfigWriters(configPath, dir)

    // L'objet réel de F1a : aucune collision sur le nom de fichier temporaire
    // partagé entre process concurrents.
    assert.equal(
      totalErrors,
      0,
      `attendu 0 exception (collision de nom de fichier tmp partagé dans atomicWriteJson), obtenu ${totalErrors}`
    )

    // Le fichier final doit rester un JSON valide et complet — jamais tronqué
    // par un rename qui aurait écrasé un tmp encore en cours d'écriture.
    const finalRaw = readFileSync(configPath, 'utf8')
    const parsed = JSON.parse(finalRaw) // lève si corrompu/tronqué
    assert.ok(parsed.budget && typeof parsed.budget.perRun === 'number',
      'le dernier writer doit avoir produit une config budget complète et valide')

    try { rmSync(dir, { recursive: true, force: true }) } catch { /* noop */ }
  })
})

// ── F1b — lecture agrégée sur plusieurs shards mensuels ─────────────────────

describe('agrégats — lecture multi-shards NDJSON', () => {
  let dir
  beforeEach(() => { dir = mkdtempSync(join(tmpdir(), 'ada-budget-shards-')) })

  test('getSessionCost somme les entrées du mois courant ET du mois précédent', () => {
    const now  = new Date()
    const prev = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - 1, 15))
    writeFileSync(join(dir, shardName('budget-log', now)),
      JSON.stringify({ runId: 'r1', amount: 1.5, ts: now.toISOString(), model: null }) + '\n', 'utf8')
    writeFileSync(join(dir, shardName('budget-log', prev)),
      JSON.stringify({ runId: 'r1', amount: 2.5, ts: prev.toISOString(), model: null }) + '\n', 'utf8')

    const { bg } = loadWith(dir)
    assert.ok(Math.abs(bg.getSessionCost('r1') - 4.0) < 1e-6, 'les deux shards doivent être sommés')
    // getDailyCost ne compte que la journée UTC courante → pas l'entrée du mois d'avant.
    assert.ok(Math.abs(bg.getDailyCost() - 1.5) < 1e-6, 'getDailyCost ne doit compter que le jour courant')
  })

  test('une ligne NDJSON corrompue est ignorée sans faire échouer l\'agrégat', () => {
    const now = new Date()
    writeFileSync(join(dir, shardName('budget-log', now)),
      JSON.stringify({ runId: 'r2', amount: 1, ts: now.toISOString() }) + '\n' +
      '{ceci n\'est pas du json\n' +
      JSON.stringify({ runId: 'r2', amount: 2, ts: now.toISOString() }) + '\n', 'utf8')

    const { bg } = loadWith(dir)
    assert.ok(Math.abs(bg.getSessionCost('r2') - 3) < 1e-6)
  })

  test('voie de migration : un ancien budget-log.json non migré reste compté', () => {
    const now = new Date()
    writeFileSync(join(dir, 'budget-log.json'), JSON.stringify([
      { runId: 'r3', amount: 10, ts: now.toISOString(), model: null },
    ]), 'utf8')

    const { bg } = loadWith(dir)
    bg.recordCost('r3', 5)
    // 10 (ancien format) + 5 (nouveau shard NDJSON)
    assert.ok(Math.abs(bg.getSessionCost('r3') - 15) < 1e-6,
      'les lecteurs existants ne doivent rien perdre tant que la migration n\'a pas eu lieu')
  })

  test('recordDelegation/getDelegationCount passent aussi en append-only', () => {
    const { bg } = loadWith(dir)
    bg.recordDelegation('run-d', { agent: 'reviewer' })
    bg.recordDelegation('run-d', { agent: 'db' })
    bg.recordDelegation('run-other', {})
    assert.equal(bg.getDelegationCount('run-d'), 2)
    assert.equal(bg.getDelegationCount('run-other'), 1)
    assert.equal(countNdjsonLines(dir, 'delegation-log'), 3)
  })
})

// ── F1c — script de migration autonome ──────────────────────────────────────

describe('migrate-budget-log — migration JSON → shards NDJSON', () => {
  let dir
  beforeEach(() => { dir = mkdtempSync(join(tmpdir(), 'ada-budget-mig-')) })

  function writeLegacy(entries) {
    const p = join(dir, 'budget-log.json')
    writeFileSync(p, JSON.stringify(entries, null, 2), 'utf8')
    return p
  }

  test('migre toutes les entrées, comptage exact, source préservée en .bak', () => {
    const now  = new Date()
    const m1   = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - 1, 10))
    const m2   = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - 2, 20))
    const entries = [
      { runId: 'a', amount: 1, ts: now.toISOString(), model: 'x' },
      { runId: 'b', amount: 2, ts: m1.toISOString(),  model: null },
      { runId: 'c', amount: 3, ts: m1.toISOString(),  model: null },
      { runId: 'd', amount: 4, ts: m2.toISOString(),  model: null },
    ]
    const src = writeLegacy(entries)
    const { mig } = loadWith(dir)

    const res = mig.migrate(src)

    assert.equal(res.migrated, entries.length, 'toutes les entrées doivent être migrées')
    assert.equal(countNdjsonLines(dir, 'budget-log'), entries.length, 'comptage NDJSON == comptage source')
    assert.equal(res.shards.length, 3, 'un shard par mois distinct')
    // (a) la source n'est ni supprimée ni tronquée
    assert.equal(existsSync(src), false, 'la source doit avoir été renommée, pas laissée en place')
    assert.ok(existsSync(src + '.bak'), 'la source doit survivre en .bak')
    assert.deepEqual(JSON.parse(readFileSync(src + '.bak', 'utf8')), entries,
      'le .bak doit être bit-à-bit équivalent à la source d\'origine')
  })

  test('fail-closed : JSON tronqué → erreur explicite, aucun shard écrit, source intacte', () => {
    const src = join(dir, 'budget-log.json')
    const truncated = '[{"runId":"a","amount":1,"ts":"2026-09-01T00:00:00.000Z"},{"runId":"b"'
    writeFileSync(src, truncated, 'utf8')
    const { mig } = loadWith(dir)

    assert.throws(() => mig.migrate(src), /JSON invalide|tronqu/i,
      'une source corrompue doit lever, jamais échouer silencieusement')
    assert.equal(countNdjsonLines(dir, 'budget-log'), 0, 'aucun shard ne doit avoir été écrit')
    assert.equal(readFileSync(src, 'utf8'), truncated, 'la source corrompue doit rester intacte')
  })

  test('fail-closed : racine JSON non-tableau → erreur, rien écrit', () => {
    const src = join(dir, 'budget-log.json')
    writeFileSync(src, '{"pas":"un tableau"}', 'utf8')
    const { mig } = loadWith(dir)
    assert.throws(() => mig.migrate(src), /tableau/i)
    assert.equal(countNdjsonLines(dir, 'budget-log'), 0)
  })

  test('idempotence : relancée deux fois, ne duplique rien', () => {
    const now = new Date()
    const src = writeLegacy([
      { runId: 'a', amount: 1, ts: now.toISOString() },
      { runId: 'b', amount: 2, ts: now.toISOString() },
    ])
    const { mig } = loadWith(dir)

    mig.migrate(src)
    const afterFirst = countNdjsonLines(dir, 'budget-log')
    assert.equal(afterFirst, 2)

    // 2e passage sur une source déjà migrée (absente) → no-op silencieux.
    const res2 = mig.migrate(src)
    assert.equal(res2.migrated, 0)
    assert.equal(countNdjsonLines(dir, 'budget-log'), afterFirst, 'aucune duplication')

    // 3e passage avec la source restaurée depuis le .bak → refus (le .bak
    // atteste qu'une migration a déjà eu lieu), toujours aucune duplication.
    writeFileSync(src, readFileSync(src + '.bak', 'utf8'), 'utf8')
    assert.throws(() => mig.migrate(src), /déjà|bak/i)
    assert.equal(countNdjsonLines(dir, 'budget-log'), afterFirst, 'aucune duplication')
  })

  test('une entrée au ts invalide est migrée quand même (jamais de perte silencieuse)', () => {
    const src = writeLegacy([
      { runId: 'a', amount: 1, ts: 'pas-une-date' },
      { runId: 'b', amount: 2, ts: new Date().toISOString() },
    ])
    const { mig } = loadWith(dir)
    const res = mig.migrate(src)
    assert.equal(res.migrated, 2)
    assert.equal(countNdjsonLines(dir, 'budget-log'), 2)
  })

  test('le script n\'exécute rien au simple require (pas d\'auto-migration)', () => {
    const now = new Date()
    const src = writeLegacy([{ runId: 'a', amount: 1, ts: now.toISOString() }])
    loadWith(dir) // require() du script
    assert.ok(existsSync(src), 'un require ne doit jamais déclencher la migration')
    assert.equal(countNdjsonLines(dir, 'budget-log'), 0)
  })

  test('migre aussi delegation-log.json (même défaut, même mécanisme)', () => {
    const now = new Date()
    const src = join(dir, 'delegation-log.json')
    writeFileSync(src, JSON.stringify([
      { runId: 'a', ts: now.toISOString(), agent: 'reviewer' },
    ]), 'utf8')
    const { mig } = loadWith(dir)
    assert.equal(mig.migrate(src).migrated, 1)
    assert.equal(countNdjsonLines(dir, 'delegation-log'), 1)
  })
})
