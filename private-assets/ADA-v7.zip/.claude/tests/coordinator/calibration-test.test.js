#!/usr/bin/env node
'use strict'
/**
 * calibration-test.test.js — Harnais de calibration du scorer (ADR-021 §1).
 *
 * Ne teste QUE la couche PURE (normalisation d'une entrée expected.json,
 * comparaison assertion-par-assertion, tri des noms de fixture) : aucune de
 * ces fonctions ne touche Postgres ni le disque. L'exécution réelle
 * (runCalibration → bench-v2.scoreSqlDeliverable → psql) est volontairement
 * hors périmètre unitaire — c'est le rôle du CLI `run-all` (mêmes conventions
 * que mutation-test.test.js, cf. son en-tête).
 *
 * calibration-test.js requiert bench-v2.js PARESSEUSEMENT (seulement dans les
 * fonctions impures) : ces tests passent donc même si bench-v2.js ou Postgres
 * sont indisponibles.
 */
const { test, describe } = require('node:test')
const assert = require('node:assert/strict')

const CT = require('../../coordinator/calibration-test.js')

// ── normalizeExpected ────────────────────────────────────────────────────────
describe('normalizeExpected', () => {
  test('applique les défauts sur une entrée vide', () => {
    const n = CT.normalizeExpected(undefined)
    assert.deepEqual(n, { expectScore: undefined, expectFail: [], expectPass: [], note: undefined })
  })

  test('conserve expectScore numérique', () => {
    assert.equal(CT.normalizeExpected({ expectScore: 100 }).expectScore, 100)
  })

  test('ignore un expectScore non numérique', () => {
    assert.equal(CT.normalizeExpected({ expectScore: '100' }).expectScore, undefined)
  })

  test('conserve expectFail/expectPass en tableaux', () => {
    const n = CT.normalizeExpected({ expectFail: ['a'], expectPass: ['b', 'c'] })
    assert.deepEqual(n.expectFail, ['a'])
    assert.deepEqual(n.expectPass, ['b', 'c'])
  })

  test('retombe sur des tableaux vides si expectFail/expectPass ne sont pas des tableaux', () => {
    const n = CT.normalizeExpected({ expectFail: 'a', expectPass: null })
    assert.deepEqual(n.expectFail, [])
    assert.deepEqual(n.expectPass, [])
  })

  test('conserve note si présente et string', () => {
    assert.equal(CT.normalizeExpected({ note: 'x' }).note, 'x')
    assert.equal(CT.normalizeExpected({ note: 42 }).note, undefined)
  })
})

// ── evaluateFixture ──────────────────────────────────────────────────────────
describe('evaluateFixture — positif (expectScore)', () => {
  test('conforme quand le score obtenu == expectScore', () => {
    const res = CT.evaluateFixture({ score: 100, detail: { assertions: [] } }, { expectScore: 100 })
    assert.equal(res.ok, true)
    assert.deepEqual(res.issues, [])
  })

  test('écart quand le score diffère', () => {
    const res = CT.evaluateFixture({ score: 88, detail: { assertions: [] } }, { expectScore: 100 })
    assert.equal(res.ok, false)
    assert.match(res.issues[0], /score attendu 100, obtenu 88/)
  })

  test('écart quand le score est null (scorer indisponible) alors qu\'un score est attendu', () => {
    const res = CT.evaluateFixture({ score: null, detail: 'postgres-indisponible' }, { expectScore: 100 })
    assert.equal(res.ok, false)
    assert.match(res.issues[0], /obtenu null/)
  })

  test('aucune entrée expected.json → écart explicite, jamais un pass silencieux', () => {
    const res = CT.evaluateFixture({ score: 100, detail: { assertions: [] } }, undefined)
    assert.equal(res.ok, false)
    assert.match(res.issues[0], /aucune entrée expected\.json/)
  })
})

describe('evaluateFixture — négatif (expectFail/expectPass)', () => {
  const detailOneFail = {
    assertions: [
      { name: 'a', ok: true, expect: '1', got: '1' },
      { name: 'b', ok: false, expect: '1', got: '0' },
      { name: 'c', ok: true, expect: '1', got: '1' },
    ],
  }

  test('conforme quand exactement les assertions attendues échouent/passent', () => {
    const res = CT.evaluateFixture({ score: 66, detail: detailOneFail }, { expectFail: ['b'], expectPass: ['a', 'c'] })
    assert.equal(res.ok, true)
    assert.deepEqual(res.issues, [])
  })

  test("écart : une assertion attendue en échec a en réalité passé", () => {
    const res = CT.evaluateFixture({ score: 100, detail: { assertions: [{ name: 'b', ok: true }] } }, { expectFail: ['b'] })
    assert.equal(res.ok, false)
    assert.match(res.issues.join('\n'), /attendue en ÉCHEC mais a PASSÉ/)
  })

  test('écart : une assertion attendue en succès a en réalité échoué', () => {
    const res = CT.evaluateFixture({ score: 0, detail: { assertions: [{ name: 'a', ok: false }] } }, { expectPass: ['a'] })
    assert.equal(res.ok, false)
    assert.match(res.issues.join('\n'), /attendue en SUCCÈS mais a ÉCHOUÉ/)
  })

  test('écart : assertion nommée introuvable dans le détail (typo de fixture)', () => {
    const res = CT.evaluateFixture({ score: 100, detail: { assertions: [{ name: 'autre', ok: true }] } }, { expectFail: ['b'] })
    assert.equal(res.ok, false)
    assert.match(res.issues.join('\n'), /introuvable dans le détail/)
  })

  test('écart : « pas plus » — une assertion échoue sans être dans expectFail (sur-détection)', () => {
    // b est attendue en échec ET c échoue AUSSI sans être annoncée : le scorer
    // détecte plus que ce que la mutation devait viser.
    const detail = {
      assertions: [
        { name: 'a', ok: true },
        { name: 'b', ok: false },
        { name: 'c', ok: false },
      ],
    }
    const res = CT.evaluateFixture({ score: 33, detail }, { expectFail: ['b'], expectPass: ['a', 'c'] })
    assert.equal(res.ok, false)
    // Le mismatch sur "c" est déjà signalé par la boucle expectPass, ET par la
    // boucle "pas plus" (double signalement acceptable — les deux angles sont
    // informatifs) ; l'important est qu'au moins un message identifie "c".
    assert.ok(res.issues.some(i => i.includes('"c"')))
  })

  test('écart : « pas plus » détecte un échec non prévu même hors expectPass', () => {
    // "d" échoue alors qu'il n'est mentionné NI dans expectFail NI dans expectPass.
    const detail = {
      assertions: [
        { name: 'a', ok: true },
        { name: 'b', ok: false },
        { name: 'd', ok: false },
      ],
    }
    const res = CT.evaluateFixture({ score: 33, detail }, { expectFail: ['b'] })
    assert.equal(res.ok, false)
    assert.ok(res.issues.some(i => i.includes('"d"') && i.includes('échec non prévu')))
  })

  test('pas de vérification "pas plus" si expectFail ET expectPass sont tous deux vides (cas expectScore pur)', () => {
    const detail = { assertions: [{ name: 'x', ok: false }] }
    const res = CT.evaluateFixture({ score: 0, detail }, { expectScore: 0 })
    assert.equal(res.ok, true)
  })

  test('detail sans assertions (chaîne, ex: "aucune assertion définie") ne plante pas', () => {
    const res = CT.evaluateFixture({ score: null, detail: 'aucune assertion définie pour la tâche' }, { expectFail: ['x'] })
    assert.equal(res.ok, false)
    assert.match(res.issues[0], /introuvable dans le détail/)
  })
})

// ── listFixtureFiles ──────────────────────────────────────────────────────────
describe('listFixtureFiles', () => {
  test('exclut expected.json et les fichiers non .txt', () => {
    const out = CT.listFixtureFiles(['expected.json', 'positive-1.txt', 'notes.md', 'negative-x.txt'])
    assert.deepEqual(out, ['positive-1.txt', 'negative-x.txt'])
  })

  test('trie positive-* avant negative-* puis alphabétique dans chaque groupe', () => {
    const out = CT.listFixtureFiles([
      'negative-b.txt', 'positive-2.txt', 'negative-a.txt', 'positive-1.txt',
    ])
    assert.deepEqual(out, ['positive-1.txt', 'positive-2.txt', 'negative-a.txt', 'negative-b.txt'])
  })

  test('tableau vide ou undefined → tableau vide', () => {
    assert.deepEqual(CT.listFixtureFiles([]), [])
    assert.deepEqual(CT.listFixtureFiles(undefined), [])
  })

  test('les fichiers ni positive- ni negative- sont classés en dernier, triés alphabétiquement', () => {
    const out = CT.listFixtureFiles(['zzz.txt', 'positive-1.txt', 'aaa.txt'])
    assert.deepEqual(out, ['positive-1.txt', 'aaa.txt', 'zzz.txt'])
  })
})

// ── Fixtures réelles sur disque (structure, pas Postgres) ────────────────────
// Vérifie que le contrat expected.json de chaque tâche calibrée référence bien
// des fichiers fixture existants, et vice versa — sans jamais appeler le
// scorer réel (aucun psql ici). Protège contre un rename de fixture non
// répercuté dans expected.json (silencieux sinon : orphanExpected n'est
// remonté que par runCalibration, qui est impure et non testée ici).
describe('cohérence disque des fixtures calibrées (sans Postgres)', () => {
  const { readFileSync, readdirSync, existsSync } = require('fs')
  const { join } = require('path')

  const taskIds = CT.listCalibratedTaskIds()

  test('au moins une tâche calibrée est présente sur le disque', () => {
    assert.ok(taskIds.length > 0, 'aucun dossier sous benchmarks/v2/calibration/')
  })

  for (const taskId of taskIds) {
    test(`${taskId} : expected.json couvre exactement les fixtures présentes`, () => {
      const dir = join(CT.CALIBRATION_DIR, taskId)
      const files = CT.listFixtureFiles(readdirSync(dir))
      assert.ok(files.length >= 2, `${taskId} devrait avoir au moins 1 positive + 1 negative`)
      assert.ok(files.some(f => f.startsWith('positive-')), `${taskId} : aucune fixture positive`)
      assert.ok(files.some(f => f.startsWith('negative-')), `${taskId} : aucune fixture negative`)

      const expectedPath = join(dir, 'expected.json')
      assert.ok(existsSync(expectedPath), `${taskId} : expected.json manquant`)
      const expected = JSON.parse(readFileSync(expectedPath, 'utf8'))

      for (const f of files) {
        assert.ok(Object.prototype.hasOwnProperty.call(expected, f), `${taskId}/${f} : aucune entrée dans expected.json`)
      }
      for (const key of Object.keys(expected)) {
        assert.ok(files.includes(key), `${taskId} : expected.json référence "${key}" qui n'existe pas sur disque`)
      }
    })

    test(`${taskId} : chaque fixture positive-* déclare expectScore, chaque negative-* déclare expectFail`, () => {
      const dir = join(CT.CALIBRATION_DIR, taskId)
      const expected = JSON.parse(readFileSync(join(dir, 'expected.json'), 'utf8'))
      for (const [fixture, entry] of Object.entries(expected)) {
        if (fixture.startsWith('positive-')) {
          assert.equal(typeof entry.expectScore, 'number', `${taskId}/${fixture} : expectScore manquant`)
        } else if (fixture.startsWith('negative-')) {
          assert.ok(Array.isArray(entry.expectFail) && entry.expectFail.length > 0, `${taskId}/${fixture} : expectFail manquant ou vide`)
        }
      }
    })
  }
})
