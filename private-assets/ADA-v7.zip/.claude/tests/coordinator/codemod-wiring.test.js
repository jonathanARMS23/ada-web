#!/usr/bin/env node
'use strict'
/**
 * codemod-wiring.test.js — câblage de l'EXÉCUTION tier 0 codemod dans `ada run` (TDD).
 *
 * task-classifier.js détecte les tâches mécaniques (mode:'codemod') et
 * codemod.js expose applyCodemod() + un CLI — mais avant ce fix, `ada run`
 * (resolveRunMode / cmdRun dans bin/ada.js) ignorait ce mode et retombait
 * systématiquement en solo (spawn d'un agent LLM pour un travail à $0/1ms).
 *
 * Deux niveaux de test :
 *  1. resolveRunMode + extractExplicitFiles — logique PURE, zéro I/O.
 *  2. cmdRun de bout en bout via subprocess (`node bin/ada.js run "..."`) —
 *     AUCUN agent LLM n'est jamais spawné par cmdRun lui-même (solo/codemod
 *     ne font qu'imprimer un plan) : la subprocess est donc sûre et rapide.
 *     Le HOME du subprocess est isolé (tmpdir sans ~/.ada.json) pour ne
 *     JAMAIS lire/écrire dans le profil réel de l'utilisateur.
 */
const { test, describe } = require('node:test')
const assert = require('node:assert/strict')
const { execFileSync } = require('child_process')
const { writeFileSync, readFileSync, mkdtempSync, rmSync, mkdirSync } = require('fs')
const { join } = require('path')
const os = require('os')

const ADA_BIN = join(__dirname, '../../bin/ada.js')
const { resolveRunMode, extractExplicitFiles } = require(ADA_BIN)
const { classifyTask } = require('../../coordinator/task-classifier.js')

const ALLOWED = ['feature', 'review', 'db-migrate', 'test', 'audit', 'deploy']

// ─── extractExplicitFiles — extraction pure ────────────────────────────────
describe('extractExplicitFiles', () => {
  test('extrait un chemin relatif simple', () => {
    assert.deepEqual(extractExplicitFiles('retire les console.log de src/foo.js'), ['src/foo.js'])
  })

  test('extrait un chemin absolu', () => {
    assert.deepEqual(extractExplicitFiles('retire les console.log de /tmp/demo/foo.js'), ['/tmp/demo/foo.js'])
  })

  test('ignore la ponctuation de fin de phrase', () => {
    assert.deepEqual(extractExplicitFiles('nettoie src/app.js.'), ['src/app.js'])
  })

  test('supporte .mjs/.cjs/.ts en plus de .js', () => {
    const r = extractExplicitFiles('retire les console.log de a.mjs, b.cjs et c.ts')
    assert.deepEqual(r, ['a.mjs', 'b.cjs', 'c.ts'])
  })

  test('aucun fichier mentionné → tableau vide', () => {
    assert.deepEqual(extractExplicitFiles('retire les console.log du projet'), [])
  })

  test('dédoublonne en conservant l\'ordre', () => {
    assert.deepEqual(extractExplicitFiles('a.js puis a.js encore'), ['a.js'])
  })

  test('desc vide/null → tableau vide, ne jette pas', () => {
    assert.deepEqual(extractExplicitFiles(''), [])
    assert.deepEqual(extractExplicitFiles(null), [])
    assert.deepEqual(extractExplicitFiles(undefined), [])
  })
})

// ─── resolveRunMode — mode 'codemod' câblé (défaut, texte libre) ───────────
describe('resolveRunMode — mode codemod (tier 0)', () => {
  test('description mécanique (remove-console) → mode codemod, tier 0, codemod propagé', () => {
    const r = resolveRunMode(['retire', 'les', 'console.log', 'de', 'src/foo.js'], ALLOWED, classifyTask)
    assert.equal(r.mode, 'codemod')
    assert.equal(r.codemod, 'remove-console')
    assert.equal(r.tier, 0)
    assert.equal(r.pipeline, null)
    assert.equal(r.forced, null)
  })

  test('description mécanique (var-to-const) → mode codemod propagé', () => {
    const r = resolveRunMode(['remplace', 'var', 'par', 'const', 'dans', 'a.js'], ALLOWED, classifyTask)
    assert.equal(r.mode, 'codemod')
    assert.equal(r.codemod, 'var-to-const')
  })

  test('description avec jugement (types/async/archi) → PAS codemod (classifieur route ailleurs)', () => {
    const r = resolveRunMode(['ajoute', 'des', 'types', 'a', 'ce', 'fichier'], ALLOWED, classifyTask)
    assert.notEqual(r.mode, 'codemod')
  })
})

describe('resolveRunMode — overrides durs bypassent le codemod', () => {
  test('--solo bypasse le mode codemod (mode=solo, tier replié à 2)', () => {
    const r = resolveRunMode(['--solo', 'retire', 'les', 'console.log', 'de', 'src/foo.js'], ALLOWED, classifyTask)
    assert.equal(r.mode, 'solo')
    assert.equal(r.forced, 'flag-solo')
    assert.equal(r.tier, 2, 'tier 0 (codemod) ne doit jamais fuiter dans un plan solo forcé')
  })

  test('--pipeline bypasse le mode codemod (mode=pipeline, tier replié à 2)', () => {
    const r = resolveRunMode(['--pipeline', 'feature', 'retire', 'les', 'console.log', 'de', 'src/foo.js'], ALLOWED, classifyTask)
    assert.equal(r.mode, 'pipeline')
    assert.equal(r.forced, 'flag-pipeline')
    assert.equal(r.tier, 2)
  })
})

// ─── cmdRun — exécution de bout en bout via subprocess ─────────────────────
// HOME isolé : loadConfig() ne trouve pas de ~/.ada.json → config par défaut
// → require(coordinator/*.js) retombe sur le repo (fallback déjà existant
// dans cmdRun) sans jamais toucher le profil réel de l'utilisateur.
function runAda(argsAfterRun, { cwd, home }) {
  return execFileSync('node', [ADA_BIN, 'run', ...argsAfterRun], {
    cwd,
    env: { ...process.env, HOME: home, USERPROFILE: home },
    encoding: 'utf8',
  })
}

describe('cmdRun — exécution codemod de bout en bout (aucun agent spawné)', () => {
  let scratch, home

  function setup() {
    scratch = mkdtempSync(join(os.tmpdir(), 'ada-codemod-scratch-'))
    home = mkdtempSync(join(os.tmpdir(), 'ada-codemod-home-'))
  }
  function teardown() {
    rmSync(scratch, { recursive: true, force: true })
    rmSync(home, { recursive: true, force: true })
  }

  test('fichier explicite existant → codemod exécuté, fichier modifié, $0 affiché', () => {
    setup()
    try {
      const f = join(scratch, 'demo.js')
      writeFileSync(f, 'function f() {\n  console.log("debug")\n  return 1\n}\n')
      const out = runAda([`retire les console.log de ${f}`], { cwd: scratch, home })
      assert.match(out, /Tier 0 — codemod déterministe/)
      assert.match(out, /tier 0 · \$0 ·/)
      assert.match(out, /1 fichier\(s\) modifié\(s\)/)
      const after = readFileSync(f, 'utf8')
      assert.equal(after, 'function f() {\n  return 1\n}\n')
    } finally { teardown() }
  })

  test('sans fichier cible explicite → fallback solo, aucun fichier touché', () => {
    setup()
    try {
      const out = runAda(['retire les console.log du projet'], { cwd: scratch, home })
      assert.match(out, /routé vers agent/)
      assert.match(out, /Plan solo/)
      assert.doesNotMatch(out, /Tier 0 — codemod déterministe/)
    } finally { teardown() }
  })

  test('fichier cible inexistant → fallback solo avec raison', () => {
    setup()
    try {
      const missing = join(scratch, 'absent.js')
      const out = runAda([`retire les console.log de ${missing}`], { cwd: scratch, home })
      assert.match(out, /routé vers agent/)
      assert.match(out, /fichier introuvable/)
    } finally { teardown() }
  })

  test('extension non supportée (.py) → fallback solo avec raison', () => {
    setup()
    try {
      const f = join(scratch, 'demo.py')
      writeFileSync(f, 'print("x")\n')
      // NB: extractExplicitFiles ne matche que .js/.mjs/.cjs/.ts — un .py
      // n'est donc jamais extrait comme cible, ce qui déclenche déjà le
      // premier fallback ("aucun fichier cible"). On vérifie ce comportement
      // conservateur explicitement ici.
      const out = runAda([`retire les console.log de ${f}`], { cwd: scratch, home })
      assert.match(out, /routé vers agent/)
    } finally { teardown() }
  })

  test('--dry-run : résumé affiché, AUCUN fichier écrit', () => {
    setup()
    try {
      const f = join(scratch, 'demo.js')
      const original = 'console.log("x")\nconst a = 1;\n'
      writeFileSync(f, original)
      const out = runAda([`retire les console.log de ${f}`, '--dry-run'], { cwd: scratch, home })
      assert.match(out, /Tier 0 — codemod déterministe/)
      assert.match(out, /--dry-run : aucun fichier écrit/)
      assert.equal(readFileSync(f, 'utf8'), original, '--dry-run ne doit jamais modifier le fichier')
    } finally { teardown() }
  })

  test('codemod qui skippe tout (changed=0) → le dit clairement, pas de fallback agent silencieux', () => {
    setup()
    try {
      const f = join(scratch, 'demo.js')
      // console.log utilisé comme valeur → toujours skippé par remove-console (conservateur)
      writeFileSync(f, 'const r = console.log(x);\n')
      const out = runAda([`retire les console.log de ${f}`], { cwd: scratch, home })
      assert.match(out, /Tier 0 — codemod déterministe/)
      assert.match(out, /Aucun changement à appliquer/)
      assert.doesNotMatch(out, /routé vers agent/, 'un skip total ne doit pas silencieusement basculer en agent')
      assert.equal(readFileSync(f, 'utf8'), 'const r = console.log(x);\n')
    } finally { teardown() }
  })

  test('--solo bypass explicite : pas de détection codemod même si la description matche', () => {
    setup()
    try {
      const f = join(scratch, 'demo.js')
      writeFileSync(f, 'console.log("debug")\n')
      const out = runAda([`retire les console.log de ${f}`, '--solo'], { cwd: scratch, home })
      assert.doesNotMatch(out, /Tier 0 — codemod déterministe/)
      assert.doesNotMatch(out, /Codemod détecté/)
      assert.match(out, /Plan solo/)
      // --solo est un override dur : le fichier ne doit pas être touché.
      assert.equal(readFileSync(f, 'utf8'), 'console.log("debug")\n')
    } finally { teardown() }
  })
})
