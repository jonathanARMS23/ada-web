#!/usr/bin/env node
'use strict'
/**
 * codemod.test.js — Tier 0 déterministe ($0, ~1ms) — TDD.
 *
 * Chaque intent est testé sur : cas transformé / cas skippé (ambigu) /
 * cas piège (dans une string, réassigné, arrow body, template literal).
 * Vérifie aussi qu'un --dry-run n'écrit jamais le fichier.
 *
 * Zéro dépendance. Parsing : lexer maison respectant quotes/commentaires/templates.
 */
const { test, describe } = require('node:test')
const assert = require('node:assert/strict')
const { execFileSync } = require('child_process')
const { writeFileSync, readFileSync, mkdtempSync, rmSync } = require('fs')
const { join } = require('path')
const os = require('os')

const CODEMOD = join(__dirname, '../../coordinator/codemod.js')
const { applyCodemod, INTENTS, isSupportedIntent, scanMask } = require(CODEMOD)

// ─── Contrat / API ──────────────────────────────────────────────────────────
describe('codemod — contrat', () => {
  test('INTENTS expose les 3 intents sûrs', () => {
    assert.deepEqual([...INTENTS].sort(), ['remove-console', 'strip-trailing-whitespace', 'var-to-const'])
  })
  test('isSupportedIntent', () => {
    assert.equal(isSupportedIntent('remove-console'), true)
    assert.equal(isSupportedIntent('add-types'), false)
  })
  test('intent inconnu → ok:false, inchangé', () => {
    const r = applyCodemod('add-types', 'var x = 1\n')
    assert.equal(r.ok, false)
    assert.equal(r.changed, false)
    assert.equal(r.output, 'var x = 1\n')
  })
  test('sortie contient {changed, output, edits, skipped, reasons}', () => {
    const r = applyCodemod('strip-trailing-whitespace', 'a = 1  \n')
    assert.equal(typeof r.changed, 'boolean')
    assert.equal(typeof r.output, 'string')
    assert.equal(typeof r.edits, 'number')
    assert.equal(typeof r.skipped, 'number')
    assert.ok(Array.isArray(r.reasons))
  })
  test('source malformée (template non terminé) → skip sûr', () => {
    const r = applyCodemod('strip-trailing-whitespace', 'const s = `unterminated  \n')
    assert.equal(r.changed, false)
    assert.ok(r.reasons.join(' ').match(/untermin|safety|s[ûu]ret/i))
  })
})

// ─── Lexer (fondation) ──────────────────────────────────────────────────────
describe('scanMask — lexer', () => {
  test('termine sur code équilibré', () => {
    assert.equal(scanMask('const x = 1;\n').terminated, true)
  })
  test('détecte string/template/comment non terminés', () => {
    assert.equal(scanMask('const s = "abc').terminated, false)
    assert.equal(scanMask('const s = `abc').terminated, false)
    assert.equal(scanMask('/* not closed').terminated, false)
  })
  test('interpolation de template = code réentrant', () => {
    assert.equal(scanMask('const s = `a${ b() }c`;\n').terminated, true)
    assert.equal(scanMask('const s = `a${ `nested` }c`;\n').terminated, true)
  })
})

// ─── strip-trailing-whitespace ──────────────────────────────────────────────
describe('strip-trailing-whitespace', () => {
  test('retire les espaces/tabs en fin de ligne', () => {
    const r = applyCodemod('strip-trailing-whitespace', 'const a = 1;   \nconst b = 2;\t\n')
    assert.equal(r.output, 'const a = 1;\nconst b = 2;\n')
    assert.equal(r.changed, true)
  })
  test('ajoute une newline finale unique', () => {
    const r = applyCodemod('strip-trailing-whitespace', 'const a = 1;')
    assert.equal(r.output, 'const a = 1;\n')
    assert.equal(r.changed, true)
  })
  test('collapse les newlines finales multiples', () => {
    const r = applyCodemod('strip-trailing-whitespace', 'const a = 1;\n\n\n')
    assert.equal(r.output, 'const a = 1;\n')
  })
  test('PIÈGE : espaces significatifs dans un template literal → préservés', () => {
    const src = 'const s = `keep these   \nend`;\n'
    const r = applyCodemod('strip-trailing-whitespace', src)
    assert.equal(r.output, src)
    assert.equal(r.changed, false)
  })
  test('idempotent', () => {
    const src = 'a = 1;  \n\n\n'
    const once = applyCodemod('strip-trailing-whitespace', src).output
    const twice = applyCodemod('strip-trailing-whitespace', once).output
    assert.equal(once, twice)
  })
  test('fichier déjà propre → inchangé', () => {
    const src = 'const a = 1;\nconst b = 2;\n'
    const r = applyCodemod('strip-trailing-whitespace', src)
    assert.equal(r.changed, false)
  })
})

// ─── remove-console ─────────────────────────────────────────────────────────
describe('remove-console', () => {
  test('retire un console.log standalone', () => {
    const src = 'function f() {\n  console.log("debug")\n  return 1\n}\n'
    const r = applyCodemod('remove-console', src)
    assert.equal(r.output, 'function f() {\n  return 1\n}\n')
    assert.equal(r.changed, true)
    assert.equal(r.edits, 1)
  })
  test('retire console.debug et console.info, garde console.error/warn', () => {
    const src = 'console.error("e")\nconsole.warn("w")\nconsole.info("i")\nconsole.debug("d")\nconsole.log("l")\n'
    const r = applyCodemod('remove-console', src)
    assert.equal(r.output, 'console.error("e")\nconsole.warn("w")\n')
    assert.equal(r.changed, true)
  })
  test('retire un console.log avec point-virgule', () => {
    const r = applyCodemod('remove-console', 'const a = 1;\nconsole.log(a);\nreturn a;\n')
    assert.equal(r.output, 'const a = 1;\nreturn a;\n')
  })
  test('multi-ligne standalone retiré', () => {
    const src = 'const a = 1;\nconsole.log(\n  "a", "b"\n)\nconst b = 2;\n'
    const r = applyCodemod('remove-console', src)
    assert.equal(r.output, 'const a = 1;\nconst b = 2;\n')
  })
  test('PIÈGE : console.log dans une string → non retiré', () => {
    const src = 'const s = "console.log(1)";\n'
    const r = applyCodemod('remove-console', src)
    assert.equal(r.output, src)
    assert.equal(r.changed, false)
  })
  test('PIÈGE : console.log dans un commentaire → non retiré', () => {
    const src = '// console.log(1)\nconst a = 1;\n'
    const r = applyCodemod('remove-console', src)
    assert.equal(r.changed, false)
  })
  test('PIÈGE : arrow body () => console.log(x) → skippé (conservateur)', () => {
    const src = 'const f = () => console.log(x);\n'
    const r = applyCodemod('remove-console', src)
    assert.equal(r.changed, false)
    assert.ok(r.skipped >= 1)
  })
  test('PIÈGE : console.log utilisé comme valeur → skippé', () => {
    const src = 'const r = console.log(x);\n'
    const r = applyCodemod('remove-console', src)
    assert.equal(r.changed, false)
    assert.ok(r.skipped >= 1)
  })
  test('PIÈGE : console.log inline avec d\'autre code → skippé', () => {
    const src = 'doStuff(); console.log(x); more();\n'
    const r = applyCodemod('remove-console', src)
    assert.equal(r.changed, false)
    assert.ok(r.skipped >= 1)
  })
  test('console.log avec template + parens imbriquées → retiré', () => {
    const src = 'a();\nconsole.log(`v=${obj.get(1)}`)\nb();\n'
    const r = applyCodemod('remove-console', src)
    assert.equal(r.output, 'a();\nb();\n')
  })
})

// ─── var-to-const ───────────────────────────────────────────────────────────
describe('var-to-const', () => {
  test('var jamais réassignée → const', () => {
    const r = applyCodemod('var-to-const', 'var x = 5;\nuse(x);\n')
    assert.equal(r.output, 'const x = 5;\nuse(x);\n')
    assert.equal(r.changed, true)
  })
  test('PIÈGE : var réassignée → let', () => {
    const r = applyCodemod('var-to-const', 'var x = 5;\nx = 6;\nuse(x);\n')
    assert.equal(r.output, 'let x = 5;\nx = 6;\nuse(x);\n')
  })
  test('var avec ++ → let', () => {
    const r = applyCodemod('var-to-const', 'var i = 0;\ni++;\n')
    assert.equal(r.output, 'let i = 0;\ni++;\n')
  })
  test('PIÈGE : utilisée avant déclaration → skip', () => {
    const src = 'use(x);\nvar x = 5;\n'
    const r = applyCodemod('var-to-const', src)
    assert.equal(r.output, src)
    assert.equal(r.changed, false)
  })
  test('PIÈGE : redéclarée → skip', () => {
    const src = 'var x = 1;\nvar x = 2;\n'
    const r = applyCodemod('var-to-const', src)
    assert.equal(r.changed, false)
  })
  test('PIÈGE : for header → skip (conservateur)', () => {
    const src = 'for (var i = 0; i < 3; i++) {}\n'
    const r = applyCodemod('var-to-const', src)
    assert.equal(r.changed, false)
  })
  test('PIÈGE : déclarateur destructuré → skip', () => {
    const src = 'var { a, b } = obj;\nuse(a, b);\n'
    const r = applyCodemod('var-to-const', src)
    assert.equal(r.changed, false)
  })
  test('PIÈGE : déclarateurs multiples (virgule) → skip', () => {
    const src = 'var a = 1, b = 2;\nuse(a, b);\n'
    const r = applyCodemod('var-to-const', src)
    assert.equal(r.changed, false)
  })
  test('PIÈGE : var dans une string → non touchée', () => {
    const src = 'const s = "var x = 1";\n'
    const r = applyCodemod('var-to-const', src)
    assert.equal(r.output, src)
    assert.equal(r.changed, false)
  })
  test('PIÈGE : échappement de scope de bloc → skip', () => {
    const src = 'if (c) {\n  var x = 1;\n}\nuse(x);\n'
    const r = applyCodemod('var-to-const', src)
    assert.equal(r.changed, false)
  })
  test('"variable" ne matche pas le mot-clé var', () => {
    const src = 'const variable = 1;\nuse(variable);\n'
    const r = applyCodemod('var-to-const', src)
    assert.equal(r.changed, false)
  })
})

// ─── CLI + --dry-run ────────────────────────────────────────────────────────
describe('CLI', () => {
  test('--dry-run ne modifie PAS le fichier', () => {
    const dir = mkdtempSync(join(os.tmpdir(), 'codemod-cli-'))
    try {
      const f = join(dir, 'demo.js')
      const src = 'var x = 5;\nconsole.log(x)\n'
      writeFileSync(f, src)
      execFileSync('node', [CODEMOD, 'remove-console', f, '--dry-run'], { encoding: 'utf8' })
      assert.equal(readFileSync(f, 'utf8'), src, 'dry-run ne doit rien écrire')
    } finally {
      rmSync(dir, { recursive: true, force: true })
    }
  })
  test('sans --dry-run écrit le fichier transformé', () => {
    const dir = mkdtempSync(join(os.tmpdir(), 'codemod-cli-'))
    try {
      const f = join(dir, 'demo.js')
      writeFileSync(f, 'const a = 1;   \n')
      execFileSync('node', [CODEMOD, 'strip-trailing-whitespace', f], { encoding: 'utf8' })
      assert.equal(readFileSync(f, 'utf8'), 'const a = 1;\n')
    } finally {
      rmSync(dir, { recursive: true, force: true })
    }
  })
  test('--json émet un rapport structuré', () => {
    const dir = mkdtempSync(join(os.tmpdir(), 'codemod-cli-'))
    try {
      const f = join(dir, 'demo.js')
      writeFileSync(f, 'console.log(1)\n')
      const out = execFileSync('node', [CODEMOD, 'remove-console', f, '--dry-run', '--json'], { encoding: 'utf8' })
      const parsed = JSON.parse(out)
      assert.equal(parsed.intent, 'remove-console')
      assert.ok(typeof parsed.changed === 'number')
      assert.ok(Array.isArray(parsed.files))
    } finally {
      rmSync(dir, { recursive: true, force: true })
    }
  })
})
