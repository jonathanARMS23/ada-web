#!/usr/bin/env node
'use strict'
/**
 * tests/coordinator/context-advisor.test.js
 * Tests pour F2 (buildPhaseContext) et F4 (injectContext).
 *
 * Stratégie :
 *   - Mock bank.js via module cache manipulation
 *   - Mock micro-lessons.js idem
 *   - Vérifier filtrage des verdicts dans buildPhaseContext
 *   - Vérifier format YAML du bloc dans injectContext
 */

const { test, describe, before, after, beforeEach } = require('node:test')
const assert = require('node:assert/strict')
const { mkdirSync, writeFileSync, rmSync, existsSync } = require('fs')
const { join } = require('path')

// ── Répertoire temporaire isolé ───────────────────────────────────────────────

const TMP      = join(__dirname, '../../..', '.test-tmp-ctx-advisor')
const COORD    = join(TMP, 'coordinator')
const BANK_JS  = join(COORD, 'bank.js')
const ML_JS    = join(COORD, 'micro-lessons.js')
const ADVISOR  = join(__dirname, '../../coordinator/context-advisor.js')

// ── Helpers ───────────────────────────────────────────────────────────────────

function setupDirs() {
  mkdirSync(COORD, { recursive: true })
}

function teardown() {
  try { rmSync(TMP, { recursive: true, force: true }) } catch {}
}

/** Réinitialise le cache require pour context-advisor et ses dépendances mockées.
 *  Purge TOUS les chemins liés aux fichiers TMP et à context-advisor.
 */
function reloadAdvisor() {
  process.env.CLAUDE_CONFIG_DIR = TMP
  // Purger toutes les entrées du cache dont le chemin contient le nom du dossier TMP
  const tmpBase = '.test-tmp-ctx-advisor'
  for (const key of Object.keys(require.cache)) {
    if (key.includes(tmpBase)) {
      delete require.cache[key]
    }
  }
  // Purger context-advisor lui-même
  try { delete require.cache[require.resolve(ADVISOR)] } catch {}
  return require(ADVISOR)
}

/**
 * Écrit un module CJS mock dans TMP/coordinator/bank.js.
 * Accepte soit { retrieve, retrieveAsync } (fonctions), soit { data } (tableau inline).
 * @param {{ data?: object[], retrieve?: string, retrieveAsync?: string, throws?: boolean }} opts
 */
function mockBank(opts = {}) {
  let src
  if (opts.throws) {
    src = `'use strict'\nmodule.exports = { retrieve: function() { throw new Error('DB crash') }, retrieveAsync: function() { return Promise.reject(new Error('DB crash')) } }\n`
  } else if (opts.never) {
    // Simule un retrieveAsync qui ne résout jamais (test timeout)
    src = `'use strict'\nmodule.exports = { retrieve: function() { return [] }, retrieveAsync: function() { return new Promise(function() {}) } }\n`
  } else {
    const data = JSON.stringify(opts.data || [])
    src = `'use strict'\nmodule.exports = { retrieve: function() { return [] }, retrieveAsync: function() { return Promise.resolve(${data}) } }\n`
  }
  writeFileSync(BANK_JS, src, 'utf8')
}

/**
 * Écrit un module CJS mock dans TMP/coordinator/micro-lessons.js
 * @param {string} lesson Valeur retournée par inject()
 */
function mockML(lesson = '') {
  writeFileSync(ML_JS, `'use strict'\nmodule.exports = { inject: function() { return ${JSON.stringify(lesson)} } }\n`, 'utf8')
}

// ── Fixtures de trajectoires ──────────────────────────────────────────────────

const SUCCESS_TRAJ = [
  { id: 'traj-001', verdict: 'success', summary: 'Tests passés', duration: 600, agent: 'tester' },
  { id: 'traj-002', verdict: 'success', summary: 'Build OK',     duration: 420, agent: 'nestjs'  },
]
const FAILURE_TRAJ = [
  { id: 'traj-003', verdict: 'failure', summary: 'Timeout DB',   duration: 120, agent: 'db'      },
]
const MIXED_TRAJ   = [...SUCCESS_TRAJ, ...FAILURE_TRAJ]
const PARTIAL_TRAJ = [
  { id: 'traj-004', verdict: 'partial', summary: 'Partiel',      duration: 300, agent: 'nestjs'  },
]

// ── Tests ─────────────────────────────────────────────────────────────────────

describe('context-advisor — buildPhaseContext', () => {
  before(() => { setupDirs() })
  after(()  => { teardown() })
  beforeEach(() => {
    ;[BANK_JS, ML_JS].forEach(p => { try { rmSync(p) } catch {} })
    reloadAdvisor()
  })

  test('retourne contexte vide si bank.js absent', async () => {
    // BANK_JS non créé → bank introuvable
    const { buildPhaseContext } = reloadAdvisor()
    const ctx = await buildPhaseContext('phase-test', 'nestjs', 'créer endpoint')
    assert.equal(ctx.injected, false)
    assert.deepEqual(ctx.trajectories, [])
    assert.equal(ctx.lesson, '')
    assert.equal(ctx.summary, '')
  })

  test('retourne contexte vide si bank.retrieve lève une erreur', async () => {
    mockBank({ throws: true })
    const { buildPhaseContext } = reloadAdvisor()
    const ctx = await buildPhaseContext('phase-test', 'nestjs', 'créer endpoint')
    assert.equal(ctx.injected, false)
    assert.deepEqual(ctx.trajectories, [])
  })

  test('filtre uniquement les trajectoires success sans errorContext', async () => {
    mockBank({ data: [
      { id: 'traj-001', verdict: 'success', summary: 'OK', duration: 600 },
      { id: 'traj-003', verdict: 'failure', summary: 'KO', duration: 120 },
      { id: 'traj-004', verdict: 'partial', summary: 'Part', duration: 300 },
    ] })
    const { buildPhaseContext } = reloadAdvisor()
    const ctx = await buildPhaseContext('phase-test', 'nestjs', 'créer endpoint')
    assert.equal(ctx.injected, true)
    assert.equal(ctx.trajectories.length, 1)
    assert.equal(ctx.trajectories[0].verdict, 'success')
  })

  test('inclut les trajectoires failure quand errorContext fourni', async () => {
    mockBank({ data: [
      { id: 'traj-001', verdict: 'success', summary: 'OK', duration: 600 },
      { id: 'traj-003', verdict: 'failure', summary: 'KO', duration: 120 },
      { id: 'traj-004', verdict: 'partial', summary: 'Part', duration: 300 },
    ] })
    const { buildPhaseContext } = reloadAdvisor()
    const ctx = await buildPhaseContext('phase-test', 'nestjs', 'créer endpoint', { pattern: 'timeout' })
    assert.equal(ctx.injected, true)
    // success + failure inclus, partial exclu
    assert.equal(ctx.trajectories.length, 2)
    const verdicts = ctx.trajectories.map(t => t.verdict).sort()
    assert.deepEqual(verdicts, ['failure', 'success'])
  })

  test('exclut les trajectoires partial dans tous les cas', async () => {
    mockBank({ data: [{ id: 'p1', verdict: 'partial', summary: 'Part', duration: 300 }] })
    const { buildPhaseContext } = reloadAdvisor()
    const ctx1 = await buildPhaseContext('p', 'a', 'task')
    assert.equal(ctx1.injected, false)

    const ctx2 = await buildPhaseContext('p', 'a', 'task', { pattern: 'err' })
    assert.equal(ctx2.injected, false)
  })

  test('inclut la leçon micro-lessons dans le résumé', async () => {
    mockBank({ data: SUCCESS_TRAJ })
    mockML('Toujours écrire les specs avant le code.')
    const { buildPhaseContext } = reloadAdvisor()
    const ctx = await buildPhaseContext('phase-test', 'nestjs', 'TDD endpoint')
    assert.ok(ctx.lesson.includes('specs avant le code'))
    assert.ok(ctx.summary.includes('Key lessons:'))
  })

  test('fallback gracieux si retrieveAsync dépasse 2s', async () => {
    // retrieveAsync bloquant simulé (ne rejette jamais mais ne résout jamais non plus)
    mockBank({ never: true })
    const { buildPhaseContext } = reloadAdvisor()
    const start = Date.now()
    const ctx = await buildPhaseContext('phase-test', 'nestjs', 'task')
    const elapsed = Date.now() - start
    // Doit résoudre en ≤ 2500ms malgré le blocage
    assert.ok(elapsed < 2500, `Timeout trop long : ${elapsed}ms`)
    assert.equal(ctx.injected, false)
  })

  test('résumé contient les IDs des trajectoires', async () => {
    mockBank({ data: SUCCESS_TRAJ })
    const { buildPhaseContext } = reloadAdvisor()
    const ctx = await buildPhaseContext('phase-test', 'nestjs', 'build feature')
    assert.ok(ctx.summary.includes('traj-001'))
    assert.ok(ctx.summary.includes('traj-002'))
  })

  test('résumé vide si aucune trajectoire et aucune leçon', async () => {
    mockBank({ data: [] })
    mockML('')
    const { buildPhaseContext } = reloadAdvisor()
    const ctx = await buildPhaseContext('phase-test', 'nestjs', 'task')
    assert.equal(ctx.injected, false)
    assert.equal(ctx.summary, '')
  })
})

// ── Tests injectContext ───────────────────────────────────────────────────────

describe('context-advisor — injectContext', () => {
  before(() => { setupDirs() })
  after(()  => { teardown() })

  test('retourne le prompt inchangé si contexte vide', () => {
    const { injectContext } = require(ADVISOR)
    const prompt = 'Implémente le service auth.'
    const result = injectContext(prompt, { injected: false, summary: '' })
    assert.equal(result, prompt)
  })

  test('retourne le prompt inchangé si contexte null', () => {
    const { injectContext } = require(ADVISOR)
    const result = injectContext('test', null)
    assert.equal(result, 'test')
  })

  test('préfixe le prompt avec le bloc YAML commenté', () => {
    const { injectContext } = require(ADVISOR)
    const ctx = {
      injected: true,
      summary: 'Similar past runs: [traj-001, traj-002] | avg success: 87% | avg duration: 11min\nKey lessons: Toujours écrire les specs en premier.',
    }
    const prompt = 'Implémente le service auth.'
    const result = injectContext(prompt, ctx)
    // Doit commencer par le header ACW
    assert.ok(result.startsWith('# Context from ADA memory (k-NN, relevance: high)'))
    // Doit contenir les lignes préfixées par #
    assert.ok(result.includes('# Similar past runs:'))
    assert.ok(result.includes('# Key lessons:'))
    // Doit se terminer par le prompt original
    assert.ok(result.endsWith(prompt))
  })

  test('le prompt original est séparé du bloc par une ligne vide', () => {
    const { injectContext } = require(ADVISOR)
    const ctx = { injected: true, summary: 'avg success: 100%' }
    const result = injectContext('do something', ctx)
    assert.ok(result.includes('\n\ndo something'))
  })

  test('chaque ligne du résumé est préfixée par #', () => {
    const { injectContext } = require(ADVISOR)
    const multilineSummary = 'Line one\nLine two\nLine three'
    const ctx = { injected: true, summary: multilineSummary }
    const result = injectContext('prompt', ctx)
    const lines = result.split('\n').filter(l => l.trim() && !l.startsWith('prompt'))
    for (const line of lines) {
      if (line.trim()) assert.ok(line.startsWith('#'), `Ligne sans # : "${line}"`)
    }
  })

  test('format exact conforme à la spécification', () => {
    const { injectContext } = require(ADVISOR)
    const ctx = {
      injected: true,
      summary: 'Similar past runs: [id1, id2, id3] | avg success: 87% | avg duration: 11min\nKey lessons: Tester avant d\'implémenter.',
    }
    const result = injectContext('Do the task.', ctx)
    const expected = [
      '# Context from ADA memory (k-NN, relevance: high)',
      '# Similar past runs: [id1, id2, id3] | avg success: 87% | avg duration: 11min',
      "# Key lessons: Tester avant d'implémenter.",
      '',
      'Do the task.',
    ].join('\n')
    assert.equal(result, expected)
  })
})
