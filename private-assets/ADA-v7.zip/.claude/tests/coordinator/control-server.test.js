#!/usr/bin/env node
'use strict'
/**
 * tests/coordinator/control-server.test.js — Control Server P0 (ADR-016).
 *
 * Couvre : handshake (ok + rejet version), HMAC (frame valide/falsifiée),
 * round-trip run.init→run.next→run.status sur socket, router.* + bank.* in-process,
 * event sur socket + présence dans events.ndjson (dédup par id),
 * erreurs 1001 (runId inconnu) et 1004 (profil mismatch).
 */

const { test, describe, before, after } = require('node:test')
const assert = require('node:assert/strict')
const net    = require('net')
const { mkdirSync, rmSync, existsSync, writeFileSync, readFileSync } = require('fs')
const { join } = require('path')

const TMP        = join(__dirname, '../../..', '.test-tmp-control')
const COORD      = join(__dirname, '../../coordinator')
const SECRET     = 'test-secret-deadbeef'

const { ControlServer, ERR, PROTOCOL_VERSION } = require(join(COORD, 'control-server.js'))
const { sign, attachSignature } = require(join(COORD, 'ipc-canonical.js'))

const PIPELINES = {
  feature: {
    description: 'Test pipeline',
    phases: [
      { id: 'schema',  agent: 'db',     depends: [],         required: true, maxRetries: 1, stopOnFailure: true, tier: 2 },
      { id: 'backend', agent: 'nestjs', depends: ['schema'], required: true, maxRetries: 1, stopOnFailure: true, tier: 3 },
    ],
  },
}

// ── Client NDJSON / JSON-RPC minimal ──────────────────────────────────────────

function connect(info) {
  return new Promise((resolve, reject) => {
    const sock = info.transport === 'tcp'
      ? net.createConnection({ host: info.host, port: info.port })
      : net.createConnection({ path: info.path })
    sock.setEncoding('utf8')
    sock.once('connect', () => resolve(sock))
    sock.once('error', reject)
  })
}

/** Envoie une frame brute (déjà construite) et attend la réponse corrélée par id. */
function rpcRaw(sock, frame) {
  return new Promise((resolve, reject) => {
    let buf = ''
    const onData = chunk => {
      buf += chunk
      let idx
      while ((idx = buf.indexOf('\n')) !== -1) {
        const line = buf.slice(0, idx)
        buf = buf.slice(idx + 1)
        if (!line.trim()) continue
        const msg = JSON.parse(line)
        if (msg.id === frame.id) {
          sock.removeListener('data', onData)
          return resolve(msg)
        }
      }
    }
    sock.on('data', onData)
    sock.once('error', reject)
    sock.write(JSON.stringify(frame) + '\n')
  })
}

let _id = 0
function call(sock, method, params) {
  const id = ++_id
  const frame = attachSignature({ jsonrpc: '2.0', id, method, params: params || {} }, SECRET)
  return rpcRaw(sock, frame)
}

async function handshake(sock, profile) {
  return call(sock, 'hello', { protocolVersion: PROTOCOL_VERSION, profile })
}

// ── Setup ──────────────────────────────────────────────────────────────────

let server, info, profile

before(async () => {
  rmSync(TMP, { recursive: true, force: true })
  mkdirSync(join(TMP, 'coordinator'), { recursive: true })
  mkdirSync(join(TMP, 'runs'), { recursive: true })
  writeFileSync(join(TMP, 'coordinator', 'pipelines.json'), JSON.stringify(PIPELINES, null, 2))

  // Fixture agents (P4a — agents.list/search lit <profileDir>/agents/*.md)
  mkdirSync(join(TMP, 'agents'), { recursive: true })
  writeFileSync(join(TMP, 'agents', 'nestjs.md'), '---\nname: "NestJS"\ndescription: "Backend NestJS"\nskills: "create-module, create-guard"\n---\n# NestJS Agent\n## Rôle\nBackend NestJS strict.\n')
  writeFileSync(join(TMP, 'agents', 'nextjs.md'), '# NextJS Agent\n## Rôle\nFrontend Next.js.\n')

  // Fixture teams (P7 — teams.list/get lit coordinator/teams.json)
  writeFileSync(join(TMP, 'coordinator', 'teams.json'), JSON.stringify([
    { id: '11111111-1111-1111-1111-111111111111', name: 'fullstack', agents: ['nestjs', 'nextjs', 'db'], pipeline: 'feature', createdAt: '2026-01-01T00:00:00.000Z', updatedAt: '2026-01-01T00:00:00.000Z' },
  ], null, 2))

  // Fixture vault Obsidian (P8 — obsidian.wiki/note lit <vault>/{wiki,topics,sessions})
  const vaultDir = join(TMP, '_obsidian')
  mkdirSync(join(vaultDir, 'wiki'), { recursive: true })
  mkdirSync(join(vaultDir, 'topics'), { recursive: true })
  mkdirSync(join(vaultDir, 'sessions'), { recursive: true })
  writeFileSync(join(vaultDir, 'wiki', 'index.md'), '---\ngenerated: 2026-06-01\nsessions: 12\n---\n# Index\n')
  writeFileSync(join(vaultDir, 'topics', 'ada-interface.md'), '---\ntopic: ADA Interface\ndomain: frontend\nsessions: 5\nupdated: 2026-05-13\n---\n# ADA Interface\nProjets :\n- `ada-ui`\n- `ada-api`\n')
  writeFileSync(join(vaultDir, 'sessions', 'session-001.md'), '# Session 001\nNote de session.\n')

  // Fixture ~/.ada.json hermétique (P8 — obsidian activé, mode per-profile)
  const adaCfgPath = join(TMP, '.ada.json')
  writeFileSync(adaCfgPath, JSON.stringify({ obsidian: { enabled: true, mode: 'per-profile', vaultPath: null } }, null, 2))

  process.env.CLAUDE_CONFIG_DIR = TMP
  process.env.ADA_EVENTS_LOG = join(TMP, 'events.ndjson')
  process.env.ADA_CONFIG_PATH = adaCfgPath
  // budget-guard.js résout son LOG_DIR via HOME (littéral), PAS via
  // CLAUDE_CONFIG_DIR — sans ce override, budget.check/budget.record (RPC)
  // lisent/écrivent le VRAI ~/.ada/logs/budget-log.json du profil réel de
  // l'utilisateur. Trouvé et corrigé 2026-08-28 après une pollution réelle
  // (2 entrées `ctrl-test` écrites puis retirées de ~/.ada/logs/budget-log.json).
  process.env.ADA_LOG_DIR = join(TMP, '.ada', 'logs')

  server = new ControlServer({ profileDir: TMP, secret: SECRET })
  info = await server.start()
  profile = server.profile
})

after(async () => {
  if (server) await server.stop()
  rmSync(TMP, { recursive: true, force: true })
  delete process.env.CLAUDE_CONFIG_DIR
  delete process.env.ADA_EVENTS_LOG
  delete process.env.ADA_CONFIG_PATH
  delete process.env.ADA_LOG_DIR
})

// ── Tests ──────────────────────────────────────────────────────────────────

describe('handshake', () => {
  test('hello compatible → handshaked', async () => {
    const sock = await connect(info)
    const res = await handshake(sock, profile)
    assert.equal(res.result.protocolVersion, PROTOCOL_VERSION)
    assert.equal(res.result.profile, profile)
    sock.destroy()
  })

  test('hello version majeure incompatible → 1005', async () => {
    const sock = await connect(info)
    const res = await call(sock, 'hello', { protocolVersion: '99.0.0', profile })
    assert.ok(res.error)
    assert.equal(res.error.code, ERR.PROTOCOL_INCOMPAT)
    sock.destroy()
  })

  test('profil mismatch → 1004', async () => {
    const sock = await connect(info)
    const res = await call(sock, 'hello', { protocolVersion: PROTOCOL_VERSION, profile: 'wrong-profile' })
    assert.ok(res.error)
    assert.equal(res.error.code, ERR.PROFILE_MISMATCH)
    sock.destroy()
  })

  test('méthode avant handshake → -32600 (hors séquence)', async () => {
    const sock = await connect(info)
    const res = await call(sock, 'health.probe', {})
    assert.ok(res.error)
    assert.equal(res.error.code, ERR.NOT_HANDSHAKED)
    sock.destroy()
  })
})

describe('HMAC', () => {
  test('frame valide acceptée', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const res = await call(sock, 'health.probe', {})
    assert.equal(res.result.status, 'ok')
    sock.destroy()
  })

  test('frame falsifiée rejetée (-32600)', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const id = ++_id
    // Signature valide puis on altère le payload après coup → _sig ne correspond plus.
    const good = attachSignature({ jsonrpc: '2.0', id, method: 'health.probe', params: {} }, SECRET)
    good.params = { tampered: true }
    const res = await rpcRaw(sock, good)
    assert.ok(res.error)
    assert.equal(res.error.code, ERR.AUTH_FAILED)
    sock.destroy()
  })
})

describe('run.* round-trip', () => {
  let runId

  test('run.init crée un run', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const res = await call(sock, 'run.init', { pipeline: 'feature', feature: 'ctrl-test' })
    assert.ok(res.result.runId, 'runId attendu')
    runId = res.result.runId
    sock.destroy()
  })

  test('run.next retourne la phase prête (schema)', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const res = await call(sock, 'run.next', { runId })
    assert.equal(res.result.runId, runId)
    assert.ok(res.result.ready.some(r => r.phaseId === 'schema'))
    const schema = res.result.ready.find(r => r.phaseId === 'schema')
    assert.ok(schema.model, 'model recommandé par tier attendu')
    sock.destroy()
  })

  test('run.status renvoie le state complet', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const res = await call(sock, 'run.status', { runId })
    assert.equal(res.result.state.id, runId)
    assert.equal(res.result.state.pipeline, 'feature')
    assert.equal(res.result.state.phases.schema.status, 'pending')
    sock.destroy()
  })

  test('run.status sur runId inconnu → 1001', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const res = await call(sock, 'run.status', { runId: 'inexistant-run-xyz' })
    assert.ok(res.error)
    assert.equal(res.error.code, ERR.RUN_NOT_FOUND)
    sock.destroy()
  })

  // Gap de couverture comblé 2026-08-28 (audit ROI Tier C) : run.start/run.done
  // n'étaient exercés par aucun test RPC — seul le round-trip init→next→status
  // l'était. C'est pourtant la surface mutative la plus utilisée par un client
  // externe (UI/CLI) du control plane.
  test('run.start puis run.done complète la phase schema', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)

    const started = await call(sock, 'run.start', { runId, phaseId: 'schema' })
    assert.ok(started.result, 'run.start doit retourner un résultat')
    assert.ok(!started.error, `run.start ne doit pas erreurer : ${JSON.stringify(started.error)}`)

    const done = await call(sock, 'run.done', { runId, phaseId: 'schema', summary: 'schema conçu (test RPC)' })
    assert.ok(done.result.ok, 'run.done doit retourner ok:true')

    const status = await call(sock, 'run.status', { runId })
    assert.equal(status.result.state.phases.schema.status, 'completed')
    sock.destroy()
  })
})

// Gap de couverture comblé 2026-08-28 (audit ROI Tier C) : run.fail/retry/
// rollback/skip n'avaient aucun test RPC — seul run.done l'avait (ajouté plus
// haut). C'est pourtant la surface mutative la plus critique du control plane
// (un bug ici corrompt l'état d'un run réel, pas juste un affichage).
describe('run.* fail/retry/rollback/skip (RPC)', () => {
  test('run.fail sans --retry marque la phase failed et bloque le pipeline (maxRetries=1, stopOnFailure=true)', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const init = await call(sock, 'run.init', { pipeline: 'feature', feature: 'fail-test-1' })
    const runId = init.result.runId

    const failed = await call(sock, 'run.fail', { runId, phaseId: 'schema', error: 'erreur de test volontaire' })
    assert.ok(failed.result.ok)

    const status = await call(sock, 'run.status', { runId })
    assert.equal(status.result.state.phases.schema.status, 'failed')
    sock.destroy()
  })

  test('run.fail --retry puis run.retry relance la phase (retries incrémenté, sous quota)', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const init = await call(sock, 'run.init', { pipeline: 'feature', feature: 'fail-retry-test' })
    const runId = init.result.runId

    await call(sock, 'run.fail', { runId, phaseId: 'schema', error: 'échec transitoire', retry: true })
    const afterFail = await call(sock, 'run.status', { runId })
    assert.ok(afterFail.result.state.phases.schema.retries >= 1, 'retries doit être incrémenté')

    const retried = await call(sock, 'run.retry', { runId })
    assert.ok(retried.result.ok, `run.retry ne doit pas erreurer : ${JSON.stringify(retried.error)}`)
    const status = await call(sock, 'run.status', { runId })
    assert.equal(status.result.state.phases.schema.status, 'retrying', 'la phase relancée doit passer retrying')
    sock.destroy()
  })

  test('run.skip marque la phase skipped avec la raison fournie', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const init = await call(sock, 'run.init', { pipeline: 'feature', feature: 'skip-test-rpc' })
    const runId = init.result.runId

    const skipped = await call(sock, 'run.skip', { runId, phaseId: 'backend', reason: 'raison de test' })
    assert.ok(skipped.result.ok)
    const status = await call(sock, 'run.status', { runId })
    assert.equal(status.result.state.phases.backend.status, 'skipped')
    assert.equal(status.result.state.phases.backend.skipReason, 'raison de test')
    sock.destroy()
  })

  test('run.rollback sur une phase completed la remet pending', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const init = await call(sock, 'run.init', { pipeline: 'feature', feature: 'rollback-test-rpc' })
    const runId = init.result.runId

    await call(sock, 'run.start', { runId, phaseId: 'schema' })
    await call(sock, 'run.done', { runId, phaseId: 'schema', summary: 'schema fait (test rollback)' })
    const before = await call(sock, 'run.status', { runId })
    assert.equal(before.result.state.phases.schema.status, 'completed')

    const rolled = await call(sock, 'run.rollback', { runId, phaseId: 'schema' })
    assert.ok(rolled.result.ok, `run.rollback ne doit pas erreurer : ${JSON.stringify(rolled.error)}`)
    const after = await call(sock, 'run.status', { runId })
    assert.equal(after.result.state.phases.schema.status, 'pending', 'la phase rollback doit repasser pending')
    sock.destroy()
  })

  test('run.list inclut les runs créés par ce test', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const init = await call(sock, 'run.init', { pipeline: 'feature', feature: 'list-test-rpc' })
    const runId = init.result.runId
    const list = await call(sock, 'run.list', {})
    assert.ok(Array.isArray(list.result.runs))
    assert.ok(list.result.runs.some(r => r.id === runId), 'le run créé doit apparaître dans run.list')
    sock.destroy()
  })
})

describe('router.* et bank.* in-process', () => {
  test('router.recommend retourne un agent', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const res = await call(sock, 'router.recommend', { phaseType: 'backend:nestjs' })
    assert.ok(res.result, 'résultat router attendu')
    assert.ok('agent' in res.result)
    sock.destroy()
  })

  test('bank.store puis bank.retrieve', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const stored = await call(sock, 'bank.store', {
      phase: 'backend', agent: 'nestjs', verdict: 'success', summary: 'control plane test trajectory',
    })
    assert.ok(stored.result.id, 'id de trajectoire attendu')
    const got = await call(sock, 'bank.retrieve', { query: 'control plane test', opts: { limit: 5 } })
    assert.ok(Array.isArray(got.result.trajectories))
    sock.destroy()
  })

  test('health.probe inclut le bloc memory (P1-2)', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const res = await call(sock, 'health.probe', {})
    assert.equal(res.result.status, 'ok')
    assert.equal(typeof res.result.uptimeMs, 'number')
    assert.equal(typeof res.result.pid, 'number')
    const mem = res.result.memory
    assert.ok(mem, 'health.probe doit exposer memory (P1-2)')
    assert.ok(mem.ollama === 'up' || mem.ollama === 'down', 'memory.ollama ∈ up|down')
    assert.equal(typeof mem.recallDegraded, 'boolean')
    assert.ok('lastRecallDegradedAt' in mem, 'memory.lastRecallDegradedAt présent (ts|null)')
    sock.destroy()
  })
})

// Gap de couverture comblé 2026-08-28 (audit ROI Tier C) : router.update en RPC
// (chemin in-process, distinct du spawn CLI fire-and-forget de run.js — voir le
// fix routerUpdate/bankStore du même jour) et budget.check/record n'avaient
// aucun test malgré leur rôle sur le control plane (gouvernance de coût réelle).
describe('router.update / router.stats (RPC in-process)', () => {
  test('router.update puis router.stats reflète le nouveau prior', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)

    const before = await call(sock, 'router.stats', {})
    const beforeTotal = before.result.totalUpdates || 0

    const updated = await call(sock, 'router.update', { phaseType: 'backend', agent: 'nestjs', outcome: 'success' })
    assert.ok(!updated.error, `router.update ne doit pas erreurer : ${JSON.stringify(updated.error)}`)

    const after = await call(sock, 'router.stats', {})
    assert.equal(after.result.totalUpdates, beforeTotal + 1, 'totalUpdates doit incrémenter de 1')
    assert.ok(after.result.priors['backend:nestjs'], 'le prior backend:nestjs (priorKey = phaseType:agent) doit exister')
    sock.destroy()
  })
})

describe('budget.check / budget.record (RPC)', () => {
  test('budget.check sous le plafond → action continue', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const res = await call(sock, 'budget.check', { runId: 'ctrl-test', phaseCost: 0.10, cumulCost: 0.10 })
    assert.equal(res.result.ok, true)
    assert.equal(res.result.action, 'continue')
    sock.destroy()
  })

  test('budget.check au-dessus du plafond perRun (config défaut onExceed=warn) → action warn, pas d\'erreur', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    // DEFAULTS.perRun = 5 (budget-guard.js), aucune clé `budget` dans la fixture
    // ~/.ada.json de ce test → défauts appliqués, onExceed='warn' (pas 'stop').
    const res = await call(sock, 'budget.check', { runId: 'ctrl-test', phaseCost: 6, cumulCost: 6 })
    assert.ok(!res.error, `onExceed=warn ne doit jamais throw : ${JSON.stringify(res.error)}`)
    assert.equal(res.result.ok, false)
    assert.equal(res.result.action, 'warn')
    sock.destroy()
  })

  test('budget.record persiste un coût (pas d\'erreur, ok:true)', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const res = await call(sock, 'budget.record', { runId: 'ctrl-test', amount: 0.05, model: 'claude-sonnet-5' })
    assert.equal(res.result.ok, true)
    sock.destroy()
  })

  // ADR-023 étape 4 — gouvernance des délégations adaptatives. Sans test RPC
  // avant (seule la fonction pure checkDelegationBudget était testée en unitaire).
  test('budget.checkDelegation sous maxDelegationsPerRun (défaut 3) → ok', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const res = await call(sock, 'budget.checkDelegation', { runId: 'ctrl-deleg-test', delegationCount: 1, cumulCost: 0.1 })
    assert.ok(!res.error)
    assert.equal(res.result.ok, true)
    sock.destroy()
  })

  test('budget.checkDelegation au-dessus de maxDelegationsPerRun → refus dur (BUDGET_EXCEEDED, adaptiveOnExceed=stop par défaut)', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    // DEFAULTS.maxDelegationsPerRun = 3, DEFAULTS.adaptiveOnExceed = 'stop'
    // (ADR-023 : refus dur exigé sur ce chemin précis, contrairement à
    // budget.check qui peut n'être qu'un avertissement).
    const res = await call(sock, 'budget.checkDelegation', { runId: 'ctrl-deleg-test-2', delegationCount: 4, cumulCost: 0.1 })
    assert.ok(res.error, 'doit throw en erreur RPC, pas juste retourner ok:false')
    assert.equal(res.error.code, ERR.BUDGET_EXCEEDED)
    sock.destroy()
  })

  test('budget.recordDelegation persiste (ok:true)', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const res = await call(sock, 'budget.recordDelegation', {
      runId: 'ctrl-deleg-test', agent: 'reviewer', model: 'claude-opus-5', mandateId: 'test-mandate', cost: 0.02,
    })
    assert.equal(res.result.ok, true)
    sock.destroy()
  })
})

describe('events', () => {
  test('event poussé sur socket abonné + présent dans events.ndjson (dédup par id)', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    await call(sock, 'subscribe', {})

    const received = new Promise(resolve => {
      let buf = ''
      sock.on('data', chunk => {
        buf += chunk
        let idx
        while ((idx = buf.indexOf('\n')) !== -1) {
          const line = buf.slice(0, idx); buf = buf.slice(idx + 1)
          if (!line.trim()) continue
          const msg = JSON.parse(line)
          if (msg.type === 'run.phase.started') resolve(msg)
        }
      })
    })

    const evt = server.emitEvent('run.phase.started', { runId: 'evt-run', phaseId: 'schema' }, { runId: 'evt-run' })
    const onSock = await received

    assert.equal(onSock.id, evt.id, 'même id sur socket et émission')
    assert.equal(onSock.corr.runId, 'evt-run')

    // Présence dans events.ndjson + dédup (un seul enregistrement pour cet id)
    const log = readFileSync(process.env.ADA_EVENTS_LOG, 'utf8').trim().split('\n').filter(Boolean)
    const matches = log.map(l => JSON.parse(l)).filter(e => e.id === evt.id)
    assert.equal(matches.length, 1, 'event présent exactement une fois (dédup)')
    assert.equal(matches[0].type, 'run.phase.started')

    sock.destroy()
  })
})

describe('P4a — surface CLI complète (méthodes in-process)', () => {
  test('agents.list retourne les agents du profil', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const res = await call(sock, 'agents.list', {})
    assert.ok(Array.isArray(res.result.agents))
    assert.ok(res.result.agents.some(a => a.name === 'nestjs'))
    assert.equal(res.result.total, res.result.agents.length)
    sock.destroy()
  })

  test('agents.search filtre par requête', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const res = await call(sock, 'agents.search', { query: 'next' })
    assert.ok(res.result.agents.some(a => a.name === 'nextjs'))
    assert.ok(!res.result.agents.some(a => a.name === 'nestjs'))
    sock.destroy()
  })

  test('skills.list retourne installed + available (lecture)', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const res = await call(sock, 'skills.list', {})
    assert.ok(Array.isArray(res.result.installed))
    assert.ok(Array.isArray(res.result.available))
    assert.ok(res.result.counts && typeof res.result.counts.installed === 'number')
    sock.destroy()
  })

  test('daemon.status reflète l\'absence de daemon (running=false)', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const res = await call(sock, 'daemon.status', {})
    assert.equal(res.result.running, false)
    assert.ok(res.result.schedule && typeof res.result.schedule === 'object')
    assert.ok(res.result.workers && typeof res.result.workers === 'object')
    sock.destroy()
  })

  test('capabilities.list annonce les nouveaux groupes + mutativeMethods', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const res = await call(sock, 'capabilities.list', {})
    assert.ok(res.result.methods.includes('agents.list'))
    assert.ok(res.result.methods.includes('skills.list'))
    assert.ok(res.result.methodGroups.daemon.includes('daemon.status'))
    assert.ok(res.result.mutativeMethods.includes('providers.set'))
    sock.destroy()
  })
})

describe('P7 — features de configuration (RPC)', () => {
  test('pipelines.list parse pipelines.json (résout tier/model/deps)', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const res = await call(sock, 'pipelines.list', {})
    assert.ok(Array.isArray(res.result.pipelines))
    const feat = res.result.pipelines.find(p => p.name === 'feature')
    assert.ok(feat, 'pipeline "feature" présent')
    assert.equal(feat.phases.length, 2)
    const backend = feat.phases.find(ph => ph.id === 'backend')
    assert.equal(backend.tier, 3)
    assert.deepEqual(backend.depends, ['schema'])
    // model résolu via router.recommendModel (string ou null en dégradation)
    assert.ok(backend.model === null || typeof backend.model === 'string')
    sock.destroy()
  })

  test('pipelines.get renvoie un pipeline ; inconnu → erreur', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const res = await call(sock, 'pipelines.get', { name: 'feature' })
    assert.equal(res.result.pipeline.name, 'feature')
    const miss = await call(sock, 'pipelines.get', { name: 'inexistant' })
    assert.ok(miss.error)
    assert.equal(miss.error.code, ERR.RUN_NOT_FOUND)
    sock.destroy()
  })

  test('mcp.add → mcp.list → mcp.remove (mute settings.json, env masqué)', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const add = await call(sock, 'mcp.add', { id: 'github', command: 'npx', args: ['-y', 'srv'], env: { GITHUB_TOKEN: 'secret-value' } })
    assert.equal(add.result.ok, true)
    // env renvoyé = clés seulement (jamais de secret en clair)
    assert.deepEqual(add.result.connector.env, ['GITHUB_TOKEN'])

    const list = await call(sock, 'mcp.list', {})
    const gh = list.result.connectors.find(c => c.id === 'github')
    assert.ok(gh)
    assert.equal(gh.transport, 'stdio')
    assert.deepEqual(gh.env, ['GITHUB_TOKEN'])
    // settings.json contient bien le secret (mais jamais surfacé par le RPC)
    const persisted = JSON.parse(readFileSync(join(TMP, 'settings.json'), 'utf8'))
    assert.equal(persisted.mcpServers.github.env.GITHUB_TOKEN, 'secret-value')

    const rm = await call(sock, 'mcp.remove', { id: 'github' })
    assert.equal(rm.result.removed, 1)
    sock.destroy()
  })

  test('mcp.registry expose le catalogue', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const res = await call(sock, 'mcp.registry', {})
    assert.ok(Array.isArray(res.result.catalog))
    assert.ok(res.result.catalog.some(c => c.id === 'github'))
    sock.destroy()
  })

  test('teams.list lit teams.json ; teams.get + create + remove', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const list = await call(sock, 'teams.list', {})
    assert.ok(list.result.teams.some(t => t.name === 'fullstack'))

    const created = await call(sock, 'teams.create', { name: 'mobile', agents: ['react-native', 'api-designer'] })
    assert.equal(created.result.ok, true)
    assert.ok(SAFE_UUID(created.result.team.id))

    const got = await call(sock, 'teams.get', { id: created.result.team.id })
    assert.equal(got.result.team.name, 'mobile')

    const rm = await call(sock, 'teams.remove', { id: created.result.team.id })
    assert.equal(rm.result.removed, 1)
    sock.destroy()
  })

  test('agents.info renvoie frontmatter + prompt + skills', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const res = await call(sock, 'agents.info', { slug: 'nestjs' })
    assert.equal(res.result.agent.slug, 'nestjs')
    assert.equal(res.result.agent.name, 'NestJS')
    assert.deepEqual(res.result.agent.skills, ['create-module', 'create-guard'])
    assert.ok(res.result.agent.prompt.includes('Backend NestJS strict'))
    const miss = await call(sock, 'agents.info', { slug: 'ghost' })
    assert.ok(miss.error)
    assert.equal(miss.error.code, ERR.RUN_NOT_FOUND)
    sock.destroy()
  })

  test('capabilities.list annonce les groupes P7 (pipelines/mcp/teams/settings)', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const res = await call(sock, 'capabilities.list', {})
    assert.ok(res.result.methodGroups.pipelines.includes('pipelines.list'))
    assert.ok(res.result.methodGroups.mcp.includes('mcp.add'))
    assert.ok(res.result.methodGroups.teams.includes('teams.create'))
    assert.ok(res.result.methodGroups.settings.includes('settings.get'))
    assert.ok(res.result.mutativeMethods.includes('mcp.add'))
    assert.ok(res.result.mutativeMethods.includes('teams.create'))
    assert.ok(res.result.mutativeMethods.includes('profiles.switch'))
    sock.destroy()
  })
})

// Gap de couverture comblé 2026-08-28 (audit ROI Tier C, suite) : 27 méthodes
// RPC supplémentaires sans aucun test. Portée volontairement limitée aux
// chemins SÛRS : `readAdaConfig`/`writeAdaConfig` honorent ADA_CONFIG_PATH
// (déjà isolé dans le before() de ce fichier) donc testables pleinement.
// EXCLUS délibérément d'un test comportemental complet — risque réel non
// maîtrisable dans ce harnais : `team.pull`/`team.push` (git réseau),
// `provider.complete`/`provider.embed` (appel LLM réel si provider actif),
// `skill.install` (archive distante), `daemon.run` sur un worker EXISTANT
// (spawn détaché réel) — seule leur validation d'entrée est couverte.
describe('P9 — profiles/schedules/providers/obsidian.setEnabled (RPC, [MUTATIF ~/.ada.json isolé])', () => {
  test('profiles.create puis profiles.switch', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const created = await call(sock, 'profiles.create', { name: 'rpc-test-profile' })
    assert.equal(created.result.ok, true)
    assert.equal(created.result.profile.name, 'rpc-test-profile')

    const switched = await call(sock, 'profiles.switch', { profile: 'rpc-test-profile' })
    assert.equal(switched.result.ok, true)
    assert.equal(switched.result.active, 'claude-rpc-test-profile')
    sock.destroy()
  })

  test('profiles.switch/create rejette un nom invalide (path traversal, espaces, etc.)', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const res = await call(sock, 'profiles.switch', { profile: '../../etc/passwd' })
    assert.ok(res.error)
    assert.equal(res.error.code, ERR.INVALID_PARAMS)
    sock.destroy()
  })

  test('schedules.add → schedules.list → schedules.toggle → schedules.remove', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const added = await call(sock, 'schedules.add', { pipeline: 'feature', cron: '0 9 * * *', name: 'test-schedule' })
    assert.equal(added.result.ok, true)
    const id = added.result.schedule.id

    const listed = await call(sock, 'schedules.list', {})
    assert.ok(listed.result.schedules.some(s => s.id === id))

    const toggled = await call(sock, 'schedules.toggle', { id })
    assert.equal(toggled.result.schedule.enabled, false, 'toggle doit inverser enabled (true→false)')

    const removed = await call(sock, 'schedules.remove', { id })
    assert.equal(removed.result.removed, 1)
    const afterRemove = await call(sock, 'schedules.list', {})
    assert.ok(!afterRemove.result.schedules.some(s => s.id === id))
    sock.destroy()
  })

  test('providers.status lit le mode par défaut ; providers.set rejette un mode invalide', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const status = await call(sock, 'providers.status', {})
    assert.ok(!status.error)
    assert.ok(typeof status.result.mode === 'string')

    const bad = await call(sock, 'providers.set', { mode: 'not-a-real-mode' })
    assert.ok(bad.error)
    assert.equal(bad.error.code, ERR.INVALID_PARAMS)
    sock.destroy()
  })

  test('obsidian.setEnabled bascule le flag dans ~/.ada.json (isolé)', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const off = await call(sock, 'obsidian.setEnabled', { enabled: false })
    assert.equal(off.result.enabled, false)
    const on = await call(sock, 'obsidian.setEnabled', { enabled: true })
    assert.equal(on.result.enabled, true)
    sock.destroy()
  })

  test('logs.tail (source events) retourne les dernières lignes de ADA_EVENTS_LOG', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    await call(sock, 'subscribe', {}) // génère au moins un event côté serveur si besoin
    const res = await call(sock, 'logs.tail', { lines: 5 })
    assert.equal(res.result.source, 'events')
    assert.ok(Array.isArray(res.result.lines))
    sock.destroy()
  })

  test('bank.stream retourne des chunks (fallback retrieve si collectStream absent)', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    await call(sock, 'bank.store', { phase: 'backend', agent: 'nestjs', verdict: 'success', summary: 'bank.stream RPC test fixture' })
    const res = await call(sock, 'bank.stream', { query: 'bank.stream RPC test', opts: { limit: 5 } })
    assert.ok(!res.error, `bank.stream ne doit pas erreurer : ${JSON.stringify(res.error)}`)
    assert.ok(Array.isArray(res.result.chunks))
    sock.destroy()
  })

  test('cost.report ne throw pas et retourne un objet (agrégation sur profil de test vide)', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const res = await call(sock, 'cost.report', {})
    assert.ok(!res.error, `cost.report ne doit pas erreurer : ${JSON.stringify(res.error)}`)
    assert.equal(typeof res.result, 'object')
    sock.destroy()
  })

  test('fed.status / fed.peers (lecture seule, aucun I/O réseau)', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const status = await call(sock, 'fed.status', {})
    assert.ok(!status.error)
    assert.equal(typeof status.result.enabled, 'boolean')
    const peers = await call(sock, 'fed.peers', {})
    assert.ok(Array.isArray(peers.result.configured))
    sock.destroy()
  })

  test('bridge.list / bridge.status (lecture seule, aucun I/O réseau)', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const list = await call(sock, 'bridge.list', {})
    assert.ok(Array.isArray(list.result.profiles))
    const status = await call(sock, 'bridge.status', {})
    assert.ok(typeof status.result.current === 'string')
    sock.destroy()
  })

  test('bridge.send/receive/shareLessons valident leurs paramètres requis (pas d\'I/O réel testé — écrit chez un AUTRE profil)', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const send = await call(sock, 'bridge.send', { runId: 'x' }) // manque `to`
    assert.ok(send.error)
    assert.equal(send.error.code, ERR.INVALID_PARAMS)
    const share = await call(sock, 'bridge.shareLessons', {}) // manque `to`
    assert.ok(share.error)
    assert.equal(share.error.code, ERR.INVALID_PARAMS)
    sock.destroy()
  })

  test('skill.install/uninstall valident { name } requis (pas d\'installation réelle testée — archive distante possible)', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const install = await call(sock, 'skill.install', {})
    assert.ok(install.error)
    assert.equal(install.error.code, ERR.INVALID_PARAMS)
    const uninstall = await call(sock, 'skill.uninstall', {})
    assert.ok(uninstall.error)
    assert.equal(uninstall.error.code, ERR.INVALID_PARAMS)
    sock.destroy()
  })

  test('daemon.run valide le nom de worker (path traversal / RCE) sans jamais spawn un worker existant', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const bad = await call(sock, 'daemon.run', { worker: '../../../etc/passwd' })
    assert.ok(bad.error)
    assert.equal(bad.error.code, ERR.INVALID_PARAMS)
    // Nom valide au format mais fichier worker inexistant : runWorker() logue un
    // warning et retourne sans spawn (vérifié en lisant workers/daemon.js) — le
    // RPC lui-même retourne ok:true sans qu'aucun process réel ne démarre.
    const noop = await call(sock, 'daemon.run', { worker: 'rpc-test-nonexistent-worker' })
    assert.equal(noop.result.ok, true)
    sock.destroy()
  })
})

describe('P8 — mémoire riche (memory.graph + obsidian.wiki/note)', () => {
  test('memory.graph projette le graphe en { nodes, edges, stats }', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const res = await call(sock, 'memory.graph', {})
    assert.ok(Array.isArray(res.result.nodes), 'nodes est un tableau')
    assert.ok(Array.isArray(res.result.edges), 'edges est un tableau')
    assert.ok(res.result.stats && typeof res.result.stats.totalNodes === 'number')
    // pipelines.json (schema→backend) → 2 nœuds phase + 1 pipeline, 1 arête PRÉCÈDE
    assert.ok(res.result.nodes.length >= 2, 'graphe non vide depuis pipelines.json')
    assert.ok(res.result.empty === false)
    const node = res.result.nodes[0]
    assert.ok(typeof node.id === 'string' && typeof node.label === 'string' && typeof node.type === 'string')
    const edge = res.result.edges[0]
    assert.ok(typeof edge.source === 'string' && typeof edge.target === 'string')
    sock.destroy()
  })

  test('memory.graph ?pagerank annote chaque nœud d\'un score', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const res = await call(sock, 'memory.graph', { pagerank: true, top: 5 })
    assert.equal(res.result.pagerank, true)
    assert.ok(res.result.nodes.length <= 5)
    assert.ok(res.result.nodes.every(n => typeof n.pagerank === 'number'))
    sock.destroy()
  })

  test('memory.graph dégrade gracieusement quand le graphe est vide', async () => {
    // Pas de bank-state ; un configDir vide → graphe sans pipelines = vide.
    const sock = await connect(info)
    await handshake(sock, profile)
    // On valide la forme du payload : même non vide ici, stats restent cohérentes.
    const res = await call(sock, 'memory.graph', {})
    assert.ok('empty' in res.result)
    assert.ok(res.result.stats.totalEdges === res.result.edges.length)
    sock.destroy()
  })

  test('obsidian.wiki liste les topics + index du vault', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const res = await call(sock, 'obsidian.wiki', {})
    assert.equal(res.result.empty, false)
    assert.equal(res.result.totalSessions, 12)
    assert.ok(res.result.topics.some(t => t.slug === 'ada-interface'))
    const topic = res.result.topics.find(t => t.slug === 'ada-interface')
    assert.equal(topic.domain, 'frontend')
    assert.deepEqual(topic.projects, ['ada-ui', 'ada-api'])
    sock.destroy()
  })

  test('obsidian.note lit une note .md (sessions/ ou topics/)', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const res = await call(sock, 'obsidian.note', { file: 'session-001.md' })
    assert.equal(res.result.file, 'session-001.md')
    assert.equal(res.result.dir, 'sessions')
    assert.ok(res.result.content.includes('Note de session'))
    // Note dans topics/ également résolue.
    const topicNote = await call(sock, 'obsidian.note', { file: 'ada-interface.md' })
    assert.equal(topicNote.result.dir, 'topics')
    sock.destroy()
  })

  test('obsidian.note rejette le path-traversal et les noms invalides', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    for (const bad of ['../../../etc/passwd', '..%2Fsecret.md', 'sub/dir.md', '/abs.md', 'note.txt', '..md', 'a/../b.md']) {
      const res = await call(sock, 'obsidian.note', { file: bad })
      assert.ok(res.error, `attendu rejet pour "${bad}"`)
      assert.equal(res.error.code, ERR.INVALID_PARAMS, `code INVALID_PARAMS pour "${bad}"`)
    }
    // Note absente mais nom valide → RUN_NOT_FOUND (1001), pas une fuite.
    const missing = await call(sock, 'obsidian.note', { file: 'ghost.md' })
    assert.ok(missing.error)
    assert.equal(missing.error.code, ERR.RUN_NOT_FOUND)
    sock.destroy()
  })

  test('capabilities.list annonce le groupe memory + obsidian.wiki/note', async () => {
    const sock = await connect(info)
    await handshake(sock, profile)
    const res = await call(sock, 'capabilities.list', {})
    assert.ok(res.result.methodGroups.memory.includes('memory.graph'))
    assert.ok(res.result.methodGroups.obsidian.includes('obsidian.wiki'))
    assert.ok(res.result.methodGroups.obsidian.includes('obsidian.note'))
    sock.destroy()
  })
})

const SAFE_UUID = s => /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(s)

describe('canonical HMAC (régression bug racine)', () => {
  test('ordre des clés indifférent → même signature', () => {
    const a = { jsonrpc: '2.0', method: 'x', id: 1, params: { b: 2, a: 1 } }
    const b = { params: { a: 1, b: 2 }, id: 1, method: 'x', jsonrpc: '2.0' }
    assert.equal(sign(a, SECRET), sign(b, SECRET))
  })
})
