#!/usr/bin/env node
'use strict'
/**
 * conventions.test.js — Axe A : storeConvention (A3), boost convention au retrieve (A3),
 * recall/buildRecallBlock (A2). seed-conventions (A1) testé via CLI.
 */
const { test, describe, before, after, beforeEach } = require('node:test')
const assert = require('node:assert/strict')
const { mkdirSync, rmSync, existsSync, readFileSync, writeFileSync, unlinkSync } = require('fs')
const { join } = require('path')
const { execSync } = require('child_process')

const TMP = join(__dirname, '../../..', '.test-tmp-conventions')
const BANK_JS = join(__dirname, '../../coordinator/bank.js')

let bank
function loadBank() {
  delete require.cache[require.resolve(BANK_JS)]
  process.env.CLAUDE_CONFIG_DIR = TMP
  const mod = require(BANK_JS)
  mod._resetDB()
  return mod
}

function cleanDB() {
  const cd = join(TMP, 'coordinator')
  const dbPath = join(cd, 'bank.db')
  // bank.db + WAL/SHM, et les artefacts dérivés (graphe, HNSW, index) qui sinon
  // fuiteraient des scores appris d'un test à l'autre (ex: graph boost agent→phase).
  const artefacts = [
    dbPath, dbPath + '-wal', dbPath + '-shm',
    join(cd, 'graph-state.json'),
    join(cd, 'bank-hnsw.json'),
    join(cd, 'bank-index.json'),
  ]
  for (const f of artefacts) {
    if (existsSync(f)) { try { unlinkSync(f) } catch {} }
  }
}

before(() => { mkdirSync(join(TMP, 'coordinator'), { recursive: true }) })
after(() => { try { rmSync(TMP, { recursive: true }) } catch {} })
beforeEach(() => {
  const f = join(TMP, 'coordinator', 'bank-state.json')
  writeFileSync(f, JSON.stringify({ version: 1, trajectories: [], insights: null, updatedAt: new Date().toISOString() }, null, 2))
  cleanDB()
  bank = loadBank()
})

// ─── A3 — storeConvention ──────────────────────────────────────────────────────

describe('storeConvention (A3)', () => {
  test('stocke une convention avec phase/agent/verdict/tag corrects', () => {
    const { id, skipped } = bank.storeConvention('uuid PK + timestamps sur toutes les tables')
    assert.ok(id && id.startsWith('traj-'))
    assert.equal(skipped, false)
    bank.syncSnapshot()
    const t = bank.retrieve('uuid PK timestamps tables', { limit: 5 }).find(x => x.id === id)
    assert.ok(t, 'la convention doit être récupérable')
    assert.equal(t.phase, 'convention')
    assert.equal(t.agent, 'project')
    assert.equal(t.verdict, 'success')
    assert.ok(t.tags.includes('convention'), 'tag convention présent')
  })

  test('idempotent : re-store identique ne duplique pas (skipped=true)', () => {
    const a = bank.storeConvention('Pas de any TS')
    const b = bank.storeConvention('Pas de any TS')
    assert.equal(a.skipped, false)
    assert.equal(b.skipped, true)
    assert.equal(b.id, a.id, 'retourne l\'id existant')
  })

  test('dédup normalise casse et espaces', () => {
    const a = bank.storeConvention('RLS Supabase activé')
    const b = bank.storeConvention('  rls   SUPABASE   activé  ')
    assert.equal(a.skipped, false)
    assert.equal(b.skipped, true, 'doit être vu comme doublon après normalisation')
  })

  test('texte vide → skipped, pas de stockage', () => {
    const { id, skipped } = bank.storeConvention('   ')
    assert.equal(id, null)
    assert.equal(skipped, true)
  })
})

// ─── A3 — boost convention au retrieve ──────────────────────────────────────────

describe('boost convention au retrieve (A3)', () => {
  test('une convention matchante remonte AVANT une trajectoire non-convention comparable', () => {
    // Même vocabulaire dans les deux entrées → score brut comparable.
    // La convention doit gagner grâce au boost.
    bank.store('backend', 'nestjs', 'success', 'endpoint facture montant liste workspace pagination')
    bank.storeConvention('endpoint facture montant liste workspace doit filtrer par workspace_id')
    bank.syncSnapshot()

    const results = bank.retrieve('endpoint facture montant liste workspace', { limit: 5 })
    assert.ok(results.length >= 2, `attendu >=2 résultats, obtenu ${results.length}`)
    assert.ok(results[0].tags.includes('convention'), 'la convention doit être en tête')
  })

  test('une trajectoire qui matche le contenu bat une convention hors-sujet', () => {
    // La convention ne partage AUCUN token avec la requête → ne doit PAS recevoir
    // le boost convention, donc la trajectoire pertinente reste en tête.
    bank.storeConvention('Conventional Commits obligatoires sur tous les commits git')
    bank.store('backend', 'nestjs', 'success', 'kubernetes helm chart deployment ingress nginx')
    bank.syncSnapshot()
    const results = bank.retrieve('kubernetes helm ingress nginx', { limit: 5 })
    assert.ok(results.length > 0)
    assert.ok(!results[0].tags.includes('convention'), 'convention hors-sujet ne doit pas remonter en tête')
  })
})

// ─── A2 — buildRecallBlock / recall ─────────────────────────────────────────────

describe('buildRecallBlock (A2)', () => {
  test('conventions listées EN PREMIER, puis leçons', () => {
    bank.store('backend', 'nestjs', 'success', 'stripe webhook idempotency montant facture retry')
    bank.storeConvention('toute facture stocke le montant en centimes entiers')
    bank.syncSnapshot()

    const block = bank.buildRecallBlock('facture montant stripe', { limit: 6 })
    assert.ok(block.includes('[CONNAISSANCE PROJET — ReasoningBank]'))
    assert.ok(block.includes('Conventions:'))
    const convIdx = block.indexOf('Conventions:')
    const lessonIdx = block.indexOf('Leçons pertinentes:')
    if (lessonIdx !== -1) {
      assert.ok(convIdx < lessonIdx, 'Conventions doit précéder Leçons pertinentes')
    }
    assert.ok(block.includes('centimes entiers'), 'la convention doit apparaître')
  })

  test('sortie vide si aucune connaissance pertinente', () => {
    const block = bank.buildRecallBlock('xyzzy plugh quux inexistant', { limit: 6 })
    assert.equal(block, '')
  })

  test('sortie vide même si des conventions existent mais hors-sujet', () => {
    // Régression : le bonus de récence laisse passer les conventions au retrieve ;
    // buildRecallBlock doit filtrer sur le contenu et ne RIEN injecter si hors-sujet.
    bank.storeConvention('uuid PK + timestamps sur toutes les tables métier')
    bank.storeConvention('Pas de any TS jamais de secrets dans le code')
    bank.syncSnapshot()
    const block = bank.buildRecallBlock('zzz qqq plugh xyzzy inexistant', { limit: 6 })
    assert.equal(block, '', 'aucune convention ne partage de vocabulaire → bloc vide')
  })

  test('bloc avec uniquement des conventions (pas de section Leçons)', () => {
    bank.storeConvention('jamais de secrets dans le code source')
    bank.syncSnapshot()
    const block = bank.buildRecallBlock('secrets code source', { limit: 6 })
    assert.ok(block.includes('Conventions:'))
    assert.ok(block.includes('secrets'))
  })
})

// ─── A1 — seed-conventions (CLI) ────────────────────────────────────────────────

describe('seed-conventions (A1, CLI)', () => {
  test('parse CLAUDE.md Règles stack + conventions.md et dédup (idempotent)', () => {
    // CLAUDE.md factice dans un cwd dédié
    const proj = join(TMP, 'proj')
    mkdirSync(proj, { recursive: true })
    const claudeMd = [
      '# Projet test',
      '## Routing automatique',
      '- ceci NE doit PAS être pris (mauvaise section)',
      '## Règles stack (défaut)',
      '- uuid PK + timestamps sur les tables métier',
      '- Pas de any TS',
      '- RLS Supabase activé',
      '## Format',
      '- ceci non plus',
    ].join('\n')
    writeFileSync(join(proj, 'CLAUDE.md'), claudeMd)
    writeFileSync(join(TMP, 'conventions.md'), '# Conventions\n- Convention manuelle additionnelle\n- Pas de any TS\n')

    const env = { ...process.env, CLAUDE_CONFIG_DIR: TMP }
    const out1 = execSync(`node "${BANK_JS}" seed-conventions`, { cwd: proj, env, encoding: 'utf8' })
    // 3 (stack) + 1 (manuelle ; "Pas de any TS" dédupliqué) = 4 conventions, toutes ajoutées
    assert.match(out1, /Ajoutées : 4/)

    // Re-run idempotent : 0 ajoutées
    const out2 = execSync(`node "${BANK_JS}" seed-conventions`, { cwd: proj, env, encoding: 'utf8' })
    assert.match(out2, /Ajoutées : 0/)

    // Vérifier qu'on ne capture pas les autres sections
    bank = loadBank()
    const all = bank.retrieve('ceci NE doit PAS', { limit: 10 })
    assert.ok(!all.some(t => t.summary.includes('mauvaise section')), 'sections hors Règles stack ignorées')
  })
})

// ─── A1-auto — extractConventionCandidates (extracteur heuristique pur) ─────────

describe('extractConventionCandidates (A1-auto)', () => {
  test('garde les phrases-règles (marqueurs FR/EN), rejette le bruit', () => {
    const block = [
      'feat(auth): ajoute le login',                                   // pas de marqueur → rejeté
      'Toujours filtrer les requêtes par workspace_id en SaaS',        // marqueur "toujours"
      'Ne jamais committer de secrets dans le code source',            // marqueur "jamais"
      'You must validate input before persistence in the API layer',   // marqueur "must"
      'https://example.com/doc-toujours',                              // URL → rejeté
      'const x = 1; // toujours',                                      // ligne de code → rejeté
      'ok',                                                            // trop court → rejeté
    ].join('\n')
    const out = bank.extractConventionCandidates([block])
    assert.ok(out.some(l => /workspace_id/.test(l)), 'phrase "toujours" gardée')
    assert.ok(out.some(l => /secrets/.test(l)), 'phrase "jamais" gardée')
    assert.ok(out.some(l => /validate input/.test(l)), 'phrase "must" gardée')
    assert.ok(!out.some(l => /example\.com/.test(l)), 'URL rejetée')
    assert.ok(!out.some(l => /const x/.test(l)), 'ligne de code rejetée')
    assert.ok(!out.includes('feat(auth): ajoute le login'), 'sans marqueur rejeté')
  })

  test('déduplique (normalisation casse/accents/ponctuation)', () => {
    const out = bank.extractConventionCandidates([
      'RLS doit etre active sur toutes les tables',
      '  rls  DOIT  être  activé  sur toutes les tables.  ',
    ])
    assert.equal(out.length, 1, 'doublon normalisé fusionné')
  })

  test('filtre longueur (15-300 chars)', () => {
    const long = 'toujours ' + 'x'.repeat(400)
    const out = bank.extractConventionCandidates(['doit y', long])  // "doit y" = trop court
    assert.equal(out.length, 0)
  })
})

// ─── A1-auto — storeCandidate (file séparée + idempotence + isolation injection) ─

describe('storeCandidate (A1-auto)', () => {
  test('stocke un candidat avec phase/agent/verdict/tag corrects', () => {
    const { id, skipped } = bank.storeCandidate('Toujours filtrer par workspace_id en multi-tenant')
    assert.ok(id && id.startsWith('traj-'))
    assert.equal(skipped, false)
    const t = bank.getRecent(50).find(x => x.id === id)
    assert.ok(t, 'candidat persisté')
    assert.equal(t.phase, 'convention-candidate')
    assert.equal(t.agent, 'project')
    assert.equal(t.verdict, 'partial')
    assert.ok(t.tags.includes('convention-candidate'), 'tag candidate présent')
    assert.ok(!t.tags.includes('convention'), 'PAS le tag convention (sinon boosté)')
  })

  test('idempotent vs candidat existant', () => {
    const a = bank.storeCandidate('Ne jamais utiliser any en TypeScript')
    const b = bank.storeCandidate('  ne  JAMAIS  utiliser  any  en  typescript  ')
    assert.equal(a.skipped, false)
    assert.equal(b.skipped, true, 'doublon normalisé skipé')
    assert.equal(b.id, a.id)
  })

  test('idempotent vs convention DÉJÀ promue (ne re-propose pas ce qui est validé)', () => {
    bank.storeConvention('RLS Supabase obligatoire sur toutes les tables')
    const c = bank.storeCandidate('rls supabase obligatoire sur toutes les tables')
    assert.equal(c.skipped, true, 'candidat déjà couvert par une convention active')
  })

  test('texte vide → skipped', () => {
    const { id, skipped } = bank.storeCandidate('   ')
    assert.equal(id, null)
    assert.equal(skipped, true)
  })
})

// ─── A1-auto — PREUVE D'ISOLATION : un candidat n'est PAS injecté ───────────────

describe('isolation injection (A1-auto)', () => {
  test('un candidat n\'apparaît PAS dans recall/buildRecallBlock', () => {
    // Candidat ET convention partagent le même vocabulaire métier.
    bank.storeCandidate('endpoint facture montant workspace doit valider le payload candidate-xyz')
    bank.storeConvention('endpoint facture montant workspace doit filtrer par workspace_id')
    bank.syncSnapshot()

    const block = bank.buildRecallBlock('endpoint facture montant workspace', { limit: 10 })
    assert.ok(block.includes('workspace_id'), 'la convention active est injectée')
    assert.ok(!block.includes('candidate-xyz'), 'le CANDIDAT ne doit JAMAIS être injecté')
  })

  test('un candidat seul ne produit aucun bloc injectable', () => {
    // Aucune convention active, seulement un candidat → recall doit rester vide.
    bank.storeCandidate('toujours paginer les listes au-dela de cinquante elements distinct-token-zzz')
    bank.syncSnapshot()
    const block = bank.buildRecallBlock('paginer listes cinquante elements distinct-token-zzz', { limit: 10 })
    assert.ok(!block.includes('distinct-token-zzz'), 'candidat absent du bloc')
    // tolérant : si d'autres entrées matchent on n'exige pas le vide total,
    // mais le candidat lui-même ne doit pas fuiter.
  })
})

// ─── A1-auto — promote / reject ─────────────────────────────────────────────────

describe('promote / reject (A1-auto)', () => {
  test('promote : candidat → convention active, puis visible dans recall', () => {
    const { id } = bank.storeCandidate('Toujours chiffrer montant facture en centimes entiers convention-promo')
    const shortId = id.replace(/^traj-/, '')
    const env = { ...process.env, CLAUDE_CONFIG_DIR: TMP }
    const out = execSync(`node "${BANK_JS}" conventions promote ${shortId}`, { env, encoding: 'utf8' })
    assert.match(out, /Promu en convention active/)

    bank = loadBank()
    // Le candidat ne doit plus exister
    assert.equal(bank.getRecent(50).find(x => x.id === id), undefined, 'candidat supprimé après promotion')
    // La convention active doit être injectable
    bank.syncSnapshot()
    const block = bank.buildRecallBlock('chiffrer montant facture centimes entiers', { limit: 10 })
    assert.ok(block.includes('centimes entiers'), 'convention promue injectée')
    const promoted = bank.getRecent(50).find(x => x.phase === 'convention' && /centimes entiers/.test(x.summary))
    assert.ok(promoted, 'entrée convention active créée')
    assert.ok(promoted.tags.includes('convention'), 'tag convention présent après promotion')
  })

  test('reject : suppression du candidat', () => {
    const { id } = bank.storeCandidate('Ne jamais logger les tokens en clair convention-reject')
    const shortId = id.replace(/^traj-/, '')
    const env = { ...process.env, CLAUDE_CONFIG_DIR: TMP }
    const out = execSync(`node "${BANK_JS}" conventions reject ${shortId}`, { env, encoding: 'utf8' })
    assert.match(out, /Candidat rejeté/)

    bank = loadBank()
    assert.equal(bank.getRecent(50).find(x => x.id === id), undefined, 'candidat supprimé')
  })
})

// ─── P0-3 — non-fuite des conventions archived au retrieve (RPC bank.retrieve) ──

describe('retrieve n\'expose JAMAIS une convention archived (P0-3)', () => {
  test('retrieve (sync) exclut une convention marquée archived', () => {
    const { id } = bank.storeConvention('endpoint paiement archived-leak doit filtrer par workspace_id')
    bank.syncSnapshot()
    // sanity : récupérable tant qu'active
    let hit = bank.retrieve('endpoint paiement archived-leak workspace', { limit: 10 }).find(x => x.id === id)
    assert.ok(hit, 'la convention active doit être récupérable')

    // supersession → archived (chemin P0-3 réel : updateMetadata archived=true)
    bank._markArchived(id)

    hit = bank.retrieve('endpoint paiement archived-leak workspace', { limit: 10 }).find(x => x.id === id)
    assert.equal(hit, undefined, 'une convention archived NE DOIT PAS fuir via retrieve (RPC bank.retrieve)')
  })

  test('retrieveAsync exclut aussi une convention archived', async () => {
    const { id } = bank.storeConvention('toujours chiffrer archived-async les secrets au repos')
    bank.syncSnapshot()
    bank._markArchived(id)
    const res = await bank.retrieveAsync('chiffrer archived-async secrets repos', { limit: 10 })
    assert.equal(res.find(x => x.id === id), undefined, 'archived ne doit pas fuir via retrieveAsync')
  })

  // Régression du LEAK confirmé par /tmp/repro_archived_leak.js : la convention
  // supersédée (archived, verdict='success') fuyait via smartRetrieve → ACW run.js
  // → prompt agent, car loadAllTrajectories ne filtrait pas archived.
  test('smartRetrieve (chemin ACW agent) n\'injecte PAS une convention supersédée', () => {
    // Supersession réelle : la 2e convention archive la 1re (dédup lexicale, sans Ollama).
    const a = bank.storeConvention('Utiliser snake_case pour les colonnes SQL')
    const b = bank.storeConvention('Utiliser snake_case strictement pour toutes les colonnes SQL')
    assert.equal(b.superseded, a.id, 'la 2e convention doit superséder la 1re (archived)')
    bank.syncSnapshot()

    const sr = bank.smartRetrieve('convention SQL colonnes snake_case', { limit: 8 }) || []
    // Reproduit le filtre exact de run.js:544 (verdict==='success') avant injection prompt.
    const injected = sr.filter(t => t.verdict === 'success').slice(0, 5)
    assert.equal(injected.find(t => t.id === a.id), undefined, 'la convention archived ne doit JAMAIS être injectée dans le prompt agent')
    assert.equal(injected.filter(t => t.archived).length, 0, 'aucune trajectoire archived dans l\'injection ACW')
  })

  test('getRecent (team-sync) ne propage PAS une convention supersédée', () => {
    const a = bank.storeConvention('Indenter avec 2 espaces partout team-sync-leak')
    const b = bank.storeConvention('Indenter strictement avec 2 espaces partout team-sync-leak')
    assert.equal(b.superseded, a.id, 'la 2e convention doit superséder la 1re')
    bank.syncSnapshot()

    const recent = bank.getRecent(100)
    assert.equal(recent.find(t => t.id === a.id), undefined, 'getRecent ne doit pas exposer la convention archived (push team-sync)')
    assert.equal(recent.filter(t => t.archived).length, 0, 'aucune trajectoire archived dans getRecent')
  })
})

// ─── P1-2 — bank.health() : forme observable ────────────────────────────────────

describe('bank.health() (P1-2)', () => {
  test('retourne ollama:boolean + lastRecallDegraded (forme contrat)', async () => {
    const h = await bank.health()
    assert.equal(typeof h.ollama, 'boolean', 'ollama est un booléen (sonde réelle)')
    assert.ok('lastRecallDegraded' in h, 'expose lastRecallDegraded (ts|null)')
    assert.ok('trajectories' in h && 'coverage' in h, 'expose coverage embeddings')
  })
})

// ─── A1-auto — candidates (liste CLI) ───────────────────────────────────────────

describe('conventions candidates (A1-auto, CLI)', () => {
  test('liste les candidats en attente', () => {
    bank.storeCandidate('Toujours valider les entrées utilisateur avant persistence listing-test')
    bank.syncSnapshot()
    const env = { ...process.env, CLAUDE_CONFIG_DIR: TMP }
    const out = execSync(`node "${BANK_JS}" conventions candidates`, { env, encoding: 'utf8' })
    assert.match(out, /Candidats de convention en attente/)
    assert.match(out, /listing-test/)
  })
})
