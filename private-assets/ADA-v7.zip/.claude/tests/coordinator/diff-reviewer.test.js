#!/usr/bin/env node
'use strict'
/**
 * tests/coordinator/diff-reviewer.test.js
 *
 * Tests unitaires pour .claude/coordinator/diff-reviewer.js
 *
 * Vérifie :
 *  - filtrage par agent === 'reviewer' sur les trajectoires bank
 *  - format de injectedContext (max 300 tokens, sections attendues)
 *  - dégradation gracieuse si bank indisponible ou vide
 *  - timeout → retourne un contexte vide
 */

const { test, describe, before, after } = require('node:test')
const assert = require('node:assert/strict')
const { join } = require('path')
const { mkdirSync, rmSync, existsSync, writeFileSync } = require('fs')

const TMP = join(__dirname, '../../..', '.test-tmp-diff-reviewer')
const DIFF_REVIEWER_FILE = join(__dirname, '../../coordinator/diff-reviewer.js')

// ── Helpers ───────────────────────────────────────────────────────────────────

/**
 * Charge diff-reviewer avec CLAUDE_CONFIG_DIR pointant sur TMP
 * et bank.js remplacé par un mock.
 * @param {Array|null} mockTrajectories - null = bank absent
 * @param {{ timeout?: boolean }} opts
 * @returns {object} module diff-reviewer
 */
function loadWithMock(mockTrajectories, opts = {}) {
  // Vider le cache pour permettre de re-charger avec un mock différent
  Object.keys(require.cache).forEach(k => {
    if (k.includes('diff-reviewer') || k.includes('bank.js')) delete require.cache[k]
  })

  process.env.CLAUDE_CONFIG_DIR = TMP

  if (mockTrajectories !== null) {
    // Créer un faux bank.js dans le répertoire coordinator TMP
    const bankPath = join(TMP, 'coordinator', 'bank.js')
    mkdirSync(join(TMP, 'coordinator'), { recursive: true })

    const trajectoryJson = JSON.stringify(mockTrajectories)
    const delay = opts.timeout ? 5000 : 0  // simuler un timeout si requis

    writeFileSync(bankPath, `
'use strict'
module.exports = {
  retrieve(query, opts) {
    return ${trajectoryJson}
  },
  async retrieveAsync(query, opts) {
    if (${delay} > 0) {
      await new Promise(r => setTimeout(r, ${delay}))
    }
    return ${trajectoryJson}
  }
}
`, 'utf8')
  } else {
    // Bank absent → supprimer le fichier si existant
    const bankPath = join(TMP, 'coordinator', 'bank.js')
    if (existsSync(bankPath)) rmSync(bankPath)
  }

  return require(DIFF_REVIEWER_FILE)
}

// ── Setup / Teardown ──────────────────────────────────────────────────────────

before(() => {
  mkdirSync(join(TMP, 'coordinator'), { recursive: true })
})

after(() => {
  try { rmSync(TMP, { recursive: true }) } catch {}
  // Nettoyer le cache après les tests
  Object.keys(require.cache).forEach(k => {
    if (k.includes('diff-reviewer') || k.includes(TMP)) delete require.cache[k]
  })
})

// ── Tests ─────────────────────────────────────────────────────────────────────

describe('getReviewContext — filtrage par agent reviewer', () => {

  test('retourne vide si aucune trajectoire reviewer parmi les résultats', async () => {
    const mod = loadWithMock([
      { id: 't1', agent: 'nestjs',  phase: 'backend', verdict: 'success', summary: 'Module auth implémenté' },
      { id: 't2', agent: 'nextjs',  phase: 'frontend', verdict: 'success', summary: 'Page login créée' },
      { id: 't3', agent: 'db',      phase: 'db',       verdict: 'success', summary: 'Migration users ajoutée' },
    ])

    const result = await mod.getReviewContext('auth module diff stat')

    assert.equal(result.patterns.length, 0, 'patterns devrait être vide sans trajectoires reviewer')
    assert.equal(result.warnings.length, 0, 'warnings devrait être vide')
    assert.equal(result.injectedContext, '', 'injectedContext devrait être vide')
  })

  test('filtre et retourne le contexte pour les trajectoires agent=reviewer', async () => {
    const mod = loadWithMock([
      { id: 't1', agent: 'nestjs',   phase: 'backend', verdict: 'success',  summary: 'JWT implémenté' },
      { id: 't2', agent: 'reviewer', phase: 'review',  verdict: 'success',  summary: 'Missing input validation on /api/users endpoint' },
      { id: 't3', agent: 'reviewer', phase: 'review',  verdict: 'failure',  summary: 'No rate limiting found on auth routes — flagged as critical' },
    ])

    const result = await mod.getReviewContext('git diff --stat HEAD: api/users.ts +45 -12')

    // Il doit y avoir des patterns ou warnings extraits des trajectoires reviewer
    assert.ok(
      result.patterns.length > 0 || result.warnings.length > 0,
      'doit extraire des patterns/warnings des trajectoires reviewer'
    )
    assert.notEqual(result.injectedContext, '', 'injectedContext ne doit pas être vide')
  })

  test('filtre par phase=review (pas uniquement agent=reviewer)', async () => {
    const mod = loadWithMock([
      { id: 't1', agent: 'code-review', phase: 'review', verdict: 'success', summary: 'SQL injection risk in rawQuery usage' },
    ])

    const result = await mod.getReviewContext('database migration diff')

    assert.ok(
      result.patterns.length > 0 || result.warnings.length > 0,
      'doit accepter phase=review même sans agent=reviewer'
    )
    assert.notEqual(result.injectedContext, '', 'injectedContext ne doit pas être vide')
  })

})

describe('getReviewContext — format injectedContext', () => {

  test('injectedContext commence par le header ADA memory', async () => {
    const mod = loadWithMock([
      { id: 't1', agent: 'reviewer', phase: 'review', verdict: 'success',
        summary: 'Always check for missing error boundaries in React components. Use try/catch around async calls.' },
    ])

    const result = await mod.getReviewContext('React component diff')

    assert.ok(
      result.injectedContext.startsWith('# Review patterns from similar past diffs (ADA memory)'),
      'doit commencer par le header'
    )
  })

  test('injectedContext ne dépasse pas 1200 caractères (~300 tokens)', async () => {
    // Générer beaucoup de trajectoires reviewer avec des summaries longs
    const longTrajs = Array.from({ length: 10 }, (_, i) => ({
      id: `t${i}`,
      agent: 'reviewer',
      phase: 'review',
      verdict: i % 2 === 0 ? 'success' : 'failure',
      summary: `Pattern ${i}: ` + 'x'.repeat(300),
    }))

    const mod = loadWithMock(longTrajs)
    const result = await mod.getReviewContext('large diff with many files')

    assert.ok(
      result.injectedContext.length <= 1200,
      `injectedContext doit être ≤1200 chars, got ${result.injectedContext.length}`
    )
  })

  test('injectedContext contient les sections attendues si données disponibles', async () => {
    const mod = loadWithMock([
      {
        id: 't1', agent: 'reviewer', phase: 'review', verdict: 'success',
        summary: 'Always validate JWT expiry. Use short-lived tokens for sensitive endpoints.',
      },
      {
        id: 't2', agent: 'reviewer', phase: 'review', verdict: 'failure',
        summary: 'Missing CORS headers flagged. No rate limiting on public routes.',
      },
    ])

    const result = await mod.getReviewContext('auth middleware changes')

    assert.ok(result.injectedContext.includes('# Review patterns'), 'doit contenir # Review patterns')
    assert.ok(result.injectedContext.includes('# What was flagged'), 'doit contenir # What was flagged')
  })

  test('retourne un objet bien formé même si injectedContext est vide', async () => {
    const mod = loadWithMock([])

    const result = await mod.getReviewContext('empty diff')

    assert.ok('patterns' in result, 'doit avoir la clé patterns')
    assert.ok('warnings' in result, 'doit avoir la clé warnings')
    assert.ok('injectedContext' in result, 'doit avoir la clé injectedContext')
    assert.ok(Array.isArray(result.patterns), 'patterns doit être un tableau')
    assert.ok(Array.isArray(result.warnings), 'warnings doit être un tableau')
    assert.equal(typeof result.injectedContext, 'string', 'injectedContext doit être une string')
  })

})

describe('getReviewContext — dégradation gracieuse', () => {

  test('retourne vide si bank est absent', async () => {
    const mod = loadWithMock(null)  // bank.js absent

    const result = await mod.getReviewContext('some diff summary')

    assert.deepEqual(result, { patterns: [], warnings: [], injectedContext: '' })
  })

  test('retourne vide si diffSummary est falsy', async () => {
    const mod = loadWithMock([
      { id: 't1', agent: 'reviewer', phase: 'review', verdict: 'success', summary: 'Test summary' },
    ])

    const result1 = await mod.getReviewContext('')
    const result2 = await mod.getReviewContext(null)

    assert.deepEqual(result1, { patterns: [], warnings: [], injectedContext: '' })
    assert.deepEqual(result2, { patterns: [], warnings: [], injectedContext: '' })
  })

  test('retourne vide si bank lance une erreur', async () => {
    Object.keys(require.cache).forEach(k => {
      if (k.includes('diff-reviewer') || k.includes(TMP)) delete require.cache[k]
    })
    process.env.CLAUDE_CONFIG_DIR = TMP

    // Écrire un bank.js qui lève une erreur
    const bankPath = join(TMP, 'coordinator', 'bank.js')
    writeFileSync(bankPath, `
'use strict'
module.exports = {
  retrieve() { throw new Error('bank unavailable') },
  async retrieveAsync() { throw new Error('bank unavailable') },
}
`, 'utf8')

    const mod = require(DIFF_REVIEWER_FILE)
    const result = await mod.getReviewContext('diff summary')

    assert.deepEqual(result, { patterns: [], warnings: [], injectedContext: '' })
  })

})
