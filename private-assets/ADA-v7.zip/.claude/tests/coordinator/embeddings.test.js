#!/usr/bin/env node
'use strict'
const { test, describe } = require('node:test')
const assert = require('node:assert/strict')
const { join } = require('path')

const EMBEDDINGS_JS = join(__dirname, '../../coordinator/embeddings.js')
const { tokenize, buildIDF, cosineSimilarity, buildIndex, embed, HNSW, recencyBoost, reciprocalRankFusion } = require(EMBEDDINGS_JS)

// ── tokenize ──────────────────────────────────────────────────────────────────

describe('tokenize', () => {
  test('met en minuscule et supprime les stop words anglais', () => {
    const tokens = tokenize('The authentication service is working')
    assert.ok(!tokens.includes('the'))
    assert.ok(!tokens.includes('is'))
    // Le stemming réduit 'authentication' → 'authentica' — on vérifie la racine
    assert.ok(tokens.some(t => t.startsWith('authent')), `tokens: ${tokens}`)
    assert.ok(tokens.some(t => t.startsWith('serv')), `tokens: ${tokens}`)
  })

  test('filtre les tokens trop courts (< 3 chars)', () => {
    const tokens = tokenize('a ab abc abcd')
    assert.ok(!tokens.includes('a'))
    assert.ok(!tokens.includes('ab'))
    // 'abc' peut passer ou non selon le stemming, mais doit avoir au moins 'abcd'
    assert.ok(tokens.some(t => t.length >= 3))
  })

  test('tokenise du texte français', () => {
    const tokens = tokenize('Migration de la base de données PostgreSQL avec les policies RLS')
    assert.ok(!tokens.includes('de'))
    assert.ok(!tokens.includes('la'))
    assert.ok(!tokens.includes('les'))
    // Le stemming réduit 'migration' → 'migra' — on vérifie la racine
    assert.ok(tokens.some(t => t.startsWith('migr')), `tokens: ${tokens}`)
    assert.ok(tokens.some(t => t.toLowerCase().startsWith('postgr') || t.toLowerCase() === 'postgresql'), `tokens: ${tokens}`)
  })

  test('retourne un tableau vide pour une chaîne vide', () => {
    assert.deepEqual(tokenize(''), [])
  })

  test('retourne un tableau vide si tous les tokens sont des stop words', () => {
    const tokens = tokenize('le la les un de du des')
    assert.equal(tokens.length, 0)
  })
})

// ── buildIDF ──────────────────────────────────────────────────────────────────

describe('buildIDF', () => {
  test('IDF plus élevé pour les termes rares', () => {
    const docs = [
      ['jwt', 'authentication', 'guards'],
      ['stripe', 'payment', 'webhook'],
      ['migration', 'database', 'postgresql'],
    ]
    const idf = buildIDF(docs)
    // 'jwt' apparaît dans 1 doc / 3 → IDF élevé
    // 'authentication' apparaît dans 1 doc / 3 → IDF élevé
    assert.ok(idf.get('jwt') > 0)
    assert.ok(idf.get('stripe') > 0)
  })

  test('IDF plus bas pour les termes fréquents', () => {
    const docs = [
      ['nestjs', 'guards', 'common'],
      ['nestjs', 'service', 'common'],
      ['nestjs', 'module', 'common'],
    ]
    const idf = buildIDF(docs)
    // 'nestjs' et 'common' apparaissent dans tous les docs → IDF bas
    // 'guards' n'apparaît que dans 1 → IDF plus élevé
    const idfNestjs = idf.get('nestjs')
    const idfGuards = idf.get('guards')
    assert.ok(idfGuards > idfNestjs, `IDF guards(${idfGuards}) devrait être > nestjs(${idfNestjs})`)
  })

  test('retourne une Map vide pour un corpus vide', () => {
    const idf = buildIDF([])
    assert.equal(idf.size, 0)
  })

  test('tous les termes ont un IDF positif', () => {
    const docs = [['hello', 'world'], ['hello', 'foo']]
    const idf = buildIDF(docs)
    for (const [, v] of idf) {
      assert.ok(v > 0, `IDF devrait être > 0, obtenu: ${v}`)
    }
  })
})

// ── cosineSimilarity ──────────────────────────────────────────────────────────

describe('cosineSimilarity', () => {
  test('retourne 1.0 pour des vecteurs identiques', () => {
    const v = new Map([['jwt', 0.5], ['auth', 0.8], ['guards', 0.3]])
    const sim = cosineSimilarity(v, v)
    assert.ok(Math.abs(sim - 1.0) < 1e-9, `Attendu ~1.0, obtenu ${sim}`)
  })

  test('retourne 0.0 pour des vecteurs orthogonaux', () => {
    const a = new Map([['jwt', 1.0], ['auth', 1.0]])
    const b = new Map([['stripe', 1.0], ['payment', 1.0]])
    const sim = cosineSimilarity(a, b)
    assert.equal(sim, 0)
  })

  test('retourne 0.0 si le vecteur a est vide', () => {
    const a = new Map()
    const b = new Map([['jwt', 1.0]])
    assert.equal(cosineSimilarity(a, b), 0)
  })

  test('retourne 0.0 si le vecteur b est vide', () => {
    const a = new Map([['jwt', 1.0]])
    const b = new Map()
    assert.equal(cosineSimilarity(a, b), 0)
  })

  test('similarité entre 0 et 1 pour des vecteurs partiellement communs', () => {
    const a = new Map([['jwt', 1.0], ['auth', 0.5]])
    const b = new Map([['jwt', 0.8], ['stripe', 0.6]])
    const sim = cosineSimilarity(a, b)
    assert.ok(sim > 0 && sim < 1, `Attendu entre 0 et 1, obtenu ${sim}`)
  })
})

// ── buildIndex ────────────────────────────────────────────────────────────────

describe('buildIndex', () => {
  test('search retourne [] si corpus vide', () => {
    const { search } = buildIndex([])
    assert.deepEqual(search('authentication'), [])
  })

  test('search retourne [] si aucune correspondance', () => {
    const { search } = buildIndex([
      { id: 'doc1', text: 'JWT authentication guards nestjs' },
    ])
    const results = search('xyzqrwlmn obscur')
    assert.deepEqual(results, [])
  })

  test('search trouve le document le plus similaire', () => {
    const { search } = buildIndex([
      { id: 'doc-jwt',     text: 'JWT authentication guards nestjs validation' },
      { id: 'doc-stripe',  text: 'Stripe payment webhook idempotency retry' },
      { id: 'doc-migrate', text: 'PostgreSQL migration RLS policies database' },
    ])
    const results = search('jwt authentication')
    assert.ok(results.length > 0)
    assert.equal(results[0].id, 'doc-jwt')
    assert.ok(results[0].score > 0)
  })

  test('search retourne au max topK résultats', () => {
    const docs = Array.from({ length: 20 }, (_, i) => ({
      id: `doc-${i}`,
      text: `authentication service nestjs guards module ${i}`
    }))
    const { search } = buildIndex(docs)
    const results = search('authentication', 5)
    assert.ok(results.length <= 5, `Attendu ≤5, obtenu ${results.length}`)
  })

  test('score plus élevé pour un match exact de terme rare', () => {
    const { search } = buildIndex([
      { id: 'exact',   text: 'idempotency stripe webhook payment retry logic' },
      { id: 'partial', text: 'stripe payment service integration gateway' },
    ])
    const results = search('idempotency')
    assert.ok(results.length > 0)
    assert.equal(results[0].id, 'exact', 'Le document avec le terme exact devrait être en premier')
  })

  test('résultats triés par score décroissant', () => {
    const { search } = buildIndex([
      { id: 'd1', text: 'authentication jwt token guards nestjs service module' },
      { id: 'd2', text: 'authentication jwt' },
      { id: 'd3', text: 'stripe payment unrelated content here' },
    ])
    const results = search('authentication jwt guards nestjs')
    if (results.length >= 2) {
      assert.ok(results[0].score >= results[1].score, 'Résultats doivent être triés par score décroissant')
    }
  })
})

// ── embed ─────────────────────────────────────────────────────────────────────

describe('embed', () => {
  test('retourne tokens et vector non vides pour un texte valide', () => {
    const { tokens, vector } = embed('JWT authentication guards nestjs validation')
    assert.ok(tokens.length > 0, 'tokens ne doit pas être vide')
    assert.ok(Object.keys(vector).length > 0, 'vector ne doit pas être vide')
  })

  test('retourne tokens vides pour un texte vide', () => {
    const { tokens, vector } = embed('')
    assert.deepEqual(tokens, [])
    assert.deepEqual(vector, {})
  })

  test('les valeurs du vector sont des nombres positifs', () => {
    const { vector } = embed('authentication guards nestjs service')
    for (const [term, score] of Object.entries(vector)) {
      assert.ok(typeof score === 'number', `score de "${term}" doit être un nombre`)
      assert.ok(score > 0, `score de "${term}" doit être positif`)
    }
  })

  test('utilise l IDF fourni si disponible', () => {
    const idf = new Map([['authentication', 2.5], ['guards', 1.8]])
    const { vector } = embed('authentication guards nestjs', idf)
    // Les termes avec IDF élevé doivent avoir un score plus élevé (toutes choses égales)
    assert.ok(Object.keys(vector).length > 0)
  })

  test('retourne un vector avec uniquement des entrées pour les tokens filtrés', () => {
    const { tokens, vector } = embed('le la les un authentication')
    // Les stop words ne doivent pas apparaître dans le vecteur
    assert.ok(!('le' in vector))
    assert.ok(!('la' in vector))
    assert.ok(!('les' in vector))
    // Les tokens filtrés doivent correspondre aux clés du vecteur
    for (const key of Object.keys(vector)) {
      assert.ok(tokens.includes(key) || tokens.some(t => t === key),
        `Clé "${key}" du vecteur doit correspondre à un token`)
    }
  })
})

// ── HNSW ──────────────────────────────────────────────────────────────────────

describe('HNSW', () => {
  /** Vecteur dense simple à n dimensions pour les tests */
  function vec(...values) { return values }

  test('insert + search retourne le voisin le plus proche', () => {
    const hnsw = new HNSW(4, 20)
    // Vecteurs dans un espace 3D : on cherche le plus proche de [1,0,0]
    hnsw.insert('a', vec(1, 0, 0))    // identique à la query
    hnsw.insert('b', vec(0, 1, 0))    // orthogonal
    hnsw.insert('c', vec(0, 0, 1))    // orthogonal
    hnsw.insert('d', vec(0.9, 0.1, 0)) // très proche de a

    const results = hnsw.search(vec(1, 0, 0), 1)
    assert.ok(results.length >= 1, 'Doit retourner au moins 1 résultat')
    assert.equal(results[0].id, 'a', `Voisin le plus proche attendu 'a', obtenu '${results[0].id}'`)
    assert.ok(results[0].dist < 1e-9, `Distance attendue ~0, obtenue ${results[0].dist}`)
    assert.ok(results[0].similarity > 0.99, `Similarité attendue ~1, obtenue ${results[0].similarity}`)
  })

  test('search sur graphe vide retourne []', () => {
    const hnsw = new HNSW()
    const results = hnsw.search(vec(1, 0, 0))
    assert.deepEqual(results, [])
  })

  test('serialize/deserialize préserve les résultats de search', () => {
    const hnsw = new HNSW(4, 20)
    hnsw.insert('x', vec(1, 0, 0))
    hnsw.insert('y', vec(0, 1, 0))
    hnsw.insert('z', vec(0.5, 0.5, 0))

    const data = hnsw.serialize()
    const hnsw2 = HNSW.deserialize(data)

    const r1 = hnsw.search(vec(1, 0, 0), 1)
    const r2 = hnsw2.search(vec(1, 0, 0), 1)

    assert.ok(r1.length > 0, 'Original doit retourner des résultats')
    assert.ok(r2.length > 0, 'Désérialisé doit retourner des résultats')
    assert.equal(r1[0].id, r2[0].id, `IDs doivent correspondre: ${r1[0].id} vs ${r2[0].id}`)
    assert.ok(Math.abs(r1[0].dist - r2[0].dist) < 1e-9, 'Distances doivent être identiques')
  })

  test('search avec k > nodes.size retourne tous les nœuds', () => {
    const hnsw = new HNSW(4, 20)
    hnsw.insert('p1', vec(1, 0))
    hnsw.insert('p2', vec(0, 1))
    hnsw.insert('p3', vec(1, 1))

    const results = hnsw.search(vec(0.5, 0.5), 100)
    assert.equal(results.length, 3, `Attendu 3 résultats, obtenu ${results.length}`)
    const ids = new Set(results.map(r => r.id))
    assert.ok(ids.has('p1') && ids.has('p2') && ids.has('p3'), 'Tous les nœuds doivent être retournés')
  })

  test('insert 100 nœuds → search correct (smoke test)', () => {
    const hnsw = new HNSW(8, 50)
    const DIM = 8
    const nodes = []

    // Générer 100 vecteurs aléatoires déterministes
    for (let i = 0; i < 100; i++) {
      const v = Array.from({ length: DIM }, (_, d) => Math.sin(i * 0.3 + d * 0.7))
      nodes.push({ id: `node-${i}`, v })
      hnsw.insert(`node-${i}`, v)
    }

    assert.equal(hnsw.size, 100, `Attendu 100 nœuds, obtenu ${hnsw.size}`)

    // La query est identique au vecteur du nœud 42 → doit le retrouver en top-3
    const query = nodes[42].v
    const results = hnsw.search(query, 3)

    assert.ok(results.length >= 1, 'Doit retourner au moins 1 résultat')
    assert.ok(
      results.some(r => r.id === 'node-42'),
      `node-42 doit apparaître dans les top-3 résultats. Obtenus: ${results.map(r => r.id).join(', ')}`
    )
    assert.ok(results[0].similarity >= 0, 'Similarité doit être >= 0')
    // Résultats triés par distance croissante
    for (let i = 1; i < results.length; i++) {
      assert.ok(results[i].dist >= results[i - 1].dist, 'Résultats doivent être triés par distance croissante')
    }
  })
})

// ── recencyBoost ──────────────────────────────────────────────────────────────

describe('embeddings — recencyBoost', () => {
  test('retourne ~1.0 pour une date d\'aujourd\'hui (±0.01)', () => {
    const now = new Date().toISOString()
    const boost = recencyBoost(now)
    assert.ok(Math.abs(boost - 1.0) < 0.01, `Attendu ~1.0, obtenu ${boost}`)
  })

  test('retourne ~0.5 pour une date il y a 30 jours (halfLife=30)', () => {
    const ts = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString()
    const boost = recencyBoost(ts, 30)
    assert.ok(Math.abs(boost - 0.5) < 0.02, `Attendu ~0.5, obtenu ${boost}`)
  })

  test('retourne ~0.25 pour 60 jours (deux demi-vies)', () => {
    const ts = new Date(Date.now() - 60 * 24 * 60 * 60 * 1000).toISOString()
    const boost = recencyBoost(ts, 30)
    assert.ok(Math.abs(boost - 0.25) < 0.02, `Attendu ~0.25, obtenu ${boost}`)
  })

  test('retourne une valeur > 0 pour une date très ancienne (jamais zéro)', () => {
    const ts = new Date(Date.now() - 3650 * 24 * 60 * 60 * 1000).toISOString()  // ~10 ans
    const boost = recencyBoost(ts, 30)
    assert.ok(boost > 0, `Boost doit être > 0 même pour une date très ancienne, obtenu ${boost}`)
  })
})

// ── reciprocalRankFusion avec recency ─────────────────────────────────────────

describe('embeddings — reciprocalRankFusion avec recency', () => {
  test('sans opts.recency → comportement identique à avant', () => {
    const list1 = [{ id: 'a', score: 1 }, { id: 'b', score: 0.5 }]
    const list2 = [{ id: 'b', score: 1 }, { id: 'a', score: 0.3 }]

    const withoutOpts = reciprocalRankFusion([list1, list2])
    const withOptsDefault = reciprocalRankFusion([list1, list2], 60, {})

    assert.equal(withoutOpts.length, withOptsDefault.length)
    for (let i = 0; i < withoutOpts.length; i++) {
      assert.equal(withoutOpts[i].id, withOptsDefault[i].id)
      assert.ok(Math.abs(withoutOpts[i].rrfScore - withOptsDefault[i].rrfScore) < 1e-10)
    }
  })

  test('avec opts.recency=true et tsMap → scores modifiés pour les entrées récentes', () => {
    const nowTs = new Date().toISOString()
    const oldTs = new Date(Date.now() - 365 * 24 * 60 * 60 * 1000).toISOString()

    const list = [{ id: 'recent', score: 1 }, { id: 'old', score: 0.9 }]
    const tsMap = new Map([['recent', nowTs], ['old', oldTs]])

    const withoutRecency = reciprocalRankFusion([list], 60, {})
    const withRecency = reciprocalRankFusion([list], 60, { recency: true, tsMap })

    // 'recent' doit avoir un score plus élevé avec recency qu'une entrée ancienne
    const recentWithout = withoutRecency.find(r => r.id === 'recent').rrfScore
    const recentWith    = withRecency.find(r => r.id === 'recent').rrfScore
    const oldWith       = withRecency.find(r => r.id === 'old').rrfScore

    assert.ok(recentWith > recentWithout, `Score recency (${recentWith}) doit être > sans recency (${recentWithout})`)
    assert.ok(recentWith > oldWith, `Entrée récente (${recentWith}) doit scorer plus haut que ancienne (${oldWith})`)
  })

  test('entrée récente rankée après une ancienne peut monter avec recency', () => {
    const nowTs = new Date().toISOString()
    const oldTs = new Date(Date.now() - 180 * 24 * 60 * 60 * 1000).toISOString()

    // 'old' est rank 0 (meilleur), 'recent' est rank 1
    const list = [{ id: 'old', score: 1 }, { id: 'recent', score: 0.8 }]
    const tsMap = new Map([['old', oldTs], ['recent', nowTs]])

    const fused = reciprocalRankFusion([list], 60, { recency: true, tsMap })

    const recentEntry = fused.find(r => r.id === 'recent')
    const oldEntry    = fused.find(r => r.id === 'old')

    assert.ok(recentEntry, 'recent doit être dans les résultats')
    assert.ok(oldEntry, 'old doit être dans les résultats')
    // Avec un recency boost significatif (180j/30j = 6 demi-vies → boost ~1.5%), l'ancienne reste devant,
    // mais la récente doit avoir un boost relatif mesurable vs le cas sans recency
    const fusedNoRecency = reciprocalRankFusion([list], 60, {})
    const recentNoRecency = fusedNoRecency.find(r => r.id === 'recent').rrfScore
    assert.ok(recentEntry.rrfScore > recentNoRecency, `Score de 'recent' doit augmenter avec recency`)
  })
})
