#!/usr/bin/env node
'use strict'
/**
 * tests/coordinator/engine-cli.test.js
 *
 * `ada engine status|enable|disable|mode` — pilotage de `.ada/engines.yaml`
 * (P5/P6, routage moteurs claude_code/codex, ada-api-nest/src/config/
 * engines.{schema,config}.ts + orchestration/engine-router.service.ts).
 * Distinct de `ada provider` (cfg.providerMode dans ~/.ada.json — bascule
 * d'auth d'un `claude` interactif direct — jamais touché ici).
 *
 * Décision de conception (voir commentaire en tête du bloc "ada engine" dans
 * bin/ada.js) : mutation YAML par édition regex ciblée (OPTION B — pas
 * js-yaml, absent des dépendances de production de .claude/package.json) —
 * un remplacement de ligne scopé au bloc `engines.<id>:`, qui préserve tout
 * le reste du fichier (autre moteur, routing, api_budget, commentaires) tel
 * quel, et refuse (throw) toute mutation sur un bloc/champ non reconnu.
 *
 * Ces tests couvrent la logique PURE exportée par bin/ada.js (parsing/
 * mutation de texte YAML, résolution de racine de dépôt) : zéro
 * process.exit, zéro écriture disque réelle (setEngineYamlField retourne un
 * nouveau texte, n'écrit jamais sur disque) — donc pas besoin de dossier
 * temporaire. Le gabarit réel `.ada/engines.yaml.example` du dépôt sert de
 * fixture (c'est la forme exacte que les commandes manipulent en pratique).
 */
const { test, describe } = require('node:test')
const assert = require('node:assert/strict')
const { readFileSync } = require('node:fs')
const { join } = require('node:path')

const {
  ENGINE_YAML_IDS,
  ENGINE_USAGE_MODES,
  findEngineYamlBlock,
  parseEngineYamlStatus,
  parseEnginesYamlStatus,
  setEngineYamlField,
  pickRepoRootForEngines,
} = require('../../bin/ada.js')

const EXAMPLE_PATH = join(__dirname, '..', '..', '..', '.ada', 'engines.yaml.example')
const EXAMPLE_YAML = readFileSync(EXAMPLE_PATH, 'utf8')

describe('ENGINE_YAML_IDS / ENGINE_USAGE_MODES — constantes', () => {
  test('liste exactement claude_code et codex', () => {
    assert.deepEqual(ENGINE_YAML_IDS, ['claude_code', 'codex'])
  })
  test('liste exactement subscription et api', () => {
    assert.deepEqual(ENGINE_USAGE_MODES, ['subscription', 'api'])
  })
})

describe('findEngineYamlBlock — bornes du bloc engines.<id> (sur le gabarit réel du dépôt)', () => {
  test('claude_code : ne déborde pas sur le bloc codex', () => {
    const block = findEngineYamlBlock(EXAMPLE_YAML, 'claude_code')
    assert.ok(block)
    const body = block.lines.slice(block.start, block.end).join('\n')
    assert.match(body, /claude_code:/)
    assert.doesNotMatch(body, /codex:/)
    assert.doesNotMatch(body, /auth_profile_ref: codex-local/)
  })

  test('codex : ne déborde pas sur routing:', () => {
    const block = findEngineYamlBlock(EXAMPLE_YAML, 'codex')
    assert.ok(block)
    const body = block.lines.slice(block.start, block.end).join('\n')
    assert.match(body, /codex:/)
    assert.doesNotMatch(body, /routing:/)
    assert.doesNotMatch(body, /allow_enabled_engine_fallback/)
  })

  test('moteur inconnu → null', () => {
    assert.equal(findEngineYamlBlock(EXAMPLE_YAML, 'gpt5'), null)
  })
})

describe('parseEngineYamlStatus / parseEnginesYamlStatus', () => {
  test('lit enabled + usage_mode pour claude_code depuis le gabarit', () => {
    assert.deepEqual(parseEngineYamlStatus(EXAMPLE_YAML, 'claude_code'), { enabled: true, usage_mode: 'subscription' })
  })

  test('lit enabled + usage_mode pour codex depuis le gabarit', () => {
    assert.deepEqual(parseEngineYamlStatus(EXAMPLE_YAML, 'codex'), { enabled: true, usage_mode: 'subscription' })
  })

  test('parseEnginesYamlStatus couvre les deux moteurs en une passe', () => {
    const status = parseEnginesYamlStatus(EXAMPLE_YAML)
    assert.deepEqual(Object.keys(status).sort(), ['claude_code', 'codex'])
    assert.equal(status.claude_code.enabled, true)
    assert.equal(status.codex.enabled, true)
  })

  test('bloc absent → null (jamais une valeur par défaut inventée)', () => {
    assert.equal(parseEngineYamlStatus('version: 1\n', 'claude_code'), null)
  })

  test('champ manquant dans le bloc → null', () => {
    const truncated = 'engines:\n  claude_code:\n    enabled: true\n'
    assert.equal(parseEngineYamlStatus(truncated, 'claude_code'), null)
  })
})

describe('setEngineYamlField — mutation ciblée, préservation du reste', () => {
  test('claude_code.enabled: true → false ; codex et commentaires intacts ; une seule ligne modifiée', () => {
    const mutated = setEngineYamlField(EXAMPLE_YAML, 'claude_code', 'enabled', 'false')
    assert.deepEqual(parseEngineYamlStatus(mutated, 'claude_code'), { enabled: false, usage_mode: 'subscription' })
    assert.deepEqual(parseEngineYamlStatus(mutated, 'codex'), { enabled: true, usage_mode: 'subscription' })
    assert.match(mutated, /Omettre auth_profile_ref/)
    assert.match(mutated, /Le mode API est validable par le schéma/)

    const before = EXAMPLE_YAML.split('\n')
    const after = mutated.split('\n')
    assert.equal(before.length, after.length)
    const diffLines = before.filter((l, i) => l !== after[i])
    assert.deepEqual(diffLines, ['    enabled: true'])
  })

  test('codex.usage_mode: subscription → api ; claude_code intact', () => {
    const mutated = setEngineYamlField(EXAMPLE_YAML, 'codex', 'usage_mode', 'api')
    assert.deepEqual(parseEngineYamlStatus(mutated, 'codex'), { enabled: true, usage_mode: 'api' })
    assert.deepEqual(parseEngineYamlStatus(mutated, 'claude_code'), { enabled: true, usage_mode: 'subscription' })
  })

  test('moteur inconnu → throw explicite, jamais un texte tronqué', () => {
    assert.throws(() => setEngineYamlField(EXAMPLE_YAML, 'gpt5', 'enabled', 'false'), /introuvable/)
  })

  test('champ inconnu sous un bloc valide → throw explicite', () => {
    assert.throws(() => setEngineYamlField(EXAMPLE_YAML, 'claude_code', 'nope_field', 'x'), /introuvable/)
  })
})

describe('pickRepoRootForEngines — résolution de racine de dépôt (même principe que cmdInstall)', () => {
  test('retourne le premier candidat où exists(<candidat>/.ada) est vrai', () => {
    const exists = (p) => p === '/repo/b/.ada'
    const root = pickRepoRootForEngines(['/repo/a', '/repo/b', '/repo/c'], exists)
    assert.equal(root, '/repo/b')
  })

  test('aucun candidat valide → retombe sur le premier (comportement historique cmdInstall)', () => {
    const root = pickRepoRootForEngines(['/repo/a', '/repo/b'], () => false)
    assert.equal(root, '/repo/a')
  })
})
