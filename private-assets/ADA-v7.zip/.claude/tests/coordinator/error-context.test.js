#!/usr/bin/env node
'use strict'
/**
 * tests/coordinator/error-context.test.js
 *
 * Suite RED : ces tests échouent TANT QUE coordinator/error-context.js
 * n'existe pas ou ne respecte pas le contrat ci-dessous.
 *
 * Contrat testé :
 *   parseErrors(rawOutput)               → ParsedError[]
 *   formatForPrompt(errors, iter, max)   → string
 *   buildRetryContext(phaseState, iter)  → RetryContext
 */

const { describe, it } = require('node:test')
const assert = require('node:assert/strict')
const { join } = require('node:path')

// ── Le module n'existe pas encore → RED immédiat si le require échoue ────────
const EC = require(join(__dirname, '../../coordinator/error-context.js'))

// ─── parseErrors ─────────────────────────────────────────────────────────────

describe('parseErrors — TypeScript', () => {
  it('parse une erreur TS simple', () => {
    const raw = `src/auth/auth.service.ts(47,15): error TS2339: Property 'userId' does not exist on type 'JwtPayload'.`
    const errors = EC.parseErrors(raw)
    assert.equal(errors.length, 1)
    assert.equal(errors[0].type, 'typescript')
    assert.equal(errors[0].file, 'src/auth/auth.service.ts')
    assert.equal(errors[0].line, 47)
    assert.ok(errors[0].message.includes('userId'))
    assert.ok(typeof errors[0].raw === 'string')
  })

  it('parse plusieurs erreurs TS dans un même output', () => {
    const raw = [
      `src/auth/auth.service.ts(47,15): error TS2339: Property 'userId' does not exist on type 'JwtPayload'.`,
      `src/users/users.module.ts(12,3): error TS2345: Argument of type 'string' is not assignable to parameter of type 'number'.`,
    ].join('\n')
    const errors = EC.parseErrors(raw)
    assert.equal(errors.length, 2)
    assert.equal(errors[0].file, 'src/auth/auth.service.ts')
    assert.equal(errors[1].file, 'src/users/users.module.ts')
    assert.equal(errors[1].line, 12)
  })

  it('retourne type typescript même sans numéro de colonne', () => {
    const raw = `dist/main.js(1): error TS6133: 'x' is declared but its value is never read.`
    const errors = EC.parseErrors(raw)
    assert.equal(errors[0].type, 'typescript')
    assert.equal(errors[0].line, 1)
  })
})

describe('parseErrors — Node:test / TAP', () => {
  it('parse un échec TAP "not ok"', () => {
    const raw = [
      `not ok 1 - should return 401 if token invalid`,
      `  ---`,
      `  duration_ms: 2.345`,
      `  failureType: 'testCodeFailure'`,
      `  error: 'AssertionError [ERR_ASSERTION]: Expected values to be strictly equal:\n+ actual - expected\n+ 200\n- 401'`,
      `  ...`,
    ].join('\n')
    const errors = EC.parseErrors(raw)
    assert.equal(errors.length, 1)
    assert.equal(errors[0].type, 'test')
    assert.ok(errors[0].message.includes('should return 401'))
  })

  it('parse plusieurs "not ok" dans le même output', () => {
    const raw = [
      `not ok 1 - should return 401 if token invalid`,
      `not ok 2 - should reject expired token`,
    ].join('\n')
    const errors = EC.parseErrors(raw)
    assert.equal(errors.length, 2)
    assert.equal(errors[0].type, 'test')
    assert.equal(errors[1].type, 'test')
  })

  it('ignore les lignes "ok N -" (succès)', () => {
    const raw = [
      `ok 1 - should create user`,
      `not ok 2 - should return 401`,
    ].join('\n')
    const errors = EC.parseErrors(raw)
    assert.equal(errors.length, 1)
    assert.ok(errors[0].message.includes('should return 401'))
  })
})

describe('parseErrors — Runtime / Module', () => {
  it('parse une erreur Cannot find module', () => {
    const raw = [
      `Error: Cannot find module '@app/auth/dto/auth.dto'`,
      `    at Function.Module._resolveFilename (node:internal/modules/cjs/loader:1039:15)`,
    ].join('\n')
    const errors = EC.parseErrors(raw)
    assert.equal(errors.length, 1)
    assert.equal(errors[0].type, 'runtime')
    assert.ok(errors[0].message.includes('Cannot find module'))
  })

  it('extrait le fichier et la ligne depuis la stack trace', () => {
    const raw = [
      `TypeError: Cannot read properties of undefined (reading 'id')`,
      `    at AuthService.validateUser (src/auth/auth.service.ts:89:20)`,
    ].join('\n')
    const errors = EC.parseErrors(raw)
    assert.equal(errors[0].type, 'runtime')
    assert.equal(errors[0].file, 'src/auth/auth.service.ts')
    assert.equal(errors[0].line, 89)
  })
})

describe('parseErrors — Lint (ESLint)', () => {
  it('parse une erreur ESLint', () => {
    const raw = [
      `src/app.module.ts`,
      `  12:1  error  'Injectable' is defined but never used  @typescript-eslint/no-unused-vars`,
    ].join('\n')
    const errors = EC.parseErrors(raw)
    assert.equal(errors.length, 1)
    assert.equal(errors[0].type, 'lint')
    assert.equal(errors[0].file, 'src/app.module.ts')
    assert.equal(errors[0].line, 12)
    assert.ok(errors[0].message.includes('Injectable'))
  })
})

describe('parseErrors — Cas limites', () => {
  it('retourne [] sur une chaîne vide', () => {
    assert.deepEqual(EC.parseErrors(''), [])
  })

  it('retourne [] sur null / undefined', () => {
    assert.deepEqual(EC.parseErrors(null), [])
    assert.deepEqual(EC.parseErrors(undefined), [])
  })

  it('retourne type unknown si aucun pattern ne matche', () => {
    const raw = `Build completed successfully.`
    const errors = EC.parseErrors(raw)
    assert.equal(errors.length, 0, 'un output de succès ne doit pas générer d\'erreur')
  })

  it('n\'inclut pas les non-déterministes dans le loop (réseau, OOM)', () => {
    const nonDeterministic = [
      `Error: ECONNREFUSED 127.0.0.1:5432`,
      `Error: ETIMEDOUT`,
      `FATAL ERROR: CALL_AND_RETRY_LAST Allocation failed - JavaScript heap out of memory`,
    ]
    for (const raw of nonDeterministic) {
      const errors = EC.parseErrors(raw)
      const loopable = errors.filter(e => e.loopable !== false)
      assert.equal(loopable.length, 0, `"${raw}" ne doit pas déclencher de loop`)
    }
  })
})

// ─── formatForPrompt ──────────────────────────────────────────────────────────

describe('formatForPrompt', () => {
  const errors = [
    {
      type: 'typescript',
      file: 'src/auth/auth.service.ts',
      line: 47,
      message: "Property 'userId' does not exist on type 'JwtPayload'.",
      raw: "src/auth/auth.service.ts(47,15): error TS2339: Property 'userId'...",
    },
    {
      type: 'test',
      file: null,
      line: null,
      message: 'should return 401 if token invalid',
      raw: 'not ok 1 - should return 401 if token invalid',
    },
  ]

  it('contient le header avec numéro d\'itération', () => {
    const block = EC.formatForPrompt(errors, 2, 3)
    assert.ok(block.includes('Iteration 2/3'), `block: ${block}`)
  })

  it('liste chaque erreur avec son type et sa localisation', () => {
    const block = EC.formatForPrompt(errors, 1, 3)
    assert.ok(block.includes('typescript'))
    assert.ok(block.includes('src/auth/auth.service.ts:47'))
    assert.ok(block.includes("userId"))
  })

  it('inclut une directive de correction ciblée', () => {
    const block = EC.formatForPrompt(errors, 1, 3)
    assert.ok(
      block.toLowerCase().includes('fix') || block.toLowerCase().includes('corrige'),
      'doit contenir une directive de correction'
    )
  })

  it('retourne une chaîne non vide même sur errors=[]', () => {
    const block = EC.formatForPrompt([], 1, 3)
    assert.ok(typeof block === 'string')
    assert.ok(block.length > 0)
  })

  it('mentionne la limite max de loops atteinte quand iter === max', () => {
    const block = EC.formatForPrompt(errors, 3, 3)
    assert.ok(
      block.includes('3/3') || block.toLowerCase().includes('final') || block.toLowerCase().includes('last'),
      'doit signaler que c\'est la dernière itération'
    )
  })
})

// ─── buildRetryContext ────────────────────────────────────────────────────────

describe('buildRetryContext', () => {
  it('retourne hasErrors:false si pas d\'erreur dans phaseState', () => {
    const phaseState = { status: 'failed', error: '', summary: 'timeout' }
    const ctx = EC.buildRetryContext(phaseState, 1)
    assert.equal(ctx.hasErrors, false)
    assert.ok(Array.isArray(ctx.errors))
    assert.equal(ctx.errors.length, 0)
  })

  it('retourne hasErrors:true et errors parsés si erreur TS dans phaseState.error', () => {
    const phaseState = {
      status: 'failed',
      error: `src/auth/auth.service.ts(47,15): error TS2339: Property 'userId' does not exist on type 'JwtPayload'.`,
      summary: 'TypeScript compilation failed',
    }
    const ctx = EC.buildRetryContext(phaseState, 1)
    assert.equal(ctx.hasErrors, true)
    assert.equal(ctx.errors[0].type, 'typescript')
    assert.ok(ctx.formattedBlock.includes('Iteration 1'))
  })

  it('inclut le numéro d\'itération dans le formattedBlock', () => {
    const phaseState = {
      status: 'failed',
      error: `not ok 1 - should create user\nnot ok 2 - should find user by id`,
    }
    const ctx = EC.buildRetryContext(phaseState, 2)
    assert.ok(ctx.formattedBlock.includes('2'), 'l\'itération 2 doit apparaître')
    assert.equal(ctx.iteration, 2)
  })

  it('retourne un RetryContext valide même si phaseState.error est null', () => {
    const phaseState = { status: 'failed', error: null, summary: 'agent crashed' }
    const ctx = EC.buildRetryContext(phaseState, 1)
    assert.ok('hasErrors' in ctx)
    assert.ok('errors' in ctx)
    assert.ok('formattedBlock' in ctx)
    assert.ok('iteration' in ctx)
  })
})
