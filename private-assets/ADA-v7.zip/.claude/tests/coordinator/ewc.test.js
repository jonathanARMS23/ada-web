#!/usr/bin/env node
'use strict'
/**
 * tests/coordinator/ewc.test.js
 * Tests EWC++ — Elastic Weight Consolidation pour la protection des priors
 */

const { test, describe, before, after, beforeEach } = require('node:test')
const assert = require('node:assert/strict')
const { mkdirSync, rmSync, existsSync } = require('fs')
const { join } = require('path')

const TMP        = join(__dirname, '../../..', '.test-tmp-ewc')
const EWC_JS     = join(__dirname, '../../coordinator/ewc.js')
const ROUTER_JS  = join(__dirname, '../../coordinator/router.js')
const BANK_JS    = join(__dirname, '../../coordinator/bank.js')

let ewc, router, bank

before(() => {
  mkdirSync(join(TMP, 'coordinator'), { recursive: true })
  process.env.CLAUDE_CONFIG_DIR = TMP
  delete require.cache[require.resolve(EWC_JS)]
  delete require.cache[require.resolve(ROUTER_JS)]
  ewc    = require(EWC_JS)
  router = require(ROUTER_JS)
})

after(() => {
  delete process.env.CLAUDE_CONFIG_DIR
  try { rmSync(TMP, { recursive: true }) } catch {}
})

beforeEach(() => {
  // Reset module cache pour garantir isolation
  delete require.cache[require.resolve(EWC_JS)]
  delete require.cache[require.resolve(ROUTER_JS)]
  ewc    = require(EWC_JS)
  router = require(ROUTER_JS)
  // Reset l'état du router
  const stateFile = join(TMP, 'coordinator', 'router-state.json')
  if (existsSync(stateFile)) rmSync(stateFile)
})

// ── computeFisherImportance ───────────────────────────────────────────────────

describe('computeFisherImportance', () => {
  test('Beta(1,1) — seulement 2 data points — retourne 0', () => {
    // n=2 → on dépasse le seuil minimum mais variance = max → importance ≈ 0
    const val = ewc.computeFisherImportance(1, 1)
    assert.strictEqual(val, 0)
  })

  test('alpha=0.5, beta=0.5 — n < 2 — retourne 0 (garde-fou)', () => {
    // n = 1 < 2 → retourne 0
    const val = ewc.computeFisherImportance(0.5, 0.5)
    assert.strictEqual(val, 0)
  })

  test('alpha=100, beta=1 — très certain — importance proche de 1', () => {
    const val = ewc.computeFisherImportance(100, 1)
    assert.ok(val > 0.9, `importance=${val} devrait être > 0.9`)
    assert.ok(val <= 1)
  })

  test('alpha=1, beta=100 — certain dans l\'autre sens — importance proche de 1', () => {
    const val = ewc.computeFisherImportance(1, 100)
    assert.ok(val > 0.9, `importance=${val} devrait être > 0.9`)
    assert.ok(val <= 1)
  })

  test('alpha=50, beta=50 — beaucoup de données mais 50/50 — importance intermédiaire', () => {
    const val = ewc.computeFisherImportance(50, 50)
    // Variance = (50*50)/(100²*101) = 2500/1010000 ≈ 0.00248 → faible → importance élevée
    assert.ok(val > 0.9, `importance=${val} — beaucoup de données même 50/50 = faible variance`)
  })

  test('plus de données = plus important : computeFisherImportance(10,1) > computeFisherImportance(2,1)', () => {
    const imp10 = ewc.computeFisherImportance(10, 1)
    const imp2  = ewc.computeFisherImportance(2, 1)
    assert.ok(imp10 > imp2, `imp(10,1)=${imp10} devrait être > imp(2,1)=${imp2}`)
  })

  test('importance toujours dans [0, 1]', () => {
    const cases = [
      [1, 1], [2, 1], [10, 1], [1, 10], [50, 50], [100, 1], [1, 100], [5, 3]
    ]
    for (const [a, b] of cases) {
      const val = ewc.computeFisherImportance(a, b)
      assert.ok(val >= 0 && val <= 1, `importance(${a},${b})=${val} hors [0,1]`)
    }
  })

  test('retourne un number (pas NaN)', () => {
    const val = ewc.computeFisherImportance(5, 3)
    assert.ok(!isNaN(val), 'importance ne doit pas être NaN')
    assert.strictEqual(typeof val, 'number')
  })
})

// ── computeEffectiveDecayFactor ───────────────────────────────────────────────

describe('computeEffectiveDecayFactor', () => {
  test('importance=0 → effectiveFactor = factor (pas de protection)', () => {
    const val = ewc.computeEffectiveDecayFactor(0.95, 0, 0.8)
    assert.strictEqual(val, 0.95)
  })

  test('importance=1, ewcStrength=0.8 → effectiveFactor = 0.99 (protection max)', () => {
    const val = ewc.computeEffectiveDecayFactor(0.95, 1, 0.8)
    assert.ok(Math.abs(val - 0.99) < 1e-10, `val=${val} devrait être 0.99`)
  })

  test('importance=0.5, ewcStrength=0.8 → entre 0.95 et 0.99', () => {
    const val = ewc.computeEffectiveDecayFactor(0.95, 0.5, 0.8)
    assert.ok(val > 0.95 && val < 0.99, `val=${val} devrait être entre 0.95 et 0.99`)
  })

  test('ewcStrength=0 → aucune protection quel que soit importance', () => {
    const val = ewc.computeEffectiveDecayFactor(0.95, 1, 0)
    assert.strictEqual(val, 0.95)
  })

  // ANCIEN comportement (bug B3) : factor + (1-factor)*1*1 = 1.0 → facteur de
  // decay 1.0 = prior GELÉ à vie (α/β jamais réduits, confiance jamais rouverte).
  // Le facteur est désormais plafonné STRICTEMENT sous 1.
  test('B3 — protection maximale ne gèle JAMAIS un prior (facteur < 1)', () => {
    const val = ewc.computeEffectiveDecayFactor(0.95, 1, 1)
    assert.ok(val < 1, `val=${val} doit être < 1 (aucun gel possible)`)
    assert.equal(val, ewc.MAX_EFFECTIVE_DECAY_FACTOR)
    assert.ok(val > 0.95, 'la protection maximale doit tout de même ralentir le decay')
  })

  test('B3 — le plafond ne descend jamais SOUS le facteur nominal', () => {
    // factor déjà supérieur au plafond → le decay nominal reste appliqué tel quel
    const val = ewc.computeEffectiveDecayFactor(0.9995, 0, 0.8)
    assert.equal(val, 0.9995)
  })

  test('protection hors bornes clampée (robustesse)', () => {
    assert.equal(ewc.computeEffectiveDecayFactor(0.9, -5, 0.8), 0.9)
    assert.ok(ewc.computeEffectiveDecayFactor(0.9, 99, 0.8) < 1)
    assert.equal(ewc.computeEffectiveDecayFactor(0.9, NaN, 0.8), 0.9)
  })

  test('ewcStrength par défaut = 0.8', () => {
    const withDefault = ewc.computeEffectiveDecayFactor(0.95, 1)
    const withExplicit = ewc.computeEffectiveDecayFactor(0.95, 1, 0.8)
    assert.strictEqual(withDefault, withExplicit)
  })
})

// ── computeRecencyWeight / computeProtectionWeight (B3) ───────────────────────

describe('computeRecencyWeight', () => {
  const NOW = Date.parse('2026-08-04T12:00:00.000Z')

  test('timestamp absent → 0 (aucune preuve de renforcement récent)', () => {
    assert.equal(ewc.computeRecencyWeight(undefined, { now: NOW }), 0)
    assert.equal(ewc.computeRecencyWeight(null,      { now: NOW }), 0)
    assert.equal(ewc.computeRecencyWeight('',        { now: NOW }), 0)
  })

  test('timestamp invalide → 0', () => {
    assert.equal(ewc.computeRecencyWeight('pas-une-date', { now: NOW }), 0)
  })

  test('renforcé à l\'instant → 1', () => {
    assert.equal(ewc.computeRecencyWeight(new Date(NOW).toISOString(), { now: NOW }), 1)
  })

  test('une demi-vie → 0.5', () => {
    const ts = new Date(NOW - ewc.DEFAULT_HALF_LIFE_DAYS * 86_400_000).toISOString()
    assert.ok(Math.abs(ewc.computeRecencyWeight(ts, { now: NOW }) - 0.5) < 1e-9)
  })

  test('décroît strictement avec l\'âge', () => {
    const w = d => ewc.computeRecencyWeight(new Date(NOW - d * 86_400_000).toISOString(), { now: NOW })
    assert.ok(w(0) > w(10) && w(10) > w(30) && w(30) > w(180))
    assert.ok(w(365) < 0.01, `récence à 1 an = ${w(365)} devrait être quasi nulle`)
  })

  test('accepte un epoch ms et reste dans [0,1]', () => {
    assert.equal(ewc.computeRecencyWeight(NOW, { now: NOW }), 1)
    // horodatage dans le futur → clampé à 1, pas > 1
    assert.equal(ewc.computeRecencyWeight(NOW + 10_000_000, { now: NOW }), 1)
  })
})

describe('computeProtectionWeight — certitude × récence', () => {
  const NOW = Date.parse('2026-08-04T12:00:00.000Z')
  const iso = days => new Date(NOW - days * 86_400_000).toISOString()

  test('B3 — prior massif mais ancien : protection quasi nulle', () => {
    const p = { alpha: 200, beta: 1, lastUpdatedAt: iso(365) }
    assert.ok(ewc.computeFisherImportance(200, 1) > 0.99, 'pré-condition : certitude quasi max')
    assert.ok(ewc.computeProtectionWeight(p, { now: NOW }) < 0.01,
      'un prior silencieux depuis 1 an ne doit plus être protégé, quel que soit son volume')
  })

  test('prior massif ET récent : protection élevée', () => {
    const p = { alpha: 200, beta: 1, lastUpdatedAt: iso(0) }
    assert.ok(ewc.computeProtectionWeight(p, { now: NOW }) > 0.99)
  })

  test('B3 — un prior ancien N\'est PAS plus protégé qu\'un prior récent moins certain', () => {
    const vieuxCertain = { alpha: 200, beta: 1, lastUpdatedAt: iso(200) }
    const recentMoins  = { alpha: 5,   beta: 2, lastUpdatedAt: iso(0)   }
    assert.ok(
      ewc.computeProtectionWeight(recentMoins, { now: NOW }) > ewc.computeProtectionWeight(vieuxCertain, { now: NOW }),
      'effet inversé détecté : l\'ancien resterait le plus protégé'
    )
  })

  test('prior sans timestamp (legacy) → protection 0', () => {
    assert.equal(ewc.computeProtectionWeight({ alpha: 500, beta: 1 }, { now: NOW }), 0)
  })

  test('prior trop jeune (n < 2) → 0 même renforcé à l\'instant', () => {
    assert.equal(ewc.computeProtectionWeight({ alpha: 0.5, beta: 0.5, lastUpdatedAt: iso(0) }, { now: NOW }), 0)
  })

  test('entrée invalide → 0 (jamais NaN)', () => {
    assert.equal(ewc.computeProtectionWeight(null), 0)
    assert.equal(ewc.computeProtectionWeight({}), 0)
    assert.equal(ewc.computeProtectionWeight({ alpha: 'x', beta: 1, lastUpdatedAt: iso(0) }), 0)
  })

  test('protection ∈ [0,1]', () => {
    for (const [a, b, d] of [[1,1,0],[2,1,1],[10,1,15],[1,10,60],[50,50,0],[100,1,400]]) {
      const v = ewc.computeProtectionWeight({ alpha: a, beta: b, lastUpdatedAt: iso(d) }, { now: NOW })
      assert.ok(v >= 0 && v <= 1, `protection(${a},${b},${d}j)=${v}`)
    }
  })
})

// ── analyzeRouterState ────────────────────────────────────────────────────────

describe('analyzeRouterState', () => {
  test('état vide → tableau vide', () => {
    const result = ewc.analyzeRouterState({ priors: {} })
    assert.deepStrictEqual(result, [])
  })

  test('state sans priors → tableau vide', () => {
    const result = ewc.analyzeRouterState({})
    assert.deepStrictEqual(result, [])
  })

  test('retourne un tableau d\'entrées avec les bons champs', () => {
    const state = {
      priors: {
        'backend:nestjs': { alpha: 10, beta: 2, successes: 9, failures: 1 }
      }
    }
    const result = ewc.analyzeRouterState(state)
    assert.strictEqual(result.length, 1)
    const entry = result[0]
    assert.strictEqual(entry.key, 'backend:nestjs')
    assert.ok('importance'      in entry, 'manque importance')
    assert.ok('recency'         in entry, 'manque recency')
    assert.ok('protection'      in entry, 'manque protection')
    assert.ok('effectiveFactor' in entry, 'manque effectiveFactor')
    assert.ok('alpha'           in entry, 'manque alpha')
    assert.ok('beta'            in entry, 'manque beta')
  })

  test('B3 — trie par protection : un prior récent passe devant un prior massif ancien', () => {
    const NOW = Date.parse('2026-08-04T12:00:00.000Z')
    const state = {
      priors: {
        'schema:db':     { alpha: 300, beta: 1, lastUpdatedAt: new Date(NOW - 300 * 86_400_000).toISOString() },
        'specs:tester':  { alpha: 8,   beta: 2, lastUpdatedAt: new Date(NOW).toISOString() },
      }
    }
    const result = ewc.analyzeRouterState(state, { now: NOW })
    assert.strictEqual(result[0].key, 'specs:tester', 'le prior encore vivant doit être le plus protégé')
    assert.ok(result[1].protection < 0.05, 'le prior ancien ne doit plus être protégé')
    assert.ok(result[1].effectiveFactor < result[0].effectiveFactor,
      'le prior ancien doit décayer plus vite que le prior récent')
  })

  test('retourne un tableau trié par importance décroissante', () => {
    const state = {
      priors: {
        'backend:drf':    { alpha: 2, beta: 1, successes: 1, failures: 0 },
        'backend:nestjs': { alpha: 50, beta: 1, successes: 49, failures: 0 },
        'frontend:nextjs': { alpha: 5, beta: 3, successes: 4, failures: 2 },
      }
    }
    const result = ewc.analyzeRouterState(state)
    assert.strictEqual(result.length, 3)
    // Vérifier tri décroissant
    for (let i = 0; i < result.length - 1; i++) {
      assert.ok(
        result[i].importance >= result[i + 1].importance,
        `résultat[${i}].importance=${result[i].importance} < résultat[${i+1}].importance=${result[i+1].importance}`
      )
    }
  })
})

// ── decay avec EWC dans router.js ─────────────────────────────────────────────

describe('router.decay avec EWC', () => {
  test('prior important (α=50,β=1) decay moins que prior récent (α=2,β=1)', () => {
    // Configurer deux priors dans le state
    router.update('backend', 'nestjs', 'success')  // α=2, β=1 après 1 succès
    // Simuler un prior avec beaucoup de données en faisant 49 succès supplémentaires
    for (let i = 0; i < 49; i++) router.update('review', 'reviewer', 'success')

    const stateBefore = router.loadState()
    const alphaNestjsBefore   = stateBefore.priors['backend:nestjs']?.alpha   ?? 2
    const alphaReviewerBefore = stateBefore.priors['review:reviewer']?.alpha  ?? 50

    router.decay(0.95, { ewc: true, ewcStrength: 0.8 })

    const stateAfter = router.loadState()
    const alphaNestjsAfter   = stateAfter.priors['backend:nestjs']?.alpha
    const alphaReviewerAfter = stateAfter.priors['review:reviewer']?.alpha

    // reviewer a plus de données → importance plus haute → decay moins agressif
    const decayNestjs   = alphaNestjsAfter   / alphaNestjsBefore
    const decayReviewer = alphaReviewerAfter / alphaReviewerBefore

    assert.ok(
      decayReviewer >= decayNestjs,
      `reviewer (plus de données) devrait decay moins : decayReviewer=${decayReviewer.toFixed(4)} decayNestjs=${decayNestjs.toFixed(4)}`
    )
  })

  test('decay avec --no-ewc : tous les priors decay uniformément au même factor', () => {
    // Ajouter deux priors très différents
    for (let i = 0; i < 2; i++) router.update('backend', 'nestjs', 'success')
    for (let i = 0; i < 30; i++) router.update('review', 'reviewer', 'success')

    const stateBefore = router.loadState()
    const alphaNestjsBefore   = stateBefore.priors['backend:nestjs']?.alpha
    const alphaReviewerBefore = stateBefore.priors['review:reviewer']?.alpha

    router.decay(0.90, { ewc: false })

    const stateAfter = router.loadState()
    const alphaNestjsAfter   = stateAfter.priors['backend:nestjs']?.alpha
    const alphaReviewerAfter = stateAfter.priors['review:reviewer']?.alpha

    // Sans EWC, le ratio de decay doit être identique (ou floored à 1)
    if (alphaNestjsBefore > 1 / 0.90) {
      const ratioNestjs   = alphaNestjsAfter   / alphaNestjsBefore
      const ratioReviewer = alphaReviewerAfter / alphaReviewerBefore
      assert.ok(
        Math.abs(ratioNestjs - ratioReviewer) < 0.01,
        `Sans EWC les ratios doivent être identiques : nestjs=${ratioNestjs.toFixed(4)} reviewer=${ratioReviewer.toFixed(4)}`
      )
    }
  })

  test('B3 — decay : un prior ancien perd sa protection (facteur nominal)', () => {
    for (let i = 0; i < 100; i++) router.update('schema', 'db', 'success')
    // Rendre ce prior très certain silencieux depuis 6 mois
    const st = router.loadState()
    st.priors['schema:db'].lastUpdatedAt = new Date(Date.now() - 180 * 86_400_000).toISOString()
    router.saveState(st)

    const before = router.loadState().priors['schema:db'].alpha
    const res = router.decay(0.9, { ewc: true, ewcStrength: 0.8 })
    const ratio = router.loadState().priors['schema:db'].alpha / before

    assert.ok(ratio < 0.905, `prior ancien : decay quasi nominal attendu, reçu ×${ratio.toFixed(4)}`)
    assert.equal(res.protected, 0, 'un prior ancien ne doit pas être compté comme protégé')
  })

  test('B4 — decay réduit successes/failures (la confiance peut redescendre)', () => {
    for (let i = 0; i < 12; i++) router.update('schema', 'db', 'success')
    for (let i = 0; i < 4;  i++) router.update('schema', 'db', 'failure')
    router.decay(0.5, { ewc: false })
    const p = router.loadState().priors['schema:db']
    assert.ok(Math.abs(p.successes - 6) < 1e-9, `successes attendu 6, reçu ${p.successes}`)
    assert.ok(Math.abs(p.failures  - 2) < 1e-9, `failures attendu 2, reçu ${p.failures}`)
  })

  test('decay retourne { count, factor, protected }', () => {
    router.update('backend', 'nestjs', 'success')
    const result = router.decay(0.95, { ewc: true })
    assert.ok('count'     in result, 'manque count')
    assert.ok('factor'    in result, 'manque factor')
    assert.ok('protected' in result, 'manque protected')
    assert.strictEqual(result.factor, 0.95)
    assert.ok(result.count >= 1)
    assert.ok(result.protected >= 0)
  })
})

// ── computeTrajectoryImportance depuis bank.js ────────────────────────────────

describe('computeTrajectoryImportance (bank.js)', () => {
  let bankModule

  before(() => {
    // bank.js nécessite SQLite (node:sqlite) — on importe juste computeTrajectoryImportance
    delete require.cache[require.resolve(BANK_JS)]
    bankModule = require(BANK_JS)
  })

  test('trajectoire vide (sans ts) → importance = recencyScore seul (≤ 0.2)', () => {
    // Sans ts → recencyDays=0 → recencyScore=0.2 (trajectoire supposée toute récente)
    // usage_count=0, tier=short (pas de bonus), verdict=undefined → 0+0+0+0.2 = 0.2
    const val = bankModule.computeTrajectoryImportance({})
    assert.ok(val <= 0.2, `importance vide=${val} devrait être ≤ 0.2`)
    assert.ok(val >= 0)
  })

  test('usage_count=10, tier=long, verdict=success → proche de 1', () => {
    const traj = {
      usage_count: 10,
      tier:        'long',
      verdict:     'success',
      ts:          new Date().toISOString(),
    }
    const val = bankModule.computeTrajectoryImportance(traj)
    // usageScore=1 + tierScore=0.5 + verdictScore=0.3 + recencyScore≈0.2 = >1 → clamped à 1
    assert.ok(val >= 0.9, `importance=${val} devrait être proche de 1`)
    assert.ok(val <= 1)
  })

  test('usage_count=0, tier=short, verdict=failure, ts vieux → importance ≈ 0', () => {
    const traj = {
      usage_count: 0,
      tier:        'short',
      verdict:     'failure',
      ts:          new Date(Date.now() - 200 * 86_400_000).toISOString(), // 200 jours
    }
    const val = bankModule.computeTrajectoryImportance(traj)
    assert.ok(val < 0.05, `importance=${val} devrait être ≈ 0`)
  })

  test('usage_count sature à 10 usages', () => {
    const traj10 = { usage_count: 10, ts: new Date().toISOString() }
    const traj50 = { usage_count: 50, ts: new Date().toISOString() }
    const val10  = bankModule.computeTrajectoryImportance(traj10)
    const val50  = bankModule.computeTrajectoryImportance(traj50)
    assert.strictEqual(val10, val50, 'usage_count > 10 doit saturer')
  })

  test('tier=long ajoute 0.5 (plus important que short)', () => {
    const base  = { usage_count: 0, verdict: 'failure', ts: new Date(Date.now() - 90 * 86_400_000).toISOString() }
    const short = bankModule.computeTrajectoryImportance({ ...base, tier: 'short' })
    const long  = bankModule.computeTrajectoryImportance({ ...base, tier: 'long' })
    assert.ok(long > short, `LTM doit être plus important : long=${long} short=${short}`)
    assert.ok(Math.abs((long - short) - 0.5) < 0.01, 'différence doit être ≈ 0.5')
  })

  test('verdict=success ajoute 0.3 vs failure', () => {
    const base    = { usage_count: 0, tier: 'short', ts: new Date(Date.now() - 90 * 86_400_000).toISOString() }
    const success = bankModule.computeTrajectoryImportance({ ...base, verdict: 'success' })
    const failure = bankModule.computeTrajectoryImportance({ ...base, verdict: 'failure' })
    assert.ok(success > failure, `success doit être plus important que failure`)
    assert.ok(Math.abs((success - failure) - 0.3) < 0.01, 'différence doit être ≈ 0.3')
  })

  test('importance toujours dans [0, 1]', () => {
    const cases = [
      {},
      { usage_count: 10, tier: 'long', verdict: 'success', ts: new Date().toISOString() },
      { usage_count: 5, tier: 'short', verdict: 'partial', ts: new Date().toISOString() },
      { usage_count: 100, tier: 'long', verdict: 'success', ts: new Date().toISOString() },
    ]
    for (const traj of cases) {
      const val = bankModule.computeTrajectoryImportance(traj)
      assert.ok(val >= 0 && val <= 1, `importance=${val} pour traj=${JSON.stringify(traj)}`)
    }
  })
})
