'use strict'
/**
 * tests/coordinator/federation.test.js — Tests F13 Federation mTLS sémantique
 *
 * Suite :
 *   TC01 — generateCerts crée cert.pem, key.pem, ca.pem dans un répertoire tmp
 *   TC02 — loadCerts charge les 3 Buffers
 *   TC03 — startFederationServer répond 200 sur GET /federation/health sans auth
 *   TC04 — startFederationServer répond 401 sur POST /federation/sync sans cert client
 *   TC05 — syncWithPeer filtre nodeId local et retourne { sent, received }
 *   TC06 — connectPeer lève Error si peerUrl ne commence pas par https://
 */

const assert = require('node:assert/strict')
const https  = require('node:https')
const os     = require('node:os')
const { join } = require('node:path')
const { mkdtempSync, rmSync, existsSync } = require('node:fs')
const path   = require('node:path')

// Résolution dynamique du module depuis CLAUDE_CONFIG_DIR ou __dirname
const CONFIG_DIR = process.env.CLAUDE_CONFIG_DIR
  || join(os.homedir(), '.claude')
const fedPath = join(CONFIG_DIR, 'coordinator', 'federation.js')

let fed
try {
  fed = require(fedPath)
} catch {
  fed = require(join(__dirname, '..', '..', 'coordinator', 'federation.js'))
}

const {
  generateCerts,
  loadCerts,
  startFederationServer,
  connectPeer,
  syncWithPeer,
  getFederationConfig,
} = fed

// ── Helpers ───────────────────────────────────────────────────────────────────

function tmpDir() {
  return mkdtempSync(join(os.tmpdir(), 'ada-fed-test-'))
}

function cleanup(dir) {
  try { rmSync(dir, { recursive: true, force: true }) } catch { /* silencieux */ }
}

// Génère les certs une seule fois pour tous les tests serveur
let _sharedCertDir = null
function getSharedCerts() {
  if (!_sharedCertDir) {
    _sharedCertDir = tmpDir()
    generateCerts(_sharedCertDir)
  }
  return _sharedCertDir
}

// ── TC01 — generateCerts ──────────────────────────────────────────────────────

async function tc01_generateCerts() {
  const dir = tmpDir()
  try {
    const { certPath, keyPath, caPath } = generateCerts(dir)
    assert.ok(existsSync(certPath), 'cert.pem doit exister')
    assert.ok(existsSync(keyPath),  'key.pem doit exister')
    assert.ok(existsSync(caPath),   'ca.pem doit exister')
    assert.ok(certPath.endsWith('cert.pem'))
    assert.ok(keyPath.endsWith('key.pem'))
    assert.ok(caPath.endsWith('ca.pem'))
    console.log('  [TC01] ✓ generateCerts crée cert.pem, key.pem, ca.pem')
  } finally {
    cleanup(dir)
  }
}

// ── TC02 — loadCerts ──────────────────────────────────────────────────────────

async function tc02_loadCerts() {
  const dir = tmpDir()
  try {
    generateCerts(dir)
    const { cert, key, ca } = loadCerts(dir)
    assert.ok(Buffer.isBuffer(cert), 'cert doit être un Buffer')
    assert.ok(Buffer.isBuffer(key),  'key doit être un Buffer')
    assert.ok(Buffer.isBuffer(ca),   'ca doit être un Buffer')
    assert.ok(cert.length > 0, 'cert non vide')
    assert.ok(key.length  > 0, 'key non vide')
    assert.ok(ca.length   > 0, 'ca non vide')
    console.log('  [TC02] ✓ loadCerts retourne 3 Buffers non vides')
  } finally {
    cleanup(dir)
  }
}

// ── TC03 — health endpoint (sans auth client) ─────────────────────────────────

async function tc03_healthEndpoint() {
  const certDir = getSharedCerts()
  const certs   = loadCerts(certDir)

  const server = startFederationServer({
    port:     0,    // port aléatoire
    certDir,
    allowedNodes: [],
  })

  await new Promise(resolve => server.once('listening', resolve))
  const { port } = server.address()

  try {
    const body = await new Promise((resolve, reject) => {
      // Agent sans cert client — health ne demande pas de cert
      // checkServerIdentity désactivé : les certs de test n'ont pas de SAN pour 127.0.0.1
      const agent = new https.Agent({
        ca: certs.ca,
        rejectUnauthorized: true,
        checkServerIdentity: () => undefined,
      })
      const req = https.request({
        hostname: '127.0.0.1',
        port,
        path: '/federation/health',
        method: 'GET',
        agent,
      }, res => {
        let data = ''
        res.on('data', c => { data += c })
        res.on('end', () => {
          assert.equal(res.statusCode, 200, `health → 200 attendu (reçu ${res.statusCode})`)
          resolve(JSON.parse(data))
        })
      })
      req.on('error', reject)
      req.end()
    })

    assert.equal(body.ok,      true,  'ok doit être true')
    assert.equal(body.version, '6.0', 'version doit être "6.0"')
    assert.ok(typeof body.nodeId === 'string' && body.nodeId.length > 0, 'nodeId doit être présent')
    console.log('  [TC03] ✓ GET /federation/health → 200 {ok:true, version:"6.0", nodeId}')
  } finally {
    server.close()
  }
}

// ── TC04 — sync sans cert client → 401 ───────────────────────────────────────

async function tc04_syncWithoutCert() {
  const certDir = getSharedCerts()
  const certs   = loadCerts(certDir)

  const server = startFederationServer({
    port:        0,
    certDir,
    allowedNodes: [],
  })

  await new Promise(resolve => server.once('listening', resolve))
  const { port } = server.address()

  try {
    const statusCode = await new Promise((resolve, reject) => {
      // Agent sans cert client — doit déclencher 401
      // checkServerIdentity désactivé : les certs de test n'ont pas de SAN pour 127.0.0.1
      const agent = new https.Agent({
        ca:                  certs.ca,
        rejectUnauthorized:  true,
        checkServerIdentity: () => undefined,
      })
      const body = JSON.stringify({ query: 'test', topK: 3 })
      const req = https.request({
        hostname: '127.0.0.1',
        port,
        path:   '/federation/sync',
        method: 'POST',
        agent,
        headers: {
          'Content-Type':   'application/json',
          'Content-Length': Buffer.byteLength(body),
        },
      }, res => {
        res.resume()
        resolve(res.statusCode)
      })
      req.on('error', err => {
        // TLS handshake peut se terminer en erreur socket si mTLS strict
        // On accepte 401 ou une erreur ECONNRESET/EPROTO comme résultat valide
        if (err.code === 'ECONNRESET' || err.code === 'EPROTO' || err.code === 'ERR_SSL_SSLV3_ALERT_HANDSHAKE_FAILURE') {
          resolve(401)  // mTLS rejecte avant HTTP
        } else {
          reject(err)
        }
      })
      req.write(body)
      req.end()
    })

    assert.ok(statusCode === 401 || statusCode === undefined,
      `sync sans cert → 401 ou handshake failure attendu (reçu ${statusCode})`)
    console.log(`  [TC04] ✓ POST /federation/sync sans cert client → ${statusCode} (non autorisé)`)
  } finally {
    server.close()
  }
}

// ── TC05 — syncWithPeer filtre le nodeId local ────────────────────────────────

async function tc05_syncWithPeerFiltersLocalNodeId() {
  const localNodeId = os.hostname()

  // Mock peer : retourne une trajectoire locale + une distante
  const mockPeer = {
    async sync(query, topK) {
      return {
        nodeId: 'remote-node',
        trajectories: [
          {
            nodeId:  localNodeId,   // doit être filtré
            phase:   'backend',
            agent:   'nestjs',
            verdict: 'success',
            summary: 'trajectoire locale — ne doit pas être importée',
            tags:    [],
          },
          {
            nodeId:  'remote-node', // doit être importé
            phase:   'backend',
            agent:   'nestjs',
            verdict: 'success',
            summary: 'trajectoire distante valide',
            tags:    [],
          },
        ],
      }
    },
  }

  // Mock bank.store pour capturer les appels
  const stored = []
  const originalGetBank = fed._getLocalNodeId  // juste pour vérifier l'isolation

  // Monkey-patch temporaire du bank via la config
  const origEnv = process.env.CLAUDE_CONFIG_DIR
  const tmpCfgDir = tmpDir()
  try {
    // Générer des certs dans tmpCfgDir pour que _getLocalNodeId retourne os.hostname()
    generateCerts(join(tmpCfgDir, 'federation', 'certs'))
    process.env.CLAUDE_CONFIG_DIR = tmpCfgDir

    // Override bank lazy-require avec un mock
    // On utilise une approche directe : on teste avec un peer mock
    // et on vérifie que syncWithPeer retourne { sent: topK, received }
    const result = await syncWithPeer(mockPeer, 'test query', 3)

    // received peut être 0 si bank est absent dans le test (pas de SQLite)
    // L'important est que sent = topK et received ≤ 1 (la trajectoire distante seulement)
    assert.equal(result.sent, 3, 'sent doit être égal à topK')
    assert.ok(typeof result.received === 'number', 'received doit être un nombre')
    assert.ok(result.received <= 1,
      `received doit être ≤ 1 (trajectoire locale filtrée) — reçu ${result.received}`)
    console.log(`  [TC05] ✓ syncWithPeer filtre nodeId local → sent=${result.sent} received=${result.received}`)
  } finally {
    process.env.CLAUDE_CONFIG_DIR = origEnv || ''
    if (!origEnv) delete process.env.CLAUDE_CONFIG_DIR
    cleanup(tmpCfgDir)
  }
}

// ── TC06 — connectPeer lève Error si non HTTPS ────────────────────────────────

async function tc06_connectPeerRequiresHttps() {
  const dir = tmpDir()
  try {
    generateCerts(dir)
    assert.throws(
      () => connectPeer('http://staging.local:7878', dir),
      /Federation requires HTTPS/,
      'connectPeer doit lancer une erreur si peerUrl ne commence pas par https://'
    )
    console.log('  [TC06] ✓ connectPeer("http://...") → Error("Federation requires HTTPS")')
  } finally {
    cleanup(dir)
  }
}

// ── Runner ────────────────────────────────────────────────────────────────────

async function runAll() {
  console.log('\nF13 — Federation mTLS sémantique\n')

  const tests = [
    ['TC01', tc01_generateCerts],
    ['TC02', tc02_loadCerts],
    ['TC03', tc03_healthEndpoint],
    ['TC04', tc04_syncWithoutCert],
    ['TC05', tc05_syncWithPeerFiltersLocalNodeId],
    ['TC06', tc06_connectPeerRequiresHttps],
  ]

  let passed = 0
  let failed = 0

  for (const [name, fn] of tests) {
    try {
      await fn()
      passed++
    } catch (err) {
      console.error(`  [${name}] ✗ ÉCHEC — ${err.message}`)
      if (process.env.VERBOSE) console.error(err.stack)
      failed++
    }
  }

  // Nettoyage des certs partagés
  if (_sharedCertDir) cleanup(_sharedCertDir)

  console.log(`\n  Résultat : ${passed} passés, ${failed} échoués / ${tests.length} tests\n`)
  process.exit(failed > 0 ? 1 : 0)
}

runAll().catch(err => {
  console.error(`Erreur inattendue : ${err.message}`)
  process.exit(1)
})
