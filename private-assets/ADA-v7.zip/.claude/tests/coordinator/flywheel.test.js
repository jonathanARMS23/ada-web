'use strict'
/**
 * tests/coordinator/flywheel.test.js — boucle fermée « flywheel » anti-régression.
 *
 * Écrit AVANT l'implémentation (TDD). Couvre :
 *   1. recall@k correct sur fixtures (pur, recallFn injecté)
 *   2. baseline monotone (accepte ≥, refuse <)
 *   3. check détecte une régression simulée (ancre impossible)
 *   4. policy apply → régression → revert AUTOMATIQUE (fail-closed)
 *   5. policy absente → défauts (loadPolicy)
 *   6. idempotence apply (re-apply de la même policy = no-op)
 *   + intégration : anchors réels verts au baseline ; bad policy vide le recall.
 */

const test = require('node:test')
const assert = require('node:assert')
const { mkdtempSync, writeFileSync, readFileSync, existsSync, rmSync } = require('fs')
const { join } = require('path')
const { tmpdir } = require('os')

const fw = require('../../coordinator/flywheel.js')
const policyMod = require('../../coordinator/flywheel-policy.js')

function tmp() {
  return mkdtempSync(join(tmpdir(), 'flywheel-'))
}

// ── 1. recall@k sur fixtures ──────────────────────────────────────────────────
test('computeRecallAtK — tous les markers présents → 1.0', () => {
  const block = 'Conventions:\n- RLS Supabase\n- uuid PK + workspace_id'
  const r = fw.computeRecallAtK(block, ['RLS', 'uuid', 'workspace_id'])
  assert.strictEqual(r.recall, 1)
  assert.deepStrictEqual(r.missing, [])
})

test('computeRecallAtK — partiel → ratio, case-insensitive', () => {
  const block = 'Conventions:\n- Jamais de secrets'
  const r = fw.computeRecallAtK(block, ['SECRETS', 'outbox'])
  assert.strictEqual(r.recall, 0.5)
  assert.deepStrictEqual(r.found, ['SECRETS'])
  assert.deepStrictEqual(r.missing, ['outbox'])
})

test('computeRecallAtK — bloc vide → 0', () => {
  const r = fw.computeRecallAtK('', ['RLS'])
  assert.strictEqual(r.recall, 0)
})

test('evalAnchors — score = moyenne des recall@k', () => {
  const anchors = [
    { id: 'a', query: 'q1', expectedMarkers: ['RLS'] },
    { id: 'b', query: 'q2', expectedMarkers: ['outbox', 'cents'] },
  ]
  const recallFn = (q) => (q === 'q1' ? 'RLS ok' : 'outbox only')
  const res = fw.evalAnchors({ anchors, k: 5, recallFn })
  // a: 1.0 ; b: 0.5 → moyenne 0.75
  assert.strictEqual(res.score, 0.75)
  assert.strictEqual(res.k, 5)
  assert.strictEqual(res.anchors.length, 2)
})

// ── 2. baseline monotone ──────────────────────────────────────────────────────
test('baseline monotone — refuse un score inférieur, accepte un score ≥', () => {
  const dir = tmp()
  const p = join(dir, 'baseline.json')
  const r1 = fw.writeBaseline(p, { score: 0.9, k: 5, anchors: { a: 0.9 } })
  assert.strictEqual(r1.written, true)

  // score inférieur → refusé
  const r2 = fw.writeBaseline(p, { score: 0.5, k: 5, anchors: { a: 0.5 } })
  assert.strictEqual(r2.written, false)
  assert.match(r2.reason, /monoton|inf|regress/i)
  assert.strictEqual(fw.readBaseline(p).score, 0.9) // inchangé

  // score égal → accepté
  const r3 = fw.writeBaseline(p, { score: 0.9, k: 5, anchors: { a: 0.9 } })
  assert.strictEqual(r3.written, true)

  // score supérieur → accepté
  const r4 = fw.writeBaseline(p, { score: 1.0, k: 5, anchors: { a: 1.0 } })
  assert.strictEqual(r4.written, true)
  assert.strictEqual(fw.readBaseline(p).score, 1.0)
  rmSync(dir, { recursive: true, force: true })
})

test('baseline monotone — --force outrepasse le garde-fou', () => {
  const dir = tmp()
  const p = join(dir, 'baseline.json')
  fw.writeBaseline(p, { score: 0.9, k: 5, anchors: {} })
  const r = fw.writeBaseline(p, { score: 0.1, k: 5, anchors: {} }, { force: true })
  assert.strictEqual(r.written, true)
  assert.strictEqual(fw.readBaseline(p).score, 0.1)
  rmSync(dir, { recursive: true, force: true })
})

// ── 3. check détecte une régression ───────────────────────────────────────────
test('checkAgainstBaseline — score ≥ baseline → ok', () => {
  const baseline = { score: 0.8, k: 5, anchors: { a: 1, b: 0.6 } }
  const result = { score: 0.9, k: 5, anchors: [{ id: 'a', recall: 1 }, { id: 'b', recall: 0.8 }] }
  const c = fw.checkAgainstBaseline(result, baseline)
  assert.strictEqual(c.ok, true)
  assert.ok(c.delta >= 0)
})

test('checkAgainstBaseline — ancre impossible → régression détaillée', () => {
  const baseline = { score: 1.0, k: 5, anchors: { a: 1, b: 1 } }
  // b s'effondre (marker impossible non trouvé)
  const result = { score: 0.5, k: 5, anchors: [{ id: 'a', recall: 1 }, { id: 'b', recall: 0 }] }
  const c = fw.checkAgainstBaseline(result, baseline)
  assert.strictEqual(c.ok, false)
  assert.ok(c.delta < 0)
  assert.ok(c.regressions.some(r => r.id === 'b'), 'doit lister l\'ancre perdue')
})

test('checkAgainstBaseline — premier run (pas de baseline) → ok', () => {
  const result = { score: 0.7, k: 5, anchors: [] }
  const c = fw.checkAgainstBaseline(result, null)
  assert.strictEqual(c.ok, true)
  assert.strictEqual(c.firstRun, true)
})

// ── 5. policy absente → défauts ───────────────────────────────────────────────
test('loadPolicy — fichier absent → défauts', () => {
  const dir = tmp()
  const p = join(dir, 'active-policy.json')
  const params = policyMod.loadPolicy({ path: p, fresh: true })
  assert.deepStrictEqual(params, policyMod.DEFAULTS)
  rmSync(dir, { recursive: true, force: true })
})

test('loadPolicy — fichier corrompu → défauts (fail-safe silencieux)', () => {
  const dir = tmp()
  const p = join(dir, 'active-policy.json')
  writeFileSync(p, '{ this is not json')
  const params = policyMod.loadPolicy({ path: p, fresh: true })
  assert.deepStrictEqual(params, policyMod.DEFAULTS)
  rmSync(dir, { recursive: true, force: true })
})

test('loadPolicy — params partiels → merge avec défauts', () => {
  const dir = tmp()
  const p = join(dir, 'active-policy.json')
  writeFileSync(p, JSON.stringify({ params: { recallK: 12 } }))
  const params = policyMod.loadPolicy({ path: p, fresh: true })
  assert.strictEqual(params.recallK, 12)
  assert.strictEqual(params.gateScoreThreshold, policyMod.DEFAULTS.gateScoreThreshold)
  rmSync(dir, { recursive: true, force: true })
})

// ── 4. policy apply → régression → revert automatique ─────────────────────────
test('applyPolicy — check ok → policy appliquée, previous sauvegardé', () => {
  const dir = tmp()
  const p = join(dir, 'active-policy.json')
  const okCheck = () => ({ ok: true, delta: 0.1, regressions: [] })
  const res = fw.applyPolicy({ policyPath: p, params: { recallK: 8 }, checkFn: okCheck })
  assert.strictEqual(res.ok, true)
  assert.strictEqual(res.reverted, false)
  const active = JSON.parse(readFileSync(p, 'utf8'))
  assert.strictEqual(active.params.recallK, 8)
  assert.strictEqual(active.previous, null) // pas de policy antérieure
  rmSync(dir, { recursive: true, force: true })
})

test('applyPolicy — régression → REVERT automatique (fail-closed)', () => {
  const dir = tmp()
  const p = join(dir, 'active-policy.json')
  // policy initiale saine
  fw.applyPolicy({ policyPath: p, params: { recallK: 8 }, checkFn: () => ({ ok: true, regressions: [] }) })

  // policy mauvaise → check échoue → doit revert vers recallK:8
  const badCheck = () => ({ ok: false, delta: -0.5, regressions: [{ id: 'x' }] })
  const res = fw.applyPolicy({ policyPath: p, params: { gateScoreThreshold: 9999 }, checkFn: badCheck })
  assert.strictEqual(res.ok, false)
  assert.strictEqual(res.reverted, true)

  // état restauré : recallK:8, pas gateScoreThreshold:9999
  const active = JSON.parse(readFileSync(p, 'utf8'))
  assert.strictEqual(active.params.recallK, 8)
  assert.strictEqual(active.params.gateScoreThreshold, undefined)
  rmSync(dir, { recursive: true, force: true })
})

test('revertPolicy — restaure previous ; sans previous → retour aux défauts (fichier supprimé)', () => {
  const dir = tmp()
  const p = join(dir, 'active-policy.json')
  fw.applyPolicy({ policyPath: p, params: { recallK: 8 }, checkFn: () => ({ ok: true }) })
  fw.applyPolicy({ policyPath: p, params: { recallK: 10 }, checkFn: () => ({ ok: true }) })
  // revert → recallK:8
  const r1 = fw.revertPolicy({ policyPath: p })
  assert.strictEqual(r1.ok, true)
  assert.strictEqual(JSON.parse(readFileSync(p, 'utf8')).params.recallK, 8)
  // revert → previous null → fichier supprimé (défauts)
  const r2 = fw.revertPolicy({ policyPath: p })
  assert.strictEqual(r2.ok, true)
  assert.strictEqual(existsSync(p), false)
  rmSync(dir, { recursive: true, force: true })
})

// ── 6. idempotence apply ──────────────────────────────────────────────────────
test('applyPolicy — re-apply de la MÊME policy = no-op (previous inchangé)', () => {
  const dir = tmp()
  const p = join(dir, 'active-policy.json')
  fw.applyPolicy({ policyPath: p, params: { recallK: 8 }, checkFn: () => ({ ok: true }) })
  fw.applyPolicy({ policyPath: p, params: { recallK: 10 }, checkFn: () => ({ ok: true }) })
  const before = readFileSync(p, 'utf8')

  const res = fw.applyPolicy({ policyPath: p, params: { recallK: 10 }, checkFn: () => ({ ok: true }) })
  assert.strictEqual(res.noop, true)
  const after = readFileSync(p, 'utf8')
  assert.strictEqual(before, after, 'no-op ne doit pas écraser previous')
  // un revert doit toujours ramener à recallK:8 (previous non corrompu par le no-op)
  fw.revertPolicy({ policyPath: p })
  assert.strictEqual(JSON.parse(readFileSync(p, 'utf8')).params.recallK, 8)
  rmSync(dir, { recursive: true, force: true })
})

// ── Intégration : ancres réelles + bad policy vide le recall ──────────────────
test('intégration — anchors réels tous verts au baseline (score = 1.0)', () => {
  const anchors = fw.loadAnchors()
  assert.ok(anchors.anchors.length >= 10, 'au moins 10 ancres figées')
  assert.strictEqual(anchors.frozen, true)
  const res = fw.evalAnchors({ anchors: anchors.anchors, k: anchors.k || 5, recallFn: fw.defaultRecallFn })
  assert.strictEqual(res.score, 1, `toutes les ancres doivent passer avec la config actuelle — perdues: ${
    res.anchors.filter(a => a.recall < 1).map(a => `${a.id}(${a.missing.join('|')})`).join(', ')}`)
})

test('intégration — policy « gate absurde » fait chuter le recall (régression réelle)', () => {
  const anchors = fw.loadAnchors()
  const k = anchors.k || 5
  // baseline verte
  const base = fw.evalAnchors({ anchors: anchors.anchors, k, recallFn: fw.defaultRecallFn })
  assert.strictEqual(base.score, 1)

  // gate absurde : exige 99 tokens partagés + seuil de score inatteignable → NONE → bloc vide
  const badRecall = fw.makeRecallFn({ gateScoreThreshold: 9999, gateMinSharedTokens: 99 })
  const bad = fw.evalAnchors({ anchors: anchors.anchors, k, recallFn: badRecall })
  assert.ok(bad.score < base.score, `le recall doit chuter (base=${base.score}, bad=${bad.score})`)

  const c = fw.checkAgainstBaseline(bad, { score: base.score, k, anchors: Object.fromEntries(base.anchors.map(a => [a.id, a.recall])) })
  assert.strictEqual(c.ok, false)
  assert.ok(c.regressions.length > 0)
})
