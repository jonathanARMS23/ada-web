#!/usr/bin/env node
'use strict'
/**
 * tests/coordinator/graph-memory.test.js
 * Tests KnowledgeGraph — RED phase (module does not exist yet)
 *
 * Run : node --test tests/coordinator/graph-memory.test.js
 */

const { test, describe, before, after, beforeEach } = require('node:test')
const assert = require('node:assert/strict')
const { mkdirSync, rmSync, writeFileSync, existsSync } = require('fs')
const { join } = require('path')

const GRAPH_MEMORY_JS  = join(__dirname, '../../coordinator/graph-memory.js')
const GRAPH_BUILDER_JS = join(__dirname, '../../coordinator/graph-builder.js')

const TMP = join(__dirname, '../../..', '.test-tmp-graph')

let KnowledgeGraph

// ── Bootstrap ─────────────────────────────────────────────────────────────────

before(() => {
  delete require.cache[require.resolve(GRAPH_MEMORY_JS)]
  const mod = require(GRAPH_MEMORY_JS)
  KnowledgeGraph = mod.KnowledgeGraph
})

// ── Helpers ───────────────────────────────────────────────────────────────────

function freshGraph () {
  return new KnowledgeGraph()
}

// ═══════════════════════════════════════════════════════════════════════════════
// KnowledgeGraph — Nodes
// ═══════════════════════════════════════════════════════════════════════════════

describe('KnowledgeGraph — Nodes', () => {
  test('addNode crée un noeud récupérable via getNode', () => {
    const g = freshGraph()
    g.addNode('agent:nestjs', 'agent', 'NestJS', { lang: 'ts' })
    const node = g.getNode('agent:nestjs')
    assert.ok(node !== null, 'getNode doit retourner le noeud créé')
    assert.strictEqual(node.id,    'agent:nestjs')
    assert.strictEqual(node.type,  'agent')
    assert.strictEqual(node.label, 'NestJS')
    assert.strictEqual(node.attrs.lang, 'ts')
  })

  test('getNode retourne null pour un id inconnu', () => {
    const g = freshGraph()
    assert.strictEqual(g.getNode('agent:unknown'), null)
  })

  test('addNode upsert fusionne les attrs sans perdre le type', () => {
    const g = freshGraph()
    g.addNode('phase:backend', 'phase', 'Backend', { tier: 2 })
    g.addNode('phase:backend', 'phase', 'Backend updated', { priority: 'high' })
    const node = g.getNode('phase:backend')
    assert.strictEqual(node.type, 'phase', 'type doit être conservé')
    assert.strictEqual(node.attrs.priority, 'high', 'nouvel attr doit être présent')
    assert.strictEqual(node.attrs.tier, 2, 'ancien attr doit être conservé')
  })

  test('plusieurs noeuds coexistent sans collision', () => {
    const g = freshGraph()
    g.addNode('agent:nestjs',  'agent', 'NestJS',  {})
    g.addNode('agent:tester',  'agent', 'Tester',  {})
    g.addNode('phase:backend', 'phase', 'Backend', {})
    assert.ok(g.getNode('agent:nestjs')  !== null)
    assert.ok(g.getNode('agent:tester')  !== null)
    assert.ok(g.getNode('phase:backend') !== null)
    assert.strictEqual(g.getNode('agent:drf'), null)
  })
})

// ═══════════════════════════════════════════════════════════════════════════════
// KnowledgeGraph — Edges
// ═══════════════════════════════════════════════════════════════════════════════

describe('KnowledgeGraph — Edges', () => {
  test('addEdge crée une arête avec poids par défaut 1.0', () => {
    const g = freshGraph()
    g.addNode('agent:nestjs',  'agent', 'NestJS',  {})
    g.addNode('phase:backend', 'phase', 'Backend', {})
    g.addEdge('agent:nestjs', 'phase:backend', 'WIN_RATE')
    const edge = g.getEdge('agent:nestjs', 'phase:backend', 'WIN_RATE')
    assert.ok(edge !== null, 'getEdge doit retourner l\'arête créée')
    assert.strictEqual(edge.from,   'agent:nestjs')
    assert.strictEqual(edge.to,     'phase:backend')
    assert.strictEqual(edge.type,   'WIN_RATE')
    assert.strictEqual(edge.weight, 1.0)
  })

  test('getEdge retourne null pour une arête manquante', () => {
    const g = freshGraph()
    g.addNode('agent:nestjs',  'agent', 'NestJS',  {})
    g.addNode('phase:backend', 'phase', 'Backend', {})
    assert.strictEqual(g.getEdge('agent:nestjs', 'phase:backend', 'WIN_RATE'), null)
  })

  test('addEdge accumule le poids sur une arête existante (+=)', () => {
    const g = freshGraph()
    g.addNode('agent:nestjs',  'agent', 'NestJS',  {})
    g.addNode('phase:backend', 'phase', 'Backend', {})
    g.addEdge('agent:nestjs', 'phase:backend', 'WIN_RATE', 0.5)
    g.addEdge('agent:nestjs', 'phase:backend', 'WIN_RATE', 0.8)
    const edge = g.getEdge('agent:nestjs', 'phase:backend', 'WIN_RATE')
    // addEdge fait += sur une arête existante : 0.5 + 0.8 = 1.3
    assert.ok(Math.abs(edge.weight - 1.3) < 1e-9, `poids cumulé doit être 1.3, obtenu ${edge.weight}`)
  })

  test('addEdge avec poids explicite le conserve exactement', () => {
    const g = freshGraph()
    g.addNode('agent:drf',    'agent', 'DRF',     {})
    g.addNode('phase:schema', 'phase', 'Schema',  {})
    g.addEdge('agent:drf', 'phase:schema', 'A_RÉSOLU', 0.75)
    const edge = g.getEdge('agent:drf', 'phase:schema', 'A_RÉSOLU')
    assert.strictEqual(edge.weight, 0.75)
  })

  test('addEdge auto-crée les noeuds from/to inconnus', () => {
    const g = freshGraph()
    // Noeuds non créés explicitement
    g.addEdge('agent:auto-from', 'phase:auto-to', 'PRÉCÈDE')
    assert.ok(g.getNode('agent:auto-from') !== null, 'noeud from doit être auto-créé')
    assert.ok(g.getNode('phase:auto-to')   !== null, 'noeud to doit être auto-créé')
  })
})

// ═══════════════════════════════════════════════════════════════════════════════
// KnowledgeGraph — getNeighbors
// ═══════════════════════════════════════════════════════════════════════════════

describe('KnowledgeGraph — getNeighbors', () => {
  // getNeighbors retourne Array<{ node: GraphNode, edge: GraphEdge }>

  test('direction out retourne les voisins sortants', () => {
    const g = freshGraph()
    g.addEdge('agent:nestjs',  'phase:backend',  'WIN_RATE')
    g.addEdge('agent:nestjs',  'phase:frontend', 'WIN_RATE')
    g.addEdge('phase:backend', 'agent:nestjs',   'WIN_RATE')  // arête inverse

    const neighbors = g.getNeighbors('agent:nestjs', { direction: 'out' })
    const ids = neighbors.map(entry => entry.node.id)
    assert.ok(ids.includes('phase:backend'),  'phase:backend doit être voisin sortant')
    assert.ok(ids.includes('phase:frontend'), 'phase:frontend doit être voisin sortant')
    assert.ok(!ids.includes('agent:nestjs'),  'le noeud source ne doit pas apparaître')
  })

  test('direction in retourne les voisins entrants', () => {
    const g = freshGraph()
    g.addEdge('agent:nestjs',  'phase:backend', 'WIN_RATE')
    g.addEdge('agent:tester',  'phase:backend', 'WIN_RATE')
    g.addEdge('phase:backend', 'agent:nestjs',  'WIN_RATE')  // arête sortante de phase:backend

    const neighbors = g.getNeighbors('phase:backend', { direction: 'in' })
    const ids = neighbors.map(entry => entry.node.id)
    assert.ok(ids.includes('agent:nestjs'),  'agent:nestjs doit être voisin entrant')
    assert.ok(ids.includes('agent:tester'),  'agent:tester doit être voisin entrant')
  })

  test('direction both retourne l\'union des voisins', () => {
    const g = freshGraph()
    g.addEdge('agent:nestjs',   'phase:backend',  'WIN_RATE')
    g.addEdge('phase:frontend', 'agent:nestjs',   'WIN_RATE')

    const neighbors = g.getNeighbors('agent:nestjs', { direction: 'both' })
    const ids = neighbors.map(entry => entry.node.id)
    assert.ok(ids.includes('phase:backend'),  'voisin sortant doit apparaître')
    assert.ok(ids.includes('phase:frontend'), 'voisin entrant doit apparaître')
  })

  test('filtre par edgeType n\'inclut que les arêtes du bon type', () => {
    const g = freshGraph()
    g.addEdge('agent:nestjs', 'phase:backend',  'WIN_RATE')
    g.addEdge('agent:nestjs', 'phase:frontend', 'ANTI_CORRÈLE')

    const neighbors = g.getNeighbors('agent:nestjs', { direction: 'out', edgeType: 'WIN_RATE' })
    const ids = neighbors.map(entry => entry.node.id)
    assert.ok(ids.includes('phase:backend'),   'phase:backend (WIN_RATE) doit être inclus')
    assert.ok(!ids.includes('phase:frontend'), 'phase:frontend (ANTI_CORRÈLE) doit être exclu')
  })
})

// ═══════════════════════════════════════════════════════════════════════════════
// KnowledgeGraph — BFS
// ═══════════════════════════════════════════════════════════════════════════════

describe('KnowledgeGraph — BFS', () => {
  test('bfs traverses 1 hop correctement', () => {
    const g = freshGraph()
    g.addEdge('agent:nestjs',  'phase:backend',  'WIN_RATE')
    g.addEdge('phase:backend', 'agent:db',       'PRÉCÈDE')

    const result = g.bfs('agent:nestjs', { maxHops: 3 })
    assert.ok(result instanceof Map, 'bfs doit retourner une Map')
    assert.ok(result.has('phase:backend'), 'phase:backend doit être à 1 hop')
    assert.strictEqual(result.get('phase:backend').depth, 1)
  })

  test('bfs respecte maxHops=1', () => {
    const g = freshGraph()
    g.addEdge('agent:nestjs',  'phase:backend', 'WIN_RATE')
    g.addEdge('phase:backend', 'agent:db',      'PRÉCÈDE')

    const result = g.bfs('agent:nestjs', { maxHops: 1 })
    assert.ok(result.has('phase:backend'),  'phase:backend (hop 1) doit être inclus')
    assert.ok(!result.has('agent:db'),      'agent:db (hop 2) doit être exclu')
  })

  test('bfs sur graphe vide retourne une Map vide', () => {
    const g = freshGraph()
    g.addNode('agent:nestjs', 'agent', 'NestJS', {})

    const result = g.bfs('agent:nestjs', { maxHops: 3 })
    assert.ok(result instanceof Map)
    assert.strictEqual(result.size, 0)
  })

  test('bfs n\'inclut pas le noeud de départ', () => {
    const g = freshGraph()
    g.addEdge('agent:nestjs', 'phase:backend', 'WIN_RATE')

    const result = g.bfs('agent:nestjs', { maxHops: 3 })
    assert.ok(!result.has('agent:nestjs'), 'le noeud de départ ne doit pas apparaître dans le résultat')
  })
})

// ═══════════════════════════════════════════════════════════════════════════════
// KnowledgeGraph — PageRank
// ═══════════════════════════════════════════════════════════════════════════════

describe('KnowledgeGraph — PageRank', () => {
  test('pageRank retourne une Map avec tous les noeuds', () => {
    const g = freshGraph()
    g.addEdge('agent:nestjs',  'phase:backend',  'WIN_RATE')
    g.addEdge('agent:tester',  'phase:backend',  'WIN_RATE')
    g.addEdge('agent:nestjs',  'phase:frontend', 'WIN_RATE')

    const ranks = g.pageRank({ iterations: 10, damping: 0.85 })
    assert.ok(ranks instanceof Map, 'pageRank doit retourner une Map')
    // Tous les noeuds présents dans le graphe doivent avoir un score
    for (const id of ['agent:nestjs', 'agent:tester', 'phase:backend', 'phase:frontend']) {
      assert.ok(ranks.has(id), `noeud ${id} doit être dans le résultat pageRank`)
    }
  })

  test('tous les scores pageRank somment approximativement à 1', () => {
    const g = freshGraph()
    g.addEdge('agent:nestjs', 'phase:backend',  'WIN_RATE')
    g.addEdge('agent:tester', 'phase:backend',  'WIN_RATE')
    g.addEdge('agent:drf',    'phase:frontend', 'WIN_RATE')

    const ranks = g.pageRank({ iterations: 30, damping: 0.85 })
    const total = [...ranks.values()].reduce((sum, v) => sum + v, 0)
    assert.ok(
      Math.abs(total - 1.0) < 0.01,
      `la somme des scores pageRank doit être ≈ 1, obtenu ${total}`
    )
  })

  test('noeud avec plus d\'arêtes entrantes obtient un score plus élevé', () => {
    const g = freshGraph()
    // phase:backend reçoit 3 arêtes, phase:frontend reçoit 1
    g.addEdge('agent:nestjs', 'phase:backend',  'WIN_RATE')
    g.addEdge('agent:tester', 'phase:backend',  'WIN_RATE')
    g.addEdge('agent:drf',    'phase:backend',  'WIN_RATE')
    g.addEdge('agent:nestjs', 'phase:frontend', 'WIN_RATE')

    const ranks = g.pageRank({ iterations: 50, damping: 0.85 })
    const backendScore  = ranks.get('phase:backend')
    const frontendScore = ranks.get('phase:frontend')
    assert.ok(
      backendScore > frontendScore,
      `phase:backend (${backendScore}) doit avoir un score > phase:frontend (${frontendScore})`
    )
  })
})

// ═══════════════════════════════════════════════════════════════════════════════
// KnowledgeGraph — scoreAgentPhase
// ═══════════════════════════════════════════════════════════════════════════════

describe('KnowledgeGraph — scoreAgentPhase', () => {
  test('retourne 0 pour un agent/phase inconnu', () => {
    const g = freshGraph()
    const score = g.scoreAgentPhase('nestjs', 'backend')
    assert.strictEqual(score, 0)
  })

  test('retourne > 0 après aggregate success', () => {
    const g = freshGraph()
    g.aggregate('nestjs', 'backend', 'success')
    const score = g.scoreAgentPhase('nestjs', 'backend')
    assert.ok(score > 0, `score doit être > 0 après un succès, obtenu ${score}`)
    assert.ok(score <= 1, `score doit être ≤ 1, obtenu ${score}`)
  })

  test('le score augmente avec plusieurs succès', () => {
    const g = freshGraph()
    g.aggregate('nestjs', 'backend', 'success')
    const score1 = g.scoreAgentPhase('nestjs', 'backend')
    g.aggregate('nestjs', 'backend', 'success')
    g.aggregate('nestjs', 'backend', 'success')
    const score3 = g.scoreAgentPhase('nestjs', 'backend')
    assert.ok(
      score3 >= score1,
      `score après 3 succès (${score3}) doit être ≥ score après 1 succès (${score1})`
    )
  })

  test('aggregate failure crée une arête ANTI_CORRÈLE', () => {
    const g = freshGraph()
    g.aggregate('nestjs', 'backend', 'failure')
    const edge = g.getEdge('agent:nestjs', 'phase:backend', 'ANTI_CORRÈLE')
    assert.ok(edge !== null, 'une arête ANTI_CORRÈLE doit être créée après un failure')
    assert.ok(edge.weight > 0)
  })
})

// ═══════════════════════════════════════════════════════════════════════════════
// KnowledgeGraph — toJSON / fromJSON
// ═══════════════════════════════════════════════════════════════════════════════

describe('KnowledgeGraph — toJSON / fromJSON', () => {
  test('toJSON retourne un objet avec tableaux nodes et edges', () => {
    const g = freshGraph()
    g.addNode('agent:nestjs', 'agent', 'NestJS', {})
    g.addEdge('agent:nestjs', 'phase:backend', 'WIN_RATE', 0.9)

    const json = g.toJSON()
    assert.ok(Array.isArray(json.nodes), 'nodes doit être un tableau')
    assert.ok(Array.isArray(json.edges), 'edges doit être un tableau')
    assert.ok(json.nodes.length >= 1)
    assert.ok(json.edges.length >= 1)
  })

  test('fromJSON restaure le bon nombre de noeuds', () => {
    const g = freshGraph()
    g.addNode('agent:nestjs',  'agent', 'NestJS',  {})
    g.addNode('agent:tester',  'agent', 'Tester',  {})
    g.addNode('phase:backend', 'phase', 'Backend', {})

    const json  = g.toJSON()
    const g2    = KnowledgeGraph.fromJSON(json)
    assert.ok(g2 instanceof KnowledgeGraph, 'fromJSON doit retourner une instance KnowledgeGraph')
    // Les 3 noeuds doivent être présents
    assert.ok(g2.getNode('agent:nestjs')  !== null)
    assert.ok(g2.getNode('agent:tester')  !== null)
    assert.ok(g2.getNode('phase:backend') !== null)
  })

  test('fromJSON restaure le bon nombre d\'arêtes', () => {
    const g = freshGraph()
    g.addEdge('agent:nestjs',  'phase:backend',  'WIN_RATE',   0.8)
    g.addEdge('agent:tester',  'phase:specs',    'A_RÉSOLU',   0.6)
    g.addEdge('phase:backend', 'phase:frontend', 'PRÉCÈDE',    1.0)

    const json = g.toJSON()
    const g2   = KnowledgeGraph.fromJSON(json)

    assert.ok(g2.getEdge('agent:nestjs',  'phase:backend',  'WIN_RATE')  !== null)
    assert.ok(g2.getEdge('agent:tester',  'phase:specs',    'A_RÉSOLU')  !== null)
    assert.ok(g2.getEdge('phase:backend', 'phase:frontend', 'PRÉCÈDE')   !== null)
  })

  test('round-trip préserve le résultat de scoreAgentPhase', () => {
    const g = freshGraph()
    g.aggregate('nestjs', 'backend', 'success')
    g.aggregate('nestjs', 'backend', 'success')
    const scoreBefore = g.scoreAgentPhase('nestjs', 'backend')

    const g2         = KnowledgeGraph.fromJSON(g.toJSON())
    const scoreAfter = g2.scoreAgentPhase('nestjs', 'backend')

    assert.ok(
      Math.abs(scoreBefore - scoreAfter) < 1e-9,
      `score avant=${scoreBefore} après round-trip=${scoreAfter} — doit être identique`
    )
  })
})

// ═══════════════════════════════════════════════════════════════════════════════
// graph-builder.js — buildFromBankState / buildFromPipelines / saveGraph / loadGraph
// ═══════════════════════════════════════════════════════════════════════════════

describe('graph-builder — buildFromBankState', () => {
  let builder

  before(() => {
    mkdirSync(join(TMP, 'coordinator'), { recursive: true })
    delete require.cache[require.resolve(GRAPH_BUILDER_JS)]
    builder = require(GRAPH_BUILDER_JS)
  })

  after(() => {
    try { rmSync(TMP, { recursive: true }) } catch {}
  })

  test('buildFromBankState retourne une instance KnowledgeGraph', async () => {
    const bankState = {
      version: 1,
      trajectories: [
        {
          id: 'traj-001',
          ts: new Date().toISOString(),
          phase: 'backend',
          agent: 'nestjs',
          verdict: 'success',
          summary: 'test summary',
          tags: ['backend', 'nestjs']
        }
      ]
    }
    const bankPath = join(TMP, 'bank-state-test.json')
    writeFileSync(bankPath, JSON.stringify(bankState))

    const graph = await builder.buildFromBankState(bankPath)
    assert.ok(graph instanceof KnowledgeGraph, 'doit retourner une KnowledgeGraph')
  })

  test('buildFromBankState crée des noeuds pour agents et phases', async () => {
    const bankState = {
      version: 1,
      trajectories: [
        {
          id: 'traj-002',
          ts: new Date().toISOString(),
          phase: 'specs',
          agent: 'tester',
          verdict: 'success',
          summary: 'TDD specs',
          tags: []
        },
        {
          id: 'traj-003',
          ts: new Date().toISOString(),
          phase: 'schema',
          agent: 'db',
          verdict: 'success',
          summary: 'DB schema',
          tags: []
        }
      ]
    }
    const bankPath = join(TMP, 'bank-state-agents.json')
    writeFileSync(bankPath, JSON.stringify(bankState))

    const graph = await builder.buildFromBankState(bankPath)
    assert.ok(graph.getNode('agent:tester') !== null, 'agent:tester doit exister')
    assert.ok(graph.getNode('agent:db')     !== null, 'agent:db doit exister')
    assert.ok(graph.getNode('phase:specs')  !== null, 'phase:specs doit exister')
    assert.ok(graph.getNode('phase:schema') !== null, 'phase:schema doit exister')
  })

  test('buildFromBankState avec fichier vide/trajectories vide retourne un graphe vide', async () => {
    const bankState = { version: 1, trajectories: [] }
    const bankPath = join(TMP, 'bank-state-empty.json')
    writeFileSync(bankPath, JSON.stringify(bankState))

    const graph = await builder.buildFromBankState(bankPath)
    assert.ok(graph instanceof KnowledgeGraph)
    const json = graph.toJSON()
    assert.strictEqual(json.nodes.length, 0, 'graphe vide : 0 noeuds')
    assert.strictEqual(json.edges.length, 0, 'graphe vide : 0 arêtes')
  })
})

describe('graph-builder — buildFromPipelines', () => {
  let builder

  before(() => {
    mkdirSync(join(TMP, 'coordinator'), { recursive: true })
    delete require.cache[require.resolve(GRAPH_BUILDER_JS)]
    builder = require(GRAPH_BUILDER_JS)
  })

  test('buildFromPipelines retourne une instance KnowledgeGraph', async () => {
    const pipelines = {
      feature: {
        description: 'feature pipeline',
        phases: [
          { id: 'schema',  label: 'Schema',   agent: 'db',      depends: [] },
          { id: 'backend', label: 'Backend',  agent: 'nestjs',  depends: ['schema'] }
        ]
      }
    }
    const pipPath = join(TMP, 'pipelines-test.json')
    writeFileSync(pipPath, JSON.stringify(pipelines))

    const graph = await builder.buildFromPipelines(pipPath)
    assert.ok(graph instanceof KnowledgeGraph, 'doit retourner une KnowledgeGraph')
  })

  test('buildFromPipelines crée des arêtes PRÉCÈDE entre phases dépendantes', async () => {
    const pipelines = {
      feature: {
        phases: [
          { id: 'schema',  label: 'Schema',  agent: 'db',     depends: [] },
          { id: 'specs',   label: 'Specs',   agent: 'tester', depends: ['schema'] },
          { id: 'backend', label: 'Backend', agent: 'nestjs', depends: ['specs'] }
        ]
      }
    }
    const pipPath = join(TMP, 'pipelines-deps.json')
    writeFileSync(pipPath, JSON.stringify(pipelines))

    const graph = await builder.buildFromPipelines(pipPath)
    const edge = graph.getEdge('phase:schema', 'phase:specs', 'PRÉCÈDE')
    assert.ok(edge !== null, 'arête PRÉCÈDE entre schema et specs doit exister')
  })
})

describe('graph-builder — saveGraph / loadGraph', () => {
  let builder

  before(() => {
    mkdirSync(join(TMP, 'coordinator'), { recursive: true })
    delete require.cache[require.resolve(GRAPH_BUILDER_JS)]
    builder = require(GRAPH_BUILDER_JS)
  })

  test('saveGraph écrit le fichier sur disque', async () => {
    const g = new KnowledgeGraph()
    g.addNode('agent:nestjs', 'agent', 'NestJS', {})
    g.addEdge('agent:nestjs', 'phase:backend', 'WIN_RATE', 0.9)

    const graphPath = join(TMP, 'graph-saved.json')
    await builder.saveGraph(g, graphPath)

    assert.ok(existsSync(graphPath), 'fichier graph doit exister sur disque')
  })

  test('loadGraph restaure une KnowledgeGraph identique à celle sauvegardée', async () => {
    const g = new KnowledgeGraph()
    g.addEdge('agent:tester', 'phase:specs', 'A_RÉSOLU', 0.7)

    const graphPath = join(TMP, 'graph-roundtrip.json')
    await builder.saveGraph(g, graphPath)
    const g2 = await builder.loadGraph(graphPath)

    assert.ok(g2 instanceof KnowledgeGraph, 'loadGraph doit retourner une KnowledgeGraph')
    const edge = g2.getEdge('agent:tester', 'phase:specs', 'A_RÉSOLU')
    assert.ok(edge !== null, 'arête A_RÉSOLU doit être restaurée')
    assert.ok(Math.abs(edge.weight - 0.7) < 1e-9, 'poids doit être préservé')
  })
})

describe('graph-builder — loadOrBuild (cache-aware)', () => {
  let builder

  before(() => {
    mkdirSync(join(TMP, 'coordinator'), { recursive: true })
    delete require.cache[require.resolve(GRAPH_BUILDER_JS)]
    builder = require(GRAPH_BUILDER_JS)
  })

  test('loadOrBuild charge depuis le cache si le fichier existe déjà', async () => {
    // Préparer un graphe pré-sauvegardé
    const g = new KnowledgeGraph()
    g.addNode('agent:cached', 'agent', 'Cached', {})
    const graphPath   = join(TMP, 'graph-cache.json')
    const bankPath    = join(TMP, 'bank-state-noop.json')
    const pipPath     = join(TMP, 'pipelines-noop.json')

    writeFileSync(bankPath, JSON.stringify({ version: 1, trajectories: [] }))
    writeFileSync(pipPath,  JSON.stringify({}))
    await builder.saveGraph(g, graphPath)

    const g2 = await builder.loadOrBuild({
      graphPath,
      bankStatePath: bankPath,
      pipelinesPath: pipPath
    })
    assert.ok(g2 instanceof KnowledgeGraph)
    assert.ok(g2.getNode('agent:cached') !== null, 'doit charger depuis le cache')
  })

  test('loadOrBuild construit le graphe si le cache est absent', async () => {
    const bankState = {
      version: 1,
      trajectories: [
        {
          id: 'traj-build',
          ts: new Date().toISOString(),
          phase: 'backend',
          agent: 'nestjs',
          verdict: 'success',
          summary: 'built from scratch',
          tags: []
        }
      ]
    }
    const bankPath  = join(TMP, 'bank-state-build.json')
    const pipPath   = join(TMP, 'pipelines-build.json')
    const graphPath = join(TMP, 'graph-missing.json')  // n'existe pas

    writeFileSync(bankPath, JSON.stringify(bankState))
    writeFileSync(pipPath, JSON.stringify({}))

    const g = await builder.loadOrBuild({ graphPath, bankStatePath: bankPath, pipelinesPath: pipPath })
    assert.ok(g instanceof KnowledgeGraph, 'doit retourner une KnowledgeGraph construite')
  })
})

// ── KnowledgeGraph — scoreHybrid (PageRank) ───────────────────────────────────

describe('KnowledgeGraph — scoreHybrid', () => {
  test('scoreHybrid retourne même score que scoreAgentPhase si pageRankScores absent', () => {
    const g = new KnowledgeGraph()
    g.aggregate('nestjs', 'backend', 'success')
    const local  = g.scoreAgentPhase('nestjs', 'backend')
    const hybrid = g.scoreHybrid('nestjs', 'backend')
    assert.equal(hybrid, local)
  })

  test('scoreHybrid retourne même score avec Map vide', () => {
    const g = new KnowledgeGraph()
    g.aggregate('nestjs', 'backend', 'success')
    const local  = g.scoreAgentPhase('nestjs', 'backend')
    const hybrid = g.scoreHybrid('nestjs', 'backend', new Map())
    assert.equal(hybrid, local)
  })

  test('scoreHybrid avec PageRank non nul booste le score', () => {
    const g = new KnowledgeGraph()
    g.aggregate('nestjs', 'backend', 'success')
    const local  = g.scoreAgentPhase('nestjs', 'backend')
    const pr = new Map([['agent:nestjs', 0.5]])
    const hybrid = g.scoreHybrid('nestjs', 'backend', pr)
    assert.ok(hybrid >= local, `hybrid ${hybrid} >= local ${local}`)
  })

  test('scoreHybrid reste ≤ 1 même avec PageRank très élevé', () => {
    const g = new KnowledgeGraph()
    g.aggregate('nestjs', 'backend', 'success')
    g.aggregate('nestjs', 'backend', 'success')
    g.aggregate('nestjs', 'backend', 'success')
    const pr = new Map([['agent:nestjs', 999]])
    const hybrid = g.scoreHybrid('nestjs', 'backend', pr)
    assert.ok(hybrid <= 1, `scoreHybrid doit rester ≤ 1, got ${hybrid}`)
  })
})

// ── scoreAgentPhase — net win rate ────────────────────────────────────────────

describe('KnowledgeGraph — scoreAgentPhase net win rate', () => {
  test('score avec mix succès/échecs reflète le taux net', () => {
    const g = new KnowledgeGraph()
    g.aggregate('nestjs', 'backend', 'success')
    g.aggregate('nestjs', 'backend', 'failure')
    // net = 1 succès / (1+1) = 0.5 → win rate 50%
    const score = g.scoreAgentPhase('nestjs', 'backend')
    assert.ok(score > 0 && score < 0.8, `score ${score} doit être modéré avec 50% succès`)
  })

  test('score pur succès > score mixte', () => {
    const g1 = new KnowledgeGraph()
    g1.aggregate('nestjs', 'backend', 'success')
    g1.aggregate('nestjs', 'backend', 'success')
    const pureScore = g1.scoreAgentPhase('nestjs', 'backend')

    const g2 = new KnowledgeGraph()
    g2.aggregate('nestjs', 'backend', 'success')
    g2.aggregate('nestjs', 'backend', 'failure')
    const mixedScore = g2.scoreAgentPhase('nestjs', 'backend')

    assert.ok(pureScore > mixedScore, `pur ${pureScore} > mixte ${mixedScore}`)
  })
})

// ── graph-builder — buildFromSQLite ──────────────────────────────────────────

describe('graph-builder — buildFromSQLite (graceful sans DB)', () => {
  test('retourne un graphe vide si le fichier db est absent', async () => {
    const builder = require(GRAPH_BUILDER_JS)
    const g = builder.buildFromSQLite(join(TMP, 'nonexistent.db'))
    assert.ok(g instanceof KnowledgeGraph)
    assert.equal(g.nodes.size, 0)
  })
})
