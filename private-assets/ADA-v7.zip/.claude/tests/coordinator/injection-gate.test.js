#!/usr/bin/env node
'use strict'
/**
 * injection-gate.test.js — Gate d'injection à DEUX ÉTAGES du recall ReasoningBank.
 *
 * Motivation : `ada bank recall` injecte du contexte sur des heuristiques de
 * similarité seules — parfois du hors-sujet qui gaspille le budget contexte. Ce
 * gate ajoute un SECOND étage déterministe (chevauchement de TOKENS CONCRETS) qui
 * confirme la pertinence AVANT injection et module le niveau (NONE / HINT / FULL).
 *
 * Le gate agit EN AMONT sur la PERTINENCE (filtre/module ce qui entre dans le
 * bloc), JAMAIS en aval sur la taille du bloc formaté (garde par taille déjà
 * rejetée : le format à puces est porteur, vérifié par bank-recall/conventions).
 *
 * Deux niveaux de test :
 *   (A) Le module pur `injection-gate.js` — zéro dépendance, déterministe.
 *   (B) Intégration bank.js — chemin recall-block réel + flag ADA_INJECTION_GATE.
 */

const { test, describe, before, after, beforeEach } = require('node:test')
const assert = require('node:assert/strict')
const { mkdirSync, rmSync, existsSync, writeFileSync, unlinkSync } = require('fs')
const { join } = require('path')

const GATE_JS = join(__dirname, '../../coordinator/injection-gate.js')
const { gateRecall, extractConcreteTokens } = require(GATE_JS)

// Fabrique de candidats (forme minimale telle que produite par retrieve/_recallConventions).
const conv = (summary, extra = {}) => ({ summary, tags: ['convention', ...(extra.tags || [])], ...extra })
const lesson = (summary, extra = {}) => ({ summary, tags: extra.tags || ['backend'], ...extra })

// ─── (A) Extraction de tokens concrets : identifiants techniques vs stopwords ───

describe('extractConcreteTokens — tokens concrets ≥4 chars, stopwords FR/EN exclus', () => {
  test('garde les identifiants techniques (fichiers, symboles, stack)', () => {
    const toks = extractConcreteTokens('créer une migration prisma pour la table workspace')
    assert.ok(toks.includes('migration'), 'migration gardé')
    assert.ok(toks.includes('prisma'), 'prisma gardé')
    assert.ok(toks.includes('table'), 'table gardé')
    assert.ok(toks.includes('workspace'), 'workspace gardé')
  })

  test('jette les stopwords FR/EN et les mots < 4 chars', () => {
    const toks = extractConcreteTokens('the api est un peu sur les DTO')
    assert.ok(!toks.includes('the'), 'stopword EN "the" exclu')
    assert.ok(!toks.includes('les'), 'stopword FR "les" exclu')
    assert.ok(!toks.includes('api'), 'mot 3 chars "api" exclu (< 4)')
    assert.ok(!toks.includes('dto'), 'mot 3 chars "dto" exclu (< 4)')
    assert.ok(!toks.includes('un'), 'mot court exclu')
  })

  test('extrait des noms de fichiers / symboles composés', () => {
    const toks = extractConcreteTokens('bug dans bank.js sur workspace_id de UserService')
    assert.ok(toks.includes('bank'), 'nom de fichier segmenté')
    assert.ok(toks.includes('workspace'), 'snake_case segmenté')
    assert.ok(toks.includes('userservice'), 'symbole minusculé')
  })

  test('robuste aux entrées vides / non-string', () => {
    assert.deepEqual(extractConcreteTokens(''), [])
    assert.deepEqual(extractConcreteTokens(null), [])
    assert.deepEqual(extractConcreteTokens(undefined), [])
  })
})

// ─── (A) Décision NONE / HINT / FULL ────────────────────────────────────────────

describe('gateRecall — niveau FULL quand une leçon pertinente est confirmée', () => {
  test('candidat pertinent (chevauchement de tokens concrets) → FULL + gardé', () => {
    const candidates = [
      lesson('migration prisma appliquée sur la table workspace en expand-contract'),
    ]
    const r = gateRecall('créer une migration prisma table workspace', candidates)
    assert.equal(r.level, 'FULL', 'une leçon on-topic confirmée déclenche FULL')
    assert.equal(r.kept.length, 1)
    assert.equal(r.dropped.length, 0)
    assert.ok(r.reasons.length >= 1, 'reasons documente la décision')
  })

  test('deux candidats confirmés → FULL', () => {
    const candidates = [
      conv('toute migration passe par prisma migrate deploy'),
      lesson('migration workspace testée avec pgtap'),
    ]
    const r = gateRecall('migration prisma workspace', candidates)
    assert.equal(r.level, 'FULL')
    assert.equal(r.kept.length, 2)
  })
})

describe('gateRecall — hors-sujet → NONE, tout droppé avec reasons', () => {
  test('recette de cuisine vs candidats techniques → NONE', () => {
    const candidates = [
      conv('RLS Supabase obligatoire sur toutes les tables'),
      lesson('healthcheck docker compose postgres configuré'),
    ]
    const r = gateRecall('recette de gâteau au chocolat avec des fraises', candidates)
    assert.equal(r.level, 'NONE', 'aucun token concret partagé → NONE')
    assert.equal(r.kept.length, 0, 'rien injecté')
    assert.equal(r.dropped.length, 2, 'les deux candidats droppés')
    assert.ok(r.reasons.length >= 1, 'reasons non vide')
  })

  test('liste de candidats vide → NONE', () => {
    const r = gateRecall('créer une migration', [])
    assert.equal(r.level, 'NONE')
    assert.deepEqual(r.kept, [])
  })

  test('tâche vide → NONE', () => {
    const r = gateRecall('', [conv('RLS Supabase obligatoire')])
    assert.equal(r.level, 'NONE')
  })
})

describe('gateRecall — conventions préservées par défaut (alwaysKeepConventions)', () => {
  test('convention NON confirmée token-wise mais tâche on-topic → conv gardée (HINT)', () => {
    // "RLS" ne partage aucun token concret ≥4 avec la tâche, mais un AUTRE candidat
    // confirme que la tâche est on-topic → la convention ride-along (règle projet).
    const candidates = [
      conv('RLS Supabase obligatoire sur toutes les tables'),      // pas de token partagé
      lesson('migration workspace appliquée en expand-contract'),  // confirme on-topic
    ]
    const r = gateRecall('migration workspace expand-contract', candidates)
    assert.notEqual(r.level, 'NONE', 'tâche on-topic → pas NONE')
    assert.ok(r.kept.includes(candidates[0]), 'la convention RLS est conservée (ride-along)')
    assert.ok(r.kept.includes(candidates[1]), 'la leçon confirmée est conservée')
  })

  test('convention hors-sujet ET tâche globalement hors-sujet → NONE (pas de ride-along)', () => {
    // Le ride-along ne s'active QUE si la tâche est on-topic : sinon une convention
    // serait injectée pour une recette de cuisine. Ici rien n'est confirmé → NONE.
    const candidates = [conv('RLS Supabase obligatoire sur toutes les tables')]
    const r = gateRecall('recette de gâteau au chocolat', candidates)
    assert.equal(r.level, 'NONE', 'aucune confirmation → convention non injectée')
    assert.equal(r.kept.length, 0)
  })

  test('alwaysKeepConventions:false → convention gatée comme une leçon', () => {
    const candidates = [
      conv('RLS Supabase obligatoire sur toutes les tables'),
      lesson('migration workspace expand-contract'),
    ]
    const r = gateRecall('migration workspace expand-contract', candidates, { alwaysKeepConventions: false })
    assert.ok(!r.kept.includes(candidates[0]), 'convention non confirmée droppée quand alwaysKeep=false')
    assert.ok(r.kept.includes(candidates[1]), 'la leçon confirmée reste')
  })
})

describe('gateRecall — modulation HINT (faible) vs FULL (fort)', () => {
  test('seule une convention confirmée, aucune leçon forte → HINT', () => {
    const candidates = [conv('migration prisma via migrate deploy')]
    const r = gateRecall('migration prisma', candidates)
    assert.equal(r.level, 'HINT', 'une seule convention confirmée → HINT (indice)')
    assert.equal(r.kept.length, 1)
  })

  test('une leçon (non-convention) confirmée → FULL', () => {
    const candidates = [lesson('migration prisma via migrate deploy')]
    const r = gateRecall('migration prisma', candidates)
    assert.equal(r.level, 'FULL', 'une leçon confirmée déclenche FULL')
  })
})

describe('gateRecall — étage 1 (score) consommé, jamais recalculé', () => {
  test('candidat sans token partagé MAIS score ≥ seuil → confirmé (stage 1)', () => {
    // Aucun token concret partagé, mais le ranking amont a déjà stampé un _content
    // élevé (ex: match sémantique embedding). Le gate le consomme.
    const candidates = [{ summary: 'contenu opaque sans mots communs', tags: ['backend'], _content: 5 }]
    const r = gateRecall('sujet totalement different', candidates)
    assert.equal(r.level, 'FULL', 'score amont élevé confirme le candidat sans recalcul')
    assert.equal(r.kept.length, 1)
  })

  test('candidat sans token partagé ET score sous le seuil → droppé', () => {
    const candidates = [{ summary: 'contenu opaque sans mots communs', tags: ['backend'], _content: 0 }]
    const r = gateRecall('sujet totalement different', candidates)
    assert.equal(r.level, 'NONE')
    assert.equal(r.dropped.length, 1)
  })
})

// ─── (B) Intégration bank.js — chemin recall-block + flag ADA_INJECTION_GATE ─────

const BANK_JS = join(__dirname, '../../coordinator/bank.js')
const TMP = join(__dirname, '../../..', '.test-tmp-injection-gate')

function loadBank() {
  delete require.cache[require.resolve(BANK_JS)]
  process.env.CLAUDE_CONFIG_DIR = TMP
  process.env.OLLAMA_URL = 'http://127.0.0.1:1' // Ollama down déterministe → TF-IDF dégradé
  const mod = require(BANK_JS)
  mod._resetDB()
  return mod
}
function cleanDB() {
  const dbPath = join(TMP, 'coordinator', 'bank.db')
  for (const f of [dbPath, dbPath + '-wal', dbPath + '-shm']) {
    if (existsSync(f)) { try { unlinkSync(f) } catch {} }
  }
}

describe('(B) intégration bank.js — recall-block réel', () => {
  let bank
  before(() => { mkdirSync(join(TMP, 'coordinator'), { recursive: true }) })
  after(() => {
    try { rmSync(TMP, { recursive: true }) } catch {}
    delete process.env.ADA_INJECTION_GATE
  })
  beforeEach(() => {
    delete process.env.ADA_INJECTION_GATE // défaut : gate ACTIF
    const f = join(TMP, 'coordinator', 'bank-state.json')
    writeFileSync(f, JSON.stringify({ version: 1, trajectories: [], insights: null, updatedAt: new Date().toISOString() }, null, 2))
    cleanDB()
    bank = loadBank()
  })

  test('tâche hors-sujet (recette) → bloc VIDE (NONE)', () => {
    bank.store('convention', 'project', 'success', 'RLS Supabase obligatoire sur toutes les tables', { tags: ['convention'] })
    bank.store('backend', 'nestjs', 'success', 'migration prisma appliquée sur workspace', {})
    const block = bank.buildRecallBlock('recette de gâteau au chocolat fraises')
    assert.equal(block, '', 'aucun contexte injecté pour une tâche hors-sujet')
  })

  test('tâche alignée (migration) → bloc NON vide, format à puces préservé', () => {
    bank.store('convention', 'project', 'success', 'Toute migration SQL suit expand-contract sans downtime', { tags: ['convention'] })
    const block = bank.buildRecallBlock('créer une migration SQL sur la table workspace')
    assert.ok(block.includes('[CONNAISSANCE PROJET — ReasoningBank]'), 'en-tête présent')
    assert.ok(block.includes('Conventions:'), 'section conventions présente')
    assert.match(block, /^- /m, 'format à puces préservé (contrat de format)')
    assert.match(block, /expand-contract/, 'la convention pertinente est injectée')
  })

  test('flag ADA_INJECTION_GATE=off → comportement identique à avant (gate bypassé)', () => {
    bank.store('convention', 'project', 'success', 'RLS Supabase obligatoire sur toutes les tables', { tags: ['convention'] })
    bank.store('backend', 'nestjs', 'success', 'migration prisma appliquée sur workspace', {})

    // Gate actif : recette → vide.
    const gated = bank.buildRecallBlock('recette de gâteau au chocolat fraises')
    assert.equal(gated, '', 'gate actif : bloc vide sur hors-sujet')

    // Gate désactivé : on retombe sur le comportement d'origine (_assembleRecallBlock seul).
    process.env.ADA_INJECTION_GATE = 'off'
    const ungated = bank.buildRecallBlock('recette de gâteau au chocolat fraises')
    // _assembleRecallBlock renvoie '' si aucun overlap lexical → identique ici, mais la
    // décision NE PASSE PAS par le gate (vérifié par le chemin migration ci-dessous).
    const gatedMig = (() => { delete process.env.ADA_INJECTION_GATE; return bank.buildRecallBlock('migration prisma workspace') })()
    process.env.ADA_INJECTION_GATE = 'off'
    const ungatedMig = bank.buildRecallBlock('migration prisma workspace')
    assert.equal(typeof ungated, 'string')
    assert.ok(ungatedMig.includes('migration') || ungatedMig.includes('Conventions:'), 'gate off : bloc produit par la voie historique')
    assert.ok(gatedMig.length > 0, 'gate on : migration reste on-topic')
  })

  test('tâche ALIGNÉE : gate on ≡ gate off (le gate ne modifie pas un bloc on-topic)', () => {
    // Garde anti-divergence : sur une tâche pertinente, le gate laisse passer les
    // mêmes candidats → _assembleRecallBlock produit un bloc BYTE-IDENTIQUE à l'historique.
    bank.store('convention', 'project', 'success', 'Toute migration SQL suit expand-contract sans downtime', { tags: ['convention'] })
    bank.store('backend', 'nestjs', 'success', 'migration workspace appliquée en expand-contract testée pgtap', {})

    delete process.env.ADA_INJECTION_GATE
    const gated = bank.buildRecallBlock('créer une migration SQL sur la table workspace')
    process.env.ADA_INJECTION_GATE = 'off'
    const ungated = bank.buildRecallBlock('créer une migration SQL sur la table workspace')
    delete process.env.ADA_INJECTION_GATE

    assert.ok(gated.length > 0, 'la tâche alignée produit bien un bloc')
    assert.equal(gated, ungated, 'gate on et gate off produisent le MÊME bloc pour une tâche on-topic')
    assert.match(gated, /^- /m, 'format à puces préservé')
  })

  test('async : recall-block dégradé (TF-IDF) — hors-sujet → vide, aligné → non vide', async () => {
    bank.store('convention', 'project', 'success', 'RLS Supabase obligatoire sur toutes les tables', { tags: ['convention'] })
    bank.store('backend', 'nestjs', 'success', 'migration prisma appliquée sur workspace', {})

    const off = await bank.buildRecallBlockAsync('recette de tarte aux pommes caramel')
    assert.equal(off.block, '', 'async : hors-sujet gaté → bloc vide')
    assert.equal(off.degraded, true, 'Ollama down → dégradé signalé (inchangé par le gate)')

    const on = await bank.buildRecallBlockAsync('migration prisma workspace table')
    assert.ok(on.block.includes('RLS Supabase') || on.block.includes('migration'), 'async : aligné → bloc non vide')
  })
})
