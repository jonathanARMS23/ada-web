#!/usr/bin/env node
'use strict'
/**
 * tests/coordinator/ipc-emit.test.js — coordinator/ipc-emit.js (0 test avant
 * l'audit ROI Tier C du 2026-08-28 — module de sécurité : signature HMAC des
 * événements + secret fail-closed, jamais exercé).
 *
 * Couvre : loadIpcSecret (env var, fichier, auto-génération 0600), signEvent
 * (signature canonique, dégradation sans secret), emitIPC (log NDJSON + socket).
 */

const { test, describe, before, after, beforeEach } = require('node:test')
const assert = require('node:assert/strict')
const net    = require('net')
const { mkdirSync, rmSync, existsSync, readFileSync, statSync, writeFileSync } = require('fs')
const { join } = require('path')
const os = require('os')

const TMP = join(__dirname, '../../..', '.test-tmp-ipc-emit')
const IPC_EMIT_JS = join(__dirname, '../../coordinator/ipc-emit.js')
const IPC_CANONICAL_JS = join(__dirname, '../../coordinator/ipc-canonical.js')

function loadFresh(env) {
  delete require.cache[require.resolve(IPC_EMIT_JS)]
  delete require.cache[require.resolve(IPC_CANONICAL_JS)]
  const saved = {}
  for (const [k, v] of Object.entries(env)) { saved[k] = process.env[k]; process.env[k] = v }
  const mod = require(IPC_EMIT_JS)
  return { mod, restore: () => { for (const [k, v] of Object.entries(saved)) { if (v === undefined) delete process.env[k]; else process.env[k] = v } } }
}

before(() => { mkdirSync(TMP, { recursive: true }) })
after(() => { try { rmSync(TMP, { recursive: true }) } catch {} })

// ─── loadIpcSecret ─────────────────────────────────────────────────────────

describe('loadIpcSecret', () => {
  test('ADA_IPC_HMAC_SECRET (env) a priorité sur tout le reste', () => {
    const { mod, restore } = loadFresh({ ADA_IPC_HMAC_SECRET: 'env-secret-value', HOME: TMP })
    assert.equal(mod.loadIpcSecret(), 'env-secret-value')
    restore()
  })

  test('sans env var, auto-génère un secret 0600 dans ~/.ada/ipc.secret (fail-closed, jamais null)', () => {
    const home = join(TMP, `home-${Date.now()}`)
    mkdirSync(home, { recursive: true })
    const { mod, restore } = loadFresh({ HOME: home, ADA_IPC_HMAC_SECRET: '' })
    delete process.env.ADA_IPC_HMAC_SECRET
    const secret = mod.loadIpcSecret()
    assert.ok(secret && secret.length >= 32, 'un secret non-vide doit toujours être retourné (fail-closed)')
    const secretFile = join(home, '.ada', 'ipc.secret')
    assert.ok(existsSync(secretFile), 'le secret doit être persisté sur disque')
    const mode = statSync(secretFile).mode & 0o777
    assert.equal(mode, 0o600, `le fichier secret doit être 0600, reçu ${mode.toString(8)}`)
    restore()
  })

  test('un secret déjà présent sur disque est réutilisé, pas régénéré', () => {
    const home = join(TMP, `home-reuse-${Date.now()}`)
    mkdirSync(join(home, '.ada'), { recursive: true })
    writeFileSync(join(home, '.ada', 'ipc.secret'), 'secret-existant-sur-disque', { mode: 0o600 })
    const { mod, restore } = loadFresh({ HOME: home, ADA_IPC_HMAC_SECRET: '' })
    delete process.env.ADA_IPC_HMAC_SECRET
    assert.equal(mod.loadIpcSecret(), 'secret-existant-sur-disque')
    restore()
  })
})

// ─── signEvent ───────────────────────────────────────────────────────────────

describe('signEvent', () => {
  test('avec secret : la ligne NDJSON contient _sig, vérifiable via ipc-canonical', () => {
    const { mod, restore } = loadFresh({ ADA_IPC_HMAC_SECRET: 'sign-test-secret', HOME: TMP })
    const line = mod.signEvent({ id: 'evt-1', ts: 1000, type: 'test.event', payload: { a: 1 } })
    assert.ok(line.endsWith('\n'), 'la ligne doit se terminer par \\n')
    const parsed = JSON.parse(line)
    assert.ok(parsed._sig, 'un champ _sig doit être présent')

    const { verify } = require(IPC_CANONICAL_JS)
    assert.equal(verify(parsed, 'sign-test-secret'), true,
      'la signature doit être vérifiable avec le même secret')
    assert.equal(verify(parsed, 'mauvais-secret'), false,
      'la signature ne doit PAS être vérifiable avec un secret différent')
    restore()
  })

  test('sans secret disponible : émet l\'objet non signé (dégradation, pas de crash)', () => {
    // Simule l'absence totale de secret : HOME jetable + pas d'env var + fichier
    // secret non-inscriptible (répertoire inexistant en lecture seule impossible
    // à simuler proprement en CI) — on force via un module stub minimal à la place.
    const home = join(TMP, `home-nosecret-${Date.now()}`)
    // Rendre le répertoire .ada non-créable : pré-créer un FICHIER à sa place.
    mkdirSync(home, { recursive: true })
    writeFileSync(join(home, '.ada'), 'not-a-directory')
    const { mod, restore } = loadFresh({ HOME: home, ADA_IPC_HMAC_SECRET: '' })
    delete process.env.ADA_IPC_HMAC_SECRET
    assert.equal(mod.loadIpcSecret(), null, 'fixture : aucun secret possible (mkdir .ada échoue)')
    const line = mod.signEvent({ id: 'evt-2', ts: 2000, type: 'test.event', payload: {} })
    const parsed = JSON.parse(line)
    assert.equal(parsed._sig, undefined, 'sans secret, aucun _sig ne doit être ajouté')
    assert.equal(parsed.id, 'evt-2', 'l\'objet reste émis tel quel (dégradation, pas de perte d\'event)')
    restore()
  })
})

// ─── emitIPC ─────────────────────────────────────────────────────────────────

describe('emitIPC', () => {
  test('écrit une ligne NDJSON signée dans ADA_EVENTS_LOG', () => {
    const eventsLog = join(TMP, `events-${Date.now()}.ndjson`)
    const { mod, restore } = loadFresh({
      ADA_IPC_HMAC_SECRET: 'emit-test-secret', HOME: TMP,
      ADA_EVENTS_LOG: eventsLog, ADA_API_IPC_PATH: join(TMP, 'nonexistent.sock'),
    })
    mod.emitIPC('test.type', { hello: 'world' })
    assert.ok(existsSync(eventsLog), 'le fichier events.ndjson doit être créé')
    const lines = readFileSync(eventsLog, 'utf8').trim().split('\n')
    const last = JSON.parse(lines[lines.length - 1])
    assert.equal(last.type, 'test.type')
    assert.deepEqual(last.payload, { hello: 'world' })
    assert.ok(last._sig, 'l\'event journalisé doit être signé')
    restore()
  })

  test('un socket absent ne fait pas throw (best-effort, dégradation gracieuse)', () => {
    const eventsLog = join(TMP, `events-nosock-${Date.now()}.ndjson`)
    const { mod, restore } = loadFresh({
      ADA_IPC_HMAC_SECRET: 'emit-test-secret-2', HOME: TMP,
      ADA_EVENTS_LOG: eventsLog, ADA_API_IPC_PATH: join(TMP, 'definitely-not-a-socket.sock'),
    })
    assert.doesNotThrow(() => mod.emitIPC('test.type', {}))
    restore()
  })

  test('un serveur socket réel reçoit la ligne émise', async () => {
    const sockPath = join(TMP, `emit-${Date.now()}.sock`)
    const eventsLog = join(TMP, `events-realsock-${Date.now()}.ndjson`)
    const received = await new Promise((resolve, reject) => {
      const server = net.createServer(sock => {
        let buf = ''
        sock.on('data', d => { buf += d })
        sock.on('end', () => { server.close(); resolve(buf) })
      })
      server.on('error', reject)
      server.listen(sockPath, () => {
        const { mod, restore } = loadFresh({
          ADA_IPC_HMAC_SECRET: 'realsock-secret', HOME: TMP,
          ADA_EVENTS_LOG: eventsLog, ADA_API_IPC_PATH: sockPath,
        })
        mod.emitIPC('real.socket.test', { n: 42 })
        restore()
      })
    })
    const parsed = JSON.parse(received.trim())
    assert.equal(parsed.type, 'real.socket.test')
    assert.deepEqual(parsed.payload, { n: 42 })
  })
})
