#!/usr/bin/env node
'use strict'
/**
 * mutation-test.test.js — Mutation testing du scorer bench-v2 (ADR-021 F6).
 *
 * Ne teste QUE la couche PURE (lexer SQL + les 9 mutations + l'analyse des
 * verdicts) : aucune de ces fonctions ne touche Postgres. L'exécution réelle
 * (runDeliverable → bench-v2.scoreSqlDeliverable → psql) est volontairement hors
 * périmètre unitaire — c'est le rôle du CLI `run-all`, comme bench-v2.test.js
 * sépare déjà ses fonctions pures de son test d'intégration guardé.
 *
 * Le module mutation-test.js requiert bench-v2.js PARESSEUSEMENT : ces tests
 * passent donc même si bench-v2.js ou Postgres sont indisponibles.
 */
const { test, describe } = require('node:test')
const assert = require('node:assert/strict')

const M = require('../../coordinator/mutation-test.js')

// Livrable de référence minimal : 2 tables liées par FK, une contrainte nommée,
// une colonne text, un trigger, une policy — assez pour exercer les 9 mutations.
const SQL = `-- en-tête
CREATE TABLE orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

-- 2. lignes
CREATE TABLE order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL,
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  quantity int NOT NULL,
  CONSTRAINT order_items_qty_ck CHECK (quantity > 0)
);

CREATE TRIGGER trg_items BEFORE UPDATE ON order_items FOR EACH ROW EXECUTE FUNCTION noop();
`

// ── Lexer ─────────────────────────────────────────────────────────────────────
describe('splitStatements', () => {
  test('découpe les instructions de premier niveau', () => {
    const st = M.splitStatements('CREATE TABLE a (id int); ALTER TABLE a ADD x int;')
    assert.equal(st.length, 2)
    assert.match(st[0].text, /CREATE TABLE a/)
    assert.match(st[1].text, /ALTER TABLE a/)
  })

  test('ne coupe pas sur un `;` dans un corps dollar-quoté', () => {
    const sql = `CREATE FUNCTION f() RETURNS trigger AS $$ BEGIN a := 1; RETURN NEW; END $$ LANGUAGE plpgsql;\nCREATE TABLE t (id int);`
    const st = M.splitStatements(sql)
    assert.equal(st.length, 2)
    assert.match(st[0].text, /CREATE FUNCTION/)
    assert.match(st[1].text, /CREATE TABLE t/)
  })

  test('gère les tags dollar nommés ($fn$) et les `;` internes', () => {
    const sql = `CREATE FUNCTION g() RETURNS int AS $fn$ SELECT 1; $fn$ LANGUAGE sql;\nSELECT 2;`
    assert.equal(M.splitStatements(sql).length, 2)
  })

  test('ne coupe pas sur un `;` dans une chaîne ou un commentaire', () => {
    assert.equal(M.splitStatements(`SELECT 'a;b';`).length, 1)
    assert.equal(M.splitStatements(`-- pas ; ici\nSELECT 1;`).length, 1)
    assert.equal(M.splitStatements(`/* ni ; la */ SELECT 1;`).length, 1)
  })

  test("l'échappement '' ne termine pas la chaîne", () => {
    assert.equal(M.splitStatements(`SELECT 'a''b;c';`).length, 1)
  })

  test('les commentaires en tête restent solidaires de leur instruction', () => {
    const st = M.splitStatements(SQL)
    const items = st.find(s => /CREATE TABLE order_items/.test(s.text))
    assert.match(items.text, /-- 2\. lignes/)
  })

  test('concaténer les chunks reconstruit le SQL à l’identique', () => {
    assert.equal(M.splitStatements(SQL).map(c => c.text).join(''), SQL)
  })
})

describe('matchParen', () => {
  test('apparie des parenthèses imbriquées', () => {
    const s = 'f(a, (b, c), d) tail'
    assert.equal(M.matchParen(s, 1), 14)
  })
  test('ignore les parenthèses dans une chaîne', () => {
    const s = `(x, ')')`
    assert.equal(M.matchParen(s, 0), s.length - 1)
  })
  test('renvoie -1 si non apparié / mauvais index', () => {
    assert.equal(M.matchParen('(a', 0), -1)
    assert.equal(M.matchParen('abc', 0), -1)
  })
})

describe('createdTables / tableBodyRange', () => {
  test('liste les tables créées dans l’ordre', () => {
    assert.deepEqual(M.createdTableNames(SQL), ['orders', 'order_items'])
  })
  test('gère IF NOT EXISTS et la qualification de schéma', () => {
    const t = M.createdTables('CREATE TABLE IF NOT EXISTS app.foo (id int);')
    assert.equal(t.length, 1)
    assert.equal(t[0].name, 'foo')
    assert.equal(t[0].schema, 'app')
  })
  test('ne confond pas order_items avec orders', () => {
    const r = M.tableBodyRange(SQL, 'orders')
    const body = SQL.slice(r.open + 1, r.close)
    assert.match(body, /status text/)
    assert.ok(!/quantity/.test(body))
  })
  test('renvoie null pour une table absente', () => {
    assert.equal(M.tableBodyRange(SQL, 'nope'), null)
  })
})

describe('definedIdentifiers / mentionsIdentifier', () => {
  test('repère tables, fonctions et triggers définis', () => {
    const ids = M.definedIdentifiers('CREATE TABLE a (id int); CREATE OR REPLACE FUNCTION fx() RETURNS int AS $$ SELECT 1 $$ LANGUAGE sql;')
    assert.ok(ids.includes('a'))
    assert.ok(ids.includes('fx'))
  })
  test('mentionsIdentifier respecte les frontières de mot', () => {
    assert.equal(M.mentionsIdentifier('REFERENCES orders(id)', 'orders'), true)
    assert.equal(M.mentionsIdentifier('CREATE TABLE order_items (x int)', 'orders'), false)
    assert.equal(M.mentionsIdentifier('CONSTRAINT orders_pkey', 'orders'), false)
  })
})

// ── Mutations ─────────────────────────────────────────────────────────────────
describe('M1 add-notnull-col-default', () => {
  test('injecte la colonne dans le corps de la bonne table', () => {
    const r = M.mutAddNotNullColumnWithDefault(SQL, { table: 'orders' })
    assert.equal(r.ok, true)
    const body = r.sql.slice(...Object.values(M.tableBodyRange(r.sql, 'orders')).sort((a, b) => a - b))
    assert.match(body, /zmut_note text NOT NULL DEFAULT 'ada'/)
    // order_items reste intacte
    assert.ok(!/zmut_note/.test(r.sql.slice(r.sql.indexOf('CREATE TABLE order_items'))))
  })
  test('le SQL reste équilibré en parenthèses', () => {
    const r = M.mutAddNotNullColumnWithDefault(SQL, { table: 'orders' })
    const open = (r.sql.match(/\(/g) || []).length
    const close = (r.sql.match(/\)/g) || []).length
    assert.equal(open, close)
  })
  test('non applicable si la table n’existe pas', () => {
    assert.equal(M.mutAddNotNullColumnWithDefault(SQL, { table: 'ghost' }).ok, false)
    assert.equal(M.mutAddNotNullColumnWithDefault(SQL, {}).ok, false)
  })
  test('pas de virgule surnuméraire sur un corps vide', () => {
    const r = M.mutAddNotNullColumnWithDefault('CREATE TABLE t ();', { table: 't' })
    assert.equal(r.ok, true)
    assert.ok(!/,\s*\)/.test(r.sql))
  })
})

describe('M2 add-notnull-col-nodefault', () => {
  test('injecte une colonne NOT NULL sans DEFAULT', () => {
    const r = M.mutAddNotNullColumnNoDefault(SQL, { table: 'order_items' })
    assert.equal(r.ok, true)
    assert.match(r.sql, /zmut_flag boolean NOT NULL/)
    assert.ok(!/zmut_flag boolean NOT NULL DEFAULT/.test(r.sql))
  })
})

describe('M3 rename-constraints', () => {
  test('renomme les contraintes nommées', () => {
    const r = M.mutRenameConstraints(SQL)
    assert.equal(r.ok, true)
    assert.match(r.sql, /CONSTRAINT order_items_qty_ck_zmut/)
    assert.ok(!/CONSTRAINT order_items_qty_ck\b(?!_)/.test(r.sql))
  })
  test('ne touche à rien d’autre que le nom', () => {
    const r = M.mutRenameConstraints(SQL)
    assert.match(r.sql, /CHECK \(quantity > 0\)/)
    assert.equal(M.createdTableNames(r.sql).join(','), 'orders,order_items')
  })
  test('renommage consistant déclaration ↔ référence', () => {
    const sql = 'ALTER TABLE t ADD CONSTRAINT c1 CHECK (x>0);\nALTER TABLE t DROP CONSTRAINT c1;'
    const r = M.mutRenameConstraints(sql)
    assert.equal((r.sql.match(/c1_zmut/g) || []).length, 2)
  })
  test('non applicable sans contrainte nommée', () => {
    assert.equal(M.mutRenameConstraints('CREATE TABLE t (id int);').ok, false)
  })
  test('respecte la limite de 63 caractères', () => {
    const long = 'c'.repeat(80)
    const r = M.mutRenameConstraints(`ALTER TABLE t ADD CONSTRAINT ${long} CHECK (x>0);`)
    const name = /CONSTRAINT\s+(\S+)/.exec(r.sql)[1]
    assert.ok(name.length <= 63, `nom de ${name.length} caractères`)
  })
})

// ── Garde-fous de neutralité ──────────────────────────────────────────────────
// Chacun de ces trois tests encode un FAUX POSITIF réellement produit par la
// première version du harnais sur les 8 livrables above-threshold. Une mutation
// qui casse le livrable n'accuse pas le scorer : elle accuse la mutation.
describe('garde-fous de neutralité des mutations', () => {
  test('M3 ne renomme pas le mot-clé d’un CREATE CONSTRAINT TRIGGER', () => {
    // Piège réel : les 2 livrables ledger déclarent un CONSTRAINT TRIGGER de bilan.
    // Renommer `TRIGGER` produisait un SQL invalide → score 0 → faux bug de scorer.
    const sql = `CREATE TABLE t (id int, CONSTRAINT c_ck CHECK (id > 0));
CREATE CONSTRAINT TRIGGER trg_balance AFTER INSERT ON t DEFERRABLE FOR EACH ROW EXECUTE FUNCTION f();`
    const r = M.mutRenameConstraints(sql)
    assert.equal(r.ok, true)
    assert.match(r.sql, /CREATE CONSTRAINT TRIGGER trg_balance/)   // intact
    assert.ok(!/TRIGGER_zmut/i.test(r.sql))
    assert.match(r.sql, /CONSTRAINT c_ck_zmut/)                    // la vraie contrainte est renommée
  })

  test('M2 s’abstient sur une table où le livrable insère avec liste de colonnes', () => {
    // Piège réel : le trigger d'audit du livrable fait
    // `INSERT INTO contacts_audit (contact_id, workspace_id, op) …`.
    // Ajouter une colonne NOT NULL sans DEFAULT casse le code DU LIVRABLE.
    const sql = `CREATE TABLE contacts (id uuid, workspace_id uuid NOT NULL);
CREATE TABLE contacts_audit (id uuid, contact_id uuid, workspace_id uuid, op text);
CREATE FUNCTION audit() RETURNS trigger AS $$ BEGIN
  INSERT INTO contacts_audit (contact_id, workspace_id, op) VALUES (NEW.id, NEW.workspace_id, TG_OP);
  RETURN NEW; END $$ LANGUAGE plpgsql;`
    assert.equal(M.mutAddNotNullColumnNoDefault(sql, { table: 'contacts_audit' }).ok, false)
    // contacts n'est jamais insérée par le livrable → mutation légitime
    assert.equal(M.mutAddNotNullColumnNoDefault(sql, { table: 'contacts' }).ok, true)
  })

  test('M1 (avec DEFAULT) reste applicable même sur une table insérée par le livrable', () => {
    const sql = `CREATE TABLE outbox (id uuid, payload jsonb);
CREATE FUNCTION f() RETURNS trigger AS $$ BEGIN INSERT INTO outbox (id, payload) VALUES (NEW.id, '{}'); RETURN NEW; END $$ LANGUAGE plpgsql;`
    assert.equal(M.mutAddNotNullColumnWithDefault(sql, { table: 'outbox' }).ok, true)
  })

  test('M5 ne déqualifie pas dans un corps de fonction (search_path durci)', () => {
    // Piège réel : livrable audit PIPELINE, `SECURITY DEFINER SET search_path = ''`
    // → un nom non qualifié n'y résout plus. Déqualifier cassait le livrable.
    const sql = `CREATE TABLE contacts_audit (id uuid);
CREATE FUNCTION f() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
BEGIN INSERT INTO public.contacts_audit (id) VALUES (gen_random_uuid()); RETURN NEW; END $$;
ALTER TABLE public.contacts_audit ENABLE ROW LEVEL SECURITY;`
    const r = M.mutUnqualifySchema(sql)
    assert.equal(r.ok, true)
    assert.match(r.sql, /INSERT INTO public\.contacts_audit/)      // corps de fonction épargné
    assert.match(r.sql, /ALTER TABLE contacts_audit/)              // hors fonction : déqualifié
  })
})

describe('splitDollarQuoted', () => {
  test('isole les corps dollar-quotés', () => {
    const seg = M.splitDollarQuoted(`SELECT 1; CREATE FUNCTION f() AS $$ BODY $$ LANGUAGE sql;`)
    assert.equal(seg.filter(s => s.quoted).length, 1)
    assert.match(seg.find(s => s.quoted).text, /BODY/)
  })
  test('la concaténation est sans perte', () => {
    const sql = `A $$x$$ B $tag$ y $tag$ C`
    assert.equal(M.splitDollarQuoted(sql).map(s => s.text).join(''), sql)
  })
})

describe('tablesInsertedWithColumnList', () => {
  test('repère les INSERT à liste de colonnes explicite', () => {
    const sql = `INSERT INTO outbox (a, b) VALUES (1, 2); INSERT INTO public.audit_t (x) VALUES (3);`
    const t = M.tablesInsertedWithColumnList(sql)
    assert.ok(t.includes('outbox'))
    assert.ok(t.includes('audit_t'))
  })
  test('ignore un INSERT sans liste de colonnes', () => {
    assert.deepEqual(M.tablesInsertedWithColumnList('INSERT INTO t VALUES (1,2);'), [])
  })
})

describe('M4/M5 (dé)qualification de schéma', () => {
  test('qualifie les références de table, pas les colonnes', () => {
    const r = M.mutQualifySchema(SQL)
    assert.equal(r.ok, true)
    assert.match(r.sql, /CREATE TABLE public\.orders/)
    assert.match(r.sql, /REFERENCES public\.orders\(id\)/)
    assert.match(r.sql, /ALTER TABLE public\.orders/)
    assert.match(r.sql, /ON public\.order_items/)
    // la colonne order_id n'est pas touchée
    assert.match(r.sql, /order_id uuid NOT NULL/)
  })
  test('ON DELETE CASCADE n’est pas confondu avec une référence de table', () => {
    const r = M.mutQualifySchema(SQL)
    assert.match(r.sql, /ON DELETE CASCADE/)
    assert.ok(!/ON public\.DELETE/i.test(r.sql))
  })
  test('la déqualification est l’inverse exact de la qualification', () => {
    const q = M.mutQualifySchema(SQL)
    const u = M.mutUnqualifySchema(q.sql)
    assert.equal(u.ok, true)
    assert.equal(u.sql, SQL)
  })
  test('déqualification non applicable si rien n’est qualifié', () => {
    assert.equal(M.mutUnqualifySchema(SQL).ok, false)
  })
})

describe('M6 add-extra-trigger', () => {
  test('ajoute une fonction no-op et son trigger BEFORE INSERT', () => {
    const r = M.mutAddExtraTrigger(SQL, { table: 'orders' })
    assert.equal(r.ok, true)
    assert.match(r.sql, /CREATE OR REPLACE FUNCTION zmut_noop_orders\(\)/)
    assert.match(r.sql, /BEFORE INSERT ON orders/)
    assert.match(r.sql, /RETURN NEW/)
  })
  test('conserve le SQL d’origine intact en tête', () => {
    const r = M.mutAddExtraTrigger(SQL, { table: 'orders' })
    assert.ok(r.sql.startsWith(SQL.replace(/\s+$/, '')))
  })
  test('non applicable sur une table non créée par le livrable', () => {
    assert.equal(M.mutAddExtraTrigger(SQL, { table: 'workspaces' }).ok, false)
  })
})

describe('appendStatements', () => {
  test('ajoute le `;` séparateur manquant', () => {
    assert.match(M.appendStatements('SELECT 1', '\nSELECT 2;'), /SELECT 1;\n/)
  })
  test('ne double pas un `;` existant', () => {
    assert.ok(!/;;/.test(M.appendStatements('SELECT 1;', '\nSELECT 2;')))
  })
})

describe('M7 quote-identifiers', () => {
  test('quote les identifiants de table dans les contextes de table', () => {
    const r = M.mutQuoteIdentifiers(SQL)
    assert.equal(r.ok, true)
    assert.match(r.sql, /CREATE TABLE "orders"/)
    assert.match(r.sql, /REFERENCES "orders"\(id\)/)
    assert.match(r.sql, /ON "order_items"/)
  })
  test('ne quote pas deux fois', () => {
    const r1 = M.mutQuoteIdentifiers(SQL)
    assert.equal(M.mutQuoteIdentifiers(r1.sql).ok, false)
    assert.ok(!/""/.test(r1.sql))
  })
})

describe('M8 text-to-varchar', () => {
  test('remplace le type text d’une colonne', () => {
    const r = M.mutTextToVarchar(SQL)
    assert.equal(r.ok, true)
    assert.match(r.sql, /status varchar\(255\) NOT NULL DEFAULT 'pending'/)
  })
  test('ne touche pas un `::text` ni un CHECK', () => {
    const sql = "CREATE TABLE t (\n  a int,\n  CONSTRAINT c CHECK (a::text <> '')\n);"
    assert.equal(M.mutTextToVarchar(sql).ok, false)
  })
  test('non applicable sans colonne text', () => {
    assert.equal(M.mutTextToVarchar('CREATE TABLE t (\n  id int\n);').ok, false)
  })
})

describe('M9 reorder-tables', () => {
  test('refuse de permuter deux blocs liés par une FK', () => {
    // order_items référence orders → permutation interdite (casserait l'apply).
    const r = M.mutReorderTables(SQL)
    assert.equal(r.ok, false)
  })

  test('permute deux blocs réellement indépendants', () => {
    const indep = `CREATE TABLE alpha (id int);
ALTER TABLE alpha ENABLE ROW LEVEL SECURITY;
CREATE TABLE beta (id int);
ALTER TABLE beta ENABLE ROW LEVEL SECURITY;
`
    const r = M.mutReorderTables(indep)
    assert.equal(r.ok, true)
    assert.ok(r.sql.indexOf('CREATE TABLE beta') < r.sql.indexOf('CREATE TABLE alpha'))
    // chaque ALTER suit toujours SA table
    assert.ok(r.sql.indexOf('CREATE TABLE beta') < r.sql.indexOf('ALTER TABLE beta'))
    assert.ok(r.sql.indexOf('CREATE TABLE alpha') < r.sql.indexOf('ALTER TABLE alpha'))
  })

  test('la permutation préserve l’ensemble des instructions', () => {
    const indep = 'CREATE TABLE alpha (id int);\nCREATE TABLE beta (id int);\n'
    const r = M.mutReorderTables(indep)
    const norm = (s) => M.splitStatements(s).map(c => c.text.trim()).sort().join('|')
    assert.equal(norm(r.sql), norm(indep))
  })

  test('refuse si un bloc utilise une fonction définie par l’autre', () => {
    const sql = `CREATE TABLE alpha (id int);
CREATE FUNCTION shared() RETURNS trigger AS $$ BEGIN RETURN NEW; END $$ LANGUAGE plpgsql;
CREATE TABLE beta (id int);
CREATE TRIGGER tb BEFORE INSERT ON beta FOR EACH ROW EXECUTE FUNCTION shared();
`
    assert.equal(M.mutReorderTables(sql).ok, false)
  })

  test('non applicable avec moins de 2 tables', () => {
    assert.equal(M.mutReorderTables('CREATE TABLE a (id int);').ok, false)
  })
})

// ── Registre & variantes ──────────────────────────────────────────────────────
describe('registre de mutations', () => {
  test('les 10 mutations (témoin inclus) sont enregistrées et uniques', () => {
    const ids = M.MUTATIONS.map(m => m.id)
    assert.equal(new Set(ids).size, ids.length)
    for (const id of ['identity', 'add-notnull-col-default', 'add-notnull-col-nodefault',
      'rename-constraints', 'qualify-schema', 'unqualify-schema', 'add-extra-trigger',
      'quote-identifiers', 'text-to-varchar', 'reorder-tables']) {
      assert.ok(ids.includes(id), `mutation manquante: ${id}`)
    }
  })

  test('le témoin identity ne modifie rien', () => {
    const r = M.applyMutation('identity', SQL)
    assert.equal(r.ok, true)
    assert.equal(r.sql, SQL)
  })

  test('applyMutation rejette proprement une mutation inconnue', () => {
    assert.equal(M.applyMutation('nope', SQL).ok, false)
  })

  test('buildVariants développe les mutations perTable', () => {
    const v = M.buildVariants(SQL, ['add-notnull-col-default', 'rename-constraints'])
    assert.deepEqual(v.map(x => x.variant).sort(), [
      'add-notnull-col-default@order_items',
      'add-notnull-col-default@orders',
      'rename-constraints',
    ].sort())
  })

  test('buildVariants sans filtre couvre tout le registre', () => {
    const v = M.buildVariants(SQL)
    assert.ok(v.length >= M.MUTATIONS.length)
    assert.ok(v.some(x => x.variant === 'identity'))
  })

  test('toute mutation applicable produit un SQL différent de l’original (sauf témoin)', () => {
    for (const v of M.buildVariants(SQL)) {
      if (v.id === 'identity') continue
      const r = M.applyMutation(v.id, SQL, { table: v.table })
      if (r.ok) assert.notEqual(r.sql, SQL, `${v.variant} annoncée ok mais SQL inchangé`)
    }
  })

  test('toute mutation applicable préserve les tables créées', () => {
    for (const v of M.buildVariants(SQL)) {
      const r = M.applyMutation(v.id, SQL, { table: v.table })
      if (!r.ok) continue
      assert.deepEqual(M.createdTableNames(r.sql).sort(), ['order_items', 'orders'],
        `${v.variant} a altéré la liste des tables`)
    }
  })
})

// ── Analyse des verdicts ──────────────────────────────────────────────────────
describe('verdictFor', () => {
  test('score identique ⇒ stable', () => assert.equal(M.verdictFor(100, 100, true), 'stable'))
  test('score en baisse ⇒ regression', () => assert.equal(M.verdictFor(100, 90, true), 'regression'))
  test('score en hausse ⇒ anomalie', () => assert.equal(M.verdictFor(90, 100, true), 'anomalie'))
  test('score non numérique (skip) ⇒ anomalie', () => assert.equal(M.verdictFor(100, null, true), 'anomalie'))
  test('non applicable ⇒ n/a', () => assert.equal(M.verdictFor(100, null, false), 'n/a'))
})

describe('brokenAssertions', () => {
  const base = { assertions: [{ name: 'a', ok: true }, { name: 'b', ok: true }, { name: 'c', ok: false }] }
  test('ne retient que les assertions qui passaient et échouent après mutation', () => {
    const mut = { assertions: [{ name: 'a', ok: true }, { name: 'b', ok: false, expect: '1', got: '0' }, { name: 'c', ok: false }] }
    const broken = M.brokenAssertions(base, mut)
    assert.equal(broken.length, 1)
    assert.equal(broken[0].name, 'b')
    assert.equal(broken[0].got, '0')
  })
  test('vide si rien ne casse', () => {
    assert.deepEqual(M.brokenAssertions(base, base), [])
  })
  test('tolère des détails absents ou textuels', () => {
    assert.deepEqual(M.brokenAssertions(null, null), [])
    assert.deepEqual(M.brokenAssertions('postgres-indisponible', undefined), [])
  })
})

describe('summarize', () => {
  test('compte les verdicts', () => {
    const c = M.summarize([{ verdict: 'stable' }, { verdict: 'stable' }, { verdict: 'regression' }, { verdict: 'n/a' }])
    assert.equal(c.stable, 2)
    assert.equal(c.regression, 1)
    assert.equal(c['n/a'], 1)
    assert.equal(c.anomalie, 0)
  })
})

describe('wrapDeliverable / inferTaskId', () => {
  test('wrapDeliverable produit un bloc ```sql ré-extractible', () => {
    const w = M.wrapDeliverable('SELECT 1;')
    assert.match(w, /^```sql\n/)
    assert.match(w, /```\n$/)
  })
  test('inferTaskId prend l’id le plus long qui préfixe le fichier', () => {
    const ids = ['at-orders-fulfillment-schema', 'at-orders']
    assert.equal(M.inferTaskId('/tmp/benchv2-at-orders-fulfillment-schema-NATIVE.txt', ids), 'at-orders-fulfillment-schema')
    assert.equal(M.inferTaskId('/tmp/benchv2-at-orders-PIPELINE.txt', ids), 'at-orders')
  })
  test('inferTaskId renvoie null si aucun id ne correspond', () => {
    assert.equal(M.inferTaskId('/tmp/benchv2-inconnu-NATIVE.txt', ['at-orders']), null)
  })
})
