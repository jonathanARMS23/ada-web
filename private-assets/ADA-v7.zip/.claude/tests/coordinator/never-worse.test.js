'use strict'
/**
 * tests/coordinator/never-worse.test.js
 *
 * TDD — écrit AVANT le branchement final sur bank.js/micro-lessons.js/context-advisor.js.
 * Inspiré de rtk (src/core/guard.rs) : un formateur/optimiseur ne doit jamais
 * produire un résultat plus gros (en tokens estimés) que la source brute.
 */
const { test, describe } = require('node:test')
const assert = require('node:assert/strict')
const { join } = require('path')

const { estimateTokens, neverWorse, guardInjection } = require(join(__dirname, '../../coordinator/never-worse.js'))

// ── estimateTokens ───────────────────────────────────────────────────────────────

describe('estimateTokens', () => {
  test('approxime len/4 arrondi au-dessus', () => {
    assert.equal(estimateTokens('abcd'), 1)
    assert.equal(estimateTokens('abcde'), 2)
    assert.equal(estimateTokens('abcdefgh'), 2)
  })

  test('chaîne vide → 0', () => {
    assert.equal(estimateTokens(''), 0)
  })

  test('non-string → 0 (défensif)', () => {
    assert.equal(estimateTokens(null), 0)
    assert.equal(estimateTokens(undefined), 0)
    assert.equal(estimateTokens(42), 0)
  })
})

// ── neverWorse ─────────────────────────────────────────────────────────────────

describe('neverWorse', () => {
  test('transformed plus petit que raw → transformed gagne', () => {
    const raw = 'a'.repeat(400)
    assert.equal(neverWorse(raw, 'ok'), 'ok')
  })

  test('transformed plus gros que raw (ex: JSON pretty-print) → raw gagne', () => {
    const raw = '{}'
    const transformed = '{\n  "pretty": true\n}'
    assert.equal(neverWorse(raw, transformed), raw)
  })

  test('égalité (même taille estimée) → transformed gagne (tie-break)', () => {
    assert.equal(neverWorse('abcd', 'wxyz'), 'wxyz')
  })

  test('la comparaison suit estimateTokens, pas la longueur brute exacte', () => {
    // 'abcd' (4 chars, 1 token) vs 'abcde' (5 chars, 2 tokens) → transformed pire
    assert.equal(neverWorse('abcd', 'abcde'), 'abcd')
    // 'abcdefgh' (8 chars, 2 tokens) vs 'ijklmnop' (8 chars, 2 tokens) → égalité, transformed gagne
    assert.equal(neverWorse('abcdefgh', 'ijklmnop'), 'ijklmnop')
  })

  test('raw vide, transformed non vide → raw (vide) gagne : transformed est "plus gros" que rien', () => {
    assert.equal(neverWorse('', '0 matches'), '')
  })

  test('raw non vide, transformed vide → transformed (vide) gagne, jamais pire que rien', () => {
    assert.equal(neverWorse('data', ''), '')
  })

  test('les deux vides → chaîne vide', () => {
    assert.equal(neverWorse('', ''), '')
  })

  test('entrées non-string traitées comme chaîne vide (défensif)', () => {
    // null → '' côté raw : 'ok' (1 token) > '' (0 token) → raw ('') gagne, cf. cas empty_raw ci-dessus.
    assert.equal(neverWorse(null, 'ok'), '')
    // null → '' côté transformed : '' (0 token) ≤ raw substantiel → transformed ('') gagne.
    assert.equal(neverWorse('a'.repeat(100), null), '')
  })

  test('scénario réaliste : formatage qui duplique le contenu (bug) retombe sur raw', () => {
    const raw = 'Pas de any TS, préfère unknown puis narrow'
    const buggyTransformed = `${raw}\n${raw}` // un bug qui duplique la ligne
    assert.equal(neverWorse(raw, buggyTransformed), raw)
  })
})

// ── guardInjection ─────────────────────────────────────────────────────────────

describe('guardInjection', () => {
  test('injection dans le ratio → base + injection, séparés par une ligne vide', () => {
    const base = 'Instructions agent : implémente le endpoint.'
    const injection = 'Convention: pas de any TS.'
    const result = guardInjection(base, injection, { maxRatio: 2 })
    assert.equal(result, `${base}\n\n${injection}`)
  })

  test('injection énorme relativement à la base → tronquée proprement', () => {
    const base = 'a'.repeat(40) // 10 tokens estimés
    const injection = 'b'.repeat(4000) // 1000 tokens estimés
    const result = guardInjection(base, injection, { maxRatio: 0.5 }) // budget: 5 tokens = 20 chars
    assert.ok(result.startsWith(base))
    assert.ok(result.length < base.length + injection.length, 'le résultat doit être bien plus court que base+injection bruts')
    // Le fragment injecté ne doit pas dépasser le budget alloué (~20 chars + séparateur)
    const injectedPart = result.slice(base.length + 2)
    assert.ok(injectedPart.length <= 20, `fragment injecté trop long: ${injectedPart.length} chars`)
  })

  test('injection énorme et budget nul (maxRatio ~0) → omise, base seule renvoyée', () => {
    const base = 'court' // 5 chars → 2 tokens estimés
    const injection = 'x'.repeat(1000)
    const result = guardInjection(base, injection, { maxRatio: 0 })
    assert.equal(result, base)
  })

  test('pas d\'injection (chaîne vide) → base inchangée', () => {
    assert.equal(guardInjection('base prompt', '', {}), 'base prompt')
  })

  test('pas de base (chaîne vide) → injection renvoyée telle quelle (rien à protéger)', () => {
    assert.equal(guardInjection('', 'contenu injecté'), 'contenu injecté')
  })

  test('maxRatio par défaut est 0.5 si non fourni', () => {
    const base = 'a'.repeat(40) // 10 tokens
    const smallInjection = 'b'.repeat(16) // 4 tokens ≤ 5 (10*0.5) → passe
    const bigInjection = 'c'.repeat(100) // 25 tokens > 5 → tronqué
    assert.equal(guardInjection(base, smallInjection), `${base}\n\n${smallInjection}`)
    assert.notEqual(guardInjection(base, bigInjection), `${base}\n\n${bigInjection}`)
  })

  test('entrées non-string traitées comme chaîne vide (défensif)', () => {
    assert.equal(guardInjection(null, 'x'), 'x')
    assert.equal(guardInjection('base', null), 'base')
  })

  test('scénario réaliste : contexte ACW raisonnable passe intact', () => {
    const staticInstructions = 'Tu es un agent NestJS. '.repeat(20) // instructions substantielles
    const dynamicContext = 'Similar past runs: [id1, id2] | avg success: 100%\nKey lessons: Toujours écrire les specs en premier.'
    const result = guardInjection(staticInstructions, dynamicContext, { maxRatio: 20 })
    assert.equal(result, `${staticInstructions}\n\n${dynamicContext}`)
  })
})
