'use strict'
/**
 * tests/coordinator/path-validator.test.js
 */
const { test, describe } = require('node:test')
const assert = require('node:assert/strict')
const { join } = require('path')
const { tmpdir } = require('os')

const {
  validatePath,
  isSafeFilename,
  checkSensitiveFiles,
} = require(join(__dirname, '../../coordinator/path-validator.js'))

const BASE = tmpdir()

describe('validatePath', () => {
  test('chemin dans le répertoire autorisé → safe=true', () => {
    const result = validatePath('subdir/file.txt', BASE)
    assert.equal(result.safe, true)
    assert.ok(result.resolved?.startsWith(BASE))
  })

  test('chemin direct dans la base → safe=true', () => {
    const result = validatePath('bank.db', BASE)
    assert.equal(result.safe, true)
  })

  test('path traversal ../ → safe=false', () => {
    const result = validatePath('../etc/passwd', BASE)
    assert.equal(result.safe, false)
    assert.ok(result.reason?.includes('traversal') || result.reason?.includes('Path'))
  })

  test('path traversal absolu hors base → safe=false', () => {
    const result = validatePath('/etc/passwd', BASE)
    assert.equal(result.safe, false)
  })

  test('null byte → safe=false', () => {
    const result = validatePath('file\0.txt', BASE)
    assert.equal(result.safe, false)
    assert.ok(result.reason?.includes('Null'))
  })

  test('chemin vide → safe=false', () => {
    const result = validatePath('', BASE)
    assert.equal(result.safe, false)
  })

  test('chemin non-string → safe=false', () => {
    // @ts-ignore intentional
    const result = validatePath(null, BASE)
    assert.equal(result.safe, false)
  })
})

describe('isSafeFilename', () => {
  test('bank.db est valide', () => {
    assert.equal(isSafeFilename('bank.db'), true)
  })

  test('router-state.json est valide', () => {
    assert.equal(isSafeFilename('router-state.json'), true)
  })

  test('fichier avec underscore est valide', () => {
    assert.equal(isSafeFilename('my_file_01.txt'), true)
  })

  test('../etc/passwd est invalide (contient /)', () => {
    assert.equal(isSafeFilename('../etc/passwd'), false)
  })

  test('nom avec / est invalide', () => {
    assert.equal(isSafeFilename('path/file.txt'), false)
  })

  test('nom avec ; est invalide', () => {
    assert.equal(isSafeFilename('file;cmd.txt'), false)
  })

  test('null byte est invalide', () => {
    assert.equal(isSafeFilename('file\0.txt'), false)
  })

  test('chaine vide est invalide', () => {
    assert.equal(isSafeFilename(''), false)
  })

  test('juste . est invalide', () => {
    assert.equal(isSafeFilename('.'), false)
  })

  test('nom trop long (>255 chars) est invalide', () => {
    assert.equal(isSafeFilename('a'.repeat(256)), false)
  })
})

describe('checkSensitiveFiles', () => {
  test('.env est sensible', () => {
    const result = checkSensitiveFiles('/project/.env')
    assert.equal(result.safe, false)
    assert.ok(result.reason?.includes('sensible'))
  })

  test('.env.local est sensible', () => {
    const result = checkSensitiveFiles('/project/.env.local')
    assert.equal(result.safe, false)
  })

  test('id_rsa est sensible', () => {
    const result = checkSensitiveFiles('/home/user/.ssh/id_rsa')
    assert.equal(result.safe, false)
  })

  test('id_ed25519 est sensible', () => {
    const result = checkSensitiveFiles('/home/user/.ssh/id_ed25519')
    assert.equal(result.safe, false)
  })

  test('fichier .pem est sensible', () => {
    const result = checkSensitiveFiles('/certs/server.pem')
    assert.equal(result.safe, false)
  })

  test('secrets.json est sensible', () => {
    const result = checkSensitiveFiles('/config/secrets.json')
    assert.equal(result.safe, false)
  })

  test('.aws/credentials est sensible', () => {
    const result = checkSensitiveFiles('/home/user/.aws/credentials')
    assert.equal(result.safe, false)
  })

  test('bank.db est safe', () => {
    const result = checkSensitiveFiles('/coordinator/bank.db')
    assert.equal(result.safe, true)
  })

  test('router-state.json est safe', () => {
    const result = checkSensitiveFiles('/coordinator/router-state.json')
    assert.equal(result.safe, true)
  })

  test('script.js est safe', () => {
    const result = checkSensitiveFiles('/project/coordinator/bank.js')
    assert.equal(result.safe, true)
  })
})
