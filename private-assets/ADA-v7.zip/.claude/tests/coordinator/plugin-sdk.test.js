#!/usr/bin/env node
'use strict'

const { test, describe, before, after } = require('node:test')
const assert = require('node:assert/strict')
const { mkdirSync, rmSync, writeFileSync } = require('node:fs')
const { join } = require('node:path')

const SDK_JS = join(__dirname, '../../coordinator/plugin-sdk.js')

let validateManifest, listPlugins, loadPlugin, PLUGIN_EVENTS

before(() => {
  const mod = require(SDK_JS)
  validateManifest = mod.validateManifest
  listPlugins      = mod.listPlugins
  loadPlugin       = mod.loadPlugin
  PLUGIN_EVENTS    = mod.PLUGIN_EVENTS
})

// ─── validateManifest ─────────────────────────────────────────────────────────

describe('validateManifest', () => {
  test('retourne valid=true pour un manifest minimal correct', () => {
    const result = validateManifest({
      name:        'my-plugin',
      version:     '1.0.0',
      description: 'A well-described plugin',
    })
    assert.equal(result.valid, true)
    assert.deepEqual(result.errors, [])
  })

  test('retourne valid=false si name manquant', () => {
    const result = validateManifest({
      version:     '1.0.0',
      description: 'Missing name field',
    })
    assert.equal(result.valid, false)
    assert.ok(result.errors.some(e => e.includes('name')), `Attendu erreur sur "name", erreurs: ${JSON.stringify(result.errors)}`)
  })

  test('retourne valid=false si version manquante', () => {
    const result = validateManifest({
      name:        'my-plugin',
      description: 'Missing version field',
    })
    assert.equal(result.valid, false)
    assert.ok(result.errors.some(e => e.includes('version')), `Attendu erreur sur "version", erreurs: ${JSON.stringify(result.errors)}`)
  })

  test('retourne valid=false si description manquante', () => {
    const result = validateManifest({
      name:    'my-plugin',
      version: '1.0.0',
    })
    assert.equal(result.valid, false)
    assert.ok(result.errors.some(e => e.includes('description')))
  })

  test('retourne une erreur si hooks contient un event inconnu', () => {
    const result = validateManifest({
      name:        'my-plugin',
      version:     '1.0.0',
      description: 'Plugin with bad hook',
      hooks:       ['git-commit', 'unknown-event'],
    })
    assert.equal(result.valid, false)
    assert.ok(result.errors.some(e => e.includes('unknown-event')))
  })

  test('retourne valid=true si hooks contient uniquement des events connus', () => {
    const result = validateManifest({
      name:        'my-plugin',
      version:     '1.0.0',
      description: 'Plugin with valid hooks',
      hooks:       ['git-commit', 'git-push', 'test-js'],
    })
    assert.equal(result.valid, true)
    assert.deepEqual(result.errors, [])
  })

  test('retourne un warning si hooks est vide', () => {
    const result = validateManifest({
      name:        'my-plugin',
      version:     '1.0.0',
      description: 'Plugin with empty hooks',
      hooks:       [],
    })
    assert.equal(result.valid, true)
    assert.ok(result.warnings.some(w => w.includes('hooks') && (w.includes('vide') || w.includes('jamais'))),
      `Attendu warning sur hooks vide, warnings: ${JSON.stringify(result.warnings)}`)
  })

  test('retourne un warning si description trop courte', () => {
    const result = validateManifest({
      name:        'my-plugin',
      version:     '1.0.0',
      description: 'Short',
    })
    assert.equal(result.valid, true)
    assert.ok(result.warnings.some(w => w.includes('description')),
      `Attendu warning sur description courte, warnings: ${JSON.stringify(result.warnings)}`)
  })

  test('retourne valid=true avec tous les champs optionnels valides', () => {
    const result = validateManifest({
      name:           'full-plugin',
      version:        '2.1.0',
      description:    'A fully specified plugin with all optional fields',
      hooks:          ['git-commit', 'cve-critical'],
      minSdkVersion:  '1.0.0',
      minNodeVersion: 22,
      author:         'Jonathan Arms',
      license:        'MIT',
    })
    assert.equal(result.valid, true)
    assert.deepEqual(result.errors, [])
  })

  test('retourne une erreur si minSdkVersion a un format invalide', () => {
    const result = validateManifest({
      name:          'my-plugin',
      version:       '1.0.0',
      description:   'Plugin with bad semver',
      minSdkVersion: 'not-a-version',
    })
    assert.equal(result.valid, false)
    assert.ok(result.errors.some(e => e.includes('minSdkVersion')))
  })

  test('retourne valid=false si name est une chaîne vide', () => {
    const result = validateManifest({
      name:        '',
      version:     '1.0.0',
      description: 'Empty name plugin',
    })
    assert.equal(result.valid, false)
    assert.ok(result.errors.some(e => e.includes('name')))
  })

  test('retourne valid=false si hooks n\'est pas un tableau', () => {
    const result = validateManifest({
      name:        'my-plugin',
      version:     '1.0.0',
      description: 'Plugin with wrong hooks type',
      hooks:       'git-commit',
    })
    assert.equal(result.valid, false)
    assert.ok(result.errors.some(e => e.includes('hooks')))
  })
})

// ─── listPlugins ──────────────────────────────────────────────────────────────

const TMP_PLUGINS = join(__dirname, '../../..', '.test-tmp-plugins')

describe('listPlugins', () => {
  before(() => {
    mkdirSync(TMP_PLUGINS, { recursive: true })
  })

  after(() => {
    try { rmSync(TMP_PLUGINS, { recursive: true }) } catch {}
  })

  test('retourne [] si le répertoire plugins est vide', () => {
    const emptyDir = join(TMP_PLUGINS, 'empty')
    mkdirSync(emptyDir, { recursive: true })
    const result = listPlugins(emptyDir)
    assert.deepEqual(result, [])
  })

  test('retourne [] si le répertoire plugins n\'existe pas', () => {
    const result = listPlugins(join(TMP_PLUGINS, 'non-existent-dir'))
    assert.deepEqual(result, [])
  })

  test('liste correctement les plugins avec manifest.json', () => {
    const pluginsDir = join(TMP_PLUGINS, 'with-plugins')
    const pluginDir  = join(pluginsDir, 'my-plugin')
    mkdirSync(pluginDir, { recursive: true })
    writeFileSync(join(pluginDir, 'manifest.json'), JSON.stringify({
      name:        'my-plugin',
      version:     '1.0.0',
      description: 'Test plugin for unit tests',
      hooks:       ['git-commit'],
    }))

    const result = listPlugins(pluginsDir)
    assert.equal(result.length, 1)
    assert.equal(result[0].name, 'my-plugin')
    assert.ok(result[0].manifest !== null)
    assert.equal(result[0].manifest.name, 'my-plugin')
    assert.equal(result[0].path, pluginDir)
  })

  test('détecte la présence de worker.js', () => {
    const pluginsDir = join(TMP_PLUGINS, 'with-worker')
    const pluginDir  = join(pluginsDir, 'worker-plugin')
    mkdirSync(pluginDir, { recursive: true })
    writeFileSync(join(pluginDir, 'manifest.json'), JSON.stringify({
      name: 'worker-plugin', version: '1.0.0', description: 'Has a worker file'
    }))
    writeFileSync(join(pluginDir, 'worker.js'), '// worker')

    const result = listPlugins(pluginsDir)
    assert.equal(result.length, 1)
    assert.equal(result[0].hasWorker, true)
    assert.equal(result[0].hasHook,   false)
  })

  test('détecte la présence de hook.js', () => {
    const pluginsDir = join(TMP_PLUGINS, 'with-hook')
    const pluginDir  = join(pluginsDir, 'hook-plugin')
    mkdirSync(pluginDir, { recursive: true })
    writeFileSync(join(pluginDir, 'manifest.json'), JSON.stringify({
      name: 'hook-plugin', version: '1.0.0', description: 'Has a hook file'
    }))
    writeFileSync(join(pluginDir, 'hook.js'), '// hook')

    const result = listPlugins(pluginsDir)
    assert.equal(result.length, 1)
    assert.equal(result[0].hasWorker, false)
    assert.equal(result[0].hasHook,   true)
  })

  test('retourne hasWorker=false et hasHook=false si aucun fichier JS', () => {
    const pluginsDir = join(TMP_PLUGINS, 'no-js')
    const pluginDir  = join(pluginsDir, 'bare-plugin')
    mkdirSync(pluginDir, { recursive: true })
    writeFileSync(join(pluginDir, 'manifest.json'), JSON.stringify({
      name: 'bare-plugin', version: '1.0.0', description: 'Manifest only plugin'
    }))

    const result = listPlugins(pluginsDir)
    assert.equal(result.length, 1)
    assert.equal(result[0].hasWorker, false)
    assert.equal(result[0].hasHook,   false)
  })
})

// ─── PLUGIN_EVENTS ────────────────────────────────────────────────────────────

describe('PLUGIN_EVENTS', () => {
  test('contient git-commit', () => {
    assert.ok(PLUGIN_EVENTS.includes('git-commit'))
  })

  test('contient git-push', () => {
    assert.ok(PLUGIN_EVENTS.includes('git-push'))
  })

  test('contient cve-critical', () => {
    assert.ok(PLUGIN_EVENTS.includes('cve-critical'))
  })

  test('contient test-js et test-py', () => {
    assert.ok(PLUGIN_EVENTS.includes('test-js'))
    assert.ok(PLUGIN_EVENTS.includes('test-py'))
  })

  test('est un tableau non vide', () => {
    assert.ok(Array.isArray(PLUGIN_EVENTS))
    assert.ok(PLUGIN_EVENTS.length > 0)
  })
})

// ─── PluginBuilder ────────────────────────────────────────────────────────────

let PluginBuilder, createPlugin

before(() => {
  const mod = require(SDK_JS)
  PluginBuilder = mod.PluginBuilder
  createPlugin  = mod.createPlugin
})

describe('PluginBuilder — builder pattern', () => {
  test('new PluginBuilder retourne un objet avec méthodes fluent', () => {
    const b = new PluginBuilder('test-plugin')
    assert.ok(typeof b.version === 'function')
    assert.ok(typeof b.description === 'function')
    assert.ok(typeof b.author === 'function')
    assert.ok(typeof b.license === 'function')
    assert.ok(typeof b.hooks === 'function')
    assert.ok(typeof b.categories === 'function')
    assert.ok(typeof b.tags === 'function')
    assert.ok(typeof b.minSdkVersion === 'function')
    assert.ok(typeof b.minNodeVersion === 'function')
    assert.ok(typeof b.build === 'function')
  })

  test('build() retourne un manifest valide', () => {
    const manifest = new PluginBuilder('my-plugin')
      .version('1.2.3')
      .description('A well-described plugin')
      .author('Jonathan')
      .license('MIT')
      .build()

    assert.equal(manifest.name, 'my-plugin')
    assert.equal(manifest.version, '1.2.3')
    assert.equal(manifest.description, 'A well-described plugin')
    assert.equal(manifest.author, 'Jonathan')
    assert.equal(manifest.license, 'MIT')
  })

  test('hooks() set les hooks correctement', () => {
    const manifest = new PluginBuilder('hook-plugin')
      .version('1.0.0')
      .description('Plugin with hooks')
      .hooks('git-commit', 'test-js')
      .build()

    assert.deepEqual(manifest.hooks, ['git-commit', 'test-js'])
  })

  test('build() lance une Error si name absent ou vide', () => {
    assert.throws(
      () => new PluginBuilder('').version('1.0.0').description('desc').build(),
      (err) => {
        assert.ok(err instanceof Error)
        assert.ok(err.message.includes('invalide') || err.message.includes('name'))
        return true
      }
    )
  })

  test('createPlugin raccourci fonctionnel', () => {
    const manifest = createPlugin('quick-plugin', {
      version:     '2.0.0',
      description: 'Quick plugin via shortcut',
      author:      'Arms',
    })
    assert.equal(manifest.name, 'quick-plugin')
    assert.equal(manifest.version, '2.0.0')
    assert.equal(manifest.description, 'Quick plugin via shortcut')
  })
})

// ─── searchPlugins ────────────────────────────────────────────────────────────

const TMP_SEARCH = join(__dirname, '../../..', '.test-tmp-search')

let searchPlugins, getPluginsByCategory

before(() => {
  const mod = require(SDK_JS)
  searchPlugins       = mod.searchPlugins
  getPluginsByCategory = mod.getPluginsByCategory
})

describe('plugin-sdk — searchPlugins', () => {
  before(() => {
    // Crée deux faux plugins avec categories
    const pluginA = join(TMP_SEARCH, 'alpha-tool')
    const pluginB = join(TMP_SEARCH, 'beta-formatter')
    mkdirSync(pluginA, { recursive: true })
    mkdirSync(pluginB, { recursive: true })

    writeFileSync(join(pluginA, 'manifest.json'), JSON.stringify({
      name:        'alpha-tool',
      version:     '1.0.0',
      description: 'Alpha tooling plugin for testing',
      categories:  ['tooling', 'dev'],
      tags:        ['alpha'],
    }))
    writeFileSync(join(pluginB, 'manifest.json'), JSON.stringify({
      name:        'beta-formatter',
      version:     '1.0.0',
      description: 'Beta code formatter',
      categories:  ['formatting'],
      tags:        ['beta'],
    }))
  })

  after(() => {
    try { rmSync(TMP_SEARCH, { recursive: true }) } catch {}
  })

  test('searchPlugins(\'\') retourne tous les plugins (ou vide si aucun)', () => {
    const results = searchPlugins('', { pluginsDir: TMP_SEARCH })
    assert.ok(Array.isArray(results))
    assert.equal(results.length, 2)
  })

  test('searchPlugins filtre par nom case-insensitive', () => {
    const results = searchPlugins('ALPHA', { pluginsDir: TMP_SEARCH })
    assert.equal(results.length, 1)
    assert.equal(results[0].name, 'alpha-tool')
  })

  test('searchPlugins filtre par category', () => {
    const results = searchPlugins('', { category: 'formatting', pluginsDir: TMP_SEARCH })
    assert.equal(results.length, 1)
    assert.equal(results[0].name, 'beta-formatter')
  })
})

// ─── getPluginsByCategory ─────────────────────────────────────────────────────

const TMP_CATEGORY = join(__dirname, '../../..', '.test-tmp-category')

describe('plugin-sdk — getPluginsByCategory', () => {
  before(() => {
    const pluginA = join(TMP_CATEGORY, 'cat-plugin-a')
    const pluginB = join(TMP_CATEGORY, 'cat-plugin-b')
    mkdirSync(pluginA, { recursive: true })
    mkdirSync(pluginB, { recursive: true })

    writeFileSync(join(pluginA, 'manifest.json'), JSON.stringify({
      name:        'cat-plugin-a',
      version:     '1.0.0',
      description: 'Plugin in security category',
      categories:  ['security'],
    }))
    writeFileSync(join(pluginB, 'manifest.json'), JSON.stringify({
      name:        'cat-plugin-b',
      version:     '1.0.0',
      description: 'Plugin in tooling category',
      categories:  ['tooling'],
    }))
  })

  after(() => {
    try { rmSync(TMP_CATEGORY, { recursive: true }) } catch {}
  })

  test('retourne tableau vide si aucun plugin correspond à la catégorie', () => {
    const results = getPluginsByCategory('nonexistent', TMP_CATEGORY)
    assert.deepEqual(results, [])
  })

  test('filtre correctement par catégorie', () => {
    const results = getPluginsByCategory('security', TMP_CATEGORY)
    assert.equal(results.length, 1)
    assert.equal(results[0].name, 'cat-plugin-a')
  })
})
