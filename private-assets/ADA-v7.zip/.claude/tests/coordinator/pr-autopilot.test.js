'use strict'
/**
 * tests/coordinator/pr-autopilot.test.js
 *
 * Suite de tests pour coordinator/pr-autopilot.js
 * Couvre :
 *  - buildPRBody : structure Markdown, phases, coût
 *  - createPR    : payload POST correct, GithubTokenMissing si token absent
 *  - pollCIStatus: pending→success, pending→failure, timeout
 *  - GithubTokenMissing quand GITHUB_TOKEN absent
 */

const assert = require('assert')
const path   = require('path')
const https  = require('https')

// ── Résolution du module testé ────────────────────────────────────────────────

const MODULE_PATH = path.join(__dirname, '..', '..', 'coordinator', 'pr-autopilot.js')
// Nettoyer le cache entre les tests pour permettre l'injection de process.env
function fresh() {
  delete require.cache[require.resolve(MODULE_PATH)]
  return require(MODULE_PATH)
}

// ── Fixtures ──────────────────────────────────────────────────────────────────

function makeRunState(overrides = {}) {
  return {
    id:          'feature-test-run-20260523-1200',
    pipeline:    'feature',
    status:      'completed',
    startedAt:   '2026-05-23T10:00:00.000Z',
    completedAt: '2026-05-23T10:30:00.000Z',
    totalTokens: 12000,
    totalCost:   0.53,
    branch:      'feat/test-feature',
    args:        { name: 'test-feature', backend: 'nestjs' },
    phases: {
      backend: {
        status:      'completed',
        agent:       'nestjs',
        tier:        3,
        cost:        0.45,
        startedAt:   '2026-05-23T10:00:00.000Z',
        completedAt: '2026-05-23T10:12:00.000Z',
        summary:     'NestJS backend scaffolded',
      },
      tester: {
        status:      'completed',
        agent:       'tester',
        tier:        1,
        cost:        0.08,
        startedAt:   '2026-05-23T10:12:00.000Z',
        completedAt: '2026-05-23T10:16:00.000Z',
        summary:     'Tests passed',
      },
    },
    ...overrides,
  }
}

// ── Tests buildPRBody ─────────────────────────────────────────────────────────

function testBuildPRBodyStructure() {
  const { buildPRBody } = fresh()
  const state = makeRunState()
  const body  = buildPRBody(state)

  assert(typeof body === 'string', 'buildPRBody doit retourner une string')
  assert(body.includes('## ADA Run Summary'), 'Doit contenir le titre principal')
  assert(body.includes('feature-test-run-20260523-1200'), 'Doit contenir le runId')
  assert(body.includes('feature'), 'Doit contenir le pipeline')
  console.log('  ✓ buildPRBody — structure de base')
}

function testBuildPRBodyPhases() {
  const { buildPRBody } = fresh()
  const state = makeRunState()
  const body  = buildPRBody(state)

  assert(body.includes('### Phases'), 'Doit contenir la section Phases')
  assert(body.includes('backend'), 'Doit contenir la phase backend')
  assert(body.includes('nestjs'),  'Doit contenir l\'agent nestjs')
  assert(body.includes('tester'),  'Doit contenir la phase tester')
  assert(body.includes('✅'),       'Doit afficher ✅ pour les phases completed')
  console.log('  ✓ buildPRBody — phases présentes')
}

function testBuildPRBodyCost() {
  const { buildPRBody } = fresh()
  const state = makeRunState()
  const body  = buildPRBody(state)

  assert(body.includes('$0.5300'), 'Doit contenir le coût total')
  assert(body.includes('$0.4500'), 'Doit contenir le coût de la phase backend')
  assert(body.includes('$0.0800'), 'Doit contenir le coût de la phase tester')
  assert(body.includes('### Budget'), 'Doit contenir la section Budget')
  console.log('  ✓ buildPRBody — coûts présents')
}

function testBuildPRBodyDuration() {
  const { buildPRBody } = fresh()
  const state = makeRunState()
  const body  = buildPRBody(state)

  assert(body.includes('30m'), 'Doit calculer la durée du run (30 min)')
  console.log('  ✓ buildPRBody — durée calculée')
}

function testBuildPRBodyADABadge() {
  const { buildPRBody } = fresh()
  const state = makeRunState()
  const body  = buildPRBody(state)

  assert(body.includes('Généré par [ADA]'), 'Doit contenir le badge ADA')
  assert(body.includes(state.id), 'Doit référencer le runId dans le badge')
  console.log('  ✓ buildPRBody — badge ADA présent')
}

function testBuildPRBodyFailedPhase() {
  const { buildPRBody } = fresh()
  const state = makeRunState({
    phases: {
      backend: { status: 'failed', agent: 'nestjs', tier: 3, cost: 0.10,
                 startedAt: '2026-05-23T10:00:00.000Z', completedAt: '2026-05-23T10:05:00.000Z' },
    },
  })
  const body = buildPRBody(state)
  assert(body.includes('❌'), 'Doit afficher ❌ pour les phases failed')
  console.log('  ✓ buildPRBody — phase failed affichée correctement')
}

// ── Tests GithubTokenMissing ──────────────────────────────────────────────────

async function testGithubTokenMissingCreatePR() {
  const savedToken = process.env.GITHUB_TOKEN
  delete process.env.GITHUB_TOKEN

  try {
    const { createPR, GithubTokenMissing } = fresh()
    const state = makeRunState()

    let threw = false
    try {
      await createPR(state)
    } catch (e) {
      threw = true
      assert(e instanceof GithubTokenMissing, `Doit throw GithubTokenMissing, reçu: ${e.constructor.name}`)
      assert(e.code === 'GITHUB_TOKEN_MISSING', 'code doit être GITHUB_TOKEN_MISSING')
    }
    assert(threw, 'createPR doit throw quand GITHUB_TOKEN absent')
    console.log('  ✓ createPR — GithubTokenMissing quand GITHUB_TOKEN absent')
  } finally {
    if (savedToken !== undefined) process.env.GITHUB_TOKEN = savedToken
  }
}

async function testGithubTokenMissingPollCI() {
  const savedToken = process.env.GITHUB_TOKEN
  delete process.env.GITHUB_TOKEN

  try {
    const { pollCIStatus, GithubTokenMissing } = fresh()

    let threw = false
    try {
      await pollCIStatus(123)
    } catch (e) {
      threw = true
      assert(e instanceof GithubTokenMissing, `Doit throw GithubTokenMissing, reçu: ${e.constructor.name}`)
    }
    assert(threw, 'pollCIStatus doit throw quand GITHUB_TOKEN absent')
    console.log('  ✓ pollCIStatus — GithubTokenMissing quand GITHUB_TOKEN absent')
  } finally {
    if (savedToken !== undefined) process.env.GITHUB_TOKEN = savedToken
  }
}

// ── Tests createPR (mock fetch) ───────────────────────────────────────────────

async function testCreatePRPayload() {
  process.env.GITHUB_TOKEN = 'ghp_test_token_mock'

  // Mock https.request
  const originalRequest = https.request
  let capturedPayload   = null
  let capturedOptions   = null

  https.request = (options, callback) => {
    capturedOptions = options
    const res = {
      statusCode: 201,
      on: (event, handler) => {
        if (event === 'data')  handler(JSON.stringify({ number: 42, html_url: 'https://github.com/owner/repo/pull/42' }))
        if (event === 'end')   handler()
        return res
      },
      resume: () => {},
    }
    if (callback) setTimeout(() => callback(res), 0)
    return {
      on:    (event, handler) => {},
      write: (data) => { capturedPayload = JSON.parse(data) },
      end:   () => {},
    }
  }

  // Mock git commands
  const { spawnSync: origSpawnSync } = require('child_process')
  const childProcess = require('child_process')
  const origSpawn = childProcess.spawnSync
  childProcess.spawnSync = (cmd, args, opts) => {
    if (cmd === 'git' && args[0] === 'remote') {
      return { status: 0, stdout: 'git@github.com:owner/repo.git\n', stderr: '' }
    }
    if (cmd === 'git' && args[0] === 'rev-parse' && args[1] === '--abbrev-ref') {
      return { status: 0, stdout: 'feat/test-feature\n', stderr: '' }
    }
    if (cmd === 'git' && args[0] === 'rev-parse' && args[1] === 'HEAD') {
      return { status: 0, stdout: 'abc123def456\n', stderr: '' }
    }
    return origSpawn(cmd, args, opts)
  }

  try {
    const { createPR } = fresh()
    const state = makeRunState()
    const result = await createPR(state)

    assert(result.prUrl === 'https://github.com/owner/repo/pull/42', 'prUrl incorrect')
    assert(result.prNumber === 42, 'prNumber incorrect')
    assert(capturedOptions?.path === '/repos/owner/repo/pulls', 'Path API incorrect')
    assert(capturedOptions?.method === 'POST', 'Méthode doit être POST')
    assert(capturedPayload?.title?.startsWith('feat:'), 'Title doit commencer par feat:')
    assert(capturedPayload?.base === 'main', 'Base branch doit être main')
    assert(typeof capturedPayload?.body === 'string', 'Body doit être une string')
    assert(capturedPayload?.body.includes('## ADA Run Summary'), 'Body doit contenir le summary ADA')
    assert(capturedOptions?.headers?.['Authorization'] === 'Bearer ghp_test_token_mock', 'Authorization header incorrect')
    assert(capturedOptions?.headers?.['X-GitHub-Api-Version'] === '2022-11-28', 'X-GitHub-Api-Version incorrect')

    console.log('  ✓ createPR — payload POST correct')
  } finally {
    https.request = originalRequest
    childProcess.spawnSync = origSpawn
    delete process.env.GITHUB_TOKEN
  }
}

// ── Tests pollCIStatus ────────────────────────────────────────────────────────

async function testPollCIStatusSuccess() {
  process.env.GITHUB_TOKEN = 'ghp_test_token_mock'

  const originalRequest = https.request
  const childProcess    = require('child_process')
  const origSpawn       = childProcess.spawnSync

  // Simuler: 1er appel = pending, 2ème appel = completed/success
  let callCount = 0
  https.request = (options, callback) => {
    callCount++
    let responseBody

    if (options.path?.includes('/pulls/')) {
      // Appel PR pour récupérer le SHA
      responseBody = JSON.stringify({ head: { sha: 'abc123' } })
    } else if (callCount <= 2) {
      // Premier poll : check-runs en cours
      responseBody = JSON.stringify({
        check_runs: [{ status: 'in_progress', conclusion: null, name: 'ci/test' }]
      })
    } else {
      // Deuxième poll : tous completed/success
      responseBody = JSON.stringify({
        check_runs: [{ status: 'completed', conclusion: 'success', name: 'ci/test' }]
      })
    }

    const res = {
      statusCode: 200,
      on: (event, handler) => {
        if (event === 'data') handler(responseBody)
        if (event === 'end')  handler()
        return res
      },
    }
    if (callback) setTimeout(() => callback(res), 0)
    return {
      on:    () => {},
      write: () => {},
      end:   () => {},
    }
  }

  childProcess.spawnSync = (cmd, args, opts) => {
    if (cmd === 'git' && args[0] === 'remote') {
      return { status: 0, stdout: 'https://github.com/owner/repo.git\n', stderr: '' }
    }
    if (cmd === 'git' && args[0] === 'rev-parse') {
      return { status: 0, stdout: 'abc123\n', stderr: '' }
    }
    return origSpawn(cmd, args, opts)
  }

  try {
    const { pollCIStatus } = fresh()
    // intervalMs très court pour le test
    const result = await pollCIStatus(42, { maxWaitMs: 10_000, intervalMs: 100 })
    assert(result === 'success', `pollCIStatus doit retourner 'success', reçu: ${result}`)
    console.log('  ✓ pollCIStatus — pending→success détecté')
  } finally {
    https.request = originalRequest
    childProcess.spawnSync = origSpawn
    delete process.env.GITHUB_TOKEN
  }
}

async function testPollCIStatusFailure() {
  process.env.GITHUB_TOKEN = 'ghp_test_token_mock'

  const originalRequest = https.request
  const childProcess    = require('child_process')
  const origSpawn       = childProcess.spawnSync

  https.request = (options, callback) => {
    let responseBody

    if (options.path?.includes('/pulls/')) {
      responseBody = JSON.stringify({ head: { sha: 'abc123' } })
    } else {
      responseBody = JSON.stringify({
        check_runs: [{ status: 'completed', conclusion: 'failure', name: 'ci/test' }]
      })
    }

    const res = {
      statusCode: 200,
      on: (event, handler) => {
        if (event === 'data') handler(responseBody)
        if (event === 'end')  handler()
        return res
      },
    }
    if (callback) setTimeout(() => callback(res), 0)
    return {
      on:    () => {},
      write: () => {},
      end:   () => {},
    }
  }

  childProcess.spawnSync = (cmd, args, opts) => {
    if (cmd === 'git' && args[0] === 'remote') {
      return { status: 0, stdout: 'https://github.com/owner/repo.git\n', stderr: '' }
    }
    if (cmd === 'git' && args[0] === 'rev-parse') {
      return { status: 0, stdout: 'abc123\n', stderr: '' }
    }
    return origSpawn(cmd, args, opts)
  }

  try {
    const { pollCIStatus } = fresh()
    const result = await pollCIStatus(42, { maxWaitMs: 10_000, intervalMs: 100 })
    assert(result === 'failure', `pollCIStatus doit retourner 'failure', reçu: ${result}`)
    console.log('  ✓ pollCIStatus — check failed détecté')
  } finally {
    https.request = originalRequest
    childProcess.spawnSync = origSpawn
    delete process.env.GITHUB_TOKEN
  }
}

async function testPollCIStatusTimeout() {
  process.env.GITHUB_TOKEN = 'ghp_test_token_mock'

  const originalRequest = https.request
  const childProcess    = require('child_process')
  const origSpawn       = childProcess.spawnSync

  // Toujours retourner pending pour forcer le timeout
  https.request = (options, callback) => {
    let responseBody

    if (options.path?.includes('/pulls/')) {
      responseBody = JSON.stringify({ head: { sha: 'abc123' } })
    } else {
      responseBody = JSON.stringify({
        check_runs: [{ status: 'in_progress', conclusion: null }]
      })
    }

    const res = {
      statusCode: 200,
      on: (event, handler) => {
        if (event === 'data') handler(responseBody)
        if (event === 'end')  handler()
        return res
      },
    }
    if (callback) setTimeout(() => callback(res), 0)
    return {
      on:    () => {},
      write: () => {},
      end:   () => {},
    }
  }

  childProcess.spawnSync = (cmd, args, opts) => {
    if (cmd === 'git' && args[0] === 'remote') {
      return { status: 0, stdout: 'https://github.com/owner/repo.git\n', stderr: '' }
    }
    if (cmd === 'git' && args[0] === 'rev-parse') {
      return { status: 0, stdout: 'abc123\n', stderr: '' }
    }
    return origSpawn(cmd, args, opts)
  }

  try {
    const { pollCIStatus } = fresh()
    // maxWaitMs très court pour forcer le timeout
    const result = await pollCIStatus(42, { maxWaitMs: 200, intervalMs: 50 })
    assert(result === 'timeout', `pollCIStatus doit retourner 'timeout', reçu: ${result}`)
    console.log('  ✓ pollCIStatus — timeout respecté')
  } finally {
    https.request = originalRequest
    childProcess.spawnSync = origSpawn
    delete process.env.GITHUB_TOKEN
  }
}

// ── Tests loadPrConfig ────────────────────────────────────────────────────────

function testLoadPrConfigDefaults() {
  const { loadPrConfig } = fresh()
  const cfg = loadPrConfig()
  assert(typeof cfg === 'object', 'loadPrConfig doit retourner un objet')
  assert(typeof cfg.enabled    === 'boolean', 'enabled doit être boolean')
  assert(typeof cfg.autoCreate === 'boolean', 'autoCreate doit être boolean')
  console.log('  ✓ loadPrConfig — defaults valides')
}

// ── Runner ────────────────────────────────────────────────────────────────────

async function runAll() {
  let passed = 0
  let failed = 0
  const errors = []

  const tests = [
    // buildPRBody
    { name: 'buildPRBody — structure',     fn: testBuildPRBodyStructure },
    { name: 'buildPRBody — phases',        fn: testBuildPRBodyPhases },
    { name: 'buildPRBody — coût',          fn: testBuildPRBodyCost },
    { name: 'buildPRBody — durée',         fn: testBuildPRBodyDuration },
    { name: 'buildPRBody — badge ADA',     fn: testBuildPRBodyADABadge },
    { name: 'buildPRBody — phase failed',  fn: testBuildPRBodyFailedPhase },
    // GithubTokenMissing
    { name: 'GithubTokenMissing — createPR',   fn: testGithubTokenMissingCreatePR },
    { name: 'GithubTokenMissing — pollCIStatus', fn: testGithubTokenMissingPollCI },
    // createPR
    { name: 'createPR — payload POST',     fn: testCreatePRPayload },
    // pollCIStatus
    { name: 'pollCIStatus — success',      fn: testPollCIStatusSuccess },
    { name: 'pollCIStatus — failure',      fn: testPollCIStatusFailure },
    { name: 'pollCIStatus — timeout',      fn: testPollCIStatusTimeout },
    // loadPrConfig
    { name: 'loadPrConfig — defaults',     fn: testLoadPrConfigDefaults },
  ]

  console.log('\npr-autopilot.test.js\n')

  for (const { name, fn } of tests) {
    try {
      await fn()
      passed++
    } catch (e) {
      failed++
      errors.push({ name, message: e.message })
      console.error(`  ✗ ${name} — ${e.message}`)
    }
  }

  console.log(`\n${passed} passed, ${failed} failed (${tests.length} total)\n`)

  if (failed > 0) {
    for (const { name, message } of errors) {
      console.error(`  FAIL: ${name}\n    ${message}`)
    }
    process.exit(1)
  }
}

if (require.main === module) {
  runAll().catch(e => {
    process.stderr.write(`[pr-autopilot.test] fatal: ${e.message}\n${e.stack}\n`)
    process.exit(1)
  })
}

module.exports = { runAll }
