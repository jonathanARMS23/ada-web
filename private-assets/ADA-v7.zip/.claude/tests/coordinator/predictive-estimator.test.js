#!/usr/bin/env node
'use strict'
const { test, describe } = require('node:test')
const assert = require('node:assert/strict')

const PE_JS = join => require(join)
const { estimateRun, formatEstimate } = require(
  require('path').join(__dirname, '../../coordinator/predictive-estimator.js')
)

// ── Prix par tier (réplique de la table interne, dérivée de models.js PRICING.input) ──
const PRICE_PER_TOKEN = {
  1: 1.00  / 1e6,
  2: 3.00  / 1e6,
  3: 5.00  / 1e6,
}

// ── Données de test ───────────────────────────────────────────────────────────

const ROUTER_STATE = {
  priors: {
    'backend:nestjs': {
      alpha: 7,
      beta: 3,
      meanTokens: 40000,
      meanDurationMs: 720000,   // 12 min — nom canonique (écrit par router.updateDurationMean)
    },
    'tester:tester': {
      alpha: 11,
      beta: 1,
      meanTokens: 10000,
      meanDuration: 240000,   // 4 min — ancien nom, toléré en lecture (états legacy)
    },
    'reviewer:reviewer': {
      alpha: 8,
      beta: 3,
      meanTokens: 25000,
      meanDuration: 480000,   // 8 min
    },
  },
  totalUpdates: 30,
}

const PHASES = [
  { id: 'backend',  agent: 'nestjs',   tier: 3 },
  { id: 'tester',   agent: 'tester',   tier: 2 },
  { id: 'reviewer', agent: 'reviewer', tier: 2 },
]

// ── estimateRun ───────────────────────────────────────────────────────────────

describe('estimateRun — avec priors connus', () => {
  test('retourne un tableau avec autant d\'éléments que de phases', () => {
    const estimates = estimateRun(PHASES, ROUTER_STATE)
    assert.equal(estimates.length, 3)
  })

  test('phase backend — coût estimé correct pour tier 3', () => {
    const estimates = estimateRun(PHASES, ROUTER_STATE)
    const backend = estimates.find(e => e.phaseId === 'backend')
    assert.ok(backend)
    // 40000 tokens * $5/M = $0.20
    const expected = 40000 * PRICE_PER_TOKEN[3]
    assert.ok(Math.abs(backend.estimatedCostUsd - expected) < 0.001,
      `Coût attendu ~$${expected.toFixed(4)}, obtenu $${backend.estimatedCostUsd.toFixed(4)}`)
  })

  test('phase tester — coût estimé correct pour tier 2', () => {
    const estimates = estimateRun(PHASES, ROUTER_STATE)
    const tester = estimates.find(e => e.phaseId === 'tester')
    assert.ok(tester)
    const expected = 10000 * PRICE_PER_TOKEN[2]
    assert.ok(Math.abs(tester.estimatedCostUsd - expected) < 0.001)
  })

  test('phase backend — successRate = alpha/(alpha+beta)', () => {
    const estimates = estimateRun(PHASES, ROUTER_STATE)
    const backend = estimates.find(e => e.phaseId === 'backend')
    assert.ok(backend)
    // alpha=7, beta=3 → 7/10 = 0.7
    assert.ok(Math.abs(backend.successRate - 0.7) < 0.001)
  })

  test('phase tester — successRate élevé (alpha=11, beta=1)', () => {
    const estimates = estimateRun(PHASES, ROUTER_STATE)
    const tester = estimates.find(e => e.phaseId === 'tester')
    assert.ok(tester)
    // 11/12 ≈ 0.9167
    assert.ok(Math.abs(tester.successRate - (11/12)) < 0.001)
  })

  // B6 (bug jumeau) — le nom canonique est `meanDurationMs` : c'est ce que
  // router.updateDurationMean() écrit réellement. L'estimateur lisait
  // `meanDuration` (inexistant) → durée toujours = DEFAULT_DURATION (30s).
  test('B6 — durée estimée depuis meanDurationMs (nom écrit par le router)', () => {
    const estimates = estimateRun(PHASES, ROUTER_STATE)
    const backend = estimates.find(e => e.phaseId === 'backend')
    assert.ok(backend)
    assert.equal(backend.estimatedDurationMs, 720000)
    assert.notEqual(backend.estimatedDurationMs, 30000, 'ne doit PAS retomber sur DEFAULT_DURATION')
  })

  test('B6 — bout-en-bout : un prior écrit par router.update est lisible par estimateRun', () => {
    const { mkdtempSync, mkdirSync, rmSync } = require('fs')
    const os = require('os')
    const path = require('path')
    const tmp = mkdtempSync(path.join(os.tmpdir(), 'ada-pe-'))
    mkdirSync(path.join(tmp, 'coordinator'), { recursive: true })
    const prevCfg = process.env.CLAUDE_CONFIG_DIR
    process.env.CLAUDE_CONFIG_DIR = tmp
    const ROUTER_JS = path.join(__dirname, '../../coordinator/router.js')
    delete require.cache[require.resolve(ROUTER_JS)]
    try {
      const router = require(ROUTER_JS)
      router.update('backend', 'nestjs', 'success', { tokens: 12345, durationMs: 654321 })
      // Le router expose loadState (PAS loadRouterState — cf. B6 dans run.js)
      assert.equal(typeof router.loadState, 'function')
      assert.equal(typeof router.loadRouterState, 'undefined')
      const est = estimateRun([{ id: 'backend', agent: 'nestjs', tier: 3 }], router.loadState())[0]
      assert.equal(est.estimatedTokens, 12345)
      assert.equal(est.estimatedDurationMs, 654321)
    } finally {
      if (prevCfg === undefined) delete process.env.CLAUDE_CONFIG_DIR
      else process.env.CLAUDE_CONFIG_DIR = prevCfg
      delete require.cache[require.resolve(ROUTER_JS)]
      try { rmSync(tmp, { recursive: true, force: true }) } catch {}
    }
  })

  test('B6 — `meanDuration` legacy reste toléré en lecture', () => {
    const estimates = estimateRun(PHASES, ROUTER_STATE)
    const tester = estimates.find(e => e.phaseId === 'tester')
    assert.equal(tester.estimatedDurationMs, 240000)
  })

  test('utilise les valeurs par défaut si prior absent', () => {
    const phases = [{ id: 'schema', agent: 'db', tier: 1 }]
    const estimates = estimateRun(phases, { priors: {} })
    assert.equal(estimates.length, 1)
    const e = estimates[0]
    // Tokens par défaut = 50000
    const expected = 50000 * PRICE_PER_TOKEN[1]
    assert.ok(Math.abs(e.estimatedCostUsd - expected) < 0.001)
    // Durée par défaut = 30000ms
    assert.equal(e.estimatedDurationMs, 30000)
    // successRate = 1/(1+1) = 0.5 (prior uniforme)
    assert.ok(Math.abs(e.successRate - 0.5) < 0.001)
  })

  test('retourne [] si phases est vide', () => {
    const estimates = estimateRun([], ROUTER_STATE)
    assert.deepEqual(estimates, [])
  })

  test('retourne [] si phases n\'est pas un tableau', () => {
    const estimates = estimateRun(null, ROUTER_STATE)
    assert.deepEqual(estimates, [])
  })

  test('tier par défaut = 2 si non spécifié', () => {
    const phases = [{ id: 'specs', agent: 'tester' }]
    const estimates = estimateRun(phases, { priors: {} })
    const e = estimates[0]
    const expected = 50000 * PRICE_PER_TOKEN[2]
    assert.ok(Math.abs(e.estimatedCostUsd - expected) < 0.001)
  })
})

// ── formatEstimate ────────────────────────────────────────────────────────────

describe('formatEstimate — rendu ASCII', () => {
  test('contient les id de phases', () => {
    const estimates = estimateRun(PHASES, ROUTER_STATE)
    const output = formatEstimate(estimates)
    assert.match(output, /backend/)
    assert.match(output, /tester/)
    assert.match(output, /reviewer/)
  })

  test('contient une ligne TOTAL', () => {
    const estimates = estimateRun(PHASES, ROUTER_STATE)
    const output = formatEstimate(estimates)
    assert.match(output, /TOTAL/)
  })

  test('contient des symboles de tableau ASCII', () => {
    const estimates = estimateRun(PHASES, ROUTER_STATE)
    const output = formatEstimate(estimates)
    assert.match(output, /[┌└│]/)
  })

  test('retourne un message vide si tableau vide', () => {
    const output = formatEstimate([])
    assert.match(output, /aucune estimation/i)
  })

  test('les coûts sont formatés avec $', () => {
    const estimates = estimateRun(PHASES, ROUTER_STATE)
    const output = formatEstimate(estimates)
    assert.match(output, /\$\d+\.\d{2}/)
  })

  test('les durées sont formatées avec ~', () => {
    const estimates = estimateRun(PHASES, ROUTER_STATE)
    const output = formatEstimate(estimates)
    assert.match(output, /~\d+(min|s)/)
  })

  test('les taux de succès sont affichés en %', () => {
    const estimates = estimateRun(PHASES, ROUTER_STATE)
    const output = formatEstimate(estimates)
    assert.match(output, /\d+%/)
  })
})
