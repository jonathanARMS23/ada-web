#!/usr/bin/env node
'use strict'
/**
 * tests/coordinator/prompt-cache-optimizer.test.js
 *
 * Tests:
 *  1. Stable blocks receive cache_control; dynamic blocks do not
 *  2. Stable blocks come before dynamic blocks in output
 *  3. trackCacheMetrics with mock headers → correct accumulation in JSON
 *  4. getCacheStats hitRate and savedUsd calculations
 */

const { test, describe, beforeEach, afterEach } = require('node:test')
const assert = require('node:assert/strict')
const { mkdirSync, rmSync, existsSync, readFileSync, writeFileSync } = require('fs')
const { join } = require('path')
const os = require('os')

// ── Fixture paths ─────────────────────────────────────────────────────────────

const TMP_DIR     = join(os.tmpdir(), 'ada-pco-test-' + process.pid)
const METRICS_FILE = join(TMP_DIR, 'cache-metrics.json')

// Module under test — load after setting override so the path is injected early
const PCO_PATH = join(__dirname, '../../coordinator/prompt-cache-optimizer.js')

let pco

function loadFresh() {
  delete require.cache[require.resolve(PCO_PATH)]
  pco = require(PCO_PATH)
  pco._overrideMetricsFile(METRICS_FILE)
}

// ── Setup / teardown ──────────────────────────────────────────────────────────

beforeEach(() => {
  mkdirSync(TMP_DIR, { recursive: true })
  loadFresh()
})

afterEach(() => {
  if (existsSync(TMP_DIR)) {
    rmSync(TMP_DIR, { recursive: true, force: true })
  }
})

// ── Helpers ───────────────────────────────────────────────────────────────────

function readMetrics() {
  return JSON.parse(readFileSync(METRICS_FILE, 'utf8'))
}

function makeHeaders(hit, creation) {
  return {
    'anthropic-cache-read-input-tokens':     String(hit),
    'anthropic-cache-creation-input-tokens': String(creation),
  }
}

// ── 1. isStable / isDynamic heuristics ───────────────────────────────────────

describe('isStable heuristic', () => {
  test('markdown heading line is stable', () => {
    assert.equal(pco.isStable('# System Prompt\nThis is a system prompt.'), true)
  })

  test('text containing micro-lessons is stable', () => {
    assert.equal(pco.isStable('Some micro-lessons from the codebase'), true)
  })

  test('text containing instructions is stable', () => {
    assert.equal(pco.isStable('Follow these instructions carefully.'), true)
  })

  test('long text without timestamp is stable', () => {
    const longText = 'a'.repeat(201)
    assert.equal(pco.isStable(longText), true)
  })

  test('long text with ISO timestamp is NOT stable', () => {
    const longText = 'a'.repeat(180) + ' 2024-01-01T12:00:00Z more text here'
    assert.equal(pco.isStable(longText), false)
  })

  test('short text without keyword or heading is not stable', () => {
    assert.equal(pco.isStable('Hello world'), false)
  })

  test('non-string returns false', () => {
    assert.equal(pco.isStable(null), false)
    assert.equal(pco.isStable(42),   false)
  })
})

describe('isDynamic heuristic', () => {
  test('text with ISO timestamp is dynamic', () => {
    assert.equal(pco.isDynamic('Current time: 2024-05-23T10:30:00Z'), true)
  })

  test('text without ISO timestamp is not dynamic', () => {
    assert.equal(pco.isDynamic('No timestamp here'), false)
  })

  test('non-string returns false', () => {
    assert.equal(pco.isDynamic(undefined), false)
  })
})

// ── 2. optimizeMessages — cache_control placement ────────────────────────────

describe('optimizeMessages — cache_control placement', () => {
  test('stable block gets cache_control, dynamic block does not', () => {
    const messages = [
      {
        role: 'user',
        content: [
          { type: 'text', text: '# System instructions\nYou are a helpful assistant.' },
          { type: 'text', text: 'Current time is 2024-05-23T10:00:00Z' },
        ],
      },
    ]

    const result = pco.optimizeMessages(messages)
    const blocks = result[0].content

    // Find stable block (heading)
    const stableBlock = blocks.find(b => b.text.startsWith('#'))
    assert.ok(stableBlock, 'stable block must exist')
    assert.deepEqual(stableBlock.cache_control, { type: 'ephemeral' })

    // Find dynamic block (timestamp)
    const dynamicBlock = blocks.find(b => pco.isDynamic(b.text))
    assert.ok(dynamicBlock, 'dynamic block must exist')
    assert.equal(dynamicBlock.cache_control, undefined)
  })

  test('only the LAST stable block gets cache_control when multiple stable blocks exist', () => {
    const messages = [
      {
        role: 'user',
        content: [
          { type: 'text', text: '# First stable block\n' + 'x'.repeat(50) },
          { type: 'text', text: 'Follow these instructions carefully. ' + 'y'.repeat(50) },
        ],
      },
    ]

    const result = pco.optimizeMessages(messages)
    const blocks = result[0].content
    const withCache = blocks.filter(b => b.cache_control !== undefined)

    assert.equal(withCache.length, 1, 'exactly one block should have cache_control')
    assert.equal(withCache[0], blocks[blocks.length - 1], 'last block in stable group has cache_control')
  })

  test('pure function — input messages are not mutated', () => {
    const original = {
      role: 'user',
      content: [
        { type: 'text', text: '# Stable heading content here' },
        { type: 'text', text: 'timestamp 2024-01-01T00:00:00Z' },
      ],
    }
    const input = [original]
    const inputCopy = JSON.parse(JSON.stringify(input))

    pco.optimizeMessages(input)

    assert.deepEqual(input, inputCopy, 'input must not be mutated')
  })

  test('string content is normalised to block array', () => {
    const messages = [{ role: 'user', content: '# Instructions\nDo things.' }]
    const result   = pco.optimizeMessages(messages)

    assert.ok(Array.isArray(result[0].content), 'content should be an array')
    assert.equal(result[0].content[0].type, 'text')
  })

  test('non-array input is returned unchanged', () => {
    assert.equal(pco.optimizeMessages(null), null)
    assert.equal(pco.optimizeMessages('string'), 'string')
  })
})

// ── 3. optimizeMessages — ordering ───────────────────────────────────────────

describe('optimizeMessages — stable blocks before dynamic blocks', () => {
  test('dynamic block is moved after stable block regardless of original order', () => {
    const messages = [
      {
        role: 'user',
        content: [
          { type: 'text', text: 'Current request time: 2024-05-23T09:00:00Z' },  // dynamic first
          { type: 'text', text: '# Agent instructions\nAlways be helpful.' },     // stable second
        ],
      },
    ]

    const result  = pco.optimizeMessages(messages)
    const blocks  = result[0].content
    const stableIdx  = blocks.findIndex(b => b.text.includes('# Agent instructions'))
    const dynamicIdx = blocks.findIndex(b => pco.isDynamic(b.text))

    assert.ok(stableIdx < dynamicIdx, `stable (${stableIdx}) must come before dynamic (${dynamicIdx})`)
  })

  test('multiple stable blocks all precede all dynamic blocks', () => {
    const messages = [
      {
        role: 'user',
        content: [
          { type: 'text', text: 'Query timestamp: 2024-05-23T10:00:00Z' },
          { type: 'text', text: '# System prompt\n' + 'x'.repeat(50) },
          { type: 'text', text: 'Session at 2024-05-23T10:01:00Z' },
          { type: 'text', text: 'Follow these instructions to guide the response.' },
        ],
      },
    ]

    const result  = pco.optimizeMessages(messages)
    const blocks  = result[0].content

    const lastStableIdx  = blocks.reduce((max, b, i) => pco.isStable(b.text) ? i : max, -1)
    const firstDynamicIdx = blocks.findIndex(b => pco.isDynamic(b.text))

    assert.ok(firstDynamicIdx > lastStableIdx,
      `all dynamic blocks (first at ${firstDynamicIdx}) must come after all stable blocks (last at ${lastStableIdx})`)
  })
})

// ── 4. buildSystemBlock ───────────────────────────────────────────────────────

describe('buildSystemBlock', () => {
  test('static block has cache_control, dynamic block does not', () => {
    const blocks = pco.buildSystemBlock(
      '# System prompt\nYou are an assistant.',
      'User query at 2024-05-23T10:00:00Z'
    )

    assert.equal(blocks.length, 2)
    assert.deepEqual(blocks[0].cache_control, { type: 'ephemeral' })
    assert.equal(blocks[1].cache_control, undefined)
  })

  test('omitting dynamicContent returns single cached block', () => {
    const blocks = pco.buildSystemBlock('# Static content only', '')
    assert.equal(blocks.length, 1)
    assert.deepEqual(blocks[0].cache_control, { type: 'ephemeral' })
  })

  test('omitting staticContent returns single uncached block', () => {
    const blocks = pco.buildSystemBlock('', 'Dynamic content 2024-05-23T12:00:00Z')
    assert.equal(blocks.length, 1)
    assert.equal(blocks[0].cache_control, undefined)
  })
})

// ── 5. trackCacheMetrics — accumulation ──────────────────────────────────────

describe('trackCacheMetrics', () => {
  test('accumulates hit and miss tokens across calls', () => {
    pco.trackCacheMetrics(makeHeaders(1000, 500))
    pco.trackCacheMetrics(makeHeaders(2000, 300))

    const m = readMetrics()
    assert.equal(m.hitTokens,  3000)
    assert.equal(m.missTokens, 800)
    assert.equal(m.calls,      2)
  })

  test('savedUsd is computed from hit tokens (Sonnet 4.6 pricing)', () => {
    // 1,000,000 hit tokens → saved = (3.00 - 0.30) = $2.70
    pco.trackCacheMetrics(makeHeaders(1_000_000, 0))

    const m = readMetrics()
    // Allow floating point tolerance
    assert.ok(Math.abs(m.savedUsd - 2.70) < 0.0001,
      `savedUsd should be ~2.70, got ${m.savedUsd}`)
  })

  test('no-op when both header values are zero', () => {
    pco.trackCacheMetrics(makeHeaders(0, 0))
    assert.equal(existsSync(METRICS_FILE), false, 'no file should be created for zero values')
  })

  test('no-op with null headers', () => {
    pco.trackCacheMetrics(null)
    assert.equal(existsSync(METRICS_FILE), false)
  })

  test('no-op with undefined headers', () => {
    pco.trackCacheMetrics(undefined)
    assert.equal(existsSync(METRICS_FILE), false)
  })

  test('works with WHATWG Headers-like object (.get method)', () => {
    const headers = {
      get(name) {
        const map = {
          'anthropic-cache-read-input-tokens':     '500',
          'anthropic-cache-creation-input-tokens': '100',
        }
        return map[name] ?? null
      },
    }

    pco.trackCacheMetrics(headers)
    const m = readMetrics()
    assert.equal(m.hitTokens,  500)
    assert.equal(m.missTokens, 100)
  })

  test('atomic write — temp file removed after save', () => {
    pco.trackCacheMetrics(makeHeaders(100, 50))
    assert.equal(existsSync(METRICS_FILE + '.tmp'), false, 'temp file must be removed')
    assert.ok(existsSync(METRICS_FILE), 'metrics file must exist')
  })
})

// ── 6. getCacheStats ──────────────────────────────────────────────────────────

describe('getCacheStats', () => {
  test('returns zeros if no metrics file exists', () => {
    const stats = pco.getCacheStats()
    assert.equal(stats.hitTokens,  0)
    assert.equal(stats.missTokens, 0)
    assert.equal(stats.savedUsd,   0)
    assert.equal(stats.hitRate,    0)
  })

  test('hitRate = hitTokens / (hitTokens + missTokens)', () => {
    pco.trackCacheMetrics(makeHeaders(750, 250)) // 75% hit rate

    const stats = pco.getCacheStats()
    assert.ok(Math.abs(stats.hitRate - 0.75) < 0.0001,
      `hitRate should be 0.75, got ${stats.hitRate}`)
  })

  test('hitRate is 0 when both are zero (no division by zero)', () => {
    // Write a metrics file with zero tokens
    writeFileSync(METRICS_FILE, JSON.stringify({
      hitTokens: 0, missTokens: 0, savedUsd: 0, calls: 0, lastUpdated: '',
    }))

    const stats = pco.getCacheStats()
    assert.equal(stats.hitRate, 0)
  })

  test('savedUsd in getCacheStats matches what was written by trackCacheMetrics', () => {
    pco.trackCacheMetrics(makeHeaders(500_000, 100_000))

    const expected = 500_000 * (3.00 - 0.30) / 1_000_000 // $1.35
    const stats    = pco.getCacheStats()

    assert.ok(Math.abs(stats.savedUsd - expected) < 0.0001,
      `savedUsd should be ~${expected}, got ${stats.savedUsd}`)
  })

  test('projectedMonthlySavedUsd is 30× savedUsd when calls > 0', () => {
    pco.trackCacheMetrics(makeHeaders(100_000, 0))

    const stats = pco.getCacheStats()
    assert.ok(Math.abs(stats.projectedMonthlySavedUsd - stats.savedUsd * 30) < 0.0001)
  })

  test('getCacheStats handles corrupt metrics file gracefully', () => {
    writeFileSync(METRICS_FILE, 'not valid json }{')

    const stats = pco.getCacheStats()
    assert.equal(stats.hitTokens, 0)
    assert.equal(stats.hitRate,   0)
  })
})
