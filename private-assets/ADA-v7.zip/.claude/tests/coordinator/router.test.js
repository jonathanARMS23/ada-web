#!/usr/bin/env node
'use strict'
const { test, describe, before, after, beforeEach, afterEach } = require('node:test')
const assert = require('node:assert/strict')
const { mkdirSync, rmSync, writeFileSync, existsSync } = require('fs')
const { join } = require('path')

const TMP = join(__dirname, '../../..', '.test-tmp-router')
const ROUTER_JS = join(__dirname, '../../coordinator/router.js')

// RNG déterministe pour rendre les tests stochastiques reproductibles.
// Injecté via router._setRng dans les blocs qui assertent agent/confidence
// sur une phase multi-candidats (Thompson Sampling).
function mulberry32(seed) {
  let a = seed >>> 0
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}
const SEEDED_RNG_SEED = 0x1a2b3c4d

// Charger le module avec CONFIG_DIR pointant sur TMP
let router
before(() => {
  mkdirSync(join(TMP, 'coordinator'), { recursive: true })
  process.env.CLAUDE_CONFIG_DIR = TMP
  // Clear module cache pour forcer rechargement avec bon CONFIG_DIR
  delete require.cache[require.resolve(ROUTER_JS)]
  router = require(ROUTER_JS)
})

after(() => {
  delete process.env.CLAUDE_CONFIG_DIR
  try { rmSync(TMP, { recursive: true }) } catch {}
})

beforeEach(() => {
  // Reset state avant chaque test
  const stateFile = join(TMP, 'coordinator', 'router-state.json')
  if (existsSync(stateFile)) rmSync(stateFile)
  delete require.cache[require.resolve(ROUTER_JS)]
  router = require(ROUTER_JS)
})

// Phase de référence pour les tests Thompson : choix RÉELLEMENT substituable
// (reviewer ↔ security-auditor). 'backend' n'est plus valide pour ça — c'est un
// choix de stack, résolu déterministement (B1).
const THOMPSON_PHASE = 'review'
const T_A = 'reviewer'          // candidats[0]
const T_B = 'security-auditor'  // candidats[1]

// ─── Beta distribution ────────────────────────────────────────────────────────

describe('Beta distribution (Marsaglia-Tsang)', () => {
  test('sampleBeta retourne une valeur dans [0,1]', () => {
    // Test via recommend (utilise sampleBeta internalement)
    for (let i = 0; i < 100; i++) {
      const r = router.recommend(THOMPSON_PHASE)
      assert.ok(r.sample >= 0 && r.sample <= 1, `sample=${r.sample} hors [0,1]`)
    }
  })

  test('recommend avec α élevé tend vers 1 (exploitation)', () => {
    // Simuler 20 succès sur les deux candidats → samples élevés des deux côtés
    for (let i = 0; i < 20; i++) {
      router.update(THOMPSON_PHASE, T_A, 'success')
      router.update(THOMPSON_PHASE, T_B, 'success')
    }
    const results = []
    for (let i = 0; i < 50; i++) results.push(router.recommend(THOMPSON_PHASE).sample)
    const avg = results.reduce((a, b) => a + b, 0) / results.length
    assert.ok(avg > 0.7, `Moyenne ${avg.toFixed(3)} devrait être > 0.7 avec 20 succès`)
  })

  test('recommend avec β élevé tend vers 0 (agent peu fiable)', () => {
    for (let i = 0; i < 20; i++) router.update(THOMPSON_PHASE, T_B, 'failure')
    const results = []
    for (let i = 0; i < 50; i++) {
      const r = router.recommend(THOMPSON_PHASE)
      results.push(r.agent === T_A ? 1 : 0)
    }
    const rate = results.reduce((a, b) => a + b, 0) / results.length
    assert.ok(rate > 0.7, `${T_A} devrait être choisi >70% (got ${Math.round(rate*100)}%)`)
  })
})

// ─── recommend ───────────────────────────────────────────────────────────────

describe('recommend', () => {
  // Seed RNG déterministe : ces tests assertent agent/confidence sur une phase
  // multi-candidats → le tirage Thompson doit être reproductible.
  // Le beforeEach global recharge le module ; on (re)seede après ce rechargement.
  beforeEach(() => { router._setRng(mulberry32(SEEDED_RNG_SEED)) })
  afterEach(() => { router._resetRng() })

  test('candidate unique → retourne ce candidat avec confiance "none" si vide', () => {
    const r = router.recommend('schema')
    assert.equal(r.agent, 'db')
    assert.equal(r.confidence, 'none')
  })

  test('multiple candidats → retourne le meilleur par Thompson', () => {
    const r = router.recommend(THOMPSON_PHASE)
    assert.ok([T_A, T_B].includes(r.agent), `agent=${r.agent} hors candidats`)
    assert.ok(r.sample >= 0 && r.sample <= 1)
  })

  test('confiance "high" après 10+ updates', () => {
    for (let i = 0; i < 11; i++) router.update(THOMPSON_PHASE, T_A, 'success')
    const r = router.recommend(THOMPSON_PHASE)
    assert.equal(r.agent, T_A)
    assert.equal(r.confidence, 'high')
  })

  test('confiance "medium" entre 3 et 10 updates', () => {
    for (let i = 0; i < 5; i++) router.update(THOMPSON_PHASE, T_A, 'success')
    const r = router.recommend(THOMPSON_PHASE)
    assert.equal(r.confidence, 'medium')
  })

  test('retourne null.agent pour phase inconnue', () => {
    const r = router.recommend('unknown_phase_xyz')
    assert.equal(r.agent, null)
  })
})

// ─── update ──────────────────────────────────────────────────────────────────

describe('update', () => {
  test('success incrémente alpha et successes', () => {
    const { prior } = router.update('backend', 'nestjs', 'success')
    assert.equal(prior.alpha, 2)  // 1 initial + 1
    assert.equal(prior.successes, 1)
    assert.equal(prior.beta, 1)   // inchangé
  })

  test('failure incrémente beta et failures', () => {
    const { prior } = router.update('backend', 'drf', 'failure')
    assert.equal(prior.beta, 2)
    assert.equal(prior.failures, 1)
    assert.equal(prior.alpha, 1)
  })

  test('accumulation correcte sur plusieurs updates', () => {
    router.update('backend', 'nestjs', 'success')
    router.update('backend', 'nestjs', 'success')
    router.update('backend', 'nestjs', 'failure')
    const { prior } = router.update('backend', 'nestjs', 'success')
    assert.equal(prior.alpha, 4)   // 1+3
    assert.equal(prior.beta, 2)    // 1+1
    assert.equal(prior.successes, 3)
    assert.equal(prior.failures, 1)
  })

  test('lève une erreur pour outcome invalide', () => {
    assert.throws(
      () => router.update('backend', 'nestjs', 'invalid'),
      /outcome doit être/
    )
  })
})

// ─── decay ───────────────────────────────────────────────────────────────────

describe('decay', () => {
  test('réduit alpha et beta par le facteur', () => {
    // Seed quelques updates
    router.update('schema', 'db', 'success')
    router.update('schema', 'db', 'success')
    // alpha=3, beta=1 → après decay 0.9 → alpha≈2.7, beta≈0.9 (min 1)
    const { count } = router.decay(0.9)
    assert.ok(count >= 1)
    const state = router.loadState()
    const p = state.priors['schema:db']
    assert.ok(p.alpha < 3, `alpha ${p.alpha} devrait être < 3 après decay`)
    assert.ok(p.alpha >= 1, 'alpha ne doit pas passer sous 1')
  })

  // Ancien test : `p.alpha >= 9 && p.alpha < 11.5` — passait même si decay ne
  // faisait RIEN (alpha=11 est dans l'intervalle). Il ne discriminait donc pas.
  // Nouvelle version : valeur attendue exacte + garde anti-no-op.
  test('factor=0.95 → alpha décaie de la valeur EXACTE attendue (échoue si decay est un no-op)', () => {
    for (let i = 0; i < 10; i++) router.update('schema', 'db', 'success')
    const before = router.loadState().priors['schema:db']
    assert.equal(before.alpha, 11, 'pré-condition : alpha=11 (1 + 10 succès)')

    router.decay(0.95, { ewc: false })

    const p = router.loadState().priors['schema:db']
    assert.ok(Math.abs(p.alpha - 11 * 0.95) < 1e-9, `alpha attendu ${11 * 0.95}, reçu ${p.alpha}`)
    assert.ok(p.alpha < 11, 'decay no-op détecté : alpha inchangé')
  })

  // B4 — decay doit aussi décayer successes/failures, sinon `confidence` et
  // `winRate` (calculés depuis ces compteurs) restent figés à vie.
  test('B4 — decay réduit AUSSI successes et failures (proportionnellement)', () => {
    for (let i = 0; i < 8 ; i++) router.update('schema', 'db', 'success')
    for (let i = 0; i < 2 ; i++) router.update('schema', 'db', 'failure')
    const before = router.loadState().priors['schema:db']
    assert.equal(before.successes, 8)
    assert.equal(before.failures, 2)

    router.decay(0.5, { ewc: false })

    const p = router.loadState().priors['schema:db']
    assert.ok(Math.abs(p.successes - 4) < 1e-9, `successes attendu 4, reçu ${p.successes}`)
    assert.ok(Math.abs(p.failures  - 1) < 1e-9, `failures attendu 1, reçu ${p.failures}`)
    // winRate (un ratio) doit être PRÉSERVÉ : seule la masse de preuve baisse
    const winRateBefore = before.successes / (before.successes + before.failures)
    const winRateAfter  = p.successes / (p.successes + p.failures)
    assert.ok(Math.abs(winRateBefore - winRateAfter) < 1e-9, 'le winRate ne doit pas être altéré par le decay')
  })

  test('B4 — la confiance redescend de "high" après plusieurs decays', () => {
    for (let i = 0; i < 30; i++) router.update('schema', 'db', 'success')
    assert.equal(router.recommend('schema').confidence, 'high', 'pré-condition : high')

    for (let i = 0; i < 24; i++) router.decay(0.9, { ewc: false })

    const after = router.recommend('schema')
    assert.notEqual(after.confidence, 'high',
      'la confiance doit pouvoir redescendre — sinon exploration et garde-fou contextuel restent fermés à vie')
    const p = router.loadState().priors['schema:db']
    assert.ok(p.successes < 5, `successes attendu << 30 après 24 decays, reçu ${p.successes}`)
  })

  test('B4 — un choix substituable redevient "low" (exploration Thompson rouverte)', () => {
    for (let i = 0; i < 30; i++) router.update(THOMPSON_PHASE, T_A, 'success')
    assert.equal(router.recommend(THOMPSON_PHASE).confidence, 'high')
    for (let i = 0; i < 24; i++) router.decay(0.9, { ewc: false })
    const conf = router.recommend(THOMPSON_PHASE).confidence
    assert.ok(['low', 'none', 'medium'].includes(conf), `confiance attendue basse, reçue ${conf}`)
  })

  // B3 — la protection EWC doit dépendre de la RÉCENCE, pas du volume d'historique.
  test('B3 — un prior massif mais ancien décaie au facteur NOMINAL (pas de gel)', () => {
    for (let i = 0; i < 200; i++) router.update('schema', 'db', 'success')   // α=201, très "certain"
    for (let i = 0; i < 3;   i++) router.update('specs', 'tester', 'success') // α=4, récent

    // Rendre le gros prior silencieux depuis 1 an
    const st = router.loadState()
    st.priors['schema:db'].lastUpdatedAt = new Date(Date.now() - 365 * 86_400_000).toISOString()
    router.saveState(st)

    const oldBefore = router.loadState().priors['schema:db'].alpha
    const newBefore = router.loadState().priors['specs:tester'].alpha

    router.decay(0.9, { ewc: true, ewcStrength: 0.8 })

    const oldAfter = router.loadState().priors['schema:db'].alpha
    const newAfter = router.loadState().priors['specs:tester'].alpha
    const oldRatio = oldAfter / oldBefore
    const newRatio = newAfter / newBefore

    // Récence à 365j ≈ 2×10⁻⁴ (demi-vie 30j) → protection résiduelle négligeable :
    // le facteur effectif colle au nominal 0.9 à moins de 0.1% près.
    assert.ok(oldRatio >= 0.9 && oldRatio < 0.9 + 0.001,
      `prior ancien : facteur nominal ≈0.9 attendu, reçu ${oldRatio.toFixed(6)}`)
    assert.ok(newRatio > oldRatio,
      `le prior RÉCENT doit être le plus protégé (récent=${newRatio.toFixed(4)} ancien=${oldRatio.toFixed(4)})`)
  })

  test('B3 — un prior récent et certain reste protégé', () => {
    for (let i = 0; i < 50; i++) router.update('schema', 'db', 'success')
    const before = router.loadState().priors['schema:db'].alpha
    router.decay(0.9, { ewc: true, ewcStrength: 0.8 })
    const ratio = router.loadState().priors['schema:db'].alpha / before
    assert.ok(ratio > 0.9, `un prior renforcé à l'instant doit être protégé (ratio=${ratio.toFixed(4)})`)
    assert.ok(ratio < 1,   'aucun prior ne doit être gelé (ratio < 1 strictement)')
  })

  test('lève erreur si factor hors ]0,1[', () => {
    assert.throws(() => router.decay(1.5), /factor/)
    assert.throws(() => router.decay(0),   /factor/)
  })

  test('update horodate le prior (lastUpdatedAt) — support de la récence EWC', () => {
    router.update('schema', 'db', 'success')
    const p = router.loadState().priors['schema:db']
    assert.ok(p.lastUpdatedAt, 'lastUpdatedAt doit être écrit par update()')
    assert.ok(Date.now() - Date.parse(p.lastUpdatedAt) < 60_000, 'lastUpdatedAt doit être récent')
  })
})

// ─── recommendWithContext ─────────────────────────────────────────────────────

describe('recommendWithContext — choix substituable (Thompson légitime)', () => {
  test('contexte force le candidat si confiance low', () => {
    // Pas de données → confiance none → contexte prend la main
    const r = router.recommendWithContext(THOMPSON_PHASE, T_B)
    assert.equal(r.agent, T_B)
    assert.equal(r.confidence, 'context')
  })

  test('Thompson Sampling garde la main si confiance high', () => {
    // 100 succès sur T_A → α=101, β=1 → P(T_A gagne) ≈ 99%
    for (let i = 0; i < 100; i++) router.update(THOMPSON_PHASE, T_A, 'success')
    let passed = false
    for (let attempt = 0; attempt < 5; attempt++) {
      const r = router.recommendWithContext(THOMPSON_PHASE, T_B)
      if (r.confidence !== 'context') { passed = true; break }
    }
    assert.ok(passed, 'Thompson devrait prendre la main avec confiance high (α=101)')
  })

  test('contexte invalide (pas un candidat) → Thompson normal', () => {
    const r = router.recommendWithContext(THOMPSON_PHASE, 'unknown-agent')
    assert.ok([T_A, T_B].includes(r.agent))
    assert.notEqual(r.confidence, 'context')
  })
})

// ─── B1 — la stack n'est JAMAIS arbitrée par Thompson ─────────────────────────
//
// Ces tests remplacent les anciens (« backend a 2 candidats nestjs/drf »,
// « le contexte ne s'applique qu'en confiance low ») qui validaient le bug :
// avec des priors égaux et un contexte 'nestjs' explicite, le routeur envoyait
// un agent Django sur un projet NestJS ~46-50% du temps.

describe('B1 — sélection de stack déterministe', () => {
  test('nestjs/drf ne sont plus une paire arbitrée par Thompson', () => {
    const { PHASE_CANDIDATES } = router
    for (const key of Object.keys(PHASE_CANDIDATES)) {
      const c = PHASE_CANDIDATES[key]
      assert.ok(!(c.includes('nestjs') && c.includes('drf')),
        `PHASE_CANDIDATES.${key} mélange deux stacks backend incompatibles : ${c.join(', ')}`)
    }
    assert.equal(PHASE_CANDIDATES.backend, undefined, "'backend' ne doit plus être arbitré par Thompson")
    assert.equal(PHASE_CANDIDATES['task:backend'], undefined)
  })

  test('aucune paire de PHASE_CANDIDATES ne mélange deux stacks/plateformes', () => {
    const { PHASE_CANDIDATES, stackExclusiveFamily } = router
    for (const [key, candidates] of Object.entries(PHASE_CANDIDATES)) {
      assert.equal(stackExclusiveFamily(candidates), null,
        `PHASE_CANDIDATES.${key} est un choix de stack, pas un choix substituable : ${candidates.join(', ')}`)
    }
  })

  test('REPRO B1 — priors égaux + contexte nestjs → JAMAIS drf (0/500)', () => {
    for (let i = 0; i < 30; i++) router.update('backend', 'nestjs', 'success')
    for (let i = 0; i < 30; i++) router.update('backend', 'drf', 'success')
    let drf = 0
    for (let i = 0; i < 500; i++) {
      const r = router.recommendWithContext('backend', 'nestjs', { candidates: ['nestjs', 'drf'] })
      if (r.agent !== 'nestjs') drf++
    }
    assert.equal(drf, 0, `le contexte de stack doit être absolu — ${drf}/500 routages incompatibles`)
  })

  test('le contexte de stack gagne MÊME avec des priors écrasants pour l\'autre stack', () => {
    for (let i = 0; i < 200; i++) router.update('backend', 'drf', 'success')
    const r = router.recommendWithContext('backend', 'nestjs', { candidates: ['nestjs', 'drf'] })
    assert.equal(r.agent, 'nestjs')
    assert.equal(r.confidence, 'stack')
    assert.equal(r.stackSource, 'context')
  })

  test('la stack déclarée l\'emporte dans les deux sens (drf aussi)', () => {
    for (let i = 0; i < 200; i++) router.update('backend', 'nestjs', 'success')
    const r = router.recommendWithContext('backend', 'drf', { candidates: ['nestjs', 'drf'] })
    assert.equal(r.agent, 'drf')
    assert.equal(r.confidence, 'stack')
  })

  test('recommend() sur une paire de stack est déterministe (pas de tirage)', () => {
    for (let i = 0; i < 30; i++) router.update('backend', 'nestjs', 'success')
    for (let i = 0; i < 30; i++) router.update('backend', 'drf', 'success')
    const agents = new Set()
    for (let i = 0; i < 200; i++) agents.add(router.recommend('backend', { candidates: ['nestjs', 'drf'] }).agent)
    assert.equal(agents.size, 1, `déterministe attendu, reçu : ${[...agents].join('/')}`)
  })

  test('les phases de stack restent résolvables (pas de agent:null)', () => {
    for (const phase of Object.keys(router.STACK_PHASE_CANDIDATES)) {
      const r = router.recommend(phase)
      assert.ok(r.agent, `${phase} doit retourner un agent déterministe, reçu ${r.agent}`)
      assert.equal(r.confidence, 'stack')
      assert.ok(r.sample >= 0 && r.sample <= 1)
    }
  })

  test('familles de stacks : iOS↔Android et web↔mobile aussi', () => {
    const { stackExclusiveFamily, stackFamilyOf } = router
    assert.ok(stackExclusiveFamily(['android', 'swift']))
    assert.ok(stackExclusiveFamily(['nextjs', 'react-native']))
    assert.ok(stackExclusiveFamily(['react-native', 'android', 'swift']))
    assert.equal(stackFamilyOf('drf').name, 'backend')
    assert.equal(stackFamilyOf('reviewer'), null)
  })

  test('spécialiste vs généraliste d\'une MÊME stack reste arbitré par Thompson', () => {
    // ['graphql','nestjs'] : nestjs est dans une famille de stack, graphql non
    // → ce n'est pas un choix de stack, Thompson doit rester compétent.
    assert.equal(router.stackExclusiveFamily(['graphql', 'nestjs']), null)
    const r = router.recommend('task:graphql')
    assert.ok(['graphql', 'nestjs'].includes(r.agent))
    assert.notEqual(r.confidence, 'stack')
  })

  test('resolveStackChoice — priorité contexte > détection > défaut', () => {
    const { resolveStackChoice } = router
    // 1. contexte explicite
    assert.deepEqual(resolveStackChoice(['nestjs', 'drf'], 'drf', { cwd: TMP }), { agent: 'drf', source: 'context' })
    // 2. détection disque (aucun marqueur dans TMP) → 3. défaut = 1er candidat
    assert.deepEqual(resolveStackChoice(['nestjs', 'drf'], null, { cwd: TMP }), { agent: 'nestjs', source: 'default' })
    // contexte hors candidats → ignoré
    assert.equal(resolveStackChoice(['nestjs', 'drf'], 'swift', { cwd: TMP }).source, 'default')
  })

  test('detectProjectStack lit les marqueurs réels du disque', () => {
    const dir = join(TMP, 'proj-drf')
    mkdirSync(dir, { recursive: true })
    writeFileSync(join(dir, 'manage.py'), '# django')
    assert.equal(router.detectProjectStack(['nestjs', 'drf'], dir), 'drf')

    const dir2 = join(TMP, 'proj-nest')
    mkdirSync(dir2, { recursive: true })
    writeFileSync(join(dir2, 'nest-cli.json'), '{}')
    assert.equal(router.detectProjectStack(['nestjs', 'drf'], dir2), 'nestjs')

    assert.equal(router.detectProjectStack(['nestjs', 'drf'], join(TMP, 'proj-vide')), null)
  })
})

// ─── PHASE_CANDIDATES ─────────────────────────────────────────────────────────

describe('PHASE_CANDIDATES', () => {
  test('contient les phases core', () => {
    const { PHASE_CANDIDATES } = router
    assert.ok(PHASE_CANDIDATES.schema)
    assert.ok(PHASE_CANDIDATES.review)
    assert.ok(PHASE_CANDIDATES['task:data'])
  })

  test('B2 — les phases pipeline à vrai choix substituable sont qualifiées', () => {
    const { PHASE_CANDIDATES } = router
    // Phases de pipelines.json où ≥2 agents sont objectivement qualifiés
    for (const [phase, expected] of Object.entries({
      review:       ['reviewer', 'security-auditor'],
      deps:         ['reviewer', 'security-auditor'],
      safety:       ['reviewer', 'migration-strategist'],
      'data-model': ['data-modeler', 'db'],
    })) {
      assert.deepEqual(PHASE_CANDIDATES[phase], expected, `PHASE_CANDIDATES.${phase}`)
      assert.ok(PHASE_CANDIDATES[phase].length > 1, `${phase} doit donner du grain à moudre à Thompson`)
    }
  })

  test('les candidats sont des agents distincts et non vides', () => {
    for (const [key, c] of Object.entries(router.PHASE_CANDIDATES)) {
      assert.ok(Array.isArray(c) && c.length >= 1, `${key} : liste vide`)
      assert.equal(new Set(c).size, c.length, `${key} : doublons`)
    }
  })
})

// ─── Agent Booster Tier 0 ─────────────────────────────────────────────────────

describe('recommend — Agent Booster Tier 0', () => {
  test('opts.content avec code boostable → retourne agent __booster__', () => {
    // Code contenant var → boostable par var-to-const
    const code = "var x = 1\nvar y = 2\nvar z = 3\nconsole.log(x, y, z)\nreturn x + y + z"
    const r = router.recommend('backend', { content: code })
    assert.equal(r.agent, '__booster__')
    assert.equal(r.tier, 0)
    assert.equal(r.confidence, 'booster')
    assert.equal(r.winRate, 1.0)
    assert.ok(r.boosterRule, 'boosterRule doit être défini')
    assert.ok(r.reason.includes('Tier 0'))
  })

  test('opts.content avec code propre → Thompson Sampling normal', () => {
    // Code propre sans règles applicables
    const code = "'use strict'\nconst x = 1\nreturn x"
    const r = router.recommend(THOMPSON_PHASE, { content: code })
    // Ne doit PAS retourner __booster__
    assert.notEqual(r.agent, '__booster__')
    assert.ok([T_A, T_B].includes(r.agent))
  })

  test('sans opts.content → Thompson Sampling normal', () => {
    const r = router.recommend(THOMPSON_PHASE)
    assert.notEqual(r.agent, '__booster__')
    assert.ok([T_A, T_B].includes(r.agent))
  })

  test('le tier 0 booster prime même sur une phase de stack', () => {
    const code = "var x = 1\nvar y = 2\nvar z = 3\nconsole.log(x, y, z)\nreturn x + y + z"
    const r = router.recommend('backend', { content: code })
    assert.equal(r.agent, '__booster__')
    assert.equal(r.tier, 0)
  })

  test('recommend avec code boostable retourne boosterRule dans la réponse', () => {
    const code = "var a = 1\nvar b = 2"
    const r = router.recommend('task:backend', { content: code })
    if (r.agent === '__booster__') {
      assert.ok(typeof r.boosterRule === 'string')
      assert.ok(r.boosterRule.length > 0)
    }
    // Si pas boosté (confidence trop faible pour ce contenu court) → Thompson
    // Le test est satisfait dans les deux cas
  })
})
