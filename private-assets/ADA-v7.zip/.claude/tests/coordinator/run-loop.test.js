#!/usr/bin/env node
'use strict'
/**
 * tests/coordinator/run-loop.test.js
 *
 * Suite RED : ces tests échouent tant que run.js ne supporte pas :
 *   - run.js fail ... --error-output <file>  → stocke errorContext dans state
 *   - run.js next ... → inclut loopContext si phase en loop-back
 *   - Le mécanisme loopTo + maxLoops dans pipelines.json
 *
 * Ces tests complètent run.test.js (existant) — ne testent que le loop.
 */

const { describe, it, before, after } = require('node:test')
const assert = require('node:assert/strict')
const { mkdirSync, rmSync, existsSync, readFileSync, writeFileSync } = require('node:fs')
const { join } = require('node:path')
const { execSync } = require('node:child_process')
const os = require('node:os')

const TMP    = join(os.tmpdir(), `ada-run-loop-test-${process.pid}`)
const RUN_JS = join(__dirname, '../../coordinator/run.js')

// Pipeline de test : coverage → loop-back → backend (max 3 boucles)
const PIPELINES = {
  feature: {
    description: 'Test pipeline avec loop',
    onFailure: 'stop',
    phases: [
      {
        id: 'schema',   agent: 'db',       depends: [],          required: true,
        maxRetries: 1,  stopOnFailure: true
      },
      {
        id: 'specs',    agent: 'tester',   depends: ['schema'],  required: true,
        maxRetries: 1,  stopOnFailure: true
      },
      {
        id: 'backend',  agent: 'nestjs',   depends: ['specs'],   required: true,
        maxRetries: 2,  stopOnFailure: true, agentSelector: 'backend', agentAlt: 'drf'
      },
      {
        id: 'coverage', agent: 'tester',   depends: ['backend'], required: true,
        maxRetries: 1,  stopOnFailure: false,
        loopTo: 'backend',   // ← extension AI engineering loop
        maxLoops: 3,         // ← garde
        loopCondition: 'test_failures'
      },
      {
        id: 'review',   agent: 'reviewer', depends: ['coverage'], required: true,
        maxRetries: 0,  stopOnFailure: true
      }
    ]
  }
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function run(args) {
  try {
    const out = execSync(`node "${RUN_JS}" ${args}`, {
      env: { ...process.env, CLAUDE_CONFIG_DIR: TMP },
      encoding: 'utf8',
    })
    return { code: 0, out }
  } catch (e) {
    return { code: e.status || 1, out: (e.stdout || '') + (e.stderr || '') }
  }
}

function stateOf(runId) {
  const f = join(TMP, 'runs', runId, 'state.json')
  return JSON.parse(readFileSync(f, 'utf8'))
}

function initRun(name = 'loop-feature') {
  const { out } = run(`init feature "${name}"`)
  const m = out.match(/(feature-[\w-]+-\d{8}-\d{4})/)
  assert.ok(m, `runId introuvable dans: ${out}`)
  return m[1]
}

function writeErrorFile(content) {
  const f = join(TMP, `error-${Date.now()}.txt`)
  writeFileSync(f, content)
  return f
}

// ── Setup / Teardown ──────────────────────────────────────────────────────────

before(() => {
  mkdirSync(join(TMP, 'coordinator'), { recursive: true })
  mkdirSync(join(TMP, 'runs'),        { recursive: true })
  writeFileSync(
    join(TMP, 'coordinator', 'pipelines.json'),
    JSON.stringify(PIPELINES, null, 2)
  )
})

after(() => { try { rmSync(TMP, { recursive: true, force: true }) } catch {} })

// ─── Stockage errorContext dans state.json ────────────────────────────────────

describe('run.js fail --error-output : stockage du contexte d\'erreur', () => {
  it('stocke un errorContext structuré dans state.phases[phaseId]', () => {
    const runId  = initRun('store-error')
    const errFile = writeErrorFile(
      `src/auth/auth.service.ts(47,15): error TS2339: Property 'userId' does not exist on type 'JwtPayload'.`
    )

    run(`start ${runId} schema`)
    run(`done  ${runId} schema "schema ok"`)
    run(`start ${runId} specs`)
    run(`done  ${runId} specs "specs ok"`)
    run(`start ${runId} backend`)
    run(`fail  ${runId} backend "TypeScript error" --error-output "${errFile}"`)

    const state = stateOf(runId)
    const ec = state.phases.backend.errorContext

    assert.ok(ec, 'errorContext doit exister sur la phase')
    assert.ok(Array.isArray(ec.errors), 'errors doit être un tableau')
    assert.ok(ec.errors.length > 0, 'au moins 1 erreur parsée')
    assert.equal(ec.errors[0].type, 'typescript')
    assert.equal(ec.errors[0].file, 'src/auth/auth.service.ts')
    assert.equal(ec.errors[0].line, 47)
    assert.ok(typeof ec.formattedBlock === 'string' && ec.formattedBlock.length > 0)
  })

  it('stocke errorContext même avec plusieurs types d\'erreurs mélangés', () => {
    const runId  = initRun('mixed-errors')
    const errFile = writeErrorFile([
      `src/auth/auth.service.ts(47,15): error TS2339: Property 'userId' does not exist.`,
      `not ok 1 - should return 401 if token invalid`,
    ].join('\n'))

    run(`start ${runId} schema`)
    run(`done  ${runId} schema "ok"`)
    run(`start ${runId} specs`)
    run(`done  ${runId} specs "ok"`)
    run(`start ${runId} backend`)
    run(`fail  ${runId} backend "mixed failure" --error-output "${errFile}"`)

    const ec = stateOf(runId).phases.backend.errorContext
    assert.ok(ec.errors.length >= 2)
    const types = ec.errors.map(e => e.type)
    assert.ok(types.includes('typescript'))
    assert.ok(types.includes('test'))
  })

  it('n\'écrase pas un errorContext si --error-output absent (comportement actuel inchangé)', () => {
    const runId = initRun('no-error-file')
    run(`start ${runId} schema`)
    run(`done  ${runId} schema "ok"`)
    run(`start ${runId} specs`)
    run(`fail  ${runId} specs "timeout"`)

    const state = stateOf(runId)
    // Pas de errorContext si pas de --error-output
    assert.ok(
      !state.phases.specs.errorContext || state.phases.specs.errorContext === null,
      'errorContext ne doit pas exister sans --error-output'
    )
  })
})

// ─── Loop-back coverage → backend ─────────────────────────────────────────────

describe('loop-back : coverage → backend (loopTo configuré)', () => {
  function setupUntilCoverage(runId) {
    run(`start ${runId} schema`)
    run(`done  ${runId} schema "schema ok"`)
    run(`start ${runId} specs`)
    run(`done  ${runId} specs "specs ok"`)
    run(`start ${runId} backend`)
    run(`done  ${runId} backend "backend ok"`)
    run(`start ${runId} coverage`)
  }

  it('remet backend en pending après un échec coverage avec loopTo', () => {
    const runId   = initRun('loop-back-basic')
    const errFile = writeErrorFile(`not ok 1 - should return 401`)
    setupUntilCoverage(runId)

    run(`fail ${runId} coverage "tests KO" --error-output "${errFile}"`)

    const state = stateOf(runId)
    assert.equal(state.phases.backend.status, 'pending',
      'backend doit être remis en pending après loop-back')
  })

  it('incrémente loopIteration dans le state global', () => {
    const runId   = initRun('loop-counter')
    const errFile = writeErrorFile(`not ok 1 - should create user`)
    setupUntilCoverage(runId)

    run(`fail ${runId} coverage "tests KO" --error-output "${errFile}"`)

    const state = stateOf(runId)
    assert.equal(state.loopIteration, 1,
      'loopIteration doit passer à 1 après le premier loop-back')
  })

  it('stocke loopContext sur la phase backend remise en pending', () => {
    const runId   = initRun('loop-context-store')
    const errFile = writeErrorFile(`not ok 1 - should return 401 if token invalid`)
    setupUntilCoverage(runId)

    run(`fail ${runId} coverage "tests KO" --error-output "${errFile}"`)

    const state = stateOf(runId)
    const lc = state.phases.backend.loopContext
    assert.ok(lc && typeof lc === 'string' && lc.length > 0,
      'loopContext doit être stocké sur backend')
    assert.ok(lc.includes('401') || lc.includes('token'),
      'loopContext doit mentionner le contenu de l\'erreur')
  })

  it('run.js next retourne backend avec isLoopRetry:true après loop-back', () => {
    const runId   = initRun('loop-next')
    const errFile = writeErrorFile(`not ok 1 - should return 401`)
    setupUntilCoverage(runId)
    run(`fail ${runId} coverage "tests KO" --error-output "${errFile}"`)

    const { out } = run(`next ${runId} --json`)
    let next
    try { next = JSON.parse(out) } catch { assert.fail(`next output non-JSON: ${out}`) }

    const ready = next.ready || []
    const backendPhase = ready.find(p => p.phaseId === 'backend' || p.id === 'backend')
    assert.ok(backendPhase, `backend doit être dans ready: ${JSON.stringify(ready)}`)
    assert.equal(backendPhase.isLoopRetry, true)
    assert.ok(backendPhase.loopContext && backendPhase.loopContext.length > 0,
      'loopContext doit être dans la réponse next')
  })
})

// ─── Garde maxLoops ───────────────────────────────────────────────────────────

describe('garde maxLoops : escalade humaine après N itérations', () => {
  function fullLoopCycle(runId, errContent) {
    const errFile = writeErrorFile(errContent)
    run(`start ${runId} backend`)
    run(`done  ${runId} backend "backend impl"`)
    run(`start ${runId} coverage`)
    run(`fail  ${runId} coverage "tests KO" --error-output "${errFile}"`)
  }

  it('ne déclenche PAS de loop-back si loopIteration >= maxLoops (3)', () => {
    const runId = initRun('max-loops')
    run(`start ${runId} schema`)
    run(`done  ${runId} schema "ok"`)
    run(`start ${runId} specs`)
    run(`done  ${runId} specs "ok"`)

    // Boucles 1, 2, 3
    for (let i = 0; i < 3; i++) {
      fullLoopCycle(runId, `not ok 1 - still failing at loop ${i + 1}`)
    }

    const state = stateOf(runId)
    // Après 3 loop-backs, coverage doit être en failed (escalade humaine)
    assert.equal(state.phases.coverage.status, 'failed',
      'coverage doit être failed après maxLoops atteint')
    // backend ne doit plus être remis en pending
    assert.notEqual(state.phases.backend.status, 'pending',
      'backend ne doit pas être remis en pending après maxLoops')
  })

  it('state.loopIteration === maxLoops après la dernière boucle', () => {
    const runId = initRun('max-loops-counter')
    run(`start ${runId} schema`)
    run(`done  ${runId} schema "ok"`)
    run(`start ${runId} specs`)
    run(`done  ${runId} specs "ok"`)

    for (let i = 0; i < 3; i++) {
      fullLoopCycle(runId, `not ok 1 - fail ${i}`)
    }

    const state = stateOf(runId)
    assert.equal(state.loopIteration, 3)
  })

  it('le message d\'erreur mentionne LOOP LIMIT quand maxLoops atteint', () => {
    const runId = initRun('loop-limit-msg')
    run(`start ${runId} schema`)
    run(`done  ${runId} schema "ok"`)
    run(`start ${runId} specs`)
    run(`done  ${runId} specs "ok"`)

    for (let i = 0; i < 3; i++) {
      fullLoopCycle(runId, `not ok 1 - fail ${i}`)
    }

    const state = stateOf(runId)
    const summary = state.phases.coverage.summary || ''
    assert.ok(
      summary.toUpperCase().includes('LOOP') || summary.toUpperCase().includes('LIMIT'),
      `summary doit mentionner LOOP LIMIT: "${summary}"`
    )
  })
})

// ─── Pas de loop-back si loopTo absent (non-régression) ──────────────────────

describe('pas de loop-back si loopTo non défini (régression)', () => {
  it('review failure → pipeline failed (comportement actuel inchangé)', () => {
    const runId = initRun('no-loop-review')
    run(`start ${runId} schema`)
    run(`done  ${runId} schema "ok"`)
    run(`start ${runId} specs`)
    run(`done  ${runId} specs "ok"`)
    run(`start ${runId} backend`)
    run(`done  ${runId} backend "ok"`)
    run(`start ${runId} coverage`)
    run(`done  ${runId} coverage "ok"`)
    run(`start ${runId} review`)
    run(`fail  ${runId} review "security issue"`)

    const state = stateOf(runId)
    // review n'a pas de loopTo → fail direct
    assert.equal(state.phases.review.status, 'failed')
    // aucune phase précédente ne doit être remise en pending
    assert.notEqual(state.phases.backend.status, 'pending',
      'backend ne doit pas être touché par le fail de review')
    assert.notEqual(state.phases.coverage.status, 'pending',
      'coverage ne doit pas être touchée par le fail de review')
  })
})

// ─── Erreurs non-déterministes : pas de loop-back ────────────────────────────

describe('erreurs non-déterministes : pas de loop-back', () => {
  const nonDeterministic = [
    { name: 'ECONNREFUSED', content: `Error: ECONNREFUSED 127.0.0.1:5432` },
    { name: 'ETIMEDOUT',    content: `Error: ETIMEDOUT` },
    { name: 'OOM',          content: `FATAL ERROR: CALL_AND_RETRY_LAST Allocation failed - JavaScript heap out of memory` },
  ]

  for (const { name, content } of nonDeterministic) {
    it(`${name} → pas de loop-back, fail immédiat`, () => {
      const runId   = initRun(`non-det-${name.toLowerCase()}`)
      const errFile = writeErrorFile(content)

      run(`start ${runId} schema`)
      run(`done  ${runId} schema "ok"`)
      run(`start ${runId} specs`)
      run(`done  ${runId} specs "ok"`)
      run(`start ${runId} backend`)
      run(`done  ${runId} backend "ok"`)
      run(`start ${runId} coverage`)
      run(`fail  ${runId} coverage "${name}" --error-output "${errFile}"`)

      const state = stateOf(runId)
      assert.notEqual(state.phases.backend.status, 'pending',
        `${name} ne doit pas déclencher un loop-back sur backend`)
      assert.equal(state.loopIteration, 0,
        `loopIteration doit rester à 0 pour une erreur non-déterministe`)
    })
  }
})
