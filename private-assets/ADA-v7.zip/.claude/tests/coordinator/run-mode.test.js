#!/usr/bin/env node
'use strict'
/**
 * run-mode.test.js — décision de routing PURE de `ada run` (resolveRunMode).
 *
 * Vérifie le câblage du classifieur dans cmdRun SANS rien spawner :
 *  - override pipeline explicite (compat ascendante `ada run feature`)
 *  - texte libre → solo (défaut) / pipeline (multi-livrables)
 *  - flags --solo / --pipeline <name>
 *  - fallback feature si pipeline classifié inconnu
 *  - extraction de la description en présence de flags
 *
 * Fonction pure : on injecte classifyTask (réel ou stub) — aucun I/O.
 */
const { test, describe } = require('node:test')
const assert = require('node:assert/strict')

const { resolveRunMode, loadTierModels, slugifyName } = require('../../bin/ada.js')
const { classifyTask } = require('../../coordinator/task-classifier.js')

const ALLOWED = ['feature', 'review', 'db-migrate', 'test', 'audit', 'deploy', 'security-audit', 'migration', 'hotfix', 'mobile', 'saas-bootstrap']

// Stub déterministe : renvoie ce qu'on lui dit, pour isoler la logique de routing.
function stub(out) {
  return () => ({ mode: 'solo', pipeline: null, tier: 2, signals: [], reason: 'stub', ...out })
}

describe('resolveRunMode — override pipeline explicite (compat ascendante)', () => {
  test('args[0] pipeline connu → mode pipeline, forced=pipeline-arg, classifieur ignoré', () => {
    const calls = []
    const spy = (d) => { calls.push(d); return { mode: 'solo', pipeline: null, tier: 1, signals: [], reason: 'x' } }
    const r = resolveRunMode(['feature'], ALLOWED, spy)
    assert.equal(r.mode, 'pipeline')
    assert.equal(r.pipeline, 'feature')
    assert.equal(r.forced, 'pipeline-arg')
    assert.equal(r.desc, '')
    assert.equal(calls.length, 0) // le classifieur n'est pas consulté pour le mode
  })

  test('pipeline explicite + --name : nom capté comme positionnel, hors extraArgs', () => {
    const r = resolveRunMode(['review', '--name', 'pr-42'], ALLOWED, stub())
    assert.equal(r.mode, 'pipeline')
    assert.equal(r.pipeline, 'review')
    assert.equal(r.name, 'pr-42')
    assert.deepEqual(r.extraArgs, [])
  })

  test('pipeline explicite + nom positionnel : reste dans extraArgs (compat run.js)', () => {
    const r = resolveRunMode(['feature', 'mon-truc'], ALLOWED, stub())
    assert.equal(r.mode, 'pipeline')
    assert.equal(r.pipeline, 'feature')
    assert.deepEqual(r.extraArgs, ['mon-truc'])
  })
})

describe('resolveRunMode — downgrade solo sur pipeline nu (F14)', () => {
  test('pipeline nu + description solo (≥2 mots) → downgrade solo avec warning, classifieur consulté', () => {
    const calls = []
    const spy = (d) => { calls.push(d); return { mode: 'solo', pipeline: null, tier: 2, signals: ['edition-ciblee'], reason: 'solo stub' } }
    const r = resolveRunMode(['feature', 'corrige', 'le', 'bug', 'des', 'deals'], ALLOWED, spy)
    assert.equal(r.mode, 'solo')
    assert.equal(r.pipeline, null)
    assert.equal(r.forced, null)
    assert.equal(r.downgradedFrom, 'feature')
    assert.ok(r.reason.includes('feature'), `reason doit expliquer le pipeline ignoré: ${r.reason}`)
    assert.deepEqual(calls, ['feature corrige le bug des deals'])
  })

  test('pipeline nu + description qui classe pipeline → pas de downgrade, comportement inchangé', () => {
    const r = resolveRunMode(['review', 'du', 'diff', 'courant'], ALLOWED, classifyTask)
    assert.equal(r.mode, 'pipeline')
    assert.equal(r.pipeline, 'review')
    assert.equal(r.forced, 'pipeline-arg')
    assert.ok(!r.downgradedFrom)
  })

  test('description réelle correspondant au bug rapporté (get-deals) → downgrade solo', () => {
    const r = resolveRunMode(
      ['feature', 'corrige', "l'affichage", 'des', 'deals', 'dans', 'la', 'liste'],
      ALLOWED, classifyTask)
    assert.equal(r.mode, 'solo')
    assert.equal(r.downgradedFrom, 'feature')
  })

  test('un seul mot après le pipeline (probable name positionnel) → classifieur non consulté, pipeline conservé', () => {
    const calls = []
    const spy = (d) => { calls.push(d); return { mode: 'solo', pipeline: null, tier: 2, signals: [], reason: 'x' } }
    const r = resolveRunMode(['feature', 'billing-v2'], ALLOWED, spy)
    assert.equal(r.mode, 'pipeline')
    assert.equal(calls.length, 0)
  })

  test('--pipeline force toujours, même si le classifieur dirait solo sur la même description', () => {
    const r = resolveRunMode(['--pipeline', 'feature', 'corrige', 'le', 'bug', 'des', 'deals'], ALLOWED, classifyTask)
    assert.equal(r.mode, 'pipeline')
    assert.equal(r.pipeline, 'feature')
    assert.equal(r.forced, 'flag-pipeline')
  })
})

describe('resolveRunMode — texte libre classifié', () => {
  test('description ciblée → solo (défaut), pas de pipeline', () => {
    const r = resolveRunMode(['corrige', 'le', 'bug', 'N+1'], ALLOWED, classifyTask)
    assert.equal(r.mode, 'solo')
    assert.equal(r.pipeline, null)
    assert.equal(r.forced, null)
    assert.equal(r.desc, 'corrige le bug N+1')
  })

  test('description vague sans signal → solo (le défaut est solo)', () => {
    const r = resolveRunMode(['ajuste', 'la', 'config'], ALLOWED, classifyTask)
    assert.equal(r.mode, 'solo')
    assert.equal(r.pipeline, null)
  })

  test('multi-livrables → pipeline + bon pipeline', () => {
    const r = resolveRunMode(
      ['cree', 'la', 'migration', 'le', 'service', 'et', 'les', 'tests'], ALLOWED, classifyTask)
    assert.equal(r.mode, 'pipeline')
    assert.equal(r.pipeline, 'feature')
    assert.equal(r.forced, null)
  })

  test('workflow review → pipeline review', () => {
    const r = resolveRunMode(['review', 'du', 'diff', 'courant'], ALLOWED, classifyTask)
    // "review" seul = pipeline connu → override ascendant. Ici phrase complète.
    assert.equal(r.mode, 'pipeline')
  })

  test('pipeline classifié inconnu → fallback feature', () => {
    const fake = stub({ mode: 'pipeline', pipeline: 'inexistant-xyz', tier: 2 })
    const r = resolveRunMode(['une', 'tache', 'composite'], ALLOWED, fake)
    assert.equal(r.mode, 'pipeline')
    assert.equal(r.pipeline, 'feature')
  })
})

describe('resolveRunMode — flags d\'override explicite', () => {
  test('--solo force solo même sur multi-livrables, garde le tier du classifieur', () => {
    const r = resolveRunMode(
      ['--solo', 'cree', 'migration', 'service', 'et', 'tests'], ALLOWED, classifyTask)
    assert.equal(r.mode, 'solo')
    assert.equal(r.pipeline, null)
    assert.equal(r.forced, 'flag-solo')
    assert.equal(r.desc, 'cree migration service et tests') // --solo retiré de la desc
    assert.ok(r.tier >= 1 && r.tier <= 3)
  })

  test('--pipeline <name> force ce pipeline (validé)', () => {
    const r = resolveRunMode(['--pipeline', 'audit', 'verifie', 'la', 'secu'], ALLOWED, classifyTask)
    assert.equal(r.mode, 'pipeline')
    assert.equal(r.pipeline, 'audit')
    assert.equal(r.forced, 'flag-pipeline')
    assert.equal(r.desc, 'verifie la secu')
  })

  test('--pipeline=name (forme accolée) supportée', () => {
    const r = resolveRunMode(['--pipeline=review', 'le', 'code'], ALLOWED, stub())
    assert.equal(r.pipeline, 'review')
    assert.equal(r.forced, 'flag-pipeline')
  })

  test('--pipeline <name> inconnu → fallback feature', () => {
    const r = resolveRunMode(['--pipeline', 'bidon', 'tache'], ALLOWED, stub())
    assert.equal(r.mode, 'pipeline')
    assert.equal(r.pipeline, 'feature')
  })

  test('--solo prioritaire dans la décision, --pipeline prioritaire sur --solo', () => {
    // --pipeline est testé en premier dans resolveRunMode → gagne
    const r = resolveRunMode(['--solo', '--pipeline', 'review', 'x'], ALLOWED, stub())
    assert.equal(r.mode, 'pipeline')
    assert.equal(r.pipeline, 'review')
  })
})

describe('resolveRunMode — extraction de description avec flags', () => {
  test('flags retirés, description propre reconstituée', () => {
    const r = resolveRunMode(['--solo', 'ajoute', 'un', 'champ', 'email'], ALLOWED, classifyTask)
    assert.equal(r.desc, 'ajoute un champ email')
  })

  test('args vide géré sans crash', () => {
    const r = resolveRunMode([], ALLOWED, stub())
    assert.equal(r.mode, 'solo')
    assert.equal(r.desc, '')
  })
})

describe('loadTierModels — mapping tier→modèle réutilisé du router', () => {
  test('renvoie un mapping valide pour les 3 tiers', () => {
    const m = loadTierModels()
    assert.ok(m[1] && m[2] && m[3])
    assert.match(m[1], /haiku/)
    assert.match(m[2], /sonnet/)
    assert.match(m[3], /opus/)
  })
})

describe('slugifyName — dérivation pure du nom de feature', () => {
  test('accents supprimés', () => {
    assert.equal(slugifyName('Créé la facturation'), 'cree-la-facturation')
  })

  test('ponctuation → tirets, pas de tirets de bord', () => {
    assert.equal(slugifyName('migration, service & tests !'), 'migration-service-tests')
  })

  test('multi-espaces compressés en un seul tiret', () => {
    assert.equal(slugifyName('a    b     c'), 'a-b-c')
  })

  test('troncature à ~40 caractères, sans tiret final', () => {
    const r = slugifyName('mot '.repeat(30))
    assert.ok(r.length <= 40)
    assert.ok(!r.endsWith('-'))
    assert.ok(!r.startsWith('-'))
  })

  test('chaîne vide → fallback task', () => {
    assert.equal(slugifyName(''), 'task')
    assert.equal(slugifyName('   '), 'task')
    assert.equal(slugifyName('!!!'), 'task')
    assert.equal(slugifyName(null), 'task')
  })

  test('ne garde que [a-z0-9-]', () => {
    assert.match(slugifyName('Façade_v2 (POC)'), /^[a-z0-9-]+$/)
  })
})

describe('resolveRunMode — nom de feature en mode pipeline', () => {
  test('pipeline classifié sans --name → slug dérivé de la description', () => {
    const r = resolveRunMode(
      ['crée', 'une', 'migration,', 'un', 'service', 'et', 'des', 'tests', 'pour', 'la', 'facturation'],
      ALLOWED, classifyTask)
    assert.equal(r.mode, 'pipeline')
    assert.ok(r.name && r.name.length > 0)
    assert.match(r.name, /^[a-z0-9-]+$/)
    assert.equal(r.name, slugifyName(r.desc))
  })

  test('--name explicite prioritaire sur le slug dérivé', () => {
    const fake = stub({ mode: 'pipeline', pipeline: 'feature', tier: 2 })
    const r = resolveRunMode(['--name', 'billing-v2', 'une', 'tache', 'composite'], ALLOWED, fake)
    assert.equal(r.mode, 'pipeline')
    assert.equal(r.name, 'billing-v2')
  })

  test('--name n\'est jamais réinjecté dans extraArgs', () => {
    const fake = stub({ mode: 'pipeline', pipeline: 'feature', tier: 2 })
    const r = resolveRunMode(['--name', 'billing', 'desc'], ALLOWED, fake)
    assert.ok(!r.extraArgs.includes('--name'))
    assert.ok(!r.extraArgs.includes('billing'))
  })

  test('--pipeline + --name → pipeline forcé avec nom explicite', () => {
    const r = resolveRunMode(['--pipeline', 'audit', '--name', 'secu-q3', 'verifie'], ALLOWED, stub())
    assert.equal(r.pipeline, 'audit')
    assert.equal(r.name, 'secu-q3')
  })

  test('override ascendant `ada run feature` : name reste null (compat inchangée)', () => {
    const r = resolveRunMode(['feature'], ALLOWED, stub())
    assert.equal(r.forced, 'pipeline-arg')
    assert.equal(r.name, null)
  })

  test('mode solo : name null', () => {
    const r = resolveRunMode(['corrige', 'un', 'typo'], ALLOWED, classifyTask)
    assert.equal(r.mode, 'solo')
    assert.equal(r.name, null)
  })
})
