#!/usr/bin/env node
'use strict'
/**
 * tests/coordinator/run-telemetry.test.js
 *
 * Fix 1 — Télémétrie tokens : fallback automatique dans run.js.
 *
 * Constat : l'orchestrateur ne passe presque jamais --tokens/--cost à
 * `run.js done`/`run.js fail` → totalTokens=0 sur la quasi-totalité des runs.
 *
 * Vérifie :
 *   - --tokens explicite → tokensSource='reported', totaux corrects
 *   - ni --tokens ni transcript → tokensSource absent + warning + event
 *     'telemetry.missing' dans run.log
 *   - ni --tokens, MAIS un transcript exploitable dans la fenêtre de la phase
 *     → tokensSource='estimated', tokens/cost dérivés du transcript réel
 *   - même mécanique côté `run.js fail`
 */
const { test, describe, before, after, beforeEach } = require('node:test')
const assert = require('node:assert/strict')
const { mkdirSync, rmSync, existsSync, readFileSync, writeFileSync } = require('fs')
const { join } = require('path')
const { execSync } = require('child_process')
const os = require('os')

const TMP    = join(os.tmpdir(), `ada-run-telemetry-test-${process.pid}`)
const RUN_JS = join(__dirname, '../../coordinator/run.js')

const PIPELINES = {
  feature: {
    description: 'Test pipeline (telemetry)',
    phases: [
      { id: 'schema', agent: 'db',     depends: [], required: true, maxRetries: 1, stopOnFailure: true },
      { id: 'specs',  agent: 'tester', depends: ['schema'], required: true, maxRetries: 1, stopOnFailure: true },
      { id: 'docs',   agent: 'tester', depends: [], required: false, maxRetries: 1, stopOnFailure: false },
    ]
  }
}

function run(args) {
  try {
    const out = execSync(`node "${RUN_JS}" ${args}`, {
      env: { ...process.env, CLAUDE_CONFIG_DIR: TMP },
      encoding: 'utf8',
    })
    return { code: 0, out }
  } catch (e) {
    return { code: e.status || 1, out: (e.stdout || '') + (e.stderr || '') }
  }
}

function stateOf(runId) {
  return JSON.parse(readFileSync(join(TMP, 'runs', runId, 'state.json'), 'utf8'))
}

function runLogOf(runId) {
  const f = join(TMP, 'runs', runId, 'run.log')
  if (!existsSync(f)) return []
  return readFileSync(f, 'utf8').split('\n').filter(Boolean).map(l => { try { return JSON.parse(l) } catch { return null } }).filter(Boolean)
}

function initRun(name) {
  const { out } = run(`init feature "${name}"`)
  const m = out.match(/(feature-[\w-]+-\d{8}-\d{4})/)
  assert.ok(m, `runId introuvable dans: ${out}`)
  return m[1]
}

/** Écrit un transcript JSONL exploitable dans TMP/projects/<proj>/<file>.jsonl */
function writeTranscript(projName, usage, timestampISO) {
  const dir = join(TMP, 'projects', projName)
  mkdirSync(dir, { recursive: true })
  const file = join(dir, `${projName}-${Date.now()}.jsonl`)
  const line = JSON.stringify({
    type: 'assistant',
    timestamp: timestampISO,
    message: { usage },
  })
  writeFileSync(file, line + '\n')
  return file
}

before(() => {
  mkdirSync(join(TMP, 'coordinator'), { recursive: true })
  mkdirSync(join(TMP, 'runs'), { recursive: true })
  writeFileSync(join(TMP, 'coordinator', 'pipelines.json'), JSON.stringify(PIPELINES, null, 2))
})

after(() => { try { rmSync(TMP, { recursive: true, force: true }) } catch {} })

// ─── run.js done ─────────────────────────────────────────────────────────────

describe('run.js done — télémétrie tokens', () => {
  test('--tokens explicite → tokensSource=reported, totaux exacts', () => {
    const runId = initRun('telemetry-reported')
    run(`start ${runId} schema`)
    run(`done ${runId} schema "ok" --tokens 1234 --cost 0.05`)
    const state = stateOf(runId)
    assert.equal(state.phases.schema.tokens, 1234)
    assert.equal(state.phases.schema.cost, 0.05)
    assert.equal(state.phases.schema.tokensSource, 'reported')
    assert.equal(state.totalTokens, 1234)
    assert.equal(state.totalCost, 0.05)
  })

  test('ni --tokens ni transcript exploitable → tokensSource absent + warning + event telemetry.missing', () => {
    const runId = initRun('telemetry-missing')
    run(`start ${runId} schema`)
    const { out } = run(`done ${runId} schema "ok"`)
    const state = stateOf(runId)
    assert.ok(!state.phases.schema.tokensSource, 'tokensSource ne doit pas être renseigné')
    assert.ok(out.includes('telemetry') || out.includes('télémétrie'), `warning attendu dans la sortie: ${out}`)
    const events = runLogOf(runId)
    assert.ok(events.some(e => e.event === 'telemetry.missing' && e.phaseId === 'schema'),
      `event telemetry.missing attendu dans run.log: ${JSON.stringify(events)}`)
  })

  test('fallback transcript : ni --tokens ni --cost, transcript exploitable dans la fenêtre → tokensSource=estimated', () => {
    const runId = initRun('telemetry-estimated')
    run(`start ${runId} schema`)

    // Transcript écrit APRÈS le start, AVANT le done — dans la fenêtre [startedAt, now].
    writeTranscript('telemetry-estimated-proj', {
      input_tokens: 800,
      cache_creation_input_tokens: 0,
      cache_read_input_tokens: 0,
      output_tokens: 200,
    }, new Date().toISOString())

    run(`done ${runId} schema "ok"`)
    const state = stateOf(runId)
    assert.equal(state.phases.schema.tokensSource, 'estimated')
    assert.equal(state.phases.schema.tokens, 1000)
    assert.ok(state.phases.schema.cost > 0, 'cost estimé doit être > 0')
    assert.equal(state.totalTokens, 1000)
  })

  test('fallback ignore les lignes hors fenêtre temporelle (transcript trop ancien)', () => {
    const runId = initRun('telemetry-out-of-window')
    run(`start ${runId} schema`)

    // Transcript très ancien — hors fenêtre [startedAt, now] → pas de fallback exploitable.
    writeTranscript('telemetry-old-proj', {
      input_tokens: 500, output_tokens: 100,
    }, new Date('2000-01-01T00:00:00.000Z').toISOString())

    const { out } = run(`done ${runId} schema "ok"`)
    const state = stateOf(runId)
    assert.ok(!state.phases.schema.tokensSource)
    assert.ok(out.includes('telemetry') || out.includes('télémétrie'))
  })
})

// ─── Fix 2 — double comptage en parallel_mesh (watermark) ────────────────────

describe('run.js done — parallel_mesh, pas de double comptage télémétrie', () => {
  test('2 phases indépendantes partageant le même dossier de transcripts ne comptent le transcript qu\'une fois', () => {
    const runId = initRun('telemetry-parallel-mesh')

    // schema et docs sont deux phases indépendantes (docs n'a pas de depends) —
    // elles peuvent tourner "en parallèle" (même sans vraie concurrence process,
    // leurs fenêtres [startedAt, now] se chevauchent sur le même dossier transcripts).
    run(`start ${runId} schema`)
    run(`start ${runId} docs`)

    // Un SEUL transcript, écrit une fois, dans la fenêtre commune aux deux phases.
    writeTranscript('telemetry-parallel-mesh-proj', {
      input_tokens: 900,
      output_tokens: 100,
    }, new Date().toISOString())

    // Complète 'schema' d'abord (sans --tokens → fallback estimé) : doit capter
    // les 1000 tokens du transcript et faire avancer le watermark du run.
    run(`done ${runId} schema "ok"`)
    let state = stateOf(runId)
    assert.equal(state.phases.schema.tokensSource, 'estimated')
    assert.equal(state.phases.schema.tokens, 1000)
    assert.equal(state.totalTokens, 1000)

    // Complète 'docs' ensuite : sa fenêtre part maintenant du watermark (après le
    // transcript), donc elle ne doit RIEN retrouver dans le même transcript déjà
    // compté — pas de double comptage.
    run(`done ${runId} docs "ok"`)
    state = stateOf(runId)
    assert.ok(!state.phases.docs.tokensSource, 'docs ne doit pas re-capter le transcript déjà compté par schema')

    // Le total ne doit surtout PAS être 2000 (double comptage du même transcript).
    assert.equal(state.totalTokens, 1000)
  })
})

// ─── run.js fail ─────────────────────────────────────────────────────────────

describe('run.js fail — télémétrie tokens', () => {
  test('--tokens explicite sur fail → tokensSource=reported', () => {
    const runId = initRun('telemetry-fail-reported')
    run(`start ${runId} schema`)
    run(`fail ${runId} schema "boom" --tokens 500 --cost 0.02`)
    const state = stateOf(runId)
    assert.equal(state.phases.schema.tokensSource, 'reported')
    assert.equal(state.phases.schema.tokens, 500)
  })

  test('fail sans --tokens ni transcript → event telemetry.missing loggé', () => {
    const runId = initRun('telemetry-fail-missing')
    run(`start ${runId} schema`)
    run(`fail ${runId} schema "boom"`)
    const events = runLogOf(runId)
    assert.ok(events.some(e => e.event === 'telemetry.missing' && e.phaseId === 'schema'))
  })

  test('fail avec fallback transcript exploitable → tokensSource=estimated', () => {
    const runId = initRun('telemetry-fail-estimated')
    run(`start ${runId} schema`)
    writeTranscript('telemetry-fail-proj', {
      input_tokens: 300, output_tokens: 100,
    }, new Date().toISOString())
    run(`fail ${runId} schema "boom"`)
    const state = stateOf(runId)
    assert.equal(state.phases.schema.tokensSource, 'estimated')
    assert.equal(state.phases.schema.tokens, 400)
  })
})
