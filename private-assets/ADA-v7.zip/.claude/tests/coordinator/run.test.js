#!/usr/bin/env node
'use strict'
const { test, describe, before, after, beforeEach } = require('node:test')
const assert = require('node:assert/strict')
const { mkdirSync, rmSync, existsSync, readFileSync, writeFileSync } = require('fs')
const { join } = require('path')
const { execSync } = require('child_process')

const TMP = join(__dirname, '../../..', '.test-tmp-run')
const RUN_JS = join(__dirname, '../../coordinator/run.js')
const PIPELINE_FILE = join(TMP, 'coordinator', 'pipelines.json')

const PIPELINES = {
  feature: {
    description: 'Test pipeline',
    phases: [
      { id: 'schema',   agent: 'db',      depends: [],         required: true,  maxRetries: 1, stopOnFailure: true },
      { id: 'specs',    agent: 'tester',  depends: ['schema'], required: true,  maxRetries: 1, stopOnFailure: true },
      { id: 'backend',  agent: 'nestjs',  depends: ['specs'],  required: true,  maxRetries: 2, stopOnFailure: true,  agentSelector: 'backend', agentAlt: 'drf' },
      { id: 'frontend', agent: 'nextjs',  depends: ['backend'],required: false, maxRetries: 1, stopOnFailure: false, skipIf: ['--api-only'] },
      { id: 'coverage', agent: 'tester',  depends: ['backend'],required: true,  maxRetries: 1, stopOnFailure: false },
      { id: 'review',   agent: 'reviewer',depends: ['coverage'],required: true, maxRetries: 0, stopOnFailure: true },
      { id: 'deploy',   agent: 'devops',  depends: ['review'], required: false, maxRetries: 1, stopOnFailure: false, skipIf: ['--no-deploy'] }
    ]
  },
  circular: {
    description: 'Circular pipeline (invalid)',
    phases: [
      { id: 'a', agent: 'db',     depends: ['b'] },
      { id: 'b', agent: 'tester', depends: ['a'] }
    ]
  },
  // Pipeline de contrôle pour le garde-fou de collision d'id : une phase 'review'
  // dont l'agent déclaré (technical-architect) n'est PAS dans PHASE_CANDIDATES.review
  // → le pipeline doit garder son agent, aucune substitution par le routeur.
  'api-design-like': {
    description: 'Collision id review avec un agent d\'une autre famille',
    phases: [
      { id: 'contract', agent: 'api-designer',        depends: [],            required: true, maxRetries: 0, stopOnFailure: true },
      { id: 'review',   agent: 'technical-architect', depends: ['contract'],  required: true, maxRetries: 0, stopOnFailure: true },
      { id: 'fix',      agent: 'nestjs',              depends: ['review'],    required: true, maxRetries: 0, stopOnFailure: true }
    ]
  }
}

function run(args) {
  try {
    const out = execSync(`node "${RUN_JS}" ${args}`, {
      env: { ...process.env, CLAUDE_CONFIG_DIR: TMP },
      encoding: 'utf8'
    })
    return { code: 0, out }
  } catch (e) {
    return { code: e.status || 1, out: e.stdout + e.stderr }
  }
}

function stateOf(runId) {
  const f = join(TMP, 'runs', runId, 'state.json')
  return JSON.parse(readFileSync(f, 'utf8'))
}

before(() => {
  mkdirSync(join(TMP, 'coordinator'), { recursive: true })
  mkdirSync(join(TMP, 'runs'),        { recursive: true })
  writeFileSync(PIPELINE_FILE, JSON.stringify(PIPELINES, null, 2))
})

after(() => { try { rmSync(TMP, { recursive: true }) } catch {} })

// ─── run.js init ─────────────────────────────────────────────────────────────

describe('run.js init', () => {
  test('crée state.json avec toutes les phases en pending', () => {
    const { code, out } = run('init feature "test-feature"')
    assert.equal(code, 0)
    const runId = out.match(/(feature-test-feature-\d{8}-\d{4})/)?.[1]
    assert.ok(runId, 'runId introuvable dans output')
    const state = stateOf(runId)
    assert.equal(state.status, 'initialized')
    assert.equal(state.pipeline, 'feature')
    assert.equal(Object.keys(state.phases).length, 7)
    assert.equal(state.phases.schema.status, 'pending')
    assert.equal(state.phases.backend.agent, 'nestjs')
  })

  test('--backend drf sélectionne drf pour backend', () => {
    const { code, out } = run('init feature "drf-feature" --backend drf')
    assert.equal(code, 0)
    const runId = out.match(/(feature-drf-feature-\d{8}-\d{4})/)?.[1]
    const state = stateOf(runId)
    assert.equal(state.phases.backend.agent, 'drf')
    assert.equal(state.args.backend, 'drf')
  })

  test('--api-only marque frontend comme skipped', () => {
    const { out } = run('init feature "api-feature" --api-only')
    const runId = out.match(/(feature-api-feature-\d{8}-\d{4})/)?.[1]
    const state = stateOf(runId)
    assert.equal(state.phases.frontend.status, 'skipped')
    assert.ok(state.phases.frontend.skipReason.includes('--api-only'))
  })

  test('détecte les dépendances circulaires', () => {
    const { code, out } = run('init circular "bad-feature"')
    assert.equal(code, 1)
    assert.ok(out.includes('circulaire') || out.includes('circular'))
  })
})

// ─── B1/B2 — sélection d'agent : stack déterministe vs Thompson ───────────────

describe('run.js — sélection d\'agent (B1/B2)', () => {
  const ROUTER_STATE = join(TMP, 'coordinator', 'router-state.json')

  /** Écrit des priors qui favorisent MASSIVEMENT un agent. */
  function seedPriors(priors) {
    writeFileSync(ROUTER_STATE, JSON.stringify({ priors, totalUpdates: 999 }, null, 2))
  }

  beforeEach(() => { try { rmSync(ROUTER_STATE) } catch {} })
  after(()      => { try { rmSync(ROUTER_STATE) } catch {} })

  test('B1 — des priors écrasants pour drf ne peuvent PAS renverser une stack nestjs', () => {
    seedPriors({
      'backend:drf':    { alpha: 500, beta: 1, successes: 499, failures: 0, lastUpdatedAt: new Date().toISOString() },
      'backend:nestjs': { alpha: 1, beta: 500, successes: 0, failures: 499, lastUpdatedAt: new Date().toISOString() },
    })
    // 5 inits successifs : aucun ne doit dériver vers drf
    for (let i = 0; i < 5; i++) {
      const { out } = run(`init feature "stack-nest-${i}"`)
      const runId = out.match(/(feature-stack-nest-\d+-\d{8}-\d{4})/)?.[1]
      const state = stateOf(runId)
      assert.equal(state.phases.backend.agent, 'nestjs',
        `itération ${i} : la stack a été renversée par les priors`)
      assert.equal(state.phases.backend.agentSource, 'stack')
    }
  })

  test('B1 — --backend drf reste absolu malgré des priors écrasants pour nestjs', () => {
    seedPriors({
      'backend:nestjs': { alpha: 500, beta: 1, successes: 499, failures: 0, lastUpdatedAt: new Date().toISOString() },
    })
    const { out } = run('init feature "stack-drf" --backend drf')
    const runId = out.match(/(feature-stack-drf-\d{8}-\d{4})/)?.[1]
    const state = stateOf(runId)
    assert.equal(state.phases.backend.agent, 'drf')
    assert.equal(state.phases.backend.agentSource, 'stack')
  })

  test('B1 — une phase déclarant nestjs SANS agentSelector suit aussi --backend', () => {
    // 'fix' déclare nestjs sans agentSelector (cas réel : bug-fix, perf-audit,
    // saas-bootstrap). Avant, un run --backend drf y recevait quand même nestjs.
    const { out } = run('init api-design-like "stackfix" --backend drf')
    const runId = out.match(/(api-design-like-stackfix-\d{8}-\d{4})/)?.[1]
    const state = stateOf(runId)
    assert.equal(state.phases.fix.agent, 'drf')
  })

  test('B2 — la phase review (choix substituable) passe par le routeur', () => {
    seedPriors({
      'review:security-auditor': { alpha: 200, beta: 1, successes: 199, failures: 0, lastUpdatedAt: new Date().toISOString() },
      'review:reviewer':         { alpha: 1, beta: 200, successes: 0, failures: 199, lastUpdatedAt: new Date().toISOString() },
    })
    const { out } = run('init feature "review-route"')
    const runId = out.match(/(feature-review-route-\d{8}-\d{4})/)?.[1]
    const state = stateOf(runId)
    assert.equal(state.phases.review.agentSource, 'router',
      'review doit être arbitrée par Thompson (2 agents qualifiés)')
    assert.equal(state.phases.review.agent, 'security-auditor',
      'avec des priors écrasants, Thompson doit choisir security-auditor')
  })

  test('B2 — garde-fou collision d\'id : un agent hors candidats n\'est jamais substitué', () => {
    seedPriors({
      'review:security-auditor': { alpha: 200, beta: 1, successes: 199, failures: 0, lastUpdatedAt: new Date().toISOString() },
    })
    const { out } = run('init api-design-like "collide"')
    const runId = out.match(/(api-design-like-collide-\d{8}-\d{4})/)?.[1]
    const state = stateOf(runId)
    assert.equal(state.phases.review.agent, 'technical-architect',
      'PHASE_CANDIDATES est indexé par id nu : le pipeline doit garder son agent déclaré')
    assert.equal(state.phases.review.agentSource, 'static')
  })

  test('B6 — `next` affiche une estimation issue des priors (pas les défauts)', () => {
    seedPriors({
      'schema:db': {
        alpha: 9, beta: 1, successes: 8, failures: 0,
        meanTokens: 4242, meanDurationMs: 600_000,
        lastUpdatedAt: new Date().toISOString(),
      },
    })
    const { out } = run('init feature "estim"')
    const runId = out.match(/(feature-estim-\d{8}-\d{4})/)?.[1]
    const res = run(`next ${runId}`)
    assert.equal(res.code, 0)
    assert.ok(res.out.includes('Estimation'), `tableau d'estimation absent :\n${res.out}`)
    // 600000ms → « ~10min » ; le défaut cassé (30000ms) afficherait « ~30s »
    assert.ok(res.out.includes('~10min'), `durée issue du prior absente :\n${res.out}`)
    assert.ok(!res.out.includes('~30s'), `retombe sur DEFAULT_DURATION :\n${res.out}`)
  })
})

// ─── run.js start ────────────────────────────────────────────────────────────

describe('run.js start', () => {
  let runId

  beforeEach(() => {
    const { out } = run('init feature "start-test"')
    runId = out.match(/(feature-start-test-\d{8}-\d{4})/)?.[1]
  })

  test('démarre la première phase (schema)', () => {
    const { code } = run(`start ${runId} schema`)
    assert.equal(code, 0)
    const state = stateOf(runId)
    assert.equal(state.phases.schema.status, 'running')
    assert.ok(state.phases.schema.startedAt)
  })

  test('bloque si dépendances non satisfaites', () => {
    const { code, out } = run(`start ${runId} specs`)
    assert.equal(code, 1)
    assert.ok(out.includes('schema') || out.includes('dépendance') || out.includes('Dépendance'))
  })

  test('dépendances skipped comptent comme satisfaites', () => {
    run(`start ${runId} schema`)
    run(`done ${runId} schema "ok"`)
    // Marquer specs comme skipped
    run(`skip ${runId} specs "test"`)
    // Backend peut démarrer car schema=completed, specs=skipped
    const { code } = run(`start ${runId} backend`)
    assert.equal(code, 0)
  })

  test('phase already running : retourne proprement sans corrompre l\'état (lock releasé)', () => {
    // Première start : phase passe à running
    const { code: code1 } = run(`start ${runId} schema`)
    assert.equal(code1, 0)
    const stateBefore = stateOf(runId)
    assert.equal(stateBefore.phases.schema.status, 'running')
    const startedAtBefore = stateBefore.phases.schema.startedAt

    // Deuxième start sur la même phase : doit retourner 0 (warn + return, pas exit 1)
    // et ne pas modifier le startedAt ni corrompre le lock
    const { code: code2, out: out2 } = run(`start ${runId} schema`)
    assert.equal(code2, 0, `Deuxième start sur phase running doit sortir avec code 0, reçu: ${out2}`)

    const stateAfter = stateOf(runId)
    assert.equal(stateAfter.phases.schema.status, 'running', 'La phase doit rester running')
    assert.equal(stateAfter.phases.schema.startedAt, startedAtBefore, 'startedAt ne doit pas être modifié')

    // Le lock doit avoir été releasé — une opération done() doit maintenant fonctionner
    const { code: codeDone } = run(`done ${runId} schema "ok"`)
    assert.equal(codeDone, 0, 'done() doit réussir après un double-start (lock correctement releasé)')
    const stateFinal = stateOf(runId)
    assert.equal(stateFinal.phases.schema.status, 'completed')
  })
})

// ─── run.js done ─────────────────────────────────────────────────────────────

describe('run.js done', () => {
  let runId

  beforeEach(() => {
    const { out } = run('init feature "done-test"')
    runId = out.match(/(feature-done-test-\d{8}-\d{4})/)?.[1]
    run(`start ${runId} schema`)
  })

  test('marque phase completed avec summary', () => {
    run(`done ${runId} schema "migration créée"`)
    const state = stateOf(runId)
    assert.equal(state.phases.schema.status, 'completed')
    assert.ok(state.phases.schema.completedAt)
    assert.equal(state.phases.schema.summary, 'migration créée')
  })

  test('complete le run quand toutes les phases sont done', () => {
    const phases = ['schema', 'specs', 'backend', 'coverage', 'review']
    for (const p of phases) {
      run(`start ${runId} ${p}`)
      run(`done ${runId} ${p} "ok"`)
    }
    run(`skip ${runId} frontend "api-only"`)
    run(`skip ${runId} deploy "no-deploy"`)
    const state = stateOf(runId)
    assert.ok(['completed', 'completed_with_errors'].includes(state.status))
  })
})

// ─── run.js fail ─────────────────────────────────────────────────────────────

describe('run.js fail', () => {
  let runId

  beforeEach(() => {
    const { out } = run('init feature "fail-test"')
    runId = out.match(/(feature-fail-test-\d{8}-\d{4})/)?.[1]
    run(`start ${runId} schema`)
  })

  test('fail sans retry marque failed et stoppe le pipeline', () => {
    run(`fail ${runId} schema "DB unreachable"`)
    const state = stateOf(runId)
    assert.equal(state.phases.schema.status, 'failed')
    assert.equal(state.phases.schema.error, 'DB unreachable')
    assert.equal(state.status, 'failed')
    assert.equal(state.blockedAt, 'schema')
  })

  test('fail --retry incrémente retries si quota dispo', () => {
    run(`fail ${runId} schema "timeout" --retry`)
    const state = stateOf(runId)
    assert.equal(state.phases.schema.status, 'retrying')
    assert.equal(state.phases.schema.retries, 1)
  })

  test('fail --retry après quota max → failed définitif', () => {
    run(`fail ${runId} schema "err" --retry`)   // retry 1/1
    run(`start ${runId} schema`)
    run(`fail ${runId} schema "err" --retry`)   // quota épuisé
    const state = stateOf(runId)
    assert.equal(state.phases.schema.status, 'failed')
  })
})

// ─── run.js next (parallélisme) ──────────────────────────────────────────────

describe('run.js next — parallélisme', () => {
  let runId

  beforeEach(() => {
    const { out } = run('init feature "next-test"')
    runId = out.match(/(feature-next-test-\d{8}-\d{4})/)?.[1]
  })

  test('retourne schema seul au démarrage (aucune dép satisfaite)', () => {
    const { out } = run(`next ${runId} --json`)
    const parsed = JSON.parse(out)
    assert.equal(parsed.ready.length, 1)
    assert.equal(parsed.ready[0].phaseId, 'schema')
  })

  test('retourne frontend ET coverage en parallèle après backend', () => {
    const seq = ['schema', 'specs', 'backend']
    for (const p of seq) {
      run(`start ${runId} ${p}`)
      run(`done ${runId} ${p} "ok"`)
    }
    const { out } = run(`next ${runId} --json`)
    const parsed = JSON.parse(out)
    const ids = parsed.ready.map(p => p.phaseId).sort()
    assert.deepEqual(ids, ['coverage', 'frontend'])
  })

  test('retourne vide si run terminé', () => {
    const phases = ['schema', 'specs', 'backend', 'frontend', 'coverage', 'review', 'deploy']
    for (const p of phases) {
      run(`start ${runId} ${p}`)
      run(`done ${runId} ${p} "ok"`)
    }
    const { out } = run(`next ${runId}`)
    assert.ok(!out.includes('"id"') || out.includes('terminé') || out.includes('complet'))
  })
})

// ─── run.js skip ─────────────────────────────────────────────────────────────

describe('run.js skip', () => {
  test('marque phase skipped avec raison', () => {
    const { out } = run('init feature "skip-test"')
    const runId = out.match(/(feature-skip-test-\d{8}-\d{4})/)?.[1]
    run(`skip ${runId} frontend "api-only mode"`)
    const state = stateOf(runId)
    assert.equal(state.phases.frontend.status, 'skipped')
    assert.equal(state.phases.frontend.skipReason, 'api-only mode')
  })
})
