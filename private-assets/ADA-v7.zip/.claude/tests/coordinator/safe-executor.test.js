'use strict'
/**
 * tests/coordinator/safe-executor.test.js
 */
const { test, describe } = require('node:test')
const assert = require('node:assert/strict')
const { join } = require('path')

const {
  validateCommand,
  sanitizeArg,
  isValidVerdict,
  isValidPhase,
  isValidAgent,
} = require(join(__dirname, '../../coordinator/safe-executor.js'))

describe('validateCommand', () => {
  test('node est une commande autorisée', () => {
    const result = validateCommand('node', ['script.js'])
    assert.equal(result.safe, true)
  })

  test('bash est bloqué', () => {
    const result = validateCommand('bash', ['-c', 'echo hi'])
    assert.equal(result.safe, false)
    assert.ok(result.reason?.includes('bash'))
  })

  test('rm est bloqué', () => {
    const result = validateCommand('rm', ['-rf', '/'])
    assert.equal(result.safe, false)
  })

  test('détecte le shell injection dans les args (;)', () => {
    const result = validateCommand('node', ['file.js', '; rm -rf /'])
    assert.equal(result.safe, false)
    assert.ok(result.reason?.includes('dangereux'))
  })

  test('détecte le shell injection avec |', () => {
    const result = validateCommand('node', ['file.js', '| cat /etc/passwd'])
    assert.equal(result.safe, false)
  })

  test('détecte le null byte', () => {
    const result = validateCommand('node', ['file\0.js'])
    assert.equal(result.safe, false)
    assert.ok(result.reason?.includes('Null byte'))
  })

  test('commande vide retourne safe=false', () => {
    const result = validateCommand('', [])
    assert.equal(result.safe, false)
    assert.ok(result.reason)
  })

  test('commande non-string retourne safe=false', () => {
    // @ts-ignore intentional type error for test
    const result = validateCommand(null, [])
    assert.equal(result.safe, false)
  })

  test('git est autorisé', () => {
    const result = validateCommand('git', ['status'])
    assert.equal(result.safe, true)
  })

  test('python3 est autorisé', () => {
    const result = validateCommand('python3', ['script.py'])
    assert.equal(result.safe, true)
  })

  test('chemin complet vers node est autorisé', () => {
    const result = validateCommand('/usr/local/bin/node', ['script.js'])
    assert.equal(result.safe, true)
  })
})

describe('sanitizeArg', () => {
  test('retire les ; et |', () => {
    const result = sanitizeArg('arg; rm -rf /')
    assert.ok(!result.includes(';'))
  })

  test('retire le caractère |', () => {
    const result = sanitizeArg('arg | cat')
    assert.ok(!result.includes('|'))
  })

  test('préserve les arguments sains', () => {
    const result = sanitizeArg('my-safe-arg_123.json')
    assert.equal(result, 'my-safe-arg_123.json')
  })

  test('tronque à 1000 chars', () => {
    const long = 'a'.repeat(2000)
    const result = sanitizeArg(long)
    assert.equal(result.length, 1000)
  })

  test('retire le null byte', () => {
    const result = sanitizeArg('arg\0bad')
    assert.ok(!result.includes('\0'))
  })

  test('retourne chaine vide pour non-string', () => {
    // @ts-ignore intentional
    assert.equal(sanitizeArg(42), '')
    // @ts-ignore intentional
    assert.equal(sanitizeArg(null), '')
  })
})

describe('isValidVerdict', () => {
  test('success est valide', () => {
    assert.equal(isValidVerdict('success'), true)
  })

  test('failure est valide', () => {
    assert.equal(isValidVerdict('failure'), true)
  })

  test('partial est valide', () => {
    assert.equal(isValidVerdict('partial'), true)
  })

  test('invalid est rejeté', () => {
    assert.equal(isValidVerdict('invalid'), false)
    assert.equal(isValidVerdict(''), false)
    assert.equal(isValidVerdict('ok'), false)
  })
})

describe('isValidPhase', () => {
  test('backend est valide', () => {
    assert.equal(isValidPhase('backend'), true)
  })

  test('task:ai est valide', () => {
    assert.equal(isValidPhase('task:ai'), true)
  })

  test('migration-apply est valide', () => {
    assert.equal(isValidPhase('migration-apply'), true)
  })

  test('injection avec ; est rejeté', () => {
    assert.equal(isValidPhase('phase; rm -rf /'), false)
  })

  test('phase vide est rejetée', () => {
    assert.equal(isValidPhase(''), false)
  })

  test('phase trop longue est rejetée', () => {
    assert.equal(isValidPhase('a'.repeat(65)), false)
  })

  test('majuscules sont rejetées', () => {
    assert.equal(isValidPhase('Backend'), false)
  })
})

// ─── F7 — formes équivalentes d'un flag d'exécution inline ────────────────────
// Un même flag dangereux s'écrit de plusieurs façons. Le filtre doit bloquer
// TOUTES les formes, pas seulement la forme isolée :
//   isolée    : -e code
//   avec =    : --eval=code
//   collée    : -ecode        (acceptée par python/perl ; refusée par node)
//   groupée   : -pe code      (acceptée par node ; -Bc par python)
//   décalée   : -r fs -e code (un flag AVEC SA VALEUR intercalé)
// Les formes refusées par l'interpréteur sont bloquées quand même (défense en
// profondeur : le comportement varie selon l'interpréteur et sa version).

describe('validateCommand — flags inline, formes équivalentes (F7)', () => {
  const blockedNode = [
    ['forme isolée -e',            ['-e', 'console.log(1)']],
    ['forme isolée --eval',        ['--eval', 'console.log(1)']],
    ['forme isolée -p',            ['-p', '1+1']],
    ['forme isolée --print',       ['--print', '1+1']],
    ['forme = sur -e',             ['-e=console.log(1)']],
    ['forme = sur --eval',         ['--eval=console.log(1)']],
    ['forme collée -eX',           ['-econsole.log(1)']],
    ['forme collée -pX',           ['-p1+1']],
    ['forme groupée -pe',          ['-pe', 'console.log(1)']],
    ['forme groupée -i -pe',       ['-i', '-pe', 'console.log(1)']],
    ['flag+valeur intercalés',     ['-r', 'fs', '-econsole.log(1)']],
    ['flag+valeur intercalés (=)', ['--input-type=module', '-e', 'console.log(1)']],
  ]
  for (const [label, args] of blockedNode) {
    test(`node — bloque la ${label}`, () => {
      const r = validateCommand('node', args)
      assert.equal(r.safe, false, `node ${args.join(' ')} doit être refusé`)
      assert.match(String(r.reason), /inline/i)
    })
  }

  const blockedPython = [
    ['forme isolée -c',    ['-c', 'print(1)']],
    ['forme collée -cX',   ['-cprint(1)']],
    ['forme groupée -Bc',  ['-Bc', 'print(1)']],
    ['forme groupée -uc',  ['-uc', 'print(1)']],
    ['forme = sur -c',     ['-c=print(1)']],
  ]
  for (const [label, args] of blockedPython) {
    test(`python3 — bloque la ${label}`, () => {
      const r = validateCommand('python3', args)
      assert.equal(r.safe, false, `python3 ${args.join(' ')} doit être refusé`)
    })
  }

  const blockedGit = [
    ['forme isolée -c',   ['-c', 'core.pager=cat', 'log']],
    ['forme collée -cX',  ['-ccore.pager=cat', 'log']],
    ['forme = longue',    ['--upload-pack=payload', 'fetch']],
  ]
  for (const [label, args] of blockedGit) {
    test(`git — bloque la ${label}`, () => {
      const r = validateCommand('git', args)
      assert.equal(r.safe, false, `git ${args.join(' ')} doit être refusé`)
    })
  }

  // ── Non-régression : les usages légitimes des workers restent autorisés ────
  const allowed = [
    ['node',    ['script.js']],
    ['node',    ['--version']],
    ['node',    ['--check', 'file.js']],
    ['node',    ['--experimental-vm-modules', '.claude/tests/run-all.js']],
    ['node',    ['-r', './setup.js', 'app.js']],
    ['node',    ['.claude/coordinator/run.js', 'init', 'feature']],
    ['python3', ['script.py']],
    ['python3', ['-m', 'pytest']],
    ['python3', ['-mpytest']],
    ['python3', ['-B', 'script.py']],
    ['git',     ['status']],
    ['git',     ['-C', '/tmp/repo', 'status']],
    ['git',     ['commit', '-m', 'fix: quelque chose']],
    ['git',     ['commit', '-am', 'fix: quelque chose']],
    ['git',     ['log', '--oneline', '-n', '5']],
    ['npm',     ['run', 'test']],
  ]
  for (const [cmd, args] of allowed) {
    test(`pas de faux positif — ${cmd} ${args.join(' ')}`, () => {
      const r = validateCommand(cmd, args)
      assert.equal(r.safe, true, `${cmd} ${args.join(' ')} doit rester autorisé (${r.reason || ''})`)
    })
  }
})

describe('isValidAgent', () => {
  test('nestjs est valide', () => {
    assert.equal(isValidAgent('nestjs'), true)
  })

  test('react-native est valide', () => {
    assert.equal(isValidAgent('react-native'), true)
  })

  test('agent avec ; est rejeté', () => {
    assert.equal(isValidAgent('agent; inject'), false)
  })

  test('agent vide est rejeté', () => {
    assert.equal(isValidAgent(''), false)
  })

  test('agent trop long est rejeté', () => {
    assert.equal(isValidAgent('a'.repeat(33)), false)
  })
})

// ─── F7-followup — le scan s'arrête au chemin du script ───────────────────────
// F7 scannait TOUS les arguments. Or dans `node [options] script.js [args]`,
// dès le premier jeton non-flag (le chemin du script) les jetons suivants
// appartiennent au SCRIPT, pas à node. Les scanner refusait des commandes
// légitimes — dont `bank store` avec un résumé d'agent commençant par un tiret,
// silencieusement perdu côté run.js.

describe('validateCommand — scan borné au chemin du script (F7-followup)', () => {
  const allowed = [
    ['résumé d\'agent ressemblant à un flag',
      'node', ['bank.js', 'store', 'p1', 'nestjs', 'ok', '-e2e coverage ajoute']],
    ['argument -p du SCRIPT, pas de node',
      'node', ['--enable-source-maps', 'app.js', '-p', '3000']],
    ['argument -e du SCRIPT, pas de node',
      'node', ['--watch', 'app.js', '-e']],
    ['flag dangereux APRÈS le chemin du script',
      'node', ['script.js', '-e']],
    ['python : -c appartient au script',
      'python3', ['script.py', '-c', 'valeur']],
  ]
  for (const [label, cmd, args] of allowed) {
    test(`${cmd} — ${label}`, () => {
      const r = validateCommand(cmd, args)
      assert.equal(r.safe, true, `${cmd} ${args.join(' ')} doit rester autorisé (${r.reason || ''})`)
    })
  }

  // Le trou F7 ne doit pas se rouvrir : AVANT le chemin du script, toutes les
  // formes restent bloquées, y compris derrière un flag suivi de sa valeur.
  const stillBlocked = [
    ['node',    ['-r', 'fs', '-e', 'console.log(1)']],
    ['node',    ['--require', 'fs', '-pe', 'console.log(1)']],
    ['node',    ['-pe', 'console.log(1)', 'ignored.js']],
    ['python3', ['-m', 'json.tool', '-c', 'print(1)']],
  ]
  for (const [cmd, args] of stillBlocked) {
    test(`${cmd} ${args.join(' ')} — reste bloqué`, () => {
      const r = validateCommand(cmd, args)
      assert.equal(r.safe, false, `${cmd} ${args.join(' ')} doit rester refusé`)
    })
  }
})

// ─── Quoting : pourquoi safe-executor n'est PAS concerné ─────────────────────
// Le finding « contournement par quoting » (BACKLOG-SECURITE-2026-09-10) vise
// les gardes qui analysent une CHAÎNE de commande. Ici la validation porte sur
// un argv déjà séparé, transmis tel quel à spawnSync SANS `shell: true`
// (run.js : routerUpdate/bankStore) : aucun shell ne retire les guillemets.
// Un argument `"-e"` reste littéralement `"-e"` pour execve — node le prend
// pour un chemin de script, pas pour un flag. Ce test verrouille ce postulat :
// si un appelant passait un jour par un shell, il casserait ici.

describe('validateCommand — un flag quoté n\'est pas un flag (argv, pas de shell)', () => {
  const { spawnSync } = require('child_process')

  for (const quoted of ['"-e"', "'-e'"]) {
    test(`${quoted} n'exécute pas de code inline via spawnSync sans shell`, () => {
      const r = spawnSync('node', [quoted, 'console.log(42)'], { encoding: 'utf8', timeout: 10000 })
      assert.notEqual(r.status, 0, `node ne doit pas accepter ${quoted} comme flag`)
      assert.ok(!String(r.stdout).includes('42'), 'aucun code inline ne doit s\'exécuter')
    })
  }

  test('la forme déquotée, elle, est bien refusée par la validation', () => {
    assert.equal(validateCommand('node', ['-e', 'console.log(42)']).safe, false)
  })
})
