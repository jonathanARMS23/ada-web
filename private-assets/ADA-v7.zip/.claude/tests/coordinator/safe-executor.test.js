'use strict'
/**
 * tests/coordinator/safe-executor.test.js
 */
const { test, describe } = require('node:test')
const assert = require('node:assert/strict')
const { join } = require('path')

const {
  validateCommand,
  sanitizeArg,
  isValidVerdict,
  isValidPhase,
  isValidAgent,
} = require(join(__dirname, '../../coordinator/safe-executor.js'))

describe('validateCommand', () => {
  test('node est une commande autorisée', () => {
    const result = validateCommand('node', ['script.js'])
    assert.equal(result.safe, true)
  })

  test('bash est bloqué', () => {
    const result = validateCommand('bash', ['-c', 'echo hi'])
    assert.equal(result.safe, false)
    assert.ok(result.reason?.includes('bash'))
  })

  test('rm est bloqué', () => {
    const result = validateCommand('rm', ['-rf', '/'])
    assert.equal(result.safe, false)
  })

  test('détecte le shell injection dans les args (;)', () => {
    const result = validateCommand('node', ['file.js', '; rm -rf /'])
    assert.equal(result.safe, false)
    assert.ok(result.reason?.includes('dangereux'))
  })

  test('détecte le shell injection avec |', () => {
    const result = validateCommand('node', ['file.js', '| cat /etc/passwd'])
    assert.equal(result.safe, false)
  })

  test('détecte le null byte', () => {
    const result = validateCommand('node', ['file\0.js'])
    assert.equal(result.safe, false)
    assert.ok(result.reason?.includes('Null byte'))
  })

  test('commande vide retourne safe=false', () => {
    const result = validateCommand('', [])
    assert.equal(result.safe, false)
    assert.ok(result.reason)
  })

  test('commande non-string retourne safe=false', () => {
    // @ts-ignore intentional type error for test
    const result = validateCommand(null, [])
    assert.equal(result.safe, false)
  })

  test('git est autorisé', () => {
    const result = validateCommand('git', ['status'])
    assert.equal(result.safe, true)
  })

  test('python3 est autorisé', () => {
    const result = validateCommand('python3', ['script.py'])
    assert.equal(result.safe, true)
  })

  test('chemin complet vers node est autorisé', () => {
    const result = validateCommand('/usr/local/bin/node', ['script.js'])
    assert.equal(result.safe, true)
  })
})

describe('sanitizeArg', () => {
  test('retire les ; et |', () => {
    const result = sanitizeArg('arg; rm -rf /')
    assert.ok(!result.includes(';'))
  })

  test('retire le caractère |', () => {
    const result = sanitizeArg('arg | cat')
    assert.ok(!result.includes('|'))
  })

  test('préserve les arguments sains', () => {
    const result = sanitizeArg('my-safe-arg_123.json')
    assert.equal(result, 'my-safe-arg_123.json')
  })

  test('tronque à 1000 chars', () => {
    const long = 'a'.repeat(2000)
    const result = sanitizeArg(long)
    assert.equal(result.length, 1000)
  })

  test('retire le null byte', () => {
    const result = sanitizeArg('arg\0bad')
    assert.ok(!result.includes('\0'))
  })

  test('retourne chaine vide pour non-string', () => {
    // @ts-ignore intentional
    assert.equal(sanitizeArg(42), '')
    // @ts-ignore intentional
    assert.equal(sanitizeArg(null), '')
  })
})

describe('isValidVerdict', () => {
  test('success est valide', () => {
    assert.equal(isValidVerdict('success'), true)
  })

  test('failure est valide', () => {
    assert.equal(isValidVerdict('failure'), true)
  })

  test('partial est valide', () => {
    assert.equal(isValidVerdict('partial'), true)
  })

  test('invalid est rejeté', () => {
    assert.equal(isValidVerdict('invalid'), false)
    assert.equal(isValidVerdict(''), false)
    assert.equal(isValidVerdict('ok'), false)
  })
})

describe('isValidPhase', () => {
  test('backend est valide', () => {
    assert.equal(isValidPhase('backend'), true)
  })

  test('task:ai est valide', () => {
    assert.equal(isValidPhase('task:ai'), true)
  })

  test('migration-apply est valide', () => {
    assert.equal(isValidPhase('migration-apply'), true)
  })

  test('injection avec ; est rejeté', () => {
    assert.equal(isValidPhase('phase; rm -rf /'), false)
  })

  test('phase vide est rejetée', () => {
    assert.equal(isValidPhase(''), false)
  })

  test('phase trop longue est rejetée', () => {
    assert.equal(isValidPhase('a'.repeat(65)), false)
  })

  test('majuscules sont rejetées', () => {
    assert.equal(isValidPhase('Backend'), false)
  })
})

describe('isValidAgent', () => {
  test('nestjs est valide', () => {
    assert.equal(isValidAgent('nestjs'), true)
  })

  test('react-native est valide', () => {
    assert.equal(isValidAgent('react-native'), true)
  })

  test('agent avec ; est rejeté', () => {
    assert.equal(isValidAgent('agent; inject'), false)
  })

  test('agent vide est rejeté', () => {
    assert.equal(isValidAgent(''), false)
  })

  test('agent trop long est rejeté', () => {
    assert.equal(isValidAgent('a'.repeat(33)), false)
  })
})
