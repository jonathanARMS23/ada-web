#!/usr/bin/env node
'use strict'
const { test, describe } = require('node:test')
const assert = require('node:assert/strict')
const { readFileSync } = require('fs')
const { join } = require('path')

const { validatePipelines, validateRunState, validate, assertValid } = require('../../coordinator/schema-validator')

const PIPELINE_FILE = join(__dirname, '../../coordinator/pipelines.json')

// ── validatePipelines — données valides ───────────────────────────────────────

describe('validatePipelines — format tableau', () => {
  test('pipeline valide (tableau) → 0 erreur', () => {
    const data = [
      {
        id: 'feature',
        phases: [
          { id: 'schema', label: 'Schéma DB', agent: 'db', depends: [], required: true, maxRetries: 1, stopOnFailure: true }
        ]
      }
    ]
    const errors = validatePipelines(data)
    assert.equal(errors.length, 0)
  })

  test('pipeline avec champs optionnels → 0 erreur', () => {
    const data = [
      {
        id: 'hotfix',
        label: 'Hotfix pipeline',
        rollbackOnFailure: true,
        phases: [
          { id: 'fix', label: 'Fix', agent: 'nestjs', tier: 3, required: true, maxRetries: 2, depends: [], stopOnFailure: true, skipIf: ['--skip'], rollbackPhase: 'fix' }
        ]
      }
    ]
    const errors = validatePipelines(data)
    assert.equal(errors.length, 0)
  })

  test('phases manquantes dans pipeline → erreur', () => {
    const data = [{ id: 'broken' }]
    const errors = validatePipelines(data)
    assert.ok(errors.length > 0, 'devrait signaler phases manquantes')
    assert.ok(errors.some(e => e.includes('phases')))
  })

  test('phase sans id → erreur', () => {
    const data = [
      {
        id: 'p',
        phases: [{ label: 'No ID', agent: 'db' }]
      }
    ]
    const errors = validatePipelines(data)
    assert.ok(errors.some(e => e.includes('id') && e.includes('required')))
  })

  test('phase sans agent → erreur', () => {
    const data = [
      {
        id: 'p',
        phases: [{ id: 'step1', label: 'Step' }]
      }
    ]
    const errors = validatePipelines(data)
    assert.ok(errors.some(e => e.includes('agent') && e.includes('required')))
  })

  test('mauvais type sur tier (string au lieu de number) → erreur', () => {
    const data = [
      {
        id: 'p',
        phases: [{ id: 'step1', label: 'Step', agent: 'db', tier: 'high' }]
      }
    ]
    const errors = validatePipelines(data)
    assert.ok(errors.some(e => e.includes('tier') && e.includes('number')))
  })

  test('depends non-array → erreur', () => {
    const data = [
      {
        id: 'p',
        phases: [{ id: 'step1', label: 'Step', agent: 'db', depends: 'schema' }]
      }
    ]
    const errors = validatePipelines(data)
    assert.ok(errors.some(e => e.includes('depends') && e.includes('array')))
  })

  test('données non-objet à la racine → erreur', () => {
    const errors = validatePipelines('not an object')
    assert.ok(errors.length > 0)
  })
})

// ── validatePipelines — format dictionnaire (format actuel pipelines.json) ────

describe('validatePipelines — format dictionnaire', () => {
  test('objet dictionnaire valide → 0 erreur', () => {
    const data = {
      feature: {
        phases: [
          { id: 'schema', label: 'Schema', agent: 'db' }
        ]
      }
    }
    const errors = validatePipelines(data)
    assert.equal(errors.length, 0)
  })

  test('clés _comment ignorées', () => {
    const data = {
      _comment: 'ce champ est ignoré',
      feature: {
        phases: [{ id: 'schema', label: 'Schema', agent: 'db' }]
      }
    }
    const errors = validatePipelines(data)
    assert.equal(errors.length, 0)
  })

  test('pipeline sans phases → erreur', () => {
    const data = { broken: { description: 'no phases here' } }
    const errors = validatePipelines(data)
    assert.ok(errors.some(e => e.includes('phases')))
  })
})

// ── validateRunState ──────────────────────────────────────────────────────────

describe('validateRunState', () => {
  test('state valide → 0 erreur', () => {
    const state = {
      pipeline: 'feature',
      status: 'running',
      startedAt: new Date().toISOString(),
      phases: {}
    }
    const errors = validateRunState(state)
    assert.equal(errors.length, 0)
  })

  test('state sans status → erreur', () => {
    const state = { pipeline: 'feature' }
    const errors = validateRunState(state)
    assert.ok(errors.some(e => e.includes('status') && e.includes('required')))
  })

  test('state sans pipeline → erreur', () => {
    const state = { status: 'running' }
    const errors = validateRunState(state)
    assert.ok(errors.some(e => e.includes('pipeline') && e.includes('required')))
  })

  test('phases non-objet (array) → erreur', () => {
    const state = { pipeline: 'feature', status: 'running', phases: ['wrong'] }
    const errors = validateRunState(state)
    assert.ok(errors.some(e => e.includes('phases') && e.includes('object')))
  })
})

// ── assertValid ───────────────────────────────────────────────────────────────

describe('assertValid', () => {
  test('liste vide → ne lance pas d\'erreur', () => {
    assert.doesNotThrow(() => assertValid([], 'test'))
  })

  test('liste non vide → lance Error avec contexte', () => {
    assert.throws(
      () => assertValid(['root.id: required field missing'], 'pipelines.json'),
      (err) => {
        assert.ok(err instanceof Error)
        assert.ok(err.message.includes('pipelines.json'))
        assert.ok(err.message.includes('root.id: required field missing'))
        return true
      }
    )
  })
})

// ── pipelines.json réel ───────────────────────────────────────────────────────

describe('pipelines.json réel', () => {
  test('le fichier pipelines.json de production → 0 erreur de validation', () => {
    const raw = readFileSync(PIPELINE_FILE, 'utf8')
    const data = JSON.parse(raw)
    const errors = validatePipelines(data)
    assert.equal(errors.length, 0, `Erreurs trouvées : ${errors.join(', ')}`)
  })
})
