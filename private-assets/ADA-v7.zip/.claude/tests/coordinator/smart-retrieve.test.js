#!/usr/bin/env node
'use strict'
/**
 * tests/coordinator/smart-retrieve.test.js
 * SmartRetrieval : expandQuery · reciprocalRankFusion · maximalMarginalRelevance · smartRetrieve
 */

const { test, describe, beforeEach } = require('node:test')
const assert = require('node:assert/strict')
const { join } = require('path')
const { tmpdir } = require('os')
const { mkdirSync, rmSync, existsSync } = require('fs')

const EMBEDDINGS_JS = join(__dirname, '../../coordinator/embeddings.js')
const {
  expandQuery,
  reciprocalRankFusion,
  maximalMarginalRelevance,
  jaccardSim,
} = require(EMBEDDINGS_JS)

const BANK_JS = join(__dirname, '../../coordinator/bank.js')

// ── jaccardSim ────────────────────────────────────────────────────────────────

describe('jaccardSim', () => {
  test('tokens identiques → 1.0', () => {
    const t = ['nestjs', 'error', 'handler']
    assert.equal(jaccardSim(t, t), 1)
  })

  test('tokens disjoints → 0.0', () => {
    assert.equal(jaccardSim(['nestjs', 'error'], ['stripe', 'payment']), 0)
  })

  test('tableaux vides → 0', () => {
    assert.equal(jaccardSim([], []), 0)
  })

  test('intersection partielle → valeur entre 0 et 1', () => {
    const sim = jaccardSim(['jwt', 'auth', 'guard'], ['jwt', 'stripe'])
    assert.ok(sim > 0 && sim < 1, `attendu ]0,1[, obtenu ${sim}`)
  })
})

// ── expandQuery ───────────────────────────────────────────────────────────────

describe('expandQuery', () => {
  test('contient toujours la requête originale', () => {
    const variants = expandQuery('nestjs error')
    assert.ok(variants.includes('nestjs error'), `variantes: ${variants}`)
  })

  test('retourne un tableau non vide', () => {
    const variants = expandQuery('authentication jwt token')
    assert.ok(variants.length >= 1)
  })

  test('ne dépasse pas maxVariants', () => {
    const variants = expandQuery('deploy docker ci cd pipeline release', { maxVariants: 3 })
    assert.ok(variants.length <= 3, `obtenu ${variants.length} variantes`)
  })

  test('ajoute une variante phase-préfixée quand phase fournie', () => {
    const variants = expandQuery('error handling', { phase: 'backend', maxVariants: 4 })
    assert.ok(
      variants.some(v => v.startsWith('backend')),
      `variantes: ${variants}`
    )
  })

  test('ne duplique pas la phase si déjà présente dans la requête', () => {
    const variants = expandQuery('backend error', { phase: 'backend', maxVariants: 4 })
    // La variante "backend backend error" ne doit pas apparaître
    assert.ok(!variants.includes('backend backend error'))
  })

  test('sans synonymes correspondants → max 3 variantes', () => {
    // Requête sans aucun terme du dictionnaire synonymes, longue pour activer variante inversée
    const variants = expandQuery('postgresql migration schema table', { maxVariants: 3 })
    assert.ok(variants.length <= 3)
  })

  test('remplace le premier synonyme trouvé', () => {
    // "error" → "exception"
    const variants = expandQuery('nestjs error', { maxVariants: 4 })
    assert.ok(
      variants.some(v => v.includes('exception')),
      `synonyme 'exception' attendu dans: ${variants}`
    )
  })

  test('résultats dédupliqués', () => {
    const variants = expandQuery('api', { maxVariants: 10 })
    const unique = new Set(variants)
    assert.equal(variants.length, unique.size, 'pas de doublon attendu')
  })
})

// ── reciprocalRankFusion ──────────────────────────────────────────────────────

describe('reciprocalRankFusion', () => {
  test('liste vide → retourne []', () => {
    assert.deepEqual(reciprocalRankFusion([]), [])
  })

  test('une seule liste → tous les items présents', () => {
    const list = [{ id: 'a', score: 1 }, { id: 'b', score: 0.5 }]
    const result = reciprocalRankFusion([list])
    const ids = result.map(r => r.id)
    assert.ok(ids.includes('a'))
    assert.ok(ids.includes('b'))
  })

  test('item présent dans deux listes → score RRF plus élevé', () => {
    // 'b' est 1er dans la 2e liste et 2e dans la 1ère → score cumulé supérieur à 'c'
    const list1 = [{ id: 'a', score: 1 }, { id: 'b', score: 0.5 }]
    const list2 = [{ id: 'b', score: 1 }, { id: 'a', score: 0.3 }]
    const result = reciprocalRankFusion([list1, list2])
    // 'a' rank0 dans list1, rank1 dans list2 → 1/61 + 1/62
    // 'b' rank1 dans list1, rank0 dans list2 → 1/62 + 1/61
    // scores identiques ici, mais les deux doivent être présents
    assert.ok(result.length === 2)
    assert.ok(result.every(r => typeof r.rrfScore === 'number' && r.rrfScore > 0))
  })

  test('item uniquement dans une liste a un score inférieur à un item dans deux listes', () => {
    const list1 = [{ id: 'shared', score: 1 }, { id: 'only1', score: 0.8 }]
    const list2 = [{ id: 'shared', score: 1 }, { id: 'only2', score: 0.8 }]
    const result = reciprocalRankFusion([list1, list2])
    const sharedEntry = result.find(r => r.id === 'shared')
    const only1Entry  = result.find(r => r.id === 'only1')
    assert.ok(sharedEntry)
    assert.ok(only1Entry)
    assert.ok(
      sharedEntry.rrfScore > only1Entry.rrfScore,
      `shared(${sharedEntry.rrfScore}) doit > only1(${only1Entry.rrfScore})`
    )
  })

  test('k=60 donne des scores dans ]0, 1/61]', () => {
    const list = [{ id: 'x', score: 1 }]
    const result = reciprocalRankFusion([list], 60)
    // rank=0 → 1/(60+0+1) = 1/61 ≈ 0.01639
    assert.ok(Math.abs(result[0].rrfScore - 1 / 61) < 1e-10)
  })

  test('résultats triés par rrfScore décroissant', () => {
    const list1 = [{ id: 'a', score: 1 }, { id: 'b', score: 0.5 }, { id: 'c', score: 0.1 }]
    const list2 = [{ id: 'a', score: 1 }, { id: 'c', score: 0.8 }]
    const result = reciprocalRankFusion([list1, list2])
    for (let i = 1; i < result.length; i++) {
      assert.ok(
        result[i].rrfScore <= result[i - 1].rrfScore,
        `résultats non triés à l'index ${i}`
      )
    }
  })
})

// ── maximalMarginalRelevance ──────────────────────────────────────────────────

describe('maximalMarginalRelevance', () => {
  function makeCandidates(n) {
    return Array.from({ length: n }, (_, i) => ({
      id:     `cand-${i}`,
      score:  1 - i * 0.05,
      tokens: [`token${i}`, `shared`, `common`],
    }))
  }

  test('10 candidats avec topK=5 → retourne exactement 5', () => {
    const result = maximalMarginalRelevance(makeCandidates(10), ['shared'], { topK: 5 })
    assert.equal(result.length, 5)
  })

  test('candidats < topK → retourne tous (avec mmrScore=0)', () => {
    const result = maximalMarginalRelevance(makeCandidates(3), ['shared'], { topK: 5 })
    assert.equal(result.length, 3)
  })

  test('chaque résultat a un champ mmrScore', () => {
    const result = maximalMarginalRelevance(makeCandidates(8), ['shared'], { topK: 3 })
    for (const r of result) {
      assert.ok('mmrScore' in r, `mmrScore absent dans: ${JSON.stringify(r)}`)
    }
  })

  test('lambda=1.0 → trie par pertinence pure (jaccard vs queryTokens)', () => {
    // Avec lambda=1, MMR = relevance pure → on prend ceux qui matchent le mieux la query
    const candidates = [
      { id: 'a', score: 0.9, tokens: ['nestjs', 'error', 'query'] },
      { id: 'b', score: 0.8, tokens: ['stripe', 'payment', 'webhook'] },
      { id: 'c', score: 0.7, tokens: ['query', 'error'] },
    ]
    const result = maximalMarginalRelevance(candidates, ['query', 'error'], { lambda: 1.0, topK: 2 })
    // 'a' et 'c' ont 'query' et 'error' → doivent scorer plus que 'b'
    const ids = result.map(r => r.id)
    assert.ok(ids.includes('a') || ids.includes('c'), `attendu a ou c en top-2, obtenu: ${ids}`)
    assert.ok(!ids.includes('b') || result.length === 3, `'b' ne devrait pas dominer`)
  })

  test('lambda=0.0 → maximise diversité (pénalise les similaires)', () => {
    // Avec lambda=0, MMR = -maxSim → on évite les items proches de ceux déjà sélectionnés
    const candidates = [
      { id: 'a', score: 1,   tokens: ['nestjs', 'error', 'handler'] },
      { id: 'b', score: 0.9, tokens: ['nestjs', 'error', 'handler'] }, // clone de a
      { id: 'c', score: 0.8, tokens: ['stripe', 'payment', 'webhook'] }, // différent
    ]
    const result = maximalMarginalRelevance(candidates, ['query'], { lambda: 0.0, topK: 2 })
    const ids = result.map(r => r.id)
    // 'b' est très similaire à 'a' → avec diversité max, 'c' devrait être préféré après 'a'
    assert.ok(ids.length === 2)
  })
})

// ── smartRetrieve ─────────────────────────────────────────────────────────────

describe('smartRetrieve', () => {
  let tmpDir

  beforeEach(() => {
    tmpDir = join(tmpdir(), `smart-retrieve-test-${Date.now()}-${Math.random().toString(36).slice(2)}`)
    mkdirSync(tmpDir, { recursive: true })
    process.env.CLAUDE_CONFIG_DIR = tmpDir
    // Reset le singleton DB pour chaque test
    const bank = require(BANK_JS)
    bank._resetDB()
  })

  test('bank vide → retourne []', () => {
    const bank = require(BANK_JS)
    const result = bank.smartRetrieve('nestjs error handling')
    assert.deepEqual(result, [])
  })

  test('retourne au max `limit` résultats', () => {
    const bank = require(BANK_JS)
    // Stocker plusieurs trajectoires
    for (let i = 0; i < 10; i++) {
      bank.store('backend', 'nestjs', 'success', `nestjs error handling authentication jwt token ${i}`)
    }
    const result = bank.smartRetrieve('nestjs error', { limit: 3 })
    assert.ok(result.length <= 3, `attendu ≤3, obtenu ${result.length}`)
  })

  test('résultats contiennent les champs trajectoire standards', () => {
    const bank = require(BANK_JS)
    bank.store('backend', 'nestjs', 'success', 'nestjs error handler exception guard')
    const result = bank.smartRetrieve('nestjs error')
    if (result.length > 0) {
      const r = result[0]
      assert.ok('id' in r)
      assert.ok('phase' in r)
      assert.ok('agent' in r)
      assert.ok('verdict' in r)
      assert.ok('summary' in r)
    }
  })
})
