#!/usr/bin/env node
'use strict'
/**
 * task-classifier.test.js — Axe B : classifieur solo vs pipeline + tier.
 * Fonction pure, déterministe. Fixtures réalistes + cas de benchmarks/tasks.json.
 */
const { test, describe } = require('node:test')
const assert = require('node:assert/strict')
const { readFileSync, existsSync } = require('fs')
const { join } = require('path')

const { classifyTask, selectPipeline } = require('../../coordinator/task-classifier.js')
const { classifyDescFromArgs } = require('../../bin/ada.js')

// ─── SOLO — tâches ciblées (1 agent) ────────────────────────────────────────────
describe('mode solo', () => {
  test('bugfix N+1 → solo, tier 3 (raisonnement complexe)', () => {
    const r = classifyTask('corrige le bug N+1 dans ce service')
    assert.equal(r.mode, 'solo')
    assert.equal(r.pipeline, null)
    assert.equal(r.tier, 3)
    assert.ok(r.signals.includes('edition-ciblee'))
  })

  test('renomme variable → solo, tier 1 (trivial)', () => {
    const r = classifyTask('renomme la variable x en y')
    assert.equal(r.mode, 'solo')
    assert.equal(r.tier, 1)
    assert.ok(r.signals.includes('edition-ciblee'))
  })

  test('question explicative → solo', () => {
    const r = classifyTask('explique pourquoi ce test échoue')
    assert.equal(r.mode, 'solo')
    assert.equal(r.pipeline, null)
    assert.ok(r.signals.includes('edition-ciblee'))
  })

  test('ajout champ DTO → solo, tier 2', () => {
    const r = classifyTask('ajoute un champ email au DTO User')
    assert.equal(r.mode, 'solo')
    assert.equal(r.tier, 2)
    assert.ok(r.signals.includes('ajout-champ-simple'))
  })

  test('édition concurrence → solo mais tier 3', () => {
    const r = classifyTask('corrige la race condition atomique sur le décrément de stock')
    assert.equal(r.mode, 'solo')
    assert.equal(r.tier, 3)
  })

  test('correction typo doc → solo, tier 1', () => {
    const r = classifyTask('corrige une typo dans la documentation')
    assert.equal(r.mode, 'solo')
    assert.equal(r.tier, 1)
  })
})

// ─── PIPELINE — multi-livrables / multi-couches ─────────────────────────────────
describe('mode pipeline', () => {
  test('feature multi-livrables → pipeline feature', () => {
    const r = classifyTask('feature facturation multi-tenant : migration + service + DTO + tests')
    assert.equal(r.mode, 'pipeline')
    assert.equal(r.pipeline, 'feature')
    assert.ok(r.signals.some(s => s.startsWith('livrables-multiples')))
  })

  test('SaaS complet NestJS + Next.js → pipeline', () => {
    const r = classifyTask('construis un SaaS complet NestJS + Next.js')
    assert.equal(r.mode, 'pipeline')
    assert.ok(r.signals.includes('multi-couches') || r.signals.includes('stack-double'))
    assert.ok(['saas-bootstrap', 'feature'].includes(r.pipeline))
  })
})

// ── anti-régression C8 (ADR-021 point 2) : "saas" en contexte ≠ demande de construire ──
// "pour mon SaaS multi-tenant" est la formulation la plus courante de ce corpus pour une
// tâche mono-domaine (schéma SQL, endpoint isolé…) — découvert en classifiant les tâches
// réelles de tasks-v2.json (at-orders-fulfillment-schema routait à tort vers pipeline
// saas-bootstrap sur ce seul mot).
describe('anti-régression C8 — "saas" contextuel ne déclenche plus le mode pipeline', () => {
  test('schéma SQL "pour un SaaS multi-tenant" sans verbe de construction → solo', () => {
    const r = classifyTask(
      "Pour mon SaaS multi-tenant, conçois le schéma PostgreSQL COMPLET du fulfillment de " +
      "commandes en 3 tables liées : orders, order_items (lignes d'une commande, FK vers " +
      "orders), shipments (expéditions d'une commande, FK vers orders). EXIGENCES sur CHAQUE " +
      "table : id uuid PK, workspace_id uuid NOT NULL, created_at/updated_at timestamptz " +
      "DEFAULT now(), Row Level Security ACTIVÉ."
    )
    assert.equal(r.mode, 'solo')
    assert.ok(!r.signals.includes('multi-couches'))
  })
  test('"saas" + verbe de construction → multi-couches (signal légitime conservé)', () => {
    const r = classifyTask('lance un nouveau SaaS de gestion de stock')
    assert.ok(r.signals.includes('multi-couches'))
  })
  test('"bootstrap" seul (sans "saas") reste un signal fort', () => {
    const r = classifyTask('bootstrap ce projet de zéro')
    assert.ok(r.signals.includes('multi-couches'))
  })
  test('selectPipeline : "saas" contextuel seul ne route plus vers saas-bootstrap', () => {
    const { selectPipeline } = require('../../coordinator/task-classifier.js')
    assert.equal(selectPipeline('endpoint simple pour lister les factures de mon SaaS'), 'feature')
  })
  test('selectPipeline : "saas" + verbe de construction route toujours vers saas-bootstrap', () => {
    const { selectPipeline } = require('../../coordinator/task-classifier.js')
    assert.equal(selectPipeline('lance un nouveau SaaS de gestion de stock'), 'saas-bootstrap')
  })

  test('de bout en bout backend + frontend → pipeline', () => {
    const r = classifyTask('feature de bout en bout avec backend et frontend')
    assert.equal(r.mode, 'pipeline')
    assert.equal(r.pipeline, 'feature')
    assert.ok(r.signals.includes('multi-couches'))
  })

  test('review/audit → pipeline review', () => {
    const r = classifyTask('fais une review complète et un audit du diff courant sur plusieurs fichiers')
    assert.equal(r.mode, 'pipeline')
    assert.equal(r.tier, 3)
  })

  test('migration seule → pipeline db-migrate', () => {
    const r = classifyTask('génère une migration SQL pour la table invoices puis applique avec rollback')
    assert.equal(r.mode, 'pipeline')
    assert.ok(['db-migrate', 'migration'].includes(r.pipeline))
    assert.equal(r.tier, 3)
  })

  test('migration sans downtime → pipeline migration, tier 3', () => {
    const r = classifyTask('renomme une colonne sans downtime avec migration et backfill par batch et tests')
    assert.equal(r.mode, 'pipeline')
    assert.equal(r.tier, 3)
  })
})

// ─── TIER — assertions ciblées ──────────────────────────────────────────────────
describe('tier', () => {
  test('architecture → tier 3', () => {
    assert.equal(classifyTask('conçois l\'architecture du module de paiement').tier, 3)
  })
  test('sécurité → tier 3', () => {
    assert.equal(classifyTask('audit de sécurité OWASP sur l\'API').tier, 3)
  })
  test('lint/format → tier 1', () => {
    assert.equal(classifyTask('passe le lint et formatte le fichier').tier, 1)
  })
  test('tâche standard → tier 2', () => {
    assert.equal(classifyTask('ajoute un endpoint GET pour lister les produits').tier, 2)
  })
})

// ─── Robustesse / déterminisme ──────────────────────────────────────────────────
describe('robustesse — contrat & déterminisme', () => {
  test('description vide → solo, tier 2, sans crash', () => {
    const r = classifyTask('')
    assert.equal(r.mode, 'solo')
    assert.equal(r.pipeline, null)
    assert.ok([1, 2, 3].includes(r.tier))
  })

  test('déterministe : même entrée → même sortie', () => {
    const a = classifyTask('feature complète avec migration et service et tests')
    const b = classifyTask('feature complète avec migration et service et tests')
    assert.deepEqual(a, b)
  })

  test('accents/casse indifférents', () => {
    const a = classifyTask('CORRIGE le BUG')
    assert.equal(a.mode, 'solo')
  })

  test('contrat de sortie respecté', () => {
    const r = classifyTask('ajoute un champ name')
    assert.ok(['solo', 'pipeline'].includes(r.mode))
    assert.ok(r.pipeline === null || typeof r.pipeline === 'string')
    assert.ok([1, 2, 3].includes(r.tier))
    assert.ok(Array.isArray(r.signals))
    assert.equal(typeof r.reason, 'string')
  })
})

// ─── Fixtures issues de benchmarks/tasks.json ───────────────────────────────────
describe('cas réels (benchmarks/tasks.json)', () => {
  const tasksFile = join(__dirname, '../../benchmarks/tasks.json')

  test('feature-booking-mixed (profile feature) → pipeline', () => {
    if (!existsSync(tasksFile)) return
    const tasks = JSON.parse(readFileSync(tasksFile, 'utf8')).tasks
    const t = tasks.find(x => x.id === 'feature-booking-mixed')
    assert.ok(t, 'tâche feature-booking-mixed présente')
    const r = classifyTask(t.prompt)
    assert.equal(r.mode, 'pipeline', `attendu pipeline pour: ${t.title}`)
  })

  test('bugfix-nplus1 (correction ciblée) → solo', () => {
    if (!existsSync(tasksFile)) return
    const tasks = JSON.parse(readFileSync(tasksFile, 'utf8')).tasks
    const t = tasks.find(x => x.id === 'bugfix-nplus1')
    assert.ok(t)
    const r = classifyTask(t.prompt)
    // Correction d'un seul problème → solo, tier 3 (N+1 = perf/raisonnement).
    assert.equal(r.mode, 'solo')
    assert.equal(r.tier, 3)
  })

  test('zero-downtime-migration (raisonnement complexe) → tier 3', () => {
    if (!existsSync(tasksFile)) return
    const tasks = JSON.parse(readFileSync(tasksFile, 'utf8')).tasks
    const t = tasks.find(x => x.id === 'zero-downtime-migration')
    assert.ok(t)
    const r = classifyTask(t.prompt)
    assert.equal(r.tier, 3)
  })
})

// ─── CODEMOD — Tier 0 déterministe ($0) ─────────────────────────────────────────
describe('mode codemod (tier 0)', () => {
  test('retirer les console.log → codemod remove-console, tier 0', () => {
    const r = classifyTask('retire les console.log de ce fichier')
    assert.equal(r.mode, 'codemod')
    assert.equal(r.codemod, 'remove-console')
    assert.equal(r.tier, 0)
    assert.equal(r.pipeline, null)
  })
  test('supprime les console.log → remove-console', () => {
    assert.equal(classifyTask('supprime les console.log').codemod, 'remove-console')
  })
  test('remplace les var par const → var-to-const', () => {
    const r = classifyTask('remplace les var par const')
    assert.equal(r.mode, 'codemod')
    assert.equal(r.codemod, 'var-to-const')
    assert.equal(r.tier, 0)
  })
  test('convertis les var en const → var-to-const', () => {
    assert.equal(classifyTask('convertis les var en const').codemod, 'var-to-const')
  })
  test('nettoie les espaces en fin de ligne → strip-trailing-whitespace', () => {
    const r = classifyTask('nettoie les espaces en fin de ligne')
    assert.equal(r.mode, 'codemod')
    assert.equal(r.codemod, 'strip-trailing-whitespace')
    assert.equal(r.tier, 0)
  })
  test('supprime les trailing whitespace → strip-trailing-whitespace', () => {
    assert.equal(classifyTask('supprime les trailing whitespace').codemod, 'strip-trailing-whitespace')
  })

  // Garde-fous : ne PAS hijacker les tâches à jugement / non mécaniques.
  test('refactor mêlant console.log ET ajout de types → PAS codemod', () => {
    const r = classifyTask('refactorise le service pour retirer les console.log et ajouter des types partout')
    assert.notEqual(r.mode, 'codemod')
    assert.equal(r.codemod, null)
  })
  test('tâches existantes → codemod null (non régression)', () => {
    assert.equal(classifyTask('renomme la variable x en y').codemod, null)
    assert.equal(classifyTask('corrige le bug N+1 dans ce service').codemod, null)
    assert.equal(classifyTask('passe le lint et formatte le fichier').codemod, null)
  })
  test('contrat : champ codemod toujours présent', () => {
    const r = classifyTask('ajoute un endpoint GET')
    assert.ok(r.codemod === null || typeof r.codemod === 'string')
  })
})

// ─── Robustesse / cas limites ───────────────────────────────────────────────────
describe('robustesse — signaux contradictoires & entrées limites', () => {
  test('signaux contradictoires (solo + livrables multiples) → pipeline gagne', () => {
    const r = classifyTask('corrige le service et le endpoint et la migration et les tests')
    assert.equal(r.mode, 'pipeline')
  })

  test('null/undefined → solo sans crash', () => {
    assert.equal(classifyTask(null).mode, 'solo')
    assert.equal(classifyTask(undefined).mode, 'solo')
  })

  test('entrée 100k chars → linéaire (< 50ms), pas de ReDoS', () => {
    const big = 'nestjs ' + 'x '.repeat(50000)
    const t0 = Date.now()
    const r = classifyTask(big)
    assert.ok(Date.now() - t0 < 50, 'classification > 50ms (ReDoS suspecté)')
    assert.ok(r.mode === 'solo' || r.mode === 'pipeline')
  })
})

// ─── ANTI-RÉGRESSION — sur-déclenchement (audit C1-C5, C7) ──────────────────────
// Chaque test ci-dessous ÉCHOUAIT avant le fix : le classifieur partait en
// pipeline (ou en tier 3) sur des tâches ciblées, triviales ou de simple lecture.
describe('anti-régression C1 — la ponctuation seule n\'est pas un connecteur', () => {
  test('"documentation : mettre a jour les specs de l api" → solo (pas pipeline feature)', () => {
    const r = classifyTask('documentation : mettre a jour les specs de l api')
    assert.equal(r.mode, 'solo')
    assert.equal(r.pipeline, null)
    assert.ok(!r.signals.some(s => s.startsWith('livrables-multiples')),
      `":" ne doit pas composer des livrables : ${r.signals.join(',')}`)
  })

  test('"ajoute un endpoint et un test" (2 livrables, tâche courte) → solo', () => {
    const r = classifyTask('ajoute un endpoint et un test')
    assert.equal(r.mode, 'solo')
    assert.equal(r.pipeline, null)
  })

  test('une virgule séparant deux mots ne déclenche pas de pipeline', () => {
    assert.equal(classifyTask('mets a jour le service, rien d\'autre').mode, 'solo')
  })

  test('non-régression : 3+ livrables reliés par un vrai connecteur → pipeline', () => {
    const r = classifyTask('crée la migration, le service et les tests pour la facturation')
    assert.equal(r.mode, 'pipeline')
    assert.ok(r.signals.some(s => s.startsWith('livrables-multiples')))
  })

  test('non-régression : "migration + service + DTO + tests" → pipeline feature', () => {
    const r = classifyTask('feature facturation multi-tenant : migration + service + DTO + tests')
    assert.equal(r.mode, 'pipeline')
    assert.equal(r.pipeline, 'feature')
  })
})

describe('anti-régression C2 — un signal solo fort pèse dans la décision', () => {
  test('"explique la difference entre le service et le controller" → solo', () => {
    const r = classifyTask('explique la difference entre le service et le controller')
    assert.equal(r.mode, 'solo')
    assert.equal(r.pipeline, null)
    assert.ok(r.signals.includes('question-pure'), `signaux: ${r.signals.join(',')}`)
  })

  test('question longue sur une archi multi-livrables → reste solo (on explique, on ne construit pas)', () => {
    const r = classifyTask(
      'explique pourquoi la migration, le service et les tests sont organisés ainsi dans ce module')
    assert.equal(r.mode, 'solo')
  })

  test('non-régression : signal solo faible vs livrables multiples → pipeline gagne', () => {
    const r = classifyTask('corrige le service et le endpoint et la migration et les tests')
    assert.equal(r.mode, 'pipeline')
  })
})

describe('anti-régression C3 — la longueur seule ne décompose pas', () => {
  const longMonotache =
    'voici beaucoup de contexte sur notre application de facturation multi tenant qui gere ' +
    'des clients et des factures avec plein de details historiques sur la maniere dont le ' +
    'module a evolue depuis deux ans et les choix passes qui ont ete faits par l equipe ; ' +
    'corrige le typo dans ce fichier'

  test('prompt >40 mots mais monotâche → solo, tier 1', () => {
    const r = classifyTask(longMonotache)
    assert.ok(r.mode === 'solo', `attendu solo, obtenu ${r.mode} (${r.signals.join(',')})`)
    assert.ok(!r.signals.includes('scope-long'), 'scope-long ne doit pas se déclencher sur la seule longueur')
    assert.equal(r.tier, 1)
  })

  test('non-régression : prompt long croisant plusieurs problèmes durs → pipeline', () => {
    const r = classifyTask(
      'implemente le traitement des webhooks avec garantie exactly-once : deduplication ' +
      'persistee par event id, idempotence sous concurrence de deux livraisons simultanees ' +
      'du meme event, et gestion des retries pour que l effet metier ne soit jamais applique ' +
      'deux fois dans le systeme distribue')
    assert.equal(r.mode, 'pipeline')
    assert.ok(r.signals.includes('scope-long'))
  })
})

describe('anti-régression C4 — mots-clés tier3/pipeline exigent un contexte réel', () => {
  test('"formatte le code du module de securite" → tier 1 (pas Opus pour un formatage)', () => {
    const r = classifyTask('formatte le code du module de securite')
    assert.equal(r.tier, 1)
    assert.equal(r.mode, 'solo')
  })

  test('"renomme le fichier lock.ts en mutex.ts" → tier 1 (nom de fichier ≠ verrouillage)', () => {
    const r = classifyTask('renomme le fichier lock.ts en mutex.ts')
    assert.equal(r.tier, 1)
    assert.equal(r.mode, 'solo')
  })

  test('"mets un commentaire au-dessus de la fonction de review" → solo, tier 1', () => {
    const r = classifyTask('mets un commentaire au-dessus de la fonction de review')
    assert.equal(r.mode, 'solo')
    assert.equal(r.pipeline, null)
    assert.equal(r.tier, 1)
    assert.ok(!r.signals.includes('workflow-review'))
  })

  test('un nom de fichier ne dicte jamais le tier (perf.ts, security.js)', () => {
    assert.equal(classifyTask('deplace perf.ts dans le dossier utils').tier, 2)
    assert.equal(classifyTask('renomme security.js en guards.js').tier, 1)
  })

  test('non-régression : vraie review de sécurité → tier 3 + pipeline security-audit', () => {
    const r = classifyTask('fais une review de sécurité du module d\'auth')
    assert.equal(r.mode, 'pipeline')
    assert.equal(r.tier, 3)
    assert.equal(r.pipeline, 'security-audit')
  })

  test('non-régression : vraie review de code → tier 3 + pipeline review', () => {
    const r = classifyTask('fais une review complète du diff courant')
    assert.equal(r.mode, 'pipeline')
    assert.equal(r.pipeline, 'review')
    assert.equal(r.tier, 3)
  })

  test('non-régression : vrai verrouillage / vraie perf → tier 3', () => {
    assert.equal(classifyTask('ajoute un lock pessimiste sur la ligne pendant la transaction').tier, 3)
    assert.equal(classifyTask('optimise la perf de cette requête lente').tier, 3)
    assert.equal(classifyTask('audit de sécurité OWASP sur l\'API').tier, 3)
  })
})

describe('anti-régression C5 — `production` nu ne capture plus tout', () => {
  test('"deploie en production avec migration et tests" → pas hotfix', () => {
    const p = selectPipeline('deploie en production avec migration et tests')
    assert.notEqual(p, 'hotfix')
    assert.equal(p, 'db-migrate')
  })

  test('production masquait mobile → mobile préservé', () => {
    assert.equal(selectPipeline('livre l\'app mobile react native en production'), 'mobile')
  })

  test('non-régression : production + incident → hotfix', () => {
    assert.equal(selectPipeline('bug critique en production, corrige en urgence'), 'hotfix')
    assert.equal(selectPipeline('hotfix production'), 'hotfix')
  })

  test('via classifyTask : migration appliquée en production → pipeline migration/db-migrate, jamais hotfix', () => {
    const r = classifyTask(
      'applique la migration en production avec backfill par batch et les tests de non regression')
    assert.equal(r.mode, 'pipeline')
    assert.ok(['db-migrate', 'migration'].includes(r.pipeline), `pipeline obtenu: ${r.pipeline}`)
  })
})

describe('anti-régression C7 — les flags CLI ne sont pas classifiés', () => {
  test('--json exclu de la description', () => {
    assert.equal(classifyDescFromArgs(['corrige', 'le', 'bug', '--json']), 'corrige le bug')
  })

  test('classification identique avec et sans --json', () => {
    const args = ['ajoute', 'un', 'champ', 'email', 'au', 'DTO', 'User']
    assert.deepEqual(
      classifyTask(classifyDescFromArgs([...args, '--json'])),
      classifyTask(classifyDescFromArgs(args)))
  })

  test('description vide si seuls des flags sont passés', () => {
    assert.equal(classifyDescFromArgs(['--json']), '')
  })
})
