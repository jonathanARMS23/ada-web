#!/usr/bin/env node
'use strict'
/**
 * tests/coordinator/team-reap.test.js
 *
 * Fix 3 — Reaper TTL pour teammates tmux (`ada team reap`).
 *
 * Constat : les teammates Claude Code (agent teams) tournent dans des serveurs
 * tmux nommés `claude-swarm-<pid>` et ne sont jamais tués — sessions vivantes
 * des heures après livraison.
 *
 * Vérifie :
 *   - discoverSwarmSocketLabels : filtre les sockets claude-swarm-* uniquement
 *   - parseTmuxSessions : parse la sortie `tmux list-sessions -F '#{session_name} #{session_activity}'`
 *   - planReap : décision PURE (idle >= ttl → shouldKill), zéro I/O
 *   - cmdTeamReap : orchestration avec exécuteur tmux injecté (mock, zéro tmux réel)
 *     - tue les sessions idle > ttl
 *     - --dry-run ne tue rien mais rapporte ce qui serait tué
 *     - ignore proprement les sockets morts (exec qui échoue)
 */
const { test, describe } = require('node:test')
const assert = require('node:assert/strict')

const { discoverSwarmSocketLabels, parseTmuxSessions, planReap, cmdTeamReap } = require('../../bin/ada.js')

// ─── discoverSwarmSocketLabels ────────────────────────────────────────────────

describe('discoverSwarmSocketLabels — filtre les sockets claude-swarm-*', () => {
  test('ne garde que les entrées préfixées claude-swarm-', () => {
    const entries = ['claude-swarm-1234', 'default', 'claude-swarm-5678', '.lock', 'other-tool-999']
    const r = discoverSwarmSocketLabels(entries)
    assert.deepEqual(r.sort(), ['claude-swarm-1234', 'claude-swarm-5678'])
  })

  test('tableau vide ou non-tableau → []', () => {
    assert.deepEqual(discoverSwarmSocketLabels([]), [])
    assert.deepEqual(discoverSwarmSocketLabels(null), [])
    assert.deepEqual(discoverSwarmSocketLabels(undefined), [])
  })
})

// ─── parseTmuxSessions ────────────────────────────────────────────────────────

describe('parseTmuxSessions — parse la sortie tmux list-sessions -F', () => {
  test('parse plusieurs lignes name+activity', () => {
    const out = 'main 1700000000\nworker-1 1700000500\n'
    const r = parseTmuxSessions(out)
    assert.deepEqual(r, [
      { name: 'main', activityEpoch: 1700000000 },
      { name: 'worker-1', activityEpoch: 1700000500 },
    ])
  })

  test('ignore les lignes vides / malformées', () => {
    const out = 'main 1700000000\n\nbad-line-no-number\nworker 42\n'
    const r = parseTmuxSessions(out)
    assert.deepEqual(r, [
      { name: 'main', activityEpoch: 1700000000 },
      { name: 'worker', activityEpoch: 42 },
    ])
  })

  test('sortie vide/undefined → []', () => {
    assert.deepEqual(parseTmuxSessions(''), [])
    assert.deepEqual(parseTmuxSessions(undefined), [])
  })
})

// ─── planReap (décision pure) ─────────────────────────────────────────────────

describe('planReap — décision pure idle >= ttl', () => {
  test('session idle depuis exactement le ttl → shouldKill=true (borne inclusive)', () => {
    const now = 1700003600 // +3600s = 60min après activityEpoch
    const sessions = [{ name: 'x', activityEpoch: 1700000000 }]
    const r = planReap(sessions, 60, now)
    assert.equal(r[0].idleMinutes, 60)
    assert.equal(r[0].shouldKill, true)
  })

  test('session active récemment → shouldKill=false', () => {
    const now = 1700000060 // +60s = 1min
    const sessions = [{ name: 'x', activityEpoch: 1700000000 }]
    const r = planReap(sessions, 60, now)
    assert.equal(r[0].shouldKill, false)
  })

  test('sessions vides → []', () => {
    assert.deepEqual(planReap([], 60, 1700000000), [])
    assert.deepEqual(planReap(null, 60, 1700000000), [])
  })

  test('plusieurs sessions, TTL mixte', () => {
    const now = 1700000000
    const sessions = [
      { name: 'fresh', activityEpoch: 1699999900 },   // idle ~1.6min
      { name: 'stale', activityEpoch: 1699993600 },   // idle 106min
    ]
    const r = planReap(sessions, 60, now)
    const byName = Object.fromEntries(r.map(s => [s.name, s.shouldKill]))
    assert.equal(byName.fresh, false)
    assert.equal(byName.stale, true)
  })
})

// ─── cmdTeamReap — orchestration avec tmux mocké ──────────────────────────────

describe('cmdTeamReap — orchestration (tmux injecté, zéro process réel)', () => {
  test('tue les sessions idle > ttl, garde les fraîches', () => {
    const nowEpoch = 1700010000
    const calls = []
    const result = cmdTeamReap(['--ttl', '60'], {
      listSocketDir: () => ['claude-swarm-111', 'default', 'claude-swarm-222'],
      now: () => nowEpoch,
      execTmux: (label, tmuxArgs) => {
        calls.push({ label, tmuxArgs })
        if (tmuxArgs[0] === 'list-sessions') {
          if (label === 'claude-swarm-111') {
            // une session stale (idle 200min), une fraîche (idle 1min)
            return { status: 0, stdout: `stale-session ${nowEpoch - 200 * 60}\nfresh-session ${nowEpoch - 60}\n` }
          }
          return { status: 0, stdout: `only-session ${nowEpoch - 5 * 60}\n` } // idle 5min, gardée
        }
        if (tmuxArgs[0] === 'kill-session') return { status: 0, stdout: '' }
        return { status: 1, stdout: '' }
      },
    })

    assert.equal(result.sockets, 2)
    assert.equal(result.inspected, 3)
    assert.equal(result.killed, 1)

    const killCalls = calls.filter(c => c.tmuxArgs[0] === 'kill-session')
    assert.equal(killCalls.length, 1)
    assert.deepEqual(killCalls[0].tmuxArgs, ['kill-session', '-t', 'stale-session'])
    assert.equal(killCalls[0].label, 'claude-swarm-111')
  })

  test('--dry-run ne tue rien mais rapporte ce qui serait tué', () => {
    const nowEpoch = 1700010000
    const calls = []
    const result = cmdTeamReap(['--ttl', '60', '--dry-run'], {
      listSocketDir: () => ['claude-swarm-111'],
      now: () => nowEpoch,
      execTmux: (label, tmuxArgs) => {
        calls.push(tmuxArgs[0])
        if (tmuxArgs[0] === 'list-sessions') {
          return { status: 0, stdout: `stale-session ${nowEpoch - 200 * 60}\n` }
        }
        return { status: 0, stdout: '' }
      },
    })
    assert.equal(result.killed, 1) // "à tuer" comptabilisé même en dry-run
    assert.ok(result.details[0].wouldKill)
    assert.ok(!calls.includes('kill-session'), 'kill-session ne doit jamais être appelé en dry-run')
  })

  test('ignore proprement les sockets morts (status non-zéro)', () => {
    const result = cmdTeamReap(['--ttl', '60'], {
      listSocketDir: () => ['claude-swarm-dead', 'claude-swarm-alive'],
      now: () => 1700010000,
      execTmux: (label) => {
        if (label === 'claude-swarm-dead') return { status: 1, stdout: '' } // socket mort
        return { status: 0, stdout: `s ${1700010000 - 30}\n` } // idle 30s, gardée
      },
    })
    assert.equal(result.sockets, 2)
    assert.equal(result.inspected, 1) // seul le socket vivant est compté
    assert.equal(result.killed, 0)
  })

  test('ignore proprement les sockets qui lèvent une exception', () => {
    const result = cmdTeamReap(['--ttl', '60'], {
      listSocketDir: () => ['claude-swarm-throws'],
      now: () => 1700010000,
      execTmux: () => { throw new Error('ENOENT: no such socket') },
    })
    assert.equal(result.inspected, 0)
    assert.equal(result.killed, 0)
  })

  test('--ttl par défaut = 60 quand non spécifié', () => {
    const nowEpoch = 1700010000
    const result = cmdTeamReap([], {
      listSocketDir: () => ['claude-swarm-x'],
      now: () => nowEpoch,
      execTmux: (label, tmuxArgs) => {
        if (tmuxArgs[0] === 'list-sessions') {
          return { status: 0, stdout: `s1 ${nowEpoch - 59 * 60}\ns2 ${nowEpoch - 61 * 60}\n` }
        }
        return { status: 0, stdout: '' }
      },
    })
    assert.equal(result.inspected, 2)
    assert.equal(result.killed, 1) // seule s2 (61min) dépasse le TTL par défaut (60min)
  })
})
