#!/usr/bin/env node
'use strict'
/**
 * token-window.test.js — sumUsageWindow : agrégation fenêtrée multi-transcripts.
 *
 * Vérifie la mesure de coût d'un bras de benchmark quand il délègue à un sous-agent
 * (tokens répartis sur plusieurs *.jsonl). On crée des transcripts JSONL temporaires
 * dans un tmpdir (jamais le vrai dossier projet) et on contrôle la fenêtre temporelle.
 */
const { test, describe, before, after } = require('node:test')
const assert = require('node:assert/strict')
const { mkdtempSync, writeFileSync, rmSync } = require('node:fs')
const { join } = require('node:path')
const os = require('node:os')

const { sumUsageWindow } = require('../../coordinator/token-telemetry.js')

// Construit une ligne JSONL d'un tour assistant avec timestamp + usage.
function line(timestamp, usage) {
  return JSON.stringify({ type: 'assistant', timestamp, message: { usage } })
}
const U = (input, out, cr = 0, cc = 0) => ({
  input_tokens: input, output_tokens: out,
  cache_read_input_tokens: cr, cache_creation_input_tokens: cc,
})

let dir
before(() => {
  dir = mkdtempSync(join(os.tmpdir(), 'ada-tokwin-'))

  // Transcript principal : 3 tours, dont 1 hors fenêtre (avant) et 1 hors fenêtre (après).
  writeFileSync(join(dir, 'main.jsonl'), [
    line('2026-06-16T10:00:00.000Z', U(100, 10)),   // AVANT la fenêtre
    line('2026-06-16T12:00:00.000Z', U(200, 20)),   // DANS la fenêtre
    line('2026-06-16T12:30:00.000Z', U(50, 5, 40)), // DANS la fenêtre (avec cache_read)
    line('2026-06-16T18:00:00.000Z', U(999, 99)),   // APRÈS la fenêtre
  ].join('\n') + '\n')

  // Transcript sous-agent : tokens de la délégation, dans un AUTRE fichier.
  writeFileSync(join(dir, 'agent-sidechain.jsonl'), [
    line('2026-06-16T12:10:00.000Z', U(300, 30)),   // DANS la fenêtre
    line('2026-06-16T12:20:00.000Z', U(100, 10)),   // DANS la fenêtre
  ].join('\n') + '\n')

  // Lignes à ignorer : sans timestamp, sans usage, et JSON invalide.
  writeFileSync(join(dir, 'noise.jsonl'), [
    JSON.stringify({ type: 'assistant', message: { usage: U(7777, 7777) } }), // pas de timestamp
    JSON.stringify({ type: 'user', timestamp: '2026-06-16T12:15:00.000Z', message: { content: 'hi' } }), // pas de usage
    '{ ceci nest pas du JSON',                                                 // JSON invalide
    '',                                                                        // ligne vide
  ].join('\n') + '\n')

  // Fichier non-.jsonl : doit être ignoré.
  writeFileSync(join(dir, 'ignore.txt'), line('2026-06-16T12:05:00.000Z', U(5000, 5000)) + '\n')
})
after(() => { try { rmSync(dir, { recursive: true, force: true }) } catch {} })

const FROM = '2026-06-16T11:00:00.000Z'
const TO   = '2026-06-16T13:00:00.000Z'

describe('sumUsageWindow', () => {
  test('cumule sur plusieurs fichiers, seules les lignes DANS la fenêtre', () => {
    const u = sumUsageWindow(dir, FROM, TO)
    assert.ok(u, 'usage non nul attendu')
    // main(2) + agent(2) = 4 tours dans la fenêtre. Les lignes avant/après, sans
    // timestamp, sans usage, JSON invalide et le .txt sont tous exclus.
    assert.equal(u.turns, 4)
    // input plein = 200 + 50 + 300 + 100 = 650 ; cache_read = 40
    assert.equal(u.input, 650)
    assert.equal(u.cacheRead, 40)
    // output = 20 + 5 + 30 + 10 = 65
    assert.equal(u.output, 65)
    assert.equal(u.totalInput, 650 + 40)
  })

  test('exclut les lignes hors fenêtre (avant/après)', () => {
    // Fenêtre qui n'attrape QUE le 1er tour main (10:00) → exclut tout le reste.
    const u = sumUsageWindow(dir, '2026-06-16T09:00:00.000Z', '2026-06-16T11:00:00.000Z')
    assert.ok(u)
    assert.equal(u.turns, 1)
    assert.equal(u.input, 100)
    assert.equal(u.output, 10)
  })

  test('bornes inclusives', () => {
    // from/to alignés EXACTEMENT sur deux timestamps → les deux comptent.
    const u = sumUsageWindow(dir, '2026-06-16T12:00:00.000Z', '2026-06-16T12:10:00.000Z')
    assert.ok(u)
    // 12:00 (main, in=200) + 12:10 (agent, in=300) = 2 tours
    assert.equal(u.turns, 2)
    assert.equal(u.input, 500)
  })

  test('fenêtre vide → null', () => {
    const u = sumUsageWindow(dir, '2026-06-17T00:00:00.000Z', '2026-06-17T01:00:00.000Z')
    assert.equal(u, null)
  })

  test('JSON invalide / lignes sans usage|timestamp ignorés sans crash', () => {
    // La fenêtre large couvre noise.jsonl ; aucune de ses lignes ne doit compter.
    const u = sumUsageWindow(dir, '2026-06-16T00:00:00.000Z', '2026-06-16T23:59:00.000Z')
    assert.ok(u)
    // Tous les tours valides (timestamp+usage) : main 4 + agent 2 = 6.
    assert.equal(u.turns, 6)
    // Les 7777 (sans timestamp) et 5000 (.txt) ne sont jamais comptés.
    assert.ok(u.input < 7000)
  })

  test('dossier inexistant → null', () => {
    assert.equal(sumUsageWindow(join(dir, 'nope'), FROM, TO), null)
  })

  test('bornes ISO invalides → null', () => {
    assert.equal(sumUsageWindow(dir, 'pas-une-date', TO), null)
  })
})
