#!/usr/bin/env node
'use strict'
/**
 * tests/coordinator/vault.test.js
 * Suite : AES-256-GCM encryption at rest (node:test, zéro dépendance externe)
 */

const { test, describe } = require('node:test')
const assert = require('node:assert/strict')
const fs   = require('node:fs')
const os   = require('node:os')
const path = require('node:path')

const { encrypt, decrypt, deriveKey, encryptFile, decryptFile } =
  require('../../coordinator/vault.js')

// ── Helpers ───────────────────────────────────────────────────────────────────

/** Génère une clé 32-bytes aléatoire pour les tests */
function randomKey() {
  return require('node:crypto').randomBytes(32)
}

/** Crée un fichier temporaire et retourne son chemin */
function tmpFile(content = 'contenu secret') {
  const p = path.join(os.tmpdir(), `vault-test-${Date.now()}-${Math.random().toString(36).slice(2)}.txt`)
  fs.writeFileSync(p, content, 'utf8')
  return p
}

/** Nettoie les fichiers temporaires créés durant un test */
function cleanup(...paths) {
  for (const p of paths) {
    try { fs.unlinkSync(p) } catch {}
  }
}

// ── encrypt / decrypt ─────────────────────────────────────────────────────────

describe('vault — encrypt/decrypt', () => {

  test('encrypt retourne un objet { ciphertext, iv, tag }', () => {
    const key     = randomKey()
    const result  = encrypt('hello world', key)
    assert.ok(typeof result.ciphertext === 'string', 'ciphertext doit être une string')
    assert.ok(typeof result.iv         === 'string', 'iv doit être une string')
    assert.ok(typeof result.tag        === 'string', 'tag doit être une string')
    // iv = 12 bytes → 24 hex chars
    assert.equal(result.iv.length, 24,  'iv doit faire 24 chars hex (12 bytes)')
    // tag = 16 bytes → 32 hex chars
    assert.equal(result.tag.length, 32, 'tag doit faire 32 chars hex (16 bytes)')
  })

  test('decrypt restitue le plaintext original', () => {
    const key       = randomKey()
    const plaintext = 'données confidentielles 🔒'
    const payload   = encrypt(plaintext, key)
    const result    = decrypt(payload, key)
    assert.equal(result, plaintext)
  })

  test('decrypt échoue avec un tag altéré (authentication error)', () => {
    const key     = randomKey()
    const payload = encrypt('secret', key)
    // Altère le premier byte du tag
    const badTag  = '00' + payload.tag.slice(2)
    assert.throws(
      () => decrypt({ ...payload, tag: badTag }, key),
      (err) => {
        // Node peut lever 'Unsupported state' ou 'bad decrypt' selon la version
        assert.ok(err instanceof Error, 'doit lever une Error')
        return true
      }
    )
  })

  test('encrypt produit un IV différent à chaque appel (aléatoire)', () => {
    const key  = randomKey()
    const r1   = encrypt('même texte', key)
    const r2   = encrypt('même texte', key)
    assert.notEqual(r1.iv, r2.iv, 'chaque appel doit générer un IV unique')
    assert.notEqual(r1.ciphertext, r2.ciphertext, 'le ciphertext doit différer (IV unique)')
  })

  test('round-trip avec passphrase (via deriveKey)', () => {
    const passphrase = 'passphrase-de-test-123!'
    const { key, salt } = deriveKey(passphrase)
    const plaintext     = 'données sensibles via passphrase'
    const payload       = encrypt(plaintext, key)

    // Re-dérive depuis la même passphrase + salt → même clé
    const { key: key2 } = deriveKey(passphrase, salt)
    const result = decrypt(payload, key2)
    assert.equal(result, plaintext)
  })

  test('decrypt avec mauvaise clé → exception', () => {
    const key1    = randomKey()
    const key2    = randomKey()
    const payload = encrypt('secret', key1)
    assert.throws(() => decrypt(payload, key2))
  })

  test('encrypt gère les chaînes vides', () => {
    const key    = randomKey()
    const result = encrypt('', key)
    assert.equal(decrypt(result, key), '')
  })

  test('encrypt gère les chaînes longues (10 KB)', () => {
    const key       = randomKey()
    const plaintext = 'x'.repeat(10_000)
    const payload   = encrypt(plaintext, key)
    assert.equal(decrypt(payload, key), plaintext)
  })

  test('toKeyBuffer rejette une clé de mauvaise taille', () => {
    assert.throws(() => encrypt('test', Buffer.alloc(16)), /32 bytes/)
  })

  test('toKeyBuffer rejette un hex string de mauvaise taille', () => {
    assert.throws(() => encrypt('test', 'deadbeef'), /32 bytes|invalide/)
  })
})

// ── deriveKey ─────────────────────────────────────────────────────────────────

describe('vault — deriveKey', () => {

  test('retourne un objet { key: Buffer, salt: string }', () => {
    const result = deriveKey('passphrase')
    assert.ok(Buffer.isBuffer(result.key),       'key doit être un Buffer')
    assert.equal(typeof result.salt, 'string',   'salt doit être une string')
  })

  test('key est un Buffer de 32 bytes', () => {
    const { key } = deriveKey('passphrase')
    assert.equal(key.length, 32)
  })

  test('même passphrase + même salt → même clé (déterministe)', () => {
    const { key: k1, salt } = deriveKey('même passphrase')
    const { key: k2 }       = deriveKey('même passphrase', salt)
    assert.deepEqual(k1, k2)
  })

  test('salt différent → clé différente', () => {
    const { key: k1, salt: s1 } = deriveKey('passphrase')
    const { key: k2 }           = deriveKey('passphrase', require('node:crypto').randomBytes(16))
    // Probabilité de collision négligeable
    assert.notDeepEqual(k1, k2)
  })

  test('accepte un Buffer comme salt', () => {
    const saltBuf   = require('node:crypto').randomBytes(16)
    const { key: k1 } = deriveKey('passphrase', saltBuf)
    const { key: k2 } = deriveKey('passphrase', saltBuf.toString('hex'))
    assert.deepEqual(k1, k2, 'Buffer et hex string doivent produire la même clé')
  })

  test('salt généré automatiquement est une hex string de 32 chars (16 bytes)', () => {
    const { salt } = deriveKey('passphrase')
    assert.equal(salt.length, 32, 'salt = 16 bytes = 32 chars hex')
    assert.match(salt, /^[0-9a-f]+$/, 'salt doit être en minuscules hex')
  })
})

// ── encryptFile / decryptFile ─────────────────────────────────────────────────

describe('vault — encryptFile / decryptFile', () => {

  test('encryptFile crée un fichier .enc', () => {
    const src = tmpFile('contenu à chiffrer')
    let encPath
    try {
      const result = encryptFile(src, 'passphrase-test')
      encPath = result.encPath
      assert.ok(fs.existsSync(encPath), '.enc doit exister')
      assert.equal(encPath, src + '.enc')
    } finally {
      cleanup(src, encPath)
    }
  })

  test('decryptFile restitue le contenu original', () => {
    const original = 'contenu original avec émojis 🎉'
    const src = tmpFile(original)
    let encPath
    try {
      const { encPath: ep, salt } = encryptFile(src, 'passphrase-test')
      encPath = ep
      const result = decryptFile(encPath, 'passphrase-test', salt)
      assert.equal(result, original)
    } finally {
      cleanup(src, encPath)
    }
  })

  test('décryptage avec mauvais passphrase → exception', () => {
    const src = tmpFile('données secrètes')
    let encPath
    try {
      const { encPath: ep, salt } = encryptFile(src, 'bonne-passphrase')
      encPath = ep
      assert.throws(() => decryptFile(encPath, 'mauvaise-passphrase', salt))
    } finally {
      cleanup(src, encPath)
    }
  })

  test('fichier original non modifié par encryptFile', () => {
    const original = 'fichier original intact'
    const src = tmpFile(original)
    let encPath
    try {
      const { encPath: ep } = encryptFile(src, 'passphrase')
      encPath = ep
      const afterEncrypt = fs.readFileSync(src, 'utf8')
      assert.equal(afterEncrypt, original, 'le fichier source ne doit pas être modifié')
    } finally {
      cleanup(src, encPath)
    }
  })

  test('encryptFile retourne { encPath, salt } avec salt non vide', () => {
    const src = tmpFile('test salt')
    let encPath
    try {
      const result = encryptFile(src, 'passphrase')
      encPath = result.encPath
      assert.ok(typeof result.salt === 'string' && result.salt.length > 0, 'salt doit être non vide')
      assert.match(result.salt, /^[0-9a-f]+$/, 'salt doit être en hex')
    } finally {
      cleanup(src, encPath)
    }
  })

  test('.enc contient un JSON valide { ciphertext, iv, tag }', () => {
    const src = tmpFile('vérification format JSON')
    let encPath
    try {
      const { encPath: ep } = encryptFile(src, 'passphrase')
      encPath = ep
      const raw = fs.readFileSync(encPath, 'utf8')
      const parsed = JSON.parse(raw)
      assert.ok(parsed.ciphertext, 'doit avoir ciphertext')
      assert.ok(parsed.iv,         'doit avoir iv')
      assert.ok(parsed.tag,        'doit avoir tag')
    } finally {
      cleanup(src, encPath)
    }
  })
})
