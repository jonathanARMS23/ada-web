'use strict'
/**
 * tests/coordinator/witness.test.js
 *
 * Witness anti-régression (adapté de ruflo, sans Ed25519 — SHA-256 + marker).
 * TDD : ces specs sont écrites AVANT l'implémentation de coordinator/witness.js.
 *
 * Distinction fine attendue :
 *   - pass       : marker présent ET sha256 == baseline
 *   - drift      : marker présent MAIS sha256 != baseline  (toléré, warning)
 *   - regressed  : marker ABSENT                            (bloquant, exit 1)
 *   - missing    : fichier introuvable                      (bloquant, exit 1)
 */
const { test, describe } = require('node:test')
const assert = require('node:assert/strict')
const { join } = require('path')
const os = require('os')
const fs = require('fs')

const W = require(join(__dirname, '../../coordinator/witness.js'))

/** Crée un bac à sable temporaire isolé avec un repoRoot + fichiers de config witness. */
function sandbox() {
  const dir = fs.mkdtempSync(join(os.tmpdir(), 'witness-test-'))
  const fixesPath = join(dir, 'witness-fixes.json')
  const historyPath = join(dir, 'witness-history.jsonl')
  return {
    dir,
    fixesPath,
    historyPath,
    repoRoot: dir,
    writeSource(relPath, content) {
      const abs = join(dir, relPath)
      fs.mkdirSync(join(abs, '..'), { recursive: true })
      fs.writeFileSync(abs, content)
      return abs
    },
    writeFixes(fixes) {
      fs.writeFileSync(fixesPath, JSON.stringify({ schema: 'ada-witness/v1', fixes }, null, 2))
    },
    readFixes() {
      return JSON.parse(fs.readFileSync(fixesPath, 'utf8')).fixes
    },
    cleanup() {
      fs.rmSync(dir, { recursive: true, force: true })
    },
  }
}

describe('evaluateFix — statut par fix', () => {
  test('pass : marker présent + sha256 correspond au baseline', () => {
    const sb = sandbox()
    try {
      sb.writeSource('src/a.js', 'const x = 1 // MARKER_ALPHA\n')
      const sha = W.fileSha256(join(sb.dir, 'src/a.js'))
      const r = W.evaluateFix(sb.repoRoot, {
        id: 'F1', file: 'src/a.js', marker: 'MARKER_ALPHA', sha256: sha,
      })
      assert.equal(r.status, 'pass')
      assert.equal(r.markerPresent, true)
      assert.equal(r.sha256Match, true)
    } finally { sb.cleanup() }
  })

  test('drift : marker présent MAIS sha256 diffère du baseline', () => {
    const sb = sandbox()
    try {
      sb.writeSource('src/a.js', 'const x = 2 // MARKER_ALPHA + commentaire ajouté\n')
      const r = W.evaluateFix(sb.repoRoot, {
        id: 'F1', file: 'src/a.js', marker: 'MARKER_ALPHA', sha256: 'baseline_sha_qui_ne_matche_pas',
      })
      assert.equal(r.status, 'drift')
      assert.equal(r.markerPresent, true)
      assert.equal(r.sha256Match, false)
    } finally { sb.cleanup() }
  })

  test('regressed : marker absent (le fix a été supprimé)', () => {
    const sb = sandbox()
    try {
      sb.writeSource('src/a.js', 'const x = 3 // le fix a disparu\n')
      const r = W.evaluateFix(sb.repoRoot, {
        id: 'F1', file: 'src/a.js', marker: 'MARKER_ALPHA', sha256: 'peu importe',
      })
      assert.equal(r.status, 'regressed')
      assert.equal(r.markerPresent, false)
    } finally { sb.cleanup() }
  })

  test('missing : fichier introuvable', () => {
    const sb = sandbox()
    try {
      const r = W.evaluateFix(sb.repoRoot, {
        id: 'F1', file: 'src/absent.js', marker: 'MARKER_ALPHA', sha256: 'x',
      })
      assert.equal(r.status, 'missing')
      assert.equal(r.markerPresent, false)
    } finally { sb.cleanup() }
  })

  test('sans baseline sha256 (jamais regen) : marker présent → pass', () => {
    const sb = sandbox()
    try {
      sb.writeSource('src/a.js', '// MARKER_ALPHA\n')
      const r = W.evaluateFix(sb.repoRoot, { id: 'F1', file: 'src/a.js', marker: 'MARKER_ALPHA' })
      assert.equal(r.status, 'pass')
    } finally { sb.cleanup() }
  })

  test('marker multi-occurrences : présent + markerCount > 1, statut pass', () => {
    const sb = sandbox()
    try {
      sb.writeSource('src/a.js', 'MARKER_DUP\nMARKER_DUP\nMARKER_DUP\n')
      const sha = W.fileSha256(join(sb.dir, 'src/a.js'))
      const r = W.evaluateFix(sb.repoRoot, {
        id: 'F1', file: 'src/a.js', marker: 'MARKER_DUP', sha256: sha,
      })
      assert.equal(r.markerPresent, true)
      assert.equal(r.markerCount, 3)
      assert.equal(r.status, 'pass')
    } finally { sb.cleanup() }
  })
})

describe('resolveFixPath / evaluateFix — fallback layout runtime (sans préfixe .claude/)', () => {
  test('essai 1 réussit directement (layout repo) : le fallback n\'est jamais consulté', () => {
    const sb = sandbox()
    try {
      sb.writeSource('.claude/coordinator/run.js', '// FIX_MARKER\n')
      const abs = W.resolveFixPath(sb.repoRoot, '.claude/coordinator/run.js', '/chemin/qui/nexiste/pas')
      assert.equal(abs, join(sb.repoRoot, '.claude/coordinator/run.js'))
    } finally { sb.cleanup() }
  })

  test('essai 1 échoue, essai 2 réussit : chemin `.claude/` strippé et résolu via fallbackRoot', () => {
    const sb = sandbox()
    try {
      // Layout runtime : PAS de préfixe .claude/, le fichier vit directement
      // sous une racine runtime distincte (ex: ~/.claude-pro/coordinator/run.js).
      const runtimeRoot = fs.mkdtempSync(join(os.tmpdir(), 'witness-runtime-'))
      fs.mkdirSync(join(runtimeRoot, 'coordinator'), { recursive: true })
      fs.writeFileSync(join(runtimeRoot, 'coordinator/run.js'), '// FIX_MARKER\n')
      try {
        const abs = W.resolveFixPath(sb.repoRoot, '.claude/coordinator/run.js', runtimeRoot)
        assert.equal(abs, join(runtimeRoot, 'coordinator/run.js'))

        const r = W.evaluateFix(sb.repoRoot, {
          id: 'RT', file: '.claude/coordinator/run.js', marker: 'FIX_MARKER',
        }, { fallbackRoot: runtimeRoot })
        assert.equal(r.status, 'pass')
        assert.equal(r.markerPresent, true)
      } finally { fs.rmSync(runtimeRoot, { recursive: true, force: true }) }
    } finally { sb.cleanup() }
  })

  test('les deux essais échouent → missing', () => {
    const sb = sandbox()
    try {
      const abs = W.resolveFixPath(sb.repoRoot, '.claude/coordinator/absent.js', join(sb.dir, 'aucune-racine'))
      assert.equal(abs, null)
      const r = W.evaluateFix(sb.repoRoot, {
        id: 'RT2', file: '.claude/coordinator/absent.js', marker: 'X',
      }, { fallbackRoot: join(sb.dir, 'aucune-racine') })
      assert.equal(r.status, 'missing')
    } finally { sb.cleanup() }
  })

  test('fichier sans préfixe .claude/ absent en essai 1 → pas de fallback tenté, missing', () => {
    const sb = sandbox()
    try {
      // Un fallbackRoot qui contiendrait bien le fichier ne doit PAS être
      // consulté si file ne commence pas par `.claude/` (garde-fou du préfixe).
      const runtimeRoot = fs.mkdtempSync(join(os.tmpdir(), 'witness-runtime-'))
      fs.writeFileSync(join(runtimeRoot, 'run.js'), '// FIX_MARKER\n')
      try {
        const r = W.evaluateFix(sb.repoRoot, {
          id: 'RT3', file: 'run.js', marker: 'FIX_MARKER',
        }, { fallbackRoot: runtimeRoot })
        assert.equal(r.status, 'missing')
      } finally { fs.rmSync(runtimeRoot, { recursive: true, force: true }) }
    } finally { sb.cleanup() }
  })

  test('runVerify propage fallbackRoot à chaque fix évalué (layout runtime bout-en-bout)', () => {
    const sb = sandbox()
    try {
      const runtimeRoot = fs.mkdtempSync(join(os.tmpdir(), 'witness-runtime-'))
      fs.mkdirSync(join(runtimeRoot, 'coordinator'), { recursive: true })
      fs.writeFileSync(join(runtimeRoot, 'coordinator/run.js'), '// FIX_MARKER\n')
      try {
        sb.writeFixes([
          { id: 'RT', file: '.claude/coordinator/run.js', marker: 'FIX_MARKER', sha256: '' },
        ])
        const res = W.runVerify({ fixesPath: sb.fixesPath, repoRoot: sb.repoRoot, fallbackRoot: runtimeRoot })
        assert.equal(res.ok, true)
        assert.equal(res.summary.pass, 1)
        assert.equal(res.summary.missing, 0)
      } finally { fs.rmSync(runtimeRoot, { recursive: true, force: true }) }
    } finally { sb.cleanup() }
  })
})

describe('runVerify — agrégation + exit code', () => {
  test('tous pass → ok=true, summary cohérent', () => {
    const sb = sandbox()
    try {
      sb.writeSource('src/a.js', '// MARKER_A\n')
      sb.writeSource('src/b.js', '// MARKER_B\n')
      const shaA = W.fileSha256(join(sb.dir, 'src/a.js'))
      const shaB = W.fileSha256(join(sb.dir, 'src/b.js'))
      sb.writeFixes([
        { id: 'A', file: 'src/a.js', marker: 'MARKER_A', sha256: shaA },
        { id: 'B', file: 'src/b.js', marker: 'MARKER_B', sha256: shaB },
      ])
      const res = W.runVerify({ fixesPath: sb.fixesPath, repoRoot: sb.repoRoot })
      assert.equal(res.ok, true)
      assert.equal(res.summary.pass, 2)
      assert.equal(res.summary.regressed, 0)
      assert.equal(res.summary.total, 2)
    } finally { sb.cleanup() }
  })

  test('drift seul → ok=true (toléré)', () => {
    const sb = sandbox()
    try {
      sb.writeSource('src/a.js', '// MARKER_A modifié\n')
      sb.writeFixes([{ id: 'A', file: 'src/a.js', marker: 'MARKER_A', sha256: 'ancien_sha' }])
      const res = W.runVerify({ fixesPath: sb.fixesPath, repoRoot: sb.repoRoot })
      assert.equal(res.ok, true)
      assert.equal(res.summary.drift, 1)
    } finally { sb.cleanup() }
  })

  test('une régression → ok=false', () => {
    const sb = sandbox()
    try {
      sb.writeSource('src/a.js', '// fix supprimé\n')
      sb.writeFixes([{ id: 'A', file: 'src/a.js', marker: 'MARKER_A', sha256: 'x' }])
      const res = W.runVerify({ fixesPath: sb.fixesPath, repoRoot: sb.repoRoot })
      assert.equal(res.ok, false)
      assert.equal(res.summary.regressed, 1)
    } finally { sb.cleanup() }
  })

  test('fichier manquant → ok=false', () => {
    const sb = sandbox()
    try {
      sb.writeFixes([{ id: 'A', file: 'src/nope.js', marker: 'MARKER_A', sha256: 'x' }])
      const res = W.runVerify({ fixesPath: sb.fixesPath, repoRoot: sb.repoRoot })
      assert.equal(res.ok, false)
      assert.equal(res.summary.missing, 1)
    } finally { sb.cleanup() }
  })
})

describe('runRegen — recalcule les SHA après drift accepté', () => {
  test('met à jour sha256 dans le fichier de fixes + append snapshot history', () => {
    const sb = sandbox()
    try {
      sb.writeSource('src/a.js', '// MARKER_A v2\n')
      sb.writeFixes([{ id: 'A', file: 'src/a.js', marker: 'MARKER_A', sha256: 'ancien' }])

      const out = W.runRegen({
        fixesPath: sb.fixesPath,
        repoRoot: sb.repoRoot,
        historyPath: sb.historyPath,
        commit: 'deadbeef',
        issuedAt: '2026-07-15T00:00:00.000Z',
      })

      const expected = W.fileSha256(join(sb.dir, 'src/a.js'))
      assert.equal(out.fixes[0].sha256, expected)
      assert.equal(sb.readFixes()[0].sha256, expected)

      // Après regen, un verify repasse à pass (drift résorbé)
      const res = W.runVerify({ fixesPath: sb.fixesPath, repoRoot: sb.repoRoot })
      assert.equal(res.ok, true)
      assert.equal(res.summary.pass, 1)
      assert.equal(res.summary.drift, 0)

      // history.jsonl contient une entrée
      const lines = fs.readFileSync(sb.historyPath, 'utf8').split('\n').filter(Boolean)
      assert.equal(lines.length, 1)
      const snap = JSON.parse(lines[0])
      assert.equal(snap.commit, 'deadbeef')
      assert.equal(snap.fixes.A.markerVerified, true)
    } finally { sb.cleanup() }
  })
})

describe('addFix — enregistre un nouveau fix', () => {
  test('ajoute une entrée (sha256 vide tant que non regen)', () => {
    const sb = sandbox()
    try {
      sb.writeFixes([])
      W.addFix({ fixesPath: sb.fixesPath, id: 'NEW', file: 'src/x.js', marker: 'MARK', desc: 'desc' })
      const fixes = sb.readFixes()
      assert.equal(fixes.length, 1)
      assert.equal(fixes[0].id, 'NEW')
      assert.equal(fixes[0].marker, 'MARK')
      assert.equal(fixes[0].desc, 'desc')
    } finally { sb.cleanup() }
  })

  test('refuse un id en doublon', () => {
    const sb = sandbox()
    try {
      sb.writeFixes([{ id: 'DUP', file: 'src/x.js', marker: 'M' }])
      assert.throws(() => W.addFix({ fixesPath: sb.fixesPath, id: 'DUP', file: 'y.js', marker: 'N' }))
    } finally { sb.cleanup() }
  })
})

describe('history — bisect temporel', () => {
  test('findRegressionIntroductions localise la fenêtre last-pass → regressed', () => {
    const sb = sandbox()
    try {
      const rows = [
        { v: 1, commit: 'c1', issuedAt: 't1', fixes: { F: { sha256: 'a', markerVerified: true } } },
        { v: 1, commit: 'c2', issuedAt: 't2', fixes: { F: { sha256: 'b', markerVerified: true } } },
        { v: 1, commit: 'c3', issuedAt: 't3', fixes: { F: { sha256: 'c', markerVerified: false } } },
      ]
      fs.writeFileSync(sb.historyPath, rows.map(r => JSON.stringify(r)).join('\n') + '\n')
      const hist = W.loadHistory(sb.historyPath)
      const regs = W.findRegressionIntroductions(hist)
      assert.equal(regs.length, 1)
      assert.equal(regs[0].id, 'F')
      assert.equal(regs[0].lastPassCommit, 'c2')
      assert.equal(regs[0].regressedAtCommit, 'c3')
    } finally { sb.cleanup() }
  })

  test('loadHistory sur fichier absent → tableau vide', () => {
    const sb = sandbox()
    try {
      assert.deepEqual(W.loadHistory(join(sb.dir, 'nope.jsonl')), [])
    } finally { sb.cleanup() }
  })
})
