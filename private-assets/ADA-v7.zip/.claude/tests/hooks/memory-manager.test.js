#!/usr/bin/env node
'use strict'
const { test, describe, before, after } = require('node:test')
const assert = require('node:assert/strict')
const { mkdirSync, rmSync, existsSync, readFileSync, writeFileSync } = require('fs')
const { join } = require('path')
const { spawnSync } = require('child_process')

const TMP      = join(__dirname, '../../..', '.test-tmp-mm')
const HOOK_JS  = join(__dirname, '../../hooks/memory-manager.js')

before(() => mkdirSync(join(TMP, 'memory', 'global'), { recursive: true }))
after(() => { try { rmSync(TMP, { recursive: true }) } catch {} })

function runHook(payload) {
  return spawnSync('node', [HOOK_JS], {
    input: JSON.stringify(payload),
    encoding: 'utf8',
    timeout: 4000,
    env: { ...process.env, CLAUDE_CONFIG_DIR: TMP, AI_DEV_PROJECT: 'test-project' }
  })
}

function readFile(rel) {
  const p = join(TMP, rel)
  return existsSync(p) ? readFileSync(p, 'utf8') : null
}

// ─── classify — decision ──────────────────────────────────────────────────────

describe('classify → decision', () => {
  test('content avec "Decision:" → écrit dans decisions.md', () => {
    runHook({
      tool_input: { file_path: 'src/service.ts', content: 'Decision: on utilise JWT asymétrique plutôt que symétrique pour permettre la vérification multi-service sans partage de secret' }
    })
    const dec = readFile('memory/global/decisions.md')
    assert.ok(dec, 'decisions.md devrait exister')
    assert.ok(dec.includes('Décision'))
  })

  test('content avec "adr:" → classified as decision', () => {
    runHook({
      tool_input: { file_path: 'docs/adr-001.md', content: 'ADR: on décide de ne pas utiliser de micro-frontend pour ce projet car le bundle splitting suffit pour notre échelle actuelle' }
    })
    const dec = readFile('memory/global/decisions.md')
    assert.ok(dec)
    assert.ok(dec.includes('Décision') || dec.includes('dec'))
  })
})

// ─── classify — bug_fix ───────────────────────────────────────────────────────

describe('classify → bug_fix', () => {
  test('content avec "fix:" → écrit dans errors.md', () => {
    runHook({
      tool_input: { file_path: 'src/auth.service.ts', content: 'fix: corrige la race condition dans refreshToken qui causait des tokens invalides sous charge élevée quand deux requêtes arrivaient simultanément' }
    })
    const err = readFile('memory/global/errors.md')
    assert.ok(err, 'errors.md devrait exister')
    assert.ok(err.includes('Fix'))
  })

  test('filePath contenant "fix" → bug_fix', () => {
    runHook({
      tool_input: { file_path: 'src/fix-cache-invalidation.ts', content: 'correction du problème de cache invalidation sur les queries imbriquées dans le user resolver qui retournait des données périmées' }
    })
    const err = readFile('memory/global/errors.md')
    assert.ok(err)
  })
})

// ─── classify — pattern ───────────────────────────────────────────────────────

describe('classify → pattern', () => {
  test('content avec "pattern:" → écrit dans patterns.md avec code block', () => {
    runHook({
      tool_input: { file_path: 'src/utils/retry.ts', content: 'pattern: retry avec exponential backoff pour les appels LLM — utiliser avec tous les providers API qui peuvent throttler' }
    })
    const pat = readFile('memory/global/patterns.md')
    assert.ok(pat, 'patterns.md devrait exister')
    assert.ok(pat.includes('Pattern') || pat.includes('```'))
  })

  test('filePath avec "utils" → pattern', () => {
    runHook({
      tool_input: { file_path: 'src/utils/pagination.ts', content: 'helper générique pour la pagination cursor-based — retourne nextCursor et hasNextPage pour tous les endpoints list de l\'API' }
    })
    const pat = readFile('memory/global/patterns.md')
    assert.ok(pat)
  })
})

// ─── classify — db_change ────────────────────────────────────────────────────

describe('classify → db_change', () => {
  test('filePath contenant "migration" → db_change dans context.md', () => {
    runHook({
      tool_input: { file_path: 'migrations/0005_add_workspace_id.sql', content: 'ALTER TABLE users ADD COLUMN workspace_id UUID NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE; CREATE INDEX idx_users_workspace ON users(workspace_id);' }
    })
    const ctx = readFile('memory/projects/test-project/context.md')
    assert.ok(ctx, 'context.md devrait exister')
    assert.ok(ctx.includes('DB') || ctx.includes('migration'))
  })

  test('content contenant "create table" → db_change', () => {
    runHook({
      tool_input: { file_path: 'schema.sql', content: 'CREATE TABLE subscriptions (id UUID PRIMARY KEY, workspace_id UUID, status TEXT, created_at TIMESTAMPTZ DEFAULT NOW())' }
    })
    const ctx = readFile('memory/projects/test-project/context.md')
    assert.ok(ctx)
  })
})

// ─── classify — context_update (défaut) ──────────────────────────────────────

describe('classify → context_update (défaut)', () => {
  test('fichier TS standard → context_update dans context.md', () => {
    runHook({
      tool_input: { file_path: 'src/users/users.service.ts', content: 'ajout de la méthode getUsersByWorkspace qui retourne la liste paginée des utilisateurs d\'un workspace avec leurs rôles et permissions actifs' }
    })
    const ctx = readFile('memory/projects/test-project/context.md')
    assert.ok(ctx)
    assert.ok(ctx.includes('Dernières modifications') || ctx.includes('users.service.ts'))
  })
})

// ─── Filtres — skip patterns ─────────────────────────────────────────────────

describe('Skip patterns', () => {
  test('fichier dans node_modules → ignoré', () => {
    const before = readFile('memory/global/patterns.md')
    runHook({
      tool_input: { file_path: 'node_modules/express/index.js', content: 'pattern: express routing avec middleware chain — très longue description pour dépasser le seuil de 80 chars minimum requis par le hook' }
    })
    const after = readFile('memory/global/patterns.md')
    assert.equal(before, after, 'node_modules ne devrait pas modifier les fichiers mémoire')
  })

  test('content trop court (< 80 chars) → ignoré', () => {
    const before = readFile('memory/global/decisions.md')
    runHook({
      tool_input: { file_path: 'src/index.ts', content: 'Decision: court' }
    })
    const after = readFile('memory/global/decisions.md')
    assert.equal(before, after, 'Contenu trop court devrait être ignoré')
  })
})

// ─── Robustesse ───────────────────────────────────────────────────────────────

describe('Robustesse', () => {
  test('JSON invalide → exit 0 sans crash', () => {
    const r = spawnSync('node', [HOOK_JS], {
      input: 'INVALID JSON',
      encoding: 'utf8',
      timeout: 4000,
      env: { ...process.env, CLAUDE_CONFIG_DIR: TMP }
    })
    assert.equal(r.status, 0)
  })

  test('payload sans content → exit 0 sans crash', () => {
    const r = spawnSync('node', [HOOK_JS], {
      input: JSON.stringify({ tool_input: {} }),
      encoding: 'utf8',
      timeout: 4000,
      env: { ...process.env, CLAUDE_CONFIG_DIR: TMP }
    })
    assert.equal(r.status, 0)
  })
})
