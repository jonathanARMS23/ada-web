#!/usr/bin/env node
'use strict'
/**
 * tests/hooks/ponytail-subagent.test.js — hooks/ponytail-subagent.js (SubagentStart)
 *
 * Couvre : denylist non-codeur (skip), agent_type inconnu/dynamique (inject
 * par défaut — jamais d'allowlist), fiche .claude/agents/*.md marquée
 * read-only via frontmatter `tools:` (skip), stdin invalide/vide (fail-open,
 * exit 0, inject par défaut), pas de crash quand la fiche agent n'existe pas.
 */
const { test, describe, before, after } = require('node:test')
const assert = require('node:assert/strict')
const { spawnSync } = require('child_process')
const { mkdirSync, rmSync, writeFileSync } = require('fs')
const { join } = require('path')

const HOOK_JS = join(__dirname, '../../hooks/ponytail-subagent.js')
const TMP     = join(__dirname, '../../..', '.test-tmp-ponytail-subagent')
const AGENTS_DIR = join(TMP, '.claude', 'agents')

before(() => {
  mkdirSync(AGENTS_DIR, { recursive: true })
  // Fiche agent read-only fictive (aucune fiche réelle du repo n'a de champ
  // `tools:` aujourd'hui — voir header du hook) pour exercer le chemin
  // frontmatter sans toucher .claude/agents/ du repo.
  writeFileSync(join(AGENTS_DIR, 'read-only-fixture.md'), [
    '---',
    'name: read-only-fixture',
    'description: Agent de test en lecture seule',
    'tools: Read, Grep, Glob',
    '---',
    '# Read Only Fixture',
  ].join('\n'))
  // Fiche agent codeur (tools inclut Write) → ne doit jamais être skip.
  writeFileSync(join(AGENTS_DIR, 'writer-fixture.md'), [
    '---',
    'name: writer-fixture',
    'description: Agent de test avec accès écriture',
    'tools: Read, Write, Edit, Bash',
    '---',
    '# Writer Fixture',
  ].join('\n'))
})
after(() => { try { rmSync(TMP, { recursive: true }) } catch {} })

/**
 * @param {object|string|null} payload objet à sérialiser en JSON stdin, une
 *   chaîne brute (pour simuler un JSON invalide), ou null pour un stdin vide.
 * @param {object} [envOverride] variables d'env supplémentaires (ex. CLAUDE_PROJECT_DIR)
 */
function runHook(payload, envOverride = {}) {
  const input = payload === null ? '' : (typeof payload === 'string' ? payload : JSON.stringify(payload))
  const result = spawnSync('node', [HOOK_JS], {
    input,
    encoding: 'utf8',
    timeout: 5000,
    env: { ...process.env, ...envOverride },
  })
  let injected = false
  let context = ''
  try {
    const parsed = JSON.parse(result.stdout)
    context = parsed?.hookSpecificOutput?.additionalContext || ''
    injected = Boolean(context) && parsed?.hookSpecificOutput?.hookEventName === 'SubagentStart'
  } catch (e) { /* stdout vide = pas d'injection, JSON.parse échoue normalement */ }
  return { injected, context, exitCode: result.status, stdout: result.stdout, stderr: result.stderr }
}

// ─── denylist non-codeur ──────────────────────────────────────────────────

describe('denylist non-codeur', () => {
  for (const agentType of ['reviewer', 'security-auditor', 'ux-designer', 'onboarding-agent', 'Explore', 'Plan']) {
    test(`agent_type="${agentType}" → pas d'injection`, () => {
      const r = runHook({ agent_type: agentType, session_id: 's1' })
      assert.equal(r.injected, false)
      assert.equal(r.exitCode, 0)
    })
  }

  test('match insensible à la casse (REVIEWER)', () => {
    const r = runHook({ agent_type: 'REVIEWER' })
    assert.equal(r.injected, false)
    assert.equal(r.exitCode, 0)
  })
})

// ─── agent_type inconnu/dynamique → injection par défaut ──────────────────

describe('agent_type inconnu ou dynamique', () => {
  test('agent_type totalement inconnu → injecte par défaut', () => {
    const r = runHook({ agent_type: 'un-agent-genere-a-la-volee-xyz123' })
    assert.equal(r.injected, true)
    assert.equal(r.exitCode, 0)
    assert.ok(r.context.includes('ANTI-OVERBUILD'))
  })

  test('agent_type codeur connu (nestjs) → injecte', () => {
    const r = runHook({ agent_type: 'nestjs' })
    assert.equal(r.injected, true)
  })

  test('agent_type absent du payload → injecte par défaut', () => {
    const r = runHook({ session_id: 's1', hook_event_name: 'SubagentStart' })
    assert.equal(r.injected, true)
    assert.equal(r.exitCode, 0)
  })
})

// ─── fiche .claude/agents/*.md marquée read-only via frontmatter ──────────

describe('fiche agent frontmatter tools:', () => {
  test('agent avec tools: read-only (pas de Write/Edit) → pas d\'injection', () => {
    const r = runHook(
      { agent_type: 'read-only-fixture' },
      { CLAUDE_PROJECT_DIR: TMP }
    )
    assert.equal(r.injected, false)
    assert.equal(r.exitCode, 0)
  })

  test('agent avec tools: Write/Edit présent → injecte', () => {
    const r = runHook(
      { agent_type: 'writer-fixture' },
      { CLAUDE_PROJECT_DIR: TMP }
    )
    assert.equal(r.injected, true)
    assert.equal(r.exitCode, 0)
  })

  test('fiche read-only-fixture ignorée sans CLAUDE_PROJECT_DIR pointé sur TMP (pas trouvée ailleurs) → injecte par défaut', () => {
    // Sans CLAUDE_PROJECT_DIR pointant vers TMP, le hook ne trouve aucune
    // fiche read-only-fixture.md dans le vrai repo → comportement par défaut.
    const r = runHook(
      { agent_type: 'read-only-fixture' },
      { CLAUDE_PROJECT_DIR: join(TMP, 'nonexistent-dir'), CLAUDE_CONFIG_DIR: join(TMP, 'nonexistent-config') }
    )
    assert.equal(r.injected, true)
  })
})

// ─── pas de crash si la fiche agent n'existe pas ──────────────────────────

describe('fiche agent absente', () => {
  test('agent_type sans fiche .md correspondante → pas de crash, injecte', () => {
    const r = runHook(
      { agent_type: 'agent-sans-fiche-du-tout' },
      { CLAUDE_PROJECT_DIR: TMP }
    )
    assert.equal(r.injected, true)
    assert.equal(r.exitCode, 0)
    assert.equal(r.stderr, '')
  })

  test('agent_type avec traversal de chemin → ignoré proprement, injecte par défaut', () => {
    const r = runHook(
      { agent_type: '../../../etc/passwd' },
      { CLAUDE_PROJECT_DIR: TMP }
    )
    assert.equal(r.exitCode, 0)
    assert.equal(r.stderr, '')
  })
})

// ─── stdin invalide/vide → fail-open ───────────────────────────────────────

describe('fail-open sur stdin invalide', () => {
  test('stdin vide → exit 0, fail-open (injecte par défaut)', () => {
    const r = runHook(null)
    assert.equal(r.exitCode, 0)
    assert.equal(r.injected, true)
  })

  test('JSON invalide → exit 0, fail-open (injecte par défaut)', () => {
    const r = runHook('{ not valid json ::: ')
    assert.equal(r.exitCode, 0)
    assert.equal(r.injected, true)
  })

  test('stdin non-objet (ex. tableau JSON) → exit 0, ne crash pas', () => {
    const r = runHook('[1, 2, 3]')
    assert.equal(r.exitCode, 0)
    assert.equal(r.stderr, '')
  })
})

// ─── contrat de sortie ──────────────────────────────────────────────────────

describe('contrat de sortie SubagentStart', () => {
  test('injection émet hookSpecificOutput.hookEventName = SubagentStart', () => {
    const r = runHook({ agent_type: 'agent-dynamique-quelconque' })
    const parsed = JSON.parse(r.stdout)
    assert.equal(parsed.hookSpecificOutput.hookEventName, 'SubagentStart')
    assert.ok(typeof parsed.hookSpecificOutput.additionalContext === 'string')
  })

  test('skip (denylist) → aucune sortie stdout exploitable', () => {
    const r = runHook({ agent_type: 'reviewer' })
    assert.equal(r.stdout.trim(), '')
  })
})
