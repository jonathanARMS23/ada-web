#!/usr/bin/env node
'use strict'
const { test, describe, before, after } = require('node:test')
const assert = require('node:assert/strict')
const { mkdirSync, rmSync, existsSync, readFileSync } = require('fs')
const { join } = require('path')

const TMP          = join(__dirname, '../../..', '.test-tmp-post-bash')
const POST_BASH_JS = join(__dirname, '../../hooks/post-bash.js')

let detectEvent, handleGitCommit, handleTestResults, handleDbMigration

before(() => {
  mkdirSync(TMP, { recursive: true })
  // Définir PROJECT_DIR avant le require pour que le module l'utilise
  process.env.CLAUDE_CONFIG_DIR = TMP
  process.env.AI_DEV_PROJECT    = 'test-project'
  // Charger après avoir positionné les env vars
  const mod = require(POST_BASH_JS)
  detectEvent        = mod.detectEvent
  handleGitCommit    = mod.handleGitCommit
  handleTestResults  = mod.handleTestResults
  handleDbMigration  = mod.handleDbMigration
})

after(() => {
  delete process.env.CLAUDE_CONFIG_DIR
  delete process.env.AI_DEV_PROJECT
  try { rmSync(TMP, { recursive: true }) } catch {}
})

// ─── detectEvent ─────────────────────────────────────────────────────────────

describe('detectEvent', () => {
  test('détecte git commit avec sha et message', () => {
    const e = detectEvent(
      'git commit -m "feat: add user auth"',
      '[main abc1234] feat: add user auth'
    )
    assert.ok(e, 'event attendu non null')
    assert.equal(e.type, 'git-commit')
    assert.ok(e.sha, `sha manquant — event: ${JSON.stringify(e)}`)
    assert.ok(e.msg.includes('add user auth'), `msg inattendu: ${e.msg}`)
  })

  test('détecte git push avec branch', () => {
    const e = detectEvent('git push origin feature/my-branch', '')
    assert.ok(e)
    assert.equal(e.type, 'git-push')
    assert.equal(e.branch, 'feature/my-branch')
  })

  test('détecte test jest — passed/failed', () => {
    const output = 'Tests: 12 tests passed, 2 tests failed'
    const e = detectEvent('jest --ci', output)
    assert.ok(e)
    assert.equal(e.type, 'test-js')
    assert.equal(e.passed, 12)
    assert.equal(e.failed, 2)
  })

  test('détecte pytest — passed/failed/errors', () => {
    const output = '5 passed, 1 failed, 2 errors in 0.42s'
    const e = detectEvent('pytest tests/', output)
    assert.ok(e)
    assert.equal(e.type, 'test-py')
    assert.equal(e.passed, 5)
    assert.equal(e.failed, 1)
    assert.equal(e.errors, 2)
  })

  test('détecte npm install → dep-install', () => {
    const e = detectEvent('npm install express', '')
    assert.ok(e)
    assert.equal(e.type, 'dep-install')
  })

  test('retourne null pour une commande non reconnue', () => {
    const e = detectEvent('ls -la', '')
    assert.equal(e, null)
  })

  test('détecte docker build success', () => {
    const output = 'Successfully built abc123\nSuccessfully tagged myapp:latest'
    const e = detectEvent('docker build -t myapp .', output)
    assert.ok(e)
    assert.equal(e.type, 'docker-build')
    assert.equal(e.success, true)
  })

  test('détecte prisma migrate', () => {
    const e = detectEvent('npx prisma migrate deploy', '')
    assert.ok(e)
    assert.equal(e.type, 'db-migration')
  })
})

// ─── handleTestResults ────────────────────────────────────────────────────────

describe('handleTestResults', () => {
  const projectDir = () => join(TMP, 'memory', 'projects', 'test-project')
  const logFile    = () => join(projectDir(), 'test-results.log')

  before(() => {
    mkdirSync(projectDir(), { recursive: true })
  })

  test('crée le fichier test-results.log avec status PASS', () => {
    handleTestResults({ type: 'test-js', passed: 10, failed: 0, coverage: null, errors: 0 })
    assert.ok(existsSync(logFile()), 'test-results.log non créé')
    const content = readFileSync(logFile(), 'utf8')
    assert.ok(content.includes('[PASS]'), `status PASS manquant — got: ${content}`)
    assert.ok(content.includes('10 passed'), `count 10 passed manquant — got: ${content}`)
  })

  test('crée le fichier test-results.log avec status FAIL si failed > 0', () => {
    handleTestResults({ type: 'test-js', passed: 5, failed: 3, coverage: null, errors: 0 })
    const content = readFileSync(logFile(), 'utf8')
    assert.ok(content.includes('[FAIL]'), `status FAIL manquant — got: ${content}`)
    assert.ok(content.includes('3 failed'), `count 3 failed manquant — got: ${content}`)
  })

  test('ajoute coverage dans la ligne si présente', () => {
    handleTestResults({ type: 'test-js', passed: 8, failed: 0, coverage: '87.5', errors: 0 })
    const content = readFileSync(logFile(), 'utf8')
    assert.ok(content.includes('87.5%'), `coverage manquant — got: ${content}`)
  })
})
