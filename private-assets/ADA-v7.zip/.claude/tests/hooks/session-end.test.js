#!/usr/bin/env node
'use strict'
/**
 * tests/hooks/session-end.test.js
 * Tests unitaires pour updateCacheTimestamp et checkCacheExpiry
 */
const { test, describe, before, after, beforeEach } = require('node:test')
const assert = require('node:assert/strict')
const { mkdirSync, rmSync, existsSync, readFileSync, writeFileSync } = require('fs')
const { join } = require('path')

const TMP            = join(__dirname, '../../..', '.test-tmp-session-end')
const SESSION_END_JS = join(__dirname, '../../hooks/session-end.js')

let updateCacheTimestamp, checkCacheExpiry, CACHE_TTL_MS, CACHE_KEEPALIVE_FILE

before(() => {
  mkdirSync(join(TMP, 'logs'), { recursive: true })
  process.env.CLAUDE_CONFIG_DIR = TMP
  process.env.AI_DEV_PROJECT    = 'test-project'
  const mod = require(SESSION_END_JS)
  updateCacheTimestamp = mod.updateCacheTimestamp
  checkCacheExpiry     = mod.checkCacheExpiry
  CACHE_TTL_MS         = mod.CACHE_TTL_MS
  CACHE_KEEPALIVE_FILE = mod.CACHE_KEEPALIVE_FILE
})

after(() => {
  delete process.env.CLAUDE_CONFIG_DIR
  delete process.env.AI_DEV_PROJECT
  try { rmSync(TMP, { recursive: true }) } catch {}
})

beforeEach(() => {
  // Nettoyer le fichier keepalive entre chaque test
  try { rmSync(CACHE_KEEPALIVE_FILE) } catch {}
})

// ─── Constantes ───────────────────────────────────────────────────────────────

describe('CACHE_TTL_MS', () => {
  test('vaut 270 000 ms (270s < 300s TTL Anthropic)', () => {
    assert.strictEqual(CACHE_TTL_MS, 270_000)
  })
})

// ─── updateCacheTimestamp ─────────────────────────────────────────────────────

describe('updateCacheTimestamp', () => {
  test('crée le fichier cache-keepalive.json avec ts et responseCount', () => {
    const before = Date.now()
    updateCacheTimestamp(42)
    const after = Date.now()

    assert.ok(existsSync(CACHE_KEEPALIVE_FILE), 'fichier créé')
    const data = JSON.parse(readFileSync(CACHE_KEEPALIVE_FILE, 'utf8'))
    assert.ok(typeof data.ts === 'number', 'ts est un number')
    assert.ok(data.ts >= before && data.ts <= after, 'ts dans la plage [before, after]')
    assert.strictEqual(data.responseCount, 42)
  })

  test('écrase le fichier si appelé plusieurs fois', () => {
    updateCacheTimestamp(1)
    updateCacheTimestamp(99)
    const data = JSON.parse(readFileSync(CACHE_KEEPALIVE_FILE, 'utf8'))
    assert.strictEqual(data.responseCount, 99)
  })

  test('JSON valide (parseable sans erreur)', () => {
    updateCacheTimestamp(7)
    assert.doesNotThrow(() => {
      JSON.parse(readFileSync(CACHE_KEEPALIVE_FILE, 'utf8'))
    })
  })

  test('ne crash pas si le répertoire logs existe déjà', () => {
    assert.doesNotThrow(() => {
      updateCacheTimestamp(1)
      updateCacheTimestamp(2)
    })
  })
})

// ─── checkCacheExpiry ─────────────────────────────────────────────────────────

describe('checkCacheExpiry', () => {
  test('retourne false si fichier absent (pas de crash)', () => {
    // fichier supprimé par beforeEach
    assert.strictEqual(checkCacheExpiry(), false)
  })

  test('retourne false si gap < 270s', () => {
    // ts = maintenant → gap ≈ 0
    updateCacheTimestamp(1)
    assert.strictEqual(checkCacheExpiry(), false)
  })

  test('retourne false si gap = 0ms (juste écrit)', () => {
    writeFileSync(CACHE_KEEPALIVE_FILE, JSON.stringify({ ts: Date.now(), responseCount: 1 }))
    assert.strictEqual(checkCacheExpiry(), false)
  })

  test('retourne true si gap > 270s (ts artificiel dans le passé)', () => {
    const oldTs = Date.now() - 271_000  // 271s dans le passé
    writeFileSync(CACHE_KEEPALIVE_FILE, JSON.stringify({ ts: oldTs, responseCount: 1 }))
    assert.strictEqual(checkCacheExpiry(), true)
  })

  test('retourne true si gap exactement > CACHE_TTL_MS', () => {
    const oldTs = Date.now() - (CACHE_TTL_MS + 1)
    writeFileSync(CACHE_KEEPALIVE_FILE, JSON.stringify({ ts: oldTs, responseCount: 5 }))
    assert.strictEqual(checkCacheExpiry(), true)
  })

  test('retourne false si gap exactement < CACHE_TTL_MS', () => {
    const recentTs = Date.now() - (CACHE_TTL_MS - 1000)  // 1s avant expiry
    writeFileSync(CACHE_KEEPALIVE_FILE, JSON.stringify({ ts: recentTs, responseCount: 3 }))
    assert.strictEqual(checkCacheExpiry(), false)
  })

  test('retourne false si JSON malformé (pas de crash)', () => {
    writeFileSync(CACHE_KEEPALIVE_FILE, 'INVALID JSON {{{')
    assert.strictEqual(checkCacheExpiry(), false)
  })

  test('retourne false si ts absent du JSON', () => {
    writeFileSync(CACHE_KEEPALIVE_FILE, JSON.stringify({ responseCount: 1 }))
    assert.strictEqual(checkCacheExpiry(), false)
  })

  test('retourne false si ts est null', () => {
    writeFileSync(CACHE_KEEPALIVE_FILE, JSON.stringify({ ts: null, responseCount: 1 }))
    assert.strictEqual(checkCacheExpiry(), false)
  })

  test('retourne false si ts est une string non-numérique', () => {
    writeFileSync(CACHE_KEEPALIVE_FILE, JSON.stringify({ ts: 'not-a-number', responseCount: 1 }))
    assert.strictEqual(checkCacheExpiry(), false)
  })
})
