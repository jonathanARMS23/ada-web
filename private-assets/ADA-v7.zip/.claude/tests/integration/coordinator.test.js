#!/usr/bin/env node
'use strict'
/**
 * tests/integration/coordinator.test.js
 *
 * Tests d'intégration run.js + router.js + bank.js dans un TMP dir isolé.
 * Aucune dépendance sur l'état du système.
 */

const { describe, test, before, after } = require('node:test')
const assert = require('node:assert/strict')
const { mkdtempSync, rmSync, mkdirSync, writeFileSync, readFileSync, existsSync } = require('fs')
const { join } = require('path')
const { tmpdir } = require('os')
const { spawnSync } = require('child_process')

const TMP = mkdtempSync(join(tmpdir(), 'ai-dev-integration-'))
const CLAUDE_DIR = join(TMP, '.claude')

before(() => {
  mkdirSync(join(CLAUDE_DIR, 'coordinator'), { recursive: true })
  mkdirSync(join(CLAUDE_DIR, 'runs'), { recursive: true })
  const srcPipelines = join(__dirname, '../../coordinator/pipelines.json')
  writeFileSync(
    join(CLAUDE_DIR, 'coordinator', 'pipelines.json'),
    readFileSync(srcPipelines, 'utf8')
  )
})

after(() => rmSync(TMP, { recursive: true, force: true }))

// ── Helpers ───────────────────────────────────────────────────────────────────

function runCmd(args, env = {}) {
  const runJs = join(__dirname, '../../coordinator/run.js')
  return spawnSync('node', [runJs, ...args], {
    encoding: 'utf8',
    env: { ...process.env, CLAUDE_CONFIG_DIR: CLAUDE_DIR, ...env }
  })
}

/** Parse la sortie JSON de `next --json` → tableau [{id, agent}] */
function parseNextJson(stdout) {
  try {
    const parsed = JSON.parse(stdout.trim())
    if (parsed && Array.isArray(parsed.ready)) {
      return parsed.ready.map(p => ({ id: p.phaseId, agent: p.agent, ...p }))
    }
  } catch {}
  return null
}

// ── Suite run.js — pipeline feature complet ───────────────────────────────────

describe('Intégration run.js — pipeline feature complet', () => {
  let runId

  test('init crée un run avec toutes les phases pending', () => {
    const r = runCmd(['init', 'feature', 'user-auth'])
    assert.strictEqual(r.status, 0, `init failed:\nSTDOUT: ${r.stdout}\nSTDERR: ${r.stderr}`)

    // Le runId est de la forme: feature-user-auth-YYYYMMDD-HHmm
    const match = r.stdout.match(/feature-user-auth-\d{8}-\d{4}/)
    assert.ok(match, `runId introuvable dans stdout:\n${r.stdout}`)
    runId = match[0]

    // Le fichier state.json doit exister
    const statePath = join(CLAUDE_DIR, 'runs', runId, 'state.json')
    assert.ok(existsSync(statePath), `state.json absent : ${statePath}`)

    // Toutes les phases de base sont initialisées
    const state = JSON.parse(readFileSync(statePath, 'utf8'))
    assert.ok(state.phases.schema, 'phase schema manquante')
    assert.ok(state.phases.specs,  'phase specs manquante')
    assert.ok(state.phases.backend, 'phase backend manquante')
  })

  test('next retourne la première phase prête (schema)', () => {
    const r = runCmd(['next', runId, '--json'])
    assert.strictEqual(r.status, 0, `next failed: ${r.stderr}`)
    const phases = parseNextJson(r.stdout)
    assert.ok(phases, `JSON attendu dans stdout:\n${r.stdout}`)
    assert.ok(phases.length > 0, 'aucune phase ready')
    assert.strictEqual(phases[0].id, 'schema')
  })

  test('start → done → next enchaîne correctement les phases', () => {
    // start schema
    let r = runCmd(['start', runId, 'schema'])
    assert.strictEqual(r.status, 0, `start schema failed: ${r.stderr}`)

    // done schema
    r = runCmd(['done', runId, 'schema', 'migration users créée'])
    assert.strictEqual(r.status, 0, `done schema failed: ${r.stderr}`)

    // next doit retourner specs
    r = runCmd(['next', runId, '--json'])
    assert.strictEqual(r.status, 0)
    const phases = parseNextJson(r.stdout)
    assert.ok(phases, `JSON attendu dans stdout:\n${r.stdout}`)
    assert.strictEqual(phases[0].id, 'specs')
  })

  test('fail avec --retry met la phase en retrying (relançable via start)', () => {
    // start specs
    runCmd(['start', runId, 'specs'])

    // fail avec --retry → phase passe en 'retrying'
    const r = runCmd(['fail', runId, 'specs', 'timeout ollama', '--retry'])
    assert.strictEqual(r.status, 0, `fail --retry failed: ${r.stderr}`)

    // Vérifier directement dans state.json que la phase est 'retrying'
    const statePath = join(CLAUDE_DIR, 'runs', runId, 'state.json')
    const state = JSON.parse(readFileSync(statePath, 'utf8'))
    assert.strictEqual(
      state.phases.specs.status,
      'retrying',
      `statut attendu: retrying, obtenu: ${state.phases.specs.status}`
    )
    assert.ok(state.phases.specs.retries > 0, 'compteur retry doit être > 0')

    // La phase peut être relancée directement via start (status retrying est accepté)
    const restart = runCmd(['start', runId, 'specs'])
    assert.strictEqual(restart.status, 0, `re-start specs failed: ${restart.stderr}`)
  })

  test('skip frontend avec raison avance correctement', () => {
    // Compléter specs et backend d'abord
    runCmd(['done', runId, 'specs', 'specs ok'])
    runCmd(['start', runId, 'backend'])
    runCmd(['done', runId, 'backend', 'api ok'])

    // skip frontend
    const r = runCmd(['skip', runId, 'frontend', 'api-only'])
    assert.strictEqual(r.status, 0, `skip frontend failed: ${r.stderr}`)

    // Vérifier le statut dans state.json
    const statePath = join(CLAUDE_DIR, 'runs', runId, 'state.json')
    const state = JSON.parse(readFileSync(statePath, 'utf8'))
    assert.strictEqual(state.phases.frontend.status, 'skipped')
  })

  test('status affiche le run avec le runId', () => {
    const r = runCmd(['status', runId])
    assert.strictEqual(r.status, 0, `status failed: ${r.stderr}`)
    assert.ok(r.stdout.includes(runId), `runId ${runId} absent du stdout:\n${r.stdout}`)
  })
})

// ── Suite router.js — recommend + update ─────────────────────────────────────

describe('Intégration router.js — recommend + update', () => {
  const routerJs = join(__dirname, '../../coordinator/router.js')
  const env = { ...process.env, CLAUDE_CONFIG_DIR: CLAUDE_DIR }

  function routerCmd(args) {
    return spawnSync('node', [routerJs, ...args], { encoding: 'utf8', env })
  }

  test('recommend backend retourne un agent valide', () => {
    const r = routerCmd(['recommend', 'backend'])
    assert.strictEqual(r.status, 0, `recommend failed: ${r.stderr}`)
    const lastLine = r.stdout.trim().split('\n').pop()
    assert.ok(
      ['nestjs', 'drf'].includes(lastLine),
      `Agent inattendu: "${lastLine}"\nSTDOUT: ${r.stdout}`
    )
  })

  test('update + recommend adapte la recommandation', () => {
    // Enregistrer 5 succès pour drf
    for (let i = 0; i < 5; i++) {
      const r = routerCmd(['update', 'backend', 'drf', 'success'])
      assert.strictEqual(r.status, 0, `update ${i} failed: ${r.stderr}`)
    }
    const r = routerCmd(['recommend', 'backend'])
    assert.strictEqual(r.status, 0, `recommend failed: ${r.stderr}`)
    const lastLine = r.stdout.trim().split('\n').pop()
    // Avec 5 succès pour drf, l'agent retourné doit être valide (nestjs ou drf)
    assert.ok(
      ['nestjs', 'drf'].includes(lastLine),
      `Agent inattendu après 5 succès drf: "${lastLine}"`
    )
  })

  test('stats affiche les priors mis à jour avec drf', () => {
    const r = routerCmd(['stats'])
    assert.strictEqual(r.status, 0, `stats failed: ${r.stderr}`)
    assert.ok(r.stdout.includes('drf'), `"drf" absent des stats:\n${r.stdout}`)
  })
})
