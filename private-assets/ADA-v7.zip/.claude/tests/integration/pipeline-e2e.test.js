'use strict'
/**
 * tests/integration/pipeline-e2e.test.js
 * Test E2E complet du pipeline feature + hotfix via coordinator/run.js
 */

const { describe, test, before, after } = require('node:test')
const assert = require('node:assert/strict')
const { mkdtempSync, rmSync, mkdirSync, writeFileSync, readFileSync, existsSync } = require('fs')
const { join } = require('path')
const { tmpdir } = require('os')
const { spawnSync } = require('child_process')

const TMP       = mkdtempSync(join(tmpdir(), 'ai-dev-e2e-'))
const CLAUDE_DIR = join(TMP, '.claude')
const runJs     = join(__dirname, '../../coordinator/run.js')

before(() => {
  mkdirSync(join(CLAUDE_DIR, 'coordinator'), { recursive: true })
  mkdirSync(join(CLAUDE_DIR, 'runs'), { recursive: true })
  const src = join(__dirname, '../../coordinator/pipelines.json')
  writeFileSync(
    join(CLAUDE_DIR, 'coordinator', 'pipelines.json'),
    readFileSync(src, 'utf8')
  )
})

after(() => rmSync(TMP, { recursive: true, force: true }))

function run(args) {
  return spawnSync('node', [runJs, ...args], {
    encoding: 'utf8',
    timeout: 15000,
    env: { ...process.env, CLAUDE_CONFIG_DIR: CLAUDE_DIR }
  })
}

// ── Pipeline feature — E2E complet ────────────────────────────────────────────

describe('Pipeline feature — E2E complet', () => {
  let runId

  test('init pipeline feature', () => {
    const r = run(['init', 'feature', 'payment-integration'])
    assert.strictEqual(r.status, 0, `init failed: ${r.stderr}`)
    const match = r.stdout.match(/feature-payment-integration-[\d-]+/)
    assert.ok(match, `runId non trouvé dans: ${r.stdout}`)
    runId = match[0]
  })

  // Phases séquentielles du pipeline feature (skip frontend et deploy via flags d'init)
  // Note: le pipeline feature inclut schema→specs→backend→frontend→coverage→review→deploy
  // On utilise --api-only (skip frontend) et --no-deploy (skip deploy) à l'init
  test('init pipeline feature avec --api-only --no-deploy', () => {
    const r = run(['init', 'feature', 'payment-integration-v2', '--api-only', '--no-deploy'])
    assert.strictEqual(r.status, 0, `init failed: ${r.stderr}`)
    const match = r.stdout.match(/feature-payment-integration-v2-[\d-]+/)
    assert.ok(match, `runId non trouvé dans: ${r.stdout}`)
    runId = match[0]
  })

  const phases = [
    ['schema',   'db',       'Table payments créée'],
    ['specs',    'tester',   '12 specs TDD écrites'],
    ['backend',  'nestjs',   'PaymentsModule complet'],
    ['coverage', 'tester',   '94% coverage'],
    ['review',   'reviewer', 'Aucun problème critique'],
  ]

  for (const [phaseId, , summary] of phases) {
    test(`phase ${phaseId} : start → done`, () => {
      // Vérifier que la phase est prête
      const nextR = run(['next', runId])
      assert.strictEqual(nextR.status, 0, `next failed: ${nextR.stderr}`)

      // start
      const startR = run(['start', runId, phaseId])
      assert.strictEqual(startR.status, 0, `start ${phaseId} failed: ${startR.stderr}`)

      // done
      const doneR = run(['done', runId, phaseId, summary])
      assert.strictEqual(doneR.status, 0, `done ${phaseId} failed: ${doneR.stderr}`)
    })
  }

  test('run terminé après toutes les phases (frontend + deploy skippés)', () => {
    const stateFile = join(CLAUDE_DIR, 'runs', runId, 'state.json')
    assert.ok(existsSync(stateFile), `state.json introuvable pour ${runId}`)
    const state = JSON.parse(readFileSync(stateFile, 'utf8'))
    assert.ok(
      ['completed', 'completed_with_errors'].includes(state.status),
      `Status inattendu: ${state.status}`
    )
  })

  test('list affiche le run', () => {
    const r = run(['list'])
    assert.strictEqual(r.status, 0)
    assert.ok(r.stdout.includes(runId), `runId ${runId} absent de la liste`)
  })
})

// ── Pipeline hotfix — E2E ─────────────────────────────────────────────────────

describe('Pipeline hotfix — E2E', () => {
  let runId

  test('init hotfix', () => {
    const r = run(['init', 'hotfix', 'critical-auth-bypass', '--no-deploy'])
    assert.strictEqual(r.status, 0, `init hotfix failed: ${r.stderr}`)
    const match = r.stdout.match(/hotfix-critical-auth-bypass-[\d-]+/)
    assert.ok(match, `runId non trouvé dans: ${r.stdout}`)
    runId = match[0]
  })

  test('phase diagnose → start → done', () => {
    const startR = run(['start', runId, 'diagnose'])
    assert.strictEqual(startR.status, 0, `start diagnose failed: ${startR.stderr}`)

    const doneR = run(['done', runId, 'diagnose', 'JWT validation absente sur /admin'])
    assert.strictEqual(doneR.status, 0, `done diagnose failed: ${doneR.stderr}`)
  })

  test('rollback diagnose remet en pending', () => {
    const r = run(['rollback', runId, 'diagnose'])
    assert.strictEqual(r.status, 0, `rollback failed: ${r.stderr}`)

    const stateFile = join(CLAUDE_DIR, 'runs', runId, 'state.json')
    const state = JSON.parse(readFileSync(stateFile, 'utf8'))
    assert.strictEqual(
      state.phases.diagnose.status,
      'pending',
      `diagnose.status=${state.phases.diagnose.status} après rollback, attendu: pending`
    )
  })
})
