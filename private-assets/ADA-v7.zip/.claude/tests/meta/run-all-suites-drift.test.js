#!/usr/bin/env node
'use strict'
/**
 * tests/meta/run-all-suites-drift.test.js — Garde anti-dérive de la liste SUITES
 *
 * Finding F5 de l'audit (docs/AUDIT-ADA-2026-09-09.md) : la constante SUITES de
 * .claude/tests/run-all.js est une liste STATIQUE de fichiers de test à exécuter.
 * Elle avait dérivé du contenu réel du repo : au 2026-09-09, 75 fichiers *.test.js
 * existaient sous .claude/tests/ mais SUITES n'en référençait que 62 — 13 fichiers,
 * dont tests/coordinator/budget-guard.test.js (le test du finding F1), ne sont
 * JAMAIS exécutés par `node run-all.js`, donc jamais par la CI qui s'appuie dessus.
 *
 * CE TEST (tâche F5a-1, garde de non-régression) :
 *   - énumère lui-même les *.test.js réellement présents sous .claude/tests/
 *     (à l'exclusion des git worktrees, voir plus bas) et les compare à SUITES,
 *     parsée depuis le SOURCE de run-all.js (le require() direct exécuterait
 *     toute la suite + process.exit(), inutilisable ici) ;
 *   - est maintenant VERT (F5a-2 a corrigé la dérive dans SUITES) — passe la
 *     suite complète en CI et garde contre une future dérive ;
 *   - le test reste utile comme garde anti-régression même si la dérive initiale
 *     est corrigée.
 *
 * Exclusion appliquée : .claude/worktrees/** est un git worktree RÉEL (checkout
 * d'une autre branche — cf. `git worktree list`), pas du code de la branche
 * courante ; il est donc hors périmètre de run-all.js et exclu du scan.
 * Ce n'est PAS un mécanisme d'exclusion de fichiers de test métier : il n'existe
 * AUCUN mécanisme d'exclusion (allowlist/denylist) documenté ou codé dans
 * run-all.js pour omettre volontairement un test.
 */

const { test } = require('node:test')
const assert = require('node:assert/strict')
const { readFileSync, readdirSync, statSync } = require('node:fs')
const { join, relative, sep } = require('node:path')

const ROOT     = join(__dirname, '..', '..')   // .claude/ (même base que les `file:` de SUITES)
const RUN_ALL  = join(ROOT, 'tests', 'run-all.js')
const TESTS_DIR = join(ROOT, 'tests')

/**
 * Parse la constante SUITES depuis le texte source de run-all.js (regex sur
 * `file: '...'`), sans faire require(run-all.js) — ce module n'exporte rien,
 * il lance immédiatement toute la suite de tests et appelle process.exit().
 */
function parseSuiteFiles() {
  const src = readFileSync(RUN_ALL, 'utf8')
  const matches = [...src.matchAll(/file:\s*'([^']+)'/g)]
  assert.ok(
    matches.length > 0,
    'parsing de SUITES dans run-all.js a échoué (0 entrée trouvée) — le format a-t-il changé ?'
  )
  return matches.map(m => m[1]) // ex: 'tests/coordinator/bank.test.js'
}

/**
 * Énumère récursivement les *.test.js sous .claude/tests/, en chemins
 * relatifs à .claude/ (même base que les entrées `file:` de SUITES), en
 * excluant les git worktrees (checkouts d'autres branches).
 */
function walkTestFiles(dir) {
  let out = []
  for (const entry of readdirSync(dir)) {
    const abs = join(dir, entry)
    const st = statSync(abs)
    if (st.isDirectory()) {
      if (entry === 'worktrees') continue
      out = out.concat(walkTestFiles(abs))
    } else if (entry.endsWith('.test.js')) {
      out.push(relative(ROOT, abs).split(sep).join('/'))
    }
  }
  return out
}

test('SUITES (run-all.js) ne doit pas avoir dérivé des *.test.js réellement présents', () => {
  const declared = new Set(parseSuiteFiles())
  const actual = [...walkTestFiles(TESTS_DIR), ...walkTestFiles(join(ROOT, 'coordinator', 'tests'))]

  const missing = actual.filter(f => !declared.has(f)).sort()

  if (missing.length > 0) {
    assert.fail(
      `${missing.length} fichier(s) de test présent(s) sous .claude/tests/ mais ABSENT(S) de SUITES ` +
      `dans run-all.js — donc jamais exécutés par run-all.js ni par la CI qui s'appuie dessus :\n` +
      missing.map(f => `  - ${f}`).join('\n') +
      `\n\nAjouter chaque entrée manquante à SUITES.`
    )
  }
})

test('SUITES ne référence aucun fichier de test inexistant sur disque (entrées mortes)', () => {
  const declared = parseSuiteFiles()
  const stale = declared.filter(f => {
    try {
      statSync(join(ROOT, f))
      return false
    } catch {
      return true
    }
  })
  assert.deepEqual(
    stale, [],
    `entrée(s) SUITES pointant vers un fichier inexistant sur disque : ${stale.join(', ')}`
  )
})
