#!/usr/bin/env node
'use strict'
/**
 * run-all.js — Lance toute la suite de tests et affiche un rapport final.
 *
 * Usage :
 *   node .claude/tests/run-all.js           # tous les tests
 *   node .claude/tests/run-all.js --verbose  # avec stdout détaillé
 */

const { execSync, spawnSync } = require('child_process')
const { join } = require('path')
const { existsSync } = require('fs')

const ROOT = join(__dirname, '..')

const SUITES = [
  { name: 'coordinator/bank',       file: 'tests/coordinator/bank.test.js' },
  { name: 'coordinator/router',     file: 'tests/coordinator/router.test.js' },
  { name: 'coordinator/run',        file: 'tests/coordinator/run.test.js' },
  { name: 'hooks/pre-bash',         file: 'tests/hooks/pre-bash.test.js' },
  { name: 'hooks/pre-tool-validator', file: 'tests/hooks/pre-tool-validator.test.js' },
  { name: 'hooks/shell-lexer',      file: 'tests/hooks/shell-lexer.test.js' },
  { name: 'hooks/memory-manager',   file: 'tests/hooks/memory-manager.test.js' },
  { name: 'hooks/session-end',      file: 'tests/hooks/session-end.test.js' },
  { name: 'workers/audit',          file: 'tests/workers/audit.test.js' },
  { name: 'workers/daemon',         file: 'tests/workers/daemon.test.js' },
  { name: 'workers/testgaps',       file: 'tests/workers/testgaps.test.js' },
  { name: 'workers/metrics',        file: 'tests/workers/metrics.test.js' },
  { name: 'workers/cve-scan',       file: 'tests/workers/cve-scan.test.js' },
  { name: 'hooks/post-bash',         file: 'tests/hooks/post-bash.test.js' },
  { name: 'coordinator/embeddings',  file: 'tests/coordinator/embeddings.test.js' },
  { name: 'integration/coordinator', file: 'tests/integration/coordinator.test.js' },
  { name: 'coordinator/plugin-sdk',  file: 'tests/coordinator/plugin-sdk.test.js' },
  { name: 'coordinator/safe-executor',  file: 'tests/coordinator/safe-executor.test.js' },
  { name: 'coordinator/path-validator', file: 'tests/coordinator/path-validator.test.js' },
  { name: 'integration/pipeline-e2e', file: 'tests/integration/pipeline-e2e.test.js' },
  { name: 'workers/dashboard',        file: 'tests/workers/dashboard.test.js' },
  { name: 'workers/plugins',          file: 'tests/workers/plugins.test.js' },
  { name: 'workers/logs',             file: 'tests/workers/logs.test.js' },
  { name: 'workers/cost-report',          file: 'tests/workers/cost-report.test.js' },
  { name: 'coordinator/agent-booster',   file: 'tests/coordinator/agent-booster.test.js' },
  { name: 'coordinator/bank-stream',     file: 'tests/coordinator/bank-stream.test.js' },
  { name: 'coordinator/bank-recall',     file: 'tests/coordinator/bank-recall.test.js' },
  { name: 'coordinator/bank-recall-bench', file: 'tests/coordinator/bank-recall-bench.test.js' },
  { name: 'coordinator/injection-gate',  file: 'tests/coordinator/injection-gate.test.js' },
  { name: 'scripts/seed-from-git',       file: 'tests/scripts/seed-from-git.test.js' },
  { name: 'coordinator/smart-retrieve',  file: 'tests/coordinator/smart-retrieve.test.js' },
  { name: 'workers/plugins-ed25519',     file: 'tests/workers/plugins-ed25519.test.js' },
  { name: 'coordinator/ewc',             file: 'tests/coordinator/ewc.test.js' },
  { name: 'coordinator/graph-memory',    file: 'tests/coordinator/graph-memory.test.js' },
  { name: 'coordinator/vault',           file: 'tests/coordinator/vault.test.js' },
  { name: 'coordinator/control-server',  file: 'tests/coordinator/control-server.test.js' },
  { name: 'coordinator/conventions',     file: 'tests/coordinator/conventions.test.js' },
  { name: 'coordinator/task-classifier', file: 'tests/coordinator/task-classifier.test.js' },
  { name: 'coordinator/codemod',         file: 'tests/coordinator/codemod.test.js' },
  { name: 'coordinator/run-mode',        file: 'tests/coordinator/run-mode.test.js' },
  { name: 'coordinator/codemod-wiring',  file: 'tests/coordinator/codemod-wiring.test.js' },
  { name: 'coordinator/skill-registry',  file: 'tests/coordinator/skill-registry.test.js' },
  { name: 'coordinator/benchmark',        file: 'tests/coordinator/benchmark.test.js' },
  { name: 'coordinator/token-window',     file: 'tests/coordinator/token-window.test.js' },
  { name: 'coordinator/bench-v2',         file: 'tests/coordinator/bench-v2.test.js' },
  { name: 'coordinator/bench-v2-ts',      file: 'tests/coordinator/bench-v2-ts.test.js' },
  { name: 'coordinator/bench-v2-infra',   file: 'tests/coordinator/bench-v2-infra.test.js' },
  { name: 'coordinator/mutation-test',    file: 'tests/coordinator/mutation-test.test.js' },
  { name: 'coordinator/calibration-test', file: 'tests/coordinator/calibration-test.test.js' },
  // AI Engineering Loop (RED → GREEN avec l'implémentation)
  { name: 'coordinator/error-context',    file: 'tests/coordinator/error-context.test.js' },
  { name: 'coordinator/run-loop',         file: 'tests/coordinator/run-loop.test.js' },
  { name: 'coordinator/run-telemetry',    file: 'tests/coordinator/run-telemetry.test.js' },
  { name: 'coordinator/team-reap',        file: 'tests/coordinator/team-reap.test.js' },
  { name: 'coordinator/witness',          file: 'tests/coordinator/witness.test.js' },
  // Audit discoverabilité agents + garde never-worse (recall/micro-lessons)
  { name: 'coordinator/agent-audit',      file: 'tests/coordinator/agent-audit.test.js' },
  { name: 'coordinator/never-worse',      file: 'tests/coordinator/never-worse.test.js' },
  // Flywheel — boucle fermée anti-régression du recall (ancres figées + policy fail-closed)
  { name: 'coordinator/flywheel',         file: 'tests/coordinator/flywheel.test.js' },
  // Manifeste de livraison + sync par checksum de l'installeur (ADR-024)
  { name: 'scripts/ada-manifest',         file: 'tests/scripts/ada-manifest.test.js' },
  // Non-régression ranking (2 bugs trouvés/corrigés 2026-08-28 — régression flywheel)
  { name: 'coordinator/bank-ranking',     file: 'tests/coordinator/bank-ranking.test.js' },
  // Audit ROI Tier C (2026-08-28) : ipc-emit.js n'avait aucun test (module de
  // sécurité — signature HMAC + secret fail-closed des events du control plane)
  { name: 'coordinator/ipc-emit',         file: 'tests/coordinator/ipc-emit.test.js' },
  // install.sh --with-ui (opt-in UI, installeur local multi-OS)
  { name: 'scripts/install-sh',           file: 'tests/scripts/install-sh.test.js' },
  // Chantier A — hook SubagentStart anti-sur-construction (adapté de Ponytail, MIT)
  { name: 'hooks/ponytail-subagent',      file: 'tests/hooks/ponytail-subagent.test.js' },
  // F5a-2 — comblement de la dérive SUITES (audit 2026-09-09, finding F5) :
  // ces 14 fichiers existaient sur disque mais n'étaient jamais exécutés.
  { name: 'coordinator/ada-bridge',           file: 'tests/coordinator/ada-bridge.test.js' },
  { name: 'coordinator/budget-guard',         file: 'tests/coordinator/budget-guard.test.js' },
  { name: 'coordinator/context-advisor',      file: 'tests/coordinator/context-advisor.test.js' },
  { name: 'coordinator/diff-reviewer',        file: 'tests/coordinator/diff-reviewer.test.js' },
  { name: 'coordinator/federation',           file: 'tests/coordinator/federation.test.js' },
  { name: 'coordinator/pr-autopilot',         file: 'tests/coordinator/pr-autopilot.test.js' },
  { name: 'coordinator/predictive-estimator', file: 'tests/coordinator/predictive-estimator.test.js' },
  { name: 'coordinator/prompt-cache-optimizer', file: 'tests/coordinator/prompt-cache-optimizer.test.js' },
  { name: 'coordinator/provider-gateway',     file: 'tests/coordinator/provider-gateway.test.js' },
  { name: 'coordinator/schema-validator',     file: 'tests/coordinator/schema-validator.test.js' },
  { name: 'coordinator/team-sync',            file: 'tests/coordinator/team-sync.test.js' },
  { name: 'lib/cache',                        file: 'tests/lib/cache.test.js' },
  { name: 'lib/error-handler',                file: 'tests/lib/error-handler.test.js' },
  { name: 'meta/run-all-suites-drift',        file: 'tests/meta/run-all-suites-drift.test.js' },
  // F2 — hook Stop livré (settings.json source + profil neuf + merge profil existant)
  { name: 'scripts/stop-hook-wiring',     file: 'tests/scripts/stop-hook-wiring.test.js' },
  // F8b — matrice de capacités générée + garde anti-dérive des chiffres du README
  { name: 'scripts/capability-matrix',    file: 'tests/scripts/capability-matrix.test.js' },
  // TÂCHE 6 (2026-09-10) — checkLoopbackPorts() détecte ports non-loopback
  // (guillemets doubles, simples, non-quoted, syntaxe longue)
  { name: 'scripts/smoke-docker-ports',   file: 'tests/scripts/smoke-docker-ports.test.js' },
  // Revue de complétude des tests (2026-09-10) : coordinator/tests/coordinator.test.js
  // vit hors de .claude/tests/ (modifié pour F1b), donc hors du scan de
  // meta/run-all-suites-drift.test.js et jamais exécuté par la CI. Référencé ici
  // directement à son emplacement réel plutôt que déplacé — la suite couvre du
  // contenu non dupliqué ailleurs (MoE, ADR-023 étapes 4/5) et le module résout
  // ses require() via `join(__dirname, '..')`, indépendant de son entrée SUITES.
  { name: 'scripts/launch-terminal', file: 'tests/scripts/launch-terminal.test.js' },
  { name: 'scripts/codex-knowledge-hook', file: 'tests/scripts/codex-knowledge-hook.test.js' },
  { name: 'coordinator/knowledge-facade', file: 'coordinator/tests/knowledge-facade.test.js' },
  { name: 'coordinator/models-tier-baseline', file: 'coordinator/tests/models-tier-baseline.test.js' },
  { name: 'coordinator/engine-registry', file: 'coordinator/tests/engine-registry.test.js' },
  { name: 'coordinator/legacy-suite',     file: 'coordinator/tests/coordinator.test.js' },
  // Revue de complétude des tests (2026-09-10) : la fraîcheur de .ada-manifest.json
  // n'était vérifiée qu'en CI, jamais par run-all.js — distinct de
  // scripts/ada-manifest (logique du générateur sur un dépôt jetable).
  { name: 'scripts/ada-manifest-freshness', file: 'tests/scripts/ada-manifest-freshness.test.js' },
  // `ada engine` — pilotage .ada/engines.yaml (P5/P6, routage claude_code/codex)
  { name: 'coordinator/engine-cli',       file: 'tests/coordinator/engine-cli.test.js' },
]

const VERBOSE  = process.argv.includes('--verbose') || process.argv.includes('-v')
const COVERAGE = process.argv.includes('--coverage')
const PAD      = 30

const results = []
let startAll  = Date.now()

console.log('\n\x1b[1m▶ AI-Dev-Assistant — Test Suite\x1b[0m')
console.log('─'.repeat(60))

for (const suite of SUITES) {
  const filePath = join(ROOT, suite.file)
  if (!existsSync(filePath)) {
    results.push({ name: suite.name, status: 'MISSING', pass: 0, fail: 0, ms: 0 })
    console.log(`  \x1b[33m⚠ MISSING\x1b[0m  ${suite.name}`)
    continue
  }

  const t0 = Date.now()
  const coverageFlag = COVERAGE ? ['--experimental-test-coverage'] : []
  const r = spawnSync('node', [...coverageFlag, '--test', filePath], {
    encoding: 'utf8',
    timeout: 60000,
    env: { ...process.env }
  })
  const ms = Date.now() - t0

  // Extraire pass/fail du output de node:test
  // node:test émet sur stderr: "ℹ pass N" et "ℹ fail N"
  let pass = 0, fail = 0
  const stdout = r.stdout + r.stderr

  // Format node:test (reporter text) : "ℹ pass N" / "ℹ fail N"
  const passSymMatch = stdout.match(/ℹ pass (\d+)/)
  const failSymMatch = stdout.match(/ℹ fail (\d+)/)
  if (passSymMatch) pass = parseInt(passSymMatch[1], 10)
  if (failSymMatch) fail = parseInt(failSymMatch[1], 10)

  // Fallback TAP classique : "# pass N" / "# fail N"
  if (pass === 0 && fail === 0) {
    const passMatch = stdout.match(/# pass (\d+)/)
    const failMatch = stdout.match(/# fail (\d+)/)
    if (passMatch) pass = parseInt(passMatch[1], 10)
    if (failMatch) fail = parseInt(failMatch[1], 10)
  }

  // Fallback TAP "# tests N"
  if (pass === 0 && fail === 0) {
    const testsMatch = stdout.match(/# tests (\d+)/)
    const failMatch2 = stdout.match(/# fail (\d+)/)
    if (testsMatch) {
      fail = failMatch2 ? parseInt(failMatch2[1], 10) : 0
      pass = parseInt(testsMatch[1], 10) - fail
    }
  }

  // Dernier recours: compter les lignes ok / not ok du TAP
  if (pass === 0 && fail === 0) {
    pass = (stdout.match(/^ok /gm) || []).length
    fail = (stdout.match(/^not ok /gm) || []).length
  }

  const ok = r.status === 0 && fail === 0
  const status = ok ? 'PASS' : 'FAIL'
  results.push({ name: suite.name, status, pass, fail, ms })

  const icon  = ok ? '\x1b[32m✓ PASS\x1b[0m' : '\x1b[31m✗ FAIL\x1b[0m'
  const stats = pass + fail > 0 ? ` (${pass}/${pass + fail})` : ''
  console.log(`  ${icon}  ${suite.name.padEnd(PAD)} ${ms}ms${stats}`)

  if (VERBOSE || !ok) {
    const lines = stdout.split('\n').filter(l => l.trim())
    for (const line of lines) {
      if (line.startsWith('not ok') || line.includes('Error') || line.includes('AssertionError')) {
        console.log(`         \x1b[31m${line}\x1b[0m`)
      } else if (VERBOSE) {
        console.log(`         ${line}`)
      }
    }
  }
}

const totalMs   = Date.now() - startAll
const passing   = results.filter(r => r.status === 'PASS').length
const failing   = results.filter(r => r.status === 'FAIL').length
const missing   = results.filter(r => r.status === 'MISSING').length
const totalPass = results.reduce((s, r) => s + r.pass, 0)
const totalFail = results.reduce((s, r) => s + r.fail, 0)

console.log('─'.repeat(60))
console.log(`\n  Suites : ${passing} passed, ${failing} failed, ${missing} missing`)
console.log(`  Tests  : ${totalPass} passed, ${totalFail} failed`)
console.log(`  Time   : ${totalMs}ms`)
console.log(`  Coverage : node tests/run-all.js --coverage\n`)

if (failing > 0 || missing > 0) {
  if (missing > 0) console.log('\x1b[33m  Certains fichiers de test sont manquants.\x1b[0m\n')
  process.exit(1)
} else {
  console.log('\x1b[32m  Tous les tests passent. ✓\x1b[0m\n')
  process.exit(0)
}
