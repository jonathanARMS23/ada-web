#!/usr/bin/env node
'use strict'
/**
 * tests/scripts/ada-manifest-freshness.test.js — garde de fraîcheur du VRAI manifeste
 *
 * Revue de complétude des tests (2026-09-10) : `node .claude/scripts/generate-
 * ada-manifest.js --check` n'était lancé qu'en CI (.github/workflows/ci.yml,
 * job "core"). `node .claude/tests/run-all.js` restait donc vert même quand
 * `.claude/.ada-manifest.json` était périmé — arrivé 3 fois dans la session qui
 * a introduit ce test.
 *
 * Distinct de `tests/scripts/ada-manifest.test.js` (qui teste la LOGIQUE du
 * générateur sur un dépôt jetable sous os.tmpdir()) : ce test-ci lance le
 * générateur en mode --check sur le VRAI dépôt, comme le fait déjà
 * `tests/scripts/capability-matrix.test.js` pour le README.
 */

const { test, describe } = require('node:test')
const assert = require('node:assert/strict')
const { spawnSync } = require('node:child_process')
const { join } = require('node:path')

const REPO_ROOT = join(__dirname, '..', '..', '..')
const GENERATOR = join(REPO_ROOT, '.claude', 'scripts', 'generate-ada-manifest.js')

describe('generate-ada-manifest.js --check sur le vrai dépôt', () => {
  test('.claude/.ada-manifest.json ne doit pas avoir dérivé de l\'état réel du dépôt', () => {
    const r = spawnSync(process.execPath, [GENERATOR, '--check'], { cwd: REPO_ROOT, encoding: 'utf8' })
    if (r.status !== 0) {
      assert.fail(
        `.claude/.ada-manifest.json a dérivé de l'état réel du dépôt :\n${r.stdout}${r.stderr}\n\n` +
        'Corrige avec : node .claude/scripts/generate-ada-manifest.js',
      )
    }
  })
})
