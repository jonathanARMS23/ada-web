#!/usr/bin/env node
'use strict'
/**
 * tests/scripts/ada-manifest.test.js — Manifeste de livraison + sync par checksum
 *
 * Couvre les scripts introduits par ADR-024 :
 *  - scripts/generate-ada-manifest.js  (listTrackedFiles, computeManifest, diff, CLI)
 *  - scripts/manifest-files-for.js     (matchesPrefix, filesFor, CLI)
 *  - scripts/sync-content-dir.js       (planContentSync, planSystemPrune, applyPlan, CLI)
 *
 * Les 4 scénarios de la logique de décision sont testés explicitement, pas
 * seulement le happy path :
 *   1. fichier neuf                → copié
 *   2. fichier non modifié          → mis à jour
 *   3. fichier modifié par le client → JAMAIS écrasé
 *   4. fichier déprécié             → retiré s'il est intact, conservé s'il est modifié
 *
 * Aucun test ne touche un vrai profil (~/.claude*) : tout se passe dans des
 * répertoires jetables sous os.tmpdir() avec des données fictives.
 */

const { test, describe } = require('node:test')
const assert = require('node:assert/strict')
const { join, relative } = require('node:path')
const { tmpdir } = require('node:os')
const {
  mkdtempSync, mkdirSync, writeFileSync, readFileSync, existsSync, statSync, rmSync, readdirSync,
} = require('node:fs')
const { execFileSync } = require('node:child_process')
const { createHash } = require('node:crypto')

const GEN_JS   = join(__dirname, '../../scripts/generate-ada-manifest.js')
const FILES_JS = join(__dirname, '../../scripts/manifest-files-for.js')
const SYNC_JS  = join(__dirname, '../../scripts/sync-content-dir.js')

const gen   = require(GEN_JS)
const files = require(FILES_JS)
const sync  = require(SYNC_JS)

/** Date figée — aucun test ne doit dépendre de l'horloge. */
const FIXED_DATE = '2026-08-10T12:00:00.000Z'

const TMP_ROOTS = []

function tmp(prefix) {
  const d = mkdtempSync(join(tmpdir(), `ada-${prefix}-`))
  TMP_ROOTS.push(d)
  return d
}

function write(root, rel, content) {
  const abs = join(root, rel)
  mkdirSync(join(abs, '..'), { recursive: true })
  writeFileSync(abs, content)
  return abs
}

function h(content) {
  return createHash('sha256').update(content).digest('hex')
}

/**
 * Liste récursive de tous les fichiers sous `dir`, chemins relatifs à `dir`.
 * @param {string} dir
 * @param {string} [base]
 * @returns {string[]}
 */
function walk(dir, base = dir) {
  let out = []
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const abs = join(dir, entry.name)
    if (entry.isDirectory()) out = out.concat(walk(abs, base))
    else out.push(relative(base, abs))
  }
  return out
}

/**
 * Empreinte du contenu ENTIER d'un répertoire (chemin + sha256 de chaque
 * fichier), triée — sert à prouver qu'un run --dry-run n'a RIEN modifié :
 * comparer cette empreinte avant/après doit donner une égalité stricte.
 * @param {string} root
 * @returns {string[]}
 */
function snapshotTree(root) {
  if (!existsSync(root)) return []
  return walk(root)
    .sort()
    .map((rel) => `${rel}:${h(readFileSync(join(root, rel)))}`)
}

process.on('exit', () => {
  for (const d of TMP_ROOTS) {
    try { rmSync(d, { recursive: true, force: true }) } catch { /* best effort */ }
  }
})

// ── generate-ada-manifest.js : listTrackedFiles ────────────────────────────────

describe('listTrackedFiles', () => {
  /** Faux `git ls-files -z` : renvoie une sortie NUL-séparée. */
  const fakeExec = (out) => () => out.join('\0') + '\0'

  test('retire le préfixe .claude/ et trie', () => {
    const res = gen.listTrackedFiles('/repo', {
      exec: fakeExec(['.claude/coordinator/z.js', '.claude/agents/a.md', '.claude/bin/ada.js']),
    })
    assert.deepEqual(res, ['agents/a.md', 'bin/ada.js', 'coordinator/z.js'])
  })

  test('ignore ce qui est hors de .claude/', () => {
    const res = gen.listTrackedFiles('/repo', {
      exec: fakeExec(['.claude/bin/ada.js', 'install.sh', 'docs/adr/ADR-024.md']),
    })
    assert.deepEqual(res, ['bin/ada.js'])
  })

  test('GARDE-FOU : exclut teams/session-*/ même si un jour tracké par erreur', () => {
    const res = gen.listTrackedFiles('/repo', {
      exec: fakeExec([
        '.claude/teams/profiles.json',
        '.claude/teams/routing.md',
        '.claude/teams/session-abc123/state.json',
        '.claude/teams/session-xyz/agents/a.json',
      ]),
    })
    assert.deepEqual(res, ['teams/profiles.json', 'teams/routing.md'])
  })

  test('n exclut pas teams/sessions-archive (pas un dossier de session)', () => {
    const res = gen.listTrackedFiles('/repo', {
      exec: fakeExec(['.claude/teams/sessions-archive/x.json']),
    })
    assert.deepEqual(res, ['teams/sessions-archive/x.json'])
  })

  test('exclut le manifeste lui-même (pas d auto-référence)', () => {
    const res = gen.listTrackedFiles('/repo', {
      exec: fakeExec([
        '.claude/.ada-manifest.json',
        '.claude/.ada-manifest.applied.json',
        '.claude/bin/ada.js',
      ]),
    })
    assert.deepEqual(res, ['bin/ada.js'])
  })

  test('gère un nom de fichier contenant un espace (séparateur NUL)', () => {
    const res = gen.listTrackedFiles('/repo', {
      exec: fakeExec(['.claude/agents/mon agent.md']),
    })
    assert.deepEqual(res, ['agents/mon agent.md'])
  })
})

// ── generate-ada-manifest.js : computeManifest ─────────────────────────────────

describe('computeManifest', () => {
  test('calcule le sha256 de chaque fichier et fige la date fournie', () => {
    const root = tmp('gen')
    write(root, 'VERSION', '9.9.9\n')
    write(root, '.claude/coordinator/a.js', 'contenu A')
    write(root, '.claude/agents/b.md', 'contenu B')

    const { manifest, missing } = gen.computeManifest({
      repoRoot: root,
      date: FIXED_DATE,
      files: ['coordinator/a.js', 'agents/b.md'],
    })

    assert.equal(missing.length, 0)
    assert.equal(manifest.generatedAt, FIXED_DATE)
    assert.equal(manifest.version, '9.9.9')
    assert.equal(manifest.files['coordinator/a.js'], h('contenu A'))
    assert.equal(manifest.files['agents/b.md'], h('contenu B'))
  })

  test('deux appels sur la même source donnent le même manifeste (déterminisme)', () => {
    const root = tmp('gen-det')
    write(root, 'VERSION', '1.0.0')
    write(root, '.claude/x.js', 'x')
    const a = gen.computeManifest({ repoRoot: root, date: FIXED_DATE, files: ['x.js'] })
    const b = gen.computeManifest({ repoRoot: root, date: FIXED_DATE, files: ['x.js'] })
    assert.equal(gen.serializeManifest(a.manifest), gen.serializeManifest(b.manifest))
  })

  test('refuse une date implicite (pas de Date.now() caché)', () => {
    const root = tmp('gen-nodate')
    assert.throws(() => gen.computeManifest({ repoRoot: root }), /date requise/)
  })

  test('remonte les fichiers trackés absents du worktree au lieu de planter', () => {
    const root = tmp('gen-missing')
    write(root, 'VERSION', '1.0.0')
    write(root, '.claude/present.js', 'ok')
    const { manifest, missing } = gen.computeManifest({
      repoRoot: root,
      date: FIXED_DATE,
      files: ['present.js', 'disparu.js'],
    })
    assert.deepEqual(missing, ['disparu.js'])
    assert.deepEqual(Object.keys(manifest.files), ['present.js'])
  })

  test('version = "inconnue" si VERSION absent', () => {
    const root = tmp('gen-nover')
    write(root, '.claude/x.js', 'x')
    const { manifest } = gen.computeManifest({ repoRoot: root, date: FIXED_DATE, files: ['x.js'] })
    assert.equal(manifest.version, 'inconnue')
  })

  test('serializeManifest trie les clés de files', () => {
    const out = gen.serializeManifest({
      generatedAt: FIXED_DATE, version: '1', files: { 'z.js': 'h1', 'a.js': 'h2' },
    })
    assert.deepEqual(Object.keys(JSON.parse(out).files), ['a.js', 'z.js'])
    assert.ok(out.endsWith('\n'))
  })
})

describe('diffManifests', () => {
  const base = { version: '1.0.0', files: { a: 'h1', b: 'h2' } }

  test('égalité malgré un generatedAt différent', () => {
    const d = gen.diffManifests(
      { ...base, generatedAt: 'X' },
      { ...base, generatedAt: 'Y' },
    )
    assert.equal(d.equal, true)
  })

  test('détecte ajout, retrait, modification et changement de version', () => {
    const d = gen.diffManifests(
      { version: '2.0.0', files: { a: 'h1', c: 'h3' } },
      base,
    )
    assert.equal(d.equal, false)
    assert.deepEqual(d.added, ['c'])
    assert.deepEqual(d.removed, ['b'])
    assert.deepEqual(d.changed, [])
    assert.equal(d.versionChanged, true)
  })

  test('détecte un contenu modifié à liste de fichiers identique', () => {
    const d = gen.diffManifests({ version: '1.0.0', files: { a: 'CHANGE', b: 'h2' } }, base)
    assert.deepEqual(d.changed, ['a'])
    assert.equal(d.equal, false)
  })
})

// ── generate-ada-manifest.js : CLI de bout en bout sur un vrai dépôt git ──────

describe('generate-ada-manifest CLI (dépôt git réel jetable)', () => {
  function makeRepo() {
    const root = tmp('repo')
    write(root, 'VERSION', '3.2.1\n')
    write(root, '.claude/coordinator/a.js', 'code a')
    write(root, '.claude/agents/b.md', 'agent b')
    write(root, '.claude/teams/profiles.json', '{}')
    // Fichier d'état runtime : NON ajouté à l'index → doit rester hors manifeste
    write(root, '.claude/coordinator/memory-semantic.json', '{"secret":"client"}')
    // Session d'équipe vivante : jamais trackée
    write(root, '.claude/teams/session-live/state.json', '{"live":true}')

    const g = (...args) => execFileSync('git', args, { cwd: root, stdio: 'pipe' })
    g('init', '-q')
    g('config', 'user.email', 'test@example.com')
    g('config', 'user.name', 'Test')
    g('add', '.claude/coordinator/a.js', '.claude/agents/b.md', '.claude/teams/profiles.json')
    g('commit', '-qm', 'init')
    return root
  }

  test('écrit un manifeste limité aux fichiers trackés', () => {
    const root = makeRepo()
    const rc = gen.main(['--root', root, '--date', FIXED_DATE])
    assert.equal(rc, 0)

    const m = JSON.parse(readFileSync(join(root, '.claude/.ada-manifest.json'), 'utf8'))
    assert.equal(m.generatedAt, FIXED_DATE)
    assert.equal(m.version, '3.2.1')
    assert.deepEqual(
      Object.keys(m.files).sort(),
      ['agents/b.md', 'coordinator/a.js', 'teams/profiles.json'],
    )
    // Les deux propriétés de sûreté centrales :
    assert.ok(!('coordinator/memory-semantic.json' in m.files), 'état runtime hors manifeste')
    assert.ok(!('teams/session-live/state.json' in m.files), 'session vivante hors manifeste')
  })

  test('--check réussit sur un manifeste à jour, échoue sur un périmé', () => {
    const root = makeRepo()
    assert.equal(gen.main(['--root', root, '--date', FIXED_DATE]), 0)
    assert.equal(gen.main(['--root', root, '--date', FIXED_DATE, '--check']), 0)

    // Le contenu source change → le manifeste committé devient périmé
    write(root, '.claude/coordinator/a.js', 'code a MODIFIÉ')
    assert.equal(gen.main(['--root', root, '--date', FIXED_DATE, '--check']), 1)
  })

  test('rejette une option inconnue', () => {
    assert.equal(gen.main(['--nope']), 2)
  })
})

// ── manifest-files-for.js ─────────────────────────────────────────────────────

describe('matchesPrefix', () => {
  test('matche un sous-arbre', () => {
    assert.equal(files.matchesPrefix('coordinator/bench-v2.js', 'coordinator'), true)
    assert.equal(files.matchesPrefix('coordinator/tests/x.sh', 'coordinator'), true)
  })

  test('matche un fichier exact (utilisé pour pipelines.json)', () => {
    assert.equal(files.matchesPrefix('coordinator/pipelines.json', 'coordinator/pipelines.json'), true)
    assert.equal(files.matchesPrefix('coordinator/pipelines.json.bak', 'coordinator/pipelines.json'), false)
  })

  test('respecte la frontière de segment (pas de match par simple préfixe de chaîne)', () => {
    assert.equal(files.matchesPrefix('coordinator-old/x.js', 'coordinator'), false)
    assert.equal(files.matchesPrefix('agentsX/a.md', 'agents'), false)
  })

  test('tolère un slash final dans le préfixe', () => {
    assert.equal(files.matchesPrefix('agents/a.md', 'agents/'), true)
  })
})

describe('filesFor', () => {
  const manifest = {
    files: {
      'coordinator/a.js': 'h',
      'coordinator/pipelines.json': 'h',
      'coordinator/sub/b.js': 'h',
      'agents/x.md': 'h',
      'coordinator-old/c.js': 'h',
    },
  }

  test('filtre par sous-arbre et trie', () => {
    assert.deepEqual(files.filesFor(manifest, 'coordinator'), [
      'coordinator/a.js', 'coordinator/pipelines.json', 'coordinator/sub/b.js',
    ])
  })

  test('applique les exclusions (pipelines.json sort du replace)', () => {
    assert.deepEqual(files.filesFor(manifest, 'coordinator', ['coordinator/pipelines.json']), [
      'coordinator/a.js', 'coordinator/sub/b.js',
    ])
  })

  test('renvoie une liste vide pour un préfixe inconnu', () => {
    assert.deepEqual(files.filesFor(manifest, 'nexistepas'), [])
  })

  test('tolère un manifeste sans files', () => {
    assert.deepEqual(files.filesFor({}, 'coordinator'), [])
    assert.deepEqual(files.filesFor(null, 'coordinator'), [])
  })

  test('CLI : code 3 quand la liste est vide, 1 si manifeste illisible', () => {
    const root = tmp('ff')
    const mPath = join(root, 'm.json')
    writeFileSync(mPath, JSON.stringify({ files: { 'agents/a.md': 'h' } }))
    assert.equal(files.main([mPath, 'coordinator']), 3)
    assert.equal(files.main([join(root, 'absent.json'), 'agents']), 1)
  })
})

// ── sync-content-dir.js : planContentSync — les 4 scénarios ───────────────────

describe('planContentSync — les 4 scénarios de décision', () => {
  const NEXT = {
    files: {
      'agents/neuf.md': h('livré v2'),
      'agents/intact.md': h('livré v2'),
      'agents/modifie.md': h('livré v2'),
      'agents/deja-a-jour.md': h('livré v2'),
    },
  }
  const APPLIED = {
    files: {
      'agents/intact.md': h('livré v1'),
      'agents/modifie.md': h('livré v1'),
      'agents/deja-a-jour.md': h('livré v1'),
      'agents/deprecie-intact.md': h('livré v1'),
      'agents/deprecie-modifie.md': h('livré v1'),
      'agents/deprecie-deja-parti.md': h('livré v1'),
    },
  }

  const plan = sync.planContentSync({
    prefix: 'agents',
    manifest: NEXT,
    applied: APPLIED,
    currentHashes: {
      'agents/neuf.md': null,                            // 1. absent du profil
      'agents/intact.md': h('livré v1'),                 // 2. == base
      'agents/modifie.md': h('bricolé par le client'),   // 3. != base
      'agents/deja-a-jour.md': h('livré v2'),            //    == nouveau
      'agents/deprecie-intact.md': h('livré v1'),        // 4a. déprécié, intact
      'agents/deprecie-modifie.md': h('bricolé'),        // 4b. déprécié, modifié
      'agents/deprecie-deja-parti.md': null,             // 4c. déjà absent
    },
  })

  test('1. fichier neuf → copié', () => {
    assert.equal(plan.decisions['agents/neuf.md'], sync.ACTION.NEW)
    assert.ok(plan.copy.some((c) => c.path === 'agents/neuf.md'))
  })

  test('2. fichier non modifié depuis la dernière livraison → mis à jour', () => {
    assert.equal(plan.decisions['agents/intact.md'], sync.ACTION.UPDATE)
    assert.ok(plan.copy.some((c) => c.path === 'agents/intact.md'))
  })

  test('3. fichier modifié par le client → JAMAIS écrasé, signalé', () => {
    assert.equal(plan.decisions['agents/modifie.md'], sync.ACTION.CUSTOMIZED)
    assert.ok(!plan.copy.some((c) => c.path === 'agents/modifie.md'))
    assert.ok(plan.customized.includes('agents/modifie.md'))
  })

  test('déjà à la version livrée → aucune action', () => {
    assert.equal(plan.decisions['agents/deja-a-jour.md'], sync.ACTION.UP_TO_DATE)
    assert.ok(!plan.copy.some((c) => c.path === 'agents/deja-a-jour.md'))
    assert.ok(plan.upToDate.includes('agents/deja-a-jour.md'))
  })

  test('4a. déprécié + jamais modifié → supprimé', () => {
    assert.equal(plan.decisions['agents/deprecie-intact.md'], sync.ACTION.REMOVE)
    assert.deepEqual(plan.remove, ['agents/deprecie-intact.md'])
  })

  test('4b. déprécié + modifié par le client → conservé et signalé', () => {
    assert.equal(plan.decisions['agents/deprecie-modifie.md'], sync.ACTION.DEPRECATED_CUSTOMIZED)
    assert.ok(!plan.remove.includes('agents/deprecie-modifie.md'))
    assert.ok(plan.deprecatedCustomized.includes('agents/deprecie-modifie.md'))
  })

  test('4c. déprécié + déjà absent → aucune action', () => {
    assert.equal(plan.decisions['agents/deprecie-deja-parti.md'], sync.ACTION.ALREADY_GONE)
    assert.ok(plan.alreadyGone.includes('agents/deprecie-deja-parti.md'))
  })
})

describe('planContentSync — premier passage sans manifeste appliqué', () => {
  const NEXT = { files: { 'agents/a.md': h('v2'), 'agents/b.md': h('v2') } }

  test('fichier absent → copié (rien à écraser)', () => {
    const p = sync.planContentSync({
      prefix: 'agents', manifest: NEXT, applied: null,
      currentHashes: { 'agents/a.md': null, 'agents/b.md': null },
    })
    assert.deepEqual(p.copy.map((c) => c.path).sort(), ['agents/a.md', 'agents/b.md'])
    assert.deepEqual(p.customized, [])
  })

  test('fichier déjà identique à la livraison → à jour, pas de copie', () => {
    const p = sync.planContentSync({
      prefix: 'agents', manifest: NEXT, applied: null,
      currentHashes: { 'agents/a.md': h('v2'), 'agents/b.md': h('v2') },
    })
    assert.deepEqual(p.copy, [])
    assert.equal(p.upToDate.length, 2)
  })

  test('fichier divergent sans base connue → CONSERVATEUR : traité comme personnalisé', () => {
    const p = sync.planContentSync({
      prefix: 'agents', manifest: NEXT, applied: null,
      currentHashes: { 'agents/a.md': h('divergent'), 'agents/b.md': h('v2') },
    })
    assert.deepEqual(p.customized, ['agents/a.md'])
    assert.deepEqual(p.copy, [])
  })

  test('manifeste appliqué illisible = traité comme absent (jamais fatal)', () => {
    const root = tmp('applied-broken')
    const p = join(root, 'broken.json')
    writeFileSync(p, 'ceci n est pas du json')
    assert.equal(sync.loadJsonOrNull(p), null)
    assert.equal(sync.loadJsonOrNull(join(root, 'absent.json')), null)
  })
})

describe('planContentSync — propriétés de sûreté', () => {
  test('un fichier hors des deux manifestes n apparaît dans AUCUNE action', () => {
    const p = sync.planContentSync({
      prefix: 'coordinator',
      manifest: { files: { 'coordinator/a.js': h('v2') } },
      applied: { files: { 'coordinator/a.js': h('v1') } },
      currentHashes: {
        'coordinator/a.js': h('v1'),
        // état runtime du client — hors manifeste dans les deux sens
        'coordinator/memory-semantic.json': h('données client'),
        'coordinator/lessons.json': h('leçons client'),
        'coordinator/bank.db': h('trajectoires'),
      },
    })
    const touched = [
      ...p.copy.map((c) => c.path), ...p.remove, ...p.customized,
      ...p.upToDate, ...p.deprecatedCustomized, ...p.alreadyGone,
    ]
    assert.deepEqual(touched, ['coordinator/a.js'])
    for (const runtime of ['coordinator/memory-semantic.json', 'coordinator/lessons.json', 'coordinator/bank.db']) {
      assert.ok(!touched.includes(runtime), `${runtime} ne doit jamais être touché`)
    }
  })

  test('le préfixe isole les sous-arbres (skills ne bouge pas quand on sync agents)', () => {
    const p = sync.planContentSync({
      prefix: 'agents',
      manifest: { files: { 'agents/a.md': h('v2'), 'skills/s.md': h('v2') } },
      applied: { files: { 'skills/vieux.md': h('v1') } },
      currentHashes: { 'agents/a.md': null, 'skills/s.md': null, 'skills/vieux.md': h('v1') },
    })
    assert.deepEqual(p.copy.map((c) => c.path), ['agents/a.md'])
    assert.deepEqual(p.remove, [])
  })

  test('une session d équipe vivante ne peut jamais être supprimée', () => {
    const p = sync.planContentSync({
      prefix: 'teams',
      manifest: { files: { 'teams/routing.md': h('v2') } },
      applied: { files: { 'teams/routing.md': h('v1') } },
      currentHashes: {
        'teams/routing.md': h('v1'),
        'teams/session-abc/state.json': h('session vivante'),
      },
    })
    assert.deepEqual(p.remove, [])
    assert.ok(!Object.keys(p.decisions).includes('teams/session-abc/state.json'))
  })
})

// ── sync-content-dir.js : content_dirs étendus (ADR-024, Axe 1) ──────────────
// benchmarks/templates/memory/archives rejoignent agents/skills/teams dans
// `content_dirs` (install.sh). Ces tests prouvent que planContentSync ne fait
// AUCUN cas particulier par nom de préfixe — la même mécanique de décision par
// checksum s'applique telle quelle, sans code supplémentaire.

describe('planContentSync — content_dirs étendus (benchmarks/templates/memory/archives)', () => {
  for (const prefix of ['benchmarks', 'templates', 'memory', 'archives']) {
    test(`${prefix}/ : neuf → copié, modifié par le client → préservé, déprécié intact → retiré`, () => {
      const plan = sync.planContentSync({
        prefix,
        manifest: {
          files: {
            [`${prefix}/neuf.json`]: h('v2 neuf'),
            [`${prefix}/existant.json`]: h('v2 existant'),
          },
        },
        applied: {
          files: {
            [`${prefix}/existant.json`]: h('v1 existant'),
            [`${prefix}/deprecie.json`]: h('v1 deprecie'),
          },
        },
        currentHashes: {
          [`${prefix}/neuf.json`]: null,
          [`${prefix}/existant.json`]: h('BRICOLÉ PAR LE CLIENT'),
          [`${prefix}/deprecie.json`]: h('v1 deprecie'),
        },
      })

      assert.equal(plan.decisions[`${prefix}/neuf.json`], sync.ACTION.NEW)
      assert.equal(plan.decisions[`${prefix}/existant.json`], sync.ACTION.CUSTOMIZED)
      assert.equal(plan.decisions[`${prefix}/deprecie.json`], sync.ACTION.REMOVE)
    })
  }

  test('benchmarks/ : la cohabitation référence-trackée + runtime-gitignoré ne casse rien (E3-3)', () => {
    // `benchmarks/results.json` et `benchmarks/.pending.json` sont gitignorés
    // (vérifié dans .gitignore) : absents des DEUX manifestes, donc jamais
    // touchés — même garantie structurelle que memory-*.json/lessons.json.
    const p = sync.planContentSync({
      prefix: 'benchmarks',
      manifest: { files: { 'benchmarks/tasks.json': h('v2') } },
      applied: { files: { 'benchmarks/tasks.json': h('v1') } },
      currentHashes: {
        'benchmarks/tasks.json': h('v1'),
        'benchmarks/results.json': h('résultats réels du client'),
        'benchmarks/.pending.json': h('run en cours du client'),
      },
    })
    const touched = [
      ...p.copy.map((c) => c.path), ...p.remove, ...p.customized,
      ...p.upToDate, ...p.deprecatedCustomized, ...p.alreadyGone,
    ]
    assert.deepEqual(touched, ['benchmarks/tasks.json'])
  })

  test('benchmarks/v2/results-v2.json : tracké ET réécrit au runtime — protégé par la même mécanique checksum que pipelines.json, sans MANIFEST_MUTABLE', () => {
    // Contrairement à results.json/.pending.json (gitignorés), results-v2.json
    // EST tracké par git (le mainteneur y committe ses propres résultats de
    // référence) et réécrit par coordinator/bench-v2.js quand un client lance
    // ses propres runs. Double nature comme pipelines.json — mais passer par
    // le mode `content` (checksum) suffit : pas besoin d'entrer dans
    // MANIFEST_MUTABLE (qui ne sert qu'aux dirs SYSTÈME en mode replace).
    const p = sync.planContentSync({
      prefix: 'benchmarks',
      manifest: { files: { 'benchmarks/v2/results-v2.json': h('résultats mainteneur v2') } },
      applied: { files: { 'benchmarks/v2/results-v2.json': h('résultats mainteneur v1') } },
      currentHashes: {
        // Le client a lancé son propre benchmark depuis la dernière sync :
        // son fichier diverge de la base appliquée → jamais écrasé.
        'benchmarks/v2/results-v2.json': h('résultats du run du client'),
      },
    })
    assert.equal(p.decisions['benchmarks/v2/results-v2.json'], sync.ACTION.CUSTOMIZED)
    assert.deepEqual(p.copy, [])
  })
})

// ── sync-content-dir.js : planSystemPrune ─────────────────────────────────────

describe('planSystemPrune', () => {
  test('sans manifeste appliqué, ne retire RIEN (aucune base de référence)', () => {
    const p = sync.planSystemPrune({
      prefix: 'coordinator',
      manifest: { files: { 'coordinator/a.js': 'h' } },
      applied: null,
      currentHashes: { 'coordinator/vieux.js': 'h-quelconque' },
    })
    assert.deepEqual(p.remove, [])
  })

  test('retire un fichier déprécié, même modifié (dir système = replace)', () => {
    const p = sync.planSystemPrune({
      prefix: 'coordinator',
      manifest: { files: { 'coordinator/a.js': h('v2') } },
      applied: { files: { 'coordinator/a.js': h('v1'), 'coordinator/vieux.js': h('v1') } },
      currentHashes: { 'coordinator/a.js': h('v1'), 'coordinator/vieux.js': h('modifié') },
    })
    assert.deepEqual(p.remove, ['coordinator/vieux.js'])
  })

  test('ne retire jamais un fichier qu ADA n a pas livré', () => {
    const p = sync.planSystemPrune({
      prefix: 'coordinator',
      manifest: { files: {} },
      applied: { files: { 'coordinator/a.js': h('v1') } },
      currentHashes: {
        'coordinator/a.js': h('v1'),
        'coordinator/memory-semantic.json': h('client'),
        'coordinator/logs/audit.log': h('client'),
      },
    })
    assert.deepEqual(p.remove, ['coordinator/a.js'])
  })

  test('fichier déprécié déjà absent → aucune action', () => {
    const p = sync.planSystemPrune({
      prefix: 'coordinator',
      manifest: { files: {} },
      applied: { files: { 'coordinator/vieux.js': h('v1') } },
      currentHashes: { 'coordinator/vieux.js': null },
    })
    assert.deepEqual(p.remove, [])
    assert.deepEqual(p.alreadyGone, ['coordinator/vieux.js'])
  })
})

// ── sync-content-dir.js : relevantPaths / collectCurrentHashes / applyPlan ────

describe('relevantPaths', () => {
  test('union des deux manifestes, restreinte au préfixe, triée', () => {
    const r = sync.relevantPaths(
      { files: { 'agents/b.md': 'h', 'skills/s.md': 'h' } },
      { files: { 'agents/a.md': 'h', 'agents/b.md': 'h' } },
      'agents',
    )
    assert.deepEqual(r, ['agents/a.md', 'agents/b.md'])
  })
})

describe('collectCurrentHashes', () => {
  test('null pour un fichier absent, hash sinon', () => {
    const root = tmp('collect')
    write(root, 'agents/a.md', 'contenu')
    const res = sync.collectCurrentHashes(root, ['agents/a.md', 'agents/absent.md'])
    assert.equal(res['agents/a.md'], h('contenu'))
    assert.equal(res['agents/absent.md'], null)
  })
})

describe('applyPlan', () => {
  test('copie en créant les répertoires intermédiaires', () => {
    const src = tmp('ap-src')
    const dst = tmp('ap-dst')
    write(src, 'agents/nouveau/CLAUDE.md', 'agent imbriqué')
    const res = sync.applyPlan(
      { copy: [{ path: 'agents/nouveau/CLAUDE.md' }] },
      { srcRoot: src, dstRoot: dst },
    )
    assert.equal(res.copied, 1)
    assert.deepEqual(res.errors, [])
    assert.equal(readFileSync(join(dst, 'agents/nouveau/CLAUDE.md'), 'utf8'), 'agent imbriqué')
  })

  test('réaligne le mode du fichier de destination sur celui de la source', () => {
    const src = tmp('ap-mode-src')
    const dst = tmp('ap-mode-dst')
    const abs = write(src, 'bin/tool.js', '#!/usr/bin/env node\n')
    require('node:fs').chmodSync(abs, 0o755)
    write(dst, 'bin/tool.js', 'ancien')
    require('node:fs').chmodSync(join(dst, 'bin/tool.js'), 0o644)

    sync.applyPlan({ copy: [{ path: 'bin/tool.js' }] }, { srcRoot: src, dstRoot: dst })
    assert.equal(statSync(join(dst, 'bin/tool.js')).mode & 0o777, 0o755)
  })

  test('supprime les fichiers du plan remove', () => {
    const dst = tmp('ap-rm')
    write(dst, 'agents/vieux.md', 'à retirer')
    const res = sync.applyPlan({ remove: ['agents/vieux.md'] }, { srcRoot: dst, dstRoot: dst })
    assert.equal(res.removed, 1)
    assert.equal(existsSync(join(dst, 'agents/vieux.md')), false)
  })

  test('--dry-run ne modifie rien sur le disque', () => {
    const src = tmp('ap-dry-src')
    const dst = tmp('ap-dry-dst')
    write(src, 'agents/a.md', 'nouveau')
    write(dst, 'agents/a.md', 'ancien')
    write(dst, 'agents/vieux.md', 'à retirer')

    sync.applyPlan(
      { copy: [{ path: 'agents/a.md' }], remove: ['agents/vieux.md'] },
      { srcRoot: src, dstRoot: dst, dryRun: true },
    )
    assert.equal(readFileSync(join(dst, 'agents/a.md'), 'utf8'), 'ancien')
    assert.equal(existsSync(join(dst, 'agents/vieux.md')), true)
  })

  test('collecte les erreurs sans interrompre le plan', () => {
    const src = tmp('ap-err-src')
    const dst = tmp('ap-err-dst')
    write(src, 'agents/ok.md', 'ok')
    const res = sync.applyPlan(
      { copy: [{ path: 'agents/absent.md' }, { path: 'agents/ok.md' }] },
      { srcRoot: src, dstRoot: dst },
    )
    assert.equal(res.copied, 1)
    assert.equal(res.errors.length, 1)
    assert.equal(res.errors[0].path, 'agents/absent.md')
  })
})

// ── Bout en bout : sync d'un profil fictif ────────────────────────────────────

describe('sync-content-dir CLI — bout en bout sur un profil FICTIF', () => {
  /**
   * Monte une source `.claude` fictive et un profil fictif reproduisant les 4
   * scénarios + de l'état runtime, puis lance le CLI comme install.sh le fait.
   */
  function scenario() {
    const src = tmp('e2e-src')
    const dst = tmp('e2e-dst')

    // Source livrée (v2)
    write(src, 'agents/neuf.md', 'v2 neuf')
    write(src, 'agents/intact.md', 'v2 intact')
    write(src, 'agents/modifie.md', 'v2 modifie')

    // Manifeste courant
    const manifest = {
      generatedAt: FIXED_DATE,
      version: '2.0.0',
      files: {
        'agents/neuf.md': h('v2 neuf'),
        'agents/intact.md': h('v2 intact'),
        'agents/modifie.md': h('v2 modifie'),
      },
    }
    const manifestPath = join(src, 'manifest.json')
    writeFileSync(manifestPath, JSON.stringify(manifest))

    // Manifeste appliqué la fois précédente (v1)
    const applied = {
      generatedAt: '2026-01-01T00:00:00.000Z',
      version: '1.0.0',
      files: {
        'agents/intact.md': h('v1 intact'),
        'agents/modifie.md': h('v1 modifie'),
        'agents/deprecie-intact.md': h('v1 deprecie'),
        'agents/deprecie-modifie.md': h('v1 deprecie-modifie'),
      },
    }
    const appliedPath = join(dst, '.ada-manifest.applied.json')
    mkdirSync(dst, { recursive: true })
    writeFileSync(appliedPath, JSON.stringify(applied))

    // État du profil
    write(dst, 'agents/intact.md', 'v1 intact')                 // jamais touché
    write(dst, 'agents/modifie.md', 'MA VERSION PERSO')          // modifié client
    write(dst, 'agents/deprecie-intact.md', 'v1 deprecie')       // déprécié intact
    write(dst, 'agents/deprecie-modifie.md', 'MA VERSION PERSO') // déprécié modifié
    // État runtime — doit survivre intégralement
    write(dst, 'agents/mon-agent-perso.md', 'AGENT CRÉÉ PAR LE CLIENT')
    write(dst, 'coordinator/memory-semantic.json', '{"client":true}')

    return { src, dst, manifestPath, appliedPath }
  }

  test('applique les 4 décisions et ne détruit aucun état runtime', () => {
    const { src, dst, manifestPath, appliedPath } = scenario()
    const reportPath = join(dst, 'report.tsv')

    const rc = sync.main([
      '--mode', 'content', '--prefix', 'agents',
      '--src', src, '--dst', dst,
      '--manifest', manifestPath, '--applied', appliedPath,
      '--report', reportPath, '--report-tag', 'profil-fictif',
      '--quiet',
    ])
    assert.equal(rc, 0)

    const read = (rel) => readFileSync(join(dst, rel), 'utf8')

    // 1. neuf → copié
    assert.equal(read('agents/neuf.md'), 'v2 neuf')
    // 2. intact → mis à jour
    assert.equal(read('agents/intact.md'), 'v2 intact')
    // 3. modifié → préservé tel quel
    assert.equal(read('agents/modifie.md'), 'MA VERSION PERSO')
    // 4a. déprécié intact → supprimé
    assert.equal(existsSync(join(dst, 'agents/deprecie-intact.md')), false)
    // 4b. déprécié modifié → conservé
    assert.equal(read('agents/deprecie-modifie.md'), 'MA VERSION PERSO')

    // État runtime et fichiers propres au client : intacts
    assert.equal(read('agents/mon-agent-perso.md'), 'AGENT CRÉÉ PAR LE CLIENT')
    assert.equal(read('coordinator/memory-semantic.json'), '{"client":true}')

    // Rapport pour le récapitulatif d'install
    const report = readFileSync(reportPath, 'utf8')
    assert.match(report, /profil-fictif\tpersonnalise\tagents\/modifie\.md/)
    assert.match(report, /profil-fictif\tdeprecie-personnalise\tagents\/deprecie-modifie\.md/)
  })

  test('idempotence : un second passage ne change plus rien', () => {
    const { src, dst, manifestPath, appliedPath } = scenario()
    const run = () => sync.main([
      '--mode', 'content', '--prefix', 'agents',
      '--src', src, '--dst', dst,
      '--manifest', manifestPath, '--applied', appliedPath, '--quiet',
    ])
    assert.equal(run(), 0)
    const after1 = readFileSync(join(dst, 'agents/intact.md'), 'utf8')
    assert.equal(run(), 0)
    assert.equal(readFileSync(join(dst, 'agents/intact.md'), 'utf8'), after1)
    assert.equal(readFileSync(join(dst, 'agents/modifie.md'), 'utf8'), 'MA VERSION PERSO')
  })

  test('--dry-run : mêmes décisions annoncées, RIEN écrit sur le disque (ADR-024, E2-8)', () => {
    const { src, dst, manifestPath, appliedPath } = scenario()
    const before = snapshotTree(dst)
    // Rapport hors du profil, comme le fait install.sh (CUSTOM_REPORT est un
    // fichier /tmp indépendant) — ne doit pas polluer l'empreinte de `dst`.
    const reportPath = join(tmp('dry-report'), 'report.tsv')

    const stdout = execFileSync(process.execPath, [
      SYNC_JS, '--mode', 'content', '--prefix', 'agents',
      '--src', src, '--dst', dst,
      '--manifest', manifestPath, '--applied', appliedPath,
      '--report', reportPath, '--report-tag', 'profil-fictif',
      '--dry-run',
    ], { encoding: 'utf8' })

    // Le résumé annonce clairement ce qui AURAIT été fait.
    assert.match(stdout, /\[dry-run\]/)
    assert.match(stdout, /copié/)

    // Propriété centrale du --dry-run : empreinte de `dst` strictement identique.
    assert.deepEqual(snapshotTree(dst), before, 'dry-run ne doit modifier aucun fichier du profil')

    // Le rapport de personnalisations (fichier de compte-rendu de l'invocation,
    // hors profil) est bien émis même en dry-run — sinon le résumé final
    // d'install.sh ne pourrait jamais lister les fichiers personnalisés en dry-run.
    assert.match(readFileSync(reportPath, 'utf8'), /profil-fictif\tpersonnalise\tagents\/modifie\.md/)
  })

  test('rejette des arguments incomplets', () => {
    assert.equal(sync.main(['--mode', 'content']), 2)
    assert.equal(sync.main(['--mode', 'nawak', '--manifest', 'x', '--prefix', 'y', '--dst', 'z']), 2)
  })

  test('manifeste courant illisible → échec explicite, aucune action', () => {
    const { dst } = scenario()
    const rc = sync.main([
      '--mode', 'content', '--prefix', 'agents',
      '--src', dst, '--dst', dst,
      '--manifest', join(dst, 'absent.json'), '--quiet',
    ])
    assert.equal(rc, 1)
  })
})

// ── Intégration : le chemin rsync --files-from de install.sh ──────────────────

describe('rsync --files-from — protection de l état runtime (chemin install.sh)', () => {
  const hasRsync = (() => {
    try { execFileSync('rsync', ['--version'], { stdio: 'pipe' }); return true } catch { return false }
  })()

  test('met à jour les fichiers listés sans toucher au reste du profil', (t) => {
    if (!hasRsync) return t.skip('rsync absent')

    const src = tmp('rs-src')
    const dst = tmp('rs-dst')

    write(src, 'coordinator/bench.js', 'livré v2')
    write(src, 'coordinator/nouveau.js', 'livré v2')
    // Même TAILLE que la source : c'est précisément ce cas qui échappe au
    // quick-check taille+mtime de rsync et impose --checksum.
    write(dst, 'coordinator/bench.js', 'livré v1')
    write(dst, 'coordinator/memory-semantic.json', 'ÉTAT CLIENT')
    write(dst, 'coordinator/logs/audit.log', 'LOG CLIENT')
    write(dst, 'teams/session-abc/state.json', 'SESSION VIVANTE')

    const listPath = join(src, 'files-from.txt')
    writeFileSync(listPath, 'coordinator/bench.js\ncoordinator/nouveau.js\n')

    execFileSync('rsync', [
      '-a', '--checksum', '--delete', `--files-from=${listPath}`, `${src}/`, `${dst}/`,
    ], { stdio: 'pipe' })

    const read = (rel) => readFileSync(join(dst, rel), 'utf8')
    // Les fichiers livrés sont bien à jour — --checksum est ce qui le garantit
    assert.equal(read('coordinator/bench.js'), 'livré v2')
    assert.equal(read('coordinator/nouveau.js'), 'livré v2')
    // Tout l'état runtime survit à --delete
    assert.equal(read('coordinator/memory-semantic.json'), 'ÉTAT CLIENT')
    assert.equal(read('coordinator/logs/audit.log'), 'LOG CLIENT')
    assert.equal(read('teams/session-abc/state.json'), 'SESSION VIVANTE')
  })
})

// ── Intégration : install_profile() de install.sh, sur un profil FICTIF ───────

describe('install.sh :: install_profile — profil FICTIF sous os.tmpdir()', () => {
  const INSTALL_SH = join(__dirname, '../../../install.sh')

  /**
   * Prépare un faux dépôt source + un faux profil, puis exécute la VRAIE
   * fonction install_profile() de install.sh.
   *
   * install.sh est copié sans sa dernière ligne (`main "$@"`) afin de pouvoir le
   * sourcer et n'appeler QUE install_profile : aucun sudo, aucun npm, aucun
   * doctor, aucun kill du port 7777, et surtout aucun accès à un vrai ~/.claude*.
   */
  /**
   * @param {{dryRun?: boolean}} [opts] dryRun : exécute install_profile avec
   *   DRY_RUN=true (ADR-024, E2-8) — sert aux tests qui vérifient qu'aucune
   *   écriture n'a lieu sur le disque.
   */
  function harness(opts = {}) {
    const { dryRun = false } = opts
    const work = tmp('inst')
    const fakeRepo = join(work, 'repo')
    const profile = join(work, 'profil-fictif')

    // ── Faux dépôt source ──
    write(fakeRepo, 'VERSION', '9.9.9\n')
    write(fakeRepo, 'CLAUDE.md', '# CLAUDE fictif\n')
    write(fakeRepo, '.claude/settings.json', JSON.stringify({ hooks: {} }))

    // Dir système : un fichier à jour, un périmé, un nouveau
    write(fakeRepo, '.claude/coordinator/garde.js', 'livré v2')
    write(fakeRepo, '.claude/coordinator/nouveau.js', 'livré v2')
    write(fakeRepo, '.claude/coordinator/bank-state.seed.json', '{"seed":true}')
    // Fichier à double nature (présent dans MANIFEST_MUTABLE)
    write(fakeRepo, '.claude/coordinator/pipelines.json', '{"v":2}')
    // Dir contenu
    write(fakeRepo, '.claude/agents/officiel.md', 'agent v2')
    // Dirs contenu étendus (ADR-024, Axe 1) : benchmarks/templates/memory/archives
    write(fakeRepo, '.claude/benchmarks/tasks.json', 'benchmarks v2')
    write(fakeRepo, '.claude/templates/backend.json', 'template v2')
    write(fakeRepo, '.claude/memory/context.md', 'memory v2')
    write(fakeRepo, '.claude/archives/summaries/note.md', 'archive v2')

    // Les scripts réels sont nécessaires : install.sh les invoque.
    for (const s of ['generate-ada-manifest.js', 'manifest-files-for.js', 'sync-content-dir.js']) {
      write(fakeRepo, `.claude/scripts/${s}`, readFileSync(join(__dirname, '../../scripts', s)))
    }

    // ── Manifeste de la livraison v2 ──
    const manifestFiles = {
      'coordinator/garde.js': h('livré v2'),
      'coordinator/nouveau.js': h('livré v2'),
      'coordinator/bank-state.seed.json': h('{"seed":true}'),
      'coordinator/pipelines.json': h('{"v":2}'),
      'agents/officiel.md': h('agent v2'),
      'benchmarks/tasks.json': h('benchmarks v2'),
      'templates/backend.json': h('template v2'),
      'memory/context.md': h('memory v2'),
      'archives/summaries/note.md': h('archive v2'),
    }
    write(fakeRepo, '.claude/.ada-manifest.json', JSON.stringify({
      generatedAt: FIXED_DATE, version: '9.9.9', files: manifestFiles,
    }))

    // ── Profil déjà installé en v1 ──
    write(profile, '.ada-manifest.applied.json', JSON.stringify({
      generatedAt: '2026-01-01T00:00:00.000Z',
      version: '1.0.0',
      files: {
        'coordinator/garde.js': h('livré v1'),
        'coordinator/supprime.js': h('livré v1'),   // déprécié côté source
        'coordinator/pipelines.json': h('{"v":1}'),
        'agents/officiel.md': h('agent v1'),
        // benchmarks/templates/memory/archives : ABSENTS du manifeste appliqué
        // v1 (ces dirs n'étaient pas encore synchronisés avant cette passe) —
        // scénario réaliste d'un profil installé avant l'extension de
        // content_dirs.
      },
    }))
    write(profile, 'coordinator/garde.js', 'livré v1')
    write(profile, 'coordinator/supprime.js', 'livré v1')
    write(profile, 'coordinator/pipelines.json', '{"v":1}')
    write(profile, 'agents/officiel.md', 'agent v1')

    // ── État runtime du client : DOIT survivre intégralement ──
    write(profile, 'coordinator/memory-semantic.json', '{"client":"semantique"}')
    write(profile, 'coordinator/memory-episodic.json', '{"client":"episodique"}')
    write(profile, 'coordinator/lessons.json', '{"client":"lecons"}')
    write(profile, 'coordinator/audit.log', 'AUDIT CLIENT')
    write(profile, 'coordinator/bank-state.json', '{"priors":"appris"}')
    write(profile, 'coordinator/bank.db', 'TRAJECTOIRES')
    write(profile, 'coordinator/logs/run.log', 'LOG CLIENT')
    write(profile, 'coordinator/active-policy.json', '{"policy":"client"}')
    write(profile, 'agents/mon-agent.md', 'AGENT DU CLIENT')
    write(profile, 'teams/session-vivante/state.json', 'SESSION EN COURS')
    // État runtime gitignoré DANS benchmarks/ (E3-3, résultats réels du client) :
    // absent des deux manifestes → doit survivre, même quand benchmarks/
    // rejoint content_dirs.
    write(profile, 'benchmarks/results.json', '{"client":"resultats reels"}')

    // ── install.sh sans sa dernière ligne `main "$@"` ──
    const srcSh = readFileSync(INSTALL_SH, 'utf8')
    assert.match(srcSh, /^main "\$@"$/m, 'install.sh doit finir par main "$@"')
    const sourceable = join(work, 'install-sourceable.sh')
    writeFileSync(sourceable, srcSh.replace(/^main "\$@"$/m, '# main désactivé pour le test'))

    const report = join(work, 'report.tsv')
    writeFileSync(report, '')

    // Empreinte AVANT exécution — seule façon de prouver qu'un run --dry-run
    // n'a strictement rien changé (les fixtures ci-dessus sont déjà en place).
    const before = snapshotTree(profile)

    const script = [
      'set -euo pipefail',
      `source ${JSON.stringify(sourceable)}`,
      // Réancrage sur le faux dépôt : le script sourcé a calculé SOURCE_DIR
      // depuis son propre emplacement.
      `SOURCE_DIR=${JSON.stringify(fakeRepo)}`,
      'CLAUDE_DIR="$SOURCE_DIR/.claude"',
      'MANIFEST_FILE="$CLAUDE_DIR/.ada-manifest.json"',
      `CUSTOM_REPORT=${JSON.stringify(report)}`,
      `DRY_RUN=${dryRun ? 'true' : 'false'}`,
      `install_profile ${JSON.stringify(profile)}`,
    ].join('\n')

    const stdout = execFileSync('bash', ['-c', script], { encoding: 'utf8', stdio: 'pipe' })
    return { profile, fakeRepo, report, stdout, before }
  }

  test('met à jour le code livré ET préserve tout l état runtime du client', () => {
    const { profile } = harness()
    const read = (rel) => readFileSync(join(profile, rel), 'utf8')

    // ── Dir système : mis à jour ──
    assert.equal(read('coordinator/garde.js'), 'livré v2', 'fichier système périmé mis à jour')
    assert.equal(read('coordinator/nouveau.js'), 'livré v2', 'nouveau fichier système livré')
    // ── Dir système : fichier déprécié retiré (E3-4) ──
    assert.equal(
      existsSync(join(profile, 'coordinator/supprime.js')), false,
      'fichier système retiré de la source doit disparaître du profil',
    )

    // ── État runtime : intact (E2-1) ──
    assert.equal(read('coordinator/memory-semantic.json'), '{"client":"semantique"}')
    assert.equal(read('coordinator/memory-episodic.json'), '{"client":"episodique"}')
    assert.equal(read('coordinator/lessons.json'), '{"client":"lecons"}')
    assert.equal(read('coordinator/audit.log'), 'AUDIT CLIENT')
    assert.equal(read('coordinator/bank-state.json'), '{"priors":"appris"}')
    assert.equal(read('coordinator/bank.db'), 'TRAJECTOIRES')
    assert.equal(read('coordinator/logs/run.log'), 'LOG CLIENT')
    assert.equal(read('coordinator/active-policy.json'), '{"policy":"client"}')
    assert.equal(read('agents/mon-agent.md'), 'AGENT DU CLIENT')
    // Session d'équipe vivante (E3-5)
    assert.equal(read('teams/session-vivante/state.json'), 'SESSION EN COURS')

    // ── pipelines.json : DÉGELÉ (E3-2) ──
    assert.equal(read('coordinator/pipelines.json'), '{"v":2}',
      'pipelines.json non modifié par le client doit passer en v2')

    // ── Dir contenu : mis à jour ──
    assert.equal(read('agents/officiel.md'), 'agent v2')

    // ── Dirs contenu étendus (ADR-024, Axe 1) : livrés comme agents/ ──
    assert.equal(read('benchmarks/tasks.json'), 'benchmarks v2')
    assert.equal(read('templates/backend.json'), 'template v2')
    assert.equal(read('memory/context.md'), 'memory v2')
    assert.equal(read('archives/summaries/note.md'), 'archive v2')
    // État runtime gitignoré DANS benchmarks/ (E3-3) : jamais touché
    assert.equal(read('benchmarks/results.json'), '{"client":"resultats reels"}')

    // ── Manifeste appliqué déposé pour la prochaine sync ──
    const applied = JSON.parse(read('.ada-manifest.applied.json'))
    assert.equal(applied.version, '9.9.9')
    assert.ok('coordinator/garde.js' in applied.files)
    assert.ok('benchmarks/tasks.json' in applied.files)
  })

  test('--dry-run : install_profile n écrit RIEN sur le disque, y compris pour les 4 nouveaux dirs', () => {
    const { profile, before, stdout } = harness({ dryRun: true })

    // Empreinte strictement identique avant/après — la preuve la plus forte
    // qu'aucune écriture n'a eu lieu nulle part dans le profil.
    assert.deepEqual(snapshotTree(profile), before, '--dry-run ne doit modifier aucun fichier du profil')

    // Les fichiers système périmés/déprécié ne bougent pas non plus
    assert.equal(readFileSync(join(profile, 'coordinator/garde.js'), 'utf8'), 'livré v1')
    assert.equal(existsSync(join(profile, 'coordinator/supprime.js')), true,
      'un fichier déprécié ne doit pas être retiré en --dry-run')

    // Les 4 nouveaux dirs contenu n'existaient pas dans le profil v1 : ils ne
    // doivent PAS apparaître après un --dry-run.
    assert.equal(existsSync(join(profile, 'benchmarks/tasks.json')), false)
    assert.equal(existsSync(join(profile, 'templates/backend.json')), false)
    assert.equal(existsSync(join(profile, 'memory/context.md')), false)
    assert.equal(existsSync(join(profile, 'archives/summaries/note.md')), false)

    // Le manifeste appliqué reste sur l'ancienne version (jamais réécrit)
    const applied = JSON.parse(readFileSync(join(profile, '.ada-manifest.applied.json'), 'utf8'))
    assert.equal(applied.version, '1.0.0')

    // Le résumé annonce ce qui AURAIT été fait
    assert.match(stdout, /\[dry-run\]/)
  })

  test('un pipelines.json personnalisé n est jamais écrasé et est signalé', () => {
    const work = tmp('inst-custom')
    // On rejoue le harness puis on repart d'un profil où le client a bricolé
    const { profile, fakeRepo, report } = harness()
    void work

    // Le client modifie pipelines.json et un agent officiel APRÈS la sync
    writeFileSync(join(profile, 'coordinator/pipelines.json'), '{"v":"MA VERSION"}')
    writeFileSync(join(profile, 'agents/officiel.md'), 'MON AGENT MODIFIÉ')
    writeFileSync(report, '')

    const sourceable = join(fakeRepo, '..', 'install-sourceable.sh')
    const script = [
      'set -euo pipefail',
      `source ${JSON.stringify(sourceable)}`,
      `SOURCE_DIR=${JSON.stringify(fakeRepo)}`,
      'CLAUDE_DIR="$SOURCE_DIR/.claude"',
      'MANIFEST_FILE="$CLAUDE_DIR/.ada-manifest.json"',
      `CUSTOM_REPORT=${JSON.stringify(report)}`,
      `install_profile ${JSON.stringify(profile)}`,
    ].join('\n')
    execFileSync('bash', ['-c', script], { encoding: 'utf8', stdio: 'pipe' })

    assert.equal(
      readFileSync(join(profile, 'coordinator/pipelines.json'), 'utf8'), '{"v":"MA VERSION"}',
      'pipelines.json modifié par le client ne doit jamais être écrasé',
    )
    assert.equal(
      readFileSync(join(profile, 'agents/officiel.md'), 'utf8'), 'MON AGENT MODIFIÉ',
      'agent modifié par le client ne doit jamais être écrasé',
    )

    const tsv = readFileSync(report, 'utf8')
    assert.match(tsv, /personnalise\tcoordinator\/pipelines\.json/)
    assert.match(tsv, /personnalise\tagents\/officiel\.md/)
  })

  test('install_profile est idempotent', () => {
    const { profile, fakeRepo, report } = harness()
    const sourceable = join(fakeRepo, '..', 'install-sourceable.sh')
    const script = [
      'set -euo pipefail',
      `source ${JSON.stringify(sourceable)}`,
      `SOURCE_DIR=${JSON.stringify(fakeRepo)}`,
      'CLAUDE_DIR="$SOURCE_DIR/.claude"',
      'MANIFEST_FILE="$CLAUDE_DIR/.ada-manifest.json"',
      `CUSTOM_REPORT=${JSON.stringify(report)}`,
      `install_profile ${JSON.stringify(profile)}`,
    ].join('\n')

    execFileSync('bash', ['-c', script], { stdio: 'pipe' })
    const snapshot = [
      readFileSync(join(profile, 'coordinator/garde.js'), 'utf8'),
      readFileSync(join(profile, 'coordinator/pipelines.json'), 'utf8'),
      readFileSync(join(profile, 'agents/officiel.md'), 'utf8'),
      readFileSync(join(profile, 'coordinator/memory-semantic.json'), 'utf8'),
    ]
    execFileSync('bash', ['-c', script], { stdio: 'pipe' })
    assert.deepEqual([
      readFileSync(join(profile, 'coordinator/garde.js'), 'utf8'),
      readFileSync(join(profile, 'coordinator/pipelines.json'), 'utf8'),
      readFileSync(join(profile, 'agents/officiel.md'), 'utf8'),
      readFileSync(join(profile, 'coordinator/memory-semantic.json'), 'utf8'),
    ], snapshot)
  })

  test('CLAUDE.md personnalisé + env/preferences custom survivent à une ré-installation (E2-4 + E2-6, bout en bout)', () => {
    const { profile, fakeRepo, report } = harness()

    // Le client personnalise CLAUDE.md ET settings.json après le premier install.
    writeFileSync(join(profile, 'CLAUDE.md'), '# CLAUDE personnalisé par le client\n')
    const settingsPath = join(profile, 'settings.json')
    const clientSettings = JSON.parse(readFileSync(settingsPath, 'utf8'))
    clientSettings.env = { CLIENT_ONLY: 'garde-moi', SHARED_DIFFERENT: 'valeur-client' }
    clientSettings.preferences = { tmuxSplitPanes: false }
    writeFileSync(settingsPath, JSON.stringify(clientSettings, null, 2))

    // La source évolue : nouvelle version de CLAUDE.md + nouvelles clés ADA dans settings.json.
    writeFileSync(join(fakeRepo, 'CLAUDE.md'), '# CLAUDE v3 (nouvelle version livrée)\n')
    const srcSettingsPath = join(fakeRepo, '.claude/settings.json')
    const srcSettings = JSON.parse(readFileSync(srcSettingsPath, 'utf8'))
    srcSettings.env = { ADA_NEW: 'valeur-ada', SHARED_DIFFERENT: 'valeur-ada' }
    srcSettings.preferences = { tmuxSplitPanes: true, newAdaPref: 'x' }
    writeFileSync(srcSettingsPath, JSON.stringify(srcSettings, null, 2))
    writeFileSync(report, '')

    const sourceable = join(fakeRepo, '..', 'install-sourceable.sh')
    const script = [
      'set -euo pipefail',
      `source ${JSON.stringify(sourceable)}`,
      `SOURCE_DIR=${JSON.stringify(fakeRepo)}`,
      'CLAUDE_DIR="$SOURCE_DIR/.claude"',
      'MANIFEST_FILE="$CLAUDE_DIR/.ada-manifest.json"',
      `CUSTOM_REPORT=${JSON.stringify(report)}`,
      `install_profile ${JSON.stringify(profile)}`,
    ].join('\n')
    const stdout = execFileSync('bash', ['-c', script], { encoding: 'utf8', stdio: 'pipe' })

    // ── CLAUDE.md : sauvegardé PUIS écrasé par la v3 (E2-4) ──
    assert.equal(
      readFileSync(join(profile, 'CLAUDE.md'), 'utf8'), '# CLAUDE v3 (nouvelle version livrée)\n',
    )
    const backups = readdirSync(profile).filter((f) => /^CLAUDE\.md\.bak\.\d{14}$/.test(f))
    assert.equal(backups.length, 1, 'une sauvegarde horodatée doit être créée')
    assert.equal(
      readFileSync(join(profile, backups[0]), 'utf8'), '# CLAUDE personnalisé par le client\n',
    )

    // ── settings.json : env/preferences client préservés, nouvelles clés ADA arrivées (E2-6) ──
    const merged = JSON.parse(readFileSync(settingsPath, 'utf8'))
    assert.equal(merged.env.CLIENT_ONLY, 'garde-moi')
    assert.equal(merged.env.SHARED_DIFFERENT, 'valeur-client', 'conflit → valeur client conservée')
    assert.equal(merged.env.ADA_NEW, 'valeur-ada', 'nouvelle clé ADA doit atteindre le profil')
    assert.equal(merged.preferences.tmuxSplitPanes, false, 'préférence client jamais écrasée')
    assert.equal(merged.preferences.newAdaPref, 'x')

    // ── le conflit doit être signalé, pas silencieux ──
    assert.match(stdout, /[Cc]onflit/)

    // ── rien d'autre perturbé : sanity-check sur l'état runtime déjà couvert
    // par les tests dédiés plus haut ──
    assert.equal(readFileSync(join(profile, 'coordinator/bank.db'), 'utf8'), 'TRAJECTOIRES')
    assert.equal(
      readFileSync(join(profile, 'coordinator/memory-semantic.json'), 'utf8'),
      '{"client":"semantique"}',
    )
  })
})

// ── sync_claude_md : sauvegarde horodatée de CLAUDE.md (ADR-024, E2-4) ───────

describe('install.sh :: sync_claude_md — sauvegarde horodatée (E2-4)', () => {
  const INSTALL_SH = join(__dirname, '../../../install.sh')

  function makeSourceable(work) {
    const srcSh = readFileSync(INSTALL_SH, 'utf8')
    const out = join(work, 'install-sourceable.sh')
    writeFileSync(out, srcSh.replace(/^main "\$@"$/m, '# main désactivé pour le test'))
    return out
  }

  function run(work, src, dst, { dryRun = false } = {}) {
    const sourceable = makeSourceable(work)
    const script = [
      'set -euo pipefail',
      `source ${JSON.stringify(sourceable)}`,
      `DRY_RUN=${dryRun ? 'true' : 'false'}`,
      `sync_claude_md ${JSON.stringify(src)} ${JSON.stringify(dst)}`,
    ].join('\n')
    return execFileSync('bash', ['-c', script], { encoding: 'utf8', stdio: 'pipe' })
  }

  test('dst absent → copie simple, pas de sauvegarde', () => {
    const work = tmp('claudemd-new')
    const src = write(work, 'src/CLAUDE.md', '# v2\n')
    // Le profil existe déjà (mkdir -p fait par install_profile avant l'appel
    // réel) — seul CLAUDE.md est absent.
    mkdirSync(join(work, 'profile'), { recursive: true })
    const dst = join(work, 'profile/CLAUDE.md')

    const stdout = run(work, src, dst)

    assert.equal(readFileSync(dst, 'utf8'), '# v2\n')
    assert.equal(
      readdirSync(join(work, 'profile')).some((f) => f.includes('.bak.')), false,
      'aucun .bak.* ne doit être créé au premier install',
    )
    assert.match(stdout, /CLAUDE\.md \(nouveau\)/)
  })

  test('dst identique au contenu source → no-op, pas de sauvegarde', () => {
    const work = tmp('claudemd-noop')
    const content = '# identique\n'
    const src = write(work, 'src/CLAUDE.md', content)
    const dst = write(work, 'profile/CLAUDE.md', content)

    const stdout = run(work, src, dst)

    assert.equal(readFileSync(dst, 'utf8'), content, 'contenu inchangé')
    assert.equal(
      readdirSync(join(work, 'profile')).some((f) => f.includes('.bak.')), false,
      'un CLAUDE.md déjà à jour ne doit jamais produire de sauvegarde',
    )
    assert.match(stdout, /déjà à jour/)
  })

  test('dst différent → sauvegarde .bak.<timestamp> PUIS écrasement', () => {
    const work = tmp('claudemd-diff')
    const src = write(work, 'src/CLAUDE.md', '# v2 livrée\n')
    const dst = write(work, 'profile/CLAUDE.md', '# personnalisation client\n')

    const stdout = run(work, src, dst)

    assert.equal(readFileSync(dst, 'utf8'), '# v2 livrée\n', 'la nouvelle version doit finir en place')
    const backups = readdirSync(join(work, 'profile')).filter((f) => /^CLAUDE\.md\.bak\.\d{14}$/.test(f))
    assert.equal(backups.length, 1, 'exactement un fichier de sauvegarde horodaté doit être créé')
    assert.equal(
      readFileSync(join(work, 'profile', backups[0]), 'utf8'), '# personnalisation client\n',
      'la sauvegarde doit contenir la version du CLIENT, pas la nouvelle',
    )
    assert.match(stdout, /sauvegardé/)
  })

  test('--dry-run (nouveau) : rien n est écrit', () => {
    const work = tmp('claudemd-dry-new')
    const src = write(work, 'src/CLAUDE.md', '# v2\n')
    const dst = join(work, 'profile/CLAUDE.md')

    const stdout = run(work, src, dst, { dryRun: true })

    assert.equal(existsSync(dst), false, 'aucun fichier ne doit être créé en --dry-run')
    assert.match(stdout, /\[dry-run\]/)
  })

  test('--dry-run (identique) : disque strictement inchangé', () => {
    const work = tmp('claudemd-dry-noop')
    const content = '# identique\n'
    const src = write(work, 'src/CLAUDE.md', content)
    const dst = write(work, 'profile/CLAUDE.md', content)
    const before = snapshotTree(join(work, 'profile'))

    run(work, src, dst, { dryRun: true })

    assert.deepEqual(snapshotTree(join(work, 'profile')), before)
  })

  test('--dry-run (différent) : aucun .bak créé, CLAUDE.md non modifié', () => {
    const work = tmp('claudemd-dry-diff')
    const src = write(work, 'src/CLAUDE.md', '# v2 livrée\n')
    const dst = write(work, 'profile/CLAUDE.md', '# personnalisation client\n')
    const before = snapshotTree(join(work, 'profile'))

    const stdout = run(work, src, dst, { dryRun: true })

    assert.deepEqual(
      snapshotTree(join(work, 'profile')), before,
      '--dry-run ne doit ni sauvegarder ni écraser',
    )
    assert.equal(readdirSync(join(work, 'profile')).some((f) => f.includes('.bak.')), false)
    assert.match(stdout, /\[dry-run\].*sauvegardé/)
  })
})

// ── merge_settings : env + preferences (ADR-024, E2-6) ────────────────────────

describe('install.sh :: merge_settings — hooks + permissions.deny + env + preferences', () => {
  const INSTALL_SH = join(__dirname, '../../../install.sh')

  function merge(srcObj, dstObj) {
    const work = tmp('merge-settings')
    const src = write(work, 'src.json', JSON.stringify(srcObj))
    const dst = write(work, 'dst.json', JSON.stringify(dstObj))

    const srcSh = readFileSync(INSTALL_SH, 'utf8')
    const sourceable = join(work, 'install-sourceable.sh')
    writeFileSync(sourceable, srcSh.replace(/^main "\$@"$/m, '# main désactivé pour le test'))

    const script = [
      'set -euo pipefail',
      `source ${JSON.stringify(sourceable)}`,
      `merge_settings ${JSON.stringify(src)} ${JSON.stringify(dst)}`,
    ].join('\n')
    const stdout = execFileSync('bash', ['-c', script], { encoding: 'utf8', stdio: 'pipe' })
    return { result: JSON.parse(readFileSync(dst, 'utf8')), stdout }
  }

  test('régression — hooks : union dédoublonnée comme avant', () => {
    const { result } = merge(
      { hooks: { PreToolUse: [{ matcher: 'Bash', hooks: [{ type: 'command', command: 'echo new' }] }] } },
      { hooks: { PreToolUse: [{ matcher: 'Bash', hooks: [{ type: 'command', command: 'echo old' }] }] } },
    )
    assert.equal(result.hooks.PreToolUse.length, 2, 'les deux handlers distincts doivent coexister')
  })

  test('régression — hooks : un handler déjà identique n est pas dupliqué', () => {
    const entry = { matcher: 'Bash', hooks: [{ type: 'command', command: 'echo same' }] }
    const { result } = merge(
      { hooks: { PreToolUse: [entry] } },
      { hooks: { PreToolUse: [{ matcher: 'Bash', hooks: [{ type: 'command', command: 'echo same' }] }] } },
    )
    assert.equal(result.hooks.PreToolUse.length, 1)
  })

  test('régression — permissions.deny : union additive, jamais de retrait', () => {
    const { result } = merge(
      { permissions: { deny: ['Bash(rm)', 'Bash(new-rule)'] } },
      { permissions: { deny: ['Bash(rm)', 'Bash(client-rule)'] } },
    )
    assert.deepEqual(
      new Set(result.permissions.deny),
      new Set(['Bash(rm)', 'Bash(client-rule)', 'Bash(new-rule)']),
    )
  })

  test('régression — permissions.allow n est jamais touché', () => {
    const { result } = merge(
      { permissions: { allow: ['Bash(ada-allow)'] } },
      { permissions: { allow: ['Bash(client-allow)'] } },
    )
    assert.deepEqual(result.permissions.allow, ['Bash(client-allow)'])
  })

  test('env : nouvelle clé ajoutée', () => {
    const { result } = merge({ env: { NEW_KEY: '1' } }, { env: {} })
    assert.equal(result.env.NEW_KEY, '1')
  })

  test('env : clé existante même valeur → dst inchangé', () => {
    const { result } = merge({ env: { KEY: 'v' } }, { env: { KEY: 'v' } })
    assert.equal(result.env.KEY, 'v')
  })

  test('env : clé existante valeur différente → valeur CLIENT préservée + conflit signalé', () => {
    const { result, stdout } = merge({ env: { KEY: 'ada-value' } }, { env: { KEY: 'client-value' } })
    assert.equal(result.env.KEY, 'client-value', 'la valeur client ne doit jamais être écrasée')
    assert.match(stdout, /[Cc]onflit/)
    assert.match(stdout, /env\.KEY/)
    assert.match(stdout, /client-value/)
    assert.match(stdout, /ada-value/)
  })

  test('env : clé propre au client (absente de la source) intouchée', () => {
    const { result } = merge({ env: {} }, { env: { CLIENT_ONLY: 'x' } })
    assert.equal(result.env.CLIENT_ONLY, 'x')
  })

  test('preferences : nouvelle clé ajoutée', () => {
    const { result } = merge({ preferences: { newPref: true } }, { preferences: {} })
    assert.equal(result.preferences.newPref, true)
  })

  test('preferences : clé existante même valeur → dst inchangé', () => {
    const { result } = merge(
      { preferences: { tmuxSplitPanes: true } },
      { preferences: { tmuxSplitPanes: true } },
    )
    assert.equal(result.preferences.tmuxSplitPanes, true)
  })

  test('preferences : clé existante valeur différente → valeur CLIENT préservée + conflit signalé', () => {
    const { result, stdout } = merge(
      { preferences: { tmuxSplitPanes: true } },
      { preferences: { tmuxSplitPanes: false } },
    )
    assert.equal(result.preferences.tmuxSplitPanes, false)
    assert.match(stdout, /[Cc]onflit/)
    assert.match(stdout, /preferences\.tmuxSplitPanes/)
  })

  test('dst sans clés env/preferences préexistantes : copiées sans conflit', () => {
    const { result, stdout } = merge({ env: { A: '1' }, preferences: { p: 1 } }, {})
    assert.equal(result.env.A, '1')
    assert.equal(result.preferences.p, 1)
    assert.doesNotMatch(stdout, /[Cc]onflit/)
  })
})

// ── detect_profiles : ~/.claude doit être vu (E1-A) ───────────────────────────

describe('install.sh :: detect_profiles — HOME FICTIF', () => {
  const INSTALL_SH = join(__dirname, '../../../install.sh')

  function detect(homeLayout) {
    const work = tmp('detect')
    const home = join(work, 'home')
    mkdirSync(home, { recursive: true })
    for (const d of homeLayout) mkdirSync(join(home, d), { recursive: true })

    const srcSh = readFileSync(INSTALL_SH, 'utf8')
    const sourceable = join(work, 'install-sourceable.sh')
    writeFileSync(sourceable, srcSh.replace(/^main "\$@"$/m, '# main désactivé'))

    const script = [
      'set -euo pipefail',
      `source ${JSON.stringify(sourceable)}`,
      `HOME=${JSON.stringify(home)}`,
      'NONINTERACTIVE=true',
      'detect_profiles',
      // Marqueur : detect_profiles écrit aussi des lignes d'information sur
      // stdout, il faut isoler la liste des profils.
      'for p in ${PROFILES[@]+"${PROFILES[@]}"}; do echo "PROFILE:$(basename "$p")"; done',
    ].join('\n')

    return execFileSync('bash', ['-c', script], { encoding: 'utf8', stdio: 'pipe' })
      .split('\n')
      .map((s) => s.trim())
      .filter((s) => s.startsWith('PROFILE:'))
      .map((s) => s.slice('PROFILE:'.length))
      .sort()
  }

  test('détecte ~/.claude en plus des ~/.claude-*', () => {
    const out = detect(['.claude', '.claude-pro', '.claude-perso'])
    assert.deepEqual(out, ['.claude', '.claude-perso', '.claude-pro'])
  })

  test('~/.claude s ajoute à la liste, il ne la remplace pas', () => {
    const out = detect(['.claude', '.claude-pro'])
    assert.ok(out.includes('.claude'))
    assert.ok(out.includes('.claude-pro'))
    assert.equal(out.length, 2)
  })

  test('détecte ~/.claude seul (sans aucun ~/.claude-*) sans rien créer', () => {
    const out = detect(['.claude'])
    assert.deepEqual(out, ['.claude'])
  })

  test('les ~/.claude-* seuls fonctionnent comme avant', () => {
    const out = detect(['.claude-pro', '.claude-ov'])
    assert.deepEqual(out, ['.claude-ov', '.claude-pro'])
  })

  test('aucun profil → création du profil par défaut (non interactif)', () => {
    const out = detect([])
    assert.deepEqual(out, ['.claude-ada'])
  })
})

// ── select_profiles : Cas 3 corrigé + expansion de périmètre (ADR-024, E1-B) ──

describe('install.sh :: select_profiles — Cas 3 corrigé + expansion de périmètre (E1-B)', () => {
  const INSTALL_SH = join(__dirname, '../../../install.sh')

  function makeSourceable(work) {
    const srcSh = readFileSync(INSTALL_SH, 'utf8')
    const out = join(work, 'install-sourceable.sh')
    writeFileSync(out, srcSh.replace(/^main "\$@"$/m, '# main désactivé pour le test'))
    return out
  }

  /**
   * @param {{homeDirs: string[], installedProfiles?: string[], nonInteractive?: boolean, stdin?: string}} opts
   */
  function runSelect({ homeDirs, installedProfiles, nonInteractive = false, stdin = '' }) {
    const work = tmp('select')
    const home = join(work, 'home')
    mkdirSync(home, { recursive: true })
    for (const d of homeDirs) mkdirSync(join(home, d), { recursive: true })

    const adaConfig = join(home, '.ada.json')
    if (installedProfiles) {
      writeFileSync(adaConfig, JSON.stringify({ installedProfiles }))
    }

    const script = [
      'set -euo pipefail',
      `source ${JSON.stringify(makeSourceable(work))}`,
      `HOME=${JSON.stringify(home)}`,
      `ADA_CONFIG=${JSON.stringify(adaConfig)}`,
      `NONINTERACTIVE=${nonInteractive ? 'true' : 'false'}`,
      'detect_profiles',
      'select_profiles',
      'echo "___SELECTED_START___"',
      'for p in ${SELECTED[@]+"${SELECTED[@]}"}; do basename "$p"; done',
      'echo "___SELECTED_END___"',
    ].join('\n')

    const stdout = execFileSync('bash', ['-c', script], {
      encoding: 'utf8', stdio: 'pipe', input: stdin, timeout: 5000,
    })
    const selected = stdout
      .split('___SELECTED_START___\n')[1]
      .split('___SELECTED_END___')[0]
      .split('\n')
      .filter(Boolean)
      .sort()
    return { stdout, selected }
  }

  test('cfg.installedProfiles == disque exactement → sélection directe, AUCUNE lecture interactive (Cas 3, pas de prompt)', () => {
    // stdin vide : si le code retombait par erreur dans le flux interactif
    // (Cas 4), le `read -r input` échouerait sur EOF et ferait échouer le
    // script sous `set -e` — la réussite de ce test prouve l'absence de prompt.
    const { stdout, selected } = runSelect({
      homeDirs: ['.claude-pro', '.claude-perso'],
      installedProfiles: ['claude-pro', 'claude-perso'],
      nonInteractive: false,
      stdin: '',
    })
    assert.deepEqual(selected, ['.claude-perso', '.claude-pro'])
    assert.match(stdout, /réinstallation des 2 profil\(s\) déjà connu\(s\) de ~\/\.ada\.json/)
  })

  test('cfg.installedProfiles = sous-ensemble strict du disque → interactif, confirmer la présélection ne sélectionne QUE le sous-ensemble connu', () => {
    const { stdout, selected } = runSelect({
      homeDirs: ['.claude-pro', '.claude-perso', '.claude-extra'],
      installedProfiles: ['claude-pro', 'claude-perso'],
      nonInteractive: false,
      stdin: '\n', // confirme la présélection sans rien toggle
    })
    assert.deepEqual(selected, ['.claude-perso', '.claude-pro'],
      '.claude-extra (hors cfg.installedProfiles) ne doit jamais être inclus silencieusement')
    assert.match(stdout, /confirme ta sélection/)
  })

  test('expansion de périmètre en mode non-interactif (--all) : incluse quand même, message distinguant nommément connus et nouveaux', () => {
    const { stdout, selected } = runSelect({
      homeDirs: ['.claude-pro', '.claude-extra'],
      installedProfiles: ['claude-pro'],
      nonInteractive: true,
    })
    assert.deepEqual(selected, ['.claude-extra', '.claude-pro'],
      'mode non-interactif : le profil hors cfg.installedProfiles doit être inclus')
    // Le message doit distinguer nommément "connu(s)" et "nouveau(x)" — jamais
    // un message générique unique qui les confondrait (E1-B).
    assert.match(stdout, /1 profil\(s\) déjà connu\(s\) de ~\/\.ada\.json \(\.claude-pro\)/)
    assert.match(stdout, /1 nouveau\(x\) profil\(s\) ajouté\(s\) à ce run \(\.claude-extra\)/)
  })

  test('expansion de périmètre en mode interactif : bascule sur le flux interactif (Cas 4), pas de retour anticipé silencieux', () => {
    const { stdout, selected } = runSelect({
      homeDirs: ['.claude-pro', '.claude-extra'],
      installedProfiles: ['claude-pro'],
      nonInteractive: false,
      stdin: 'a\n\n', // 'a' coche tout, Entrée confirme (boucle du menu existant)
    })
    // La preuve que Cas 4 (et non un retour anticipé) a été atteint : le menu
    // de sélection numéroté apparaît sur stdout.
    assert.match(stdout, /Profils détectés — sélectionne les profils à installer/)
    assert.match(stdout, /\[numéro\]/)
    assert.deepEqual(selected, ['.claude-extra', '.claude-pro'])
  })

  test('expansion de périmètre en mode interactif : la présélection (Entrée directe) ne coche que les profils déjà connus', () => {
    const { selected } = runSelect({
      homeDirs: ['.claude-pro', '.claude-extra'],
      installedProfiles: ['claude-pro'],
      nonInteractive: false,
      stdin: '\n',
    })
    assert.deepEqual(selected, ['.claude-pro'],
      '.claude-extra doit apparaître décoché par défaut, pas sélectionné sans confirmation explicite')
  })
})

// ── print_install_plan : plan affiché avant toute écriture (ADR-024, E1-E) ──

describe('install.sh :: print_install_plan — plan premier-install/mise à jour (E1-E)', () => {
  const INSTALL_SH = join(__dirname, '../../../install.sh')

  function makeSourceable(work) {
    const srcSh = readFileSync(INSTALL_SH, 'utf8')
    const out = join(work, 'install-sourceable.sh')
    writeFileSync(out, srcSh.replace(/^main "\$@"$/m, '# main désactivé pour le test'))
    return out
  }

  /**
   * @param {{profiles: Array<{version?: string}>, adaVersion?: string,
   *   nonInteractive?: boolean, scopeExpanded?: boolean, stdin?: string}} opts
   */
  function runPlan({ profiles, adaVersion = '9.9.9', nonInteractive = false, scopeExpanded = false, stdin = '' }) {
    const work = tmp('plan')
    const profileDirs = profiles.map((p, i) => {
      const dir = join(work, `profil-${i}`)
      mkdirSync(dir, { recursive: true })
      if (p.version !== undefined) writeFileSync(join(dir, 'VERSION'), p.version + '\n')
      return dir
    })

    const script = [
      'set -euo pipefail',
      `source ${JSON.stringify(makeSourceable(work))}`,
      `ADA_VERSION=${JSON.stringify(adaVersion)}`,
      `NONINTERACTIVE=${nonInteractive ? 'true' : 'false'}`,
      `SCOPE_EXPANDED=${scopeExpanded ? 'true' : 'false'}`,
      `SELECTED=(${profileDirs.map((d) => JSON.stringify(d)).join(' ')})`,
      'print_install_plan',
      'echo "___PLAN_DONE___"',
    ].join('\n')

    const stdout = execFileSync('bash', ['-c', script], {
      encoding: 'utf8', stdio: 'pipe', input: stdin, timeout: 5000,
    })
    return { stdout, doneReached: stdout.includes('___PLAN_DONE___') }
  }

  test('VERSION absent → "[premier install]"', () => {
    const { stdout } = runPlan({ profiles: [{}], nonInteractive: true })
    assert.match(stdout, /premier install/)
  })

  test('VERSION présent et différent de ADA_VERSION → mention explicite de la mise à jour A → B', () => {
    const { stdout } = runPlan({ profiles: [{ version: '1.0.0' }], adaVersion: '9.9.9', nonInteractive: true })
    assert.match(stdout, /mise à jour/)
    assert.match(stdout, /1\.0\.0/)
    assert.match(stdout, /9\.9\.9/)
  })

  test('VERSION présent et identique à ADA_VERSION → "déjà à jour"', () => {
    const { stdout } = runPlan({ profiles: [{ version: '9.9.9' }], adaVersion: '9.9.9', nonInteractive: true })
    assert.match(stdout, /déjà à jour/)
  })

  test('profil déjà à jour, mode interactif, PAS de premier install ni d expansion → aucune confirmation demandée (pas de blocage sur read)', () => {
    // stdin vide : si une confirmation était demandée à tort, `read -rp`
    // échouerait sur EOF sous `set -e` et le script s'arrêterait avant
    // d'atteindre ___PLAN_DONE___.
    const { stdout, doneReached } = runPlan({
      profiles: [{ version: '9.9.9' }], adaVersion: '9.9.9', nonInteractive: false, stdin: '',
    })
    assert.ok(doneReached, 'print_install_plan ne doit pas lire sur stdin quand rien ne le justifie')
    assert.match(stdout, /déjà à jour/)
  })

  test('premier install détecté, mode interactif, réponse "n" → installation annulée (exit 0), rien après', () => {
    const { stdout, doneReached } = runPlan({
      profiles: [{}], nonInteractive: false, stdin: 'n\n',
    })
    assert.match(stdout, /[Aa]nnulée/)
    assert.ok(!doneReached, 'exit 0 explicite avant ___PLAN_DONE___')
  })

  test('premier install détecté, mode interactif, réponse "y" → confirmation acceptée, la suite s exécute', () => {
    const { doneReached } = runPlan({
      profiles: [{}], nonInteractive: false, stdin: 'y\n',
    })
    assert.ok(doneReached)
  })

  test('expansion de périmètre seule (SCOPE_EXPANDED, sans premier install) déclenche aussi la confirmation', () => {
    const { stdout, doneReached } = runPlan({
      profiles: [{ version: '9.9.9' }], adaVersion: '9.9.9',
      nonInteractive: false, scopeExpanded: true, stdin: 'n\n',
    })
    assert.match(stdout, /[Aa]nnulée/)
    assert.ok(!doneReached)
  })

  test('mode non-interactif : le plan est affiché mais jamais bloquant, même avec un premier install', () => {
    const { stdout, doneReached } = runPlan({ profiles: [{}], nonInteractive: true, stdin: '' })
    assert.ok(doneReached)
    assert.match(stdout, /premier install/)
  })

  test('plusieurs profils dans SELECTED : chacun reçoit sa propre ligne de statut', () => {
    const { stdout } = runPlan({
      profiles: [{}, { version: '9.9.9' }, { version: '1.0.0' }],
      adaVersion: '9.9.9',
      nonInteractive: true,
    })
    assert.match(stdout, /profil-0.*\[premier install\]/)
    assert.match(stdout, /profil-1.*\[déjà à jour, v9\.9\.9\]/)
    assert.match(stdout, /profil-2.*\[mise à jour v1\.0\.0 → v9\.9\.9\]/)
  })
})

// ── write_env_local : ADA_ACTIVE_PROFILE = vrai activeProfile, pas le 1er
//    profil de la sélection en cours (ADR-024, addendum défauts validation
//    réelle, 2026-08-11) ──────────────────────────────────────────────────

describe('install.sh :: write_env_local — ADA_ACTIVE_PROFILE reflète cfg.activeProfile, pas installed_profiles[0] (addendum défaut 1)', () => {
  const INSTALL_SH = join(__dirname, '../../../install.sh')

  function makeSourceable(work) {
    const srcSh = readFileSync(INSTALL_SH, 'utf8')
    const out = join(work, 'install-sourceable.sh')
    writeFileSync(out, srcSh.replace(/^main "\$@"$/m, '# main désactivé pour le test'))
    return out
  }

  /**
   * @param {{selectedProfiles: string[], adaJson?: object, dryRun?: boolean}} opts
   *   selectedProfiles : basenames SANS le point, ex. ['claude-jarvis'] — la
   *   sélection en cours passée en arguments à write_env_local (SELECTED[@]).
   */
  function run({ selectedProfiles, adaJson, dryRun = false }) {
    const work = tmp('env-local')
    const home = join(work, 'home')
    mkdirSync(home, { recursive: true })
    for (const name of selectedProfiles) mkdirSync(join(home, `.${name}`), { recursive: true })
    mkdirSync(join(work, 'ada-ui'), { recursive: true })

    const adaConfig = join(home, '.ada.json')
    if (adaJson) writeFileSync(adaConfig, JSON.stringify(adaJson))

    const selectedDirs = selectedProfiles.map((n) => join(home, `.${n}`))

    const script = [
      'set -euo pipefail',
      `source ${JSON.stringify(makeSourceable(work))}`,
      `SOURCE_DIR=${JSON.stringify(work)}`,
      `HOME=${JSON.stringify(home)}`,
      `ADA_CONFIG=${JSON.stringify(adaConfig)}`,
      `DRY_RUN=${dryRun ? 'true' : 'false'}`,
      `write_env_local ${selectedDirs.map((d) => JSON.stringify(d)).join(' ')}`,
    ].join('\n')

    const stdout = execFileSync('bash', ['-c', script], { encoding: 'utf8', stdio: 'pipe' })
    const envFile = join(work, 'ada-ui/.env.local')
    const envContent = existsSync(envFile) ? readFileSync(envFile, 'utf8') : null
    return { stdout, envContent }
  }

  test('~/.ada.json a un activeProfile déjà défini différent du profil en cours d installation → .env.local reflète activeProfile, PAS le profil en cours (régression du bug réel contre ~/.claude-jarvis)', () => {
    // Reproduit exactement le scénario réel : 4 profils connus, activeProfile
    // = ov, maintenance d'UN SEUL profil parmi les 4 (jarvis) via --profile.
    const { envContent } = run({
      selectedProfiles: ['claude-jarvis'],
      adaJson: {
        installedProfiles: ['claude-perso', 'claude-pro', 'claude-ov', 'claude-jarvis'],
        activeProfile: 'claude-ov',
      },
    })
    assert.match(envContent, /^ADA_ACTIVE_PROFILE=ov$/m)
    assert.doesNotMatch(envContent, /jarvis/,
      'le profil en cours de maintenance ne doit jamais écraser silencieusement l activeProfile réel')
  })

  test('~/.ada.json absent (bootstrap, premier install) → .env.local reflète le premier profil installé (comportement actuel préservé)', () => {
    const { envContent } = run({ selectedProfiles: ['claude-ada'] })
    assert.match(envContent, /^ADA_ACTIVE_PROFILE=ada$/m)
  })

  test('~/.ada.json présent mais sans activeProfile (cas limite bootstrap) → .env.local reflète le premier profil de la sélection', () => {
    const { envContent } = run({
      selectedProfiles: ['claude-pro'],
      adaJson: { installedProfiles: ['claude-pro'] },
    })
    assert.match(envContent, /^ADA_ACTIVE_PROFILE=pro$/m)
  })

  test('--dry-run : le message annonce la valeur qui serait RÉELLEMENT appliquée (activeProfile existant), disque inchangé', () => {
    const { stdout, envContent } = run({
      selectedProfiles: ['claude-jarvis'],
      adaJson: { installedProfiles: ['claude-ov', 'claude-jarvis'], activeProfile: 'claude-ov' },
      dryRun: true,
    })
    assert.match(stdout, /\[dry-run\].*ADA_ACTIVE_PROFILE=ov/)
    assert.doesNotMatch(stdout, /ADA_ACTIVE_PROFILE=jarvis/)
    assert.equal(envContent, null, 'aucun fichier ne doit être écrit en --dry-run')
  })
})

// ── write_ada_config : message dry-run reflète l'union réelle, pas la seule
//    sélection en cours (ADR-024, addendum défauts validation réelle,
//    2026-08-11) ───────────────────────────────────────────────────────────

describe('install.sh :: write_ada_config — dry-run annonce l union réelle (addendum défaut 2)', () => {
  const INSTALL_SH = join(__dirname, '../../../install.sh')

  function makeSourceable(work) {
    const srcSh = readFileSync(INSTALL_SH, 'utf8')
    const out = join(work, 'install-sourceable.sh')
    writeFileSync(out, srcSh.replace(/^main "\$@"$/m, '# main désactivé pour le test'))
    return out
  }

  /**
   * @param {{selectedProfiles: string[], adaJson?: object, dryRun?: boolean,
   *   extraDiskProfiles?: string[]}} opts
   *   selectedProfiles : basenames sans point de la sélection EN COURS
   *   (SELECTED[@] passé à write_ada_config).
   *   extraDiskProfiles : profils supplémentaires créés sur disque mais PAS
   *   passés à write_ada_config (pour vérifier le filtre fs.existsSync sur
   *   des profils connus de ~/.ada.json qui existent toujours, ou pour
   *   simuler un profil connu mais supprimé du disque).
   */
  function run({ selectedProfiles, adaJson, dryRun = true, extraDiskProfiles = [] }) {
    const work = tmp('ada-config')
    const home = join(work, 'home')
    mkdirSync(home, { recursive: true })
    for (const name of selectedProfiles) mkdirSync(join(home, `.${name}`), { recursive: true })
    for (const name of extraDiskProfiles) mkdirSync(join(home, `.${name}`), { recursive: true })

    const adaConfig = join(home, '.ada.json')
    if (adaJson) writeFileSync(adaConfig, JSON.stringify(adaJson))

    const selectedDirs = selectedProfiles.map((n) => join(home, `.${n}`))

    const script = [
      'set -euo pipefail',
      `source ${JSON.stringify(makeSourceable(work))}`,
      `SOURCE_DIR=${JSON.stringify(work)}`,
      `CLAUDE_DIR=${JSON.stringify(join(work, '.claude'))}`,
      `HOME=${JSON.stringify(home)}`,
      `ADA_CONFIG=${JSON.stringify(adaConfig)}`,
      'ADA_VERSION="9.9.9"',
      `DRY_RUN=${dryRun ? 'true' : 'false'}`,
      `write_ada_config ${selectedDirs.map((d) => JSON.stringify(d)).join(' ')}`,
    ].join('\n')

    const stdout = execFileSync('bash', ['-c', script], { encoding: 'utf8', stdio: 'pipe' })
    const cfg = existsSync(adaConfig) ? JSON.parse(readFileSync(adaConfig, 'utf8')) : null
    return { stdout, cfg }
  }

  test('dry-run : ~/.ada.json a plusieurs profils connus, un seul sélectionné dans ce run → le message annonce l UNION complète (existants + nouveau), PAS seulement la sélection en cours (régression du bug réel)', () => {
    // Reproduit exactement le scénario réel : bash install.sh --profile
    // claude-jarvis --dry-run, avec 4 profils déjà connus dont jarvis.
    const { stdout, cfg } = run({
      selectedProfiles: ['claude-jarvis'],
      adaJson: {
        installedProfiles: ['claude-perso', 'claude-pro', 'claude-ov', 'claude-jarvis'],
        activeProfile: 'claude-ov',
      },
      // Les 3 autres profils connus doivent aussi exister sur disque (comme
      // dans le scénario réel) — sinon le filtre fs.existsSync (comportement
      // réel, pas un bug) les élaguerait légitimement de l'union.
      extraDiskProfiles: ['claude-perso', 'claude-pro', 'claude-ov'],
      dryRun: true,
    })
    assert.match(stdout, /4 profil\(s\) déjà connu\(s\)/)
    assert.match(stdout, /claude-perso/)
    assert.match(stdout, /claude-pro/)
    assert.match(stdout, /claude-ov/)
    assert.match(stdout, /claude-jarvis/)
    assert.doesNotMatch(stdout, /installedProfiles=\["claude-jarvis"\]/,
      'le message ne doit jamais laisser croire que les 3 autres profils seraient retirés')
    assert.deepEqual(cfg, {
      installedProfiles: ['claude-perso', 'claude-pro', 'claude-ov', 'claude-jarvis'],
      activeProfile: 'claude-ov',
    }, 'un --dry-run ne doit écrire strictement rien sur disque')
  })

  test('dry-run : activeProfile affiché reste celui déjà présent dans ~/.ada.json, pas celui de la sélection en cours', () => {
    const { stdout } = run({
      selectedProfiles: ['claude-jarvis'],
      adaJson: { installedProfiles: ['claude-ov', 'claude-jarvis'], activeProfile: 'claude-ov' },
      dryRun: true,
    })
    assert.match(stdout, /activeProfile=claude-ov/)
    assert.doesNotMatch(stdout, /activeProfile=claude-jarvis/)
    assert.match(stdout, /inchangé/)
  })

  test('dry-run : un profil de la sélection en cours absent de ~/.ada.json est annoncé nommément comme nouveau, distinct des profils déjà connus', () => {
    const { stdout } = run({
      selectedProfiles: ['claude-extra'],
      adaJson: { installedProfiles: ['claude-pro'], activeProfile: 'claude-pro' },
      extraDiskProfiles: ['claude-pro'],
      dryRun: true,
    })
    assert.match(stdout, /1 profil\(s\) déjà connu\(s\) \(claude-pro, inchangé\(s\)\)/)
    assert.match(stdout, /1 nouveau\(x\) profil\(s\) ajouté\(s\) à ce run \(claude-extra\)/)
  })

  test('dry-run : premier install (~/.ada.json absent) → activeProfile annoncé "défini pour la première fois", installedProfiles = uniquement le(s) nouveau(x)', () => {
    const { stdout, cfg } = run({ selectedProfiles: ['claude-ada'], dryRun: true })
    assert.match(stdout, /activeProfile=claude-ada/)
    assert.match(stdout, /première fois/)
    assert.match(stdout, /1 nouveau\(x\) profil\(s\) \(claude-ada\)/)
    assert.equal(cfg, null, 'aucun ~\\/.ada.json ne doit être créé en --dry-run')
  })

  test('non-régression — comportement RÉEL (non-dry-run) inchangé : union complète appliquée, activeProfile jamais réécrit s il existe déjà', () => {
    const { cfg } = run({
      selectedProfiles: ['claude-jarvis'],
      adaJson: {
        installedProfiles: ['claude-perso', 'claude-pro', 'claude-ov', 'claude-jarvis'],
        activeProfile: 'claude-ov',
      },
      extraDiskProfiles: ['claude-perso', 'claude-pro', 'claude-ov'],
      dryRun: false,
    })
    assert.deepEqual(
      [...cfg.installedProfiles].sort(),
      ['claude-jarvis', 'claude-ov', 'claude-perso', 'claude-pro'],
      'un run de maintenance sur un seul profil ne doit jamais retirer les autres profils connus',
    )
    assert.equal(cfg.activeProfile, 'claude-ov', 'activeProfile déjà défini ne doit jamais être réécrit')
  })

  test('non-régression — comportement RÉEL : un profil connu supprimé du disque est élagué de installedProfiles', () => {
    const { cfg } = run({
      selectedProfiles: ['claude-jarvis'],
      // 'claude-pro' est connu de ~/.ada.json mais n'existe PAS sur disque
      // (extraDiskProfiles vide) → doit être élagué par le filtre existsSync.
      adaJson: { installedProfiles: ['claude-pro', 'claude-jarvis'], activeProfile: 'claude-jarvis' },
      dryRun: false,
    })
    assert.deepEqual(cfg.installedProfiles, ['claude-jarvis'])
  })
})
