#!/usr/bin/env node
'use strict'
/**
 * tests/scripts/capability-matrix.test.js — Garde anti-dérive du README (F8b)
 *
 * Finding F8 de l'audit (docs/AUDIT-ADA-2026-09-09.md) : le README affirme des
 * chiffres (agents, skills, hooks, profils, serveurs MCP…) et des versions
 * (Next.js, PostgreSQL…) sans garantie qu'ils reflètent l'état réel du dépôt.
 * F8a a corrigé le titre, la version Next.js de l'ADA UI et retiré le
 * comparatif ADA/Ruflo non reproductible — à la main, une fois. F8b rend la
 * correction des CHIFFRES durable : `.claude/scripts/generate-capability-matrix.js`
 * calcule chaque compteur depuis les fichiers réels et expose `--check`.
 *
 * CE TEST (comme `tests/meta/run-all-suites-drift.test.js`, même famille de
 * garde) :
 *   - lance `generate-capability-matrix.js --check` sur le VRAI README.md du
 *     dépôt et échoue si le code de sortie n'est pas 0 (README dérivé) ;
 *   - vérifie aussi le sens inverse sur un README JETABLE construit dans
 *     os.tmpdir() : un chiffre volontairement faux fait échouer `--check`
 *     (RED), et `generate-capability-matrix.js` (sans `--check`) le corrige
 *     puis `--check` repasse au vert (GREEN) — preuve que le script détecte ET
 *     corrige réellement une dérive, pas seulement sur le README déjà bon.
 *
 * N'exécute PAS le require() direct du générateur pour le test "vrai README" :
 * comme run-all.js le fait pour ses propres suites, on passe par un process
 * séparé (spawnSync) pour obtenir un code de sortie propre et une sortie
 * capturée, sans dépendre de l'état interne du module.
 */

const { test, describe } = require('node:test')
const assert = require('node:assert/strict')
const { spawnSync } = require('node:child_process')
const { mkdtempSync, mkdirSync, writeFileSync, readFileSync, rmSync } = require('node:fs')
const { tmpdir } = require('node:os')
const { join } = require('node:path')

const REPO_ROOT = join(__dirname, '..', '..', '..')
const GENERATOR = join(REPO_ROOT, '.claude', 'scripts', 'generate-capability-matrix.js')
const REAL_README = join(REPO_ROOT, 'README.md')

function runGenerator(args) {
  return spawnSync(process.execPath, [GENERATOR, ...args], { encoding: 'utf8' })
}

describe('generate-capability-matrix.js --check sur le vrai README.md du dépôt', () => {
  test('le README committé ne doit pas avoir dérivé de l\'état réel du dépôt', () => {
    const r = runGenerator(['--check'])
    if (r.status !== 0) {
      assert.fail(
        `README.md a dérivé de l'état réel du dépôt (finding F8) :\n${r.stdout}${r.stderr}\n\n` +
        'Corrige avec : node .claude/scripts/generate-capability-matrix.js',
      )
    }
  })

  test('le README committé contient bien le bloc CAPABILITY-MATRIX généré', () => {
    const content = readFileSync(REAL_README, 'utf8')
    assert.ok(content.includes('<!-- CAPABILITY-MATRIX:START -->'), 'marqueur START absent')
    assert.ok(content.includes('<!-- CAPABILITY-MATRIX:END -->'), 'marqueur END absent')
  })
})

describe('generate-capability-matrix.js — RED (README jetable dérivé) → GREEN (corrigé)', () => {
  /**
   * Construit une copie MINIMALE mais réaliste du dépôt sous os.tmpdir() :
   * assez de fichiers réels pour que chaque fonction compute* de
   * generate-capability-matrix.js s'exécute sans lever, avec des comptes
   * volontairement petits et connus (pas ceux du vrai dépôt).
   */
  function buildFixtureRepo() {
    const root = mkdtempSync(join(tmpdir(), 'ada-capmatrix-'))

    const write = (rel, content) => {
      const abs = join(root, rel)
      mkdirSync(join(abs, '..'), { recursive: true })
      writeFileSync(abs, content)
    }

    // 2 agents ADA natifs (fichiers) + 1 agent Ruflo (fichier) + 1 agent ADA
    // en dossier (CLAUDE.md, prime sur un éventuel doublon fichier)
    write('.claude/agents/nestjs.md', '# nestjs\nAgent natif.\n')
    write('.claude/agents/db.md', '# db\nAgent natif.\n')
    write('.claude/agents/agent-coder.md', '# agent-coder\nAdapté de Ruflo (Claude Flow).\n')
    write('.claude/agents/reviewer/CLAUDE.md', '# reviewer\nAgent natif en dossier.\n')
    write('.claude/agents/README-ruflo-agents.md', '# Notes internes (ne doit pas être compté)\n')
    // lazy-loading : full/stubs doivent correspondre au total ADA natif (3)
    for (const name of ['nestjs', 'db', 'reviewer']) {
      write(`.claude/agents/full/${name}.md`, `# ${name} (full)\n`)
      write(`.claude/agents/stubs/${name}.md`, `# ${name} (stub)\n`)
    }

    // 3 skills sous 2 dossiers
    write('.claude/skills/nestjs/create-module.md', 'skill 1')
    write('.claude/skills/nestjs/create-guard.md', 'skill 2')
    write('.claude/skills/db/create-table.md', 'skill 3')

    // 2 slash commands (1 dev, 1 saas)
    write('.claude/commands/test.md', '# /test\n')
    write('.claude/commands/saas-init.md', 'STACK = NestJS + Next.js 15 + PostgreSQL (défaut)\nStack : NestJS 10 + Next.js 15 + PostgreSQL + Prisma + Redis\n')

    // 2 hooks : un câblé (settings.json), un orphelin
    write('.claude/hooks/pre-bash.js', '#!/usr/bin/env node\n// pre-bash.js — PreToolUse\nconsole.log("ok")\n')
    write('.claude/hooks/orphan-hook.js', '#!/usr/bin/env node\n// orphan-hook.js — jamais référencé\nconsole.log("ok")\n')
    write('.claude/settings.json', JSON.stringify({
      hooks: {
        PreToolUse: [{ matcher: 'Bash', hooks: [{ command: 'node hooks/pre-bash.js', statusMessage: 'Contrôle (pre-bash)' }] }],
      },
    }))

    // profiles.json : 1 natif + 1 ruflo dérivé + 1 stack
    write('.claude/teams/profiles.json', JSON.stringify({
      team_profiles: {
        _cluster_native: null, fullstack: {},
        _cluster_swarm: null, 'swarm-hierarchical': {},
      },
      stack_profiles: { 'nestjs-next': {} },
    }))

    // mcp/mcp-servers.json : 2 serveurs
    write('mcp/mcp-servers.json', JSON.stringify({
      mcpServers: {
        github: { command: 'npx', args: ['-y', '@modelcontextprotocol/server-github'] },
        docker: { command: 'npx', args: ['-y', 'mcp-server-docker'] },
      },
    }))

    // workers/daemon.js : DEFAULT_SCHEDULE avec 2 workers
    write('.claude/workers/daemon.js', [
      "const DEFAULT_SCHEDULE = {",
      "  ultralearn:  6 * 60 * 60 * 1000,",
      "  consolidate: 2 * 60 * 60 * 1000,",
      "}",
    ].join('\n'))

    // versions : install.sh, ada-api-nest, ada-ui, docker-compose
    write('install.sh', 'if [[ "$node_major" -lt 22 ]]; then\n  exit 1\nfi\n')
    write('ada-api-nest/package.json', JSON.stringify({ dependencies: { '@nestjs/core': '^10.4.15' } }))
    write('ada-ui/package.json', JSON.stringify({ dependencies: { next: '16.2.6' } }))
    write('ada-api-nest/docker-compose.yml', 'services:\n  postgres:\n    image: postgres:16-alpine\n')

    // Fichiers requis par computeCapabilities (grep de présence/wiring)
    write('.claude/coordinator/router.js', '// router.js\n')
    write('.claude/coordinator/run.js', "require('./router.js')\nrequire('./budget-guard')\n// budget-guard\n")
    write('.claude/coordinator/bank.js', '// bank.js\n')
    write('.claude/coordinator/budget-guard.js', '// budget-guard.js\n')
    write('.claude/bin/ada.js', 'function cmdBank(){}\nfunction cmdDaemon(){}\n')
    write('install.ps1', '# installeur Windows\n')
    write('.claude/workers/daemon.js', [
      "const DEFAULT_SCHEDULE = {",
      "  ultralearn:  6 * 60 * 60 * 1000,",
      "  consolidate: 2 * 60 * 60 * 1000,",
      "}",
    ].join('\n'))

    // tests/run-all.js minimal : quelques suites "présentes" pour computeCapabilities
    write('.claude/tests/run-all.js', [
      "const SUITES = [",
      "  { name: 'coordinator/router', file: 'x' },",
      "  { name: 'coordinator/bank', file: 'x' },",
      "  { name: 'coordinator/bank-recall', file: 'x' },",
      "  { name: 'coordinator/budget-guard', file: 'x' },",
      "  { name: 'hooks/pre-tool-validator', file: 'x' },",
      "  { name: 'hooks/pre-bash', file: 'x' },",
      "  { name: 'workers/daemon', file: 'x' },",
      "  { name: 'scripts/ada-manifest', file: 'x' },",
      "  { name: 'scripts/install-sh', file: 'x' },",
      "]",
    ].join('\n'))

    return { root, write }
  }

  /** README minimal contenant TOUTES les ancres attendues par les champs scattered. */
  function buildFixtureReadme({ agentsTotal, agentsAda, agentsRuflo, skillsTotal, profilesTotal, hooksTotal, mcpTotal, commandsTotal, commandsDev, commandsSaas, workersTotal }) {
    return [
      '# Fixture',
      '',
      `> un catalogue de **${agentsTotal} agents spécialisés** (${agentsAda} ADA + ${agentsRuflo} Ruflo) et ${skillsTotal} skills pour couvrir un large éventail de stacks, ${profilesTotal} profils de routing, etc.`,
      '',
      '**Stack par défaut :** NestJS 10 · Next.js 15 · PostgreSQL 16 · Prisma · Redis',
      '',
      '### Chiffres clés',
      '',
      '| Composant | Quantité |',
      '|---|---|',
      '| placeholder | placeholder |',
      '',
      'Il orchestrate automatiquement les 3 agents pour produire un projet.',
      '',
      `Catalogue des ${agentsTotal} agents par catégorie`,
      '',
      '```bash',
      `ada agents list                    # tous les ${agentsTotal} agents`,
      '```',
      '',
      `## Système de hooks — ${hooksTotal} hooks actifs`,
      '',
      '| Hook | Type | Déclencheur | Rôle |',
      '|---|---|---|---|',
      '| `placeholder` | x | x | x |',
      '',
      '---',
      '',
      `catalogue ${mcpTotal} serveurs, toggle enable/disable`,
      '',
      '```',
      `│   ├── full/                # ${agentsAda} agents complets (~400 tokens chacun)`,
      `│   └── stubs/               # ${agentsAda} stubs (~60 tokens chacun)`,
      `├── skills/                  # ${skillsTotal} skills répartis par agent`,
      `├── commands/                # ${commandsTotal} slash commands`,
      `│   ├── profiles.json        # ${profilesTotal} profils d'agents`,
      `└── hooks/                   # ${hooksTotal} hooks Node.js`,
      '```',
      '',
      '| ID | Nom | Description |',
      '|---|---|---|',
      '| F1 | x | x |',
      '| F2 | x | x |',
      '',
      `${workersTotal} workers tournent automatiquement, schedule configurable, graceful shutdown`,
      '',
      '## Serveurs MCP',
      '',
      'Intro.',
      '',
      '| Serveur | Paquet |',
      '|---|---|',
      '| `placeholder` | `placeholder` |',
      '',
      '---',
      '',
      '## Fin',
      '',
    ].join('\n')
  }

  test('RED : --check échoue sur un README jetable avec un chiffre volontairement faux', () => {
    const { root } = buildFixtureRepo()
    const readmePath = join(root, 'README.md')
    // "999" agents au lieu des 4 réels (3 ADA + 1 Ruflo) de la fixture.
    writeFileSync(readmePath, buildFixtureReadme({
      agentsTotal: 999, agentsAda: 3, agentsRuflo: 1, skillsTotal: 3, profilesTotal: 3,
      hooksTotal: 2, mcpTotal: 2, commandsTotal: 2, commandsDev: 1, commandsSaas: 1, workersTotal: 2,
    }))

    const r = runGenerator(['--root', root, '--readme', readmePath, '--check'])
    assert.notEqual(r.status, 0, '--check devrait échouer (RED attendu) sur un chiffre faux')
    assert.match(r.stderr, /intro-summary/, 'le champ en dérive doit être nommé dans le message d\'erreur')

    rmSync(root, { recursive: true, force: true })
  })

  test('RED (un champ à la fois) : chaque compteur scattered déclenche seul une détection de dérive', () => {
    // Baseline entièrement correcte (mêmes valeurs que le fixture repo) — un
    // seul champ à la fois est faussé, tous les autres restent exacts, pour
    // prouver que CHAQUE champ est réellement vérifié isolément par --check,
    // pas seulement agentsTotal (seul champ couvert avant ce test).
    const correct = {
      agentsTotal: 4, agentsAda: 3, agentsRuflo: 1, skillsTotal: 3, profilesTotal: 3,
      hooksTotal: 2, mcpTotal: 2, commandsTotal: 2, commandsDev: 1, commandsSaas: 1, workersTotal: 2,
    }
    // Champ faussé → id(s) de scatteredFields() censé(s) s'allumer pour ce champ
    // précis (cf. .claude/scripts/generate-capability-matrix.js:scatteredFields).
    // commandsDev/commandsSaas n'apparaissent que dans le bloc CAPABILITY-MATRIX
    // principal (absent de cette fixture minimale) : pas de mention "scattered"
    // dédiée, donc pas testés par cette boucle.
    const fieldToIds = {
      agentsTotal: ['intro-summary', 'agents-list-comment-1', 'agents-list-comment-2'],
      agentsAda: ['intro-summary', 'tree-full', 'tree-stubs'],
      agentsRuflo: ['intro-summary'],
      skillsTotal: ['intro-summary', 'tree-skills'],
      profilesTotal: ['intro-summary', 'tree-profiles'],
      hooksTotal: ['hooks-heading', 'tree-hooks'],
      mcpTotal: ['mcp-connectors-page-desc'],
      commandsTotal: ['tree-commands'],
      workersTotal: ['f18-workers-row'],
    }

    for (const [field, ids] of Object.entries(fieldToIds)) {
      const { root } = buildFixtureRepo()
      const readmePath = join(root, 'README.md')
      writeFileSync(readmePath, buildFixtureReadme({ ...correct, [field]: correct[field] + 500 }))

      const r = runGenerator(['--root', root, '--readme', readmePath, '--check'])
      assert.notEqual(r.status, 0, `--check devrait échouer quand seul "${field}" est faussé`)
      const idPattern = new RegExp(ids.map((id) => `"${id}"`).join('|'))
      assert.match(r.stderr, idPattern,
        `la dérive de "${field}" devrait être signalée via l'un des champs ${JSON.stringify(ids)} :\n${r.stderr}`)

      rmSync(root, { recursive: true, force: true })
    }
  })

  test('GREEN : le mode par défaut corrige le README jetable, --check repasse au vert', () => {
    const { root } = buildFixtureRepo()
    const readmePath = join(root, 'README.md')
    writeFileSync(readmePath, buildFixtureReadme({
      agentsTotal: 999, agentsAda: 3, agentsRuflo: 1, skillsTotal: 3, profilesTotal: 3,
      hooksTotal: 2, mcpTotal: 2, commandsTotal: 2, commandsDev: 1, commandsSaas: 1, workersTotal: 2,
    }))

    const fix = runGenerator(['--root', root, '--readme', readmePath])
    assert.equal(fix.status, 0, `la correction devrait réussir :\n${fix.stdout}${fix.stderr}`)

    const check = runGenerator(['--root', root, '--readme', readmePath, '--check'])
    assert.equal(check.status, 0, `--check devrait passer après correction (GREEN attendu) :\n${check.stdout}${check.stderr}`)

    // Le chiffre réel (4 = 3 ADA + 1 Ruflo) doit maintenant apparaître.
    const fixed = readFileSync(readmePath, 'utf8')
    assert.match(fixed, /\*\*4 agents spécialisés\*\* \(3 ADA \+ 1 Ruflo\)/)

    rmSync(root, { recursive: true, force: true })
  })

  test('idempotence : une seconde correction sur un README déjà à jour ne change rien', () => {
    const { root } = buildFixtureRepo()
    const readmePath = join(root, 'README.md')
    writeFileSync(readmePath, buildFixtureReadme({
      agentsTotal: 999, agentsAda: 3, agentsRuflo: 1, skillsTotal: 3, profilesTotal: 3,
      hooksTotal: 2, mcpTotal: 2, commandsTotal: 2, commandsDev: 1, commandsSaas: 1, workersTotal: 2,
    }))

    runGenerator(['--root', root, '--readme', readmePath])
    const once = readFileSync(readmePath, 'utf8')
    runGenerator(['--root', root, '--readme', readmePath])
    const twice = readFileSync(readmePath, 'utf8')
    assert.equal(once, twice, 'une régénération sur un README déjà à jour doit être un no-op')

    rmSync(root, { recursive: true, force: true })
  })
})
