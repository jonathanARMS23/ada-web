'use strict'
const {test}=require('node:test')
const assert=require('node:assert/strict')
const {sessionStart}=require('../../../.codex/hooks/ada-knowledge-runner.js')
test('native SessionStart produces the documented context envelope',async()=>{
  const out=await sessionStart({hook_event_name:'SessionStart',cwd:'/tmp'}, {recall:async()=>({block:'conventions',degraded:false})})
  assert.deepEqual(out,{hookSpecificOutput:{hookEventName:'SessionStart',additionalContext:'conventions'}})
})
test('degraded recall remains observable',async()=>{
  const out=await sessionStart({hook_event_name:'SessionStart'},{recall:async()=>({block:'fallback',degraded:true})})
  assert.ok(out.systemMessage.includes('degraded'))
})
test('malformed events fail instead of pretending knowledge was loaded',async()=>{
  await assert.rejects(sessionStart({},{}),/SessionStart/)
})
