#!/usr/bin/env node
'use strict'
/**
 * tests/scripts/install-sh.test.js — install.sh : flag --with-ui (opt-in UI)
 *
 * install.sh (racine du repo) n'a pas de harnais de test bash dédié — ces tests
 * invoquent le VRAI script via execFileSync, toujours avec --dry-run (aucune
 * écriture disque, voir la garantie documentée dans install.sh : « aucun profil,
 * ~/.ada.json, ~/.zshrc, build npm inclus ») et toujours avec --profile <nom
 * jetable> pour ne jamais dépendre de l'état de profils réels de la machine qui
 * exécute la suite, ni déclencher une invite interactive (--profile force
 * NONINTERACTIVE=true dans parse_args).
 *
 * Portée volontairement étroite : on vérifie le COMPORTEMENT observable (texte
 * affiché, présence/absence du chemin d'install de l'interface), pas les
 * détails d'implémentation bash internes.
 */

const { test, describe } = require('node:test')
const assert = require('node:assert/strict')
const { join } = require('node:path')
const { execFileSync } = require('node:child_process')
const { mkdtempSync, mkdirSync, writeFileSync, readFileSync, copyFileSync, rmSync } = require('node:fs')
const { tmpdir } = require('node:os')

const REPO_ROOT = join(__dirname, '../../..')
const INSTALL_SH = join(REPO_ROOT, 'install.sh')

/** Lance install.sh --dry-run --profile <name> avec des args/env additionnels. */
function runDryRun(profileName, extraArgs = [], extraEnv = {}) {
  return execFileSync(
    'bash',
    [INSTALL_SH, '--dry-run', '--profile', profileName, ...extraArgs],
    {
      cwd: REPO_ROOT,
      encoding: 'utf8',
      env: { ...process.env, ...extraEnv },
    },
  )
}

describe('install.sh --help', () => {
  test('documente --with-ui et son équivalent ADA_WITH_UI', () => {
    const out = execFileSync('bash', [INSTALL_SH, '--help'], { encoding: 'utf8' })
    assert.match(out, /--with-ui/)
    assert.match(out, /ADA_WITH_UI/)
  })

  test('les flags existants restent documentés (pas de régression du usage)', () => {
    const out = execFileSync('bash', [INSTALL_SH, '--help'], { encoding: 'utf8' })
    for (const flag of ['--profile', '--all', '--non-interactive', '--with-server', '--dry-run', '--version']) {
      assert.match(out, new RegExp(flag.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')), `usage doit mentionner ${flag}`)
    }
  })
})

describe('install.sh --with-ui (opt-in, défaut CLI-only)', () => {
  test('sans --with-ui : interface non installée, message opt-in affiché', () => {
    const out = runDryRun('ada-test-cli-only-noflag')
    assert.match(out, /CLI-only/)
    assert.match(out, /--with-ui/)
    // Le chemin d'installation réel de l'interface ne doit PAS s'exécuter.
    assert.doesNotMatch(out, /Installation de l'interface ADA/)
  })

  test('avec --with-ui : le chemin d\'installation de l\'interface est emprunté', () => {
    const out = runDryRun('ada-test-cli-only-flag', ['--with-ui'])
    assert.match(out, /Installation de l'interface ADA/)
  })

  test('ADA_WITH_UI=1 a le même effet que --with-ui', () => {
    const out = runDryRun('ada-test-cli-only-env1', [], { ADA_WITH_UI: '1' })
    assert.match(out, /Installation de l'interface ADA/)
  })

  test('ADA_WITH_UI=true a le même effet que --with-ui', () => {
    const out = runDryRun('ada-test-cli-only-envtrue', [], { ADA_WITH_UI: 'true' })
    assert.match(out, /Installation de l'interface ADA/)
  })

  test('ADA_WITH_UI=0 (ou absent) reste CLI-only', () => {
    const out = runDryRun('ada-test-cli-only-env0', [], { ADA_WITH_UI: '0' })
    assert.match(out, /CLI-only/)
    assert.doesNotMatch(out, /Installation de l'interface ADA/)
  })
})

describe('install.sh --with-ui : aucune régression des autres flags', () => {
  test('--with-server (déprécié) fonctionne toujours indépendamment de --with-ui', () => {
    const out = runDryRun('ada-test-with-server', ['--with-server'])
    assert.match(out, /ada-api.*DÉPRÉCIÉ|DÉPRÉCIÉ.*ada-api/is)
    // --with-server seul ne doit pas activer l'installation de l'interface.
    assert.doesNotMatch(out, /Installation de l'interface ADA/)
  })

  test('--with-server et --with-ui combinés activent les deux chemins', () => {
    const out = runDryRun('ada-test-both-flags', ['--with-server', '--with-ui'])
    assert.match(out, /ada-api.*DÉPRÉCIÉ|DÉPRÉCIÉ.*ada-api/is)
    assert.match(out, /Installation de l'interface ADA/)
  })

  test('--dry-run ne crée aucun profil réel, avec ou sans --with-ui', () => {
    const { existsSync } = require('node:fs')
    const { homedir } = require('node:os')
    for (const name of ['ada-test-cli-only-noflag', 'ada-test-cli-only-flag']) {
      assert.equal(existsSync(join(homedir(), `.${name}`)), false,
        `--dry-run ne doit jamais créer ~/.${name}`)
    }
  })
})

/**
 * ensure_manifest() : péremption du manifeste de livraison.
 *
 * Bug corrigé : la fonction ne vérifiait que présence + non-vide. Un manifeste
 * committé mais PÉRIMÉ (fichier ajouté au dépôt depuis sa génération) passait le
 * contrôle, et comme il sert de --files-from à rsync, les fichiers manquants
 * n'étaient jamais livrés aux profils — en silence.
 *
 * Harnais : install.sh se termine par `main "$@"`, donc `source` l'exécuterait.
 * On copie le script MOINS sa dernière ligne dans un dépôt fixture, ce qui donne
 * un mode « bibliothèque » où ensure_manifest s'appelle seule, avec SOURCE_DIR /
 * CLAUDE_DIR pointant naturellement sur la fixture (calculés depuis BASH_SOURCE).
 */
describe('install.sh ensure_manifest() — détection de péremption', () => {
  /** Manifeste volontairement périmé : ne liste qu'un fichier qui n'existe pas. */
  const STALE = { version: '0.0.1', generatedAt: '2020-01-01T00:00:00.000Z', files: { 'obsolete/fantome.js': 'deadbeef' } }

  /** Dépôt fixture minimal : générateur réel + un fichier tracké + manifeste périmé. */
  function makeFixture({ git }) {
    const dir = mkdtempSync(join(tmpdir(), 'ada-manifest-fixture-'))
    mkdirSync(join(dir, '.claude/scripts'), { recursive: true })
    mkdirSync(join(dir, '.claude/coordinator'), { recursive: true })
    copyFileSync(
      join(REPO_ROOT, '.claude/scripts/generate-ada-manifest.js'),
      join(dir, '.claude/scripts/generate-ada-manifest.js'),
    )
    writeFileSync(join(dir, 'VERSION'), '9.9.9\n')
    writeFileSync(join(dir, '.claude/coordinator/nouveau-fichier.js'), 'module.exports = {}\n')

    // install.sh privé de sa dernière ligne (`main "$@"`) → sourçable.
    const src = readFileSync(INSTALL_SH, 'utf8')
    const lines = src.replace(/\n$/, '').split('\n')
    assert.equal(lines[lines.length - 1], 'main "$@"',
      'le harnais suppose que install.sh se termine par `main "$@"` — adapter si ça change')
    writeFileSync(join(dir, 'install.sh'), lines.slice(0, -1).join('\n') + '\n')

    if (git) {
      // L'index suffit : `git ls-files` n'a pas besoin d'un commit.
      execFileSync('git', ['init', '-q', '.'], { cwd: dir })
      execFileSync('git', ['add', '-A'], { cwd: dir })
    }
    writeFileSync(join(dir, '.claude/.ada-manifest.json'), JSON.stringify(STALE, null, 2))
    return dir
  }

  function ensureManifest(dir) {
    return execFileSync('bash', ['-c', 'source ./install.sh; ensure_manifest'],
      { cwd: dir, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] })
  }

  function readManifest(dir) {
    return JSON.parse(readFileSync(join(dir, '.claude/.ada-manifest.json'), 'utf8'))
  }

  test('copie de travail git : un manifeste périmé est régénéré même s\'il est présent et non-vide', () => {
    const dir = makeFixture({ git: true })
    try {
      ensureManifest(dir)
      const files = Object.keys(readManifest(dir).files)
      assert.ok(files.includes('coordinator/nouveau-fichier.js'),
        'un fichier ajouté à l\'arbre source doit apparaître dans le manifeste régénéré')
      assert.ok(!files.includes('obsolete/fantome.js'),
        'l\'entrée périmée ne doit plus figurer dans le manifeste')
    } finally {
      rmSync(dir, { recursive: true, force: true })
    }
  })

  test('archive de release (pas de .git) : le manifeste committé est utilisé tel quel', () => {
    const dir = makeFixture({ git: false })
    try {
      const out = ensureManifest(dir)
      assert.match(out, /Manifeste de livraison : 1 fichiers/)
      assert.deepEqual(readManifest(dir), STALE,
        'sans dépôt git, aucune régénération possible : le manifeste ne doit pas être touché')
    } finally {
      rmSync(dir, { recursive: true, force: true })
    }
  })
})

/**
 * MANIFEST_MUTABLE : fichiers livrés à DOUBLE NATURE (donnée de référence
 * committée + état réécrit par ADA à l'exécution).
 *
 * Régression reproduite empiriquement (2026-09-13, lot « moteur-agnostique ») :
 * `coordinator/engine-registry-state.json` est TRACKÉ par git (contrairement à
 * `engine-router-state.json`, lui gitignoré), donc présent dans le manifeste,
 * donc synchronisé en mode `replace` par `_sync_system_dir`. Conséquence
 * mesurée sur un profil réel : après `recordProbe('codex', {verified:true})`,
 * une simple re-exécution d'install.sh (chemin nominal d'une mise à jour)
 * réécrivait le fichier aux défauts livrés — `codex.verified` repassait à
 * `false`. Or `engine-router.js` exige `verified:true` pour qu'un moteur soit
 * candidat : le routage Codex du client disparaissait en silence après chaque
 * mise à jour.
 *
 * Ces tests verrouillent la garantie au niveau du COMPORTEMENT observable
 * (le fichier client survit au sync système, et un profil neuf est bien seedé),
 * pas au niveau du contenu littéral du tableau bash.
 */
describe('install.sh _sync_system_dir() — état runtime tracké par git', () => {
  /**
   * Dépôt fixture minimal + profil de destination.
   * `coordinator/` contient deux fichiers trackés :
   *   - `normal.js`                  → fichier système ordinaire, DOIT être mis à jour ;
   *   - `engine-registry-state.json` → état à double nature, NE DOIT PAS être écrasé.
   * Le second témoin est indispensable : sans lui, un sync totalement inopérant
   * ferait passer le test pour de mauvaises raisons.
   */
  function makeSyncFixture() {
    const dir = mkdtempSync(join(tmpdir(), 'ada-sync-fixture-'))
    mkdirSync(join(dir, '.claude/scripts'), { recursive: true })
    mkdirSync(join(dir, '.claude/coordinator'), { recursive: true })
    for (const s of ['generate-ada-manifest.js', 'manifest-files-for.js', 'sync-content-dir.js']) {
      copyFileSync(join(REPO_ROOT, '.claude/scripts', s), join(dir, '.claude/scripts', s))
    }
    writeFileSync(join(dir, 'VERSION'), '9.9.9\n')
    writeFileSync(join(dir, '.claude/coordinator/normal.js'), 'module.exports = { v: 2 }\n')
    writeFileSync(
      join(dir, '.claude/coordinator/engine-registry-state.json'),
      JSON.stringify({ claude_code: { verified: true, probedAt: null }, codex: { verified: false, probedAt: null } }, null, 2) + '\n',
    )

    const src = readFileSync(INSTALL_SH, 'utf8')
    const lines = src.replace(/\n$/, '').split('\n')
    assert.equal(lines[lines.length - 1], 'main "$@"',
      'le harnais suppose que install.sh se termine par `main "$@"` — adapter si ça change')
    writeFileSync(join(dir, 'install.sh'), lines.slice(0, -1).join('\n') + '\n')

    execFileSync('git', ['init', '-q', '.'], { cwd: dir })
    execFileSync('git', ['add', '-A'], { cwd: dir })

    // Profil « client » : déjà installé, avec un état de sonde accumulé.
    const profile = join(dir, 'profile')
    mkdirSync(join(profile, 'coordinator'), { recursive: true })
    writeFileSync(join(profile, 'coordinator/normal.js'), 'module.exports = { v: 1 }\n')
    writeFileSync(
      join(profile, 'coordinator/engine-registry-state.json'),
      JSON.stringify({ claude_code: { verified: true, probedAt: null }, codex: { verified: true, probedAt: '2026-09-13T05:11:26.237Z' } }, null, 2) + '\n',
    )
    return { dir, profile }
  }

  test('un état runtime tracké par git survit au sync système (pas d\'écrasement)', () => {
    const { dir, profile } = makeSyncFixture()
    try {
      execFileSync(
        'bash',
        ['-c', 'source ./install.sh; ensure_manifest >/dev/null; _sync_system_dir coordinator "$PWD/profile"'],
        { cwd: dir, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] },
      )

      const state = JSON.parse(readFileSync(join(profile, 'coordinator/engine-registry-state.json'), 'utf8'))
      assert.equal(state.codex.verified, true,
        'la sonde accumulée côté client ne doit jamais être réécrite par le sync système')
      assert.equal(state.codex.probedAt, '2026-09-13T05:11:26.237Z')

      // Témoin : un fichier système ordinaire DOIT, lui, avoir été mis à jour.
      assert.match(readFileSync(join(profile, 'coordinator/normal.js'), 'utf8'), /v: 2/,
        'un fichier système ordinaire doit rester mis à jour — sinon le test passe pour de mauvaises raisons')
    } finally {
      rmSync(dir, { recursive: true, force: true })
    }
  })

  test('le même état est déposé quand le profil n\'en a aucun (première installation)', () => {
    const { dir, profile } = makeSyncFixture()
    try {
      rmSync(join(profile, 'coordinator/engine-registry-state.json'))
      execFileSync(
        'bash',
        ['-c', 'source ./install.sh; ensure_manifest >/dev/null; CUSTOM_REPORT="$(mktemp)"; '
             + '_sync_system_dir coordinator "$PWD/profile"; '
             + '_sync_checksum coordinator/engine-registry-state.json "$PWD/profile" "  ok"'],
        { cwd: dir, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] },
      )

      const state = JSON.parse(readFileSync(join(profile, 'coordinator/engine-registry-state.json'), 'utf8'))
      assert.equal(state.codex.verified, false,
        'première installation : l\'état livré (défauts sûrs) doit bien être déposé dans le profil')
    } finally {
      rmSync(dir, { recursive: true, force: true })
    }
  })
})
