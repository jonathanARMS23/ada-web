'use strict'
const {test}=require('node:test')
const assert=require('node:assert/strict')
const {PassThrough}=require('node:stream')
const {LaunchTerminal,parseLaunchArgs,clean,wrap}=require('../../bin/launch-terminal')
function setup() {
  const sent=[],output=new PassThrough(),input=new PassThrough();let screen=''
  output.on('data',x=>{screen+=x})
  const ui=new LaunchTerminal({sessionId:'s',engine:'codex',cwd:'/tmp',input,output,send:x=>sent.push(x),quit:()=>{}})
  return {ui,sent,get screen(){return screen}}
}
test('strict argument parsing prevents implicit engine changes',()=>{
  assert.equal(parseLaunchArgs(['--engine','codex','/tmp','--resume','s']).resume,'s')
  for(const args of [['--engine'],['--engine','gpt'],['--legacy','--engine','codex'],['--what'],['a','b']])assert.throws(()=>parseLaunchArgs(args))
})
test('multiline editing, history and busy draft retention',()=>{
  const {ui,sent}=setup();ui.insert('bonjour');ui.key('',{ctrl:true,name:'j'});ui.insert('suite');ui.submit()
  assert.equal(sent[0].content,'bonjour\nsuite')
  ui.insert('next');ui.submit();assert.equal(sent.length,1);assert.equal(ui.draft,'next')
  ui.event({type:'session.turn_complete',payload:{sessionId:'s',tokens:12}});ui.key('',{name:'up'})
  assert.equal(ui.draft,'bonjour\nsuite')
})
test('permissions are queued, scoped and never default-approved',()=>{
  const {ui,sent}=setup()
  for(const [sid,id] of [['other','x'],['s','a'],['s','b']])ui.event({type:'task.permission_request',payload:{sessionId:sid,requestId:id,tool:'Write'}})
  assert.equal(ui.pending.length,2)
  ui.draft='maybe';ui.submit();assert.equal(sent.length,0);assert.equal(ui.pending.length,2)
  ui.draft='o';ui.submit();ui.draft='n';ui.submit()
  assert.deepEqual(sent.map(x=>[x.requestId,x.decision]),[['a','allow'],['b','deny']])
})
test('OSC, control characters and foreign session output do not enter terminal',()=>{
  const h=setup();h.ui.event({type:'session.output',payload:{sessionId:'other',chunk:'secret'}})
  assert.equal(h.screen,'');assert.equal(clean('\x1b]52;c;payload\x07text\x1b[2J'),'text')
  assert.deepEqual(wrap('é猫ab',3),['é猫','ab'])
})
test('split bracketed paste inserts newlines without submitting and restores terminal',()=>{
  const h=setup();h.ui.input.isTTY=true;h.ui.output.isTTY=true;h.ui.input.setRawMode=()=>{};h.ui.rich=true;h.ui.start()
  h.ui.feed('\x1b[20');h.ui.feed('0~a\r\nb');h.ui.feed('\x1b[201~')
  assert.equal(h.ui.draft,'a\nb');assert.equal(h.sent.length,0)
  h.ui.stop();assert.ok(h.screen.includes('\x1b[?1049l'))
})
test('summary fallback, error handling and interruption preserve the session',()=>{
  const h=setup();h.ui.busy=true;h.ui.interrupt();assert.equal(h.sent[0].type,'task.interrupt')
  h.ui.event({type:'session.turn_complete',payload:{sessionId:'s',summary:'done',tokens:4}})
  assert.ok(h.screen.includes('done'));assert.equal(h.ui.busy,false)
  h.ui.event({type:'task.error',error:'refused'});assert.ok(h.screen.includes('refused'))
})
test('permission widget defaults to deny and restores a draft after resolution',()=>{
  const h=setup();h.ui.insert('draft in progress')
  h.ui.event({type:'task.permission_request',payload:{sessionId:'s',requestId:'p',tool:'Write'}})
  assert.equal(h.ui.draft,'');h.ui.submit()
  assert.equal(h.sent[0].decision,'deny');assert.equal(h.ui.draft,'draft in progress')
  h.ui.event({type:'task.permission_request',payload:{sessionId:'s',requestId:'q',tool:'Write'}})
  h.ui.event({type:'task.permission_resolved',payload:{sessionId:'s',requestId:'q'}})
  assert.equal(h.ui.pending.length,0);assert.equal(h.ui.draft,'draft in progress')
})
test('real PTY: paste, send, interrupt, resize and terminal restoration',t=>{
  const {spawnSync}=require('node:child_process')
  if(spawnSync('python3',['--version']).status!==0){t.skip('python3 unavailable');return}
  const script=String.raw`
import os,pty,select,time,sys,termios,fcntl,struct
pid,fd=pty.fork()
if pid==0:
  os.environ['TERM']='xterm-256color'
  os.execvp('node',['node','-e',"const {LaunchTerminal}=require(process.argv[1]); let ui; ui=new LaunchTerminal({sessionId:'pty-session',engine:'codex',cwd:'/tmp',send:m=>{if(m.type==='task.message'){ui.event({type:'session.output',payload:{sessionId:'pty-session',chunk:'RECEIVED_MULTILINE'}})}else if(m.type==='task.interrupt'){ui.event({type:'session.turn_complete',payload:{sessionId:'pty-session',summary:'INTERRUPTED'}})}},quit:()=>{ui.stop();console.log('TERMINAL_RESTORED');process.exit(0)}});ui.start()",sys.argv[1]])
output=b''
def wait_for(marker):
  global output
  end=time.time()+5
  while marker not in output:
    if time.time()>end: raise Exception('PTY timeout '+repr(output[-2000:]))
    if select.select([fd],[],[],0.1)[0]: output+=os.read(fd,65536)
try:
  fcntl.ioctl(fd,termios.TIOCSWINSZ,struct.pack('HHHH',24,80,0,0))
  wait_for(b'ADA')
  os.write(fd,b'\x1b[200~first\nsecond\x1b[201~')
  time.sleep(.15)
  os.write(fd,b'\r');wait_for(b'RECEIVED_MULTILINE')
  os.write(fd,b'\x03');wait_for(b'Tour termin')
  fcntl.ioctl(fd,termios.TIOCSWINSZ,struct.pack('HHHH',14,45,0,0))
  os.write(fd,b'/exit\r');wait_for(b'TERMINAL_RESTORED')
  assert b'\x1b[?1049l' in output
  _,status=os.waitpid(pid,0);assert os.waitstatus_to_exitcode(status)==0
finally:
  try: os.kill(pid,9)
  except ProcessLookupError: pass
  os.close(fd)
`
  const result=spawnSync('python3',['-c',script,require.resolve('../../bin/launch-terminal')],{encoding:'utf8',timeout:15000})
  assert.equal(result.status,0,result.stderr)
})
