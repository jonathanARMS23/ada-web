#!/usr/bin/env node
'use strict'
/**
 * tests/scripts/seed-from-git.test.js — Tests pour scripts/seed-from-git.js
 *
 * Couvre :
 *  - parseCommits()     : parsing du git log formaté
 *  - inferPhaseAgent()  : inférence phase/agent depuis scope et fichiers
 *  - inferVerdict()     : détection revert → failure
 *  - seedFromGit()      : dry-run, repo réel, dégradation sans git
 *  - PHASE_FROM_FILE    : couverture des extensions principales
 */

const { test, describe } = require('node:test')
const assert = require('node:assert/strict')
const { join } = require('node:path')
const { mkdirSync, rmSync, writeFileSync } = require('node:fs')
const { execSync } = require('node:child_process')

const SEED_JS = join(__dirname, '../../scripts/seed-from-git.js')
const {
  parseCommits,
  inferPhaseAgent,
  inferVerdict,
  seedFromGit,
  PHASE_FROM_FILE,
} = require(SEED_JS)

// ── parseCommits ───────────────────────────────────────────────────────────────

describe('parseCommits', () => {
  test('parse un seul commit avec hash, subject et fichiers', () => {
    const raw = [
      'abc1234|||feat(nestjs): add auth service|||dev@example.com',
      'src/auth.service.ts',
      'src/auth.module.ts',
      '',
    ].join('\n')

    const commits = parseCommits(raw)
    assert.equal(commits.length, 1)
    assert.equal(commits[0].hash, 'abc1234')
    assert.equal(commits[0].subject, 'feat(nestjs): add auth service')
    assert.equal(commits[0].type, 'feat')
    assert.equal(commits[0].scope, 'nestjs')
    assert.ok(commits[0].files.includes('src/auth.service.ts'))
    assert.ok(commits[0].files.includes('src/auth.module.ts'))
  })

  test('parse plusieurs commits consécutifs', () => {
    const raw = [
      'aaa111|||feat(db): add migration|||dev@example.com',
      'migrations/001_init.sql',
      '',
      'bbb222|||fix(nextjs): fix hydration|||dev@example.com',
      'components/App.tsx',
      '',
    ].join('\n')

    const commits = parseCommits(raw)
    assert.equal(commits.length, 2)
    assert.equal(commits[0].scope, 'db')
    assert.equal(commits[1].scope, 'nextjs')
  })

  test('extrait le type et scope d\'un commit conventionnel avec !', () => {
    const raw = 'ccc333|||feat(drf)!: breaking change|||dev@example.com\napp/models.py\n'
    const commits = parseCommits(raw)
    assert.equal(commits[0].type, 'feat')
    assert.equal(commits[0].scope, 'drf')
  })

  test('commit sans scope → scope vide', () => {
    const raw = 'ddd444|||chore: update deps|||dev@example.com\npackage.json\n'
    const commits = parseCommits(raw)
    assert.equal(commits[0].scope, '')
    assert.equal(commits[0].type, 'chore')
  })

  test('ligne sans séparateur ||| → ignorée', () => {
    const raw = 'eee555|||feat(nestjs): add feature|||dev@test.com\nservice.ts\n\nsome-random-line-without-separator\n'
    const commits = parseCommits(raw)
    assert.equal(commits.length, 1)
  })
})

// ── inferPhaseAgent ────────────────────────────────────────────────────────────

describe('inferPhaseAgent', () => {
  test('scope "nestjs" → backend/nestjs', () => {
    const commit = { type: 'feat', scope: 'nestjs', files: [] }
    const result = inferPhaseAgent(commit)
    assert.deepEqual(result, { phase: 'backend', agent: 'nestjs' })
  })

  test('scope "next" → frontend/nextjs', () => {
    const commit = { type: 'feat', scope: 'next', files: [] }
    const result = inferPhaseAgent(commit)
    assert.deepEqual(result, { phase: 'frontend', agent: 'nextjs' })
  })

  test('scope "drf" → backend/drf', () => {
    const commit = { type: 'fix', scope: 'drf', files: [] }
    const result = inferPhaseAgent(commit)
    assert.deepEqual(result, { phase: 'backend', agent: 'drf' })
  })

  test('fichier .tsx sans scope → frontend/nextjs', () => {
    const commit = { type: 'feat', scope: '', files: ['components/Button.tsx'] }
    const result = inferPhaseAgent(commit)
    assert.deepEqual(result, { phase: 'frontend', agent: 'nextjs' })
  })

  test('fichier migration.sql → db-migrate/db', () => {
    const commit = { type: 'chore', scope: '', files: ['db/migration_001.sql'] }
    const result = inferPhaseAgent(commit)
    assert.deepEqual(result, { phase: 'db-migrate', agent: 'db' })
  })

  test('fichier Dockerfile → deploy/devops', () => {
    const commit = { type: 'chore', scope: '', files: ['Dockerfile'] }
    const result = inferPhaseAgent(commit)
    assert.deepEqual(result, { phase: 'deploy', agent: 'devops' })
  })

  test('uniquement des fichiers .md → null', () => {
    const commit = { type: 'docs', scope: '', files: ['README.md', 'CHANGELOG.md'] }
    const result = inferPhaseAgent(commit)
    assert.equal(result, null)
  })

  test('fichier .ts → backend/nestjs', () => {
    const commit = { type: 'feat', scope: '', files: ['src/user.service.ts'] }
    const result = inferPhaseAgent(commit)
    assert.deepEqual(result, { phase: 'backend', agent: 'nestjs' })
  })

  test('fichier test.spec.js → test/tester', () => {
    const commit = { type: 'test', scope: '', files: ['user.spec.ts'] }
    const result = inferPhaseAgent(commit)
    assert.deepEqual(result, { phase: 'test', agent: 'tester' })
  })

  test('commit sans scope ni fichiers reconnus → null', () => {
    const commit = { type: 'chore', scope: '', files: ['some-unknown-file.xyz'] }
    const result = inferPhaseAgent(commit)
    assert.equal(result, null)
  })
})

// ── inferVerdict ───────────────────────────────────────────────────────────────

describe('inferVerdict', () => {
  test('commit suivi d\'un revert avec son hash → failure', () => {
    const commit = { hash: 'abc1234567', subject: 'feat(nestjs): add auth' }
    const preceding = [
      { subject: 'revert: feat(nestjs): add auth (abc1234)' },
    ]
    const verdict = inferVerdict(commit, preceding)
    assert.equal(verdict, 'failure')
  })

  test('commit sans revert parmi les précédents → success', () => {
    const commit = { hash: 'abc1234567', subject: 'feat(db): add migration' }
    const preceding = [
      { subject: 'feat(nextjs): add page' },
      { subject: 'fix(drf): fix serializer' },
    ]
    const verdict = inferVerdict(commit, preceding)
    assert.equal(verdict, 'success')
  })

  test('commit sans précédents → success', () => {
    const commit = { hash: 'abc1234567', subject: 'feat(nestjs): initial' }
    const verdict = inferVerdict(commit, [])
    assert.equal(verdict, 'success')
  })

  test('revert d\'un autre commit n\'affecte pas le verdict', () => {
    const commit = { hash: 'abc1234567', subject: 'feat(nestjs): add auth' }
    const preceding = [
      { subject: 'revert: feat(drf): unrelated change (xyz9876)' },
    ]
    const verdict = inferVerdict(commit, preceding)
    assert.equal(verdict, 'success')
  })
})

// ── seedFromGit ────────────────────────────────────────────────────────────────

describe('seedFromGit — dry-run', () => {
  test('dry-run retourne un tableau de signaux sans lever d\'exception', () => {
    // Utiliser le repo AI-Dev-Assistant courant comme source
    const projectRoot = join(__dirname, '../../../..')
    let signals
    try {
      signals = seedFromGit({ dryRun: true, limit: 20, path: projectRoot })
    } catch (e) {
      // Si pas de git dans l'environnement de test, on reçoit []
      signals = []
    }
    assert.ok(Array.isArray(signals), 'signals doit être un tableau')
  })

  test('dry-run : chaque signal a phase, agent et verdict valides', () => {
    const projectRoot = join(__dirname, '../../../..')
    let signals
    try {
      signals = seedFromGit({ dryRun: true, limit: 50, path: projectRoot })
    } catch {
      signals = []
    }

    for (const s of signals) {
      assert.ok(typeof s.phase  === 'string' && s.phase.length  > 0, 'phase doit être une string non vide')
      assert.ok(typeof s.agent  === 'string' && s.agent.length  > 0, 'agent doit être une string non vide')
      assert.ok(s.verdict === 'success' || s.verdict === 'failure', `verdict invalide: ${s.verdict}`)
    }
  })

  test('dry-run sur répertoire sans git → retourne tableau vide', () => {
    // /tmp est garanti sans repo git à la racine
    const tmpNoGit = require('node:os').tmpdir()
    const signals  = seedFromGit({ dryRun: true, limit: 10, path: tmpNoGit })
    assert.ok(Array.isArray(signals), 'doit retourner un tableau')
    assert.equal(signals.length, 0, 'sans git, aucun signal')
  })
})

describe('seedFromGit — repo réel', () => {
  test('extrait > 0 signaux depuis le repo AI-Dev-Assistant courant', () => {
    const projectRoot = join(__dirname, '../../../..')
    // Vérifier que le répertoire est bien un repo git avant de tester
    let isGitRepo = false
    try {
      execSync('git rev-parse --is-inside-work-tree', { cwd: projectRoot, stdio: 'pipe' })
      isGitRepo = true
    } catch {
      // Pas de repo git → test non applicable
    }

    if (!isGitRepo) {
      // Test ignoré si pas de git disponible (CI sans repo)
      return
    }

    const signals = seedFromGit({ dryRun: true, limit: 100, path: projectRoot })
    // On s'attend à au moins quelques commits reconnaissables
    // (même 0 est acceptable si tous les commits sont sans type connu)
    assert.ok(Array.isArray(signals), 'doit retourner un tableau')
  })
})

// ── PHASE_FROM_FILE ────────────────────────────────────────────────────────────

describe('PHASE_FROM_FILE', () => {
  test('couvre les extensions TypeScript (.ts et .tsx)', () => {
    assert.ok('.ts'  in PHASE_FROM_FILE, 'PHASE_FROM_FILE doit couvrir .ts')
    assert.ok('.tsx' in PHASE_FROM_FILE, 'PHASE_FROM_FILE doit couvrir .tsx')
  })

  test('couvre Python (.py)', () => {
    assert.ok('.py' in PHASE_FROM_FILE, 'PHASE_FROM_FILE doit couvrir .py')
  })

  test('couvre SQL (.sql)', () => {
    assert.ok('.sql' in PHASE_FROM_FILE, 'PHASE_FROM_FILE doit couvrir .sql')
  })

  test('couvre les Dockerfiles', () => {
    assert.ok('Dockerfile' in PHASE_FROM_FILE, 'PHASE_FROM_FILE doit couvrir Dockerfile')
  })

  test('couvre les migrations', () => {
    assert.ok('migration' in PHASE_FROM_FILE, 'PHASE_FROM_FILE doit couvrir migration')
  })

  test('.md est explicitement null (ignoré)', () => {
    assert.equal(PHASE_FROM_FILE['.md'], null, '.md doit être null')
  })

  test('.ts pointe vers backend/nestjs', () => {
    const val = PHASE_FROM_FILE['.ts']
    assert.ok(Array.isArray(val), '.ts doit être un tableau')
    assert.equal(val[0], 'backend')
    assert.equal(val[1], 'nestjs')
  })

  test('.tsx pointe vers frontend/nextjs', () => {
    const val = PHASE_FROM_FILE['.tsx']
    assert.ok(Array.isArray(val), '.tsx doit être un tableau')
    assert.equal(val[0], 'frontend')
    assert.equal(val[1], 'nextjs')
  })
})
