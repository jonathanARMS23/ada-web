#!/usr/bin/env node
'use strict'
/**
 * .claude/tests/scripts/smoke-docker-ports.test.js — Tests de checkLoopbackPorts()
 *
 * TÂCHE 6 (audit 2026-09-09) : la regex de checkLoopbackPorts() acceptait
 * uniquement les guillemets doubles et ignorait silencieusement les ports
 * non-quoted, single-quoted ou en syntaxe longue (host_ip:) — des faux négatifs
 * sur la frontière de sécurité que ce check est censé garder.
 *
 * Ce test valide les trois formes de syntaxe courte et l'explicitation de
 * l'erreur sur la syntaxe longue non reconnue.
 */

const { test } = require('node:test')
const assert = require('node:assert/strict')

/**
 * Extrait et adapte checkLoopbackPorts() de scripts/smoke-docker.js pour le tester
 * en isolation (sans exécuter le reste du script).
 */
function checkLoopbackPorts(composeContent) {
  const violations = []
  let inPorts = false
  let portsIndent = -1
  for (const line of composeContent.split(/\r?\n/)) {
    const trimmed = line.trim()
    const indent = line.length - line.trimStart().length
    if (trimmed === 'ports:') {
      inPorts = true
      portsIndent = indent
      continue
    }
    if (!inPorts || trimmed === '') continue
    if (indent <= portsIndent) {
      inPorts = false
      continue
    }
    // Syntaxe longue (host_ip: ...) — pas encore supportée, doit échouer explicitement
    if (trimmed.includes('host_ip:')) {
      throw new Error(`syntaxe ports longue (host_ip:) non reconnue dans checkLoopbackPorts — corrige la détection`)
    }
    // Accepte guillemets doubles, simples, ou pas de guillemets
    const m = trimmed.match(/^-\s*['"]?([^'"]+?)['"]?\s*$/)
    if (m && !m[1].startsWith('127.0.0.1:')) violations.push(m[1])
  }
  return violations
}

test('checkLoopbackPorts — guillemets doubles', () => {
  const compose = `
services:
  api:
    ports:
      - "127.0.0.1:3010:3010"
`
  const violations = checkLoopbackPorts(compose)
  assert.deepEqual(violations, [], 'port en guillemets doubles et loopback accepté')
})

test('checkLoopbackPorts — guillemets simples', () => {
  const compose = `
services:
  api:
    ports:
      - '127.0.0.1:3010:3010'
`
  const violations = checkLoopbackPorts(compose)
  assert.deepEqual(violations, [], 'port en guillemets simples et loopback accepté')
})

test('checkLoopbackPorts — sans guillemets', () => {
  const compose = `
services:
  api:
    ports:
      - 127.0.0.1:3010:3010
`
  const violations = checkLoopbackPorts(compose)
  assert.deepEqual(violations, [], 'port non-quoted et loopback accepté')
})

test('checkLoopbackPorts — port non-loopback détecté (guillemets doubles)', () => {
  const compose = `
services:
  api:
    ports:
      - "0.0.0.0:3010:3010"
`
  const violations = checkLoopbackPorts(compose)
  assert.deepEqual(violations, ['0.0.0.0:3010:3010'], 'port non-loopback en guillemets doubles détecté')
})

test('checkLoopbackPorts — port non-loopback détecté (guillemets simples)', () => {
  const compose = `
services:
  api:
    ports:
      - '0.0.0.0:3010:3010'
`
  const violations = checkLoopbackPorts(compose)
  assert.deepEqual(violations, ['0.0.0.0:3010:3010'], 'port non-loopback en guillemets simples détecté')
})

test('checkLoopbackPorts — port non-loopback détecté (sans guillemets)', () => {
  const compose = `
services:
  api:
    ports:
      - 0.0.0.0:3010:3010
`
  const violations = checkLoopbackPorts(compose)
  assert.deepEqual(violations, ['0.0.0.0:3010:3010'], 'port non-loopback non-quoted détecté')
})

test('checkLoopbackPorts — syntaxe longue (host_ip:) échoue explicitement', () => {
  const compose = `
services:
  api:
    ports:
      - target: 3010
        published: 3010
        host_ip: 0.0.0.0
`
  assert.throws(
    () => checkLoopbackPorts(compose),
    /syntaxe ports longue \(host_ip:\) non reconnue/,
    'syntaxe longue doit échouer avec message explicite'
  )
})

test('checkLoopbackPorts — mélange de styles (tous acceptés)', () => {
  const compose = `
services:
  api:
    ports:
      - "127.0.0.1:3010:3010"
      - '127.0.0.1:7777:7777'
      - 127.0.0.1:5432:5432
`
  const violations = checkLoopbackPorts(compose)
  assert.deepEqual(violations, [], 'mélange de styles accepté tant que loopback')
})

test('checkLoopbackPorts — mélange avec un violateur', () => {
  const compose = `
services:
  api:
    ports:
      - "127.0.0.1:3010:3010"
      - 0.0.0.0:7777:7777
      - '127.0.0.1:5432:5432'
`
  const violations = checkLoopbackPorts(compose)
  assert.deepEqual(violations, ['0.0.0.0:7777:7777'], 'un seul violateur dans le mélange')
})
