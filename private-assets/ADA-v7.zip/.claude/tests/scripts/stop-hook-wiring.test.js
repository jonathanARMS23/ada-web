#!/usr/bin/env node
'use strict'
/**
 * tests/scripts/stop-hook-wiring.test.js — F2 : le hook Stop est réellement livré
 *
 * Régression corrigée : `.claude/settings.json` (la source livrée) n'avait AUCUNE
 * clé `hooks.Stop`. Le code de fin de session (auto-banking, télémétrie tokens,
 * note Obsidian) existait et était testé, mais n'était jamais déclenché : aucun
 * profil installé ne le câblait.
 *
 * Trois surfaces vérifiées :
 *   1. la SOURCE livrée (`.claude/settings.json`) câble stop-hook.js, fail-open ;
 *   2. install.sh sur un PROFIL NEUF → settings.json avec le hook Stop ;
 *   3. install.sh sur un PROFIL EXISTANT (merge_settings) → hook Stop ajouté
 *      sans perdre ni dupliquer les hooks/permissions du client.
 *
 * Harnais install.sh : identique à install-sh.test.js — le script est copié MOINS
 * sa dernière ligne (`main "$@"`), ce qui le rend sourçable en « bibliothèque ».
 * La copie vit dans un tmpdir (le dépôt reste propre), donc SOURCE_DIR/CLAUDE_DIR
 * — calculés depuis BASH_SOURCE — sont réassignés vers le dépôt après le source.
 * install_profile() n'écrit que dans le profil qu'on lui passe : jamais ~/.claude.
 */

const { test, describe } = require('node:test')
const assert = require('node:assert/strict')
const { join } = require('node:path')
const { execFileSync, spawnSync } = require('node:child_process')
const { mkdtempSync, writeFileSync, readFileSync, chmodSync, rmSync } = require('node:fs')
const { tmpdir } = require('node:os')

const REPO_ROOT = join(__dirname, '../../..')
const INSTALL_SH = join(REPO_ROOT, 'install.sh')
const SRC_SETTINGS = join(REPO_ROOT, '.claude/settings.json')

const readJson = p => JSON.parse(readFileSync(p, 'utf8'))
const stopEntries = settings => (settings.hooks && settings.hooks.Stop) || []

// ── 1. La source livrée ───────────────────────────────────────────────────────

describe('.claude/settings.json — hook Stop livré (F2)', () => {
  test('hooks.Stop existe, est non vide et pointe sur stop-hook.js', () => {
    const entries = stopEntries(readJson(SRC_SETTINGS))
    assert.ok(Array.isArray(entries) && entries.length > 0,
      'settings.json doit livrer au moins une entrée hooks.Stop (sinon la fin de session ne tourne jamais)')
    assert.match(JSON.stringify(entries), /hooks\/stop-hook\.js/)
  })

  test('résolution de chemin cohérente avec pre-bash/post-bash (projet puis profil)', () => {
    const cmd = stopEntries(readJson(SRC_SETTINGS))[0].hooks[0].command
    assert.match(cmd, /\$\{CLAUDE_PROJECT_DIR:-\.\}\/\.claude\/hooks\/stop-hook\.js/)
    assert.match(cmd, /\$\{CLAUDE_CONFIG_DIR:-\$HOME\/\.claude\}\/hooks\/stop-hook\.js/)
  })

  /**
   * Fail-open, avec la nuance propre à Stop : exit 2 est un code MÉTIER
   * (stop-hook bloque et injecte le rappel /summarize), il doit passer ;
   * tout autre code non nul est une PANNE du hook et doit devenir 0.
   * On substitue un faux `node` en tête de PATH pour piloter le code de sortie.
   */
  for (const [fakeExit, expected, why] of [
    [0, 0, 'succès → laisse passer'],
    [2, 2, 'exit 2 métier (rappel /summarize) → préservé'],
    [1, 0, 'panne du hook → fail-open, la fin de session n\'est jamais bloquée'],
    [127, 0, 'node/hook introuvable → fail-open'],
  ]) {
    test(`code de sortie : node exit ${fakeExit} → hook exit ${expected} (${why})`, () => {
      const dir = mkdtempSync(join(tmpdir(), 'ada-stop-exit-'))
      try {
        writeFileSync(join(dir, 'node'), `#!/bin/sh\nexit ${fakeExit}\n`)
        chmodSync(join(dir, 'node'), 0o755)
        const cmd = stopEntries(readJson(SRC_SETTINGS))[0].hooks[0].command
        const r = spawnSync('bash', ['-c', cmd], {
          encoding: 'utf8',
          env: { ...process.env, PATH: `${dir}:${process.env.PATH}`, CLAUDE_PROJECT_DIR: REPO_ROOT },
        })
        assert.equal(r.status, expected)
      } finally {
        rmSync(dir, { recursive: true, force: true })
      }
    })
  }
})

// ── 1 bis. Le diagnostic `ada status` reflète le câblage réel ─────────────────

/**
 * `ada status` lit hooks.Stop du profil ACTIF et compte les entrées câblées.
 * Le diagnostic ne suppose plus que les deux noms de fichiers (stop-hook /
 * session-end) apparaissent dans la commande : stop-hook.js appelle
 * session-end.run() IN-PROCESS, une seule entrée câble donc les deux logiques.
 *
 * Profil jetable : HOME est redirigé vers un tmpdir (ada.js résout
 * ~/.ada.json puis ~/.<activeProfile>), aucun profil réel n'est lu ni écrit.
 */
describe('ada status — ✓ Stop / ✗ Stop', () => {
  const { mkdirSync } = require('node:fs')

  function statusWithSettings(settings) {
    const home = mkdtempSync(join(tmpdir(), 'ada-fakehome-'))
    try {
      const profile = join(home, '.claude-fixture')
      mkdirSync(profile, { recursive: true })
      writeFileSync(join(home, '.ada.json'), JSON.stringify({
        activeProfile: 'claude-fixture',
        sourceDir: join(REPO_ROOT, '.claude'),
        installedProfiles: ['claude-fixture'],
      }))
      writeFileSync(join(profile, 'settings.json'), JSON.stringify(settings, null, 2))
      const r = spawnSync(process.execPath, [join(REPO_ROOT, '.claude/bin/ada.js'), 'status'], {
        encoding: 'utf8',
        env: { ...process.env, HOME: home, ADA_HEADLESS: '0' },
      })
      return (r.stdout || '') + (r.stderr || '')
    } finally {
      rmSync(home, { recursive: true, force: true })
    }
  }

  test('profil avec le hook Stop livré → ✓ Stop(1)', () => {
    const out = statusWithSettings(readJson(SRC_SETTINGS))
    assert.match(out, /✓ Stop\(1\)/)
    assert.doesNotMatch(out, /✗ Stop/)
  })

  test('profil sans hook Stop → ✗ Stop + avertissement', () => {
    const settings = readJson(SRC_SETTINGS)
    delete settings.hooks.Stop
    const out = statusWithSettings(settings)
    assert.match(out, /✗ Stop/)
    assert.match(out, /HOOKS NON CÂBLÉS/)
  })
})

// ── 2 & 3. install.sh : profil neuf et profil existant ────────────────────────

describe('install.sh — le hook Stop arrive dans les profils', () => {
  /** Copie sourçable d'install.sh + install_profile sur un profil jetable. */
  function installProfile(profileDir) {
    const dir = mkdtempSync(join(tmpdir(), 'ada-install-lib-'))
    try {
      const lines = readFileSync(INSTALL_SH, 'utf8').replace(/\n$/, '').split('\n')
      assert.equal(lines[lines.length - 1], 'main "$@"',
        'le harnais suppose que install.sh se termine par `main "$@"` — adapter si ça change')
      const lib = join(dir, 'install-lib.sh')
      writeFileSync(lib, lines.slice(0, -1).join('\n') + '\n')
      execFileSync('bash', ['-c',
        `source ${JSON.stringify(lib)}
         SOURCE_DIR=${JSON.stringify(REPO_ROOT)}
         CLAUDE_DIR="$SOURCE_DIR/.claude"
         MANIFEST_FILE="$CLAUDE_DIR/.ada-manifest.json"
         install_profile ${JSON.stringify(profileDir)}`,
      ], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] })
    } finally {
      rmSync(dir, { recursive: true, force: true })
    }
    return readJson(join(profileDir, 'settings.json'))
  }

  function withTmpProfile(fn) {
    const dir = mkdtempSync(join(tmpdir(), 'ada-profile-'))
    try { return fn(join(dir, '.claude-jetable')) } finally { rmSync(dir, { recursive: true, force: true }) }
  }

  test('profil NEUF : settings.json copié avec le hook Stop câblé', () => {
    withTmpProfile(profileDir => {
      const out = installProfile(profileDir)
      assert.match(JSON.stringify(stopEntries(out)), /hooks\/stop-hook\.js/)
    })
  })

  test('profil EXISTANT : le hook Stop est mergé sans casser la config client', () => {
    withTmpProfile(profileDir => {
      // settings.json « client » : pas de Stop, mais des hooks et permissions custom.
      const clientPost = {
        matcher: 'Write',
        hooks: [{ type: 'command', command: 'echo hook-maison-du-client' }],
      }
      const client = {
        env: { MA_VAR_CLIENT: '42' },
        permissions: { allow: ['Bash(mon-outil-maison *)'], deny: ['Bash(rm -rf /mon-disque)'] },
        hooks: { PostToolUse: [clientPost] },
      }
      require('node:fs').mkdirSync(profileDir, { recursive: true })
      writeFileSync(join(profileDir, 'settings.json'), JSON.stringify(client, null, 2))

      const out = installProfile(profileDir)

      // (a) le hook Stop est arrivé, une seule fois
      const stops = stopEntries(out)
      assert.equal(stops.filter(e => JSON.stringify(e).includes('stop-hook.js')).length, 1,
        'exactement une entrée Stop stop-hook.js (ni absente, ni dupliquée)')

      // (b) rien du client n'a disparu
      const post = JSON.stringify(out.hooks.PostToolUse)
      assert.match(post, /hook-maison-du-client/, 'le hook client doit être préservé')
      assert.match(post, /post-bash/, 'le hook ADA doit être ajouté à côté')
      assert.deepEqual(out.permissions.allow, ['Bash(mon-outil-maison *)'],
        'permissions.allow n\'est jamais mergé (choix délibéré) — la valeur client reste intacte')
      assert.ok(out.permissions.deny.includes('Bash(rm -rf /mon-disque)'),
        'la deny client doit survivre à l\'union avec la deny ADA')
      assert.equal(out.env.MA_VAR_CLIENT, '42')

      // (c) aucun doublon introduit dans les autres events
      for (const [event, entries] of Object.entries(out.hooks)) {
        const keys = entries.map(e => JSON.stringify(e))
        assert.equal(new Set(keys).size, keys.length, `doublon d'entrée dans hooks.${event}`)
      }
    })
  })

  test('profil EXISTANT réinstallé deux fois : toujours une seule entrée Stop (idempotence)', () => {
    withTmpProfile(profileDir => {
      installProfile(profileDir)
      const out = installProfile(profileDir)
      assert.equal(stopEntries(out).filter(e => JSON.stringify(e).includes('stop-hook.js')).length, 1)
    })
  })
})
