#!/usr/bin/env node
'use strict'
const { test, describe, before, after } = require('node:test')
const assert = require('node:assert/strict')
const { mkdirSync, rmSync, existsSync, readFileSync, writeFileSync, utimesSync } = require('fs')
const { join } = require('path')
const { execSync } = require('child_process')

const TMP      = join(__dirname, '../../..', '.test-tmp-audit')
const AUDIT_JS = join(__dirname, '../../workers/audit.js')
const SRC_DIR  = join(TMP, 'src')
const OUT_FILE = join(TMP, 'memory', 'projects', 'workspace', 'audit.md')

let report = ''

function writeVulnFile(filename, content) {
  const path = join(SRC_DIR, filename)
  writeFileSync(path, content, 'utf8')
  const now = new Date()
  utimesSync(path, now, now)
}

before(() => {
  mkdirSync(SRC_DIR, { recursive: true })
  mkdirSync(join(TMP, 'memory', 'projects', 'workspace'), { recursive: true })

  // SQL Injection
  writeVulnFile('repo.ts', `
async getUser(id) {
  return db.query(\`SELECT * FROM users WHERE id = \${id}\`)
}`)

  // Hardcoded secret
  writeVulnFile('config.ts', `
const apikey = "sk-prod-abcdefghij"
const password = "super-secret-pass-123"`)

  // JWT sans verify
  writeVulnFile('auth.ts', `
const payload = jwt.decode(token)
return payload.userId`)

  // eval dynamique
  writeVulnFile('engine.ts', `
function run(code) {
  return eval(code)
}`)

  // innerHTML dynamique
  writeVulnFile('component.tsx', `
function render(data) {
  container.innerHTML = data.content
}`)

  // CORS wildcard
  writeVulnFile('main.ts', `
app.use(cors({ origin: '*' }))`)

  // Données sensibles dans logs
  writeVulnFile('user.service.ts', `
async login(password) {
  console.log('login with password', password)
}`)

  // Path traversal (readFile, pas readFileSync)
  writeVulnFile('files.ts', `
async getFile(req) {
  return readFile(req.query.path, handler)
}`)

  // Run audit une seule fois sur tous les fichiers
  execSync(`node "${AUDIT_JS}"`, {
    cwd: TMP,
    env: { ...process.env, CLAUDE_CONFIG_DIR: TMP, AI_DEV_PROJECT: 'workspace' },
    encoding: 'utf8'
  })
  report = existsSync(OUT_FILE) ? readFileSync(OUT_FILE, 'utf8') : ''
})

after(() => { try { rmSync(TMP, { recursive: true }) } catch {} })

// ─── Vérification du rapport ──────────────────────────────────────────────────

test('rapport généré avec header', () => {
  assert.ok(report.includes('Audit Sécurité'), `report: ${report.slice(0, 200)}`)
})

test('rapport contient le projet et le mode', () => {
  assert.ok(report.includes('workspace'))
  assert.ok(report.includes('complet'))
})

// ─── Règles OWASP détectées ───────────────────────────────────────────────────

describe('Règles OWASP détectées', () => {
  test('SQL_INJECTION détecté', () => {
    assert.ok(report.includes('SQL_INJECTION') || report.includes('Injection SQL'),
      `SQL_INJECTION manquant — report: ${report.slice(0, 400)}`)
  })

  test('HARDCODED_SECRET détecté', () => {
    assert.ok(report.includes('HARDCODED_SECRET') || report.includes('hardcodé'),
      `HARDCODED_SECRET manquant — report: ${report.slice(0, 400)}`)
  })

  test('JWT_NO_VERIFY détecté', () => {
    assert.ok(report.includes('JWT_NO_VERIFY') || report.includes('JWT'),
      `JWT_NO_VERIFY manquant — report: ${report.slice(0, 400)}`)
  })

  test('UNSAFE_EVAL détecté', () => {
    assert.ok(report.includes('UNSAFE_EVAL') || report.includes('eval'),
      `UNSAFE_EVAL manquant — report: ${report.slice(0, 400)}`)
  })

  test('XSS_INNERHTML détecté', () => {
    assert.ok(report.includes('XSS_INNERHTML') || report.includes('innerHTML'),
      `XSS_INNERHTML manquant — report: ${report.slice(0, 400)}`)
  })

  test('CORS_WILDCARD détecté', () => {
    assert.ok(report.includes('CORS_WILDCARD') || report.includes('CORS'),
      `CORS_WILDCARD manquant — report: ${report.slice(0, 400)}`)
  })

  test('SENSITIVE_LOG détecté', () => {
    assert.ok(report.includes('SENSITIVE_LOG') || report.includes('sensibles'),
      `SENSITIVE_LOG manquant — report: ${report.slice(0, 400)}`)
  })

  test('PATH_TRAVERSAL détecté', () => {
    assert.ok(report.includes('PATH_TRAVERSAL') || report.includes('traversal') || report.includes('chemin'),
      `PATH_TRAVERSAL manquant — report: ${report.slice(0, 400)}`)
  })
})

// ─── Commentaires ignorés ─────────────────────────────────────────────────────

describe('Commentaires ignorés', () => {
  test('commentaires // single-line ne génèrent pas de faux positifs', () => {
    const tmpDir = join(TMP, '..', '.test-tmp-audit-comments')
    mkdirSync(join(tmpDir, 'memory', 'projects', 'workspace'), { recursive: true })
    mkdirSync(join(tmpDir, 'src'), { recursive: true })
    const f = join(tmpDir, 'src', 'comments.ts')
    writeFileSync(f, `
// password = "should-be-ignored-in-line-comment"
// const apikey = "sk-test-fake-should-not-trigger"
// jwt.decode(token)
export const VERSION = '1.0.0'`)
    const now = new Date()
    utimesSync(f, now, now)
    execSync(`node "${AUDIT_JS}"`, {
      cwd: tmpDir,
      env: { ...process.env, CLAUDE_CONFIG_DIR: tmpDir, AI_DEV_PROJECT: 'workspace' },
      encoding: 'utf8'
    })
    const out = readFileSync(join(tmpDir, 'memory', 'projects', 'workspace', 'audit.md'), 'utf8')
    assert.ok(out.includes('Aucun finding') || out.includes('RAS') || out.includes('✅'),
      `Commentaires // ne devraient pas déclencher de finding — got: ${out.slice(0, 300)}`)
    rmSync(tmpDir, { recursive: true })
  })

  test('commentaires /* */ block ne génèrent pas de faux positifs', () => {
    const tmpDir = join(TMP, '..', '.test-tmp-audit-block')
    mkdirSync(join(tmpDir, 'memory', 'projects', 'workspace'), { recursive: true })
    mkdirSync(join(tmpDir, 'src'), { recursive: true })
    const f = join(tmpDir, 'src', 'block.ts')
    writeFileSync(f, `/**
 * Example: password = "do-not-do-this-example"
 * Usage: jwt.decode(token)  ← bad practice
 */
export const multiply = (a: number, b: number) => a * b`)
    const now = new Date()
    utimesSync(f, now, now)
    execSync(`node "${AUDIT_JS}"`, {
      cwd: tmpDir,
      env: { ...process.env, CLAUDE_CONFIG_DIR: tmpDir, AI_DEV_PROJECT: 'workspace' },
      encoding: 'utf8'
    })
    const out = readFileSync(join(tmpDir, 'memory', 'projects', 'workspace', 'audit.md'), 'utf8')
    assert.ok(out.includes('Aucun finding') || out.includes('RAS') || out.includes('✅'),
      `Block comments ne devraient pas déclencher de finding — got: ${out.slice(0, 300)}`)
    rmSync(tmpDir, { recursive: true })
  })

  test('readFileSync avec req.params déclenche PATH_TRAVERSAL', () => {
    const tmpDir = join(TMP, '..', '.test-tmp-audit-sync')
    mkdirSync(join(tmpDir, 'memory', 'projects', 'workspace'), { recursive: true })
    mkdirSync(join(tmpDir, 'src'), { recursive: true })
    const f = join(tmpDir, 'src', 'sync.ts')
    writeFileSync(f, `async getFile(req) { return readFileSync(req.params.file, 'utf8') }`)
    const now = new Date()
    utimesSync(f, now, now)
    execSync(`node "${AUDIT_JS}"`, {
      cwd: tmpDir,
      env: { ...process.env, CLAUDE_CONFIG_DIR: tmpDir, AI_DEV_PROJECT: 'workspace' },
      encoding: 'utf8'
    })
    const out = readFileSync(join(tmpDir, 'memory', 'projects', 'workspace', 'audit.md'), 'utf8')
    assert.ok(out.includes('PATH_TRAVERSAL') || out.includes('traversal'),
      `readFileSync devrait déclencher PATH_TRAVERSAL — got: ${out.slice(0, 300)}`)
    rmSync(tmpDir, { recursive: true })
  })
})

// ─── Aucun finding sur fichier propre ────────────────────────────────────────

describe('Aucun finding sur fichier propre', () => {
  test('fichier propre → section ✅', () => {
    const cleanTmp = join(TMP, '..', '.test-tmp-audit-clean')
    mkdirSync(join(cleanTmp, 'memory', 'projects', 'workspace'), { recursive: true })
    mkdirSync(join(cleanTmp, 'src'), { recursive: true })
    const cleanFile = join(cleanTmp, 'src', 'clean.ts')
    writeFileSync(cleanFile, `export function add(a: number, b: number): number { return a + b }`)
    const now = new Date()
    utimesSync(cleanFile, now, now)
    execSync(`node "${AUDIT_JS}"`, {
      cwd: cleanTmp,
      env: { ...process.env, CLAUDE_CONFIG_DIR: cleanTmp, AI_DEV_PROJECT: 'workspace' },
      encoding: 'utf8'
    })
    const cleanOut = join(cleanTmp, 'memory', 'projects', 'workspace', 'audit.md')
    const out = existsSync(cleanOut) ? readFileSync(cleanOut, 'utf8') : ''
    assert.ok(out.includes('Aucun finding') || out.includes('RAS') || out.includes('✅'),
      `Fichier propre devrait donner "aucun finding" — got: ${out.slice(0, 200)}`)
    rmSync(cleanTmp, { recursive: true })
  })
})
