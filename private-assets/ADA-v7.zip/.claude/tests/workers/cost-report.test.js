#!/usr/bin/env node
'use strict'
/**
 * tests/workers/cost-report.test.js
 * Tests unitaires pour workers/cost-report.js
 */

const { describe, test, before, after } = require('node:test')
const assert = require('node:assert/strict')
const { mkdirSync, rmSync, writeFileSync } = require('node:fs')
const { join } = require('node:path')

const COST_REPORT = join(__dirname, '../../workers/cost-report.js')
const { resolveModel, computeCost, readSessionJsonl, aggregateSessions, buildReport, PRICING } = require(COST_REPORT)

const TMP = join(__dirname, '../../..', '.test-tmp-cost-report')

before(() => mkdirSync(TMP, { recursive: true }))
after(() => { try { rmSync(TMP, { recursive: true }) } catch {} })

// ─── resolveModel ─────────────────────────────────────────────────────────────

describe('resolveModel', () => {
  test('retourne la clé exacte si elle correspond', () => {
    assert.equal(resolveModel('claude-sonnet-4-6'), 'claude-sonnet-4-6')
    assert.equal(resolveModel('claude-haiku-4-5'), 'claude-haiku-4-5')
    assert.equal(resolveModel('claude-opus-4-8'), 'claude-opus-4-8')
  })

  test('normalise un ID avec suffixe de date', () => {
    assert.equal(resolveModel('claude-sonnet-4-6-20251001'), 'claude-sonnet-4-6')
    assert.equal(resolveModel('claude-haiku-4-5-20260101'), 'claude-haiku-4-5')
    assert.equal(resolveModel('claude-opus-4-8-20260601'), 'claude-opus-4-8')
  })

  test('retourne le fallback sonnet pour un modèle inconnu', () => {
    assert.equal(resolveModel('claude-unknown-9-0'), 'claude-sonnet-5')
    assert.equal(resolveModel('gpt-4o'), 'claude-sonnet-5')
  })

  test('retourne le fallback sonnet pour une chaîne vide', () => {
    assert.equal(resolveModel(''), 'claude-sonnet-5')
    assert.equal(resolveModel(null), 'claude-sonnet-5')
    assert.equal(resolveModel(undefined), 'claude-sonnet-5')
  })
})

// ─── computeCost ─────────────────────────────────────────────────────────────

describe('computeCost', () => {
  test('calcule le coût USD pour sonnet avec uniquement input/output', () => {
    const usage = { input_tokens: 1_000_000, output_tokens: 1_000_000 }
    const cost = computeCost(usage, 'claude-sonnet-4-6')
    // 1M input * 3.00 + 1M output * 15.00 = 18.00
    assert.ok(Math.abs(cost - 18.00) < 0.001, `attendu ~18.00, reçu ${cost}`)
  })

  test('calcule le coût USD pour haiku', () => {
    const usage = { input_tokens: 1_000_000, output_tokens: 0 }
    const cost = computeCost(usage, 'claude-haiku-4-5')
    // 1M input * 1.00 = 1.00
    assert.ok(Math.abs(cost - 1.00) < 0.001, `attendu ~1.00, reçu ${cost}`)
  })

  test('calcule le coût USD pour opus', () => {
    const usage = { input_tokens: 0, output_tokens: 1_000_000 }
    const cost = computeCost(usage, 'claude-opus-4-8')
    // 1M output * 25.00 = 25.00
    assert.ok(Math.abs(cost - 25.00) < 0.001, `attendu ~25.00, reçu ${cost}`)
  })

  test('cache_read donne un coût inférieur à input seul (même volume)', () => {
    const usageInput = { input_tokens: 100_000, output_tokens: 0 }
    const usageCacheRead = { input_tokens: 0, output_tokens: 0, cache_read_input_tokens: 100_000 }
    const costInput = computeCost(usageInput, 'claude-sonnet-4-6')
    const costCacheRead = computeCost(usageCacheRead, 'claude-sonnet-4-6')
    assert.ok(costCacheRead < costInput, `cache_read (${costCacheRead}) devrait être < input (${costInput})`)
  })

  test('cache_creation coûte plus que input standard pour sonnet', () => {
    const usageInput = { input_tokens: 100_000 }
    const usageCacheWrite = { cache_creation_input_tokens: 100_000 }
    const costInput = computeCost(usageInput, 'claude-sonnet-4-6')
    const costWrite = computeCost(usageCacheWrite, 'claude-sonnet-4-6')
    assert.ok(costWrite > costInput, `cache_write (${costWrite}) devrait être > input (${costInput})`)
  })

  test('retourne 0 pour usage vide', () => {
    assert.equal(computeCost({}, 'claude-sonnet-4-6'), 0)
  })

  test('retourne 0 pour modèle inconnu', () => {
    assert.equal(computeCost({ input_tokens: 999_999 }, 'model-inexistant'), 0)
  })
})

// ─── readSessionJsonl ─────────────────────────────────────────────────────────

describe('readSessionJsonl', () => {
  test('retourne [] si le fichier n\'existe pas', () => {
    const result = readSessionJsonl(join(TMP, 'inexistant.jsonl'))
    assert.deepEqual(result, [])
  })

  test('ignore les lignes non-JSON', () => {
    const fp = join(TMP, 'bad-lines.jsonl')
    writeFileSync(fp, 'pas du json\n{"type":"user"}\naussi mauvais{')
    const result = readSessionJsonl(fp)
    assert.deepEqual(result, [])
  })

  test('ignore les lignes sans usage', () => {
    const fp = join(TMP, 'no-usage.jsonl')
    const line = JSON.stringify({ type: 'assistant', message: { model: 'claude-sonnet-4-6', id: 'msg_1' } })
    writeFileSync(fp, line + '\n')
    const result = readSessionJsonl(fp)
    assert.deepEqual(result, [])
  })

  test('ignore les lignes de type user', () => {
    const fp = join(TMP, 'user-lines.jsonl')
    const line = JSON.stringify({ type: 'user', message: { role: 'user', content: 'bonjour' } })
    writeFileSync(fp, line + '\n')
    const result = readSessionJsonl(fp)
    assert.deepEqual(result, [])
  })

  test('extrait les entrées assistant avec usage', () => {
    const fp = join(TMP, 'valid.jsonl')
    const line = JSON.stringify({
      type: 'assistant',
      message: {
        id: 'msg_abc',
        model: 'claude-sonnet-4-6',
        usage: { input_tokens: 100, output_tokens: 50, cache_creation_input_tokens: 0, cache_read_input_tokens: 200 }
      }
    })
    writeFileSync(fp, line + '\n')
    const result = readSessionJsonl(fp)
    assert.equal(result.length, 1)
    assert.equal(result[0].model, 'claude-sonnet-4-6')
    assert.equal(result[0].usage.input_tokens, 100)
  })

  test('déduplique par message.id en gardant le max output_tokens (streaming)', () => {
    const fp = join(TMP, 'streaming.jsonl')
    const makeLine = (outTokens) => JSON.stringify({
      type: 'assistant',
      message: {
        id: 'msg_stream',
        model: 'claude-sonnet-4-6',
        usage: { input_tokens: 10, output_tokens: outTokens, cache_creation_input_tokens: 0, cache_read_input_tokens: 0 }
      }
    })
    // Simule 3 lignes de streaming : 8, 8, 250 (la dernière est le vrai total)
    writeFileSync(fp, [makeLine(8), makeLine(8), makeLine(250)].join('\n') + '\n')
    const result = readSessionJsonl(fp)
    assert.equal(result.length, 1, 'doit dédupliquer en 1 entrée')
    assert.equal(result[0].usage.output_tokens, 250, 'doit garder le max output_tokens')
  })
})

// ─── aggregateSessions ────────────────────────────────────────────────────────

describe('aggregateSessions', () => {
  test('retourne [] si le dossier n\'existe pas', () => {
    const result = aggregateSessions(join(TMP, 'inexistant'))
    assert.deepEqual(result, [])
  })

  test('somme correctement les tokens de plusieurs messages dans une session', () => {
    const projDir = join(TMP, 'proj-aggregate')
    mkdirSync(projDir, { recursive: true })
    const lines = [
      { type: 'assistant', message: { id: 'msg_1', model: 'claude-sonnet-4-6', usage: { input_tokens: 100, output_tokens: 50, cache_creation_input_tokens: 0, cache_read_input_tokens: 0 } } },
      { type: 'assistant', message: { id: 'msg_2', model: 'claude-sonnet-4-6', usage: { input_tokens: 200, output_tokens: 80, cache_creation_input_tokens: 0, cache_read_input_tokens: 0 } } },
    ].map(l => JSON.stringify(l)).join('\n')
    writeFileSync(join(projDir, 'session1.jsonl'), lines)

    const sessions = aggregateSessions(projDir, 10)
    assert.equal(sessions.length, 1)
    assert.equal(sessions[0].inputTokens, 300)
    assert.equal(sessions[0].outputTokens, 130)
  })
})

// ─── buildReport ─────────────────────────────────────────────────────────────

describe('buildReport', () => {
  test('calcule cacheEfficiency = cacheRead / (input + cacheRead)', () => {
    const sessions = [{
      file: 'test.jsonl', date: new Date(), model: 'claude-sonnet-4-6',
      cost: 0, inputTokens: 100, outputTokens: 50,
      cacheCreationTokens: 0, cacheReadTokens: 400, messageCount: 1
    }]
    const report = buildReport(sessions)
    // 400 / (100 + 400) = 0.8 = 80%
    assert.ok(Math.abs(report.cacheEfficiency - 0.8) < 0.001, `efficiency attendue 0.8, reçue ${report.cacheEfficiency}`)
  })

  test('ne crash pas avec 0 tokens (division par zéro protégée)', () => {
    const sessions = [{
      file: 'empty.jsonl', date: new Date(), model: 'claude-sonnet-4-6',
      cost: 0, inputTokens: 0, outputTokens: 0,
      cacheCreationTokens: 0, cacheReadTokens: 0, messageCount: 0
    }]
    assert.doesNotThrow(() => buildReport(sessions))
    const report = buildReport(sessions)
    assert.equal(report.cacheEfficiency, 0)
    assert.equal(report.totalCostUSD, 0)
  })

  test('agrège byModel correctement', () => {
    const sessions = [
      { file: 'a.jsonl', date: new Date(), model: 'claude-sonnet-4-6', cost: 1.0, inputTokens: 100, outputTokens: 10, cacheCreationTokens: 0, cacheReadTokens: 0, messageCount: 1 },
      { file: 'b.jsonl', date: new Date(), model: 'claude-haiku-4-5',  cost: 0.5, inputTokens:  50, outputTokens:  5, cacheCreationTokens: 0, cacheReadTokens: 0, messageCount: 1 },
    ]
    const report = buildReport(sessions)
    assert.ok(report.byModel['claude-sonnet-4-6'])
    assert.ok(report.byModel['claude-haiku-4-5'])
    assert.equal(report.byModel['claude-sonnet-4-6'].sessions, 1)
    assert.equal(report.byModel['claude-haiku-4-5'].sessions, 1)
    assert.ok(Math.abs(report.totalCostUSD - 1.5) < 0.001)
  })

  test('retourne [] pour sessions vides', () => {
    const report = buildReport([])
    assert.equal(report.totalCostUSD, 0)
    assert.deepEqual(report.sessions, [])
    assert.deepEqual(report.byModel, {})
  })
})
