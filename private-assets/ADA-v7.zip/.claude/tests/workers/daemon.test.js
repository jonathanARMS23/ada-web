#!/usr/bin/env node
'use strict'
const { test, describe, before, after } = require('node:test')
const assert = require('node:assert/strict')
const { mkdtempSync, rmSync, writeFileSync, unlinkSync } = require('fs')
const { join } = require('path')
const os = require('os')

const DAEMON_JS = join(__dirname, '../../workers/daemon.js')

// Sandbox HOME : isole loadDaemonLimits de tout ~/.ada.json réel.
// Aucun .ada.json écrit ici → on teste défaut + env + clamp.
let HOME_TMP
let _savedEnv = {}

function snapshotEnv() {
  _savedEnv = {
    HOME: process.env.HOME,
    ADA_DAEMON_TTL_SECS: process.env.ADA_DAEMON_TTL_SECS,
    ADA_DAEMON_IDLE_SECS: process.env.ADA_DAEMON_IDLE_SECS,
  }
}
function restoreEnv() {
  for (const [k, v] of Object.entries(_savedEnv)) {
    if (v === undefined) delete process.env[k]
    else process.env[k] = v
  }
}

before(() => {
  snapshotEnv()
  HOME_TMP = mkdtempSync(join(os.tmpdir(), 'ada-daemon-home-'))
  process.env.HOME = HOME_TMP
  delete process.env.ADA_DAEMON_TTL_SECS
  delete process.env.ADA_DAEMON_IDLE_SECS
})

after(() => {
  restoreEnv()
  try { rmSync(HOME_TMP, { recursive: true }) } catch {}
})

const { shouldShutdown, loadDaemonLimits } = require(DAEMON_JS)

const HOUR = 3_600_000
const DAY  = 86_400_000
const MIN  = 60_000

// ─── shouldShutdown (prédicat pur) ─────────────────────────────────────────────

describe('shouldShutdown', () => {
  test('TTL atteint → stop ttl', () => {
    const r = shouldShutdown({
      now: 1000 + 24 * HOUR, startedAt: 1000,
      lastActivity: 1000 + 24 * HOUR, ttlMs: 24 * HOUR, idleShutdownMs: 0,
    })
    assert.deepEqual(r, { stop: true, reason: 'ttl' })
  })

  test('idle atteint → stop idle', () => {
    const now = 1000 + 2 * HOUR
    const r = shouldShutdown({
      now, startedAt: 1000, lastActivity: now - 30 * MIN,
      ttlMs: 24 * HOUR, idleShutdownMs: 30 * MIN,
    })
    assert.deepEqual(r, { stop: true, reason: 'idle' })
  })

  test('ni TTL ni idle → pas de stop', () => {
    const now = 1000 + 1 * HOUR
    const r = shouldShutdown({
      now, startedAt: 1000, lastActivity: now - 5 * MIN,
      ttlMs: 24 * HOUR, idleShutdownMs: 30 * MIN,
    })
    assert.deepEqual(r, { stop: false, reason: null })
  })

  test('TTL prioritaire sur idle (les deux atteints)', () => {
    const now = 1000 + 48 * HOUR
    const r = shouldShutdown({
      now, startedAt: 1000, lastActivity: 1000, // idle aussi dépassé
      ttlMs: 24 * HOUR, idleShutdownMs: 30 * MIN,
    })
    assert.deepEqual(r, { stop: true, reason: 'ttl' })
  })

  test('limites désactivées (0) → jamais de stop', () => {
    const r = shouldShutdown({
      now: 1000 + 365 * DAY, startedAt: 1000,
      lastActivity: 1000, ttlMs: 0, idleShutdownMs: 0,
    })
    assert.deepEqual(r, { stop: false, reason: null })
  })

  test('TTL exactement au seuil (>=) → stop', () => {
    const r = shouldShutdown({
      now: 1000 + 24 * HOUR, startedAt: 1000,
      lastActivity: 1000 + 24 * HOUR, ttlMs: 24 * HOUR, idleShutdownMs: 0,
    })
    assert.equal(r.stop, true)
    assert.equal(r.reason, 'ttl')
  })
})

// ─── loadDaemonLimits (config > env > défaut + clamp) ──────────────────────────

describe('loadDaemonLimits', () => {
  test('défaut : TTL 24h, idle désactivé (0)', () => {
    delete process.env.ADA_DAEMON_TTL_SECS
    delete process.env.ADA_DAEMON_IDLE_SECS
    const { ttlMs, idleShutdownMs } = loadDaemonLimits()
    assert.equal(ttlMs, 24 * HOUR)
    assert.equal(idleShutdownMs, 0)
  })

  test('override env TTL et idle', () => {
    process.env.ADA_DAEMON_TTL_SECS = String(2 * 3600)   // 2h
    process.env.ADA_DAEMON_IDLE_SECS = String(45 * 60)   // 45min
    const { ttlMs, idleShutdownMs } = loadDaemonLimits()
    assert.equal(ttlMs, 2 * HOUR)
    assert.equal(idleShutdownMs, 45 * MIN)
    delete process.env.ADA_DAEMON_TTL_SECS
    delete process.env.ADA_DAEMON_IDLE_SECS
  })

  test('clamp bas : TTL < 1min ramené au minimum (1min)', () => {
    process.env.ADA_DAEMON_TTL_SECS = '10' // 10s < 60s
    const { ttlMs } = loadDaemonLimits()
    assert.equal(ttlMs, MIN)
    delete process.env.ADA_DAEMON_TTL_SECS
  })

  test('clamp haut : TTL > 7j ramené au maximum (7j)', () => {
    process.env.ADA_DAEMON_TTL_SECS = String(30 * 24 * 3600) // 30j
    const { ttlMs } = loadDaemonLimits()
    assert.equal(ttlMs, 7 * DAY)
    delete process.env.ADA_DAEMON_TTL_SECS
  })

  test('TTL = 0 (env) → désactivé', () => {
    process.env.ADA_DAEMON_TTL_SECS = '0'
    const { ttlMs } = loadDaemonLimits()
    assert.equal(ttlMs, 0)
    delete process.env.ADA_DAEMON_TTL_SECS
  })

  test('TTL négatif (env) → désactivé', () => {
    process.env.ADA_DAEMON_TTL_SECS = '-5'
    const { ttlMs } = loadDaemonLimits()
    assert.equal(ttlMs, 0)
    delete process.env.ADA_DAEMON_TTL_SECS
  })
})

// ─── loadDaemonLimits : branche config ~/.ada.json (chemin le plus à risque) ────

describe('loadDaemonLimits — config ~/.ada.json', () => {
  const ADA_PATH = () => join(HOME_TMP, '.ada.json')
  function writeAda(obj) { writeFileSync(ADA_PATH(), JSON.stringify(obj), 'utf8') }
  function clearAda() { try { unlinkSync(ADA_PATH()) } catch {} }

  after(() => clearAda())

  test('config ttlSecs/idleSecs appliqués', () => {
    delete process.env.ADA_DAEMON_TTL_SECS
    delete process.env.ADA_DAEMON_IDLE_SECS
    writeAda({ daemon: { ttlSecs: 2 * 3600, idleSecs: 45 * 60 } })
    const { ttlMs, idleShutdownMs } = loadDaemonLimits()
    assert.equal(ttlMs, 2 * HOUR)
    assert.equal(idleShutdownMs, 45 * MIN)
    clearAda()
  })

  test('config prioritaire sur env', () => {
    process.env.ADA_DAEMON_TTL_SECS = String(6 * 3600) // env 6h
    writeAda({ daemon: { ttlSecs: 3600 } })             // config 1h
    const { ttlMs } = loadDaemonLimits()
    assert.equal(ttlMs, 1 * HOUR) // config gagne
    delete process.env.ADA_DAEMON_TTL_SECS
    clearAda()
  })

  test('ttlSecs non numérique → ignoré, fallback défaut', () => {
    delete process.env.ADA_DAEMON_TTL_SECS
    writeAda({ daemon: { ttlSecs: 'abc' } })
    const { ttlMs } = loadDaemonLimits()
    assert.equal(ttlMs, 24 * HOUR)
    clearAda()
  })

  test('JSON corrompu → tolérant, fallback défaut', () => {
    delete process.env.ADA_DAEMON_TTL_SECS
    writeFileSync(ADA_PATH(), '{ daemon: broken', 'utf8')
    const { ttlMs } = loadDaemonLimits()
    assert.equal(ttlMs, 24 * HOUR)
    clearAda()
  })

  test('config ttlSecs:0 → TTL désactivé (override défaut)', () => {
    delete process.env.ADA_DAEMON_TTL_SECS
    writeAda({ daemon: { ttlSecs: 0 } })
    const { ttlMs } = loadDaemonLimits()
    assert.equal(ttlMs, 0)
    clearAda()
  })
})
