'use strict'
/**
 * tests/workers/dashboard.test.js
 * Tests unitaires pour workers/dashboard.js (fonctions de rendu)
 */

const { describe, test, before } = require('node:test')
const assert = require('node:assert/strict')
const { join } = require('node:path')

// Les fonctions exportées quand require.main !== module
const { buildHtml, gatherData } = require(join(__dirname, '../../workers/dashboard.js'))

// ── Helpers ────────────────────────────────────────────────────────────────────

function emptyMetrics() {
  return {
    runMetrics: {
      total: 0, completed: 0, failed: 0, errors: 0, running: 0,
      avgDurationMin: 0, byPipeline: {}, topAgents: [], topFailingPhases: []
    },
    routerMetrics: { totalUpdates: 0, rows: [] },
    bankMetrics: {
      total: 0, success: 0, failure: 0, successRate: 0,
      byPhase: {}, hasInsights: false, insightsAt: undefined
    },
    rawRuns: []
  }
}

// ── describe: gatherData ───────────────────────────────────────────────────────

describe('gatherData', () => {
  test('retourne { runs, router, bank } avec des valeurs par défaut si aucune donnée', () => {
    // Utiliser un CLAUDE_CONFIG_DIR vide pour éviter les données réelles
    const origDir = process.env.CLAUDE_CONFIG_DIR
    process.env.CLAUDE_CONFIG_DIR = join(require('os').tmpdir(), 'ai-dev-test-dash-' + Date.now())

    let result
    try {
      result = gatherData()
    } finally {
      if (origDir === undefined) delete process.env.CLAUDE_CONFIG_DIR
      else process.env.CLAUDE_CONFIG_DIR = origDir
    }

    assert.ok(typeof result === 'object', 'gatherData doit retourner un objet')
    assert.ok('runMetrics' in result, 'doit contenir runMetrics')
    assert.ok('routerMetrics' in result, 'doit contenir routerMetrics')
    assert.ok('bankMetrics' in result, 'doit contenir bankMetrics')
    assert.ok('rawRuns' in result, 'doit contenir rawRuns')
  })

  test('runs.total est 0 si RUNS_DIR absent', () => {
    const origDir = process.env.CLAUDE_CONFIG_DIR
    process.env.CLAUDE_CONFIG_DIR = join(require('os').tmpdir(), 'ai-dev-test-dash-nodir-' + Date.now())

    let result
    try {
      result = gatherData()
    } finally {
      if (origDir === undefined) delete process.env.CLAUDE_CONFIG_DIR
      else process.env.CLAUDE_CONFIG_DIR = origDir
    }

    assert.strictEqual(result.runMetrics.total, 0, 'total doit être 0 sans RUNS_DIR')
    assert.deepStrictEqual(result.rawRuns, [], 'rawRuns doit être vide')
  })
})

// ── describe: buildHtml ────────────────────────────────────────────────────────

describe('buildHtml', () => {
  test('contient le titre AI-Dev-Assistant', () => {
    const html = buildHtml(emptyMetrics())
    assert.ok(html.includes('AI-Dev-Assistant'), 'Le HTML doit contenir "AI-Dev-Assistant"')
  })

  test('contient la section Runs', () => {
    const html = buildHtml(emptyMetrics())
    assert.ok(html.includes('Runs'), 'Le HTML doit contenir une section Runs')
    assert.ok(html.includes('Total runs'), 'Le HTML doit contenir "Total runs"')
  })

  test('contient la section Thompson Sampling', () => {
    const html = buildHtml(emptyMetrics())
    assert.ok(html.includes('Thompson Sampling'), 'Le HTML doit contenir "Thompson Sampling"')
  })

  test('contient meta refresh=10', () => {
    const html = buildHtml(emptyMetrics())
    assert.ok(
      html.includes('http-equiv="refresh"') && html.includes('content="10"'),
      'Le HTML doit contenir <meta http-equiv="refresh" content="10">'
    )
  })

  test('est du HTML valide (ouverture/fermeture de balises de base)', () => {
    const html = buildHtml(emptyMetrics())
    assert.ok(html.startsWith('<!DOCTYPE html>'), 'doit commencer par DOCTYPE')
    assert.ok(html.includes('<html'), 'doit contenir <html')
    assert.ok(html.includes('</html>'), 'doit contenir </html>')
    assert.ok(html.includes('<head>'), 'doit contenir <head>')
    assert.ok(html.includes('</head>'), 'doit contenir </head>')
    assert.ok(html.includes('<body>'), 'doit contenir <body>')
    assert.ok(html.includes('</body>'), 'doit contenir </body>')
  })
})

// ─── endpoint /metrics/prometheus ────────────────────────────────────────────

describe('dashboard — buildPrometheusMetrics via endpoint', () => {
  const { buildPrometheusMetrics } = require(join(__dirname, '../../workers/metrics.js'))

  function emptyRun() {
    return {
      total: 0, completed: 0, failed: 0, errors: 0, running: 0,
      avgDurationMin: 0, byPipeline: {}, topAgents: [], topFailingPhases: []
    }
  }

  test('buildPrometheusMetrics produit du texte Prometheus valide (lignes # HELP)', () => {
    const out = buildPrometheusMetrics(
      emptyRun(),
      { totalUpdates: 0, rows: [] },
      { total: 0, success: 0, failure: 0, successRate: 0, byPhase: {}, hasInsights: false }
    )
    assert.ok(out.includes('# HELP'), 'doit contenir des lignes HELP')
    assert.ok(out.includes('# TYPE'), 'doit contenir des lignes TYPE')
  })

  test('format respecte la syntaxe metric{labels} value timestamp', () => {
    const out = buildPrometheusMetrics(
      { ...emptyRun(), completed: 7 },
      { totalUpdates: 0, rows: [] },
      { total: 0, success: 0, failure: 0, successRate: 0, byPhase: {}, hasInsights: false }
    )
    // ligne : ada_runs_total{status="completed"} 7 <ts>
    assert.match(out, /ada_runs_total\{status="completed"\} 7 \d+/)
  })
})
