'use strict'
/**
 * tests/workers/logs.test.js
 * Tests unitaires pour coordinator/run.js::runLog et bin/logs.js
 */

const { describe, test, before, after } = require('node:test')
const assert = require('node:assert/strict')
const { join }   = require('node:path')
const { mkdirSync, existsSync, readFileSync, rmSync, mkdtempSync } = require('node:fs')
const { tmpdir } = require('node:os')

// ── Helpers ───────────────────────────────────────────────────────────────────

let tmpBase
let RUNS_DIR

function setup() {
  tmpBase  = mkdtempSync(join(tmpdir(), 'ai-dev-logs-test-'))
  RUNS_DIR = join(tmpBase, 'runs')
  process.env.CLAUDE_CONFIG_DIR = tmpBase
}

function teardown() {
  try { rmSync(tmpBase, { recursive: true, force: true }) } catch {}
  delete process.env.CLAUDE_CONFIG_DIR
}

function makeRunDir(runId) {
  const dir = join(RUNS_DIR, runId)
  mkdirSync(dir, { recursive: true })
  return dir
}

function readLogEntries(runId) {
  const logPath = join(RUNS_DIR, runId, 'run.log')
  if (!existsSync(logPath)) return []
  return readFileSync(logPath, 'utf8')
    .split('\n')
    .filter(l => l.trim())
    .map(l => JSON.parse(l))
}

// Re-require runLog après avoir positionné CLAUDE_CONFIG_DIR
function loadRunLog() {
  // Purger le cache pour que CLAUDE_CONFIG_DIR soit relu
  const key = require.resolve(join(__dirname, '../../coordinator/run.js'))
  delete require.cache[key]
  return require(join(__dirname, '../../coordinator/run.js')).runLog
}

// ── Tests ─────────────────────────────────────────────────────────────────────

describe('runLog — écriture JSONL', () => {
  before(setup)
  after(teardown)

  test('écrit une entrée JSONL valide dans run.log', () => {
    const runId = 'test-run-001'
    makeRunDir(runId)
    const runLog = loadRunLog()

    runLog(runId, 'info', 'run.started', { pipeline: 'feature' })

    const entries = readLogEntries(runId)
    assert.equal(entries.length, 1)
    const e = entries[0]
    assert.ok(e.ts, 'doit avoir un champ ts')
    assert.equal(e.level, 'info')
    assert.equal(e.event, 'run.started')
    assert.equal(e.pipeline, 'feature')
  })

  test('chaque entrée a ts, level, event', () => {
    const runId = 'test-run-002'
    makeRunDir(runId)
    const runLog = loadRunLog()

    runLog(runId, 'warn', 'phase.skipped', { phaseId: 'deploy', reason: 'flag --no-deploy' })

    const [e] = readLogEntries(runId)
    assert.ok('ts'    in e, 'manque ts')
    assert.ok('level' in e, 'manque level')
    assert.ok('event' in e, 'manque event')
  })

  test('ts est une ISO string valide', () => {
    const runId = 'test-run-003'
    makeRunDir(runId)
    const runLog = loadRunLog()

    runLog(runId, 'info', 'phase.started', { phaseId: 'spec' })

    const [e] = readLogEntries(runId)
    assert.ok(!isNaN(new Date(e.ts).getTime()), `ts invalide : ${e.ts}`)
  })

  test('no-op si le répertoire du run n\'existe pas (aucun crash)', () => {
    const runLog = loadRunLog()
    // runId inexistant — ne doit pas lever d'exception
    assert.doesNotThrow(() => runLog('run-inexistant-xyz', 'info', 'run.started', {}))
  })

  test('accumule plusieurs entrées dans le même run.log', () => {
    const runId = 'test-run-004'
    makeRunDir(runId)
    const runLog = loadRunLog()

    runLog(runId, 'info',  'run.started',       { pipeline: 'feature' })
    runLog(runId, 'info',  'phase.started',      { phaseId: 'spec' })
    runLog(runId, 'info',  'phase.completed',    { phaseId: 'spec', durationMs: 1200 })
    runLog(runId, 'error', 'phase.failed',       { phaseId: 'test', error: 'timeout' })
    runLog(runId, 'info',  'run.completed',      { status: 'completed_with_errors' })

    const entries = readLogEntries(runId)
    assert.equal(entries.length, 5)
  })

  test('les champs data sont fusionnés à la racine de l\'entrée', () => {
    const runId = 'test-run-005'
    makeRunDir(runId)
    const runLog = loadRunLog()

    runLog(runId, 'error', 'phase.failed', { phaseId: 'tester', agent: 'tester', error: 'compilation error' })

    const [e] = readLogEntries(runId)
    assert.equal(e.phaseId, 'tester')
    assert.equal(e.agent,   'tester')
    assert.equal(e.error,   'compilation error')
  })

  test('fonctionne sans data (paramètre optionnel)', () => {
    const runId = 'test-run-006'
    makeRunDir(runId)
    const runLog = loadRunLog()

    assert.doesNotThrow(() => runLog(runId, 'info', 'run.started'))

    const entries = readLogEntries(runId)
    assert.equal(entries.length, 1)
    assert.equal(entries[0].event, 'run.started')
  })

  test('chaque ligne du fichier est un JSON valide indépendant', () => {
    const runId = 'test-run-007'
    makeRunDir(runId)
    const runLog = loadRunLog()

    runLog(runId, 'info', 'event.a', { x: 1 })
    runLog(runId, 'warn', 'event.b', { x: 2 })

    const logPath = join(RUNS_DIR, runId, 'run.log')
    const raw = readFileSync(logPath, 'utf8')
    const lines = raw.split('\n').filter(l => l.trim())
    assert.equal(lines.length, 2)
    for (const line of lines) {
      assert.doesNotThrow(() => JSON.parse(line), `ligne non-JSON : ${line}`)
    }
  })

  test('filtre par level error/warn fonctionne (lecture manuelle)', () => {
    const runId = 'test-run-008'
    makeRunDir(runId)
    const runLog = loadRunLog()

    runLog(runId, 'info',  'phase.started',   { phaseId: 'spec' })
    runLog(runId, 'error', 'phase.failed',    { phaseId: 'spec' })
    runLog(runId, 'warn',  'run.rollback',    { scope: 'spec' })
    runLog(runId, 'info',  'phase.completed', { phaseId: 'review' })

    const entries = readLogEntries(runId)
    const errors  = entries.filter(e => e.level === 'error' || e.level === 'warn')
    assert.equal(errors.length, 2)
  })

  test('run.log contient un newline terminal après chaque entrée', () => {
    const runId = 'test-run-009'
    makeRunDir(runId)
    const runLog = loadRunLog()

    runLog(runId, 'info', 'run.started', {})

    const logPath = join(RUNS_DIR, runId, 'run.log')
    const raw = readFileSync(logPath, 'utf8')
    assert.ok(raw.endsWith('\n'), 'la dernière entrée doit terminer par \\n')
  })

  test('level warn est écrit correctement', () => {
    const runId = 'test-run-010'
    makeRunDir(runId)
    const runLog = loadRunLog()

    runLog(runId, 'warn', 'run.rollback', { scope: 'full' })

    const [e] = readLogEntries(runId)
    assert.equal(e.level, 'warn')
    assert.equal(e.event, 'run.rollback')
    assert.equal(e.scope, 'full')
  })
})
