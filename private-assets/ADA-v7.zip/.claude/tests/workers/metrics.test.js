#!/usr/bin/env node
'use strict'
const { test, describe, before, after } = require('node:test')
const assert = require('node:assert/strict')
const { mkdirSync, rmSync, writeFileSync } = require('fs')
const { join } = require('path')

const TMP        = join(__dirname, '../../..', '.test-tmp-metrics')
const METRICS_JS = join(__dirname, '../../workers/metrics.js')

let computeRunMetrics, computeRouterMetrics, computeBankMetrics, buildMarkdown

before(() => {
  mkdirSync(TMP, { recursive: true })
  // Charger les fonctions exportées (pas via CLI)
  const mod = require(METRICS_JS)
  computeRunMetrics    = mod.computeRunMetrics
  computeRouterMetrics = mod.computeRouterMetrics
  computeBankMetrics   = mod.computeBankMetrics
  buildMarkdown        = mod.buildMarkdown
})

after(() => { try { rmSync(TMP, { recursive: true }) } catch {} })

// ─── computeRunMetrics ────────────────────────────────────────────────────────

describe('computeRunMetrics', () => {
  test('retourne des zéros si aucun run', () => {
    const m = computeRunMetrics([])
    assert.equal(m.total, 0)
    assert.equal(m.completed, 0)
    assert.equal(m.failed, 0)
    assert.equal(m.running, 0)
    assert.equal(m.avgDurationMin, 0)
  })

  test('calcule avgDurationMin depuis startedAt/completedAt', () => {
    const start = new Date('2024-01-01T10:00:00Z').toISOString()
    const end   = new Date('2024-01-01T10:04:00Z').toISOString() // +4 min
    const runs = [{ status: 'completed', startedAt: start, completedAt: end, phases: {} }]
    const m = computeRunMetrics(runs)
    assert.ok(Math.abs(m.avgDurationMin - 4) < 0.01, `avgDurationMin attendu ~4, reçu ${m.avgDurationMin}`)
  })

  test('compte correctement completed/failed/running', () => {
    const runs = [
      { status: 'completed', phases: {} },
      { status: 'completed', phases: {} },
      { status: 'failed',    phases: {} },
      { status: 'running',   phases: {} },
    ]
    const m = computeRunMetrics(runs)
    assert.equal(m.total, 4)
    assert.equal(m.completed, 2)
    assert.equal(m.failed, 1)
    assert.equal(m.running, 1)
  })

  test('identifie les top agents depuis les phases', () => {
    const runs = [
      {
        status: 'completed',
        phases: {
          p1: { agent: 'nestjs',  status: 'completed' },
          p2: { agent: 'nextjs',  status: 'completed' },
          p3: { agent: 'nestjs',  status: 'completed' },
        }
      }
    ]
    const m = computeRunMetrics(runs)
    assert.ok(m.topAgents.length > 0)
    assert.equal(m.topAgents[0][0], 'nestjs')
    assert.equal(m.topAgents[0][1], 2)
  })
})

// ─── computeRouterMetrics ─────────────────────────────────────────────────────

describe('computeRouterMetrics', () => {
  test('retourne totalUpdates = 0 si état vide', () => {
    const m = computeRouterMetrics({ priors: {}, totalUpdates: 0 })
    assert.equal(m.totalUpdates, 0)
    assert.deepEqual(m.rows, [])
  })

  test('calcule winRate correctement (successes/total * 100)', () => {
    const state = {
      totalUpdates: 10,
      priors: {
        'backend:nestjs': { successes: 3, failures: 1, alpha: 4, beta: 2 }
      }
    }
    const m = computeRouterMetrics(state)
    assert.equal(m.totalUpdates, 10)
    assert.equal(m.rows.length, 1)
    // winRate = 3/(3+1)*100 = 75
    assert.equal(m.rows[0].winRate, 75)
    assert.equal(m.rows[0].phase, 'backend')
    assert.equal(m.rows[0].agent, 'nestjs')
  })
})

// ─── computeBankMetrics ───────────────────────────────────────────────────────

describe('computeBankMetrics', () => {
  test('successRate = 0 si bank vide', () => {
    const m = computeBankMetrics({ trajectories: [], insights: null })
    assert.equal(m.total, 0)
    assert.equal(m.successRate, 0)
    assert.equal(m.hasInsights, false)
  })

  test('détecte hasInsights = true si insights présent', () => {
    const state = {
      trajectories: [
        { verdict: 'success', phase: 'backend' },
        { verdict: 'failure', phase: 'backend' },
      ],
      insights: { distilledAt: '2024-01-01T00:00:00Z' }
    }
    const m = computeBankMetrics(state)
    assert.equal(m.total, 2)
    assert.equal(m.success, 1)
    assert.equal(m.failure, 1)
    assert.equal(m.successRate, 50)
    assert.equal(m.hasInsights, true)
  })
})

// ─── buildMarkdown ────────────────────────────────────────────────────────────

describe('buildMarkdown', () => {
  const makeArgs = () => {
    const runMetrics = computeRunMetrics([
      { status: 'completed', phases: { p1: { agent: 'nestjs', status: 'completed' } } },
      { status: 'failed', phases: {} },
    ])
    const routerMetrics = computeRouterMetrics({ priors: {}, totalUpdates: 5 })
    const bankMetrics = computeBankMetrics({
      trajectories: [{ verdict: 'success', phase: 'backend' }],
      insights: null
    })
    return [runMetrics, routerMetrics, bankMetrics]
  }

  test('inclut le header avec la date', () => {
    const md = buildMarkdown(...makeArgs())
    assert.ok(md.includes('# Metrics Dashboard'), `header manquant — got: ${md.slice(0, 100)}`)
  })

  test('inclut la section Runs avec le taux de completion', () => {
    const md = buildMarkdown(...makeArgs())
    assert.ok(md.includes('## Runs'), 'section Runs manquante')
    assert.ok(md.includes('Complétés'), 'taux completion manquant')
  })

  test('inclut la section ReasoningBank', () => {
    const md = buildMarkdown(...makeArgs())
    assert.ok(md.includes('## ReasoningBank'), 'section ReasoningBank manquante')
  })
})

// ─── buildPrometheusMetrics ───────────────────────────────────────────────────

describe('buildPrometheusMetrics', () => {
  let buildPrometheusMetrics

  before(() => {
    buildPrometheusMetrics = require(METRICS_JS).buildPrometheusMetrics
  })

  function makeMetrics() {
    const run = {
      total: 5, completed: 3, failed: 1, errors: 0, running: 1,
      avgDurationMin: 2.5,
      byPipeline: { feature: { total: 3, completed: 2, failed: 1 } },
      topAgents: [['nestjs', 4]], topFailingPhases: [['backend', 1]]
    }
    const router = {
      totalUpdates: 20,
      rows: [{ phase: 'backend', agent: 'nestjs', n: 15, winRate: 80, alpha: '13.0', beta: '3.0' }]
    }
    const bank = {
      total: 30, success: 24, failure: 6, successRate: 80,
      byPhase: { backend: { total: 20, success: 16 }, schema: { total: 10, success: 8 } },
      hasInsights: true, insightsAt: '2026-05-11T10:00:00Z'
    }
    return { run, router, bank }
  }

  test('retourne une chaîne non vide', () => {
    const { run, router, bank } = makeMetrics()
    const out = buildPrometheusMetrics(run, router, bank)
    assert.ok(typeof out === 'string' && out.length > 0)
  })

  test('contient les lignes HELP et TYPE obligatoires', () => {
    const { run, router, bank } = makeMetrics()
    const out = buildPrometheusMetrics(run, router, bank)
    assert.ok(out.includes('# HELP ada_runs_total'))
    assert.ok(out.includes('# TYPE ada_runs_total gauge'))
    assert.ok(out.includes('# HELP ada_bank_trajectories_total'))
    assert.ok(out.includes('# HELP ada_router_win_rate'))
  })

  test('contient les valeurs numériques des runs', () => {
    const { run, router, bank } = makeMetrics()
    const out = buildPrometheusMetrics(run, router, bank)
    assert.ok(out.includes('status="completed"} 3'))
    assert.ok(out.includes('status="failed"} 1'))
    assert.ok(out.includes('status="running"} 1'))
  })

  test('contient le win rate router avec labels phase et agent', () => {
    const { run, router, bank } = makeMetrics()
    const out = buildPrometheusMetrics(run, router, bank)
    assert.ok(out.includes('phase="backend"') && out.includes('agent="nestjs"'))
    assert.ok(out.includes('} 80'))
  })

  test('contient le taux de succès bank global et par phase', () => {
    const { run, router, bank } = makeMetrics()
    const out = buildPrometheusMetrics(run, router, bank)
    assert.ok(out.includes('ada_bank_success_rate'))
    assert.ok(out.includes('ada_bank_phase_success_rate{phase="backend"}'))
  })

  test('inclut les métriques de tokens si tokenMetrics fourni', () => {
    const { run, router, bank } = makeMetrics()
    const tokenMetrics = {
      byModel: {
        'claude-sonnet-4-6': { inputTokens: 5000, outputTokens: 1200 }
      },
      cacheEfficiency: 0.42
    }
    const out = buildPrometheusMetrics(run, router, bank, tokenMetrics)
    assert.ok(out.includes('ada_tokens_input_total'))
    assert.ok(out.includes('model="claude-sonnet-4-6"'))
    assert.ok(out.includes('ada_cache_efficiency'))
    assert.ok(out.includes('0.4200'))
  })

  test('fonctionnel sans tokenMetrics (paramètre absent)', () => {
    const { run, router, bank } = makeMetrics()
    const out = buildPrometheusMetrics(run, router, bank)
    assert.ok(!out.includes('ada_tokens_input_total'))
    assert.ok(!out.includes('ada_cache_efficiency'))
  })
})

// ─── loadTokenMetrics — byModel ───────────────────────────────────────────────

describe('loadTokenMetrics — byModel', () => {
  const { join } = require('path')
  const { mkdirSync, writeFileSync, rmSync } = require('fs')
  const os = require('os')

  let loadTokenMetrics
  let tmpDir

  // Construit un JSONL Claude Code minimal avec deux messages (modèles différents)
  function buildJsonl(entries) {
    return entries.map(e => JSON.stringify(e)).join('\n') + '\n'
  }

  function sonnetEntry(id, inputTokens, outputTokens, cacheRead = 0, cacheWrite = 0) {
    return {
      type: 'assistant',
      message: {
        id,
        model: 'claude-sonnet-4-6-20251001',
        usage: {
          input_tokens: inputTokens,
          output_tokens: outputTokens,
          cache_read_input_tokens: cacheRead,
          cache_creation_input_tokens: cacheWrite,
        }
      }
    }
  }

  function haikuEntry(id, inputTokens, outputTokens) {
    return {
      type: 'assistant',
      message: {
        id,
        model: 'claude-haiku-4-5-20251001',
        usage: { input_tokens: inputTokens, output_tokens: outputTokens }
      }
    }
  }

  before(() => {
    tmpDir = join(os.tmpdir(), `metrics-bymodel-test-${Date.now()}`)
    const encodedCwd = process.cwd().replace(/\//g, '-')
    const projectDir = join(tmpDir, 'projects', encodedCwd)
    mkdirSync(projectDir, { recursive: true })

    // Créer une session JSONL avec entrées pour deux modèles
    const session = buildJsonl([
      sonnetEntry('msg-001', 1000, 200, 100, 50),
      sonnetEntry('msg-002', 500,  100),
      haikuEntry('msg-003',  300,  80),
    ])
    writeFileSync(join(projectDir, 'session-001.jsonl'), session)

    process.env.CLAUDE_CONFIG_DIR = tmpDir
    process.env.AI_DEV_PROJECT    = process.cwd()

    // Recharger le module avec les nouvelles variables d'env
    const metricsPath = require.resolve('../../workers/metrics.js')
    delete require.cache[metricsPath]
    loadTokenMetrics = require('../../workers/metrics.js').loadTokenMetrics
  })

  after(() => {
    try { rmSync(tmpDir, { recursive: true, force: true }) } catch {}
    delete process.env.CLAUDE_CONFIG_DIR
    delete process.env.AI_DEV_PROJECT
  })

  test('retourne byModel non nul quand des sessions existent', () => {
    const result = loadTokenMetrics(5)
    assert.ok(result !== null, 'loadTokenMetrics doit retourner un objet non nul')
    assert.ok(result.byModel !== null && typeof result.byModel === 'object',
      `byModel doit être un objet, reçu : ${typeof result.byModel}`)
  })

  test("byModel['claude-sonnet-4-6'] contient inputTokens, outputTokens, cost", () => {
    const result = loadTokenMetrics(5)
    assert.ok(result !== null)
    const sonnet = result.byModel['claude-sonnet-4-6']
    assert.ok(sonnet !== undefined, "byModel['claude-sonnet-4-6'] doit exister")
    assert.ok(typeof sonnet.inputTokens  === 'number', 'inputTokens doit être un nombre')
    assert.ok(typeof sonnet.outputTokens === 'number', 'outputTokens doit être un nombre')
    assert.ok(typeof sonnet.cost         === 'number', 'cost doit être un nombre')
    assert.ok(sonnet.inputTokens  > 0,  `inputTokens > 0 attendu, reçu ${sonnet.inputTokens}`)
    assert.ok(sonnet.outputTokens > 0, `outputTokens > 0 attendu, reçu ${sonnet.outputTokens}`)
    assert.ok(sonnet.cost         > 0,  `cost > 0 attendu, reçu ${sonnet.cost}`)
  })

  test("byModel['claude-haiku-4-5'] contient inputTokens, outputTokens, cost", () => {
    const result = loadTokenMetrics(5)
    assert.ok(result !== null)
    const haiku = result.byModel['claude-haiku-4-5']
    assert.ok(haiku !== undefined, "byModel['claude-haiku-4-5'] doit exister")
    assert.equal(haiku.inputTokens,  300)
    assert.equal(haiku.outputTokens, 80)
    assert.ok(haiku.cost > 0, `cost haiku > 0 attendu, reçu ${haiku.cost}`)
  })

  test('les totaux byModel somment bien au total global (inputTokens)', () => {
    const result = loadTokenMetrics(5)
    assert.ok(result !== null)
    const sumInput = Object.values(result.byModel)
      .reduce((acc, m) => acc + m.inputTokens, 0)
    assert.equal(sumInput, result.inputTokens,
      `Sum byModel.inputTokens (${sumInput}) doit égaler result.inputTokens (${result.inputTokens})`)
  })

  test('les totaux byModel somment bien au total global (outputTokens)', () => {
    const result = loadTokenMetrics(5)
    assert.ok(result !== null)
    const sumOutput = Object.values(result.byModel)
      .reduce((acc, m) => acc + m.outputTokens, 0)
    assert.equal(sumOutput, result.outputTokens,
      `Sum byModel.outputTokens (${sumOutput}) doit égaler result.outputTokens (${result.outputTokens})`)
  })

  test('les totaux byModel.cost somment bien au totalCost global', () => {
    const result = loadTokenMetrics(5)
    assert.ok(result !== null)
    const sumCost = Object.values(result.byModel)
      .reduce((acc, m) => acc + m.cost, 0)
    // Tolérance flottante : < 0.000001
    assert.ok(Math.abs(sumCost - result.totalCost) < 0.000001,
      `Sum byModel.cost (${sumCost}) doit égaler totalCost (${result.totalCost})`)
  })

  test('les messages dupliqués (même id) sont dédupliqués — seul le plus récent compte', () => {
    // Écrire une session avec deux entrées pour le même msg-id mais output_tokens différents
    const os2 = require('os')
    const tmpDir2 = join(os2.tmpdir(), `metrics-dedup-test-${Date.now()}`)
    const encodedCwd2 = process.cwd().replace(/\//g, '-')
    const projectDir2 = join(tmpDir2, 'projects', encodedCwd2)
    mkdirSync(projectDir2, { recursive: true })

    const dupSession = buildJsonl([
      sonnetEntry('msg-dup', 100, 50),   // version initiale (output plus faible)
      sonnetEntry('msg-dup', 100, 200),  // version finale (output plus élevé → sélectionné)
    ])
    writeFileSync(join(projectDir2, 'session-dedup.jsonl'), dupSession)

    process.env.CLAUDE_CONFIG_DIR = tmpDir2
    process.env.AI_DEV_PROJECT    = process.cwd()

    const metricsPath2 = require.resolve('../../workers/metrics.js')
    delete require.cache[metricsPath2]
    const loadTok2 = require('../../workers/metrics.js').loadTokenMetrics

    const result = loadTok2(5)
    assert.ok(result !== null)
    // Un seul message dédupliqué : inputTokens = 100, outputTokens = 200
    assert.equal(result.inputTokens,  100, `inputTokens dédupliqué doit être 100, reçu ${result.inputTokens}`)
    assert.equal(result.outputTokens, 200, `outputTokens dédupliqué doit être 200 (max), reçu ${result.outputTokens}`)

    try { rmSync(tmpDir2, { recursive: true, force: true }) } catch {}
    // Restaurer l'env pour les tests suivants
    process.env.CLAUDE_CONFIG_DIR = tmpDir
    process.env.AI_DEV_PROJECT    = process.cwd()
    delete require.cache[require.resolve('../../workers/metrics.js')]
    loadTokenMetrics = require('../../workers/metrics.js').loadTokenMetrics
  })
})
