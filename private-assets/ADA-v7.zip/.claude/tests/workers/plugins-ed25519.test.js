#!/usr/bin/env node
'use strict'
/**
 * tests/workers/plugins-ed25519.test.js — Tests Ed25519 + fédération pour bin/plugins.js
 *
 * Couvre :
 *  - generateEd25519KeyPair()  : génération paire de clés PEM
 *  - signWithEd25519()         : signature Ed25519 format "ed25519:<base64>"
 *  - verifySignature()         : Ed25519 valide/invalide, HMAC rétrocompat, algo inconnu
 *  - mergeAllRegistries()      : priorité local, déduplication multi-remotes, _registry
 *  - REGISTRY_URLS             : parsing liste séparée par virgules
 */

const { test, describe, before } = require('node:test')
const assert = require('node:assert/strict')
const { join } = require('node:path')

const PLUGINS_JS = join(__dirname, '../../bin/plugins.js')

let generateEd25519KeyPair, signWithEd25519, verifySignature, mergeAllRegistries, REGISTRY_URLS

before(() => {
  const mod = require(PLUGINS_JS)
  generateEd25519KeyPair = mod.generateEd25519KeyPair
  signWithEd25519        = mod.signWithEd25519
  verifySignature        = mod.verifySignature
  mergeAllRegistries     = mod.mergeAllRegistries
  REGISTRY_URLS          = mod.REGISTRY_URLS
})

// ── generateEd25519KeyPair ─────────────────────────────────────────────────────

describe('generateEd25519KeyPair', () => {
  test('retourne un objet avec publicKey et privateKey', () => {
    const pair = generateEd25519KeyPair()
    assert.ok(typeof pair === 'object', 'doit retourner un objet')
    assert.ok('publicKey'  in pair, 'doit contenir publicKey')
    assert.ok('privateKey' in pair, 'doit contenir privateKey')
  })

  test('publicKey contient "BEGIN PUBLIC KEY"', () => {
    const { publicKey } = generateEd25519KeyPair()
    assert.ok(
      publicKey.includes('BEGIN PUBLIC KEY'),
      `publicKey doit contenir "BEGIN PUBLIC KEY", reçu : ${publicKey.slice(0, 80)}`
    )
  })

  test('privateKey contient "BEGIN PRIVATE KEY"', () => {
    const { privateKey } = generateEd25519KeyPair()
    assert.ok(
      privateKey.includes('BEGIN PRIVATE KEY'),
      `privateKey doit contenir "BEGIN PRIVATE KEY", reçu : ${privateKey.slice(0, 80)}`
    )
  })

  test('chaque appel génère une paire différente', () => {
    const pair1 = generateEd25519KeyPair()
    const pair2 = generateEd25519KeyPair()
    assert.notEqual(pair1.publicKey,  pair2.publicKey,  'les clés publiques doivent différer')
    assert.notEqual(pair1.privateKey, pair2.privateKey, 'les clés privées doivent différer')
  })
})

// ── signWithEd25519 ────────────────────────────────────────────────────────────

describe('signWithEd25519', () => {
  test('retourne une string au format "ed25519:<base64>"', () => {
    const { privateKey } = generateEd25519KeyPair()
    const sig = signWithEd25519('hello manifest', privateKey)
    assert.ok(typeof sig === 'string', 'doit retourner une string')
    assert.ok(sig.startsWith('ed25519:'), `doit commencer par "ed25519:", reçu : ${sig.slice(0, 40)}`)
  })

  test('la partie base64 est décodable en 64 bytes (signature Ed25519)', () => {
    const { privateKey } = generateEd25519KeyPair()
    const sig = signWithEd25519('test content', privateKey)
    const b64Part = sig.slice('ed25519:'.length)
    const decoded = Buffer.from(b64Part, 'base64')
    assert.equal(decoded.length, 64, `Ed25519 signature = 64 bytes, reçu : ${decoded.length}`)
  })

  test('signe un Buffer sans erreur', () => {
    const { privateKey } = generateEd25519KeyPair()
    const sig = signWithEd25519(Buffer.from('buffer content'), privateKey)
    assert.ok(sig.startsWith('ed25519:'))
  })

  test('deux signatures du même contenu avec la même clé sont identiques', () => {
    const { privateKey } = generateEd25519KeyPair()
    const content = 'deterministic content'
    const sig1 = signWithEd25519(content, privateKey)
    const sig2 = signWithEd25519(content, privateKey)
    assert.equal(sig1, sig2, 'Ed25519 est déterministe')
  })

  test('deux contenus différents → signatures différentes', () => {
    const { privateKey } = generateEd25519KeyPair()
    const sig1 = signWithEd25519('content-A', privateKey)
    const sig2 = signWithEd25519('content-B', privateKey)
    assert.notEqual(sig1, sig2)
  })
})

// ── verifySignature — Ed25519 ──────────────────────────────────────────────────

describe('verifySignature — Ed25519', () => {
  test('clé correcte → { valid: true, reason: "OK" }', () => {
    const { publicKey, privateKey } = generateEd25519KeyPair()
    const content = 'manifest content à signer'
    const sig     = signWithEd25519(content, privateKey)
    const result  = verifySignature(content, sig, publicKey)
    assert.equal(result.valid, true,  `valid doit être true, reason : ${result.reason}`)
    assert.equal(result.reason, 'OK', `reason doit être "OK", reçu : ${result.reason}`)
  })

  test('mauvaise clé publique → { valid: false }', () => {
    const { privateKey }        = generateEd25519KeyPair()
    const { publicKey: otherPub } = generateEd25519KeyPair()
    const content = 'manifest content'
    const sig     = signWithEd25519(content, privateKey)
    const result  = verifySignature(content, sig, otherPub)
    assert.equal(result.valid, false, 'doit rejeter une signature avec une autre clé publique')
  })

  test('signature base64 corrompue → { valid: false }', () => {
    const { publicKey } = generateEd25519KeyPair()
    const result = verifySignature('content', 'ed25519:AAAAAAAAAAAAAAAA', publicKey)
    assert.equal(result.valid, false)
  })

  test('valeur base64 non-decodable → { valid: false } sans throw', () => {
    const { publicKey } = generateEd25519KeyPair()
    const result = verifySignature('content', 'ed25519:!!!invalide!!!', publicKey)
    assert.equal(result.valid, false)
    assert.ok(typeof result.reason === 'string')
  })

  test('signature pour un contenu différent → { valid: false }', () => {
    const { publicKey, privateKey } = generateEd25519KeyPair()
    const sig    = signWithEd25519('original', privateKey)
    const result = verifySignature('tampered', sig, publicKey)
    assert.equal(result.valid, false)
  })
})

// ── verifySignature — HMAC rétrocompatibilité ──────────────────────────────────

describe('verifySignature — HMAC rétrocompatibilité', () => {
  const { createHmac } = require('node:crypto')

  test('hmac-sha256 correct toujours fonctionnel', () => {
    const content = 'hello manifest'
    const key     = 'my-secret-key'
    const hex     = createHmac('sha256', key).update(content).digest('hex')
    const result  = verifySignature(content, `hmac-sha256:${hex}`, key)
    assert.equal(result.valid,  true, `valid doit être true, reason : ${result.reason}`)
    assert.equal(result.reason, 'OK')
  })

  test('hmac-sha256 mauvaise clé → { valid: false }', () => {
    const hex    = createHmac('sha256', 'good').update('content').digest('hex')
    const result = verifySignature('content', `hmac-sha256:${hex}`, 'wrong')
    assert.equal(result.valid, false)
    assert.match(result.reason, /invalide/i)
  })

  test('algo inconnu → { valid: false, reason contient "non supporté" }', () => {
    const result = verifySignature('content', 'sha3:abcdef1234', 'key')
    assert.equal(result.valid, false)
    assert.ok(
      result.reason.includes('non support'),
      `reason doit contenir "non support", reçu : "${result.reason}"`
    )
  })

  test('signature absente (null) → { valid: false }', () => {
    const result = verifySignature('content', null, 'key')
    assert.equal(result.valid, false)
  })

  test('signature sans séparateur ":" → { valid: false }', () => {
    const result = verifySignature('content', 'nocolon', 'key')
    assert.equal(result.valid, false)
  })
})

// ── mergeAllRegistries ─────────────────────────────────────────────────────────

describe('mergeAllRegistries', () => {
  test('local prioritaire sur remote pour même name', () => {
    const local  = { plugins: [{ name: 'alpha', version: '1.0.0' }] }
    const remotes = [{ url: 'https://r1.example.com', plugins: [{ name: 'alpha', version: '9.9.9' }] }]
    const merged = mergeAllRegistries(local, remotes)
    assert.equal(merged.plugins.length, 1)
    assert.equal(merged.plugins[0].version, '1.0.0', 'local doit avoir priorité')
    assert.equal(merged.plugins[0]._registry, undefined, 'plugin local ne doit pas avoir _registry')
  })

  test('plugin remote uniquement est marqué _registry: url', () => {
    const url    = 'https://r1.example.com'
    const local  = { plugins: [] }
    const remotes = [{ url, plugins: [{ name: 'remote-only', version: '2.0.0' }] }]
    const merged = mergeAllRegistries(local, remotes)
    assert.equal(merged.plugins.length, 1)
    assert.equal(merged.plugins[0]._registry, url, `_registry doit être "${url}"`)
  })

  test('déduplication entre deux remotes — premier gagne', () => {
    const url1   = 'https://r1.example.com'
    const url2   = 'https://r2.example.com'
    const local  = { plugins: [] }
    const remotes = [
      { url: url1, plugins: [{ name: 'shared', version: '1.0.0' }] },
      { url: url2, plugins: [{ name: 'shared', version: '2.0.0' }] },
    ]
    const merged = mergeAllRegistries(local, remotes)
    assert.equal(merged.plugins.length, 1)
    assert.equal(merged.plugins[0].version,   '1.0.0', 'premier remote doit gagner')
    assert.equal(merged.plugins[0]._registry, url1)
  })

  test('fusionne local + deux remotes sans doublon', () => {
    const local  = { plugins: [{ name: 'local-a' }] }
    const remotes = [
      { url: 'https://r1.example.com', plugins: [{ name: 'remote-b' }] },
      { url: 'https://r2.example.com', plugins: [{ name: 'remote-c' }] },
    ]
    const merged = mergeAllRegistries(local, remotes)
    assert.equal(merged.plugins.length, 3)
    const names = merged.plugins.map(p => p.name).sort()
    assert.deepEqual(names, ['local-a', 'remote-b', 'remote-c'])
  })

  test('tableau remotes vide → retourne uniquement local', () => {
    const local  = { plugins: [{ name: 'only-local' }] }
    const merged = mergeAllRegistries(local, [])
    assert.equal(merged.plugins.length, 1)
    assert.equal(merged.plugins[0].name, 'only-local')
  })

  test('local et remotes vides → tableau vide', () => {
    const merged = mergeAllRegistries({ plugins: [] }, [])
    assert.deepEqual(merged.plugins, [])
  })
})

// ── REGISTRY_URLS ──────────────────────────────────────────────────────────────

describe('REGISTRY_URLS', () => {
  test('est un tableau', () => {
    assert.ok(Array.isArray(REGISTRY_URLS), 'REGISTRY_URLS doit être un tableau')
  })

  test('parse correctement une liste séparée par virgules (simulation)', () => {
    // On teste directement la logique de parsing sans modifier process.env
    const raw = 'https://registry1.com,https://registry2.com, https://registry3.com'
    const parsed = raw.split(',').map(u => u.trim()).filter(Boolean)
    assert.equal(parsed.length, 3)
    assert.equal(parsed[0], 'https://registry1.com')
    assert.equal(parsed[1], 'https://registry2.com')
    assert.equal(parsed[2], 'https://registry3.com')
  })

  test('une chaîne vide → tableau vide', () => {
    const parsed = ''.split(',').map(u => u.trim()).filter(Boolean)
    assert.deepEqual(parsed, [])
  })

  test('URL unique (compatibilité PLUGIN_REGISTRY_URL singulier)', () => {
    const raw = 'https://registry1.com'
    const parsed = raw.split(',').map(u => u.trim()).filter(Boolean)
    assert.equal(parsed.length, 1)
    assert.equal(parsed[0], 'https://registry1.com')
  })
})
