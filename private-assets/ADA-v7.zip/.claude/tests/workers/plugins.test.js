#!/usr/bin/env node
'use strict'
/**
 * tests/workers/plugins.test.js — Tests pour bin/plugins.js
 *
 * Couvre :
 *  - isRemoteUrl()         : détection des URLs distantes
 *  - computeChecksum()     : calcul SHA256
 *  - cmdList()             : liste les plugins installés
 *  - cmdValidate()         : validation d'un plugin local
 *  - cmdSearch()           : recherche dans le registre local
 *  - cmdChecksum()         : affiche les SHA256 d'un plugin installé
 *  - fetchRemoteRegistry() : timeout, erreur réseau
 *  - mergeRegistries()     : déduplication, marquage [remote]
 *  - verifySignature()     : HMAC-SHA256 valide/invalide, algo inconnu, clé absente
 *  - cmdSign()             : génère une signature hex de 64 caractères
 */

const { test, describe, before, after } = require('node:test')
const assert = require('node:assert/strict')
const { mkdirSync, rmSync, writeFileSync, existsSync } = require('node:fs')
const { join } = require('node:path')
const http = require('node:http')

const PLUGINS_JS = join(__dirname, '../../bin/plugins.js')
const TMP        = join(__dirname, '../../..', '.test-tmp-plugins')
const PLUGINS_DIR = join(TMP, 'plugins')

// ── Helpers ────────────────────────────────────────────────────────────────────

/**
 * Crée un plugin de test dans pluginsDir/name avec les fichiers spécifiés.
 * @param {string} name
 * @param {object} manifest
 * @param {{ worker?: boolean, hook?: boolean }} [opts]
 */
function makePlugin(name, manifest, opts = {}) {
  const dir = join(PLUGINS_DIR, name)
  mkdirSync(dir, { recursive: true })
  writeFileSync(join(dir, 'manifest.json'), JSON.stringify(manifest, null, 2), 'utf8')
  if (opts.worker) writeFileSync(join(dir, 'worker.js'), `'use strict'\nmodule.exports = {}`, 'utf8')
  if (opts.hook)   writeFileSync(join(dir, 'hook.js'),   `'use strict'\nmodule.exports = {}`, 'utf8')
  return dir
}

// ── Setup / Teardown ───────────────────────────────────────────────────────────

let isRemoteUrl, computeChecksum, cmdList, cmdValidate, cmdSearch, cmdChecksum,
    fetchRemoteRegistry, mergeRegistries, verifySignature, cmdSign, fetchUrl

before(() => {
  mkdirSync(PLUGINS_DIR, { recursive: true })

  // Créer quelques plugins de test
  makePlugin('alpha', {
    name: 'alpha', version: '1.2.0',
    description: 'Plugin alpha pour les tests',
    hooks: ['git-commit'],
    author: 'Tester',
    license: 'MIT',
  }, { worker: true })

  makePlugin('beta', {
    name: 'beta', version: '2.0.0',
    description: 'Plugin beta sans hooks',
    hooks: [],
    author: 'Tester',
    license: 'MIT',
  }, { worker: true, hook: true })

  makePlugin('gamma', {
    name: 'gamma', version: '0.1.0',
    description: 'Plugin gamma de notification',
    hooks: ['git-push', 'test-js'],
    author: 'Tester',
    license: 'MIT',
  })

  const mod = require(PLUGINS_JS)
  isRemoteUrl          = mod.isRemoteUrl
  computeChecksum      = mod.computeChecksum
  cmdList              = mod.cmdList
  cmdValidate          = mod.cmdValidate
  cmdSearch            = mod.cmdSearch
  cmdChecksum          = mod.cmdChecksum
  fetchRemoteRegistry  = mod.fetchRemoteRegistry
  fetchUrl             = mod.fetchUrl
  mergeRegistries      = mod.mergeRegistries
  verifySignature      = mod.verifySignature
  cmdSign              = mod.cmdSign
})

after(() => {
  if (existsSync(TMP)) rmSync(TMP, { recursive: true, force: true })
})

// ── isRemoteUrl ────────────────────────────────────────────────────────────────

describe('isRemoteUrl', () => {
  test('retourne true pour une URL https://', () => {
    assert.equal(isRemoteUrl('https://example.com/plugins/notify'), true)
  })

  test('retourne true pour une URL http://', () => {
    assert.equal(isRemoteUrl('http://localhost:8080/plugins/test'), true)
  })

  test('retourne false pour un chemin local absolu', () => {
    assert.equal(isRemoteUrl('/Users/test/plugins/my-plugin'), false)
  })

  test('retourne false pour un chemin relatif', () => {
    assert.equal(isRemoteUrl('./plugins-examples/notify'), false)
  })

  test('retourne false pour une chaîne vide', () => {
    assert.equal(isRemoteUrl(''), false)
  })

  test('retourne false pour une valeur non-string', () => {
    assert.equal(isRemoteUrl(null), false)
    assert.equal(isRemoteUrl(undefined), false)
    assert.equal(isRemoteUrl(42), false)
  })
})

// ── computeChecksum ────────────────────────────────────────────────────────────

describe('computeChecksum', () => {
  test('retourne un hash hex de 64 caractères pour une string', () => {
    const hash = computeChecksum('hello world')
    assert.equal(typeof hash, 'string')
    assert.equal(hash.length, 64)
    assert.match(hash, /^[0-9a-f]{64}$/)
  })

  test('retourne un hash hex de 64 caractères pour un Buffer', () => {
    const hash = computeChecksum(Buffer.from('hello world'))
    assert.equal(hash.length, 64)
    assert.match(hash, /^[0-9a-f]{64}$/)
  })

  test('retourne le même hash pour le même contenu (string vs Buffer)', () => {
    const hashStr = computeChecksum('test content')
    const hashBuf = computeChecksum(Buffer.from('test content'))
    assert.equal(hashStr, hashBuf)
  })

  test('retourne des hashs différents pour des contenus différents', () => {
    const h1 = computeChecksum('foo')
    const h2 = computeChecksum('bar')
    assert.notEqual(h1, h2)
  })

  test('hash connu : SHA256("") === e3b0c44298fc1c149...', () => {
    const hash = computeChecksum('')
    assert.equal(hash, 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855')
  })
})

// ── cmdList ────────────────────────────────────────────────────────────────────

describe('cmdList', () => {
  test('ne lève pas d\'exception pour un répertoire valide avec plugins', () => {
    assert.doesNotThrow(() => cmdList(PLUGINS_DIR))
  })

  test('ne lève pas d\'exception pour un répertoire vide', () => {
    const emptyDir = join(TMP, 'empty-plugins')
    mkdirSync(emptyDir, { recursive: true })
    assert.doesNotThrow(() => cmdList(emptyDir))
  })

  test('ne lève pas d\'exception pour un répertoire inexistant', () => {
    assert.doesNotThrow(() => cmdList(join(TMP, 'nonexistent-dir')))
  })
})

// ── cmdValidate ────────────────────────────────────────────────────────────────

describe('cmdValidate', () => {
  test('ne lève pas d\'exception pour un manifest valide', () => {
    const pluginDir = join(PLUGINS_DIR, 'alpha')
    assert.doesNotThrow(() => cmdValidate(pluginDir))
  })
})

// ── cmdSearch ──────────────────────────────────────────────────────────────────

describe('cmdSearch', () => {
  test('ne lève pas d\'exception pour une query valide', () => {
    assert.doesNotThrow(() => cmdSearch('notify'))
  })

  test('ne lève pas d\'exception pour une query sans résultat', () => {
    assert.doesNotThrow(() => cmdSearch('xyzzy-not-found-42'))
  })
})

// ── cmdChecksum ────────────────────────────────────────────────────────────────

describe('cmdChecksum', () => {
  test('ne lève pas d\'exception pour un plugin existant', () => {
    assert.doesNotThrow(() => cmdChecksum('alpha', PLUGINS_DIR))
  })

  test('ne lève pas d\'exception pour un plugin avec worker.js et hook.js', () => {
    assert.doesNotThrow(() => cmdChecksum('beta', PLUGINS_DIR))
  })

  test('vérifie que les fichiers affichent un hash de 64 caractères hex (capture stdout)', () => {
    // Capturer console.log temporairement pour vérifier le format
    const lines = []
    const origLog = console.log
    console.log = (...args) => lines.push(args.join(' '))

    try {
      cmdChecksum('alpha', PLUGINS_DIR)
    } finally {
      console.log = origLog
    }

    // Chercher une ligne contenant "sha256:" suivi de 64 hex chars
    const hashLine = lines.find(l => /sha256:[0-9a-f]{64}/.test(l))
    assert.ok(hashLine !== undefined, `Attendu une ligne avec sha256:<64hex>, lignes reçues : ${JSON.stringify(lines)}`)
  })
})

// ── fetchRemoteRegistry ────────────────────────────────────────────────────────

describe('fetchRemoteRegistry', () => {
  test('timeout sur une URL qui ne répond pas → rejette avec Error', async () => {
    // Utiliser un port fermé sur localhost → connexion refusée immédiate
    await assert.rejects(
      () => fetchRemoteRegistry('http://127.0.0.1:19999/registry.json'),
      (err) => {
        assert.ok(err instanceof Error, 'Doit être une Error')
        return true
      }
    )
  })

  test('erreur HTTP 404 → rejette avec Error mentionnant HTTP 404', async () => {
    // Serveur HTTP minimal qui retourne 404
    const server = http.createServer((req, res) => {
      res.writeHead(404)
      res.end('Not Found')
    })
    await new Promise(resolve => server.listen(0, '127.0.0.1', resolve))
    const port = server.address().port

    try {
      await assert.rejects(
        () => fetchRemoteRegistry(`http://127.0.0.1:${port}/registry.json`),
        /HTTP 404/
      )
    } finally {
      await new Promise(resolve => server.close(resolve))
    }
  })

  test('JSON valide → retourne les plugins parsés', async () => {
    const payload = JSON.stringify({ plugins: [{ name: 'remote-plugin', version: '1.0.0' }] })
    const server  = http.createServer((req, res) => {
      res.writeHead(200, { 'Content-Type': 'application/json' })
      res.end(payload)
    })
    await new Promise(resolve => server.listen(0, '127.0.0.1', resolve))
    const port = server.address().port

    try {
      const result = await fetchRemoteRegistry(`http://127.0.0.1:${port}/registry.json`)
      assert.ok(Array.isArray(result.plugins), 'plugins doit être un tableau')
      assert.equal(result.plugins[0].name, 'remote-plugin')
    } finally {
      await new Promise(resolve => server.close(resolve))
    }
  })
})

// ── SSRF — fetchUrl / fetchRemoteRegistry rejettent les hôtes privés/internes ───
// Non-régression de l'audit C : avant correctif, `ada plugin install <url>` et
// les registries distants atteignaient n'importe quelle IP interne (metadata cloud,
// RFC-1918, LAN). Le loopback reste autorisé par design (install/registry locale).

describe('SSRF — fetchUrl rejette les hôtes privés (URL initiale, sans I/O)', () => {
  const PRIVATE = [
    'https://10.255.255.1/manifest.json',          // RFC-1918
    'https://192.168.1.1/manifest.json',           // RFC-1918
    'https://172.16.0.1/manifest.json',            // RFC-1918
    'https://169.254.169.254/latest/meta-data/',   // metadata cloud
    'https://[fd00::1]/x',                          // ULA IPv6
    'https://[fc00::1]/x',                          // ULA IPv6
  ]
  // NB: les IP décimales/octales qui normalisent vers 127.x (ex: 2130706433)
  // sont du loopback → autorisées par design pour plugins (install locale).
  for (const url of PRIVATE) {
    test(`bloque ${url}`, async () => {
      await assert.rejects(() => fetchUrl(url), /SSRF|privée|interne/)
    })
  }

  test('http:// non-loopback est interdit (force https)', async () => {
    await assert.rejects(() => fetchUrl('http://example.com/x'), /HTTP non sécurisé|https/)
  })
})

describe('SSRF — fetchRemoteRegistry rejette les hôtes privés', () => {
  test('bloque une IP RFC-1918', async () => {
    await assert.rejects(() => fetchRemoteRegistry('https://10.0.0.5/registry.json'), /SSRF|privée|interne/)
  })
  test('bloque le metadata endpoint cloud', async () => {
    await assert.rejects(() => fetchRemoteRegistry('https://169.254.169.254/registry.json'), /SSRF|privée|interne/)
  })
})

describe('SSRF — le loopback reste autorisé (install/registry locale)', () => {
  test('fetchRemoteRegistry sert un JSON depuis 127.0.0.1', async () => {
    const payload = JSON.stringify({ plugins: [{ name: 'loopback-ok', version: '1.0.0' }] })
    const server  = http.createServer((req, res) => {
      res.writeHead(200, { 'Content-Type': 'application/json' })
      res.end(payload)
    })
    await new Promise(resolve => server.listen(0, '127.0.0.1', resolve))
    const port = server.address().port
    try {
      const result = await fetchRemoteRegistry(`http://127.0.0.1:${port}/registry.json`)
      assert.equal(result.plugins[0].name, 'loopback-ok')
    } finally {
      await new Promise(resolve => server.close(resolve))
    }
  })
})

// ── mergeRegistries ────────────────────────────────────────────────────────────

describe('mergeRegistries', () => {
  test('déduplique par name — local a priorité sur remote', () => {
    const local  = { plugins: [{ name: 'alpha', version: '1.0.0' }] }
    const remote = { plugins: [{ name: 'alpha', version: '9.9.9' }] }
    const merged = mergeRegistries(local, remote)
    assert.equal(merged.plugins.length, 1)
    assert.equal(merged.plugins[0].version, '1.0.0')
    assert.equal(merged.plugins[0]._remote, undefined, 'plugin local ne doit pas être marqué _remote')
  })

  test('plugins uniquement distants sont marqués _remote: true', () => {
    const local  = { plugins: [] }
    const remote = { plugins: [{ name: 'new-plugin', version: '1.0.0' }] }
    const merged = mergeRegistries(local, remote)
    assert.equal(merged.plugins.length, 1)
    assert.equal(merged.plugins[0]._remote, true)
  })

  test('fusionne local + remote sans doublon', () => {
    const local  = { plugins: [{ name: 'a' }, { name: 'b' }] }
    const remote = { plugins: [{ name: 'b' }, { name: 'c' }] }
    const merged = mergeRegistries(local, remote)
    assert.equal(merged.plugins.length, 3)
    const names  = merged.plugins.map(p => p.name).sort()
    assert.deepEqual(names, ['a', 'b', 'c'])
  })

  test('gère les registries vides', () => {
    const merged = mergeRegistries({ plugins: [] }, { plugins: [] })
    assert.deepEqual(merged.plugins, [])
  })
})

// ── verifySignature ────────────────────────────────────────────────────────────

describe('verifySignature', () => {
  const { createHmac } = require('node:crypto')

  test('signature correcte avec bonne clé → valid: true', () => {
    const content = 'hello manifest'
    const key     = 'mysecretkey'
    const hex     = createHmac('sha256', key).update(content).digest('hex')
    const result  = verifySignature(content, `hmac-sha256:${hex}`, key)
    assert.equal(result.valid, true)
    assert.equal(result.reason, 'OK')
  })

  test('signature incorrecte avec mauvaise clé → valid: false', () => {
    const content = 'hello manifest'
    const hex     = createHmac('sha256', 'goodkey').update(content).digest('hex')
    const result  = verifySignature(content, `hmac-sha256:${hex}`, 'wrongkey')
    assert.equal(result.valid, false)
    assert.match(result.reason, /invalide/i)
  })

  test('algo non supporté → valid: false, reason contient "Algo"', () => {
    const result = verifySignature('content', 'sha1:abcdef1234567890', 'key')
    assert.equal(result.valid, false)
    assert.ok(result.reason.includes('Algo'), `reason="${result.reason}" doit contenir "Algo"`)
  })

  test('clé absente (undefined) → valid: false', () => {
    const result = verifySignature('content', 'hmac-sha256:abcdef', undefined)
    assert.equal(result.valid, false)
    assert.match(result.reason, /absente/i)
  })

  test('clé absente (null) → valid: false', () => {
    const result = verifySignature('content', 'hmac-sha256:abcdef', null)
    assert.equal(result.valid, false)
    assert.match(result.reason, /absente/i)
  })

  test('fonctionne avec un Buffer en entrée', () => {
    const content = Buffer.from('buffer manifest')
    const key     = 'bufferkey'
    const hex     = createHmac('sha256', key).update(content).digest('hex')
    const result  = verifySignature(content, `hmac-sha256:${hex}`, key)
    assert.equal(result.valid, true)
  })
})

// ── cmdSign ────────────────────────────────────────────────────────────────────

describe('cmdSign', () => {
  test('génère une signature hex de 64 caractères', () => {
    const lines    = []
    const origLog  = console.log
    console.log    = (...args) => lines.push(args.join(' '))

    try {
      cmdSign('alpha', PLUGINS_DIR, 'testsecret')
    } finally {
      console.log = origLog
    }

    const sigLine = lines.find(l => /hmac-sha256:[0-9a-f]{64}/.test(l))
    assert.ok(sigLine !== undefined, `Attendu une ligne avec hmac-sha256:<64hex>, reçu : ${JSON.stringify(lines)}`)
  })

  test('la signature produite est vérifiable via verifySignature', () => {
    const { readFileSync } = require('node:fs')
    const { join: pathJoin } = require('node:path')
    const content = readFileSync(pathJoin(PLUGINS_DIR, 'alpha', 'manifest.json'))

    let capturedSig = null
    const origLog   = console.log
    console.log     = (...args) => {
      const line = args.join(' ')
      const m = /hmac-sha256:[0-9a-f]{64}/.exec(line)
      if (m) capturedSig = m[0]
    }

    try {
      cmdSign('alpha', PLUGINS_DIR, 'verifysecret')
    } finally {
      console.log = origLog
    }

    assert.ok(capturedSig !== null, 'Signature doit être capturée')
    const { valid } = verifySignature(content, capturedSig, 'verifysecret')
    assert.equal(valid, true, 'La signature générée doit être valide')
  })
})
