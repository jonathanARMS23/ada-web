#!/usr/bin/env node
'use strict'
const { test, describe, before, after } = require('node:test')
const assert = require('node:assert/strict')
const { mkdirSync, rmSync, existsSync, readFileSync, writeFileSync, utimesSync } = require('fs')
const { join } = require('path')
const { execSync } = require('child_process')

const TMP         = join(__dirname, '../../..', '.test-tmp-testgaps')
const TESTGAPS_JS = join(__dirname, '../../workers/testgaps.js')
const SRC_DIR     = join(TMP, 'src')
const OUT_FILE    = join(TMP, 'memory', 'projects', 'workspace', 'testgaps.md')

before(() => {
  mkdirSync(SRC_DIR, { recursive: true })
  mkdirSync(join(TMP, 'memory', 'projects', 'workspace'), { recursive: true })
})
after(() => { try { rmSync(TMP, { recursive: true }) } catch {} })

function writeSrc(filename, content) {
  const path = join(SRC_DIR, filename)
  writeFileSync(path, content, 'utf8')
  const now = new Date()
  utimesSync(path, now, now)
  return path
}

function runTestgaps() {
  execSync(`node "${TESTGAPS_JS}" workspace 0`, {
    cwd: TMP,
    env: { ...process.env, CLAUDE_CONFIG_DIR: TMP, AI_DEV_PROJECT: 'workspace' },
    encoding: 'utf8'
  })
  return existsSync(OUT_FILE) ? readFileSync(OUT_FILE, 'utf8') : ''
}

// ─── Extraction de testables ──────────────────────────────────────────────────

describe('extractTestables — fonctions exportées', () => {
  test('détecte export function', () => {
    writeSrc('utils.ts', `
export function getUserById(id: string): Promise<User> {
  return db.findOne(id)
}
export function createUser(data: CreateUserDto): Promise<User> {
  return db.save(data)
}`)
    const report = runTestgaps()
    assert.ok(report.includes('getUserById') || report.includes('createUser') || report.includes('utils.ts'),
      `report: ${report.slice(0, 300)}`)
  })

  test('détecte export class', () => {
    writeSrc('auth.service.ts', `
export class AuthService {
  async login(email: string, password: string): Promise<string> {
    return this.jwtService.sign({ email })
  }
  async validateToken(token: string): Promise<boolean> {
    return this.jwtService.verify(token)
  }
}`)
    const report = runTestgaps()
    assert.ok(report.includes('AuthService') || report.includes('auth.service.ts'),
      `report: ${report.slice(0, 300)}`)
  })
})

// ─── stripComments — pas de faux positifs depuis les commentaires ─────────────

describe('stripComments — évite les faux positifs', () => {
  test('ne détecte pas de fonction dans un commentaire //', () => {
    writeSrc('clean-with-comment.ts', `
// export function oldFunction(id: string) { return db.find(id) }
export function realFunction(data: string): string {
  return data.trim()
}`)
    const report = runTestgaps()
    // oldFunction ne devrait pas apparaître, realFunction peut apparaître si pas de test
    if (report.includes('clean-with-comment.ts')) {
      assert.ok(!report.includes('oldFunction'),
        `oldFunction dans un commentaire ne devrait pas être listé`)
    }
  })

  test('ne détecte pas de fonction dans un block comment /* */', () => {
    writeSrc('block-comment.ts', `
/**
 * export function documentedButRemoved(x: string) {}
 * async legacyMethod() { return null }
 */
export function activeFunction(x: number): number {
  return x * 2
}`)
    const report = runTestgaps()
    if (report.includes('block-comment.ts')) {
      assert.ok(!report.includes('documentedButRemoved'),
        `Fonction dans block comment ne devrait pas être listée`)
      assert.ok(!report.includes('legacyMethod'),
        `Méthode dans block comment ne devrait pas être listée`)
    }
  })
})

// ─── Filtres de bruit ─────────────────────────────────────────────────────────

describe('Filtres de bruit', () => {
  test('ignore les lifecycle hooks', () => {
    writeSrc('component.ts', `
export class MyComponent {
  constructor(private service: MyService) {}
  ngOnInit() { this.load() }
  ngOnDestroy() { this.sub.unsubscribe() }
  async loadData(): Promise<void> {
    this.data = await this.service.getData()
  }
}`)
    const report = runTestgaps()
    if (report.includes('component.ts')) {
      assert.ok(!report.includes('ngOnInit'), 'ngOnInit ne devrait pas être listé')
      assert.ok(!report.includes('ngOnDestroy'), 'ngOnDestroy ne devrait pas être listé')
      assert.ok(!report.includes('constructor'), 'constructor ne devrait pas être listé')
    }
  })

  test('ignore les méthodes privées (_ prefix)', () => {
    writeSrc('service.ts', `
export class MyService {
  async _internalHelper(x: string): Promise<string> {
    return x.toLowerCase()
  }
  async publicMethod(x: string): Promise<string> {
    return this._internalHelper(x)
  }
}`)
    const report = runTestgaps()
    if (report.includes('service.ts')) {
      assert.ok(!report.includes('_internalHelper'),
        'méthode privée (_) ne devrait pas être listée')
    }
  })
})

// ─── Fichiers avec tests couverts ─────────────────────────────────────────────

describe('Couverture — fichiers avec tests', () => {
  test('fichier avec test co-localisé → section "avec tests"', () => {
    writeSrc('math.ts', `export function add(a: number, b: number) { return a + b }`)
    // Créer le test correspondant
    const testDir = join(SRC_DIR, '__tests__')
    mkdirSync(testDir, { recursive: true })
    writeFileSync(join(testDir, 'math.test.ts'), `test('add', () => expect(add(1,2)).toBe(3))`)
    const report = runTestgaps()
    assert.ok(report.includes('avec tests') || report.includes('math.ts'),
      `report: ${report.slice(0, 300)}`)
  })
})

// ─── Rapport — structure ──────────────────────────────────────────────────────

test('rapport contient le header', () => {
  const report = runTestgaps()
  assert.ok(report.includes('Test Gaps'))
  assert.ok(report.includes('workspace'))
})
