'use strict'
module.exports = { inject: function() { return 'Toujours écrire les specs avant le code.' } }