# Changelog

## [7.6.0] — 2026-08-28

### Added
- **`install.ps1`** : installeur local Windows (nouveau), orchestrateur mince qui réutilise les scripts Node existants (`generate-ada-manifest.js`, `manifest-files-for.js`, `sync-content-dir.js`) plutôt que de porter les 1700+ lignes bash — format `~/.ada.json` garanti identique à `install.sh`. CLI-only par défaut.
- **`install.sh --with-ui` / `ADA_WITH_UI=1`** : `ada-ui` (dépend de `node-pty`, natif, bloque sur Windows sans Visual Studio Build Tools) devient opt-in au lieu d'installé inconditionnellement, sur toutes les plateformes.
- `ADR-025` : stratégie documentée pour un futur installeur distant multi-OS malgré le repo privé (token GitHub fine-grained + API Releases, frontière de sécurité conforme au rejet d'ADR-020 — aucune logique de licence dans le produit). Implémentation différée.
- `tests/coordinator/bank-ranking.test.js`, `tests/coordinator/ipc-emit.test.js`, `tests/scripts/install-sh.test.js` — non-régression sur les fixes ci-dessous.
- Couverture RPC de `control-handlers.js` étendue de 27 à 47+/74 méthodes (cycle de vie `run.*`, gouvernance `budget.*`, config `profiles.*`/`schedules.*`/`providers.*`).

### Fixed
- **`router.js update`/`bank.js store` jamais persistés en production** : `run.js` utilisait un `spawn({detached:true}).unref()` qui échouait silencieusement à chaque fin de phase (0 mise à jour atterrie sur 16 runs réels complétés entre mai et juillet 2026, malgré des phases terminées avec succès) — remplacé par `spawnSync`.
- **2 bugs de ranking du ReasoningBank** (régression détectée sur les ancres flywheel) : mélange d'échelles TF-IDF/overlap dans `bank.js:retrieve()` (un candidat hors du top-N brut retombait sur un score non normalisé qui écrasait un vrai score TF-IDF) ; items `phase=topic` sans pertinence de contenu qui gardaient un score positif via le seul bonus de récence.
- **`bank.stream` (RPC) cassé depuis toujours** : appelait `collectStream` avec les mauvais arguments (query string au lieu d'un stream), jamais awaité — `TypeError` systématique, 0 test avant cette release.
- **`ada-bridge.js` sans garde `require.main`** : son dispatch CLI s'exécutait à chaque `require()` du module, pas seulement en CLI directe.
- **`mktemp` non portable dans `install.sh`** : gabarit avec suffixe après les `X` invalide sous BSD mktemp (macOS) — nom de fichier temporaire prévisible dans `/tmp`, corrigé.
- Mirror `typed-memory` retiré de `bank.store()` (écriture sur chaque trajectoire, aucun lecteur nulle part dans le repo).

### Docs
- `ADR-023` étape 6 (T2) close : le mécanisme adaptatif ne généralise pas hors SQL (≥FIXED sur SQL, <FIXED sur Docker aux deux modèles testés) — recommandation de ne pas activer les pipelines basculés sans checklist domaine mesurée.

## [7.5.2] — 2026-08-19

### Fixed
- **`TIER_MODELS[3]` pointait vers `claude-opus-4-8`** (superseded, pas retiré) au lieu de `claude-opus-5` — le classifieur pouvait router les tâches tier 3 (backend, review, architecture) vers un ancien Opus au lieu du modèle courant. `claude-opus-4-8` reste en alias legacy dans `PRICING` pour la résolution des transcripts historiques.
- Dérive corrigée sur les 5 profils runtime installés (`.claude`, `.claude-jarvis`, `.claude-perso`, `.claude-pro`, `.claude-ov`), pas seulement le repo.
- `CLAUDE.md` : deux occurrences périmées (table "Sélection de modèle" + règle "Vérification des IDs") mises à jour, plus les copies globales du profil.
- Littéraux `'claude-sonnet-4-6'` codés en dur dans `workers/cost-report.js` et `workers/metrics.js` (fallback modèle inconnu) remplacés par une référence à `TIER_MODELS[2]` importé de `models.js`.

### Added
- Marker witness `models-tier3-opus5` dans `witness-fixes.json`, symétrique du marker tier-2 existant — le garde-fou anti-régression couvre désormais les deux tiers.

## [7.5.1] — 2026-08-13

### Fixed
- **`ada-ui` ne se connectait plus aux vraies données** : `ada start`/`ada server` ne démarraient jamais `ada-api-nest` ni le Control Server (seule l'UI, ou l'ancien `ada-api` déprécié, démarraient) ; même démarré manuellement, `ada-api-nest` retombait sur le mauvais profil par défaut (`claude-pro` codé en dur au lieu du profil actif réel). `ada start server` gère maintenant les 3 services dans le bon ordre, sous le bon profil — vérifié avec de vraies données Postgres.
- **Fiabilité machine neuve** : `install.sh` n'installait/ne construisait/ne configurait jamais `ada-api-nest` (composant cœur depuis la refonte P0, plus optionnel comme l'était l'ancien `ada-api`). Génère désormais un `.env` minimal (JWT_SECRET aléatoire) si absent — testé en conditions réelles, boot propre même sans Postgres (mode dégradé).

### Added
- **`/api/agents` scopé réellement par profil** : chaque profil a son propre `<profileDir>/agents/` sur disque (agents custom par profil) — le paramètre `profile` était rejeté côté backend et jamais envoyé côté frontend. Câblé bout en bout (control-server → NestJS → hook → UI).
- **Statut Obsidian live** : la carte Settings n'était qu'un formulaire de config (toggle + chemin, sauvegarde différée) — affiche maintenant un vrai statut (badge Actif/Inactif, lien "Ouvrir" le vault, compteur de sessions, message CLI si vault non initialisé), avec bascule immédiate (`POST /obsidian/status`, nouveau). Bouton Obsidian ajouté sur `/memory` ; indicateur sur la sidebar (lien renommé "Memory" → "Memory Graph").

### Fixed (dette de tests e2e)
- Bug systémique : `page.route()` avec un pattern relatif ne matchait jamais les requêtes cross-origin (`:7777`→`:3010`) depuis le retrait du Canal A — corrigé dans 6 fichiers de specs.
- `ProfileCard` écrasait systématiquement toute bascule de profil au chargement suivant (pas seulement un bug de test).
- Suite e2e complète : 51 échecs/5 passés → 14 échecs/39 passés. Restent `teams.spec.ts` et `profile-types.spec.ts` (fonctionnalités absentes, documentées dans `ada-ui/e2e/KNOWN-GAPS.md`, hors scope de cette release).

## [7.5.0] — 2026-08-13

### Added
- **ADR-023 étape 4** : gouvernance de coût des délégations adaptatives
- **ADR-023 étape 5** : bascule adaptative du pipeline `review` par flag
- Extension de la bascule adaptative aux 6 pipelines restants (mesure de l'écart non encore complétée — à surveiller en prod)

### Fixed
- `bench-v2` : exclut les entrées `superseded` du calcul de `buildReport`
- Test périmé `sdk-interactive-session.spec.ts` corrigé (fixture UUID pour `--resume`, cf. commit dédié) — n'affectait pas le code produit

### Docs
- Rattrapage `CHANGELOG.md` : entrées 7.3.0 et 7.4.0 précédemment manquantes
- `CLAUDE.md` (global + projet) : tier 2 corrigé vers `claude-sonnet-5` (source `models.js`), note sur l'écart réel de la règle télémétrie tokens
- Mesure réelle ADR-023 point 2 (review FIXED vs ADAPTIVE-MECH)

### Tests
- Couverture ADR-023 étapes 4-5 (délégations adaptatives + flag review)
- **92 suites / 2009 tests** au total (.claude + ada-api + ada-api-nest), 0 échec

## [7.4.0] — 2026-08-03

### Added
- **Licence commerciale propriétaire** (Phase 0 commercialisation) — voir `LICENSE`. État runtime purgé du dépôt, README repositionné en conséquence.
- Exécution directe du tier-0 codemod dans `ada run` (transform déterministe, zéro appel LLM)
- Gate d'injection mémoire à deux étages sur le recall ReasoningBank
- Flywheel anti-régression recall : ancres figées, baseline monotone, policy réversible
- Garde witness anti-régression, lexer shell segmenté, audit agents, garde « never-worse »
- `ada team reap` : TTL cleanup, downgrade solo/pipeline, fallback profil générique

### Changed
- IDs de modèles et pricing centralisés dans `coordinator/models.js` (source unique) — ajout de Claude Sonnet 5, correction de tarifs Opus/Haiku obsolètes
- Installeur rendu distribuable à des clients externes ; `ada update`/`ada install` unifiés, `install-remote.sh` supprimé
- Installeur : préserve `pipelines.json` personnalisé + propage `permissions.deny`

### Security
- Path traversal fermé dans le retry de l'AI Engineering Loop ; re-scan/double-comptage de télémétrie stoppé
- Allowlist Bash restreinte, hooks câblés fail-closed

### Fixed
- WAL + `busy_timeout` SQLite pour écritures concurrentes sur le ReasoningBank
- Résolution de chemin à deux essais pour le layout runtime (witness)
- Stub SQL de bench : préserve la qualification de schéma

### Docs
- ADR-020 (architecture licensing/entitlement par siège) proposée puis rejetée — le modèle économique réel n'a pas d'entitlement
- Wording corrigé « copié » → « adapté » dans `README-ruflo-agents.md`

## [7.3.0] — 2026-06-30

### Added
- **AI Engineering Loop** : `error-context.js` — parseur d'erreurs (TypeScript / `node:test` TAP / runtime / lint) → contexte structuré injecté dans le re-prompt agent
  - `run.js fail --error-output <file>` — capture et stocke `errorContext` dans `state.json`
  - Garde `maxLoops` (défaut 3) + escalade humaine (`LOOP LIMIT REACHED`)
  - Détection des erreurs non-déterministes (`ECONNREFUSED`, OOM…) → pas de loop, escalade directe
  - `run.js next --json` expose `loopContext` et `isLoopRetry` pour l'orchestrateur
  - `pipelines.json` : champs `loopTo` / `maxLoops` / `loopCondition` sur la phase coverage
  - `docs/ai-engineering-loop.md` — spécification complète (state machine, contrats API)

### Fixed
- Docker : entrypoint pour corriger les permissions du volume `ada-api`
- Docker : ajout de python3/make/g++ pour la compilation native de `node-pty`
- Docker : skip du téléchargement des navigateurs Playwright à l'étape `deps`

### Tests
- 22 nouveaux tests unitaires `error-context.test.js`, 14 nouveaux tests d'intégration `run-loop.test.js`
- 964/964 assertions — 0 régression sur les 40 suites existantes

## [7.2.0] — 2026-06-02

### Added
- **Dual-provider mode** : `ada provider set <claude-code|api>`
  - `claude-code` (défaut) : session Claude Code authentifiée via OAuth Claude.ai — aucune clé API requise
  - `api` : utilise `ANTHROPIC_API_KEY` injectée explicitement dans le processus Claude — idéal CI/CD ou sans compte Claude.ai
  - `ada provider` / `ada provider status` : affiche le mode actif et l'état de la clé
  - Mode persisté dans `~/.ada.json` → champ `providerMode`
  - `ada status` affiche désormais le fournisseur actif
  - En mode `claude-code`, `ANTHROPIC_API_KEY` est supprimée de l'env du processus fils (force OAuth, évite fuite)
- `.env.server.example` : section `ADA_PROVIDER_MODE` documentée avec les deux modes
- `docs/GUIDE.md` : section 6.2 "Mode fournisseur (dual-provider)" + table des prérequis par mode

## [7.1.0] — 2026-06-01

### Security
- HMAC-SHA256 sur événements IPC (backward-compatible, activé via `ADA_IPC_HMAC_SECRET`)
- CSP nonce-based via middleware Next.js (suppression `unsafe-inline` scripts en production)
- Validation pipeline regex + args spawn (`SAFE_ARG_RE /^[a-zA-Z0-9_\-:@=]{1,128}$/`)
- `timingSafeEqual` sur comparaison mot de passe mode server (anti timing attack)
- JWT WS : ticket one-time-use 30s — suppression `?token=` query string
- Cookie HttpOnly `ada-ui-token` pour token UI (suppression `data-ada-token` DOM)
- SQL injection curseurs pagination corrigée → paramètres préparés
- Curseur pagination isolé par `workspace_id` (fuite cross-workspace impossible)
- `maxPayload` WebSocket limité à 1 MB
- `adaApiToken` en mémoire uniquement (hors `localStorage`)
- `fast-uri` upgrade >=2.4.2 (CVE GHSA-q3j6-qgpj-74h6, GHSA-v39h-62p7-jpjc)
- Rate limit : 10 req/15min sur `POST /api/auth/token`, 60 req/min sur `GET /api/ws/ticket`
- `drizzle-orm` upgrade 0.45.2 (CVE GHSA-gpj5-g38j-94v9)

### Fixed
- HMAC ipc-emit off-by-one (`slice(0,-2)`) — pipeline événements réparé
- WS cleanup idempotent (flag `cleaned` — double `close`+`error` sans exception)
- `IpcClient` socket orphan sur fallback Unix→TCP
- `NdjsonParser` buffer cap 1 MB (protection OOM)
- Stale closure `activeWorkspaceId` dans `use-ada-ws` (corrigé via `useRef`)
- Migration runner séquentiel — migrations 0001+0002 maintenant appliquées dans l'ordre
- `stdout`/`stderr` du processus spawné drainés (évite blocage pipe)
- `wsTickets` nettoyage périodique via `setInterval` 5min (évite fuite mémoire)
- Race condition `~/.ada.json` — writes sérialisés via Promise queue
- MCP command path traversal — validation `includes('/')` avant allowlist
- SSE guard `token !== 'cookie'` (littéral `cookie` n'est plus transmis comme token)

### Performance
- N+1 conversations list corrigé → subquery `COUNT` inline
- `LIMIT 50` sur recherche conversations
- `getWorkspaceStats` : 3 queries → 1 CTE
- Prepared statements WS gateway (enregistrés dans `addHook onReady`)
- `useShallow` Zustand sur 7 composants (re-renders réduits)
- JWT rotation automatique : refresh déclenché à 90% du TTL

### Changed
- WS connexion : flux 2 étapes ticket (`GET /api/ws/ticket` → connect `?ticket=`)
- `wsTickets` décoré au niveau `app.js` (fix scope plugin Fastify)
- Timeline `stats/observe` `30d` non tronquée à 14 jours
- `cancelled` mappé correctement dans `mapStatus` (stats)

---

## [2.0.0] — 2026-05-10

### Phase 1 — Fix & Stabilisation

**Résolution de 5 merge conflicts bloquants :**
- `.claude/settings.json` — hook unifié sur `memory-manager.js` via `${CLAUDE_CONFIG_DIR}`
- `install.sh` — version propre, `CLAUDE_CONFIG_DIR` configurable, alias `dev-ai-<profile>()`
- `tmux-dev.sh` — refactorée, CONFIG_DIR flexible, projet obligatoire en argument
- `.claude/agents/orchestrator/CLAUDE.md` — suppression nom hardcodé
- `.claude/agents/reviewer/CLAUDE.md` — idem
- `.claude/commands/fetch-sprint.md` — exemples génériques

**Réécriture critique du hook `memory-manager.js` :**
- ESM (`import`) → CJS (`require`) : compatible Node.js sans configuration supplémentaire
- `for await` top-level → stdin event-driven (`data`/`end`) : évite crash REPL
- Ajout try/catch global avec logging dans `memory/hook.log`
- Timeout de sécurité 3s : Claude Code n'est jamais bloqué par un crash du hook

### Phase 2 — Unified Coordinator (State Machine)

**Nouveau : `coordinator/pipelines.json`**
DAG déclaratif de tous les pipelines (`feature`, `review`, `db-migrate`, `test`).
Chaque phase déclare ses dépendances, criticité, retry max, agent cible.
Modifier l'ordre d'un pipeline = modifier ce fichier, pas les prompts d'agents.

**Nouveau : `coordinator/run.js`**
CLI state machine Node.js (CJS, zero dépendance externe) :
- `init` : initialise un run avec runId unique
- `start` : démarre une phase (vérifie les dépendances)
- `done` : marque une phase terminée (calcule la prochaine)
- `fail` : marque un échec (retry si quota restant, stop si critique)
- `skip` : saute une phase (ex: frontend sur --api-only)
- `status` : affiche l'état complet d'un run avec durées
- `list` : liste les 20 runs récents
État persisté dans `.claude/runs/<runId>/state.json`.

**Architecture Domain-Based dans l'orchestrateur :**
Inspiré du Unified Swarm Coordinator de ruflo (ADR-003).
Les agents sont routés via leur domaine fonctionnel (DATA / BACKEND / FRONTEND / QUALITY)
plutôt qu'une table statique de mots-clés.

**Refonte de `.claude/commands/feature.md` :**
Intégre le coordinator à chaque étape (init → start → done/fail → status).
Retry logic explicite (max configurable par phase dans pipelines.json).
Protocole de diagnostic d'échec structuré.

**Nouveau : `docs/ADR-001-unified-coordinator.md`**
Architecture Decision Record documentant le choix, les alternatives rejetées,
les conséquences et les futures améliorations planifiées.

### Phase 3 — Hooks System & Background Workers

**Nouveau hook : `hooks/pre-bash.js`** (PreToolUse Bash)
Garde de sécurité dynamique avec 8 règles bloquantes (rm -rf ciblé, curl|bash, DROP en prod, secrets exportés…).
Log de toutes les commandes dans `logs/commands.log` avec catégorie et flags warning.
Protocole Claude Code : `{"decision": "allow"|"block", "reason": "..."}` — jamais bloquant si le hook plante.

**Nouveau hook : `hooks/post-bash.js`** (PostToolUse Bash)
Détection d'événements dans les commandes Bash : git commit/push, test runs (Jest/Vitest/pytest), migrations DB, builds Docker/TS.
Par événement : mise à jour du log correspondant dans `memory/projects/<project>/` + dispatch du worker approprié en background.

**Nouveau hook : `hooks/session-end.js`** (Stop)
Checkpoint léger après chaque réponse Claude Code (counter de réponses).
Dispatch de `consolidate` toutes les 10 réponses si mémoire > 200 lignes.
Dispatch de `ultralearn` toutes les 20 réponses.

**Nouveau worker : `workers/testgaps.js`**
Analyse les fichiers source modifiés dans les 2 dernières heures.
Identifie ceux sans fichier de test correspondant + extrait les fonctions/classes exportées sans test.
Écrit un rapport dans `memory/projects/<project>/testgaps.md`.

**Nouveau worker : `workers/audit.js`**
Scan de sécurité OWASP sur les fichiers modifiés (30min mode quick, 4h mode complet).
10 règles : SQL injection, secrets hardcodés, JWT sans verify, eval(), Math.random() crypto, XSS innerHTML, path traversal, CORS wildcard, logs sensibles, RLS manquante.
Rapport dans `memory/projects/<project>/audit.md`.

**Nouveau worker : `workers/consolidate.js`**
Déduplication des entrées par similarité Jaccard (seuil 0.8).
Archivage des entrées > 30 jours dans `archive/YYYY-QN.md`.
Conservation des 50 entrées les plus récentes par fichier.

**Nouveau worker : `workers/ultralearn.js`**
Extraction des termes récurrents (7 derniers jours) par fréquence.
Génération automatique d'une liste DO/DON'T depuis errors.md.
Mise à jour de `memory/global/insights.md` avec les 10 dernières sessions.

**settings.json** — 3 nouveaux événements hooks enregistrés (PreToolUse Bash, PostToolUse Bash, Stop).

**Nouveau : `docs/ADR-002-hooks-workers.md`**
Architecture Decision Record : mapping ruflo → AI Dev Assistant, table des règles de sécurité,
registre des logs, protocole async, conséquences et trade-offs.

### Phase 4 — Thompson Sampling Router

**Nouveau : `coordinator/router.js`** (CLI + module Node.js)
Implémentation complète Thompson Sampling (Beta distribution via Marsaglia-Tsang, zero-dependency).
- `recommend <phaseType>` : agent optimal par sampling Beta(α,β) sur tous les candidats
- `update <phase> <agent> success|failure` : mise à jour des priors
- `seed` : bootstrap automatique depuis tous les `runs/*/state.json` existants
- `stats` : dashboard avec barres, win rates, niveaux de confiance

**Intégration transparente dans `run.js`** :
`run.js done` → `router.js update <phase> <agent> success` (background)
`run.js fail` → `router.js update <phase> <agent> failure` (background)
Zéro modification des slash commands — les priors se mettent à jour automatiquement.

**Orchestrateur mis à jour** (`orchestrator/CLAUDE.md`) :
Section routing adaptatif avec protocole de décision par niveau de confiance (none/low/medium/high).

**Nouveau : `docs/ADR-003-thompson-sampling.md`**
Algorithme détaillé, phases et candidats, niveaux de confiance, exemple d'évolution sur 20 sessions.

### Phase 5 — ReasoningBank (Mémoire par trajectoires)

**Nouveau : `coordinator/bank.js`** (CLI + module Node.js)
Mémoire par trajectoires structurées — pipeline STORE→RETRIEVE→JUDGE→DISTILL→CONSOLIDATE.
- `store <phase> <agent> <verdict> "<summary>"` : enregistre une trajectoire après chaque phase
- `retrieve <query> [--phase p] [--agent a]` : retrouve les trajectoires pertinentes par score composite (phase+agent+tokens+recency)
- `distill [--since <days>]` : extrait DO/DON'T depuis les succès et échecs, génère insights par phase
- `consolidate` : déduplique par Jaccard similarity > 0.85, archive les trajectoires > 90j avec score < 0.2
- `stats` : dashboard avec taux de succès par phase, agent favori, insights globaux
- `list [--phase p]` : liste les trajectoires récentes

**Scoring de pertinence (RETRIEVE) :**
Phase match +4 · Agent match +3 · Token overlap +1/token · Recency +2 max · Success verdict +0.5

**Intégration transparente dans `run.js`** :
`run.js done` → `bank.js store <phase> <agent> success` (background)
`run.js fail` → `bank.js store <phase> <agent> failure` (background)
Même pattern fire-and-forget que le Thompson Sampling router.

**Distillation automatique dans `workers/ultralearn.js`** :
Toutes les 20 réponses → `ultralearn` → `bank.js distill --since 30` (background)
Maintient `insights.byPhase` et `insights.globalDo/globalDont` à jour.

**Orchestrateur mis à jour** (`orchestrator/CLAUDE.md`) :
Section ReasoningBank avec protocole de consultation avant délégation.
Trajectoires success → contexte enrichi pour l'agent.
Trajectoires failure → avertissements sur les pièges connus.

**Nouveau : `docs/ADR-004-reasoningbank.md`**
Pipeline complet, structure de trajectoire, scoring RETRIEVE, exemple sur 10 sessions,
relation avec la mémoire plate existante, roadmap phase 6 (embedding sémantique).

### Roadmap

- Phase 6 — Embedding sémantique (nomic-embed via ollama) pour retrieve vectoriel

---

## [1.1.0] — 2025

### Fixed
- Added YAML frontmatter to all agent files (required by Claude Code for agent discovery)
  - Without `name:` and `description:` fields, Claude Code silently ignores agent files
  - Claude Code caches agents at session start — restart required after modifying agent files

### Agent file format
Each agent file now follows the required structure:
```
---
name: <agent-name>
description: <one-line description used by Claude Code for agent selection>
---

# Agent title
## Rôle
...
```

## [1.0.0] — 2025

### Added
- 11 specialized agents (flat structure: agents/<name>.md)
- 9 slash commands
- 8 MCP servers (GitHub, Supabase, Filesystem, Playwright, Docker, Sentry, AWS, Linear)
- Automatic memory system with hierarchical compression
- tmux workspace with 7-pane layout
- Multi-profile support (claude-perso, claude-pro, claude-ov)
- install.sh only injects dev-ai-*() functions, never overrides existing claude-* aliases

## [1.2.0] — 2025

### Fixed

#### tmux — pane-base-index mismatch
- Replaced all numeric pane references (`.0`, `.1`...) with absolute pane IDs (`%N`)
- ID captured via `tmux display-message -p '#{pane_id}'` immediately after each split
- Immunized against any `pane-base-index` setting in tmux.conf

#### tmux — claude not started in panes
- Each pane now runs `CLAUDE_CONFIG_DIR='...' command claude` on startup
- All 7 main panes + 3 mobile panes open a live Claude REPL with correct profile
- Orchestrator pane focused last so user lands directly in it

## [1.3.0] — 2025

### Fixed

#### settings.json — clé incorrecte pour le mode tmux agent teams
- Remplacé `preferences.tmuxSplitPanes: true` (clé inexistante, ignorée silencieusement)
- Par `"teammatMode": "tmux"` (clé correcte pour Claude Code)
- Ajout de `env.CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS: "1"` requis pour activer les agent teams
- Sans ces deux clés, les agents se lancent dans la même fenêtre au lieu de panes séparés

## [1.3.1] — 2025

### Fixed

#### settings.json — faute d'orthographe + configuration incomplète
- `"teammatMode"` → `"teammateMode"` (faute d'orthographe corrigée)
- Ajout de `"preferences": { "tmuxSplitPanes": true }` requis pour activer le split tmux
- Configuration correcte finale :
  ```json
  "teammateMode": "tmux",
  "preferences": {
    "tmuxSplitPanes": true
  }
  ```

## [1.3.2] — 2025

### Fixed

#### Séparation correcte des clés de configuration tmux agent teams
- `"teammateMode": "tmux"` → déplacé dans `.claude.json` (doc officielle)
- `"preferences": { "tmuxSplitPanes": true }` → conservé dans `settings.json`
- `"teammatMode"` (faute) et doublon dans `settings.json` supprimés

## [1.4.0] — 2025

### Added

#### CLAUDE.md — activation explicite du système agent teams
- Ajout d'une règle fondamentale : "Ne jamais implémenter directement"
- Délégation systématique via `Task` tool pour toute tâche de développement
- Tableau des agents avec mapping tâche → agent
- Ordre de délégation standard pour une feature complète
- Liste des slash commands disponibles
- Format de résumé obligatoire après chaque tâche
- Sans ce prompt, Claude répond en mode conversationnel standard et n'orchestre pas les agents

## [1.5.0] — 2025

### Added — 13 nouveaux agents (total : 24)

| Agent | Rôle |
|-------|------|
| `feature-architect` | Analyse codebase + conception architecture feature |
| `technical-architect` | Architecture système globale + ADR |
| `api-designer` | Contrats API avant implémentation |
| `ux-designer` | User flows, wireframes textuels, accessibilité |
| `data-modeler` | Modélisation DB stratégique avant agent db |
| `security-auditor` | Audit sécurité OWASP dédié |
| `performance-analyst` | Bottlenecks, N+1, bundle, optimisation |
| `devils-advocate` | Risques, hypothèses, contre-analyse |
| `business-researcher` | Valeur produit, KPIs, priorisation |
| `financial-analyst` | ROI, coûts infra, viabilité |
| `doc-writer` | README, ADR, OpenAPI, changelogs |
| `migration-strategist` | Migrations sans downtime, expand/contract |
| `onboarding-agent` | Brief complet d'un projet inconnu |

### Updated
- `CLAUDE.md` — tableau de routage étendu + ordre de délégation en 16 étapes
- `install.sh` — installation des 24 agents

## [1.5.1] — 2025

### Updated

#### tmux workspace — 5 fenêtres pour 24 agents
- `[1] main`     — orchestrateur + agents core (nestjs/nextjs/db/devops/tester/reviewer)
- `[2] strategy` — agents avant implémentation (9 agents)
- `[3] business` — agents business/produit (4 agents)
- `[4] mobile`   — agents mobile (3 agents)
- `[5] logs`     — monitoring
- Tous les agents démarrent avec claude automatiquement au lancement du workspace

## [1.6.0] — 2025

### Added
- MCP activation sélective via `MCP_ENABLED` dans `.env`
  - `MCP_ENABLED=all` → activer tous les MCP
  - `MCP_ENABLED=github,supabase` → activer sélectivement
  - `MCP_ENABLED=` (vide) → aucun MCP (défaut)
- `.env.example` mis à jour avec documentation de `MCP_ENABLED`

### Changed — tmux workspace
- Démarrage limité à **3 panes actifs** (orchestrateur + nestjs + reviewer)
- Les autres agents sont dans des fenêtres idle (vars exportées, claude non démarré)
- Activer un agent à la demande : naviguer dans le pane + lancer `claude-perso/pro/ov`
- Réduction de la consommation mémoire au démarrage

### Raison
- Chaque instance claude active consomme ~200-400MB de RAM
- 24 instances actives = potentiellement 5-10GB RAM
- Stratégie lazy loading : n'activer que les agents dont on a besoin

## [2.0.0] — 2025 — Optimisation tokens

### Breaking changes
- CLAUDE.md global réduit de ~120 lignes à 39 lignes (-68%)
- Tous les agents réduits à 7-10 lignes (-85% par agent)
- Maximum 3 agents actifs par session (via team profiles)

### Added
- **Team profiles** — 14 profils prédéfinis (équipe + stack)
  - `/team fullstack` / `frontend` / `backend-drf` / `review` / `strategy` / etc.
  - Limite stricte à 3 agents par profil
  - Profil sauvegardé dans `teams/active-profile.txt`
- **`/team`** — lister, activer, désactiver les profils
- **`/reset`** — vider le contexte (soft / complet / avec summary)
- **`/compact`** — compresser l'historique sans vider
- Règle token dans CLAUDE.md : vérifier /compact après 20 échanges

### Optimisations
- CLAUDE.md : 120 → 39 lignes
- Agents : 40-80 → 7-10 lignes chacun
- 3 panes actifs au démarrage (inchangé depuis v1.6)
- MCP sélectifs via MCP_ENABLED (inchangé depuis v1.6)

### Économie tokens estimée
- Par prompt solo : -70% (CLAUDE.md + agents allégés)
- Par session avec profil 3 agents : -85% vs tous les agents actifs
- Avec /compact régulier : -60% supplémentaire sur l'historique

## [2.1.0] — 2025

### Changed — Architecture simplifiée

#### tmux — 1 seul pane
- Suppression de tous les panes agents
- 1 pane orchestrateur + 1 fenêtre logs
- Les agents s'exécutent via Task tool (subagents Claude Code natif)
- Économie RAM : ~2GB au démarrage

#### Auto-switch de profil
- L'orchestrateur analyse chaque prompt et active automatiquement le profil adapté
- Pas besoin de `/team` manuel — le switch est transparent
- Profil affiché en début de réponse : `[Profil: fullstack]`

#### Auto-compact et auto-reset
- Compteur interne : 7 échanges maximum par session
- Échange 6 : avertissement automatique
- Échange 7 : /compact déclenché automatiquement
- Format de réponse : `[Profil: X] [Échange N/7]`

## [2.2.0] — 2025

### Added — Détection automatique de stack

#### detect-stack.sh
Lancé automatiquement par `tmux-dev.sh` avant de démarrer claude.
Lit les fichiers du projet courant et détecte :
- Backend : NestJS, DRF, Django, FastAPI
- Frontend : Next.js, Tailwind, shadcn/ui
- DB : PostgreSQL (Prisma/Django), Supabase, MySQL
- Mobile : React Native/Expo, iOS/Swift, Android/Kotlin
- Infra : Docker, GitHub Actions
- Tests : Jest, Vitest, pytest, Playwright

Écrit le résultat dans `context.md` du projet (~50 tokens, une seule fois).
Sauvegarde le profil optimal dans `active-profile.txt`.
Coût : négligeable vs devoir décrire la stack manuellement.

#### Profil activé dès le démarrage
Le titre du pane tmux affiche : `AI Dev — <projet> [<profil>]`
Claude démarre avec le profil déjà activé sans aucune intervention.

## [2.3.0] — 2025

### Token optimizations

#### CLAUDE.md : 39 → 6 lignes (-85%)
- Contenu déplacé dans `.claude/teams/routing.md`
- routing.md chargé une seule fois au démarrage de session (pas à chaque échange)
- Économie : ~2.5k tokens × 7 échanges = **~17k tokens/session**

#### Grep-first sur les agents qui lisent du code
- `feature-architect` : grep ciblé obligatoire avant toute lecture
- `onboarding-agent` : exploration légère par étapes (find → grep → lecture sélective)
- `reviewer`, `security-auditor`, `performance-analyst`, `technical-architect` : hint grep ajouté
- Objectif : passer de 4 lectures séquentielles de fichiers à des greps ciblés
- Économie estimée : **-60% sur les tokens de lecture fichiers**

#### Impact estimé sur la tâche de référence (90k tokens)
| Poste | Avant | Après | Économie |
|-------|-------|-------|----------|
| CLAUDE.md × 7 | 21k | 4k | -17k |
| Lectures fichiers | 34k | ~14k | -20k |
| Écriture/éditions | 18k | 18k | 0 |
| **Total estimé** | **90k** | **~53k** | **-41%** |

## [2.3.1] — 2025

### Fixed — Agent teams context

#### CLAUDE.md : routing réintégré (35 lignes)
- Problème : CLAUDE.md à 6 lignes référençait routing.md mais Claude Code
  ne charge pas automatiquement les fichiers référencés
- Fix : routing table réintégrée directement dans CLAUDE.md
- Équilibre : 35 lignes (vs 6 trop court, vs 79 trop long)
- Comportement orchestrateur explicite : quand et comment déléguer

#### settings.json nettoyé
- Suppression de `preferences.tmuxSplitPanes` — inutile avec 1 seul pane
- `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS: "1"` conservé
- `teammateMode: "tmux"` reste dans `.claude.json` (doc officielle)

## [2.4.0] — 2025

### Added — 94 skills (24 agents)

Skills générés pour tous les agents :

| Agent | Skills |
|-------|--------|
| orchestrator | 4 (delegate-feature, triage-task, consolidate-results, session-handoff) |
| nestjs | 7 (create-module, create-guard, create-queue-worker, create-prisma-service, create-health-check, add-rate-limiting, create-config-module) |
| drf | 5 (create-app, create-viewset, create-serializer, create-celery-task, create-factory) |
| nextjs | 7 (create-page, create-form, create-tanstack-query, create-server-action, create-zustand-store, create-data-table, create-auth-flow) |
| db | 5 (create-table, create-rls-policies, create-index-strategy, create-audit-log, add-full-text-search) |
| devops | 5 (create-dockerfile, create-github-actions-ci, create-github-actions-deploy, create-docker-compose, + deploy) |
| tester | 6 (write-tdd-specs, write-unit-tests-nestjs, write-e2e-playwright, create-test-factories, write-component-tests, + autres) |
| reviewer | 4 (review-pr, review-security, generate-review-checklist, review-test-quality) |
| security-auditor | 4 (audit-authentication, audit-authorization, audit-dependencies, create-rate-limiting) |
| feature-architect | 3 (explore-codebase, design-feature, estimate-complexity) |
| technical-architect | 3 (write-adr, design-microservices, design-caching-strategy) |
| api-designer | 3 (design-rest-api, design-error-responses, design-pagination) |
| ux-designer | 4 (design-user-flow, design-wireframe, design-form-ux, audit-accessibility) |
| data-modeler | 3 (model-domain, design-soft-delete, design-multi-tenant) |
| performance-analyst | 4 (analyze-query-plan, fix-n-plus-one, optimize-bundle, optimize-react-renders) |
| migration-strategist | 3 (plan-zero-downtime-migration, backfill-data, create-rollback-plan) |
| react-native | 3 (create-screen, create-list-screen, add-offline-support) |
| android | 2 (create-feature-module, write-viewmodel-tests) |
| swift | 4 (create-feature-module, create-swiftui-view, add-keychain-storage, write-xctest-unit) |
| business-researcher | 3 (analyze-feature-value, prioritization-matrix, write-product-brief) |
| financial-analyst | 3 (estimate-dev-cost, calculate-roi, build-vs-buy-analysis) |
| devils-advocate | 3 (challenge-feature, pre-mortem, risk-matrix) |
| doc-writer | 3 (write-readme, write-runbook, write-postmortem) |
| onboarding-agent | 3 (explore-project-structure, write-project-brief, assess-code-quality) |
