# Architecture Mémoire — ADA

> Document de référence technique. Dernière mise à jour : 2026-05-31.

---

## Vue d'ensemble

ADA dispose d'un système de mémoire **hybride à 7 couches** qui opèrent de façon complémentaire : les couches 1 à 2 sont des stores structurés actifs à chaque appel, les couches 3 à 4 sont des hooks réactifs déclenchés par les événements Claude Code, les couches 5 à 6 sont des surfaces de persistance longue durée (vault Obsidian + fichiers Markdown), et la couche 7 est la couche vectorielle HNSW persistante superposée à SQLite (v7.0.0).

```
┌─────────────────────────────────────────────────────────────────┐
│                        CLAUDE CODE (LLM)                        │
│                                                                 │
│  Lit  ──► MEMORY.md + context.md           [Couche 6]          │
│  Écrit ──► via hooks PostToolUse / Stop                         │
└─────────────┬────────────────────┬──────────────────────────────┘
              │                    │
     PostToolUse hook           Stop hook
     (chaque Write/Edit)        (chaque réponse)
              │                    │
              ▼                    ▼
┌─────────────────────┐   ┌──────────────────────────────────────┐
│  Memory Manager     │   │  Session End                         │
│  [Couche 3]         │   │  [Couche 4]                          │
│                     │   │                                      │
│  decisions.md       │   │  sessions.log                        │
│  patterns.md        │   │  cache-keepalive.json                │
│  errors.md          │   │  → worker consolidate (> 200 lignes) │
│  context.md         │   │  → worker ultralearn (/ 20 réponses) │
│  + archivage /archive│  │  → router.js decay (/ 30 réponses)   │
└─────────────────────┘   └──────────────┬───────────────────────┘
                                         │
                          ┌──────────────▼───────────────────────┐
                          │  Obsidian Vault [Couche 5]            │
                          │                                       │
                          │  sessions/YYYY-MM-DD-HHhMM.md        │
                          │  daily/YYYY-MM-DD.md (append)        │
                          └──────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│  STORES ACTIFS (utilisés par le coordinator à chaque run)       │
│                                                                 │
│  Typed Memory [Couche 1]          KnowledgeGraph [Couche 2]    │
│  ┌────────────────────────┐       ┌───────────────────────────┐│
│  │ episodic  (TTL 7j)     │       │ Nœuds : agent/phase/      ││
│  │ semantic  (TF-IDF pur) │       │         pipeline/pattern/ ││
│  │ procedural (boost usage│       │         error/unknown     ││
│  │ Max 500 entrées/store  │       │ Arêtes : WIN_RATE /        ││
│  └────────────────────────┘       │   PRÉCÈDE / A_RÉSOLU /    ││
│                                   │   CO_OCCURRENCE / CAUSE / ││
│                                   │   ANTI_CORRÈLE            ││
│                                   │ Algos : BFS, PageRank,    ││
│                                   │   scoreHybrid             ││
│                                   └───────────────────────────┘│
└─────────────────────────────────────────────────────────────────┘
```

---

## Couche 1 : Typed Memory (3-Stores)

**Fichier source :** `.claude/coordinator/typed-memory.js`

### Principe

Trois stores JSON indépendants, chacun avec une stratégie de scoring différente adaptée à la nature de l'information stockée. Toutes les opérations sont synchrones (Node.js CJS pur, zéro dépendance externe). Les écritures utilisent un pattern tmp→rename pour éviter la corruption.

### Structure d'une entrée

```json
{
  "id":      "mem-1716300000000-abc12",
  "key":     "fix symlink ada cli",
  "content": "sudo ln -sf .claude/bin/ada.js /usr/local/bin/ada",
  "tags":    ["fix", "symlink", "ada", "cli"],
  "ts":      "2026-05-21T14:32:00.000Z",
  "usages":  3,
  "score":   0.5,
  "ttl":     "2026-05-28T14:32:00.000Z",   // episodic seulement
  "meta":    { "phase": "install", "agent": "devops" }
}
```

- `id` : `mem-<timestamp>-<5 chars aléatoires>`
- `key` : tronqué à 200 caractères
- `content` : tronqué à 4 000 caractères
- `tags` : 20 premiers tokens du champ `key + content`
- `meta` : champ libre (phase, agent, runId, verdict…)

### Store episodic

**Fichier :** `~/.claude-pro/coordinator/memory-episodic.json`

Destiné aux contextes récents de session. Décroissance temporelle agressive.

- TTL explicite : **7 jours** (`TTL_EPISODIC_MS = 7 * 24 * 60 * 60 * 1000`)
- La purge supprime toute entrée dont `ttl < Date.now()`

**Scoring :**
```
score = TF-IDF × exp(-ageHours / 48)
```
La demi-vie effective est de **48 heures** : une entrée vieille d'un jour vaut `exp(-24/48) ≈ 0.61` de son score TF-IDF initial. À 4 jours (~96h) : `exp(-2) ≈ 0.135`.

**Détection automatique :** le router détecte l'episodic si la requête contient : `récemment`, `dernier`, `aujourd`, `session`, `hier`, `ce matin`, `vient de`, `just now`.

### Store semantic

**Fichier :** `~/.claude-pro/coordinator/memory-semantic.json`

Connaissances durables accumulées (décisions d'architecture, faits techniques).

**Scoring :** TF-IDF pur — pas de décroissance temporelle, pas de boost par usage.
```
score = cosineSimilarity(queryTokens, entryTokens)
```

**Détection automatique :** store par défaut si aucun pattern episodic ou procedural n'est détecté.

### Store procedural

**Fichier :** `~/.claude-pro/coordinator/memory-procedural.json`

Patterns, recettes, étapes, best practices — information procédurale réutilisable.

**Scoring :**
```
score = TF-IDF × (1 + 0.1 × usages)
```
Chaque réutilisation (`incrementUsage`) augmente le score de 10%. Une entrée utilisée 10 fois bénéficie d'un multiplicateur de ×2 sur son score TF-IDF.

**Détection automatique :** si la requête contient : `comment`, `how to`, `étapes`, `procédure`, `pattern`, `best practice`, `recette`, `template`.

### Scoring TF-IDF (implémentation inline)

L'implémentation évite toute dépendance externe en utilisant une similarité cosine sparse sur les tokens.

**Tokenisation :**
```javascript
text.toLowerCase()
    .replace(/[^a-z0-9àâéèêëîïôùûüç\s]/g, ' ')
    .split(/\s+/)
    .filter(t => t.length > 2)
```
Supporte les caractères accentués français. Les tokens de 1 ou 2 caractères sont filtrés.

**Similarité cosine sparse :**
```
cosineSimilarity(a, b) = |intersection(Set(a), Set(b))| / (sqrt(|Set(a)|) × sqrt(|Set(b)|))
```
Epsilon `1e-10` pour éviter la division par zéro. La similarité est calculée sur les ensembles (pas les multisets) — la fréquence d'un terme ne compte pas, seule sa présence/absence.

**Ordre de recherche :** le store détecté en priorité est interrogé en premier. Les autres stores sont interrogés ensuite dans l'ordre `episodic → semantic → procedural`. Les résultats sont fusionnés et triés par score décroissant.

### Éviction LRU

Déclenchée automatiquement à chaque `store()` si le nombre d'entrées dépasse **500** (`MAX_PER_STORE`).

**Formule de ranking :**
```
rank = score × exp(-ageMs / (30j_en_ms)) + usages × 0.01
```
Les 500 entrées avec le rank le plus élevé sont conservées. Les entrées très anciennes et peu utilisées sont éjectées en premier.

### Purge des entrées dormantes

La commande `expire` supprime :
1. Toute entrée episodic dont `ttl < now`
2. Toute entrée (tous stores) dont : `âge > 30j ET score < 0.1 ET usages === 0`

### API CLI

```bash
# Stocker une entrée
node .claude/coordinator/typed-memory.js store episodic "titre" "contenu"
node .claude/coordinator/typed-memory.js store semantic  "titre" "contenu"
node .claude/coordinator/typed-memory.js store procedural "titre" "contenu"
node .claude/coordinator/typed-memory.js store auto       "titre" "contenu"

# Rechercher
node .claude/coordinator/typed-memory.js retrieve "symlink ada"
node .claude/coordinator/typed-memory.js retrieve "migration SQL" --type semantic --limit 10

# Statistiques
node .claude/coordinator/typed-memory.js stats

# Purger les entrées expirées
node .claude/coordinator/typed-memory.js expire
```

---

## Couche 2 : KnowledgeGraph (Graphify)

**Fichiers sources :** `.claude/coordinator/graph-memory.js` (classe), `.claude/coordinator/graph-builder.js` (construction)

### Principe

Graphe orienté et pondéré modélisant les relations entre agents, phases, pipelines, patterns et erreurs. Utilisé par le coordinator pour scorer les paires agent×phase lors du routage. La classe `KnowledgeGraph` est un module pur (Maps en mémoire), indépendant de tout I/O.

### Nœuds et types

| Type | Format ID | Description |
|------|-----------|-------------|
| `agent` | `agent:<slug>` | Agent Claude Code (ex: `agent:nestjs`) |
| `phase` | `phase:<id>` | Phase d'un pipeline (ex: `phase:implement`) |
| `pipeline` | `pipeline:<name>` | Pipeline nommé |
| `pattern` | `pattern:<id>` | Pattern appris (usage futur) |
| `error` | `error:<id>` | Erreur catégorisée |
| `unknown` | tout ID | Nœud créé implicitement par une arête orpheline |

Structure d'un nœud :
```json
{
  "id":    "agent:nestjs",
  "type":  "agent",
  "label": "nestjs",
  "attrs": { "winRate": 0.88, "totalRuns": 42 }
}
```

**Upsert :** si un nœud avec le même ID existe, ses `attrs` sont fusionnés (`Object.assign`) mais `type` et `label` sont conservés.

### Arêtes et types

| Type | Direction | Sémantique | Poids |
|------|-----------|------------|-------|
| `WIN_RATE` | agent → phase | Succès de l'agent sur cette phase | Cumulatif (+1 par succès) |
| `A_RÉSOLU` | agent → phase | Résolution confirmée | Cumulatif (+1) |
| `ANTI_CORRÈLE` | agent → phase | Échec de l'agent sur cette phase | Cumulatif (+0.5) |
| `PRÉCÈDE` | phase → phase | Ordre d'exécution dans un pipeline | 1 (fixe) |
| `CO_OCCURRENCE` | agent → agent | Deux agents ont traité la même phase dans une fenêtre de 5 | Cumulatif (+1) |
| `CAUSE` | error → error ou phase → error | Relation causale | Défini par l'appelant |

**Clé d'arête :** `${from}→${to}:${type}` — garantit l'unicité par couple (from, to, type). Si une arête existe déjà, le poids est **cumulé** (+=), pas remplacé.

### Algorithme BFS

```javascript
graph.bfs('agent:nestjs', { maxHops: 3, edgeTypes: ['WIN_RATE', 'PRÉCÈDE'] })
// Retourne : Map<nodeId, { depth: number, viaEdge: GraphEdge }>
```

BFS standard avec file FIFO. Parcourt uniquement les arêtes sortantes (`adj`). Filtre optionnel sur le type d'arête. Le nœud de départ n'est pas inclus dans le résultat.

### Algorithme PageRank

```javascript
const scores = graph.pageRank({ iterations: 20, damping: 0.85 })
// Retourne : Map<nodeId, number>
```

**Paramètres :** 20 itérations, facteur d'amortissement d=0.85 (valeur standard Google).

**Formule par itération :**
```
PR(u) = (1 - d) / N + d × (Σ PR(v) / OutDegree(v))  pour tout v → u
```

**Gestion des nœuds dangling** (sans arête sortante) : le score total des nœuds dangling est redistribué équitablement à tous les nœuds à chaque itération, ce qui évite la fuite de score ("rank sink").

**Initialisation :** chaque nœud reçoit un score initial de `1/N`.

### Scoring scoreAgentPhase

```javascript
graph.scoreAgentPhase('nestjs', 'implement')
// Retourne : number ∈ [0, 1]
```

```
netRate = WIN_RATE.weight / (WIN_RATE.weight + ANTI_CORRÈLE.weight)
           (0.5 si aucune donnée)

score = netRate × 0.7 + min(A_RÉSOLU.weight / 10, 1) × 0.3
```

- **70%** de la pondération vient du ratio succès/échecs nets
- **30%** vient du nombre de résolutions confirmées (plafonné à 10)

### Scoring scoreHybrid

```javascript
const pr = graph.pageRank()
graph.scoreHybrid('nestjs', 'implement', pr)
// Retourne : number ∈ [0, 1]
```

Enrichit `scoreAgentPhase` avec l'importance structurelle de l'agent dans le graphe :
```
prNorm = min(PR(agent) × N, 2)   // cap à 2× pour éviter domination
score  = min(localScore × (1 + prNorm × 0.2), 1)
```
Un agent au centre du graphe (PageRank élevé) bénéficie d'un boost maximal de **40%** sur son score local.

### Sources de données

**Priorité de construction :** SQLite (`bank.db`) > JSON (`bank-state.json`) > vide.

#### bank-state.json / bank.db

Contient les trajectoires passées (agent, phase, verdict).

**Passe 1 — aggregate :** pour chaque trajectoire, appelle `graph.aggregate(agent, phase, verdict)` :
- `success` → +1 WIN_RATE + +1 A_RÉSOLU
- `failure` → +0.5 ANTI_CORRÈLE
- `partial` → aucune modification du graphe

**Passe 2 — CO_OCCURRENCE :** fenêtre glissante de **5 trajectoires consécutives**. Si deux agents différents ont traité la même phase dans cette fenêtre → arête CO_OCCURRENCE +1 entre ces agents.

#### pipelines.json

Pour chaque pipeline, crée des arêtes `PRÉCÈDE` (poids 1) entre phases consécutives dans l'ordre déclaré. Supporte les formats `phases[].id` et `steps[].phase`.

#### SQLite bank.db

Préféré si présent car toujours à jour. Requête :
```sql
SELECT agent, phase, verdict, ts FROM trajectories ORDER BY ts ASC
```
Utilise `node:sqlite` (Node.js 22+). Si `node:sqlite` est absent ou si la DB est verrouillée, le builder bascule silencieusement sur bank-state.json.

### Persistance

**Fichier :** `~/.claude-pro/coordinator/graph-state.json` (ou `~/.claude/coordinator/graph-state.json` selon `CLAUDE_CONFIG_DIR`)

Format :
```json
{
  "nodes": [ { "id": "...", "type": "...", "label": "...", "attrs": {} } ],
  "edges": [ { "from": "...", "to": "...", "type": "...", "weight": 1, "ts": "...", "attrs": {} } ]
}
```

**Cache :** `loadOrBuild()` relit le fichier si son âge est inférieur à **1 heure**. Au-delà, reconstruit depuis les sources et sauvegarde.

### API CLI

```bash
# Construire et sauvegarder le graphe depuis toutes les sources
node .claude/coordinator/graph-builder.js build

# Statistiques du graphe sauvegardé
node .claude/coordinator/graph-builder.js stats

# Afficher le JSON brut du graphe
node .claude/coordinator/graph-memory.js graph

# Stats via graph-memory.js directement
node .claude/coordinator/graph-memory.js stats
```

---

## Couche 3 : Memory Manager Hook (PostToolUse)

**Fichier source :** `.claude/hooks/memory-manager.js`

### Déclenchement

Hook `PostToolUse` déclaré dans `settings.json`. Se déclenche après chaque appel aux outils `Write`, `Edit`, et `MultiEdit` effectués par Claude Code. Lit le payload JSON depuis `stdin`. Timeout de sécurité : **3 secondes** (`setTimeout(() => process.exit(0), 3000)`).

### Filtrage des fichiers

Deux niveaux de filtrage empêchent la mémorisation de fichiers sans valeur :

**Filtrage par chemin (SKIP_PATTERNS) :**
```
memory/  hooks/  node_modules  .git/
dist/  build/  __pycache__  .next/  coverage/
session-state.json  session-skill-cache.json
```

**Filtrage par extension (SKIP_EXTENSIONS) :**
`.json`, `.lock`, `.yaml`, `.yml`, `.toml`, `.ini`, `.env`, `.log`, `.tmp`, `.bak`, `.map`, `.png`, `.jpg`, `.jpeg`, `.gif`, `.svg`, `.ico`, `.webp`, `.woff`, `.woff2`, `.ttf`, `.eot`, `.zip`, `.tar`, `.gz`

**Whitelist JSON :** `package.json`, `tsconfig.json`, `prisma/schema.prisma` passent malgré l'extension `.json`.

**Filtre de taille :** le contenu doit faire au moins **80 caractères**.

### Classification des contenus

```
classify(content, filePath)
```

| Type retourné | Conditions de détection |
|---------------|------------------------|
| `decision` | contenu contient `decision:` OU `adr:` OU `on décide` |
| `bug_fix` | contenu contient `fix:` OU `bug:` OU `hotfix` OU chemin contient `fix` |
| `pattern` | contenu contient `pattern:` OU chemin contient `utils` OU `helpers` |
| `db_change` | chemin contient `migration` OU `.sql` OU contenu contient `create table` |
| `context_update` | défaut (aucune condition précédente) |

La détection est insensible à la casse (`content.toLowerCase()`).

### Structure des fichiers de mémoire

**Répertoire global :** `$CLAUDE_CONFIG_DIR/memory/global/`

| Fichier | Type de contenu | Format d'entrée |
|---------|-----------------|-----------------|
| `decisions.md` | Décisions d'architecture | `## [YYYY-MM-DD HH:MM] Décision \`fichier\`\n<snippet 400 chars>` |
| `patterns.md` | Patterns réutilisables | `### [ts] Pattern \`fichier\`\n\`\`\`\n<snippet>\n\`\`\`` |
| `errors.md` | Bugs et corrections | `### [ts] Fix \`fichier\`\n<snippet>` |

**Répertoire projet :** `$CLAUDE_CONFIG_DIR/memory/projects/<PROJECT_ID>/`

| Fichier | Contenu |
|---------|---------|
| `context.md` | Contexte projet : Stack / Dernières modifications / Décisions récentes / Blockers |

`PROJECT_ID` est auto-détecté depuis `package.json` (champ `name`), `pyproject.toml`, ou le nom du répertoire courant. Peut être surchargé via `AI_DEV_PROJECT`.

**Routage des types :**
- `decision` → `global/decisions.md` + résumé court dans `context.md` (section `## Décisions récentes`)
- `pattern` → `global/patterns.md`
- `bug_fix` → `global/errors.md`
- `context_update` → `context.md` (section `## Dernières modifications`)

### Compression automatique

`compressIfNeeded(filePath)` est appelée après chaque écriture. Seuil : **150 lignes** (`COMPRESS_THRESHOLD`).

**Comportement :**
1. Sépare les lignes d'en-tête (débutant par `#`, `>`, `<!--`, ou vides) des lignes d'entrées
2. Conserve les **120 dernières lignes d'entrées** (`KEEP_RECENT × 4 = 30 × 4`)
3. Extrait un résumé des anciennes lignes : uniquement les lignes commençant par `##` ou `- ` (25 max)
4. Archive le résumé dans `archive/<YYYY-WNN>.md` (une archive par semaine ISO)
5. Réécrit le fichier principal avec en-têtes + lien vers l'archive + lignes récentes

### Archivage hebdomadaire

```
$CLAUDE_CONFIG_DIR/memory/global/archive/<YYYY-WNN>.md
```

L'archive est en mode append : plusieurs compressions dans la même semaine s'accumulent dans le même fichier d'archive.

---

## Couche 4 : Session Memory (session-end.js Hook)

**Fichier source :** `.claude/hooks/session-end.js`

### Cycle de vie

Hook `Stop` déclenché à **chaque fin de réponse** Claude Code (pas uniquement en fin de session complète). L'état de session persiste entre les réponses via `$CLAUDE_CONFIG_DIR/logs/.session-state.json`.

**Structure du state :**
```json
{
  "sessionStart":    "2026-05-21T14:00:00.000Z",
  "responseCount":   7,
  "lastConsolidate": "2026-05-21T14:30:00.000Z",
  "lastUltralearn":  "2026-05-21T14:45:00.000Z",
  "lastDecay":       null
}
```

Les écritures JSON utilisent le pattern tmp→rename (atomique).

### Cache keep-alive (Anthropic prompt cache)

Le TTL natif du cache de prompt Anthropic est de **5 minutes (300 secondes)**. Pour suivre les gaps d'activité qui causeraient des cache miss :

- **Fichier de suivi :** `$CLAUDE_CONFIG_DIR/logs/cache-keepalive.json`
- **TTL surveillé :** `CACHE_TTL_MS = 270 000 ms` (270s, marge de 30s avant expiration)
- À chaque réponse, le timestamp est écrit dans `cache-keepalive.json`
- Si le gap depuis le dernier timestamp dépasse 270s → log dans `cache-keepalive.log` avec la durée du gap

```json
{ "ts": 1716300000000, "responseCount": 7 }
```

### Checkpoint sessions.log

À chaque réponse, une ligne est ajoutée à `$CLAUDE_CONFIG_DIR/logs/sessions.log` :
```
2026-05-21 14:32 [response #7] project=ai-dev-assistant
```

### Déclencheurs workers

Les workers sont des processus Node.js détachés (`spawn` avec `detached: true, stdio: 'ignore'`). Ils ne bloquent pas le hook.

| Worker | Déclenchement | Condition |
|--------|---------------|-----------|
| `consolidate` | Tous les 10 réponses (`responseCount % 10 === 0`) | Si `countMemoryLines() > 200` |
| `ultralearn` | Tous les 20 réponses (`responseCount % 20 === 0`) | Toujours |
| `router.js decay` | Tous les 30 réponses (`responseCount % 30 === 0`) | Si `router.js` existe |

**`countMemoryLines()`** : somme des lignes de tous les fichiers `.md` dans `$CLAUDE_CONFIG_DIR/memory/global/`.

**Workers disponibles :**
- `consolidate.js` — Résume et compacte la mémoire global
- `ultralearn.js` — Extrait des leçons des trajectoires récentes
- `cost-report.js`, `audit.js`, `dashboard.js`, `metrics.js`, etc.

### Auto-decay Thompson Sampling

Tous les 30 réponses, `router.js decay --factor 0.95` est lancé. Ce decay multiplie les paramètres Beta `α` et `β` de chaque prior par **0.95**, réduisant progressivement la confiance dans les anciennes observations. Permet d'adapter le routage à l'évolution des performances des agents.

### Webhook

Si `~/.ada.json` contient une configuration `webhook.url` et que l'événement `session.end` est dans `webhook.events`, un POST HTTP/HTTPS est envoyé avec :
```json
{ "event": "session.end", "ts": "...", "responseCount": 7, "project": "ai-dev-assistant" }
```
Timeout : 5 secondes. Toute erreur est silencieuse (ne bloque pas le hook).

---

## Couche 5 : Obsidian Vault

### Configuration (~/.ada.json)

```json
{
  "obsidian": {
    "enabled": true,
    "mode": "per-profile",
    "vaultPath": null,
    "apiPort": 27123
  }
}
```

| Champ | Type | Description |
|-------|------|-------------|
| `enabled` | boolean | Active/désactive l'écriture Obsidian |
| `mode` | `"per-profile"` \| `"unified"` | Stratégie de vault |
| `vaultPath` | string \| null | Chemin du vault pour mode `unified` |
| `apiPort` | number | Port de l'API Obsidian (non utilisé actuellement) |

### Modes

**Mode `per-profile` (défaut) :**
```
$CLAUDE_CONFIG_DIR/_obsidian/
```
Le vault est embarqué dans le répertoire du profil. Exemple pour le profil `pro` : `~/.claude-pro/_obsidian/`.

**Mode `unified` :**
```
<vaultPath>/profiles/<profile>/
```
Vault partagé entre profils, avec un sous-répertoire par profil. `<profile>` est extrait du basename de `CLAUDE_CONFIG_DIR` : `.claude-pro` → `pro`, `.claude` → `default`.

### Structure du vault

```
_obsidian/
├── README.md          — Fichier d'identification du vault
├── sessions/          — Notes de session automatiques
│   └── YYYY-MM-DD-HHhMM.md
├── daily/             — Daily notes (append)
│   └── YYYY-MM-DD.md
└── memory/            — Mémoire longue durée (réservé, future sync)
```

Le vault ne se crée pas automatiquement. Le répertoire `sessions/` doit exister pour que les notes soient écrites (protection contre l'écriture hors-vault).

### Écriture des notes de session

Déclenchée uniquement si `responseCount >= 2` (session non triviale).

**Format d'une note :**
```markdown
---
date: 2026-05-21T14:32:00.000Z
profile: pro
project: ai-dev-assistant
exchanges: 7
tags: [session, ada]
---

## 14h32 — ai-dev-assistant

| Champ | Valeur |
|---|---|
| Profil | pro |
| Échanges | 7 |
| Début | 2026-05-21T14:00:00.000Z |

<!-- Annotations -->
```

L'écriture est atomique (tmp → rename). Le nom de fichier est `YYYY-MM-DD-HHhMM.md`.

### Daily notes

Pour chaque note de session, une ligne est ajoutée (append) à `daily/YYYY-MM-DD.md` :
```
- 14h32 [[sessions/2026-05-21-14h32|ai-dev-assistant]] (7 échanges)
```

### Intégration UI

**API :** `GET /api/obsidian/status?profile=<name>`

Réponses possibles :
```json
{ "enabled": false }
// obsidian désactivé dans ~/.ada.json

{ "enabled": true, "initialized": false }
// activé mais vault non initialisé (répertoire absent)

{
  "enabled": true,
  "initialized": true,
  "vaultName": "_obsidian",
  "vaultDir": "/Users/x/.claude-pro/_obsidian",
  "uri": "obsidian://open?vault=_obsidian",
  "sessionCount": 42
}
```

`POST /api/obsidian/status` avec `{ "enabled": boolean }` pour activer/désactiver.

---

## Couche 6 : Mémoire Contextuelle Claude (MEMORY.md + fichiers .md)

### Emplacement et structure

**Fichier d'index :** `~/.claude-pro/projects/-Users-jonathanarms-Documents-ARMS-projects-AI-Dev-Assistant/memory/MEMORY.md`

Format : liste de liens Markdown vers des fichiers de détail.
```markdown
- [titre court](fichier.md) — description courte et date
```

**Fichiers de détail :** dans le même répertoire, chaque thème a son propre `.md` avec le contenu développé (ex: `project_ada_cli_install.md`, `project_ada_interface.md`).

**Mémoire contextuelle projet :** `.claude/memory/context.md` — lu directement par Claude Code via `CLAUDE.md` (inject dans le contexte de chaque session).

### Types de mémoire contextuelle

| Type | Emplacement | Description |
|------|-------------|-------------|
| `user` | `MEMORY.md` | Préférences, habitudes, décisions répétées |
| `feedback` | `MEMORY.md` | Retours sur les réponses passées |
| `project` | `MEMORY.md` + fichiers `.md` | Connaissances techniques du projet |
| `reference` | `context.md` | Stack, décisions d'architecture, blockers |

### Cycle de vie et expiration

Il n'y a pas d'expiration automatique de `MEMORY.md` — c'est une mémoire manuelle ou gérée par le worker `ultralearn`. Les entrées dans `context.md` sont mises à jour par le hook `memory-manager.js` (sections `## Dernières modifications` et `## Décisions récentes`).

La compression du hook (couche 3) protège `context.md` de la croissance illimitée : au-delà de 150 lignes, les anciennes entrées sont archivées.

---

## Couche 7 — HNSW Vector Bank (v7.0.0)

Couche vectorielle persistante superposée à SQLite (Couche 1). Opère en parallèle du ReasoningBank.

```
bank.store(phase, agent, verdict, summary)
     │
     ├── SQLite (bank.db)          ← source of truth, queryable
     │
     └── HNSW Insert               ← async, non-bloquant
           │
           ├── _getOrLoadHNSW()    ← charge bank-hnsw.json si présent
           ├── embedTokenize(text) ← tokenisation : lowercase + alphanum
           ├── vocab expand        ← _hnswVocab[] + _hnswVocabSet (O(1))
           ├── _toHNSWVector()     ← TF-IDF dense sur vocab partagé
           └── debounce 5s → _persistHNSW() → bank-hnsw.json (atomic)
```

### SmartRetrieval — ACW v2

Pipeline injecté avant chaque spawn agent dans `run.js` :

```
taskDescription (label de la phase)
     │
     ├── bank.retrieve(query, {limit:10})    ← SQLite TF-IDF + BM25 re-rank
     │         │
     │         └── RETRIEVE_CAP=500          ← hard cap anti-O(n²)
     │
     ├── expandQuery(query, {maxVariants:3}) ← 3 reformulations BM25
     │
     ├── searchBM25(variant_i, summaries)    ← BM25 scoring × 3
     │
     ├── reciprocalRankFusion(lists, k=60)   ← fusion + boost recency
     │
     └── maximalMarginalRelevance(λ=0.6)     ← top-5 diversifiés
                   │
                   └── phase.acwContext      ← injecté dans le prompt
```

### Auto-Banking (session-end.js)

Protection contre la perte de trajectoires :

```
[Hook Stop — chaque réponse Claude Code]
     │
     └── scan coordinator/runs/
               │
               └── run actif (status='running', activePhase≠null)
                         │
                         └── phases completed non bankées (max 3)
                                   │
                                   ├── bank.store() avec retry backoff
                                   │     tentative 1: immédiat
                                   │     tentative 2: +200ms
                                   │     tentative 3: +800ms
                                   │
                                   └── state.bankedPhases[runKey:phaseId] = ts
```

---

## Flux de données complet

```
┌─────────────────────────────────────────────────────────────────────────┐
│  ÉVÉNEMENT : Claude Code écrit un fichier (Write/Edit)                  │
└──────────────────────────┬──────────────────────────────────────────────┘
                           │ PostToolUse hook
                           ▼
              memory-manager.js
              ├── classify(content, filePath)
              │     decision → global/decisions.md
              │     bug_fix  → global/errors.md
              │     pattern  → global/patterns.md
              │     default  → projects/<ID>/context.md
              └── compressIfNeeded() → archive/<YYYY-WNN>.md

┌─────────────────────────────────────────────────────────────────────────┐
│  ÉVÉNEMENT : Claude Code termine une réponse (Stop)                     │
└──────────────────────────┬──────────────────────────────────────────────┘
                           │ Stop hook
                           ▼
              session-end.js
              ├── +1 responseCount → .session-state.json
              ├── updateCacheTimestamp() → cache-keepalive.json
              ├── append → logs/sessions.log
              ├── [/10 + memLines > 200] spawn consolidate.js
              ├── [/20]                  spawn ultralearn.js
              ├── [/30]                  spawn router.js decay
              ├── [>= 2 échanges]        writeObsidianNote()
              │     sessions/YYYY-MM-DD-HHhMM.md  (atomic)
              │     daily/YYYY-MM-DD.md            (append)
              └── dispatchWebhook('session.end')

┌─────────────────────────────────────────────────────────────────────────┐
│  UTILISATION : Coordinator route un run vers des agents                 │
└──────────────────────────┬──────────────────────────────────────────────┘
                           │ Appelé par run.js
                           ▼
              graph-builder.js (loadOrBuild, cache 1h)
              ├── SQLite bank.db  →  graph.aggregate() × N
              │   (ou bank-state.json si pas de DB)
              ├── pipelines.json  →  arêtes PRÉCÈDE
              └── KnowledgeGraph.scoreHybrid(agent, phase, pageRank)
                  → score ∈ [0, 1] pour le routage

┌─────────────────────────────────────────────────────────────────────────┐
│  UTILISATION : UI affiche le Memory Graph                               │
└──────────────────────────┬──────────────────────────────────────────────┘
                           │ GET /api/memory?profile=<name>
                           ▼
              readMemoryGraph()
              ├── router-state.json   → nœuds agent + phase + liens
              ├── micro-lessons.json  → nœuds lesson (max 60)
              └── memory-{store}.json → nœuds mem:store:N (max 15/store)
                  (episodic, semantic, procedural)
```

---

## Chemins de fichiers de référence

| Fichier | Rôle | Couche |
|---------|------|--------|
| `~/.claude-pro/coordinator/memory-episodic.json` | Store épisodique (TTL 7j) | 1 |
| `~/.claude-pro/coordinator/memory-semantic.json` | Store sémantique (permanent) | 1 |
| `~/.claude-pro/coordinator/memory-procedural.json` | Store procédural (boost usage) | 1 |
| `~/.claude-pro/coordinator/graph-state.json` | KnowledgeGraph persisté (cache 1h) | 2 |
| `~/.claude-pro/coordinator/bank-state.json` | Trajectoires JSON (fallback SQLite) | 2 |
| `~/.claude-pro/coordinator/bank.db` | Trajectoires SQLite (source primaire) | 2 |
| `~/.claude-pro/coordinator/pipelines.json` | Définitions des pipelines DAG | 2 |
| `~/.claude-pro/coordinator/router-state.json` | Priors Thompson Sampling | 2, UI |
| `~/.claude-pro/coordinator/micro-lessons.json` | Micro-leçons extraites | UI |
| `~/.claude-pro/memory/global/decisions.md` | Décisions d'architecture | 3 |
| `~/.claude-pro/memory/global/patterns.md` | Patterns réutilisables | 3 |
| `~/.claude-pro/memory/global/errors.md` | Bugs et corrections | 3 |
| `~/.claude-pro/memory/global/archive/<YYYY-WNN>.md` | Archives hebdomadaires | 3 |
| `~/.claude-pro/memory/projects/<ID>/context.md` | Contexte projet courant | 3 |
| `~/.claude-pro/logs/.session-state.json` | State de session (responseCount, etc.) | 4 |
| `~/.claude-pro/logs/sessions.log` | Journal des réponses | 4 |
| `~/.claude-pro/logs/cache-keepalive.json` | Timestamp dernier keepalive cache | 4 |
| `~/.claude-pro/logs/cache-keepalive.log` | Log des cache miss détectés | 4 |
| `~/.claude-pro/logs/workers.log` | Log des dispatches workers | 4 |
| `~/.ada.json` | Configuration globale ADA (obsidian, webhook, schedules) | 4, 5 |
| `~/.claude-pro/_obsidian/sessions/*.md` | Notes de session Obsidian | 5 |
| `~/.claude-pro/_obsidian/daily/*.md` | Daily notes Obsidian | 5 |
| `~/.claude-pro/projects/<project-hash>/memory/MEMORY.md` | Index mémoire Claude | 6 |
| `.claude/memory/context.md` | Contexte projet (lu par CLAUDE.md) | 6 |
| `ada-ui/lib/ada-fs.ts` | Fonctions de lecture UI (readMemoryGraph, etc.) | UI |
| `ada-ui/app/api/memory/route.ts` | API REST mémoire | UI |
| `ada-ui/app/api/obsidian/status/route.ts` | API REST Obsidian | UI |

> **Note :** `~/.claude-pro/` correspond à `$CLAUDE_CONFIG_DIR` pour le profil `pro`. Pour le profil par défaut, remplacer par `~/.claude/`.

---

## Diagnostics et debug

### Couche 1 — Typed Memory

```bash
# Voir le contenu des 3 stores
cat ~/.claude-pro/coordinator/memory-episodic.json | python3 -m json.tool | head -50
cat ~/.claude-pro/coordinator/memory-semantic.json | python3 -m json.tool | head -50
cat ~/.claude-pro/coordinator/memory-procedural.json | python3 -m json.tool | head -50

# Compter les entrées
node .claude/coordinator/typed-memory.js stats

# Tester une recherche
node .claude/coordinator/typed-memory.js retrieve "migration PostgreSQL" --limit 10

# Purger les entrées expirées
node .claude/coordinator/typed-memory.js expire

# Stocker une entrée manuellement
node .claude/coordinator/typed-memory.js store semantic "NestJS guards" "Les guards NestJS s'appliquent avant les interceptors"
```

### Couche 2 — KnowledgeGraph

```bash
# Reconstruire le graphe depuis toutes les sources
CLAUDE_CONFIG_DIR=~/.claude-pro node .claude/coordinator/graph-builder.js build

# Statistiques du graphe courant
CLAUDE_CONFIG_DIR=~/.claude-pro node .claude/coordinator/graph-builder.js stats

# Afficher les nœuds et arêtes en JSON
CLAUDE_CONFIG_DIR=~/.claude-pro node .claude/coordinator/graph-memory.js graph | python3 -m json.tool

# Vérifier les scores d'un agent
node -e "
const { KnowledgeGraph } = require('./.claude/coordinator/graph-memory.js')
const { loadGraph } = require('./.claude/coordinator/graph-builder.js')
const g = loadGraph(process.env.HOME + '/.claude-pro/coordinator/graph-state.json')
console.log('Score nestjs/implement:', g.scoreAgentPhase('nestjs', 'implement'))
const pr = g.pageRank()
console.log('Hybrid nestjs/implement:', g.scoreHybrid('nestjs', 'implement', pr))
"
```

### Couche 3 — Memory Manager

```bash
# Voir les décisions enregistrées
cat ~/.claude-pro/memory/global/decisions.md

# Voir les patterns
cat ~/.claude-pro/memory/global/patterns.md

# Voir les erreurs/bugs
cat ~/.claude-pro/memory/global/errors.md

# Voir le contexte projet
cat ~/.claude-pro/memory/projects/ai-dev-assistant/context.md

# Tester le hook manuellement
echo '{"tool_input":{"path":"test.ts","content":"decision: utiliser NestJS guards pour la gestion des rôles"},"tool_result":""}' | \
  CLAUDE_CONFIG_DIR=~/.claude-pro node .claude/hooks/memory-manager.js

# Voir les erreurs du hook
cat ~/.claude-pro/memory/hook.log
```

### Couche 4 — Session End

```bash
# État de session courant
cat ~/.claude-pro/logs/.session-state.json | python3 -m json.tool

# Journal des sessions
tail -20 ~/.claude-pro/logs/sessions.log

# Détections de cache miss
cat ~/.claude-pro/logs/cache-keepalive.log

# Journal des workers
tail -20 ~/.claude-pro/logs/workers.log

# Tester le hook
echo '{}' | CLAUDE_CONFIG_DIR=~/.claude-pro node .claude/hooks/session-end.js
```

### Couche 5 — Obsidian

```bash
# Vérifier la config
cat ~/.ada.json | python3 -m json.tool

# Lister les notes de session
ls -la ~/.claude-pro/_obsidian/sessions/

# Voir la dernière note
ls -t ~/.claude-pro/_obsidian/sessions/*.md | head -1 | xargs cat

# API UI (si ada-ui tourne)
curl http://localhost:3000/api/obsidian/status?profile=pro | python3 -m json.tool

# Activer Obsidian via API
curl -X POST http://localhost:3000/api/obsidian/status \
  -H 'Content-Type: application/json' \
  -d '{"enabled": true}'
```

### Couche 6 — Mémoire Contextuelle

```bash
# Voir la mémoire contextuelle projet
cat .claude/memory/context.md

# Voir l'index mémoire Claude
# (chemin basé sur le hash du projet, peut varier)
ls ~/.claude-pro/projects/*/memory/MEMORY.md

# API mémoire UI
curl "http://localhost:3000/api/memory?profile=pro" | python3 -m json.tool
```

---

## Limitations connues et points d'attention

### Bug : readMemoryGraph — stores typés invisibles dans l'UI

**Fichier :** `ada-ui/lib/ada-fs.ts`, fonction `readMemoryGraph`, ligne ~812.

**Symptôme :** les nœuds des stores épisodique/sémantique/procédural n'apparaissent pas dans le graphe UI, même quand les fichiers `memory-*.json` contiennent des données.

**Cause :** le code lit correctement le fichier JSON, mais la condition sur `i.summary` ou `i.content` n'est jamais vraie pour les entrées issues de `typed-memory.js`, qui utilisent le champ `key` et `content` (et non `summary`).

```typescript
// Code actuel (ligne ~818) :
const summary = typeof i.summary === 'string'
  ? i.summary
  : typeof i.content === 'string'
    ? i.content
    : ''
```

En pratique, `i.content` existe bien sur les entrées typées, mais le rendu de `summary.slice(0, 60)` est correct. Le vrai problème est que `const items = Array.isArray(storeRaw) ? storeRaw : []` fonctionne **si** `memory-episodic.json` contient un array direct — ce qui est le format effectif de `typed-memory.js` (`saveStore` écrit un array). Le bug peut donc être environnemental (fichier absent ou vide plutôt que malformé).

**Vérification :** `cat ~/.claude-pro/coordinator/memory-episodic.json | python3 -c "import json,sys; d=json.load(sys.stdin); print(type(d), len(d) if isinstance(d, list) else 'not-array')"`.

### Couplage fort : CLAUDE_CONFIG_DIR

`typed-memory.js` utilise `~/.claude-pro` (via `CLAUDE_CONFIG_DIR` ou fallback `HOME + '/.claude-pro'`) tandis que `graph-memory.js` en CLI utilise `~/.claude` comme défaut. Ce désentrelacement cause des confusions si la variable d'environnement n'est pas positionnée lors des appels directs.

**Fix temporaire :** toujours préfixer `CLAUDE_CONFIG_DIR=~/.claude-pro` pour les appels manuels.

### Écriture Obsidian conditionnelle au répertoire sessions/

Si `~/.claude-pro/_obsidian/sessions/` n'existe pas, `writeObsidianNote` quitte silencieusement sans créer de note ni le répertoire. C'est voulu (protection contre les vaults non initialisés), mais peut surprendre après un déplacement ou suppression accidentelle du répertoire.

**Fix :** recréer manuellement `mkdir -p ~/.claude-pro/_obsidian/sessions/`.

### Double lecture ~/.ada.json dans l'UI

`ada-fs.ts` et `route.ts` (obsidian/status) résolvent `resolveVaultDir` de manière légèrement différente. Dans `route.ts`, la résolution per-profile utilise `.claude-<profile>` basé sur le paramètre de requête, tandis que `session-end.js` l'extrait du basename de `CLAUDE_CONFIG_DIR`. Ils donnent le même résultat en pratique mais la logique est dupliquée.

### Thompson Sampling decay non conditionné

Le decay `router.js decay --factor 0.95` est lancé tous les 30 réponses **sans condition** (même si aucune exécution d'agent n'a eu lieu). Dans les sessions d'édition pure (sans runs), les priors vont se dégrader inutilement.

### Fenêtre CO_OCCURRENCE non temporelle

La détection de co-occurrence dans `graph-builder.js` utilise une fenêtre de **5 trajectoires consécutives** dans l'ordre de chargement du fichier, pas une fenêtre temporelle. Si `bank-state.json` n'est pas trié par timestamp, les co-occurrences peuvent être inexactes.

### Timeout hook 3 secondes

Les hooks `memory-manager.js` et `session-end.js` s'auto-terminent après 3 secondes via `setTimeout(() => process.exit(0), 3000)`. Si le système de fichiers est lent (NFS, chiffrement, disque plein), des entrées peuvent être perdues silencieusement.

### Cache graph-state.json non invalidé

`loadOrBuild` invalide le cache après **1 heure**. Si `bank.db` reçoit de nouvelles trajectoires dans la fenêtre d'une heure, le graphe en mémoire (et l'UI) affichent des données obsolètes jusqu'à la prochaine expiration.

**Forcer le rebuild :** `rm ~/.claude-pro/coordinator/graph-state.json`.
