# AI Dev Assistant — ADA v6

> Assistant de développement IA construit sur Claude Code — le levier mesuré est le **tier-routing de modèles** (Haiku/Sonnet/Opus selon la complexité de la tâche) et la **mémoire de conventions projet** (ReasoningBank : recall des patterns et pièges déjà rencontrés sur le repo). S'appuie sur un catalogue de **131 agents spécialisés** (59 ADA + 72 Ruflo) et 250 skills pour couvrir un large éventail de stacks, 30 profils de routing, SmartRetrieval ACW v2, HNSW persistant, daemon worker scheduler, et un SaaS Builder qui scaffolde un projet complet en une commande.

---

## Vue d'ensemble

**AI Dev Assistant (ADA)** transforme votre terminal en une équipe coordonnée d'agents IA bâtie sur [Claude Code](https://docs.anthropic.com/en/docs/claude-code). Chaque agent est un spécialiste avec son propre contexte, ses conventions et ses règles — orchestrés automatiquement selon la tâche, avec apprentissage adaptatif par Thompson Sampling.

**Stack par défaut :** NestJS 10 · Next.js 15 · PostgreSQL 15 · Prisma · Redis

### Chiffres clés

| Composant | Quantité |
|-----------|----------|
| Agents spécialisés | **131** (59 ADA natifs + 72 Ruflo) |
| Skills (recettes prêtes à l'emploi) | 250 |
| Slash commands | 18 (12 dev + 6 SaaS Builder) |
| Hooks Claude Code | 7 (PreToolUse · PostToolUse · Stop) |
| Team profiles | **30** (15 natifs + 15 Ruflo dérivés) |
| MCP servers supportés | 15 |
| Features intelligence v7 | 14 F1–F14 + SmartRetrieval + HNSW + Daemon |
| Workers background | 12 (scheduler automatique) |

### Benchmark v7

| Dimension | ADA v6 | ADA v7 | Ruflo |
|-----------|--------|--------|-------|
| Score global | 6.1/10 | **8.2/10** | 9.1/10 |
| Retrieval qualité | 4.2 | **7.8** | 8.9 |
| Routing intelligence | 8.1 | **8.1** | 7.4 |
| Agent catalogue | 5.2 | **8.3** | 9.0 |
| Robustesse production | 4.5 | **6.0** | 8.7 |
| Déploiement | 8.2 | **8.4** | 6.8 |

---

## Nouveautés v6

### Sprint S14 — Sécurité (7 correctifs)
- `safeCompare` constant-time (length oracle corrigé)
- IPv6 bracket bypass dans le SSRF guard webhook
- Guard `req.json()` sur profile-types, `isProfileError` sur memory route
- Pipelines `.max(50)` phases, MCP env limits (50 vars / 4096 chars)
- `tmpName` validation dans plugins.js

### Sprint S15 — Intelligence adaptative
- **F2 Adaptive Context Window** — HNSW k-NN, top-5 trajectoires injectées en YAML
- **F4 Smart Retry Diagnostic** — trajectoires d'échec injectées au retry via bank
- **F10 Budget Guard** — circuit-breaker `warn|stop|downgrade_tier`
- **F12 Predictive Estimator** — tableau pré-run (coût/durée/succès estimés)

### Sprint S16 — Cache et multi-provider
- **F1 Prompt Cache Optimizer** — `cache_control: {type:"ephemeral"}` sur blocs stables, $2.70/1M tokens économisés
- **F5 Multi-Provider Gateway** — Anthropic → OpenAI → DeepSeek → Ollama, circuit breaker (3 fails → open, 5 min → half-open)

### Sprint S17 — Collaboration et observabilité
- **F3 PR Autopilot** — création PR GitHub automatique (`GITHUB_TOKEN`), monitoring CI check-runs
- **F6 Team Sync** — sync git-based des priors Thompson, merge `alpha_merged = alpha_local + alpha_remote - 1`
- **F7 Observability Dashboard** — SVG charts, win-rates Thompson, timeline coûts 14 jours

### Sprint S18 — Éditeur, fédération et marketplace
- **F8 Pipeline Composer** — éditeur visuel DAG HTML5 drag-and-drop, détection cycles DFS
- **F13 Federation mTLS** — échange P2P de trajectoires, `requestCert: true`, bind `127.0.0.1`
- **F14 Skill Marketplace** — installation SHA256-verified, jail path traversal, cache TTL 1 h

### Sprint S19 — Intégration Ruflo (v7.0.0)
- **SmartRetrieval ACW v2** — `expandQuery` → BM25×3 → `reciprocalRankFusion(k=60,recency)` → `maximalMarginalRelevance(λ=0.6)` — diversité et recency dans les trajectoires injectées
- **HNSW persistant** — graphe vectoriel `bank-hnsw.json` construit incrémentalement à chaque `store()` ; `hnswSearch(query, k)` API directe
- **Auto-banking session-end** — trajectoires sauvegardées automatiquement à chaque Stop Claude Code, retry backoff×3
- **Daemon Worker Scheduler** — 12 workers tournent automatiquement (ultralearn/6h · consolidate/2h · audit/24h · cve-scan/72h)
- **131 agents** — 72 agents Ruflo intégrés (coordinator, memory, benchmark, sona, github, ml, security, dev, infra)
- **30 profils de routing** — 15 profils Ruflo dérivés (swarm-coordinator, benchmark, sona-optimizer, sparc-coder, github-ops, consensus, ml-agent, goal-planner, memory-swarm, pair-dev, graph-analysis, meta-agent, security-neural, release-ops, fintech)
- **7 nouvelles commandes CLI** — `ada daemon`, `ada memory search/hnsw/stats`, `ada agents list/search`, `ada bank hnsw`

### Sprint S19 — Stabilité P1 (v7.0.1)
- `_hnswVocabSet` (Set) : O(1) lookups vocab — élimine O(n) `includes()` sur vocab croissant
- `RETRIEVE_CAP=500` : borne l'HNSW rebuild O(n²) dans `bank.retrieve()`
- Timeout 2s ACW : skip injection si SQLite lent, phases non bloquées
- Retry backoff (×3) sur `bank.store()` auto-banking + log persistant
- `_gracefulShutdown()` : drain timers + 2s grâce — plus de workers zombies
- Validation schedule : whitelist workers + intervalle [1min, 7j]

---

## Installation rapide

> Installation côté client (licencié) : voir le guide dédié
> **[docs/INSTALL-CLIENT.md](docs/INSTALL-CLIENT.md)**.

```bash
git clone <url-du-depot>   ADA
cd ADA
bash install.sh
```

L'installeur crée un profil `~/.claude-ada` s'il n'en existe aucun, installe les
agents et le coordinateur, pose la commande `ada`, puis lance un diagnostic.

**Ne déplacez pas le dossier cloné après l'installation** : la commande `ada` est
un lien symbolique qui pointe dessus.

**Options :**
```bash
bash install.sh --help                  # toutes les options
bash install.sh --profile claude-pro    # profil nommé (créé s'il n'existe pas)
bash install.sh --all                   # tous les profils ~/.claude-*/ détectés
bash install.sh --non-interactive       # provisioning automatisé
bash install.sh --with-server           # installe aussi ada-api
```

**Vérification :**
```bash
ada --version   # version du dépôt + version installée dans le profil
ada doctor      # doit afficher « Tout est OK »
```

---

## Prérequis

| Outil | Version | Installation |
|-------|---------|-------------|
| Node.js | **>= 22** (bloquant) | [nodejs.org](https://nodejs.org) · `nvm install 22` |
| Claude Code CLI | Latest | `npm i -g @anthropic-ai/claude-code` |
| git | >= 2.30 | [git-scm.com](https://git-scm.com) |
| tmux | >= 3.0 (agents en équipe) | `brew install tmux` / `apt install tmux` |

Accès LLM en BYOK : clé `ANTHROPIC_API_KEY` (`ada provider set api`) ou compte
Claude.ai (`ada provider set claude-code`). Aucun crédit LLM n'est fourni avec
ADA. macOS et Linux ; Windows via WSL2 uniquement.

---

## SaaS Builder

Le SaaS Builder génère un projet SaaS complet from scratch en une commande. Il orchestrate automatiquement les 24 agents pour produire la structure, le schéma DB, l'auth, le billing et le CI/CD selon le mode choisi.

### Démarrage rapide

```bash
# Scaffolde un SaaS complet (interview interactive)
/saas-init mon-saas

# Mode explicite
/saas-init mon-saas --mode full --billing stripe

# Ajouter auth sur un projet existant
/saas-auth --provider supabase

# Ajouter Stripe Subscriptions
/saas-billing --plans free,starter,pro --trial 14

# Ajouter une feature métier avec contexte SaaS
/saas-feature invoice-management
/saas-feature analytics --plan-gate starter

# CI/CD + monitoring
/saas-deploy --target railway

# Audit sécurité SaaS
/saas-audit --focus all
```

### 3 modes de déploiement

| Mode | Périmètre | Temps estimé | Usage |
|------|-----------|-------------|-------|
| `minimal` | API + Auth + DB | ~25 min | Valider avant d'investir |
| `core` | + Dashboard + Settings + Onboarding | ~45 min | Bêta-testeurs |
| `full` | + Billing Stripe + CI/CD + Monitoring | ~70 min | Lancement public |

### Ce que chaque mode produit

**Structure commune (tous modes) :**
```
apps/
  api/        — NestJS 10 (port 3001)
  web/        — Next.js 15 (port 3000)
packages/
  shared/     — Types TypeScript partagés
docker-compose.yml
.env.example  — Variables documentées
Makefile      — make dev · make db-migrate · make test
```

**DB migrations :**
- `001_saas_foundation.sql` — workspaces, users, workspace_members, invitations + RLS
- `002_billing.sql` — subscriptions, invoices, plan_limits (mode core/full avec Stripe)

**Guards disponibles après /saas-init :**
- `WorkspaceGuard` — isole chaque requête dans le workspace du JWT
- `WorkspaceMemberGuard` + `@WorkspaceRoles('admin')` — contrôle des rôles
- `PlanGuard` + `@RequiresPlan('starter')` — gates de fonctionnalités premium

---

## Commandes de développement

### Slash commands

| Commande | Description |
|----------|-------------|
| `/feature <n>` | Scaffolde une feature complète (DB + backend + frontend + tests) |
| `/saas-init <n>` | Bootstrap un SaaS complet from scratch |
| `/saas-auth` | Ajoute auth + multi-tenant sur un projet existant |
| `/saas-billing` | Ajoute Stripe Subscriptions |
| `/saas-feature <n>` | Feature métier avec contexte SaaS (workspace, guards, plans) |
| `/saas-deploy` | CI/CD + monitoring + checklist launch |
| `/saas-audit` | Audit sécurité SaaS (IDOR, RLS, billing, API) |
| `/review` | Code review du diff courant — verdict ✅/⚠️/❌ |
| `ada schedule list` | Liste les pipelines planifiés |
| `ada schedule add <pipeline> "<cron>"` | Ajoute un pipeline planifié |
| `ada schedule remove <id>` | Supprime un schedule |
| `ada schedule toggle <id>` | Active/désactive un schedule |
| `ada profile push <url>` | Push du profil actif vers un repo git |
| `ada profile pull <url>` | Pull/clone d'un profil depuis un repo git |
| `ada run <pipeline> --retry` | Réessaye les phases échouées d'un run |
| `ada daemon start\|stop\|status\|run <w>` | Contrôle le scheduler de workers background |
| `ada memory search <query>` | SmartRetrieval : expandQuery→BM25→RRF→MMR |
| `ada memory hnsw <query>` | Recherche vectorielle HNSW directe |
| `ada memory stats` | Compte trajectoires + état HNSW |
| `ada agents list [--category <cat>]` | Catalogue des 131 agents par catégorie |
| `ada agents search <query>` | Grep multicritère nom/titre/description |
| `ada bank hnsw <query>` | Alias `hnswSearch` |
| `/deploy <env>` | Docker build → push ghcr.io → deploy |
| `/push-staging` | Review → PR → auto-merge vers staging |
| `/revert-staging` | Rollback du dernier merge staging |
| `/test` | Tests avec rapport de couverture |
| `/db-migrate <desc>` | Générer + appliquer une migration SQL |
| `/summarize` | Archiver la session en mémoire long-terme |
| `/compact` | Compression manuelle du contexte (~95% tokens économisés) |
| `/team <profil>` | Changer de profil d'agents sans réinstaller |

### Workflow quotidien

```bash
# Matin
dev-ai mon-projet
claude-perso
/fetch-sprint    # charger le sprint depuis Linear/GitHub
/memory show     # revoir le contexte

# Développement
/feature user-auth
/saas-feature invoice-management --plan-gate starter
/test
/review

# Merge
/push-staging
/deploy staging

# Fin de journée
/summarize
```

---

## Features Intelligence — v7

### F1–F14 (héritage v6)

| ID | Nom | Description |
|----|-----|-------------|
| F1 | Prompt Cache Optimizer | Inject `cache_control: ephemeral` sur blocs stables — tracking savings Anthropic |
| F2 | Adaptive Context Window | HNSW k-NN top-5 trajectoires → YAML injecté dans le prompt |
| F3 | PR Autopilot | Création PR GitHub automatique + monitoring CI check-runs |
| F4 | Smart Retry Diagnostic | Trajectoires d'échec injectées au retry pour guider la correction |
| F5 | Multi-Provider Gateway | Anthropic → OpenAI → DeepSeek → Ollama avec circuit breaker |
| F6 | Team Sync | Sync git-based des priors Thompson entre équipes |
| F7 | Observability Dashboard | SVG charts : win-rates, timeline coûts 14 j, alertes budget |
| F8 | Pipeline Composer | Éditeur visuel DAG HTML5 drag-and-drop, détection cycles DFS |
| F10 | Budget Guard | Circuit-breaker budgétaire par run/session/day (`warn\|stop\|downgrade_tier`) |
| F12 | Predictive Estimator | Tableau pré-run : coût estimé, durée, taux de succès historique |
| F13 | Federation mTLS | Échange P2P de trajectoires via TLS mutuel, bind `127.0.0.1` par défaut |
| F14 | Skill Marketplace | Installation SHA256-verified, jail path traversal, cache TTL 1 h |

### Nouvelles features v7 (Sprint Ruflo)

| ID | Nom | Description |
|----|-----|-------------|
| F15 | SmartRetrieval ACW v2 | `expandQuery → BM25×3 → RRF(k=60,recency) → MMR(λ=0.6)` — diversité + recency dans l'ACW |
| F16 | HNSW Persistant | Graphe vectoriel `bank-hnsw.json` incrémental, `hnswSearch()` API directe |
| F17 | Auto-Banking Session-End | Sauvegarde trajectoires à chaque Stop Claude Code, retry backoff×3 |
| F18 | Daemon Worker Scheduler | 12 workers tournent automatiquement, schedule configurable, graceful shutdown |
| F19 | Multi-Profile Bridge | `ada-bridge.js send/share-lessons` — fédération JSON inter-profils |

---

## ADA UI — Dashboard v2

Interface web Next.js 15 pour piloter ADA depuis le navigateur. Démarrée via `ada start`, accessible sur le port **3000** par défaut.

### Pages disponibles

| Route | Description |
|-------|-------------|
| `/dashboard` | Vue globale — runs récents, widget coût, état du système |
| `/auth` | Configuration auth Claude |
| `/agents` | Liste des agents avec hot-reload |
| `/teams` | Equipes et compositions |
| `/profile-types` | Types de profils de routing |
| `/pipelines` | Pipelines déclaratifs + timeline des phases |
| `/connectors` | Registre MCP — catalogue 15 serveurs, toggle enable/disable |
| `/schedules` | Planification cron des pipelines (CRUD + toggle) |
| `/audit` | Journal d'audit NDJSON, auto-refresh 30s |
| `/settings` | Config webhook + paramètres |

### Commandes

```bash
ada start          # démarre ada-ui en arrière-plan (port 3000)
ada open           # ouvre dans le navigateur
ada stop           # arrête le serveur
```

---

## Routing automatique

### Profils natifs ADA

| Prompt contient | Profil | Agents actifs |
|-----------------|--------|---------------|
| `nestjs + next` | fullstack | nestjs · nextjs · db |
| `drf + next` | fullstack-drf | drf · nextjs · db |
| `frontend / next / react / ui` | frontend | nextjs · ux-designer · reviewer |
| `nestjs` seul | backend-nestjs | nestjs · db · tester |
| `drf / django / python` | backend-drf | drf · db · tester |
| `react native / expo` | mobile-rn | react-native · api-designer · reviewer |
| `android / swift / ios` | mobile-native | android · swift · api-designer |
| `docker / deploy / ci` | devops | devops · security-auditor · reviewer |
| `review / audit / perf` | review | reviewer · security-auditor · performance-analyst |
| `architecture / conception` | strategy | feature-architect · devils-advocate · api-designer |
| `ux / wireframe / design` | design | ux-designer · technical-architect · data-modeler |
| `db / sql / migration` | data | data-modeler · db · migration-strategist |
| `nouveau projet` | onboarding | onboarding-agent · feature-architect · technical-architect |
| `saas / bootstrap / startup` | saas-builder | technical-architect · db · devops |
| `llm / openai / langgraph / agent` | ai-engineer | ai-engineer · agent-architect · memory-engineer |
| `fastapi / async / sse / otel` | ai-backend | python-backend · ai-engineer · observability-engineer |
| `llama / ollama / whisper / tts` | ai-infra | ml-ops · perception-engineer · observability-engineer |
| `sandbox / code execution / ast` | ai-security | sandbox-security · security-auditor · observability-engineer |

### Profils Ruflo dérivés (v7.0.0)

| Prompt contient | Profil | Agents actifs |
|-----------------|--------|---------------|
| `swarm / coordinator / hive / topology` | swarm-coordinator | agent-adaptive-coordinator · agent-queen-coordinator · agent-hierarchical-coordinator |
| `benchmark / performance test / load test` | benchmark | agent-benchmark-suite · agent-performance-benchmarker · agent-performance-optimizer |
| `sona / learning optimizer / pattern learning` | sona-optimizer | agent-sona-learning-optimizer · agentdb-learning · agent-memory-coordinator |
| `coder / implementer / sparc` | sparc-coder | agent-coder · agent-implementer-sparc-coder · agent-tdd-london-swarm |
| `github / pr / release / workflow` | github-ops | agent-github-pr-manager · agent-ops-cicd-github · agent-release-manager |
| `consensus / raft / byzantine / distributed` | consensus | agent-byzantine-coordinator · agent-raft-manager · agent-consensus-coordinator |
| `neural network / ml model / trading` | ml-agent | agent-neural-network · agent-data-ml-model · agent-trading-predictor |
| `goal planner / code goal / decomposition` | goal-planner | agent-goal-planner · agent-code-goal-planner · agent-planner |
| `swarm memory / agentdb / vector search` | memory-swarm | agent-swarm-memory-manager · agentdb-vector-search · agentdb-advanced |
| `pair programming / collaboration` | pair-dev | pair-programming · agent-coder · agent-code-review-swarm |
| `pagerank / graph analysis / matrix` | graph-analysis | agent-pagerank-analyzer · agent-matrix-optimizer · agent-performance-analyzer |
| `skill builder / agent builder / meta-agent` | meta-agent | skill-builder · agent-researcher · agent-arch-system-design |
| `security neural / safla / v3 security` | security-neural | agent-security-manager · agent-safla-neural · agent-v3-security-architect |
| `release / deployment / multi-repo` | release-ops | agent-release-manager · agent-release-swarm · agent-repo-architect |
| `payments / agentic payments / fintech` | fintech | agent-agentic-payments · agent-payments · agent-trading-predictor |

---

## Agents et Skills

### Groupe Core Dev — 104 skills

| Agent | Skills | Description |
|-------|--------|-------------|
| `orchestrator` | 5 | Routing, délégation, consolidation, handoff session |
| `nestjs` | 19 | Modules, guards, intercepteurs, queues, Stripe, workspace guards, plan guards |
| `drf` | 15 | ViewSets, serializers, Celery, permissions, filtres, webhooks |
| `nextjs` | 20 | App Router, forms, auth, dashboard, pricing page, onboarding, settings |
| `db` | 16 | Tables, RLS, index, triggers, pgvector, schéma SaaS, billing tables, usage tracking |
| `devops` | 13 | Docker, GitHub Actions, Railway, Vercel, AWS ECS, Nginx, monitoring |
| `tester` | 14 | TDD, Jest, pytest, Playwright, coverage gates, mutation testing |
| `reviewer` | 8 | PR review, sécurité, perf, architecture, API contract |

### Groupe Strategy — 73 skills

| Agent | Skills | Description |
|-------|--------|-------------|
| `feature-architect` | 7 | Exploration codebase, conception feature, breaking changes |
| `technical-architect` | 8 | ADR, microservices, event-driven, scalabilité, cache |
| `api-designer` | 10 | REST, CRUD, auth, webhooks, pagination, OpenAPI |
| `ux-designer` | 10 | User flows, wireframes, accessibilité, onboarding, mobile |
| `data-modeler` | 9 | DDD, multi-tenant, time series, JSONB, soft delete |
| `security-auditor` | 10 | OWASP, injections, IDOR, RLS Supabase, Stripe webhooks |
| `performance-analyst` | 10 | N+1, EXPLAIN ANALYZE, bundle, cache Redis, benchmarks |
| `migration-strategist` | 9 | Zero-downtime, expand/contract, backfill, rollback |

### Groupe Business — 34 skills

| Agent | Skills | Description |
|-------|--------|-------------|
| `business-researcher` | 7 | Valeur produit, concurrence, KPIs, market sizing |
| `financial-analyst` | 6 | ROI, infra costs, SaaS pricing model, runway impact |
| `devils-advocate` | 6 | Pre-mortem, hypothèses, risk matrix, stress test |
| `doc-writer` | 8 | README, ADR, API docs, runbook, postmortem, changelog |
| `onboarding-agent` | 7 | Exploration projet inconnu, detect-stack, conventions |

### Agents Ruflo — 72 agents (v7.0.0)

Intégrés depuis Ruflo (Claude Flow) dans `.claude/agents/`. Activés via les 15 profils de routing dérivés.

| Catégorie | Agents (exemples) | Usage |
|-----------|-------------------|-------|
| `coordinator` | agent-adaptive-coordinator · agent-queen-coordinator · agent-hierarchical-coordinator · hive-mind | Orchestration swarm, topologies mesh/centralized/hybrid |
| `memory` | agentdb-learning · agentdb-vector-search · agentdb-advanced · agent-swarm-memory-manager | Mémoire vectorielle partagée entre agents |
| `benchmark` | agent-benchmark-suite · agent-performance-benchmarker · agent-performance-optimizer | Benchmarks BEIR, tests charge, profiling |
| `sona` | agent-sona-learning-optimizer · agent-memory-coordinator | Auto-optimisation neurale (SONA+EWC++) |
| `github` | agent-github-pr-manager · agent-ops-cicd-github · agent-release-manager | Automation GitHub, CI/CD, releases |
| `ml` | agent-neural-network · agent-data-ml-model · agent-trading-predictor | Modèles ML, trading, prédiction |
| `security` | agent-security-manager · agent-safla-neural · agent-v3-security-architect | Sécurité neurale, SAFLA, V3 |
| `dev` | agent-coder · pair-programming · agent-tdd-london-swarm · agent-code-review-swarm | Développement SPARC, pair, TDD |
| `infra` | agent-byzantine-coordinator · agent-raft-manager · agent-consensus-coordinator | Consensus distribué, RAFT, Byzantine |

```bash
ada agents list                    # tous les 131 agents
ada agents list --category github  # agents catégorie github
ada agents search "coordinator"    # recherche par nom/description
```

### Groupe Mobile — 33 skills

| Agent | Skills | Description |
|-------|--------|-------------|
| `react-native` | 12 | Expo Router, FlashList, offline, push notifications, deep links |
| `android` | 10 | Kotlin, Jetpack Compose, Hilt, Room, Retrofit, Crashlytics |
| `swift` | 11 | SwiftUI, async/await, SwiftData, Combine, Keychain, WidgetKit |

---

## Système de hooks — 7 hooks actifs

| Hook | Type | Déclencheur | Rôle |
|------|------|-------------|------|
| `pre-tool-validator.js` | PreToolUse | Bash | Bloque 10 patterns dangereux (rm -rf, DROP TABLE, curl\|bash...) |
| `memory-manager.js` | PostToolUse | Write/Edit | Mémoire long terme — filtre 22 extensions inutiles |
| `notify.js` | PostToolUse | Write/Edit | Notification système à la fin de /feature, /deploy, /test |
| `skill-cache.js` | PostToolUse | Read | Cache les skills déjà lus — évite les doubles lectures |
| `stop-hook.js` | Stop | Fin de réponse | Rappel /summarize si ≥ 3 échanges sans sauvegarde |
| `mark-summarized.js` | Appelé par /summarize | — | Désactive le stop-hook après sauvegarde |
| `reset-session-cache.js` | Appelé par /compact | — | Vide les caches skill et session |

---

## Architecture du projet

```
~/.claude-perso/
├── CLAUDE.md                    # 35 lignes — routing + règles globales
├── install.sh                   # Installation one-command avec lazy loading
├── tmux-dev.sh                  # Lanceur workspace tmux 5 fenêtres
├── init-project.sh              # Initialisation mémoire projet
├── detect-stack.sh              # Détection automatique de stack
└── .claude/
    ├── settings.json            # 3 types de hooks + allow/deny list
    ├── agents/                  # Agents actifs (full ou stub selon profil)
    │   ├── full/                # 24 agents complets (~400 tokens chacun)
    │   └── stubs/               # 24 stubs (~60 tokens chacun)
    ├── skills/                  # 250 skills répartis par agent
    ├── commands/                # 18 slash commands
    ├── teams/
    │   ├── profiles.json        # 14 profils d'agents
    │   └── routing.md
    ├── hooks/                   # 7 hooks Node.js
    └── memory/
        ├── global/              # decisions.md · patterns.md · errors.md
        └── projects/<p>/        # context.md · stories.md · archive/
```

---

## Optimisations tokens — v2

Le système intègre plusieurs mécanismes pour minimiser la consommation de tokens :

**Lazy loading des agents** : seuls les agents du profil actif sont chargés en version complète. Les 20 autres sont des stubs de 60 tokens. En profil `fullstack` : 3 059 tokens au lieu de 10 208 (-70%).

**Cache skill en session** : chaque skill lu est enregistré dans `session-skill-cache.json`. Si le même skill est demandé à nouveau dans la session, il n'est pas relu. Économie : ~500 tokens par double lecture évitée.

**Mapping tâche → 1 skill exact** : chaque agent contient un tableau précis indiquant quel skill lire pour quelle tâche. Élimine les lectures défensives (4-6 skills → 1 skill par tâche). Économie : ~2 500 tokens/tâche.

**Filtrage memory-manager** : 22 extensions ignorées (`.json`, `.lock`, `.yaml`, `.env`, images...). Whitelist pour 3 fichiers JSON significatifs. Réduction de l'overhead du hook : ~60%.

**Budget tokens typique en session fullstack :**

| Composant | Tokens |
|-----------|--------|
| CLAUDE.md | ~465 |
| Agents actifs (×4 full + ×20 stubs) | ~3 060 |
| 1 slash command | ~700 |
| 1 skill lu | ~500 |
| Historique échanges (incompressible) | ~60 000 |
| **Total système** | **~65 000** |

---

## Système de mémoire

Deux couches complémentaires :

- **ReasoningBank** (`bank.db`, SQLite) — source de vérité de la connaissance agent :
  trajectoires, conventions projet et insights distillés. Recall sémantique via Ollama
  (repli TF-IDF **observable**, jamais silencieux) ; conventions à portée global/domaine
  avec supersession et détection de contradiction. Détails :
  [`docs/architecture-memoire.md`](docs/architecture-memoire.md) · décision :
  [`docs/adr/ADR-018-memoire-recall-asservi.md`](docs/adr/ADR-018-memoire-recall-asservi.md).
- **Mémoire Markdown** (`memory/`) — décisions/patterns/contexte projet lisibles,
  auto-compression. Complète le bank (ne le remplace pas).

### Commandes mémoire

```bash
ada bank recall "<tâche>"          # bloc de connaissance projet injecté avant délégation
ada bank health                    # santé : ollama up/down, coverage, mode dégradé
ada bank seed-conventions          # peuple le bank depuis les Règles stack du CLAUDE.md

/memory show
/memory add decision "uuid PKs partout"
/memory search "stripe"
```

> **Mémoire = seul driver de valeur prouvé** (ablation 4 bras : `B−A = +8.3` ;
> routing et teams n'apportent rien sous le seuil de complexité). Voir
> [`docs/adr/ADR-019-bench-v2-ablation.md`](docs/adr/ADR-019-bench-v2-ablation.md).

---

## Layout tmux — 5 fenêtres

```
[1] main     — orchestrateur + nestjs/nextjs/db + devops/tester/reviewer
[2] strategy — feature-architect · technical-architect · api-designer
               devils-advocate · ux-designer · data-modeler
               security-auditor · performance-analyst · doc-writer
[3] business — business-researcher · financial-analyst
               migration-strategist · onboarding-agent
[4] mobile   — react-native · android · swift
[5] logs     — monitoring & git
```

### Raccourcis tmux

| Raccourci | Action |
|-----------|--------|
| `Ctrl+a` | Préfixe |
| `Ctrl+a 1-5` | Changer de fenêtre |
| `Ctrl+a h/j/k/l` | Naviguer entre panes |
| `Ctrl+a z` | Zoom pane courant |
| `Ctrl+a o` | Zoom orchestrateur |

---

## Serveurs MCP

La configuration est gérée dans `coordinator/mcp-registry.json` (séparé de `settings.json`). `ada start` synchronise automatiquement les connecteurs activés vers `settings.json`.

| Serveur | Description |
|---------|-------------|
| `filesystem` | Lecture/écriture fichiers locaux |
| `github` | PRs, issues, workflows, branches |
| `postgres` | Requêtes SQL directes |
| `fetch` | Requêtes HTTP depuis les agents |
| `brave-search` | Recherche web |
| `sqlite` | Base SQLite locale |
| `memory` | Mémoire persistante inter-sessions |
| `puppeteer` | Automatisation navigateur / tests E2E |
| `slack` | Messages et notifications |
| `git` | Opérations git avancées |
| `sequential-thinking` | Raisonnement structuré multi-étapes |
| `aws-kb` | Knowledge Base AWS Bedrock |
| `everything` | Indexation et recherche locale |
| `linear` | Gestion sprint |
| `notion` | Pages et bases de données Notion |

---

## Git Flow

```
feature/<id>  →  dev  →  staging  →  main
                              ↑
                       /push-staging
```

---

## Règles globales

- **TDD** : specs avant implémentation — toujours
- **Secrets** : jamais dans le code — `.env` + GitHub Secrets
- **Types** : pas de `any` TypeScript
- **DB** : UUID PK + `created_at` + `updated_at` + `workspace_id` sur toutes les tables SaaS
- **RLS** : activé + testé avant merge
- **Langue** : français, concis, résumé post-tâche obligatoire

---

## Contribuer

```bash
git checkout -b feature/mon-amélioration
# Committer avec les conventions : feat: add new skill
# PR vers dev
```

---

## Licence

Propriétaire — tous droits réservés. Usage soumis à une licence commerciale valide. Voir [LICENSE](LICENSE).

---

*Construit sur [Claude Code](https://docs.anthropic.com/en/docs/claude-code) par Anthropic.*
