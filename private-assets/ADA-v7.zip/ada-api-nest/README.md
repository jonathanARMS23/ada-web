# ada-api-nest (P1)

NestJS API parlant au **Control Server ada-core** (P0) via JSON-RPC/UDS, miroir
Postgres des events, et **surface REST lecture seule**. Coexiste avec `ada-api`
(Fastify) le temps de la bascule (ADR-016 §10, ROADMAP P1).

> **Lecture seule.** Aucune route ne mute l'état ada-core. Pas de `POST /tasks`,
> pas d'exécution `claude`. L'OrchestrationLoop et les sessions sont P2/P3.

## Démarrage

```bash
npm install
cp .env.example .env          # ajuster JWT_SECRET, ADA_ACTIVE_PROFILE, DATABASE_URL

# 1. Control Server ada-core (P0) — dans le repo racine :
node .claude/coordinator/control-server.js start        # UDS <profileDir>/control.sock

# 2. Postgres (optionnel — sans lui l'API démarre en mode dégradé) :
docker compose up -d postgres                            # host 5433
npm run db:migrate

# 3. API :
npm run build && npm start          # ou: npm run start:dev
# Swagger : http://127.0.0.1:3010/api/docs
```

## Endpoints (tous sous `/api`, JWT Bearer sauf `/health`)

| Méthode | Endpoint | RPC relayé |
|---------|----------|-----------|
| GET | `/capabilities` | `capabilities.list` |
| GET | `/health` *(public)* | `health.probe` + état Postgres |
| GET | `/runs` | projection Postgres, fallback `run.list` |
| GET | `/runs/:id` | `run.status` |
| GET | `/memory?q=` | `bank.retrieve` |
| GET | `/router/stats` | `router.stats` |
| GET | `/stats/cost` | `cost.report` |
| GET | `/stats/metrics` | `metrics.get` |

## Mode dégradé Postgres

Sans `DATABASE_URL` ou si Postgres est injoignable au boot : l'app démarre,
logue un `warn`, `/health` renvoie `db: "down"`. Les endpoints qui ne dépendent
pas de la DB (capabilities, health, memory, stats…) restent fonctionnels ; `/runs`
bascule sur `run.list` live.

## Tests

```bash
npm test                # unit (ControlPlaneClient vs vrai control-server) + e2e
```

Les tests Postgres sont **skippés proprement** si `DATABASE_URL` est absent.
