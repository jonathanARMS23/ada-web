# P3 / P3.5 — Sessions interactives & Permission Broker (hook PreToolUse validé)

Ce document décrit le mécanisme **réel et validé live** d'interception des
permissions entre une session Claude Code headless et NestJS : le **Claude Agent
SDK** (`@anthropic-ai/claude-agent-sdk`) avec un **hook `PreToolUse`**. Le moteur
de politique (Fork #2), le flux d'events request/response, le `SessionManager` et
le `StreamGateway` restent inchangés (testés P1-P3). Seul le **binding
d'interception** a été refait en P3.5 — l'ancien câblage MCP
`--permission-prompt-tool` est **abandonné** (voir l'historique en fin de
document).

## Vue d'ensemble du flux (P3.5)

```
SdkInteractiveSession  ──>  query({ prompt: <async gen user msgs>, options })
                              options.hooks.PreToolUse = [{ hooks: [preToolUse] }]
   │  le SDK intercepte CHAQUE outil AVANT exécution et appelle le hook
   ▼
preToolUse(input)            (in-process, même process Node que NestJS)
   │  input = { hook_event_name:'PreToolUse', tool_name, tool_input, session_id, tool_use_id }
   ▼
PermissionPolicyService.evaluate(ctx)
   ├─ mode bypassPermissions -> allow        (immédiat)
   ├─ mode plan              -> deny          (immédiat)
   ├─ policy allow/deny      -> immédiat (Fork #2 : Read/Grep/Glob/LS/NotebookRead=allow)
   └─ policy ask (Bash/Write/Edit/MultiEdit/WebFetch/MCP/inconnu) :
        emit  task.permission_request {requestId, tool, input}   (StreamGateway -> UI)
        await task.permission_response {requestId, decision, updatedInput?}
        (timeout ADA_PERMISSION_TIMEOUT_MS -> deny)
   ▼
return { hookSpecificOutput: {
          hookEventName: 'PreToolUse',
          permissionDecision: 'allow' | 'deny',
          permissionDecisionReason: '...',
          updatedInput?            // sur allow, si la policy a réécrit l'input
        } }
```

Le hook retourne `permissionDecision: 'allow'` (l'outil s'exécute, éventuellement
avec `updatedInput`) ou `'deny'` (l'outil est refusé **avant** exécution, et
apparaît dans `result.permission_denials[]`).

## Snippet de référence (validé live)

```ts
import { query } from '@anthropic-ai/claude-agent-sdk'

const preToolUse = async (input) => {
  if (input.hook_event_name !== 'PreToolUse') return {}
  const { tool_name, tool_input } = input
  const result = await policy.evaluate({ tool: tool_name, input: tool_input, /* session ctx */ })
  return {
    hookSpecificOutput: {
      hookEventName: 'PreToolUse',
      permissionDecision: result.behavior === 'allow' ? 'allow' : 'deny',
      permissionDecisionReason: result.message ?? 'policy ADA',
      ...(result.updatedInput ? { updatedInput: result.updatedInput } : {}),
    },
  }
}

const q = query({
  prompt: userMessages(),            // AsyncGenerator<SDKUserMessage> — streaming input
  options: {
    cwd,
    permissionMode: 'default',       // OBLIGATOIRE : laisse le hook décider
    settingSources: ['user','project','local'],
    abortController,                 // cancel() => abortController.abort()
    hooks: { PreToolUse: [{ hooks: [preToolUse] }] },
    maxTurns,                        // optionnel
    resume: claudeSessionId,         // reprise multi-tours / reconnexion
  },
})

for await (const msg of q) {
  // {type:'system',subtype:'init',session_id}  -> capture session_id
  // {type:'assistant',message:{content:[{type:'text'|'tool_use',...}]}}  -> output / tool
  // {type:'result', subtype, result, usage:{input_tokens,output_tokens}, total_cost_usd, permission_denials[]}
}
q.interrupt()                        // équivalent ESC (streaming input requis)
```

Faits confirmés live : `permissionMode:'default'` obligatoire pour que le hook
décide ; un outil refusé apparaît dans `result.permission_denials[]` ;
`result.total_cost_usd` + `usage.{input,output}_tokens` sont disponibles ;
`session_id` arrive dans `system/init`.

## Ordre d'évaluation (du plus prioritaire au moins prioritaire)

1. **Allow-list `settings.json` du profil** (chargée via `settingSources`) — c'est
   le **premier filtre du SDK** : tout outil pré-autorisé (echo/git/npm/…)
   s'exécute SANS jamais déclencher le hook. **Fast-path voulu.**
2. **Hook `PreToolUse`** (`PermissionPolicyService.evaluate`) pour tout le reste :
   1. **Mode** : `bypassPermissions` → allow ; `plan` → deny.
   2. **Deny** explicite de la policy → deny immédiat.
   3. **Allow** (policy ou Fork #2 : Read/Grep/Glob/LS/NotebookRead ;
      `acceptEdits` upgrade Edit/Write/MultiEdit) → allow immédiat.
   4. **Ask** (Bash/Write/Edit/MultiEdit/WebFetch/MCP/inconnu) → `task.permission_request`
      vers l'UI, attente de `task.permission_response`, timeout → deny.
      `allow_always` persiste une règle `allow` dans `permission_policies`.

> Résumé : **Allow-list (SDK) → Hook[ Mode → Deny → Allow → Ask ]**. L'allow-list
> court-circuite le hook ; le hook gère tout ce qui n'y est pas.

## settingSources (configurable)

`ADA_SETTING_SOURCES` (CSV, défaut `user,project,local`) → `options.settingSources`.

- **Charger le profil** (défaut) applique le **CLAUDE.md orchestrateur**, les
  **agents**, et l'**allow-list `settings.json`** du profil. Conséquence voulue :
  les outils pré-autorisés (echo/git/npm) sont en fast-path et ne passent pas par
  le hook ; le hook (Fork #2) gère le reste.
- **`ADA_SETTING_SOURCES=""`** (vide) → aucune source chargée : le hook gère
  **TOUS** les outils (aucun fast-path). Utile pour un mode strict.

## Lancement de la session (SdkInteractiveSession)

- `ADA_EXECUTOR=sdk` (ou l'alias historique `cli`) sélectionne
  `SdkInteractiveSessionFactory` ; `mock` reste le défaut (tests/dev).
- **Streaming input** : `query({ prompt })` reçoit un générateur async de
  `SDKUserMessage` maintenu ouvert toute la session. Chaque `task.message`
  (follow-up) est poussé comme un nouveau tour user. Le générateur se termine sur
  `cancel()`.
- `CLAUDE_CONFIG_DIR` = `profileDir` (isolation profil), `cwd` = workspace.
- `session_id` capturé depuis `{type:'system',subtype:'init',session_id}` et
  réutilisé via `options.resume` (reprise multi-tours / reconnexion).
- **`interrupt`** → `q.interrupt()` (équivalent ESC). **`cancel`** →
  `abortController.abort()` + fin du générateur d'input.

## Surface conservée (testée, sans claude réel)

- `StreamParser` (utilisé par le MockExecutor de phases) capture `session_id`.
- `PermissionPolicyService` : Fork #2, ask Bash/Write/Edit/MultiEdit/WebFetch,
  `allow_always` persisté, timeout→deny, modes default/acceptEdits/bypass/plan.
- `SessionManager` : session bidirectionnelle multi-tours via factory mock|sdk,
  `resume` réutilise le `session_id`, persistance messages/tool_calls/sessions.
- `PlanClarificationService` : `task.plan`/`task.clarification` ↔ réponses.
- Le hook `PreToolUse` est testé via un **faux `query()`** (injecté dans
  `SdkInteractiveSessionFactory`) qui émet une séquence SDK canned et déclenche le
  hook : Read→allow sans event, Bash→ask (allow sur réponse, deny sur timeout),
  `allow_always` persiste, mapping SDK→events, multi-tours + `resume`,
  interrupt/cancel.

## Tests (Claude/SDK jamais exécuté pour de vrai)

- `test/sdk-interactive-session.spec.ts` : hook PreToolUse + mapping + streaming.
- `test/permission-policy.spec.ts`, `test/permission-broker.spec.ts`,
  `test/session-manager.spec.ts`, `test/interactive-session-resume.spec.ts` :
  inchangés/adaptés, toujours verts.
- DB/pg-boss : skip propre sans `DATABASE_URL` (mode dégradé).

---

## HISTORIQUE — binding MCP `--permission-prompt-tool` (ABANDONNÉ, P3.5)

> Conservé pour mémoire. Les classes `McpBrokerController` et
> `PermissionBrokerService` ainsi que les env `ADA_PERMISSION_PROMPT_TOOL` /
> `ADA_MCP_BROKER_CONFIG` sont marquées `@deprecated` : hors du chemin live, gardées
> uniquement pour ne pas casser les tests du moteur de décision. La classe
> `CliInteractiveSession` (spawn `claude -p`) a été **supprimée**.

### Résultat validation live (2026-06-09) — binding non fonctionnel

Test avec `claude` réel (v2.1.169) + `--permission-prompt-tool mcp__ada__approve` :

- **HTTP** (`type:"http"`) et **stdio** (`command:"node"`) : le serveur MCP reste
  `status:"pending"`, l'outil `approve` n'est jamais exposé, et une commande
  **hors allow-list** (`whoami`) s'exécute SANS appel à `approve` (broker bypassé).
- Le `settings.json` du profil est le **premier filtre** : tout ce qui y est
  `allow` (echo/git/npm/…) ne déclenche jamais le permission-prompt-tool.
- La logique broker NestJS elle-même était correcte (curl `approve(Read)` → allow).

### Pistes évaluées

1. **Claude Agent SDK `canUseTool`** : **non invoqué en headless** (bug #27203) → abandonné.
2. **Claude Agent SDK `PreToolUse` hooks** : **VALIDÉ** → c'est la solution retenue (ci-dessus).
3. Serveur MCP Streamable-HTTP officiel : non nécessaire une fois le hook validé.

**Conclusion** : `--permission-prompt-tool` + serveur MCP custom n'intercepte pas
les permissions en mode headless `-p`. Le mécanisme retenu est le hook
`PreToolUse` du SDK, in-process.
