import type { Config } from 'drizzle-kit';

// Drizzle introspection/generate config (the runtime uses raw SQL migrations
// in src/persistence/migrations). Kept for schema diffing during P2.
export default {
  schema: './src/persistence/schema.ts',
  out: './src/persistence/migrations',
  dialect: 'postgresql',
  dbCredentials: {
    url: process.env.DATABASE_URL ?? 'postgresql://ada:ada@127.0.0.1:5433/ada',
  },
} satisfies Config;
