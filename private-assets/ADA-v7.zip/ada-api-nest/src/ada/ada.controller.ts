import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  Param,
  Post,
  Put,
  Query,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/jwt-auth.guard.js';
import { TaskRateLimitGuard } from '../tasks/task-rate-limit.guard.js';
import { AdaService } from './ada.service.js';
import { ConfigService } from './config.service.js';
import { AgentsQueryDto, SearchQueryDto } from './dto/ada-query.dto.js';
import {
  CreateScheduleDto,
  DaemonRunDto,
  InstallSkillDto,
  ObsidianToggleDto,
  SetProviderDto,
} from './dto/ada-mutation.dto.js';
import { CreateProfileDto, SwitchProfileDto } from './dto/config.dto.js';

/**
 * Full CLI surface over the Control Server (ADR-016 §6bis D — P4a).
 *
 * Acceptance criterion: every `ada` command reachable from ada-ui via ada-api,
 * no terminal needed. Reads are plain JWT-guarded GETs; mutations are POST/PUT/
 * DELETE behind JWT, and the spawn/network-bearing ones add TaskRateLimitGuard.
 *
 * JWT applies to ALL routes (controller-level guard). This relays only — no
 * ada-core state is mutated in this process (the Control Server owns mutations).
 */
@ApiTags('ada')
@ApiBearerAuth()
@Controller()
@UseGuards(JwtAuthGuard)
export class AdaController {
  constructor(
    private readonly service: AdaService,
    private readonly config: ConfigService,
  ) {}

  // ── Reads ──────────────────────────────────────────────────────────────────

  @Get('profiles')
  @ApiOperation({ summary: 'Profils installés + profil actif (profiles.list)' })
  profiles() {
    return this.service.profiles();
  }

  @Get('agents')
  @ApiOperation({ summary: 'Agents du profil (agents.list)' })
  agents(@Query() q: AgentsQueryDto) {
    return this.service.agents(q.category, q.profile);
  }

  @Get('agents/search')
  @ApiOperation({ summary: 'Recherche d’agents (agents.search)' })
  searchAgents(@Query() q: SearchQueryDto) {
    return this.service.searchAgents(q.q ?? '');
  }

  // Déclaré APRÈS agents/search pour que le segment statique prime sur :slug.
  @Get('agents/:slug')
  @ApiOperation({ summary: 'Détail d’un agent (frontmatter + prompt + stats) — agents.info' })
  agentInfo(@Param('slug') slug: string) {
    return this.config.agentInfo(slug);
  }

  @Get('skills')
  @ApiOperation({ summary: 'Skills installés + disponibles (skills.list)' })
  skills() {
    return this.service.skills();
  }

  @Get('skills/search')
  @ApiOperation({ summary: 'Recherche de skills (skills.search)' })
  searchSkills(@Query() q: SearchQueryDto) {
    return this.service.searchSkills(q.q ?? '');
  }

  @Get('skills/:name')
  @ApiOperation({ summary: 'Détail d’un skill (skills.info)' })
  skillInfo(@Param('name') name: string) {
    return this.service.skillInfo(name);
  }

  @Get('teams/sync')
  @ApiOperation({ summary: 'Statut de la synchro d’équipe (team.status)' })
  teamSync() {
    return this.service.teamStatus();
  }

  @Get('bridge')
  @ApiOperation({ summary: 'Statut du bridge multi-profil (bridge.status)' })
  bridge() {
    return this.service.bridge();
  }

  @Get('federation')
  @ApiOperation({ summary: 'Statut de la fédération (fed.status)' })
  federation() {
    return this.service.federation();
  }

  @Get('federation/peers')
  @ApiOperation({ summary: 'Pairs configurés + actifs (fed.peers)' })
  federationPeers() {
    return this.service.federationPeers();
  }

  @Get('daemon')
  @ApiOperation({ summary: 'Statut du daemon + schedule (daemon.status)' })
  daemon() {
    return this.service.daemon();
  }

  @Get('schedules')
  @ApiOperation({ summary: 'Schedules configurés (schedules.list)' })
  schedules() {
    return this.service.schedules();
  }

  @Get('providers')
  @ApiOperation({ summary: 'Mode fournisseur + providers disponibles (providers.status)' })
  providers() {
    return this.service.providers();
  }

  @Get('obsidian/status')
  @ApiOperation({ summary: 'Statut de l’intégration Obsidian (obsidian.status)' })
  obsidian() {
    return this.service.obsidian();
  }

  @Post('obsidian/status')
  @ApiOperation({ summary: 'Bascule rapide enabled (obsidian.setEnabled) — mute ~/.ada.json' })
  setObsidianEnabled(@Body() dto: ObsidianToggleDto) {
    return this.service.setObsidianEnabled(dto.enabled);
  }

  @Get('pr')
  @ApiOperation({ summary: 'Config PR autopilot (pr.status)' })
  pr() {
    return this.service.pr();
  }

  // GET /logs est désormais servi par LogsController (P5 — persistance + fallback
  // live logs.tail quand la DB est down). AdaService.logs() reste pour ce dernier.

  // ── Mutations (JWT + rate limit on spawn/network) ────────────────────────────

  @Put('providers')
  @ApiOperation({ summary: 'Change le mode fournisseur (providers.set) — mute ~/.ada.json' })
  setProvider(@Body() dto: SetProviderDto) {
    return this.service.setProvider(dto.mode);
  }

  @Put('profiles/active')
  @UseGuards(TaskRateLimitGuard)
  @ApiOperation({ summary: 'Bascule le profil actif (profiles.switch) — mute ~/.ada.json' })
  switchProfile(@Body() dto: SwitchProfileDto) {
    return this.config.switchProfile(dto.profile);
  }

  @Post('profiles')
  @HttpCode(201)
  @UseGuards(TaskRateLimitGuard)
  @ApiOperation({ summary: 'Crée/enregistre un profil (profiles.create) — mute ~/.ada.json' })
  createProfile(@Body() dto: CreateProfileDto) {
    return this.config.createProfile(dto.name, dto.activate);
  }

  @Post('schedules')
  @HttpCode(201)
  @ApiOperation({ summary: 'Ajoute un schedule (schedules.add) — mute ~/.ada.json' })
  addSchedule(@Body() dto: CreateScheduleDto) {
    return this.service.addSchedule(dto);
  }

  @Put('schedules/:id/toggle')
  @ApiOperation({ summary: 'Bascule un schedule (schedules.toggle) — mute ~/.ada.json' })
  toggleSchedule(@Param('id') id: string) {
    return this.service.toggleSchedule(id);
  }

  @Delete('schedules/:id')
  @ApiOperation({ summary: 'Supprime un schedule (schedules.remove) — mute ~/.ada.json' })
  removeSchedule(@Param('id') id: string) {
    return this.service.removeSchedule(id);
  }

  @Post('skills')
  @HttpCode(202)
  @UseGuards(TaskRateLimitGuard)
  @ApiOperation({ summary: 'Installe un skill (skill.install) — spawn/copie, rate-limité' })
  installSkill(@Body() dto: InstallSkillDto) {
    return this.service.installSkill(dto.name);
  }

  @Delete('skills/:name')
  @ApiOperation({ summary: 'Désinstalle un skill (skill.uninstall) — fs' })
  uninstallSkill(@Param('name') name: string) {
    return this.service.uninstallSkill(name);
  }

  @Post('teams/sync/push')
  @HttpCode(202)
  @UseGuards(TaskRateLimitGuard)
  @ApiOperation({ summary: 'Push la synchro d’équipe (team.push) — git/réseau, rate-limité' })
  teamPush() {
    return this.service.teamPush();
  }

  @Post('teams/sync/pull')
  @HttpCode(202)
  @UseGuards(TaskRateLimitGuard)
  @ApiOperation({ summary: 'Pull la synchro d’équipe (team.pull) — git/réseau, rate-limité' })
  teamPull() {
    return this.service.teamPull();
  }

  @Post('daemon/run')
  @HttpCode(202)
  @UseGuards(TaskRateLimitGuard)
  @ApiOperation({ summary: 'Exécute un worker daemon (daemon.run) — spawn, rate-limité' })
  daemonRun(@Body() dto: DaemonRunDto) {
    return this.service.daemonRun(dto.worker);
  }
}
