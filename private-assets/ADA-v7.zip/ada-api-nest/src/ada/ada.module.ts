import { Module } from '@nestjs/common';
import { AdaController } from './ada.controller.js';
import { AdaService } from './ada.service.js';
import { ConfigService } from './config.service.js';
import { AgentAccessService } from './agent-access.service.js';
import {
  McpController,
  PipelinesController,
  SettingsController,
  TeamsController,
} from './config.controllers.js';
import { TaskRateLimitGuard } from '../tasks/task-rate-limit.guard.js';

/**
 * Full CLI surface module (ADR-016 §6bis D — P4a) + P7 configuration features
 * (pipelines, MCP CRUD, profiles switch/create, teams, agent detail, settings).
 * Relays to the Control Server via the global ControlPlaneClient; reuses
 * TaskRateLimitGuard for mutations. ControlPlaneClient is @Global.
 */
@Module({
  controllers: [
    AdaController,
    PipelinesController,
    McpController,
    TeamsController,
    SettingsController,
  ],
  providers: [AdaService, ConfigService, AgentAccessService, TaskRateLimitGuard],
})
export class AdaModule {}
