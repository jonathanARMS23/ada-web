import { Injectable } from '@nestjs/common';
import { ControlPlaneClient } from '../control-plane/control-plane.client.js';

/**
 * Relay over the Control Server for the full CLI surface (ADR-016 §6bis D, P4a).
 *
 * Method classification (mirrors capabilities.list.methodGroups / mutativeMethods):
 *   - read        : idempotent RPC reads (profiles/agents/skills/team/bridge/fed/
 *                   daemon/schedules/providers/obsidian/pr/logs status + search).
 *   - control     : light bounded effect, no spawn (none here beyond reads).
 *   - mutative    : mutate ~/.ada.json or spawn/network — wired but guarded at the
 *                   controller layer (JWT + rate limit on spawn/network ones).
 *
 * Thin wrappers over client.request so the controller stays declarative. No
 * state is mutated in this process: every mutation is delegated to ada-core.
 */
@Injectable()
export class AdaService {
  constructor(private readonly client: ControlPlaneClient) {}

  // ── Reads ──────────────────────────────────────────────────────────────────

  profiles(): Promise<unknown> {
    return this.client.request('profiles.list');
  }

  agents(category?: string, profile?: string): Promise<unknown> {
    const params: Record<string, string> = {};
    if (category) params.category = category;
    if (profile) params.profile = profile;
    return this.client.request('agents.list', params);
  }

  searchAgents(query: string): Promise<unknown> {
    return this.client.request('agents.search', { query });
  }

  skills(): Promise<unknown> {
    return this.client.request('skills.list');
  }

  searchSkills(query: string): Promise<unknown> {
    return this.client.request('skills.search', { query });
  }

  skillInfo(name: string): Promise<unknown> {
    return this.client.request('skills.info', { name });
  }

  teamStatus(): Promise<unknown> {
    return this.client.request('team.status');
  }

  bridge(): Promise<unknown> {
    return this.client.request('bridge.status');
  }

  federation(): Promise<unknown> {
    return this.client.request('fed.status');
  }

  federationPeers(): Promise<unknown> {
    return this.client.request('fed.peers');
  }

  daemon(): Promise<unknown> {
    return this.client.request('daemon.status');
  }

  schedules(): Promise<unknown> {
    return this.client.request('schedules.list');
  }

  providers(): Promise<unknown> {
    return this.client.request('providers.status');
  }

  obsidian(): Promise<unknown> {
    return this.client.request('obsidian.status');
  }

  setObsidianEnabled(enabled: boolean): Promise<unknown> {
    return this.client.request('obsidian.setEnabled', { enabled });
  }

  pr(): Promise<unknown> {
    return this.client.request('pr.status');
  }

  logs(source: string | undefined, lines: number | undefined): Promise<unknown> {
    return this.client.request('logs.tail', { source, lines });
  }

  // ── Mutations (delegated to ada-core; guarded at controller layer) ───────────

  /** [MUTATIVE — ~/.ada.json] change the provider mode. */
  setProvider(mode: string): Promise<unknown> {
    return this.client.request('providers.set', { mode });
  }

  /** [MUTATIVE — ~/.ada.json] add a schedule entry. */
  addSchedule(params: { pipeline: string; cron: string; name?: string }): Promise<unknown> {
    return this.client.request('schedules.add', { ...params });
  }

  /** [MUTATIVE — ~/.ada.json] toggle a schedule entry. */
  toggleSchedule(id: string): Promise<unknown> {
    return this.client.request('schedules.toggle', { id });
  }

  /** [MUTATIVE — ~/.ada.json] remove a schedule entry. */
  removeSchedule(id: string): Promise<unknown> {
    return this.client.request('schedules.remove', { id });
  }

  /** [MUTATIVE — spawn/copy] install a skill (rate-limited at controller). */
  installSkill(name: string): Promise<unknown> {
    return this.client.request('skill.install', { name });
  }

  /** [MUTATIVE — fs] uninstall a skill. */
  uninstallSkill(name: string): Promise<unknown> {
    return this.client.request('skill.uninstall', { name });
  }

  /** [MUTATIVE — git/network] push the team sync repo (rate-limited at controller). */
  teamPush(): Promise<unknown> {
    return this.client.request('team.push');
  }

  /** [MUTATIVE — git/network] pull the team sync repo (rate-limited at controller). */
  teamPull(): Promise<unknown> {
    return this.client.request('team.pull');
  }

  /** [MUTATIVE — spawn detached] run a daemon worker now (rate-limited at controller). */
  daemonRun(worker: string): Promise<unknown> {
    return this.client.request('daemon.run', { worker });
  }
}
