import { Injectable } from '@nestjs/common';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { AppConfigService } from '../config/app-config.service.js';

/**
 * TÂCHE A+B — Enrichissement réel du détail d'agent (mcps + skills).
 *
 * Source de vérité (données RÉELLES, aucune invention) :
 *  - MCP    : RPC `mcp.list` du Control Server → connecteurs MCP CONFIGURÉS
 *             (lus depuis settings.json `mcpServers`, secrets masqués). C'est la
 *             même source que la page MCP de l'UI (GET /api/mcp/connectors).
 *  - Skills : RPC `skills.list` → `available[]` (skills dotés d'un skill.json
 *             dans `.claude/skills/`). Même source que GET /api/skills.
 *
 * Règle d'accessibilité (frontmatter `tools` de `.claude/agents/<slug>.md`) :
 *  - `tools` absent ou "All tools"  → l'agent accède à TOUS les serveurs MCP
 *    configurés et à TOUS les skills disponibles.
 *  - `tools` restreint (liste)      → sous-ensemble : seuls les serveurs MCP
 *    dont au moins un outil `mcp__<server>__*` figure dans la liste sont gardés ;
 *    les skills sont filtrés par nom présent dans la liste, sinon vide.
 *
 * Tout est calculé dans la couche ada-api-nest (frontmatter lu directement,
 * RPC relayées), JAMAIS dans le coordinator.
 */
@Injectable()
export class AgentAccessService {
  constructor(private readonly appConfig: AppConfigService) {}

  /**
   * Lit le frontmatter d'un agent et retourne sa déclaration `tools` brute,
   * ou null si l'agent/fichier est introuvable.
   */
  private readToolsFrontmatter(slug: string): string | null {
    if (!/^[A-Za-z0-9_-]+$/.test(slug)) return null;
    const dir = this.appConfig.agentsDir;
    let file = path.join(dir, `${slug}.md`);
    if (!fs.existsSync(file)) {
      const nested = path.join(dir, slug, 'CLAUDE.md');
      if (!fs.existsSync(nested)) return null;
      file = nested;
    }
    let content = '';
    try {
      content = fs.readFileSync(file, 'utf8');
    } catch {
      return null;
    }
    const fmMatch = content.match(/^---\s*\n([\s\S]*?)\n---/);
    if (!fmMatch) return null;
    const toolsLine = fmMatch[1].match(/^tools:\s*(.+)$/m);
    return toolsLine ? toolsLine[1].trim() : null;
  }

  /**
   * true si l'agent a accès à TOUS les outils (frontmatter `tools` absent
   * ou explicitement "All tools" / "*").
   */
  private hasAllTools(toolsRaw: string | null): boolean {
    if (toolsRaw == null || toolsRaw === '') return true;
    const v = toolsRaw.toLowerCase();
    return v === 'all tools' || v === 'all' || v === '*';
  }

  /** Liste les noms d'outils déclarés dans un `tools` restreint. */
  private parseToolList(toolsRaw: string): string[] {
    return toolsRaw
      .replace(/^\[|\]$/g, '')
      .split(',')
      .map((t) => t.trim().replace(/^["']|["']$/g, ''))
      .filter(Boolean);
  }

  /**
   * Calcule la liste des serveurs MCP accessibles à l'agent.
   * @param slug          slug de l'agent
   * @param configuredMcp noms des serveurs MCP configurés (depuis mcp.list)
   */
  resolveMcps(slug: string, configuredMcp: string[]): string[] {
    const toolsRaw = this.readToolsFrontmatter(slug);
    if (this.hasAllTools(toolsRaw)) return [...configuredMcp];
    const tools = this.parseToolList(toolsRaw as string);
    // Un serveur est accessible si un outil `mcp__<server>__*` (ou `mcp__<server>`)
    // figure dans la liste restreinte.
    return configuredMcp.filter((server) =>
      tools.some(
        (t) => t === `mcp__${server}` || t.startsWith(`mcp__${server}__`),
      ),
    );
  }

  /**
   * Calcule la liste des skills accessibles à l'agent.
   * @param slug             slug de l'agent
   * @param availableSkills  noms des skills disponibles (depuis skills.list)
   */
  resolveSkills(slug: string, availableSkills: string[]): string[] {
    const toolsRaw = this.readToolsFrontmatter(slug);
    if (this.hasAllTools(toolsRaw)) return [...availableSkills];
    const tools = this.parseToolList(toolsRaw as string);
    // Un skill restreint est accessible si son nom (ou Skill(<name>)) est listé.
    return availableSkills.filter((name) =>
      tools.some((t) => t === name || t === `Skill(${name})`),
    );
  }
}
