import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  Param,
  Patch,
  Post,
  Put,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/jwt-auth.guard.js';
import { TaskRateLimitGuard } from '../tasks/task-rate-limit.guard.js';
import { ConfigService } from './config.service.js';
import {
  CreateMcpConnectorDto,
  CreateProfileDto,
  CreateTeamDto,
  SwitchProfileDto,
  UpdateMcpConnectorDto,
  UpdateSettingsDto,
  UpdateTeamDto,
} from './dto/config.dto.js';

/**
 * P7 — Configuration features over the Control Server (relay only; mutations
 * delegated to ada-core). JWT on every route; mutations add TaskRateLimitGuard.
 *
 * Reads  : pipelines.*, mcp.list/registry, teams.list/get, agents.info, settings.get.
 * Mutates: mcp.add/update/remove, profiles.switch/create, teams.*, settings.set.
 */

// ── Pipelines (read-only) ────────────────────────────────────────────────────

@ApiTags('pipelines')
@ApiBearerAuth()
@Controller('pipelines')
@UseGuards(JwtAuthGuard)
export class PipelinesController {
  constructor(private readonly config: ConfigService) {}

  @Get()
  @ApiOperation({ summary: 'Liste des pipelines (DAG résolu : agent/tier/model/deps) — pipelines.list' })
  list() {
    return this.config.listPipelines();
  }

  @Get(':name')
  @ApiOperation({ summary: 'Détail d’un pipeline (pipelines.get)' })
  get(@Param('name') name: string) {
    return this.config.getPipeline(name);
  }
}

// ── MCP connectors (CRUD config + catalogue) ──────────────────────────────────

@ApiTags('mcp')
@ApiBearerAuth()
@Controller('mcp')
@UseGuards(JwtAuthGuard)
export class McpController {
  constructor(private readonly config: ConfigService) {}

  @Get('connectors')
  @ApiOperation({ summary: 'Serveurs MCP configurés (mcp.list) — secrets masqués' })
  listConnectors() {
    return this.config.listMcp();
  }

  @Get('registry')
  @ApiOperation({ summary: 'Catalogue MCP (mcp.registry)' })
  registry() {
    return this.config.mcpRegistry();
  }

  @Post('connectors')
  @HttpCode(201)
  @UseGuards(TaskRateLimitGuard)
  @ApiOperation({ summary: 'Ajoute un serveur MCP (mcp.add) — mute settings.json' })
  addConnector(@Body() dto: CreateMcpConnectorDto) {
    return this.config.addMcp(dto);
  }

  @Patch('connectors/:id')
  @UseGuards(TaskRateLimitGuard)
  @ApiOperation({ summary: 'Met à jour un serveur MCP (mcp.update) — mute settings.json' })
  updateConnector(@Param('id') id: string, @Body() dto: UpdateMcpConnectorDto) {
    return this.config.updateMcp(id, dto);
  }

  @Delete('connectors/:id')
  @UseGuards(TaskRateLimitGuard)
  @ApiOperation({ summary: 'Supprime un serveur MCP (mcp.remove) — mute settings.json' })
  removeConnector(@Param('id') id: string) {
    return this.config.removeMcp(id);
  }
}

// ── Teams (CRUD) ──────────────────────────────────────────────────────────────

@ApiTags('teams')
@ApiBearerAuth()
@Controller('teams')
@UseGuards(JwtAuthGuard)
export class TeamsController {
  constructor(private readonly config: ConfigService) {}

  @Get()
  @ApiOperation({ summary: 'Liste des teams (teams.list)' })
  list() {
    return this.config.listTeams();
  }

  @Get(':id')
  @ApiOperation({ summary: 'Détail d’une team (teams.get)' })
  get(@Param('id') id: string) {
    return this.config.getTeam(id);
  }

  @Post()
  @HttpCode(201)
  @UseGuards(TaskRateLimitGuard)
  @ApiOperation({ summary: 'Crée une team (teams.create) — mute coordinator/teams.json' })
  create(@Body() dto: CreateTeamDto) {
    return this.config.createTeam(dto);
  }

  @Patch(':id')
  @UseGuards(TaskRateLimitGuard)
  @ApiOperation({ summary: 'Met à jour une team (teams.update) — mute coordinator/teams.json' })
  update(@Param('id') id: string, @Body() dto: UpdateTeamDto) {
    return this.config.updateTeam(id, dto);
  }

  @Delete(':id')
  @UseGuards(TaskRateLimitGuard)
  @ApiOperation({ summary: 'Supprime une team (teams.remove) — mute coordinator/teams.json' })
  remove(@Param('id') id: string) {
    return this.config.removeTeam(id);
  }
}

// ── Settings (vue agrégée ~/.ada.json) ────────────────────────────────────────

@ApiTags('settings')
@ApiBearerAuth()
@Controller('settings')
@UseGuards(JwtAuthGuard)
export class SettingsController {
  constructor(private readonly config: ConfigService) {}

  @Get()
  @ApiOperation({ summary: 'Settings agrégés (providers/budget/obsidian/webhook) — settings.get' })
  get() {
    return this.config.getSettings();
  }

  @Put()
  @UseGuards(TaskRateLimitGuard)
  @ApiOperation({ summary: 'Met à jour les settings (settings.set) — mute ~/.ada.json' })
  set(@Body() dto: UpdateSettingsDto) {
    return this.config.setSettings(dto);
  }
}

// ── Agent detail + Profiles switch/create (réexportés via DTO) ────────────────
// Note: ces routes (GET /agents/:slug, PUT /profiles/active, POST /profiles)
// sont portées par AdaController (qui possède déjà /agents et /profiles).
export { SwitchProfileDto, CreateProfileDto };
