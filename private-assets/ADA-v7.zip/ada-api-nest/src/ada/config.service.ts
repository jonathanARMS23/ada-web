import { Injectable } from '@nestjs/common';
import { ControlPlaneClient } from '../control-plane/control-plane.client.js';
import { AgentAccessService } from './agent-access.service.js';
import type {
  CreateMcpConnectorDto,
  UpdateMcpConnectorDto,
  CreateTeamDto,
  UpdateTeamDto,
  UpdateSettingsDto,
} from './dto/config.dto.js';

/** Forme partielle de la RPC `agents.info` (champs consommés ici). */
interface AgentInfoResult {
  agent?: {
    slug?: string;
    skills?: string[];
    [k: string]: unknown;
  };
  [k: string]: unknown;
}

/** Forme partielle de la RPC `mcp.list` (connecteurs configurés). */
interface McpListResult {
  connectors?: Array<{ id?: string; name?: string }>;
}

/** Forme partielle de la RPC `skills.list` (skills disponibles). */
interface SkillsListResult {
  available?: Array<{ name?: string }>;
}

/**
 * P7 — Relay over the Control Server for the configuration features
 * (pipelines, MCP, profiles switch/create, teams, agent detail, settings).
 *
 * Like AdaService: thin wrappers over client.request. No state is mutated in
 * this process — every mutation is delegated to ada-core (the Control Server
 * owns ~/.ada.json / settings.json / coordinator/teams.json). Reads are
 * idempotent; mutations are guarded (JWT + rate limit) at the controller layer.
 */
@Injectable()
export class ConfigService {
  constructor(
    private readonly client: ControlPlaneClient,
    private readonly agentAccess: AgentAccessService,
  ) {}

  // ── Pipelines (read) ─────────────────────────────────────────────────────
  listPipelines(): Promise<unknown> {
    return this.client.request('pipelines.list');
  }

  getPipeline(name: string): Promise<unknown> {
    return this.client.request('pipelines.get', { name });
  }

  // ── MCP (read + mutations) ─────────────────────────────────────────────────
  listMcp(): Promise<unknown> {
    return this.client.request('mcp.list');
  }

  mcpRegistry(): Promise<unknown> {
    return this.client.request('mcp.registry');
  }

  /** [MUTATIVE — settings.json mcpServers] */
  addMcp(dto: CreateMcpConnectorDto): Promise<unknown> {
    return this.client.request('mcp.add', { ...dto });
  }

  /** [MUTATIVE — settings.json mcpServers] */
  updateMcp(id: string, dto: UpdateMcpConnectorDto): Promise<unknown> {
    return this.client.request('mcp.update', { id, ...dto });
  }

  /** [MUTATIVE — settings.json mcpServers] */
  removeMcp(id: string): Promise<unknown> {
    return this.client.request('mcp.remove', { id });
  }

  // ── Profiles (mutations) ───────────────────────────────────────────────────
  /** [MUTATIVE — ~/.ada.json activeProfile] */
  switchProfile(profile: string): Promise<unknown> {
    return this.client.request('profiles.switch', { profile });
  }

  /** [MUTATIVE — ~/.ada.json installedProfiles] */
  createProfile(name: string, activate?: boolean): Promise<unknown> {
    return this.client.request('profiles.create', { name, activate: !!activate });
  }

  // ── Teams (read + mutations) ───────────────────────────────────────────────
  listTeams(): Promise<unknown> {
    return this.client.request('teams.list');
  }

  getTeam(id: string): Promise<unknown> {
    return this.client.request('teams.get', { id });
  }

  /** [MUTATIVE — coordinator/teams.json] */
  createTeam(dto: CreateTeamDto): Promise<unknown> {
    return this.client.request('teams.create', { ...dto });
  }

  /** [MUTATIVE — coordinator/teams.json] */
  updateTeam(id: string, dto: UpdateTeamDto): Promise<unknown> {
    return this.client.request('teams.update', { id, ...dto });
  }

  /** [MUTATIVE — coordinator/teams.json] */
  removeTeam(id: string): Promise<unknown> {
    return this.client.request('teams.remove', { id });
  }

  // ── Agent detail (read) ────────────────────────────────────────────────────
  /**
   * Détail d'agent enrichi (TÂCHE A+B) :
   *  - `agent.mcps`   : serveurs MCP CONFIGURÉS accessibles (source réelle =
   *    RPC `mcp.list`, même que GET /api/mcp/connectors). Vide tant qu'aucun
   *    serveur n'est configuré dans settings.json (vide honnête, pas d'invention).
   *  - `agent.skills` : skills DISPONIBLES accessibles (source réelle = RPC
   *    `skills.list` → available[]). L'agents.info renvoyait `skills` depuis le
   *    frontmatter `skills:` (absent → toujours vide) ; on l'écrase ici.
   *
   * L'accessibilité dépend du frontmatter `tools` de l'agent (cf.
   * AgentAccessService). Enrichissement fait côté ada-api-nest après la RPC.
   */
  async agentInfo(slug: string): Promise<AgentInfoResult> {
    const info = await this.client.request<AgentInfoResult>('agents.info', { slug });
    if (!info || typeof info !== 'object' || !info.agent) return info;

    // Sources réelles, en parallèle ; dégradation gracieuse si une RPC échoue.
    const [configuredMcp, availableSkills] = await Promise.all([
      this.client
        .request<McpListResult>('mcp.list')
        .then((r) =>
          (r.connectors ?? [])
            .map((c) => c.name ?? c.id ?? '')
            .filter((n): n is string => !!n),
        )
        .catch(() => [] as string[]),
      this.client
        .request<SkillsListResult>('skills.list')
        .then((r) =>
          (r.available ?? [])
            .map((s) => s.name ?? '')
            .filter((n): n is string => !!n),
        )
        .catch(() => [] as string[]),
    ]);

    info.agent.mcps = this.agentAccess.resolveMcps(slug, configuredMcp);
    info.agent.skills = this.agentAccess.resolveSkills(slug, availableSkills);
    return info;
  }

  // ── Settings (read + mutation) ─────────────────────────────────────────────
  getSettings(): Promise<unknown> {
    return this.client.request('settings.get');
  }

  /** [MUTATIVE — ~/.ada.json] */
  setSettings(dto: UpdateSettingsDto): Promise<unknown> {
    return this.client.request('settings.set', { ...dto });
  }
}
