import { IsBoolean, IsIn, IsOptional, IsString, Matches, MaxLength, MinLength } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

/** PUT /providers — switch the provider mode (mutates ~/.ada.json). */
export class SetProviderDto {
  @ApiProperty({ description: 'Mode fournisseur', enum: ['claude-code', 'api'], example: 'claude-code' })
  @IsIn(['claude-code', 'api'])
  mode!: 'claude-code' | 'api';
}

/** POST /obsidian/status — bascule rapide enabled (mutates ~/.ada.json), sans
 * passer par le formulaire settings global (voir ADR obsidian.setEnabled). */
export class ObsidianToggleDto {
  @ApiProperty({ description: 'Nouvel état de la synchronisation Obsidian', example: false })
  @IsBoolean()
  enabled!: boolean;
}

/** POST /schedules — add a scheduled pipeline (mutates ~/.ada.json). */
export class CreateScheduleDto {
  @ApiProperty({ description: 'Pipeline à planifier', example: 'feature' })
  @IsString()
  @MinLength(1)
  @MaxLength(64)
  pipeline!: string;

  @ApiProperty({ description: 'Expression cron', example: '0 9 * * 1' })
  @IsString()
  @MinLength(1)
  @MaxLength(128)
  cron!: string;

  @ApiPropertyOptional({ description: 'Nom lisible du schedule', example: 'Lundi matin' })
  @IsOptional()
  @IsString()
  @MaxLength(128)
  name?: string;
}

/** POST /skills — install a skill by name (spawn/copy; rate-limited). */
export class InstallSkillDto {
  @ApiProperty({ description: 'Nom du skill à installer', example: 'create-module' })
  @IsString()
  @MinLength(1)
  @MaxLength(128)
  // Safe filename only — defence in depth (ada-core also validates).
  @Matches(/^[a-zA-Z0-9._-]+$/, { message: 'name: caractères autorisés a-z 0-9 . _ -' })
  name!: string;
}

/** POST /daemon/run — trigger a worker now (spawn detached; rate-limited). */
export class DaemonRunDto {
  @ApiProperty({ description: 'Nom du worker daemon', example: 'consolidate' })
  @IsString()
  @MinLength(1)
  @MaxLength(64)
  @Matches(/^[a-zA-Z0-9._-]+$/, { message: 'worker: caractères autorisés a-z 0-9 . _ -' })
  worker!: string;
}
