import { IsIn, IsInt, IsOptional, IsString, Max, MaxLength, Min, MinLength } from 'class-validator';
import { Type } from 'class-transformer';
import { ApiPropertyOptional } from '@nestjs/swagger';

/** Free-text search query (agents/skills search). */
export class SearchQueryDto {
  @ApiPropertyOptional({ description: 'Terme de recherche', example: 'nestjs' })
  @IsOptional()
  @IsString()
  @MinLength(1)
  @MaxLength(128)
  q?: string;
}

/** Optional category + cross-profile filter for GET /agents. */
export class AgentsQueryDto {
  @ApiPropertyOptional({ description: 'Filtre par source/catégorie', example: 'ada' })
  @IsOptional()
  @IsString()
  @MaxLength(64)
  category?: string;

  // 2026-08-13 : chaque profil a son propre <profileDir>/agents/ sur disque —
  // scoping cross-profil sans reconnexion control-plane (voir agents.list dans
  // control-handlers.js). Forme courte ("ov") ou complète ("claude-ov")
  // acceptées, normalisées côté control-server (même convention que
  // profiles.switch). Absent => profil du process courant (comportement
  // historique inchangé).
  @ApiPropertyOptional({ description: 'Profil à interroger (défaut : profil courant du process)', example: 'ov' })
  @IsOptional()
  @IsString()
  @MaxLength(64)
  profile?: string;
}

/** Tail query for GET /logs. */
export class LogsQueryDto {
  @ApiPropertyOptional({ description: 'Source du log', enum: ['events', 'daemon'], example: 'events' })
  @IsOptional()
  @IsIn(['events', 'daemon'])
  source?: 'events' | 'daemon';

  @ApiPropertyOptional({ description: 'Nombre de lignes (1-1000)', example: 100 })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(1000)
  lines?: number;
}
