import {
  IsArray,
  IsBoolean,
  IsIn,
  IsObject,
  IsOptional,
  IsString,
  IsUrl,
  Matches,
  MaxLength,
  MinLength,
} from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

/**
 * P7 — DTOs des features de configuration (pipelines, MCP, profils, teams,
 * settings). Validés sur tous les endpoints ; les mutations sont relayées au
 * Control Server (NestJS ne mute pas l'état). Pas de secret renvoyé en clair.
 */

const SAFE_CONNECTOR = /^[a-z0-9][a-z0-9_-]{0,63}$/;
const SAFE_PROFILE = /^[a-z0-9][a-z0-9-]{0,30}$/;

// ── MCP connectors ─────────────────────────────────────────────────────────

/** POST /mcp/connectors — ajoute un serveur MCP (mute settings.json mcpServers). */
export class CreateMcpConnectorDto {
  @ApiProperty({ description: 'Identifiant du connecteur', example: 'github' })
  @IsString()
  @Matches(SAFE_CONNECTOR, { message: 'id: a-z 0-9 _ - (commence par alphanumérique)' })
  id!: string;

  @ApiPropertyOptional({ description: 'Commande (transport stdio)', example: 'npx' })
  @IsOptional()
  @IsString()
  @MaxLength(512)
  command?: string;

  @ApiPropertyOptional({ description: 'URL (transport http/sse)', example: 'https://mcp.example.com' })
  @IsOptional()
  @IsString()
  @MaxLength(2048)
  url?: string;

  @ApiPropertyOptional({ description: 'Arguments de la commande', type: [String] })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  args?: string[];

  @ApiPropertyOptional({ description: 'Variables d’environnement (clé→valeur)', type: Object })
  @IsOptional()
  @IsObject()
  env?: Record<string, string>;
}

/** PATCH /mcp/connectors/:id — met à jour un serveur MCP. */
export class UpdateMcpConnectorDto {
  @ApiPropertyOptional({ description: 'Commande (transport stdio)' })
  @IsOptional()
  @IsString()
  @MaxLength(512)
  command?: string;

  @ApiPropertyOptional({ description: 'URL (transport http/sse)' })
  @IsOptional()
  @IsString()
  @MaxLength(2048)
  url?: string;

  @ApiPropertyOptional({ type: [String] })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  args?: string[];

  @ApiPropertyOptional({ type: Object })
  @IsOptional()
  @IsObject()
  env?: Record<string, string>;

  @ApiPropertyOptional({ description: 'Activer/désactiver le connecteur' })
  @IsOptional()
  @IsBoolean()
  enabled?: boolean;
}

// ── Profils ──────────────────────────────────────────────────────────────────

/** PUT /profiles/active — bascule le profil actif (mute ~/.ada.json). */
export class SwitchProfileDto {
  @ApiProperty({ description: 'Nom du profil (sans préfixe claude-)', example: 'pro' })
  @IsString()
  @Matches(SAFE_PROFILE, { message: 'profile: a-z 0-9 - (commence par alphanumérique)' })
  profile!: string;
}

/** POST /profiles — enregistre un profil (mute ~/.ada.json). */
export class CreateProfileDto {
  @ApiProperty({ description: 'Nom du profil (sans préfixe claude-)', example: 'client-x' })
  @IsString()
  @Matches(SAFE_PROFILE, { message: 'name: a-z 0-9 - (commence par alphanumérique)' })
  name!: string;

  @ApiPropertyOptional({ description: 'Activer immédiatement le profil créé' })
  @IsOptional()
  @IsBoolean()
  activate?: boolean;
}

// ── Teams ──────────────────────────────────────────────────────────────────

/** POST /teams — crée une team (mute coordinator/teams.json). */
export class CreateTeamDto {
  @ApiProperty({ description: 'Nom de la team', example: 'fullstack' })
  @IsString()
  @MinLength(1)
  @MaxLength(64)
  name!: string;

  @ApiProperty({ description: 'Agents membres', type: [String], example: ['nestjs', 'nextjs', 'db'] })
  @IsArray()
  @IsString({ each: true })
  agents!: string[];

  @ApiPropertyOptional({ description: 'Pipeline par défaut', example: 'feature' })
  @IsOptional()
  @IsString()
  @MaxLength(64)
  pipeline?: string;

  @ApiPropertyOptional({ description: 'Description', example: 'NestJS + Next.js + DB' })
  @IsOptional()
  @IsString()
  @MaxLength(1000)
  description?: string;
}

/** PATCH /teams/:id — met à jour une team. */
export class UpdateTeamDto {
  @ApiPropertyOptional({ description: 'Nom de la team' })
  @IsOptional()
  @IsString()
  @MinLength(1)
  @MaxLength(64)
  name?: string;

  @ApiPropertyOptional({ type: [String] })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  agents?: string[];

  @ApiPropertyOptional({ description: 'Pipeline par défaut' })
  @IsOptional()
  @IsString()
  @MaxLength(64)
  pipeline?: string;

  @ApiPropertyOptional({ description: 'Description' })
  @IsOptional()
  @IsString()
  @MaxLength(1000)
  description?: string;
}

// ── Settings ─────────────────────────────────────────────────────────────────

/** Bloc webhook des settings (secret jamais renvoyé en clair). */
export class WebhookSettingsDto {
  @ApiProperty({ description: 'URL du webhook (http/https)', example: 'https://hooks.example.com/ada' })
  @IsUrl({ require_protocol: true, protocols: ['http', 'https'] })
  @MaxLength(2048)
  url!: string;

  @ApiPropertyOptional({ description: 'Événements souscrits', type: [String] })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  events?: string[];

  @ApiPropertyOptional({ description: 'Secret de signature (stocké, jamais renvoyé)' })
  @IsOptional()
  @IsString()
  @MaxLength(512)
  secret?: string;
}

/** PUT /settings — vue agrégée mutable de ~/.ada.json. */
export class UpdateSettingsDto {
  @ApiPropertyOptional({ description: 'Mode fournisseur', enum: ['claude-code', 'api'] })
  @IsOptional()
  @IsIn(['claude-code', 'api'])
  providerMode?: 'claude-code' | 'api';

  @ApiPropertyOptional({ description: 'Config budget (cap mensuel, seuil, blocage)', type: Object })
  @IsOptional()
  @IsObject()
  budget?: Record<string, unknown>;

  @ApiPropertyOptional({ description: 'Config Obsidian', type: Object })
  @IsOptional()
  @IsObject()
  obsidian?: Record<string, unknown>;

  @ApiPropertyOptional({ description: 'Config webhook (null pour retirer)', type: WebhookSettingsDto, nullable: true })
  @IsOptional()
  webhook?: WebhookSettingsDto | null;
}
