import { Module } from '@nestjs/common';
import { AppConfigModule } from './config/config.module.js';
import { AuthModule } from './auth/auth.module.js';
import { ControlPlaneModule } from './control-plane/control-plane.module.js';
import { OrchestrationModule } from './orchestration/orchestration.module.js';
import { PersistenceModule } from './persistence/persistence.module.js';
import { ClaudeModule } from './claude/claude.module.js';
import { AdaModule } from './ada/ada.module.js';
import { PlannerModule } from './planner/planner.module.js';
import { TasksModule } from './tasks/tasks.module.js';
import { SessionsModule } from './sessions/sessions.module.js';
import { WorkspacesModule } from './workspaces/workspaces.module.js';
import { LogsModule } from './logs/logs.module.js';
import { StatsModule } from './stats/stats.module.js';
import { MemoryModule } from './memory/memory.module.js';

@Module({
  imports: [
    AppConfigModule,
    AuthModule,
    ControlPlaneModule,
    // OrchestrationModule before PersistenceModule so the global
    // OrchestrationEvents is resolvable by the event projector.
    OrchestrationModule,
    PersistenceModule,
    // SessionsModule (P3) after Persistence: it depends on DatabaseService and
    // OrchestrationEvents (both global), and provides the SessionInboundRouter
    // the StreamGateway optionally consumes for inbound task.* messages.
    SessionsModule,
    ClaudeModule,
    AdaModule,
    PlannerModule,
    TasksModule,
    // P5: workspaces/conversations CRUD + logs persistence/retention.
    WorkspacesModule,
    LogsModule,
    // P6: dashboard agrégé & coûts temps réel (stats overview/activity/budget/timeline).
    StatsModule,
    // P8: mémoire riche (graphe navigable 3D + wiki Obsidian).
    MemoryModule,
  ],
})
export class AppModule {}
