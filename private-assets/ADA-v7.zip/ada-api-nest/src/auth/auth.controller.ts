import { Controller, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from './jwt-auth.guard.js';
import { JwtService, type IssuedToken } from './jwt.service.js';
import { Public } from './public.decorator.js';

/**
 * Émission de jetons locaux pour le bootstrap de l'UI (P6). Miroir léger de
 * ada-api/src/routes/auth.js, SANS les sessions SQLite (pas de révocation
 * persistée côté NestJS — la surface est mono-utilisateur locale).
 *
 *  - POST /auth/token   : @Public, mode local = émission directe (pas de mot de passe).
 *  - POST /auth/refresh : protégé par le guard JWT ; ré-émet un jeton frais.
 *
 * Le StreamGateway accepte ce JWT via `?token=` (auth WS sans round-trip ticket).
 */
@ApiTags('auth')
@Controller('auth')
export class AuthController {
  constructor(private readonly jwt: JwtService) {}

  @Public()
  @Post('token')
  @ApiOperation({ summary: 'Émet un JWT local (mode local : pas de mot de passe)' })
  token(): Promise<IssuedToken> {
    return this.jwt.sign();
  }

  @Post('refresh')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Ré-émet un JWT frais (jeton courant requis)' })
  refresh(): Promise<IssuedToken> {
    // Le guard a déjà validé le jeton courant ; on émet un nouveau jeton local.
    return this.jwt.sign();
  }
}
