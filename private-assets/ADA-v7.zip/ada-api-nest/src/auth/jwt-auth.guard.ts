import {
  CanActivate,
  ExecutionContext,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import type { FastifyRequest } from 'fastify';
import { JwtService, VerifyError } from './jwt.service.js';
import { AppConfigService } from '../config/app-config.service.js';
import { IS_PUBLIC_KEY } from './public.decorator.js';

/**
 * Bearer JWT guard on every protected route (mirrors ada-api auth middleware,
 * minus the SQLite session-revocation check which belongs to the Fastify app).
 * Routes flagged @Public() (e.g. /health) bypass it.
 */
@Injectable()
export class JwtAuthGuard implements CanActivate {
  constructor(
    private readonly jwt: JwtService,
    private readonly config: AppConfigService,
    private readonly reflector: Reflector,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (isPublic) return true;
    if (this.config.authDisabled) return true;

    const req = context.switchToHttp().getRequest<FastifyRequest>();
    const header = req.headers['authorization'];
    if (!header || !header.startsWith('Bearer ')) {
      throw new UnauthorizedException({
        error: 'UNAUTHORIZED',
        message: 'Missing or invalid Authorization header',
      });
    }
    const token = header.slice(7);
    try {
      const payload = await this.jwt.verify(token);
      (req as FastifyRequest & { user?: unknown }).user = payload;
      return true;
    } catch (err) {
      const code = (err as VerifyError).code;
      if (code === 'TOKEN_EXPIRED') {
        throw new UnauthorizedException({ error: 'TOKEN_EXPIRED', message: 'Token has expired' });
      }
      throw new UnauthorizedException({
        error: 'INVALID_TOKEN',
        message: 'Token signature invalid',
      });
    }
  }
}
