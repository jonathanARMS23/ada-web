import { Injectable } from '@nestjs/common';
import { SignJWT, jwtVerify } from 'jose';
import { AppConfigService } from '../config/app-config.service.js';

export interface JwtPayload {
  sub: string;
  iat?: number;
  exp?: number;
}

/** Jeton émis : valeur + expiration ISO + type Bearer (mirroir ada-api). */
export interface IssuedToken {
  token: string;
  expiresAt: string;
  tokenType: 'Bearer';
}

export type VerifyError = { code: 'TOKEN_EXPIRED' | 'INVALID_TOKEN' };

/** TTL par défaut d'un jeton local (15 min) — mirroir ada-api jwtTtlSeconds. */
const DEFAULT_TTL_SECONDS = 15 * 60;

/**
 * JWT sign + verify using jose (HS256) — mirrors ada-api/src/auth/jwt.js.
 * P6 ajoute l'émission locale (AuthController) pour le bootstrap de l'UI ;
 * pas de sessions SQLite (la révocation appartient à l'app Fastify legacy).
 */
@Injectable()
export class JwtService {
  constructor(private readonly config: AppConfigService) {}

  private get key(): Uint8Array {
    return new TextEncoder().encode(this.config.jwtSecret);
  }

  /**
   * Émet un JWT HS256 signé avec JWT_SECRET. En mode local le sujet est
   * `local` et aucune donnée sensible n'est embarquée.
   */
  async sign(
    claims: Record<string, unknown> = {},
    ttlSeconds: number = DEFAULT_TTL_SECONDS,
  ): Promise<IssuedToken> {
    const now = Math.floor(Date.now() / 1000);
    const exp = now + ttlSeconds;
    const token = await new SignJWT({ ...claims })
      .setProtectedHeader({ alg: 'HS256' })
      .setSubject(typeof claims.sub === 'string' ? claims.sub : 'local')
      .setIssuedAt(now)
      .setExpirationTime(exp)
      .sign(this.key);
    return { token, expiresAt: new Date(exp * 1000).toISOString(), tokenType: 'Bearer' };
  }

  async verify(token: string): Promise<JwtPayload> {
    try {
      const { payload } = await jwtVerify(token, this.key, { algorithms: ['HS256'] });
      return {
        sub: typeof payload.sub === 'string' ? payload.sub : 'local',
        iat: payload.iat,
        exp: payload.exp,
      };
    } catch (err) {
      const code = (err as { code?: string }).code;
      if (code === 'ERR_JWT_EXPIRED') {
        throw { code: 'TOKEN_EXPIRED' } satisfies VerifyError;
      }
      throw { code: 'INVALID_TOKEN' } satisfies VerifyError;
    }
  }
}
