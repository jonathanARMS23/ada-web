import { Controller, Get, Param, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOkResponse, ApiOperation, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/jwt-auth.guard.js';
import { Public } from '../auth/public.decorator.js';
import { ClaudeService } from './claude.service.js';
import { MemoryQueryDto } from './dto/memory-query.dto.js';
import { HealthReportDto } from './dto/health-report.dto.js';

/**
 * Read-only REST surface over the Control Server (ADR-016 §0 table).
 * Every route relays to an RPC read method; NONE mutates ada-core state (P1).
 * JWT guard applies to all routes except @Public() /health.
 */
@ApiTags('claude')
@ApiBearerAuth()
@Controller()
@UseGuards(JwtAuthGuard)
export class ClaudeController {
  constructor(private readonly service: ClaudeService) {}

  @Get('capabilities')
  @ApiOperation({ summary: 'Manifeste de capacités live (capabilities.list)' })
  capabilities() {
    return this.service.getCapabilities();
  }

  @Get('health')
  @Public()
  @ApiOperation({ summary: 'Santé Control Server + Postgres + mémoire (health.probe + db)' })
  @ApiOkResponse({ type: HealthReportDto })
  health() {
    return this.service.getHealth();
  }

  @Get('runs')
  @ApiOperation({ summary: 'Liste des runs (projection Postgres ou live run.list)' })
  runs() {
    return this.service.listRuns();
  }

  @Get('runs/:id')
  @ApiOperation({ summary: 'État complet d’un run (run.status)' })
  run(@Param('id') id: string) {
    return this.service.getRun(id);
  }

  @Get('memory')
  @ApiOperation({ summary: 'Recherche mémoire (bank.retrieve)' })
  memory(@Query() query: MemoryQueryDto) {
    return this.service.retrieveMemory(query.q);
  }

  @Get('router/stats')
  @ApiOperation({ summary: 'Stats du routeur Thompson (router.stats)' })
  routerStats() {
    return this.service.routerStats();
  }

  @Get('stats/cost')
  @ApiOperation({ summary: 'Rapport de coûts (cost.report)' })
  cost() {
    return this.service.costReport();
  }

  @Get('stats/metrics')
  @ApiOperation({ summary: 'Métriques agrégées (metrics.get)' })
  metrics() {
    return this.service.metrics();
  }
}
