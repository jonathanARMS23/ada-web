import { Injectable, NotFoundException } from '@nestjs/common';
import { desc, eq } from 'drizzle-orm';
import { ControlPlaneClient } from '../control-plane/control-plane.client.js';
import { CapabilityDiscoveryService } from '../control-plane/capability-discovery.service.js';
import { HealthProbeService, ControlPlaneStatus } from '../control-plane/health-probe.service.js';
import { DatabaseService } from '../persistence/database.service.js';
import { runs as runsTable } from '../persistence/schema.js';
import type { CapabilitiesManifest } from '../control-plane/capability-discovery.service.js';

export interface RunSummary {
  coreRunId: string;
  pipeline: string;
  status: string;
  name?: string | null;
  totalCost?: number;
  source: 'postgres' | 'control_plane';
}

export interface HealthReport {
  status: 'ok' | 'degraded';
  controlPlane: ControlPlaneStatus;
  db: 'up' | 'down' | 'disabled';
  dbError: string | null;
  /**
   * Memory-layer health (P1-2). INFORMATIVE only: `memory.degraded` does NOT
   * affect `status` — recall stays functional via TF-IDF when Ollama is down.
   */
  memory: { ollama: 'up' | 'down'; degraded: boolean };
}

/**
 * Read-only orchestration of the Control Server + Postgres projection.
 * No method here mutates ada-core state (P1 contract).
 */
@Injectable()
export class ClaudeService {
  constructor(
    private readonly client: ControlPlaneClient,
    private readonly capabilities: CapabilityDiscoveryService,
    private readonly healthProbe: HealthProbeService,
    private readonly database: DatabaseService,
  ) {}

  getCapabilities(): Promise<CapabilitiesManifest> {
    return this.capabilities.list();
  }

  async getHealth(): Promise<HealthReport> {
    const controlPlane = await this.healthProbe.status();
    const db = this.database.status;
    // `status` aggregates ONLY control-plane reachability + db. Memory health is
    // surfaced but deliberately excluded from this predicate (P1-2): a degraded
    // recall (Ollama down → TF-IDF) is still functional and must not page.
    const healthy = controlPlane.reachable && db !== 'down';
    const mem = controlPlane.probe?.memory;
    return {
      status: healthy ? 'ok' : 'degraded',
      controlPlane,
      db: db === 'disabled' ? 'down' : db, // report disabled as down for the probe
      dbError: this.database.lastError,
      memory: {
        ollama: mem?.ollama ?? 'down',
        // Prefer the core's explicit flag; fall back to deriving from ollama.
        degraded: mem ? mem.recallDegraded : true,
      },
    };
  }

  /** Runs from Postgres projection if up, else live from the Control Server. */
  async listRuns(): Promise<RunSummary[]> {
    const db = this.database.db;
    if (this.database.isUp && db) {
      const rows = await db.select().from(runsTable).orderBy(desc(runsTable.createdAt)).limit(100);
      return rows.map((r) => ({
        coreRunId: r.coreRunId,
        pipeline: r.pipeline,
        status: r.status,
        name: r.name,
        totalCost: Number(r.totalCost),
        source: 'postgres' as const,
      }));
    }
    const res = await this.client.request<{ runs: Array<Record<string, unknown>> }>('run.list');
    return (res.runs ?? []).map((r) => ({
      coreRunId: String(r.id),
      pipeline: String(r.pipeline ?? ''),
      status: String(r.status ?? ''),
      name: (r.name as string | undefined) ?? null,
      totalCost: typeof r.totalCost === 'number' ? r.totalCost : 0,
      source: 'control_plane' as const,
    }));
  }

  /** Full run state (always live from the Control Server — source of truth). */
  async getRun(id: string): Promise<unknown> {
    try {
      const res = await this.client.request<{ state: unknown }>('run.status', { runId: id });
      return res.state;
    } catch (err) {
      const code = (err as { code?: number }).code;
      if (code === 1001) throw new NotFoundException({ error: 'RUN_NOT_FOUND', message: `Run inconnu: ${id}` });
      throw err;
    }
  }

  retrieveMemory(query: string): Promise<unknown> {
    return this.client.request('bank.retrieve', { query });
  }

  routerStats(): Promise<unknown> {
    return this.client.request('router.stats');
  }

  costReport(): Promise<unknown> {
    return this.client.request('cost.report');
  }

  metrics(): Promise<unknown> {
    return this.client.request('metrics.get');
  }

  /** Convenience for the persisted projection of a single run (P1 read). */
  async getRunFromDb(id: string): Promise<unknown | null> {
    const db = this.database.db;
    if (!this.database.isUp || !db) return null;
    const rows = await db.select().from(runsTable).where(eq(runsTable.coreRunId, id)).limit(1);
    return rows[0] ?? null;
  }
}
