import { ApiProperty } from '@nestjs/swagger';

/**
 * Memory-layer health surfaced on GET /api/health (P1-2).
 *
 * INFORMATIVE only: `degraded` (recall fell back to TF-IDF because the Ollama
 * embedding backend is down) does NOT flip the global `status` to 'degraded' —
 * recall stays functional, just less semantic.
 */
export class MemoryHealthDto {
  @ApiProperty({
    enum: ['up', 'down'],
    description: 'État de la sonde Ollama (backend d’embeddings).',
    example: 'up',
  })
  ollama!: 'up' | 'down';

  @ApiProperty({
    description:
      'true si le recall est dégradé (fallback TF-IDF, Ollama indisponible). Informatif — ne fait PAS basculer le status global.',
    example: false,
  })
  degraded!: boolean;
}

/** Aggregated health of the read-only API: control plane + Postgres + memory. */
export class HealthReportDto {
  @ApiProperty({
    enum: ['ok', 'degraded'],
    description: 'Statut global (control-plane joignable ET db non-down).',
    example: 'ok',
  })
  status!: 'ok' | 'degraded';

  @ApiProperty({ description: 'État du Control Server (health.probe).', type: 'object', additionalProperties: true })
  controlPlane!: Record<string, unknown>;

  @ApiProperty({ enum: ['up', 'down', 'disabled'], description: 'État de la projection Postgres.', example: 'down' })
  db!: 'up' | 'down' | 'disabled';

  @ApiProperty({ description: 'Dernière erreur DB, sinon null.', nullable: true, example: null })
  dbError!: string | null;

  @ApiProperty({ description: 'Santé de la couche mémoire (informatif).', type: MemoryHealthDto })
  memory!: MemoryHealthDto;
}
