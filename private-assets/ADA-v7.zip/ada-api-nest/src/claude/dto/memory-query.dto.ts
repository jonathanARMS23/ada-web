import { IsString, MinLength, MaxLength } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class MemoryQueryDto {
  @ApiProperty({ description: 'Requête de recherche dans la ReasoningBank', example: 'auth nestjs jwt' })
  @IsString()
  @MinLength(1)
  @MaxLength(512)
  q!: string;
}
