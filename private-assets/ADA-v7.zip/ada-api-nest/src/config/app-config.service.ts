import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as os from 'node:os';
import * as path from 'node:path';
import * as fs from 'node:fs';
import type { Env } from './env.schema.js';

/**
 * Typed, derived configuration for the whole app. Centralises the profile /
 * socket / secret resolution so every module reads the same values
 * (mirrors control-server.js resolveProfileDir / loadIpcSecret semantics).
 */
@Injectable()
export class AppConfigService {
  constructor(private readonly config: ConfigService<Env, true>) {}

  private get<K extends keyof Env>(key: K): Env[K] {
    return this.config.get(key, { infer: true });
  }

  get nodeEnv(): Env['NODE_ENV'] {
    return this.get('NODE_ENV');
  }
  get port(): number {
    return this.get('PORT');
  }
  get host(): string {
    return this.get('HOST');
  }

  /** Profile slug used in the `hello` handshake (ADR-016 §1.4). */
  get profile(): string {
    return this.get('ADA_ACTIVE_PROFILE');
  }

  /**
   * Profile directory. Honours CLAUDE_CONFIG_DIR; else derives ~/.<profile>.
   * Matches control-server.js resolveProfileDir / profileName conventions.
   */
  get profileDir(): string {
    const explicit = this.get('CLAUDE_CONFIG_DIR');
    if (explicit) return explicit;
    return path.join(os.homedir(), `.${this.profile}`);
  }

  get controlTcpPort(): number | undefined {
    return this.get('ADA_CONTROL_TCP');
  }

  get controlSocketPath(): string {
    return this.get('ADA_CONTROL_SOCKET') ?? path.join(this.profileDir, 'control.sock');
  }

  get eventsLogPath(): string {
    return this.get('ADA_EVENTS_LOG') ?? path.join(this.profileDir, 'events.ndjson');
  }

  /**
   * HMAC secret shared with the Control Server. Resolution order mirrors
   * ipc-emit.loadIpcSecret: env var → ~/.ada/ipc.secret → null (unsigned).
   */
  get ipcSecret(): string | null {
    const env = this.get('ADA_IPC_HMAC_SECRET');
    if (env) return env;
    const file = path.join(os.homedir(), '.ada', 'ipc.secret');
    try {
      return fs.readFileSync(file, 'utf8').trim() || null;
    } catch {
      return null;
    }
  }

  get jwtSecret(): string {
    return this.get('JWT_SECRET');
  }
  get authDisabled(): boolean {
    return this.get('AUTH_DISABLED');
  }

  get databaseUrl(): string | undefined {
    return this.get('DATABASE_URL');
  }

  /** Applique les migrations au boot (true en dev, false en prod). */
  get dbAutoMigrate(): boolean {
    return this.get('ADA_DB_AUTO_MIGRATE');
  }

  get reconnectMinMs(): number {
    return this.get('ADA_RECONNECT_MIN_MS');
  }
  get reconnectMaxMs(): number {
    return this.get('ADA_RECONNECT_MAX_MS');
  }

  // ── P2 : moteur d'exécution ──────────────────────────────────────────────
  /** Raw executor kind (mock|cli|sdk). `cli` is a historical alias of `sdk`. */
  get executorKind(): 'mock' | 'cli' | 'sdk' {
    return this.get('ADA_EXECUTOR');
  }

  /** True when interactive sessions must use the real Claude Agent SDK (P3.5). */
  get useSdkSession(): boolean {
    const k = this.executorKind;
    return k === 'sdk' || k === 'cli';
  }

  /** Chemin absolu vers `claude` (CliExecutor). Undefined => non configuré. */
  get claudeBin(): string | undefined {
    return this.get('ADA_CLAUDE_BIN');
  }

  get phaseConcurrency(): number {
    return this.get('ADA_PHASE_CONCURRENCY');
  }

  get phaseTimeoutMs(): number {
    return this.get('ADA_PHASE_TIMEOUT_MS');
  }

  get queueName(): string {
    return this.get('ADA_QUEUE_NAME');
  }

  /**
   * Répertoire des system prompts d'agents (.claude/agents). Si non configuré,
   * dérivé en remontant depuis le profileDir vers <repo>/.claude/agents.
   */
  get agentsDir(): string {
    const explicit = this.get('ADA_AGENTS_DIR');
    if (explicit) return explicit;
    return path.join(this.profileDir, 'agents');
  }

  // ── P3 : sessions interactives + Permission Broker ─────────────────────────
  get permissionTimeoutMs(): number {
    return this.get('ADA_PERMISSION_TIMEOUT_MS');
  }

  // ── P3.5 : Claude Agent SDK + hook PreToolUse ──────────────────────────────
  /**
   * SettingSources chargés par le SDK. Charger le profil applique le CLAUDE.md
   * orchestrateur, les agents et l'allow-list `settings.json` (fast-path qui
   * court-circuite le hook PreToolUse pour les outils pré-autorisés).
   */
  get settingSources(): Array<'user' | 'project' | 'local'> {
    return this.get('ADA_SETTING_SOURCES');
  }

  /** maxTurns transmis au SDK ; undefined si non borné (0). */
  get sessionMaxTurns(): number | undefined {
    const v = this.get('ADA_SESSION_MAX_TURNS');
    return v > 0 ? v : undefined;
  }

  /**
   * @deprecated P3.5 — le binding MCP `--permission-prompt-tool` est abandonné
   * (jamais invoqué en headless). Conservé pour compat ; ignoré par la session.
   */
  get permissionPromptTool(): string {
    return this.get('ADA_PERMISSION_PROMPT_TOOL');
  }

  /**
   * @deprecated P3.5 — `--mcp-config` du broker abandonné (voir
   * SESSIONS-permission-broker.md). Toujours null en pratique.
   */
  get mcpBrokerConfigPath(): string | null {
    return this.get('ADA_MCP_BROKER_CONFIG') ?? null;
  }
}
