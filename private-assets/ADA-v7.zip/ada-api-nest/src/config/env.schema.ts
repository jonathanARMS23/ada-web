import { z } from 'zod';

/**
 * Typed environment schema (ADR-016 §1, §9 — no secrets in code).
 * Validated once at boot; a bad env fails fast with a clear message.
 */
export const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  PORT: z.coerce.number().int().positive().default(3010),
  HOST: z.string().default('127.0.0.1'),

  // Profil ada-core ciblé (isolation CLAUDE_CONFIG_DIR — ADR-016 §1.1).
  ADA_ACTIVE_PROFILE: z.string().default('claude-pro'),
  // Répertoire profil. Si absent, dérivé de ~/.<ADA_ACTIVE_PROFILE>.
  CLAUDE_CONFIG_DIR: z.string().optional(),

  // Transport Control Plane (UDS par défaut, TCP loopback en fallback).
  ADA_CONTROL_TCP: z.coerce.number().int().positive().optional(),
  // Chemin socket explicite (sinon <profileDir>/control.sock).
  ADA_CONTROL_SOCKET: z.string().optional(),
  // Journal events rejouable (sinon <profileDir>/events.ndjson).
  ADA_EVENTS_LOG: z.string().optional(),

  // Secret HMAC partagé avec le Control Server (~/.ada/ipc.secret si absent).
  ADA_IPC_HMAC_SECRET: z.string().optional(),

  // JWT (jose HS256), réutilisé tel quel de ada-api/src/auth.
  JWT_SECRET: z.string().min(16, 'JWT_SECRET trop court (>= 16 chars)'),
  // Désactive le guard JWT (dev/tests uniquement).
  AUTH_DISABLED: z
    .enum(['true', 'false'])
    .default('false')
    .transform((v) => v === 'true'),

  // Postgres (ADR-017). Optionnel : absence = mode dégradé (db:down).
  DATABASE_URL: z.string().optional(),
  // Appliquer les migrations au boot (dev/local). Mettre 'false' en prod où les
  // migrations sont délibérées (`npm run db:migrate` en CI/déploiement).
  ADA_DB_AUTO_MIGRATE: z
    .enum(['true', 'false'])
    .default('true')
    .transform((v) => v === 'true'),

  // Backoff reconnexion Control Plane (ADR-016 §7).
  ADA_RECONNECT_MIN_MS: z.coerce.number().int().positive().default(1000),
  ADA_RECONNECT_MAX_MS: z.coerce.number().int().positive().default(30000),

  // ── P2 : moteur d'exécution (ADR-016 §5/§6, ROADMAP P2) ───────────────────
  // Sélection de l'executor de phase / session : mock (défaut, tests/dev) ou
  // sdk (réel, via @anthropic-ai/claude-agent-sdk — P3.5). `cli` reste accepté
  // comme alias historique de `sdk` (l'ancien spawn `claude -p` est déprécié).
  ADA_EXECUTOR: z.enum(['mock', 'cli', 'sdk']).default('mock'),
  // Chemin ABSOLU vers le binaire `claude` (CliExecutor). Requis si ADA_EXECUTOR=cli.
  ADA_CLAUDE_BIN: z.string().optional(),
  // Concurrence max des phases parallel_mesh (borne le fan-out — ADR-016 §5).
  ADA_PHASE_CONCURRENCY: z.coerce.number().int().positive().default(3),
  // Racine du dépôt agents (.claude/agents) pour résoudre les system prompts.
  ADA_AGENTS_DIR: z.string().optional(),
  // Timeout (ms) d'exécution d'une phase via l'executor.
  ADA_PHASE_TIMEOUT_MS: z.coerce.number().int().positive().default(600000),
  // Nom de la file pg-boss pour l'orchestration.
  ADA_QUEUE_NAME: z.string().default('orchestrate'),

  // ── P3 : sessions interactives + Permission Broker (ADR-016 §6bis) ─────────
  // Timeout (ms) d'attente d'une réponse de permission (ask) avant deny.
  ADA_PERMISSION_TIMEOUT_MS: z.coerce.number().int().positive().default(120000),

  // ── P3.5 : Claude Agent SDK + hook PreToolUse (mécanisme validé live) ──────
  // SettingSources chargés par le SDK (CSV : user,project,local). Charger le
  // profil permet au CLAUDE.md orchestrateur + agents + allow-list de
  // s'appliquer ; l'allow-list `settings.json` court-circuite le hook pour les
  // outils pré-autorisés (fast-path echo/git/npm). Le hook gère le reste
  // (Fork #2). Vide ("") => aucune source (le hook gère TOUT).
  ADA_SETTING_SOURCES: z
    .string()
    .default('user,project,local')
    .transform((v) =>
      v
        .split(',')
        .map((s) => s.trim())
        .filter((s): s is 'user' | 'project' | 'local' => s === 'user' || s === 'project' || s === 'local'),
    ),
  // maxTurns transmis au SDK query() (borne anti-boucle d'une session). 0 = défaut SDK.
  ADA_SESSION_MAX_TURNS: z.coerce.number().int().nonnegative().default(0),

  // @deprecated P3.5 — binding MCP `--permission-prompt-tool` ABANDONNÉ
  // (jamais invoqué en headless, cf. SESSIONS-permission-broker.md). Conservés
  // pour compat de config ; ignorés par SdkInteractiveSession.
  ADA_PERMISSION_PROMPT_TOOL: z.string().default('mcp__ada__approve'),
  ADA_MCP_BROKER_CONFIG: z.string().optional(),
});

export type Env = z.infer<typeof envSchema>;

export function validateEnv(raw: Record<string, unknown>): Env {
  const parsed = envSchema.safeParse(raw);
  if (!parsed.success) {
    const issues = parsed.error.issues
      .map((i) => `  - ${i.path.join('.') || '(root)'}: ${i.message}`)
      .join('\n');
    throw new Error(`Configuration d'environnement invalide :\n${issues}`);
  }
  return parsed.data;
}
