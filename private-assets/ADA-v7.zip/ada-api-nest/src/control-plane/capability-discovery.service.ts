import { Injectable } from '@nestjs/common';
import { ControlPlaneClient } from './control-plane.client.js';

export interface CapabilitiesManifest {
  protocolVersion: string;
  methods: string[];
  events: string[];
  [k: string]: unknown;
}

/** Wraps `capabilities.list` (ADR-016 §4). */
@Injectable()
export class CapabilityDiscoveryService {
  constructor(private readonly client: ControlPlaneClient) {}

  list(): Promise<CapabilitiesManifest> {
    return this.client.request<CapabilitiesManifest>('capabilities.list');
  }
}
