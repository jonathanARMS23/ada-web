import {
  Injectable,
  Logger,
  OnModuleDestroy,
  OnModuleInit,
  ServiceUnavailableException,
} from '@nestjs/common';
import { EventEmitter } from 'node:events';
import * as net from 'node:net';
import { randomUUID } from 'node:crypto';
import { AppConfigService } from '../config/app-config.service.js';
import { attachSignature, verify } from './ipc-canonical.js';
import { EventsLogReplayer } from './events-log-replayer.js';
import type {
  ConnectionState,
  ControlEvent,
  HelloResult,
  JsonRpcResponse,
  RunDoneResult,
  RunFailResult,
  RunInitResult,
  RunNextResult,
  RunStartResult,
} from './control-plane.types.js';

const PROTOCOL_VERSION = '1.0.0';
const REQUEST_TIMEOUT_MS = 10_000;

interface Pending {
  resolve: (v: unknown) => void;
  reject: (e: Error) => void;
  timer: NodeJS.Timeout;
}

/**
 * Client for the ada-core Control Server (ADR-016, control-server.js).
 *
 * - Transport: Unix socket `<profileDir>/control.sock`, TCP loopback fallback
 *   when ADA_CONTROL_TCP is set.
 * - Framing: JSON-RPC 2.0 over NDJSON, one signed frame per line.
 * - Auth: HMAC per frame via the canonical serialisation (ipc-canonical port).
 * - Handshake: `hello` with protocolVersion 1.0.0 + profile before any method.
 * - Events: `subscribe` to the live stream; on every (re)connect replay
 *   events.ndjson past the cursor (G2/G3) so nothing is missed during outages.
 * - Reconnect: exponential backoff 1s -> 30s.
 *
 * Read-only by contract (P1): exposes only the read methods of §2; no run.init/
 * start/done/fail or any state-mutating call is wired here.
 */
@Injectable()
export class ControlPlaneClient extends EventEmitter implements OnModuleInit, OnModuleDestroy {
  private readonly log = new Logger(ControlPlaneClient.name);

  private socket: net.Socket | null = null;
  private buffer = '';
  private state: ConnectionState = 'disconnected';
  private readonly pending = new Map<string, Pending>();
  private reconnectTimer: NodeJS.Timeout | null = null;
  private replayTimer: NodeJS.Timeout | null = null;
  private backoff: number;
  private destroyed = false;
  private serverInfo: HelloResult | null = null;
  private readonly replayer: EventsLogReplayer;
  private readonly secret: string | null;

  constructor(private readonly config: AppConfigService) {
    super();
    this.setMaxListeners(0);
    this.backoff = config.reconnectMinMs;
    this.secret = config.ipcSecret;
    this.replayer = new EventsLogReplayer(config.eventsLogPath);
  }

  onModuleInit(): void {
    // Skip historical events; only stream/replay what happens from now on.
    this.replayer.seekToEnd();
    this.connect();
    // Periodic cursor drain catches hors-bande events (CLI/daemon writes) even
    // when the live socket subscription missed them or is down.
    this.replayTimer = setInterval(() => this.drainReplay(), 1000);
    this.replayTimer.unref?.();
  }

  onModuleDestroy(): void {
    this.destroyed = true;
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    if (this.replayTimer) clearInterval(this.replayTimer);
    for (const [, p] of this.pending) {
      clearTimeout(p.timer);
      p.reject(new Error('Control plane client shutting down'));
    }
    this.pending.clear();
    this.socket?.destroy();
    this.socket = null;
  }

  // ── Public API ───────────────────────────────────────────────────────────

  get connectionState(): ConnectionState {
    return this.state;
  }

  get ready(): boolean {
    return this.state === 'ready';
  }

  get server(): HelloResult | null {
    return this.serverInfo;
  }

  /**
   * Issues a JSON-RPC request and resolves with `result`. Throws a mapped
   * ServiceUnavailableException if not connected, or an Error carrying the
   * JSON-RPC error code on a remote failure.
   */
  async request<T = unknown>(method: string, params: Record<string, unknown> = {}): Promise<T> {
    if (this.state !== 'ready') {
      throw new ServiceUnavailableException({
        error: 'CONTROL_PLANE_UNAVAILABLE',
        message: `Control Server injoignable (état: ${this.state})`,
      });
    }
    return this.send<T>(method, params);
  }

  // ── P2: run.* mutations (ADR-016 §2/§5) ────────────────────────────────────
  //
  // The OrchestrationLoop drives the run lifecycle EXCLUSIVELY through these RPC
  // calls. NestJS NEVER writes state.json directly — only the Control Server
  // mutates state (ROADMAP P2 risk #2). These are thin typed wrappers over
  // request() so the loop reads strongly-typed results.

  runInit(params: {
    pipeline: string;
    feature: string;
    flags?: string[];
    correlation?: { workspaceId?: string; conversationId?: string };
  }): Promise<RunInitResult> {
    return this.request<RunInitResult>('run.init', { ...params });
  }

  runNext(runId: string): Promise<RunNextResult> {
    return this.request<RunNextResult>('run.next', { runId });
  }

  runStart(runId: string, phaseId: string): Promise<RunStartResult> {
    return this.request<RunStartResult>('run.start', { runId, phaseId });
  }

  runDone(params: {
    runId: string;
    phaseId: string;
    summary?: string;
    tokens?: number;
    cost?: number;
  }): Promise<RunDoneResult> {
    return this.request<RunDoneResult>('run.done', { ...params });
  }

  runFail(params: {
    runId: string;
    phaseId: string;
    error: string;
    retry?: boolean;
    tokens?: number;
    cost?: number;
  }): Promise<RunFailResult> {
    return this.request<RunFailResult>('run.fail', { ...params });
  }

  // ── Connection lifecycle ───────────────────────────────────────────────────

  private connect(): void {
    if (this.destroyed || this.socket) return;
    this.state = 'connecting';

    const tcpPort = this.config.controlTcpPort;
    const sock = tcpPort
      ? net.createConnection({ host: '127.0.0.1', port: tcpPort })
      : net.createConnection({ path: this.config.controlSocketPath });

    this.socket = sock;
    sock.setEncoding('utf8');

    sock.once('connect', () => {
      this.log.log(
        tcpPort
          ? `Connecté au Control Server (tcp 127.0.0.1:${tcpPort})`
          : `Connecté au Control Server (uds ${this.config.controlSocketPath})`,
      );
      void this.handshake();
    });

    sock.on('data', (chunk: string) => this.onData(chunk));
    sock.on('error', (err) => {
      // Connection-time errors are expected when the server is down.
      this.log.debug(`Socket error: ${(err as Error).message}`);
    });
    sock.once('close', () => this.onClose());
  }

  private async handshake(): Promise<void> {
    this.state = 'handshaking';
    try {
      const result = await this.send<HelloResult>('hello', {
        protocolVersion: PROTOCOL_VERSION,
        client: 'ada-api-nest/0.1.0',
        profile: this.config.profile,
      });
      this.serverInfo = result;
      this.state = 'ready';
      this.backoff = this.config.reconnectMinMs;
      this.log.log(`Handshake OK (profile=${result.profile} serverPid=${result.serverPid})`);

      // Subscribe to the live event stream (fire-and-forget; server replies ok).
      this.send('subscribe', {}).catch(() => undefined);
      // Replay anything appended while we were down, then emit ready.
      this.drainReplay();
      this.emit('ready', result);
    } catch (err) {
      this.log.warn(`Handshake échoué: ${(err as Error).message}`);
      this.socket?.destroy();
    }
  }

  private onClose(): void {
    const wasReady = this.state === 'ready';
    this.socket = null;
    this.buffer = '';
    this.state = 'disconnected';
    this.serverInfo = null;
    // Reject in-flight requests so callers don't hang.
    for (const [id, p] of this.pending) {
      clearTimeout(p.timer);
      p.reject(new Error('Connexion Control Server perdue'));
      this.pending.delete(id);
    }
    if (wasReady) {
      this.log.warn('Connexion Control Server perdue — reconnexion programmée');
      this.emit('disconnected');
    }
    this.scheduleReconnect();
  }

  private scheduleReconnect(): void {
    if (this.destroyed || this.reconnectTimer) return;
    const delay = this.backoff;
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      this.connect();
    }, delay);
    this.reconnectTimer.unref?.();
    // Exponential backoff 1s -> 30s (ADR-016 §7).
    this.backoff = Math.min(this.backoff * 2, this.config.reconnectMaxMs);
  }

  // ── Framing ────────────────────────────────────────────────────────────────

  private onData(chunk: string): void {
    this.buffer += chunk;
    let idx: number;
    while ((idx = this.buffer.indexOf('\n')) !== -1) {
      const line = this.buffer.slice(0, idx);
      this.buffer = this.buffer.slice(idx + 1);
      if (line.trim()) this.onLine(line);
    }
  }

  private onLine(line: string): void {
    let frame: Record<string, unknown>;
    try {
      frame = JSON.parse(line) as Record<string, unknown>;
    } catch {
      this.log.debug('Frame non-JSON ignorée');
      return;
    }

    // Verify HMAC on every inbound frame when a secret is configured.
    if (this.secret && !verify(frame, this.secret)) {
      this.log.warn('Frame entrante avec HMAC invalide — ignorée');
      return;
    }

    // Event notification: control-server emits raw {id, ts, type, corr, payload}
    // (no jsonrpc wrapper) on events.ndjson and to subscribers.
    if (typeof frame.type === 'string' && typeof frame.id === 'string' && !('jsonrpc' in frame)) {
      this.emitEvent(frame as unknown as ControlEvent);
      return;
    }

    // JSON-RPC response.
    const resp = frame as unknown as JsonRpcResponse;
    if (typeof resp.id === 'string' && this.pending.has(resp.id)) {
      const p = this.pending.get(resp.id)!;
      this.pending.delete(resp.id);
      clearTimeout(p.timer);
      if (resp.error) {
        const e = new Error(resp.error.message) as Error & { code?: number; data?: unknown };
        e.code = resp.error.code;
        e.data = resp.error.data;
        p.reject(e);
      } else {
        p.resolve(resp.result);
      }
    }
  }

  private send<T>(method: string, params: Record<string, unknown>): Promise<T> {
    const id = randomUUID();
    const frame: Record<string, unknown> = { jsonrpc: '2.0', id, method, params };
    const line = JSON.stringify(this.secret ? attachSignature(frame, this.secret) : frame) + '\n';

    return new Promise<T>((resolve, reject) => {
      if (!this.socket || this.socket.destroyed) {
        return reject(new Error('Socket non connecté'));
      }
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`Timeout RPC ${method} (${REQUEST_TIMEOUT_MS}ms)`));
      }, REQUEST_TIMEOUT_MS);
      timer.unref?.();
      this.pending.set(id, {
        resolve: resolve as (v: unknown) => void,
        reject,
        timer,
      });
      this.socket.write(line, (err) => {
        if (err) {
          clearTimeout(timer);
          this.pending.delete(id);
          reject(err);
        }
      });
    });
  }

  // ── Events ───────────────────────────────────────────────────────────────

  private readonly seen = new Set<string>();

  private emitEvent(evt: ControlEvent): void {
    if (this.seen.has(evt.id)) return;
    this.seen.add(evt.id);
    // Bound the dedup set so it can't grow unbounded.
    if (this.seen.size > 50_000) {
      this.seen.clear();
      this.seen.add(evt.id);
    }
    this.emit('event', evt);
  }

  private drainReplay(): void {
    try {
      for (const evt of this.replayer.drain()) this.emitEvent(evt);
    } catch (err) {
      this.log.debug(`Replay events.ndjson échoué: ${(err as Error).message}`);
    }
  }
}
