import { Global, Module } from '@nestjs/common';
import { ControlPlaneClient } from './control-plane.client.js';
import { CapabilityDiscoveryService } from './capability-discovery.service.js';
import { HealthProbeService } from './health-probe.service.js';

@Global()
@Module({
  providers: [ControlPlaneClient, CapabilityDiscoveryService, HealthProbeService],
  exports: [ControlPlaneClient, CapabilityDiscoveryService, HealthProbeService],
})
export class ControlPlaneModule {}
