/** Wire types for the Control Plane (ADR-016 §1.2, §3). */

export interface JsonRpcRequest {
  jsonrpc: '2.0';
  id: string;
  method: string;
  params?: Record<string, unknown>;
}

export interface JsonRpcError {
  code: number;
  message: string;
  data?: unknown;
}

export interface JsonRpcResponse {
  jsonrpc: '2.0';
  id: string | null;
  result?: unknown;
  error?: JsonRpcError;
}

/** Normalised event as emitted by the Control Server (control-server.js emitEvent). */
export interface ControlEvent {
  id: string;
  ts: number;
  type: string;
  corr?: {
    runId?: string | null;
    workspaceId?: string | null;
    conversationId?: string | null;
  };
  payload?: Record<string, unknown>;
}

export type ConnectionState = 'disconnected' | 'connecting' | 'handshaking' | 'ready';

export interface HelloResult {
  protocolVersion: string;
  profile: string;
  serverPid: number;
}

// ── P2 : types des méthodes run.* mutantes (ADR-016 §2) ──────────────────────

export interface RunInitResult {
  runId: string | null;
  output?: string;
}

/** Une phase prête, telle que renvoyée par `run.next` (ADR-016 §2). */
export interface ReadyPhase {
  phaseId: string;
  agent: string;
  tier: number;
  model: string;
  required: boolean;
  acwContext?: unknown;
  retryContext?: unknown;
}

export type Topology = 'sequential' | 'parallel_mesh';

export interface RunNextResult {
  runId: string;
  topology: Topology;
  ready: ReadyPhase[];
  parallelizable: string[];
}

export interface RunStartResult {
  ok: boolean;
  lockId?: string;
  output?: string;
}

export interface RunDoneResult {
  ok: boolean;
  runStatus?: string;
  output?: string;
}

export interface RunFailResult {
  ok: boolean;
  output?: string;
}
