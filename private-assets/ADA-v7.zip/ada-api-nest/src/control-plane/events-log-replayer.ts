import * as fs from 'node:fs';
import type { ControlEvent } from './control-plane.types.js';

/**
 * Replays events.ndjson by byte-offset cursor (ADR-016 §3.B, ADR-014 G2/G3).
 * On reconnect, the client replays everything appended past the last cursor it
 * saw, so no lifecycle event is lost during a Control Server outage. Dedup by
 * event `id` is the consumer's responsibility (ON CONFLICT DO NOTHING in PG).
 *
 * Cursor = byte length consumed. We only ever emit lines fully terminated by
 * `\n` (a trailing partial line is left for the next pass).
 */
export class EventsLogReplayer {
  private cursor = 0;

  constructor(private readonly logPath: string) {}

  /** Initialise the cursor to the current end of file (skip historical events). */
  seekToEnd(): void {
    try {
      this.cursor = fs.statSync(this.logPath).size;
    } catch {
      this.cursor = 0;
    }
  }

  get position(): number {
    return this.cursor;
  }

  /**
   * Reads everything appended since the last call, advancing the cursor to the
   * last full line. Lines that fail to parse are skipped (best-effort replay).
   * Note: we do NOT HMAC-verify replayed lines — they are read from our own
   * profile dir (trusted FS, 0600), and the live socket path enforces HMAC.
   */
  drain(): ControlEvent[] {
    let size: number;
    try {
      size = fs.statSync(this.logPath).size;
    } catch {
      return [];
    }
    if (size <= this.cursor) {
      // File truncated/rotated -> reset to avoid reading stale tail.
      if (size < this.cursor) this.cursor = 0;
      if (size === this.cursor) return [];
    }

    const fd = fs.openSync(this.logPath, 'r');
    try {
      const length = size - this.cursor;
      const buf = Buffer.allocUnsafe(length);
      const read = fs.readSync(fd, buf, 0, length, this.cursor);
      const text = buf.toString('utf8', 0, read);

      const lastNl = text.lastIndexOf('\n');
      if (lastNl === -1) return []; // no complete line yet

      const complete = text.slice(0, lastNl);
      this.cursor += Buffer.byteLength(complete, 'utf8') + 1; // +1 for the \n

      const events: ControlEvent[] = [];
      for (const line of complete.split('\n')) {
        if (!line.trim()) continue;
        try {
          const evt = JSON.parse(line) as ControlEvent;
          if (evt && typeof evt.id === 'string' && typeof evt.type === 'string') {
            events.push(evt);
          }
        } catch {
          // skip malformed line
        }
      }
      return events;
    } finally {
      fs.closeSync(fd);
    }
  }
}
