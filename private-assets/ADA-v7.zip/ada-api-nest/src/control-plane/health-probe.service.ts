import { Injectable } from '@nestjs/common';
import { ControlPlaneClient } from './control-plane.client.js';

/**
 * Memory-layer health relayed by the control server's `health.probe`
 * (P1-2). `ollama` is the live probe of the embedding backend; when it is
 * 'down' the recall silently degrades to TF-IDF but stays functional.
 */
export interface MemoryHealth {
  ollama: 'up' | 'down';
  recallDegraded: boolean;
  lastRecallDegradedAt: string | null;
}

export interface ControlHealth {
  status: 'ok';
  uptimeMs: number;
  pid: number;
  /** Optional: present once the core ships the P1-2 memory health block. */
  memory?: MemoryHealth;
}

export interface ControlPlaneStatus {
  reachable: boolean;
  state: string;
  protocolVersion: string | null;
  serverPid: number | null;
  probe?: ControlHealth;
}

/** Wraps `health.probe` (ADR-016 §5/§7). Never throws — reports reachability. */
@Injectable()
export class HealthProbeService {
  constructor(private readonly client: ControlPlaneClient) {}

  async status(): Promise<ControlPlaneStatus> {
    const base: ControlPlaneStatus = {
      reachable: this.client.ready,
      state: this.client.connectionState,
      protocolVersion: this.client.server?.protocolVersion ?? null,
      serverPid: this.client.server?.serverPid ?? null,
    };
    if (!this.client.ready) return base;
    try {
      const probe = await this.client.request<ControlHealth>('health.probe');
      return { ...base, reachable: true, probe };
    } catch {
      return { ...base, reachable: false };
    }
  }
}
