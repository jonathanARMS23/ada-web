import { createHmac, timingSafeEqual } from 'node:crypto';

/**
 * TypeScript port of coordinator/ipc-canonical.js — byte-identical canonical
 * serialisation + HMAC, so this client's signatures verify against the real
 * Control Server (control-server.js) and vice-versa.
 *
 * Invariants reproduced exactly:
 *  - object keys sorted lexicographically (recursive)
 *  - `_sig` always excluded from the signed payload
 *  - undefined / function / symbol omitted (JSON.stringify parity)
 *  - non-finite numbers -> "null"
 */

type Json = unknown;

export function canonicalStringify(value: Json): string {
  const out = canon(value);
  return out === undefined ? 'null' : out;
}

function canon(value: Json): string | undefined {
  if (value === null) return 'null';
  const t = typeof value;
  if (t === 'number') return Number.isFinite(value as number) ? String(value) : 'null';
  if (t === 'boolean') return value ? 'true' : 'false';
  if (t === 'string') return JSON.stringify(value);
  if (t === 'bigint') return JSON.stringify((value as bigint).toString());
  if (t === 'undefined' || t === 'function' || t === 'symbol') return undefined;

  if (Array.isArray(value)) {
    const items = value.map((v) => {
      const s = canon(v);
      return s === undefined ? 'null' : s;
    });
    return '[' + items.join(',') + ']';
  }

  const obj = value as Record<string, Json>;
  const keys = Object.keys(obj)
    .filter((k) => k !== '_sig')
    .sort();
  const parts: string[] = [];
  for (const k of keys) {
    const s = canon(obj[k]);
    if (s === undefined) continue;
    parts.push(JSON.stringify(k) + ':' + s);
  }
  return '{' + parts.join(',') + '}';
}

export function sign(payload: Record<string, unknown>, secret: string): string {
  return createHmac('sha256', secret).update(canonicalStringify(payload)).digest('hex');
}

export function verify(frame: Record<string, unknown> | null | undefined, secret: string): boolean {
  if (!frame || typeof frame !== 'object') return false;
  const provided = (frame as { _sig?: unknown })._sig;
  if (typeof provided !== 'string' || provided.length === 0) return false;
  const expected = sign(frame, secret);
  const a = Buffer.from(provided, 'utf8');
  const b = Buffer.from(expected, 'utf8');
  if (a.length !== b.length) return false;
  try {
    return timingSafeEqual(a, b);
  } catch {
    return false;
  }
}

export function attachSignature<T extends Record<string, unknown>>(
  payload: T,
  secret: string,
): T & { _sig: string } {
  return { ...payload, _sig: sign(payload, secret) };
}
