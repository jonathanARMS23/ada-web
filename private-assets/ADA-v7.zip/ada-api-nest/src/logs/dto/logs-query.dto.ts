import { IsIn, IsInt, IsISO8601, IsOptional, IsString, Max, MaxLength, Min } from 'class-validator';
import { Type } from 'class-transformer';
import { ApiPropertyOptional } from '@nestjs/swagger';

/**
 * Query of GET /logs. Filters apply to the Postgres-backed query; in live
 * fallback only `source` (events|daemon) + `limit` are honoured.
 */
export class LogsQueryDto {
  @ApiPropertyOptional({ description: 'Niveau', enum: ['debug', 'info', 'warn', 'error'] })
  @IsOptional()
  @IsIn(['debug', 'info', 'warn', 'error'])
  level?: 'debug' | 'info' | 'warn' | 'error';

  @ApiPropertyOptional({ description: 'Source (ex: orchestration, events.ndjson, daemon)' })
  @IsOptional()
  @IsString()
  @MaxLength(64)
  source?: string;

  @ApiPropertyOptional({ description: 'core_run_id à filtrer' })
  @IsOptional()
  @IsString()
  @MaxLength(128)
  run?: string;

  @ApiPropertyOptional({ description: 'Borne basse (ISO 8601)' })
  @IsOptional()
  @IsISO8601()
  from?: string;

  @ApiPropertyOptional({ description: 'Borne haute (ISO 8601)' })
  @IsOptional()
  @IsISO8601()
  to?: string;

  @ApiPropertyOptional({ description: 'Recherche texte (message ILIKE)' })
  @IsOptional()
  @IsString()
  @MaxLength(200)
  q?: string;

  @ApiPropertyOptional({ description: 'Taille de page (1-1000)', example: 100 })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(1000)
  limit?: number;

  @ApiPropertyOptional({ description: 'Curseur (id du dernier log de la page précédente)' })
  @IsOptional()
  @IsString()
  cursor?: string;
}
