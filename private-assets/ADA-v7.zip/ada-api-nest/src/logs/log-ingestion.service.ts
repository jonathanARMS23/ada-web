import { Injectable, Logger, OnModuleDestroy, OnModuleInit, Optional } from '@nestjs/common';
import * as fs from 'node:fs';
import * as readline from 'node:readline';
import { AppConfigService } from '../config/app-config.service.js';
import { ControlPlaneClient } from '../control-plane/control-plane.client.js';
import { OrchestrationEvents } from '../orchestration/orchestration-events.js';
import { DatabaseService } from '../persistence/database.service.js';
import { logs } from '../persistence/schema.js';
import type { ControlEvent } from '../control-plane/control-plane.types.js';

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
type LogLevel = 'debug' | 'info' | 'warn' | 'error';

interface LogInput {
  level: LogLevel;
  source: string;
  message: string;
  coreRunId?: string | null;
  workspaceId?: string | null;
  payload?: Record<string, unknown> | null;
  ts?: Date;
  dedupKey: string;
}

/**
 * Persists logs into the `logs` table (P5 §7). Two sources, both idempotent via
 * the UNIQUE `dedup_key`:
 *  1. The in-process OrchestrationEvents bus — run/phase lifecycle events become
 *     info/error log lines (dedup_key = event id).
 *  2. A tail of the profile's `events.ndjson` — a byte-offset cursor advances as
 *     lines arrive; each line's dedup_key is `events.ndjson:<offset>` so a replay
 *     never double-inserts.
 *
 * Degrades to a no-op + warn when the DB is down/disabled (never blocks boot).
 */
@Injectable()
export class LogIngestionService implements OnModuleInit, OnModuleDestroy {
  private readonly log = new Logger(LogIngestionService.name);
  private offset = 0;
  private watcher: fs.FSWatcher | null = null;
  private reading = false;
  private ingested = 0;

  constructor(
    private readonly config: AppConfigService,
    private readonly database: DatabaseService,
    private readonly client: ControlPlaneClient,
    @Optional() private readonly loopEvents?: OrchestrationEvents,
  ) {}

  get ingestedCount(): number {
    return this.ingested;
  }

  onModuleInit(): void {
    // Source 1: OrchestrationEvents bus (Mode A source of truth).
    this.loopEvents?.onEvent((evt) => {
      void this.ingestEvent(evt).catch((err) =>
        this.log.debug(`Ingestion log (bus) échouée: ${(err as Error).message}`),
      );
    });
    // Hors-bande Control Server events.
    this.client.on('event', (evt: ControlEvent) => {
      void this.ingestEvent(evt).catch((err) =>
        this.log.debug(`Ingestion log (control) échouée: ${(err as Error).message}`),
      );
    });

    // Source 2: tail events.ndjson (cursor + dedup).
    this.startTail();
  }

  onModuleDestroy(): void {
    this.watcher?.close();
    this.watcher = null;
  }

  // ── Source 1 : bus events ─────────────────────────────────────────────────
  /** Maps a lifecycle ControlEvent to a log row. Returns false if dropped. */
  async ingestEvent(evt: ControlEvent): Promise<boolean> {
    const level: LogLevel = evt.type.includes('failed') || evt.type.includes('error') ? 'error' : 'info';
    const corr = evt.corr ?? {};
    return this.write({
      level,
      source: 'orchestration',
      message: this.describe(evt),
      coreRunId: corr.runId ?? null,
      workspaceId: corr.workspaceId ?? null,
      payload: evt.payload ?? null,
      ts: new Date(evt.ts),
      dedupKey: `event:${evt.id}`,
    });
  }

  private describe(evt: ControlEvent): string {
    const p = evt.payload ?? {};
    const phase = typeof p.phaseId === 'string' ? ` phase=${p.phaseId}` : '';
    const agent = typeof p.agent === 'string' ? ` agent=${p.agent}` : '';
    return `${evt.type}${phase}${agent}`.trim();
  }

  // ── Source 2 : tail events.ndjson ──────────────────────────────────────────
  private startTail(): void {
    const file = this.config.eventsLogPath;
    // Read whatever already exists, then watch for appends.
    void this.drainFile(file);
    try {
      this.watcher = fs.watch(file, { persistent: false }, () => void this.drainFile(file));
    } catch {
      // File may not exist yet; a later create will be missed but ingestion via
      // the bus still works. Non-fatal.
      this.log.debug(`events.ndjson absent (${file}) — tail différé au bus`);
    }
  }

  /** Reads new bytes from `offset`, parses each NDJSON line, persists it. */
  private async drainFile(file: string): Promise<void> {
    if (this.reading) return;
    this.reading = true;
    try {
      if (!fs.existsSync(file)) return;
      const size = fs.statSync(file).size;
      if (size <= this.offset) {
        if (size < this.offset) this.offset = 0; // truncated/rotated
        return;
      }
      const stream = fs.createReadStream(file, { start: this.offset, encoding: 'utf8' });
      const rl = readline.createInterface({ input: stream, crlfDelay: Infinity });
      let consumed = this.offset;
      for await (const line of rl) {
        consumed += Buffer.byteLength(line, 'utf8') + 1; // +1 for newline
        const trimmed = line.trim();
        if (!trimmed) continue;
        await this.ingestNdjsonLine(trimmed, consumed);
      }
      this.offset = consumed;
    } catch (err) {
      this.log.debug(`Tail events.ndjson échoué: ${(err as Error).message}`);
    } finally {
      this.reading = false;
    }
  }

  private async ingestNdjsonLine(line: string, offset: number): Promise<void> {
    let evt: ControlEvent | null = null;
    try {
      evt = JSON.parse(line) as ControlEvent;
    } catch {
      return; // malformed line — skip
    }
    if (!evt || typeof evt.type !== 'string') return;
    const corr = evt.corr ?? {};
    const level: LogLevel = evt.type.includes('failed') || evt.type.includes('error') ? 'error' : 'info';
    await this.write({
      level,
      source: 'events.ndjson',
      message: this.describe(evt),
      coreRunId: corr.runId ?? null,
      workspaceId: corr.workspaceId ?? null,
      payload: evt.payload ?? null,
      ts: typeof evt.ts === 'number' ? new Date(evt.ts) : new Date(),
      dedupKey: `events.ndjson:${offset}`,
    });
  }

  // ── Write ───────────────────────────────────────────────────────────────────
  /** Inserts a log row idempotently. No-op when the DB is down. */
  async write(input: LogInput): Promise<boolean> {
    const db = this.database.db;
    if (!db || !this.database.isUp) return false; // degraded
    const workspaceId = input.workspaceId && UUID_RE.test(input.workspaceId) ? input.workspaceId : null;
    await db
      .insert(logs)
      .values({
        level: input.level,
        source: input.source,
        message: input.message,
        coreRunId: input.coreRunId ?? null,
        workspaceId,
        payload: input.payload ?? null,
        ts: input.ts ?? new Date(),
        dedupKey: input.dedupKey,
      })
      .onConflictDoNothing({ target: logs.dedupKey });
    this.ingested++;
    return true;
  }
}
