import { Injectable, Logger, OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import { LogsService } from './logs.service.js';

const DAY_MS = 24 * 60 * 60 * 1000;
const RETENTION_DAYS = 30;

/**
 * Log retention job (P5 §9). `@nestjs/schedule` is NOT a dependency of this
 * project and pg-boss schedules require the queue to be the DB-backed variant
 * (not guaranteed). So retention runs on a self-managed DAILY interval:
 *  - frequency: every 24h (and once ~30s after boot to catch a stale backlog).
 *  - action: DELETE FROM logs WHERE ts < now() - interval '30 days'.
 *
 * Daily (vs monthly) keeps the table bounded with a small, predictable delete
 * each run rather than a large monthly purge; both satisfy "≤ 30 days kept".
 * Degrades to a no-op when the DB is down (purgeOlderThan handles that).
 */
@Injectable()
export class LogRetentionService implements OnModuleInit, OnModuleDestroy {
  private readonly log = new Logger(LogRetentionService.name);
  private timer: NodeJS.Timeout | null = null;
  private kickoff: NodeJS.Timeout | null = null;

  constructor(private readonly logs: LogsService) {}

  onModuleInit(): void {
    // Initial sweep shortly after boot (don't block startup).
    this.kickoff = setTimeout(() => void this.run(), 30_000);
    this.kickoff.unref?.();
    // Then daily.
    this.timer = setInterval(() => void this.run(), DAY_MS);
    this.timer.unref?.();
  }

  onModuleDestroy(): void {
    if (this.timer) clearInterval(this.timer);
    if (this.kickoff) clearTimeout(this.kickoff);
    this.timer = null;
    this.kickoff = null;
  }

  /** Public for tests + manual trigger. */
  async run(): Promise<number> {
    try {
      return await this.logs.purgeOlderThan(RETENTION_DAYS);
    } catch (err) {
      this.log.warn(`Rétention logs échouée: ${(err as Error).message}`);
      return 0;
    }
  }
}
