import { Controller, Get, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/jwt-auth.guard.js';
import { LogsService } from './logs.service.js';
import { LogsQueryDto } from './dto/logs-query.dto.js';

/**
 * GET /logs (P5 §8). Postgres-backed filterable + paginated query when the DB is
 * up; live `logs.tail` fallback when it is down. JWT on the route.
 *
 * Supersedes the legacy AdaController `logs.tail` relay (removed there).
 */
@ApiTags('logs')
@ApiBearerAuth()
@Controller('logs')
@UseGuards(JwtAuthGuard)
export class LogsController {
  constructor(private readonly service: LogsService) {}

  @Get()
  @ApiOperation({ summary: 'Logs persistés filtrables + paginés (fallback live si DB down)' })
  query(@Query() q: LogsQueryDto) {
    return this.service.query(q);
  }
}
