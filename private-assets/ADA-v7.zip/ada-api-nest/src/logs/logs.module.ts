import { Module } from '@nestjs/common';
import { LogsController } from './logs.controller.js';
import { LogsService } from './logs.service.js';
import { LogIngestionService } from './log-ingestion.service.js';
import { LogRetentionService } from './log-retention.service.js';

/**
 * P5 — Logs persistence. DatabaseService, ControlPlaneClient and
 * OrchestrationEvents are all global (Persistence/ControlPlane/Orchestration
 * modules), so this module only wires its own providers.
 *
 *  - LogIngestionService: bus events + events.ndjson tail -> `logs` table.
 *  - LogsService:         GET /logs query (Postgres) + live fallback + purge.
 *  - LogRetentionService: daily sweep deleting logs > 30 days.
 */
@Module({
  controllers: [LogsController],
  providers: [LogsService, LogIngestionService, LogRetentionService],
  exports: [LogsService, LogIngestionService],
})
export class LogsModule {}
