import { Injectable, Logger } from '@nestjs/common';
import { and, desc, eq, gte, ilike, lt, lte, sql, type SQL } from 'drizzle-orm';
import { ControlPlaneClient } from '../control-plane/control-plane.client.js';
import { DatabaseService } from '../persistence/database.service.js';
import { logs } from '../persistence/schema.js';
import type { LogsQueryDto } from './dto/logs-query.dto.js';

type LogRow = typeof logs.$inferSelect;

export interface LogsPage {
  source: 'postgres' | 'live';
  items: LogRow[] | unknown;
  nextCursor?: string | null;
  hasMore?: boolean;
}

/**
 * GET /logs (P5 §8). When the DB is up, queries the persisted `logs` table with
 * filters (source/level/run/date range/text) + cursor pagination. When the DB is
 * down/disabled, falls back to the live `logs.tail` RPC (the historical relay),
 * so the endpoint never goes dark.
 */
@Injectable()
export class LogsService {
  private readonly log = new Logger(LogsService.name);

  constructor(
    private readonly database: DatabaseService,
    private readonly client: ControlPlaneClient,
  ) {}

  async query(q: LogsQueryDto): Promise<LogsPage> {
    const db = this.database.db;
    if (!db || !this.database.isUp) {
      // Fallback: live tail (events|daemon). `level` filters don't apply here.
      const tailSource = q.source === 'daemon' ? 'daemon' : 'events';
      const items = await this.client.request('logs.tail', {
        source: tailSource,
        lines: q.limit ?? 100,
      });
      return { source: 'live', items };
    }

    const limit = Math.min(Math.max(1, q.limit ?? 100), 1000);
    const conditions: SQL[] = [];
    if (q.level) conditions.push(eq(logs.level, q.level));
    if (q.source) conditions.push(eq(logs.source, q.source));
    if (q.run) conditions.push(eq(logs.coreRunId, q.run));
    if (q.from) conditions.push(gte(logs.ts, new Date(q.from)));
    if (q.to) conditions.push(lte(logs.ts, new Date(q.to)));
    if (q.q) conditions.push(ilike(logs.message, `%${q.q}%`));

    // Cursor pagination: keyset on ts (descending), tie-break on id.
    if (q.cursor) {
      const cur = await db.select({ ts: logs.ts }).from(logs).where(eq(logs.id, q.cursor)).limit(1);
      if (cur[0]) conditions.push(lt(logs.ts, cur[0].ts));
    }

    const where = conditions.length ? and(...conditions) : undefined;
    const rows = await db
      .select()
      .from(logs)
      .where(where)
      .orderBy(desc(logs.ts), desc(logs.id))
      .limit(limit + 1);

    const hasMore = rows.length > limit;
    const items = hasMore ? rows.slice(0, limit) : rows;
    const nextCursor = hasMore ? items[items.length - 1].id : null;
    return { source: 'postgres', items, nextCursor, hasMore };
  }

  /** Retention: delete logs older than `days`. Returns the deleted count. */
  async purgeOlderThan(days: number): Promise<number> {
    const db = this.database.db;
    if (!db || !this.database.isUp) return 0;
    const res = await db
      .delete(logs)
      .where(sql`${logs.ts} < now() - (${days} || ' days')::interval`)
      .returning({ id: logs.id });
    if (res.length > 0) this.log.log(`Rétention logs: ${res.length} ligne(s) > ${days}j supprimée(s).`);
    return res.length;
  }
}
