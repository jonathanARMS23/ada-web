import 'reflect-metadata';
import { Logger, ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { FastifyAdapter, NestFastifyApplication } from '@nestjs/platform-fastify';
import { WsAdapter } from '@nestjs/platform-ws';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { AppModule } from './app.module.js';
import { AppConfigService } from './config/app-config.service.js';

export async function buildApp(): Promise<NestFastifyApplication> {
  const app = await NestFactory.create<NestFastifyApplication>(
    AppModule,
    new FastifyAdapter(),
    { bufferLogs: false },
  );

  app.setGlobalPrefix('api');
  // CORS pour l'UI locale (ada-ui sur :7777). Origines additionnelles via
  // ADA_CORS_ORIGINS (CSV). Bearer JWT en header → pas de cookies cross-site.
  const corsOrigins = (process.env.ADA_CORS_ORIGINS ?? 'http://localhost:7777,http://127.0.0.1:7777')
    .split(',')
    .map((o) => o.trim())
    .filter(Boolean);
  app.enableCors({ origin: corsOrigins, methods: ['GET', 'POST', 'PATCH', 'DELETE', 'OPTIONS'] });
  // WebSocket StreamGateway (ADR-016 §3) on /ws, native `ws` adapter.
  app.useWebSocketAdapter(new WsAdapter(app));
  app.useGlobalPipes(
    new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true, transform: true }),
  );

  const swagger = new DocumentBuilder()
    .setTitle('ADA API (NestJS, P1)')
    .setDescription('Control Plane client — surface lecture seule (ADR-016 §0)')
    .setVersion('0.1.0')
    .addBearerAuth()
    .build();
  const doc = SwaggerModule.createDocument(app, swagger);
  SwaggerModule.setup('api/docs', app, doc);

  return app;
}

async function bootstrap(): Promise<void> {
  const app = await buildApp();
  const config = app.get(AppConfigService);
  await app.listen(config.port, config.host);
  Logger.log(
    `ADA NestJS API en écoute sur http://${config.host}:${config.port}/api (profil: ${config.profile})`,
    'Bootstrap',
  );
}

// Only auto-bootstrap when run directly (not when imported by e2e tests).
if (require.main === module) {
  bootstrap().catch((err) => {
    Logger.error(`Bootstrap échoué: ${(err as Error).message}`, 'Bootstrap');
    process.exit(1);
  });
}
