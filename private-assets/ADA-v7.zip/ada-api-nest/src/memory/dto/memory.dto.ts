import { Type } from 'class-transformer';
import { IsBoolean, IsInt, IsOptional, Matches, Max, Min } from 'class-validator';
import { ApiPropertyOptional } from '@nestjs/swagger';

/**
 * P8 — Query for the navigable memory graph (viz 3D). Relays to RPC memory.graph.
 * `pagerank` annotates each node with an importance score; `top` caps the graph
 * to the N most important nodes (edges filtered accordingly).
 */
export class MemoryGraphQueryDto {
  @ApiPropertyOptional({ description: 'Calcule le PageRank et annote chaque nœud', example: true })
  @IsOptional()
  @Type(() => Boolean)
  @IsBoolean()
  pagerank?: boolean;

  @ApiPropertyOptional({ description: 'Conserve les N nœuds les plus importants', example: 100 })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(1000)
  top?: number;
}

/**
 * P8 — Note slug param (anti path-traversal). Strict allowlist: alphanum +
 * hyphen/underscore, with an OPTIONAL `.md` suffix; no `/`, `\` or `..` can
 * match this regex. The UI wiki addresses topics by bare slug (e.g.
 * `agent-architecture`), so the suffix must be optional — the controller
 * normalises it to `<slug>.md` before relaying to the Control Server, whose
 * SAFE_NOTE_RE still requires the `.md` suffix (defense in depth upstream).
 */
export class NoteSlugParamDto {
  @ApiPropertyOptional({ description: 'Slug de note wiki, avec ou sans suffixe .md', example: 'agent-architecture' })
  @Matches(/^[A-Za-z0-9_-]+(\.md)?$/, {
    message: 'file doit être un slug valide (lettres, chiffres, - et _), suffixe .md optionnel',
  })
  file!: string;
}
