import {
  BadRequestException,
  Controller,
  Get,
  NotFoundException,
  Param,
  Query,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/jwt-auth.guard.js';
import { MemoryService } from './memory.service.js';
import { MemoryGraphQueryDto, NoteSlugParamDto } from './dto/memory.dto.js';

/**
 * P8 — Rich memory REST surface (relay only; read-only, P1 contract).
 * JWT on every route. Powers the Memory feature (3D graph + Obsidian wiki).
 *
 *  - GET /memory/graph        → memory.graph  (viz 3D : nodes/edges/stats).
 *  - GET /memory/wiki         → obsidian.wiki (topics/index of the vault).
 *  - GET /memory/notes/:file  → obsidian.note (single .md, slug validated).
 *
 * The existing GET /memory?q= search lives in ClaudeController (bank.retrieve).
 */
@ApiTags('memory')
@ApiBearerAuth()
@Controller('memory')
@UseGuards(JwtAuthGuard)
export class MemoryController {
  constructor(private readonly service: MemoryService) {}

  @Get('graph')
  @ApiOperation({ summary: 'Graphe mémoire navigable pour la viz 3D (memory.graph)' })
  graph(@Query() query: MemoryGraphQueryDto) {
    return this.service.graph({ pagerank: query.pagerank, top: query.top });
  }

  @Get('wiki')
  @ApiOperation({ summary: 'Wiki Obsidian — topics/index du vault (obsidian.wiki)' })
  wiki() {
    return this.service.wiki();
  }

  @Get('notes/:file')
  @ApiOperation({ summary: 'Contenu d’une note du wiki (obsidian.note) — slug validé' })
  async note(@Param() params: NoteSlugParamDto) {
    // La page wiki adresse les topics par slug nu (ex: `agent-architecture`).
    // La RPC obsidian.note exige le suffixe `.md` — on normalise ici.
    const file = params.file.endsWith('.md') ? params.file : `${params.file}.md`;
    try {
      return await this.service.note(file);
    } catch (err) {
      // Map ADA error codes (ADR-016 §8) to HTTP: 1001 -> 404, INVALID_PARAMS -> 400.
      const code = (err as { code?: number }).code;
      const message = (err as { message?: string }).message ?? 'Erreur';
      if (code === 1001) throw new NotFoundException({ error: 'NOTE_NOT_FOUND', message });
      if (code === -32602) throw new BadRequestException({ error: 'INVALID_NOTE', message });
      throw err;
    }
  }
}
