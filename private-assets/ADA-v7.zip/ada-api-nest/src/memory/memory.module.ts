import { Module } from '@nestjs/common';
import { MemoryController } from './memory.controller.js';
import { MemoryService } from './memory.service.js';

/**
 * P8 — Rich memory (navigable graph + Obsidian wiki). ControlPlaneClient is
 * global (ControlPlaneModule), so this module only wires its own providers.
 */
@Module({
  controllers: [MemoryController],
  providers: [MemoryService],
  exports: [MemoryService],
})
export class MemoryModule {}
