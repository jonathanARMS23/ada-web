import { Injectable } from '@nestjs/common';
import { ControlPlaneClient } from '../control-plane/control-plane.client.js';

/**
 * P8 — Rich memory relay over the Control Server (read-only, P1 contract).
 *
 * Thin wrappers over client.request, like ClaudeService/ConfigService:
 *  - graph(): memory.graph  → { nodes, edges, stats } for the 3D viz.
 *  - wiki():  obsidian.wiki  → wiki topics/index of the profile vault.
 *  - note():  obsidian.note  → a single .md note (slug validated upstream).
 *
 * No state is mutated here; graceful degradation (empty graph / disabled vault)
 * is handled by the Control Server, which returns annotated empty payloads.
 */
@Injectable()
export class MemoryService {
  constructor(private readonly client: ControlPlaneClient) {}

  /** memory.graph — navigable knowledge graph projected for the 3D viz. */
  graph(opts: { pagerank?: boolean; top?: number }): Promise<unknown> {
    const params: Record<string, unknown> = {};
    if (opts.pagerank !== undefined) params.pagerank = opts.pagerank;
    if (opts.top !== undefined) params.top = opts.top;
    return this.client.request('memory.graph', params);
  }

  /** obsidian.wiki — structure/list of the wiki notes of the profile vault. */
  wiki(): Promise<unknown> {
    return this.client.request('obsidian.wiki');
  }

  /** obsidian.note — content of a single note (file already slug-validated). */
  note(file: string): Promise<unknown> {
    return this.client.request('obsidian.note', { file });
  }
}
