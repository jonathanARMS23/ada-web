import { Injectable, Logger } from '@nestjs/common';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { AppConfigService } from '../config/app-config.service.js';
import type { ReadyPhase } from '../control-plane/control-plane.types.js';

/**
 * Resolves agent system prompts (.claude/agents/<slug>.md or
 * <slug>/CLAUDE.md) for injection via --append-system-prompt, and builds the
 * per-phase user prompt (ADR-016 §5: instruction/feature + phase role +
 * acwContext).
 */
@Injectable()
export class AgentPromptService {
  private readonly log = new Logger(AgentPromptService.name);
  private readonly cache = new Map<string, string | null>();

  constructor(private readonly config: AppConfigService) {}

  /** Reads the system prompt for an agent slug, or null if none is found. */
  resolveAgentPrompt(agent: string | undefined): string | null {
    if (!agent) return null;
    if (this.cache.has(agent)) return this.cache.get(agent) ?? null;
    const dir = this.config.agentsDir;
    const candidates = [path.join(dir, `${agent}.md`), path.join(dir, agent, 'CLAUDE.md')];
    let content: string | null = null;
    for (const file of candidates) {
      try {
        if (fs.existsSync(file) && fs.statSync(file).isFile()) {
          content = stripFrontmatter(fs.readFileSync(file, 'utf8'));
          break;
        }
      } catch {
        /* ignore */
      }
    }
    if (!content) this.log.debug(`Aucun prompt agent trouvé pour "${agent}" dans ${dir}`);
    this.cache.set(agent, content);
    return content;
  }

  /** Builds the user prompt for a phase run. */
  buildPhasePrompt(params: {
    instruction: string;
    feature: string;
    pipeline: string;
    phase: ReadyPhase;
  }): string {
    const { instruction, feature, pipeline, phase } = params;
    const acw =
      phase.acwContext != null
        ? `\n\nContexte ACW (sorties des phases précédentes):\n${safeJson(phase.acwContext)}`
        : '';
    return (
      `Tâche: ${instruction}\n` +
      `Pipeline: ${pipeline} · Feature: ${feature}\n` +
      `Phase courante: ${phase.phaseId} (agent: ${phase.agent})\n` +
      `Exécute le rôle de cette phase pour la feature ci-dessus.` +
      acw
    );
  }
}

function stripFrontmatter(md: string): string {
  if (md.startsWith('---')) {
    const end = md.indexOf('\n---', 3);
    if (end !== -1) {
      const after = md.indexOf('\n', end + 1);
      return after !== -1 ? md.slice(after + 1).trim() : md;
    }
  }
  return md.trim();
}

function safeJson(v: unknown): string {
  try {
    return JSON.stringify(v).slice(0, 4000);
  } catch {
    return String(v);
  }
}
