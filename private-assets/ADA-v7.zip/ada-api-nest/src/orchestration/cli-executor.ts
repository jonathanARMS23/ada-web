import { Injectable, Logger } from '@nestjs/common';
import { spawn } from 'node:child_process';
import * as fs from 'node:fs';
import { AppConfigService } from '../config/app-config.service.js';
import { StreamParser } from './stream-parser.js';
import type { PhaseExecutor, PhaseResult, PhaseRunContext } from './phase-executor.js';

/**
 * Real executor (ADR-016 §5/§6, §9). Spawns Claude Code headless:
 *
 *   claude -p --output-format stream-json --model <phase.model>
 *          [--append-system-prompt <agentPrompt>]
 *
 * Hard constraints (ADR-016 §9): `claude` resolved by ABSOLUTE path (no PATH
 * lookup), shell:false, args as an array, CLAUDE_CONFIG_DIR pinned to the
 * profile dir for state isolation. The phase prompt is passed on stdin.
 *
 * NOTE: this is NOT exercised by the test-suite (cost/auth). Enable in real
 * runs with ADA_EXECUTOR=cli and ADA_CLAUDE_BIN=/abs/path/to/claude.
 */
@Injectable()
export class CliExecutor implements PhaseExecutor {
  readonly kind = 'cli' as const;
  private readonly log = new Logger(CliExecutor.name);

  constructor(private readonly config: AppConfigService) {}

  async execute(ctx: PhaseRunContext): Promise<PhaseResult> {
    const bin = this.config.claudeBin;
    if (!bin || !fs.existsSync(bin) || !fs.statSync(bin).isFile()) {
      // ADR-016 §8 CLAUDE_EXEC_FAILED -> non-retryable config error.
      return {
        ok: false,
        summary: '',
        usage: { tokens: 0, cost: 0 },
        error: `ADA_CLAUDE_BIN introuvable: ${bin ?? '(non défini)'}`,
        retryable: false,
      };
    }

    const args = [
      '-p',
      '--output-format',
      'stream-json',
      '--verbose',
      '--model',
      ctx.phase.model,
    ];
    if (ctx.agentPrompt) {
      args.push('--append-system-prompt', ctx.agentPrompt);
    }

    return new Promise<PhaseResult>((resolve) => {
      const child = spawn(bin, args, {
        shell: false,
        env: { ...process.env, CLAUDE_CONFIG_DIR: ctx.profileDir },
        stdio: ['pipe', 'pipe', 'pipe'],
      });

      const parser = new StreamParser(ctx.onEvent);
      let stderr = '';
      let settled = false;

      const timeout = setTimeout(() => {
        if (!settled) {
          settled = true;
          child.kill('SIGKILL');
          resolve({
            ok: false,
            summary: parser.summary,
            usage: parser.usage,
            error: `timeout (${this.config.phaseTimeoutMs}ms)`,
            retryable: true,
          });
        }
      }, this.config.phaseTimeoutMs);
      timeout.unref?.();

      const onAbort = (): void => {
        if (!settled) child.kill('SIGTERM');
      };
      ctx.signal?.addEventListener('abort', onAbort, { once: true });

      child.stdout.setEncoding('utf8');
      child.stdout.on('data', (d: string) => parser.push(d));
      child.stderr.setEncoding('utf8');
      child.stderr.on('data', (d: string) => {
        stderr += d;
      });

      child.on('error', (err) => {
        if (settled) return;
        settled = true;
        clearTimeout(timeout);
        resolve({
          ok: false,
          summary: '',
          usage: { tokens: 0, cost: 0 },
          error: `spawn claude échoué: ${err.message}`,
          retryable: false,
        });
      });

      child.on('close', (code) => {
        if (settled) return;
        settled = true;
        clearTimeout(timeout);
        parser.end();
        ctx.signal?.removeEventListener('abort', onAbort);
        if (code === 0 && !parser.error) {
          resolve({ ok: true, summary: parser.summary || 'ok', usage: parser.usage });
        } else {
          resolve({
            ok: false,
            summary: parser.summary,
            usage: parser.usage,
            error: parser.error ?? `claude exited ${code}: ${stderr.slice(0, 500)}`,
            retryable: true,
          });
        }
      });

      // Feed the phase prompt on stdin and close it (single-shot -p run).
      try {
        child.stdin.write(ctx.prompt);
        child.stdin.end();
      } catch (err) {
        this.log.warn(`écriture stdin claude échouée: ${(err as Error).message}`);
      }
    });
  }
}
