import { Injectable, Logger, OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import PgBoss from 'pg-boss';
import { AppConfigService } from '../config/app-config.service.js';

export interface OrchestrateJob {
  runId: string;
  instruction: string;
  pipeline: string;
  feature: string;
  workspaceId?: string | null;
  conversationId?: string | null;
}

export type JobHandler = (job: OrchestrateJob) => Promise<void>;

/**
 * Async job queue for the OrchestrationLoop (ADR-016 §5).
 *
 * - Primary: pg-boss on Postgres (durable, survives restarts, concurrency).
 * - Degraded: if DATABASE_URL is absent, an in-process queue runs jobs in the
 *   same Node process (dev/tests) with a warn. This keeps P2 testable without a
 *   DB, exactly like P1 degrades.
 */
@Injectable()
export class JobQueueService implements OnModuleInit, OnModuleDestroy {
  private readonly log = new Logger(JobQueueService.name);
  private boss: PgBoss | null = null;
  private handler: JobHandler | null = null;
  private mode: 'pgboss' | 'inproc' = 'inproc';
  private readonly inflight = new Set<Promise<void>>();

  constructor(private readonly config: AppConfigService) {}

  get backend(): 'pgboss' | 'inproc' {
    return this.mode;
  }

  async onModuleInit(): Promise<void> {
    const url = this.config.databaseUrl;
    if (!url) {
      this.mode = 'inproc';
      this.log.warn('DATABASE_URL absent — JobQueue en mode in-process (dégradé, dev/tests)');
      return;
    }
    try {
      this.boss = new PgBoss({ connectionString: url, schema: 'pgboss' });
      this.boss.on('error', (e) => this.log.warn(`pg-boss error: ${e.message}`));
      await this.boss.start();
      await this.boss.createQueue(this.config.queueName);
      this.mode = 'pgboss';
      this.log.log(`JobQueue pg-boss démarrée (queue: ${this.config.queueName})`);
    } catch (err) {
      this.mode = 'inproc';
      this.boss = null;
      this.log.warn(`pg-boss indisponible — fallback in-process: ${(err as Error).message}`);
    }
  }

  async onModuleDestroy(): Promise<void> {
    await Promise.allSettled([...this.inflight]);
    try {
      await this.boss?.stop({ graceful: true, timeout: 5000 });
    } catch {
      /* ignore */
    }
  }

  /** Registers the single orchestration handler and starts consuming. */
  async registerHandler(handler: JobHandler): Promise<void> {
    this.handler = handler;
    if (this.mode === 'pgboss' && this.boss) {
      await this.boss.work<OrchestrateJob>(
        this.config.queueName,
        { batchSize: this.config.phaseConcurrency },
        async (jobs) => {
          for (const job of jobs) await this.runHandler(job.data);
        },
      );
    }
  }

  /** Enqueues an orchestration job. Returns the job id (or a synthetic one). */
  async enqueue(job: OrchestrateJob): Promise<string> {
    if (this.mode === 'pgboss' && this.boss) {
      const id = await this.boss.send(this.config.queueName, job);
      return id ?? job.runId;
    }
    // In-process: schedule on next tick so POST /tasks returns 202 immediately.
    const p = (async () => {
      await Promise.resolve();
      await this.runHandler(job);
    })();
    this.track(p);
    return job.runId;
  }

  /** Awaits all in-flight in-process jobs (test helper for the inproc path). */
  async drain(): Promise<void> {
    await Promise.allSettled([...this.inflight]);
  }

  private track(p: Promise<void>): void {
    this.inflight.add(p);
    void p.finally(() => this.inflight.delete(p));
  }

  private async runHandler(job: OrchestrateJob): Promise<void> {
    if (!this.handler) {
      this.log.error('Aucun handler enregistré pour la JobQueue');
      return;
    }
    try {
      await this.handler(job);
    } catch (err) {
      this.log.error(`Job orchestrate ${job.runId} échoué: ${(err as Error).message}`);
    }
  }
}
