import { Injectable, Logger } from '@nestjs/common';
import { StreamParser } from './stream-parser.js';
import type { PhaseExecutor, PhaseResult, PhaseRunContext } from './phase-executor.js';

/**
 * Default executor (ADR-016 §5, P2 tests/dev). Emits a deterministic
 * stream-json NDJSON sequence — text, a tool_use, then a `result` with usage —
 * and runs it through the REAL StreamParser, so the whole streaming/usage path
 * is exercised without spawning `claude` (zero cost, zero auth).
 */
@Injectable()
export class MockExecutor implements PhaseExecutor {
  readonly kind = 'mock' as const;
  private readonly log = new Logger(MockExecutor.name);

  async execute(ctx: PhaseRunContext): Promise<PhaseResult> {
    const { phase } = ctx;
    this.log.debug(`MockExecutor phase=${phase.phaseId} agent=${phase.agent} model=${phase.model}`);

    const lines = this.cannedNdjson(ctx);
    const parser = new StreamParser(ctx.onEvent);
    for (const line of lines) {
      if (ctx.signal?.aborted) {
        return { ok: false, summary: '', usage: { tokens: 0, cost: 0 }, error: 'aborted', retryable: false };
      }
      parser.push(line + '\n');
      // Yield to the event loop so streamed events are observable in order.
      await Promise.resolve();
    }
    parser.end();

    if (parser.error) {
      return { ok: false, summary: parser.summary, usage: parser.usage, error: parser.error, retryable: true };
    }
    return { ok: true, summary: parser.summary || `phase ${phase.phaseId} ok (mock)`, usage: parser.usage };
  }

  /** Canned stream-json lines for one phase (text + tool_use + result/usage). */
  private cannedNdjson(ctx: PhaseRunContext): string[] {
    const { phase } = ctx;
    // Deterministic, small, non-zero usage so persistence/cost assertions hold.
    const tokens = 100 + phase.phaseId.length;
    const cost = Number((tokens * 0.000003).toFixed(6));
    return [
      JSON.stringify({
        type: 'assistant',
        message: { content: [{ type: 'text', text: `[mock ${phase.agent}] starting ${phase.phaseId}` }] },
      }),
      JSON.stringify({
        type: 'assistant',
        message: { content: [{ type: 'tool_use', name: 'Write', input: { path: `${phase.phaseId}.ts` } }] },
      }),
      JSON.stringify({
        type: 'assistant',
        message: { content: [{ type: 'text', text: `[mock ${phase.agent}] completed ${phase.phaseId}` }] },
      }),
      JSON.stringify({
        type: 'result',
        subtype: 'success',
        is_error: false,
        result: `phase ${phase.phaseId} done by ${phase.agent}`,
        usage: { input_tokens: Math.floor(tokens / 2), output_tokens: Math.ceil(tokens / 2) },
        total_cost_usd: cost,
      }),
    ];
  }
}
