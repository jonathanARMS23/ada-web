import { Injectable } from '@nestjs/common';
import { EventEmitter } from 'node:events';
import { randomUUID } from 'node:crypto';
import type { ControlEvent } from '../control-plane/control-plane.types.js';

/**
 * In-process bus for events the OrchestrationLoop emits as the SOURCE OF TRUTH
 * of the run lifecycle in Mode A (ADR-016 §3.A). The StreamGateway and the
 * persistence projector both subscribe. Events carry a stable UUID `id` so the
 * gateway can dedup against hors-bande Control Server events (G3).
 */
@Injectable()
export class OrchestrationEvents extends EventEmitter {
  constructor() {
    super();
    this.setMaxListeners(0);
  }

  /** Builds + emits a normalised event (same wire shape as ControlEvent). */
  emitRun(
    type: string,
    payload: Record<string, unknown>,
    corr: { runId?: string | null; workspaceId?: string | null; conversationId?: string | null },
  ): ControlEvent {
    const evt: ControlEvent = {
      id: randomUUID(),
      ts: Date.now(),
      type,
      corr: {
        runId: corr.runId ?? (payload.runId as string | undefined) ?? null,
        workspaceId: corr.workspaceId ?? null,
        conversationId: corr.conversationId ?? null,
      },
      payload,
    };
    this.emit('event', evt);
    return evt;
  }

  onEvent(handler: (e: ControlEvent) => void): void {
    this.on('event', handler);
  }
}
