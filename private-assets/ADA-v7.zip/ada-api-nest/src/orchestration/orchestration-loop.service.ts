import { Inject, Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { ControlPlaneClient } from '../control-plane/control-plane.client.js';
import { AppConfigService } from '../config/app-config.service.js';
import { OrchestrationEvents } from './orchestration-events.js';
import { AgentPromptService } from './agent-prompt.service.js';
import { JobQueueService, OrchestrateJob } from './job-queue.service.js';
import {
  PHASE_EXECUTOR,
  PhaseExecutor,
  PhaseResult,
  PhaseStreamEvent,
} from './phase-executor.js';
import type { ReadyPhase, RunNextResult } from '../control-plane/control-plane.types.js';

const MAX_LOOP_ITERATIONS = 200; // hard safety bound against a stuck run.next

/**
 * The execution engine (ADR-016 §5). In Mode A, NestJS drives the run lifecycle
 * EXCLUSIVELY through Control Plane RPC — it NEVER writes state.json (ROADMAP P2
 * risk #2). NestJS is the source of truth of the UI event stream, emitting all
 * run.* lifecycle events itself (ADR-016 §3.A).
 *
 * Algorithm per run:
 *   emit run.started
 *   loop (bounded):
 *     control.run.next(runId) -> {topology, ready[], parallelizable}
 *     if ready empty -> break
 *     run phases of `ready`:
 *       - topology=parallel_mesh -> concurrently, bounded by phaseConcurrency
 *       - else sequentially
 *     each phase: control.run.start -> executor.execute -> control.run.done|fail
 *   emit run.completed
 *
 * Idempotent resume: a re-entrant job simply calls run.next again; already
 * completed phases are not returned by the Control Server.
 */
@Injectable()
export class OrchestrationLoop implements OnModuleInit {
  private readonly log = new Logger(OrchestrationLoop.name);

  constructor(
    private readonly client: ControlPlaneClient,
    private readonly config: AppConfigService,
    private readonly events: OrchestrationEvents,
    private readonly prompts: AgentPromptService,
    private readonly queue: JobQueueService,
    @Inject(PHASE_EXECUTOR) private readonly executor: PhaseExecutor,
  ) {}

  async onModuleInit(): Promise<void> {
    await this.queue.registerHandler((job) => this.run(job));
  }

  /** Entry point invoked by the JobQueue worker for one run. */
  async run(job: OrchestrateJob): Promise<void> {
    const { runId, pipeline, feature } = job;
    const corr = { runId, workspaceId: job.workspaceId ?? null, conversationId: job.conversationId ?? null };
    this.log.log(`Orchestration démarrée runId=${runId} pipeline=${pipeline} executor=${this.executor.kind}`);

    this.events.emitRun('run.started', { runId, pipeline, name: feature }, corr);

    let status = 'completed';
    try {
      let iterations = 0;
      for (;;) {
        if (++iterations > MAX_LOOP_ITERATIONS) {
          throw new Error('boucle d’orchestration: limite d’itérations atteinte');
        }
        const next: RunNextResult = await this.client.runNext(runId);
        const ready = next.ready ?? [];
        if (ready.length === 0) break;

        if (next.topology === 'parallel_mesh' && ready.length > 1) {
          await this.runConcurrent(ready, job, corr);
        } else {
          for (const phase of ready) {
            await this.runPhase(phase, job, corr);
          }
        }
      }
    } catch (err) {
      status = 'failed';
      this.log.error(`Orchestration runId=${runId} interrompue: ${(err as Error).message}`);
    }

    this.events.emitRun('run.completed', { runId, pipeline, status }, corr);
    this.log.log(`Orchestration terminée runId=${runId} status=${status}`);
  }

  /** Runs parallel_mesh phases concurrently, bounded by phaseConcurrency. */
  private async runConcurrent(
    ready: ReadyPhase[],
    job: OrchestrateJob,
    corr: { runId: string; workspaceId: string | null; conversationId: string | null },
  ): Promise<void> {
    const limit = Math.max(1, this.config.phaseConcurrency);
    const queue = [...ready];
    const workers: Promise<void>[] = [];
    const spawnWorker = async (): Promise<void> => {
      for (;;) {
        const phase = queue.shift();
        if (!phase) return;
        await this.runPhase(phase, job, corr);
      }
    };
    for (let i = 0; i < Math.min(limit, ready.length); i++) workers.push(spawnWorker());
    await Promise.all(workers);
  }

  /** Runs a single phase: run.start -> execute -> run.done|run.fail. */
  private async runPhase(
    phase: ReadyPhase,
    job: OrchestrateJob,
    corr: { runId: string; workspaceId: string | null; conversationId: string | null },
  ): Promise<void> {
    const { runId } = corr;
    const startedAt = Date.now();

    await this.client.runStart(runId, phase.phaseId);
    this.events.emitRun(
      'run.phase.started',
      { runId, phaseId: phase.phaseId, agent: phase.agent, model: phase.model },
      corr,
    );

    const onEvent = (e: PhaseStreamEvent): void => {
      if (e.kind === 'output') {
        this.events.emitRun('run.phase.output', { runId, phaseId: phase.phaseId, chunk: e.chunk }, corr);
      } else {
        this.events.emitRun('run.phase.tool', { runId, phaseId: phase.phaseId, tool: e.tool, input: e.input }, corr);
      }
    };

    let result: PhaseResult;
    try {
      result = await this.executor.execute({
        runId,
        phase,
        prompt: this.prompts.buildPhasePrompt({
          instruction: job.instruction,
          feature: job.feature,
          pipeline: job.pipeline,
          phase,
        }),
        profileDir: this.config.profileDir,
        agentPrompt: this.prompts.resolveAgentPrompt(phase.agent),
        onEvent,
      });
    } catch (err) {
      result = {
        ok: false,
        summary: '',
        usage: { tokens: 0, cost: 0 },
        error: (err as Error).message,
        retryable: true,
      };
    }

    const durationMs = Date.now() - startedAt;

    if (result.ok) {
      await this.client.runDone({
        runId,
        phaseId: phase.phaseId,
        summary: result.summary,
        tokens: result.usage.tokens,
        cost: result.usage.cost,
      });
      this.events.emitRun(
        'run.phase.completed',
        {
          runId,
          phaseId: phase.phaseId,
          agent: phase.agent,
          tokens: result.usage.tokens,
          cost: result.usage.cost,
          durationMs,
        },
        corr,
      );
    } else {
      await this.client.runFail({
        runId,
        phaseId: phase.phaseId,
        error: result.error ?? 'phase failed',
        retry: result.retryable ?? false,
        tokens: result.usage.tokens,
        cost: result.usage.cost,
      });
      this.events.emitRun(
        'run.phase.failed',
        {
          runId,
          phaseId: phase.phaseId,
          agent: phase.agent,
          error: result.error ?? 'phase failed',
          retryable: result.retryable ?? false,
          tokens: result.usage.tokens,
          cost: result.usage.cost,
        },
        corr,
      );
    }
  }
}
