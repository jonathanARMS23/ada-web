import { Global, Module } from '@nestjs/common';
import { ControlPlaneModule } from '../control-plane/control-plane.module.js';
import { OrchestrationEvents } from './orchestration-events.js';
import { JobQueueService } from './job-queue.service.js';
import { OrchestrationLoop } from './orchestration-loop.service.js';
import { AgentPromptService } from './agent-prompt.service.js';
import { StreamGateway } from './stream.gateway.js';
import { MockExecutor } from './mock-executor.js';
import { CliExecutor } from './cli-executor.js';
import { PHASE_EXECUTOR } from './phase-executor.js';
import { AppConfigService } from '../config/app-config.service.js';

/**
 * Execution engine module (ADR-016 §5). Wires the OrchestrationLoop, the
 * pg-boss JobQueue, the PhaseExecutor strategy (mock|cli via ADA_EXECUTOR), the
 * StreamParser-backed executors, and the WebSocket StreamGateway.
 *
 * OrchestrationEvents is exported globally so the persistence projector
 * (PersistenceModule) can subscribe to loop events without a circular import.
 */
@Global()
@Module({
  imports: [ControlPlaneModule],
  providers: [
    OrchestrationEvents,
    JobQueueService,
    OrchestrationLoop,
    AgentPromptService,
    StreamGateway,
    MockExecutor,
    CliExecutor,
    {
      provide: PHASE_EXECUTOR,
      // Strategy selection at composition time (ADR-016 §5): mock default.
      // `sdk` (interactive-session executor) has no pipeline PhaseExecutor of its
      // own — it reuses the real `claude -p` CliExecutor so the module boots and
      // any residual pipeline phase still runs against the real binary. The
      // conversational discussions path no longer goes through the pipeline.
      useFactory: (config: AppConfigService, mock: MockExecutor, cli: CliExecutor) =>
        config.executorKind === 'cli' || config.executorKind === 'sdk' ? cli : mock,
      inject: [AppConfigService, MockExecutor, CliExecutor],
    },
  ],
  exports: [OrchestrationEvents, JobQueueService, OrchestrationLoop, AgentPromptService],
})
export class OrchestrationModule {}
