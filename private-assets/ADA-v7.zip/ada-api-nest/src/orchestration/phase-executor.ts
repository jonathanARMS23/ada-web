import type { ReadyPhase } from '../control-plane/control-plane.types.js';

/** Normalised events emitted while a phase runs (ADR-016 §3.A). */
export interface PhaseOutputEvent {
  kind: 'output';
  chunk: string;
}
export interface PhaseToolEvent {
  kind: 'tool';
  tool: string;
  input: unknown;
}
export type PhaseStreamEvent = PhaseOutputEvent | PhaseToolEvent;

/** Final usage extracted from the executor's `result` message (ADR-016 §3, §5). */
export interface PhaseUsage {
  tokens: number;
  cost: number;
}

export interface PhaseResult {
  /** True if the phase produced a successful terminal result. */
  ok: boolean;
  summary: string;
  usage: PhaseUsage;
  /** Set when ok=false. */
  error?: string;
  /** Whether a failure is retryable (drives run.fail --retry). */
  retryable?: boolean;
}

/** Context passed to an executor for a single phase run. */
export interface PhaseRunContext {
  runId: string;
  phase: ReadyPhase;
  /** instruction/feature + role of the phase + acwContext. */
  prompt: string;
  /** Profile dir -> CLAUDE_CONFIG_DIR for the spawned process. */
  profileDir: string;
  /** Absolute path to the resolved agent system prompt content, if any. */
  agentPrompt: string | null;
  /** Per-stream-event callback (token streaming + tool-use). */
  onEvent: (e: PhaseStreamEvent) => void;
  /** Optional cancellation. */
  signal?: AbortSignal;
}

/**
 * Injectable strategy for running one phase (ADR-016 §5 ProtocolAdapter / L3a).
 * Two implementations: MockExecutor (tests/dev, zero spawn) and CliExecutor
 * (real `claude -p` subprocess). Selected via ADA_EXECUTOR.
 */
export interface PhaseExecutor {
  readonly kind: 'mock' | 'cli';
  execute(ctx: PhaseRunContext): Promise<PhaseResult>;
}

/** DI token for the active PhaseExecutor. */
export const PHASE_EXECUTOR = Symbol('PHASE_EXECUTOR');
