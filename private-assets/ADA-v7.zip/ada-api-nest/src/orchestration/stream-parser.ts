import type { PhaseStreamEvent, PhaseUsage } from './phase-executor.js';

/**
 * Parses Claude Code `--output-format stream-json` NDJSON into normalised
 * stream events + the final usage (ADR-016 §3 StreamParser, §5).
 *
 * The stream-json schema emits one JSON object per line. We handle the shapes
 * produced by `claude -p --output-format stream-json`:
 *  - {type:"assistant", message:{content:[{type:"text",text}|{type:"tool_use",name,input}]}}
 *  - {type:"content_block_delta", delta:{type:"text_delta", text}}  (token deltas)
 *  - {type:"result", subtype, usage:{input_tokens,output_tokens}, total_cost_usd, is_error}
 *
 * It is line-oriented and resilient: unknown shapes are ignored, malformed
 * lines are skipped. Designed so the same parser serves the MockExecutor's
 * canned NDJSON and the CliExecutor's real stdout.
 */
export class StreamParser {
  private buffer = '';
  private _usage: PhaseUsage = { tokens: 0, cost: 0 };
  private _summary = '';
  private _error: string | null = null;
  private _resultSeen = false;
  private _sessionId: string | null = null;

  constructor(private readonly onEvent: (e: PhaseStreamEvent) => void) {}

  /** Feeds a chunk of stdout; emits events for each complete line found. */
  push(chunk: string): void {
    this.buffer += chunk;
    let idx: number;
    while ((idx = this.buffer.indexOf('\n')) !== -1) {
      const line = this.buffer.slice(0, idx);
      this.buffer = this.buffer.slice(idx + 1);
      if (line.trim()) this.line(line);
    }
  }

  /** Flushes any trailing partial line (no newline at EOF). */
  end(): void {
    if (this.buffer.trim()) this.line(this.buffer);
    this.buffer = '';
  }

  get usage(): PhaseUsage {
    return this._usage;
  }
  get summary(): string {
    return this._summary;
  }
  get error(): string | null {
    return this._error;
  }
  get resultSeen(): boolean {
    return this._resultSeen;
  }
  /**
   * The claude `session_id`, captured from the `{type:"system",subtype:"init"}`
   * frame (and reconfirmed from the final `result` frame). Drives `--resume`
   * for bidirectional sessions (ADR-016 §6/§6bis A, validated smoke test).
   */
  get sessionId(): string | null {
    return this._sessionId;
  }

  private line(raw: string): void {
    let obj: Record<string, unknown>;
    try {
      obj = JSON.parse(raw) as Record<string, unknown>;
    } catch {
      return; // not JSON -> skip (e.g. a stray log line)
    }
    const type = obj.type;

    if (type === 'system') {
      // {type:"system",subtype:"init",session_id,...} — capture session_id here.
      if (typeof obj.session_id === 'string' && obj.session_id) {
        this._sessionId = obj.session_id;
      }
      return;
    }

    if (type === 'content_block_delta') {
      const delta = obj.delta as Record<string, unknown> | undefined;
      if (delta && delta.type === 'text_delta' && typeof delta.text === 'string') {
        this.onEvent({ kind: 'output', chunk: delta.text });
      }
      return;
    }

    if (type === 'assistant') {
      const message = obj.message as Record<string, unknown> | undefined;
      const content = message?.content;
      if (Array.isArray(content)) {
        for (const block of content) {
          const b = block as Record<string, unknown>;
          if (b.type === 'text' && typeof b.text === 'string') {
            this.onEvent({ kind: 'output', chunk: b.text });
            this._summary = b.text;
          } else if (b.type === 'tool_use' && typeof b.name === 'string') {
            this.onEvent({ kind: 'tool', tool: b.name, input: b.input ?? {} });
          }
        }
      }
      return;
    }

    if (type === 'result') {
      this._resultSeen = true;
      if (typeof obj.session_id === 'string' && obj.session_id) {
        this._sessionId = obj.session_id;
      }
      const usage = obj.usage as Record<string, unknown> | undefined;
      const input = num(usage?.input_tokens);
      const output = num(usage?.output_tokens);
      this._usage = {
        tokens: input + output || num(obj.tokens),
        cost: num(obj.total_cost_usd) || num(obj.cost),
      };
      if (typeof obj.result === 'string' && obj.result.trim()) this._summary = obj.result;
      if (obj.is_error === true || obj.subtype === 'error_max_turns') {
        this._error = typeof obj.result === 'string' ? obj.result : `result error (${String(obj.subtype)})`;
      }
    }
  }
}

function num(v: unknown): number {
  return typeof v === 'number' && Number.isFinite(v) ? v : 0;
}
