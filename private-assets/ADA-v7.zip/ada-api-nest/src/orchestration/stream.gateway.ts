import { Logger, OnModuleInit, Optional } from '@nestjs/common';
import {
  OnGatewayConnection,
  OnGatewayDisconnect,
  WebSocketGateway,
} from '@nestjs/websockets';
import type { WebSocket } from 'ws';
import type { IncomingMessage } from 'node:http';
import { JwtService } from '../auth/jwt.service.js';
import { AppConfigService } from '../config/app-config.service.js';
import { OrchestrationEvents } from './orchestration-events.js';
import { ControlPlaneClient } from '../control-plane/control-plane.client.js';
import { SessionInboundRouter } from '../sessions/session-inbound.router.js';
import type { ControlEvent } from '../control-plane/control-plane.types.js';

interface Client {
  socket: WebSocket;
  workspaceId: string | null;
}

/**
 * WebSocket gateway streaming run.* events to clients (ADR-016 §3, §9).
 *
 * - Auth reuses the JWT (bearer in `Authorization` header or `?token=`/`?ticket=`
 *   query). Unauthenticated sockets are closed immediately.
 * - Routing is BY WORKSPACE ROOM: a client only receives events whose
 *   corr.workspaceId matches its own (or events with no workspace, treated as
 *   global to its room). NEVER a global broadcast (ROADMAP P2 risk #4 / §3).
 * - Dedup BY EVENT `id`: OrchestrationLoop (source of truth) and hors-bande
 *   Control Server events are both forwarded; duplicates collapse by id (G3).
 *
 * Events émis (room workspace) :
 *  - run.started / run.phase.started / run.phase.completed / run.phase.failed /
 *    run.completed (cycle de vie du run).
 *  - P6 cost.delta { workspaceId, runId, phaseId, cost, cumulativeCost } — émis
 *    par EventIngestionService à chaque coût de phase (coûts live du dashboard).
 *  - P6 budget.warning { scope, spent, limit, pct, action, message } — émis quand
 *    budget.check signale une alerte/dépassement (relai budget-guard).
 */
@WebSocketGateway({ path: '/ws' })
export class StreamGateway
  implements OnGatewayConnection, OnGatewayDisconnect, OnModuleInit
{
  private readonly log = new Logger(StreamGateway.name);
  private readonly clients = new Map<WebSocket, Client>();
  private readonly seen = new Set<string>();

  constructor(
    private readonly jwt: JwtService,
    private readonly config: AppConfigService,
    private readonly events: OrchestrationEvents,
    private readonly control: ControlPlaneClient,
    @Optional() private readonly inbound?: SessionInboundRouter,
  ) {}

  onModuleInit(): void {
    this.events.onEvent((e) => this.fanout(e));
    // Hors-bande events from the Control Server (already deduped by id there,
    // re-deduped here against loop events).
    this.control.on('event', (e: ControlEvent) => this.fanout(e));
  }

  async handleConnection(socket: WebSocket, req: IncomingMessage): Promise<void> {
    const workspaceId = await this.authenticate(socket, req);
    if (workspaceId === undefined) return; // closed in authenticate()
    this.clients.set(socket, { socket, workspaceId });
    // Inbound interactive messages (ADR-016 §3.C): task.message/interrupt/
    // cancel/permission_response/plan_response/clarification_response. Routed to
    // the sessions module when present (P3); ignored otherwise (P1/P2).
    socket.on('message', (data: unknown) => {
      void this.onInbound(socket, data);
    });
    this.log.debug(`WS connecté (workspace=${workspaceId ?? 'none'}) total=${this.clients.size}`);
  }

  /** Parses an inbound WS frame and dispatches it to the session router. */
  private async onInbound(socket: WebSocket, data: unknown): Promise<void> {
    if (!this.inbound) return;
    let msg: { type?: string } & Record<string, unknown>;
    try {
      const raw = typeof data === 'string' ? data : (data as { toString(): string }).toString();
      msg = JSON.parse(raw) as { type?: string } & Record<string, unknown>;
    } catch {
      return; // ignore malformed inbound frames
    }
    if (typeof msg.type !== 'string') return;
    try {
      await this.inbound.handle(msg as { type: string } & Record<string, unknown>);
    } catch (err) {
      this.log.warn(`Message entrant ${msg.type} échoué: ${(err as Error).message}`);
      try {
        if (socket.readyState === socket.OPEN) {
          socket.send(JSON.stringify({ type: 'task.error', error: (err as Error).message }));
        }
      } catch {
        /* ignore */
      }
    }
  }

  handleDisconnect(socket: WebSocket): void {
    this.clients.delete(socket);
  }

  /**
   * Verifies the JWT. Returns the workspaceId room (string|null) on success, or
   * `undefined` after closing the socket on failure.
   */
  private async authenticate(socket: WebSocket, req: IncomingMessage): Promise<string | null | undefined> {
    if (this.config.authDisabled) {
      return this.workspaceFrom(req);
    }
    const token = this.extractToken(req);
    if (!token) {
      socket.close(4401, 'UNAUTHORIZED');
      return undefined;
    }
    try {
      const payload = await this.jwt.verify(token);
      const wsFromToken =
        (payload as { workspaceId?: string }).workspaceId ?? this.workspaceFrom(req);
      return wsFromToken ?? null;
    } catch {
      socket.close(4401, 'INVALID_TOKEN');
      return undefined;
    }
  }

  private extractToken(req: IncomingMessage): string | null {
    const header = req.headers['authorization'];
    if (typeof header === 'string' && header.startsWith('Bearer ')) return header.slice(7);
    const url = new URL(req.url ?? '', 'http://localhost');
    return url.searchParams.get('token') ?? url.searchParams.get('ticket');
  }

  private workspaceFrom(req: IncomingMessage): string | null {
    const url = new URL(req.url ?? '', 'http://localhost');
    return url.searchParams.get('workspaceId');
  }

  /** Forwards an event to the clients in its workspace room, deduped by id. */
  private fanout(evt: ControlEvent): void {
    if (this.seen.has(evt.id)) return;
    this.seen.add(evt.id);
    if (this.seen.size > 50_000) {
      this.seen.clear();
      this.seen.add(evt.id);
    }

    const evtWorkspace = evt.corr?.workspaceId ?? null;
    const frame = JSON.stringify(evt);
    for (const client of this.clients.values()) {
      // Room match: client receives events for its workspace, or unscoped
      // events (no workspace) so a single-tenant client still gets the stream.
      if (evtWorkspace !== null && client.workspaceId !== null && evtWorkspace !== client.workspaceId) {
        continue;
      }
      try {
        if (client.socket.readyState === client.socket.OPEN) client.socket.send(frame);
      } catch {
        /* drop on slow/broken client (lossy output, ADR-016 §7) */
      }
    }
  }
}
