import { Injectable, Logger, OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import { drizzle, NodePgDatabase } from 'drizzle-orm/node-postgres';
import pg from 'pg';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { AppConfigService } from '../config/app-config.service.js';
import { schema } from './schema.js';

const { Pool } = pg;

export type DbStatus = 'up' | 'down' | 'disabled';
export type Db = NodePgDatabase<typeof schema>;

/**
 * Postgres provider with graceful degradation (P1 requirement):
 *  - no DATABASE_URL          -> status 'disabled', app boots, /health db:down.
 *  - DATABASE_URL unreachable -> status 'down', app boots with a warn.
 *  - reachable                -> migrations applied, status 'up'.
 *
 * Never throws at boot; failures degrade instead of crashing.
 */
@Injectable()
export class DatabaseService implements OnModuleInit, OnModuleDestroy {
  private readonly log = new Logger(DatabaseService.name);
  private pool: pg.Pool | null = null;
  private _db: Db | null = null;
  private _status: DbStatus = 'disabled';
  private _error: string | null = null;

  constructor(private readonly config: AppConfigService) {}

  get status(): DbStatus {
    return this._status;
  }
  get lastError(): string | null {
    return this._error;
  }
  get db(): Db | null {
    return this._db;
  }
  get isUp(): boolean {
    return this._status === 'up' && this._db !== null;
  }

  async onModuleInit(): Promise<void> {
    const url = this.config.databaseUrl;
    if (!url) {
      this._status = 'disabled';
      this.log.warn('DATABASE_URL absent — persistance désactivée (mode dégradé, /health: db:down)');
      return;
    }
    try {
      this.pool = new Pool({ connectionString: url, max: 5, connectionTimeoutMillis: 3000 });
      // Probe connectivity before declaring up.
      const client = await this.pool.connect();
      client.release();
      this._db = drizzle(this.pool, { schema });
      // Auto-migration au boot : pratique en dev/local, à désactiver en prod où
      // les migrations sont un acte délibéré (`npm run db:migrate` en CI/déploiement).
      if (this.config.dbAutoMigrate) {
        await this.runMigrations();
        this.log.log('Postgres connecté, migrations appliquées (status: up)');
      } else {
        this.log.log('Postgres connecté — auto-migrate désactivé (lancer `npm run db:migrate`) (status: up)');
      }
      this._status = 'up';
    } catch (err) {
      this._error = (err as Error).message;
      this._status = 'down';
      this.log.warn(`Postgres injoignable au boot — mode dégradé (db:down): ${this._error}`);
      try {
        await this.pool?.end();
      } catch {
        /* ignore */
      }
      this.pool = null;
      this._db = null;
    }
  }

  async onModuleDestroy(): Promise<void> {
    try {
      await this.pool?.end();
    } catch {
      /* ignore */
    }
  }

  /** Applies the raw SQL migrations in order (idempotent DDL). */
  async runMigrations(): Promise<void> {
    if (!this.pool) throw new Error('No pool to migrate');
    const dir = migrationsDir();
    const files = fs
      .readdirSync(dir)
      .filter((f) => f.endsWith('.sql'))
      .sort();
    for (const f of files) {
      const sql = fs.readFileSync(path.join(dir, f), 'utf8');
      await this.pool.query(sql);
      this.log.debug(`Migration appliquée: ${f}`);
    }
  }
}

export function migrationsDir(): string {
  // Works from both dist (compiled) and src (tsx). __dirname is the folder of
  // this file; migrations live in ./migrations, copied to dist at build time.
  const candidate = path.join(__dirname, 'migrations');
  if (fs.existsSync(candidate)) return candidate;
  // Fallback to source tree (when running compiled but sql not copied).
  return path.join(__dirname, '..', '..', 'src', 'persistence', 'migrations');
}
