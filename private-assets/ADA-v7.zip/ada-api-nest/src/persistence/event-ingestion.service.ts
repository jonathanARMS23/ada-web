import { Injectable, Logger, OnModuleInit, Optional } from '@nestjs/common';
import { eq, sql } from 'drizzle-orm';
import { ControlPlaneClient } from '../control-plane/control-plane.client.js';
import { OrchestrationEvents } from '../orchestration/orchestration-events.js';
import { DatabaseService, Db } from './database.service.js';
import { events, runs, runPhases, messages, toolCalls, costLedger } from './schema.js';
import type { ControlEvent } from '../control-plane/control-plane.types.js';

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
function asUuid(v: unknown): string | null {
  return typeof v === 'string' && UUID_RE.test(v) ? v : null;
}

/**
 * Ingests Control Plane events into Postgres (ADR-016 §3, ADR-017 §1.11).
 *
 * - Every event is upserted into `events` with ON CONFLICT (id) DO NOTHING (G3
 *   idempotence) so socket-push + ndjson-replay duplicates collapse.
 * - Lifecycle events also project into `runs` / `run_phases` (best-effort).
 * - Degrades silently if the DB is down/disabled (P1 read-only never blocks).
 */
@Injectable()
export class EventIngestionService implements OnModuleInit {
  private readonly log = new Logger(EventIngestionService.name);
  private ingested = 0;

  constructor(
    private readonly client: ControlPlaneClient,
    private readonly database: DatabaseService,
    @Optional() private readonly loopEvents?: OrchestrationEvents,
  ) {}

  onModuleInit(): void {
    // Hors-bande Control Server events (CLI/daemon/other instance).
    this.client.on('event', (evt: ControlEvent) => {
      void this.ingest(evt, 'control_server').catch((err) =>
        this.log.debug(`Ingestion event ${evt.id} échouée: ${(err as Error).message}`),
      );
    });
    // P2: OrchestrationLoop events — source of truth in Mode A (ADR-016 §3.A).
    this.loopEvents?.onEvent((evt: ControlEvent) => {
      void this.ingest(evt, 'orchestration_loop').catch((err) =>
        this.log.debug(`Ingestion loop event ${evt.id} échouée: ${(err as Error).message}`),
      );
    });
  }

  get ingestedCount(): number {
    return this.ingested;
  }

  /** Public entry used by tests and the live listeners. */
  async ingest(
    evt: ControlEvent,
    origin: 'orchestration_loop' | 'control_server' | 'client' = 'control_server',
  ): Promise<boolean> {
    const db = this.database.db;
    if (!db || !this.database.isUp) return false; // degraded: drop on the floor

    const corr = evt.corr ?? {};
    const coreRunId = corr.runId ?? (evt.payload?.runId as string | undefined) ?? null;
    const workspaceId = corr.workspaceId ?? null;

    await db
      .insert(events)
      .values({
        id: evt.id,
        type: evt.type,
        coreRunId,
        workspaceId: corr.workspaceId ?? null,
        conversationId: corr.conversationId ?? null,
        origin,
        payload: evt.payload ?? {},
        ts: new Date(evt.ts),
      })
      .onConflictDoNothing({ target: events.id });

    this.ingested++;
    await this.project(db, evt, coreRunId, workspaceId);
    return true;
  }

  /** Projects lifecycle events into runs/run_phases (best-effort, idempotent). */
  private async project(
    db: Db,
    evt: ControlEvent,
    coreRunId: string | null,
    workspaceId: string | null,
  ): Promise<void> {
    if (!coreRunId) return;
    const p = evt.payload ?? {};

    switch (evt.type) {
      case 'run.started': {
        await db
          .insert(runs)
          .values({
            coreRunId,
            pipeline: typeof p.pipeline === 'string' ? p.pipeline : 'unknown',
            name: typeof p.name === 'string' ? p.name : null,
            status: 'running',
            workspaceId,
            startedAt: new Date(evt.ts),
          })
          .onConflictDoNothing({ target: runs.coreRunId });
        break;
      }
      case 'run.completed': {
        await db
          .update(runs)
          .set({
            status: typeof p.status === 'string' ? p.status : 'completed',
            totalTokens: numberOr(p.totalTokens, 0),
            totalCost: String(numberOr(p.totalCost, 0)),
            completedAt: new Date(evt.ts),
            updatedAt: new Date(),
          })
          .where(eq(runs.coreRunId, coreRunId));
        break;
      }
      case 'run.phase.started': {
        await this.ensureRun(db, coreRunId);
        await db
          .insert(runPhases)
          .values({
            coreRunId,
            phaseId: String(p.phaseId ?? 'unknown'),
            agent: typeof p.agent === 'string' ? p.agent : null,
            model: typeof p.model === 'string' ? p.model : null,
            status: 'running',
            startedAt: new Date(evt.ts),
          })
          .onConflictDoNothing({ target: [runPhases.coreRunId, runPhases.phaseId, runPhases.retryCount] });
        break;
      }
      case 'run.phase.completed':
      case 'run.phase.failed': {
        const failed = evt.type === 'run.phase.failed';
        await this.ensureRun(db, coreRunId);
        const phaseId = String(p.phaseId ?? 'unknown');
        // Upsert the row first so an out-of-order completed event still lands.
        await db
          .insert(runPhases)
          .values({
            coreRunId,
            phaseId,
            agent: typeof p.agent === 'string' ? p.agent : null,
            status: failed ? 'failed' : 'completed',
            tokens: numberOr(p.tokens, 0),
            cost: String(numberOr(p.cost, 0)),
            durationMs: typeof p.durationMs === 'number' ? p.durationMs : null,
            error: failed && typeof p.error === 'string' ? p.error : null,
            retryable: failed && typeof p.retryable === 'boolean' ? p.retryable : null,
            completedAt: new Date(evt.ts),
          })
          .onConflictDoNothing({ target: [runPhases.coreRunId, runPhases.phaseId, runPhases.retryCount] });
        await db
          .update(runPhases)
          .set({
            status: failed ? 'failed' : 'completed',
            tokens: numberOr(p.tokens, 0),
            cost: String(numberOr(p.cost, 0)),
            durationMs: typeof p.durationMs === 'number' ? p.durationMs : null,
            error: failed && typeof p.error === 'string' ? p.error : null,
            completedAt: new Date(evt.ts),
            updatedAt: new Date(),
          })
          .where(eq(runPhases.coreRunId, coreRunId));
        // P6 : grand-livre des coûts + events WS de coût live. Une ligne par
        // phase porteuse d'un coût (completed, ou failed avec coût). Idempotent
        // par eventId. cost.delta émis sur le bus (room workspace).
        await this.recordCost(db, evt, coreRunId, phaseId, workspaceId);
        break;
      }
      case 'run.phase.output': {
        const chunk = typeof p.chunk === 'string' ? p.chunk : '';
        if (chunk) {
          await db.insert(messages).values({
            coreRunId,
            phaseId: String(p.phaseId ?? 'unknown'),
            role: 'assistant',
            content: chunk,
          });
        }
        break;
      }
      case 'run.phase.tool': {
        await db.insert(toolCalls).values({
          coreRunId,
          phaseId: String(p.phaseId ?? 'unknown'),
          tool: typeof p.tool === 'string' ? p.tool : 'unknown',
          input: (p.input as Record<string, unknown>) ?? {},
        });
        break;
      }
      default:
        break;
    }
  }

  /**
   * P6 — insère une ligne cost_ledger pour la phase terminée et émet cost.delta.
   * Idempotent par eventId (ON CONFLICT DO NOTHING) ; le cumul est recalculé
   * depuis le ledger (SUM) pour rester exact même en cas de rejeu/désordre.
   * Sans coût ni tokens, ne fait rien (failed sans coût → pas de ligne).
   */
  private async recordCost(
    db: Db,
    evt: ControlEvent,
    coreRunId: string,
    phaseId: string,
    workspaceId: string | null,
  ): Promise<void> {
    const p = evt.payload ?? {};
    const cost = numberOr(p.cost, 0);
    const inputTokens = numberOr(p.inputTokens, 0);
    const outputTokens = numberOr(p.outputTokens, 0);
    const tokens = numberOr(p.tokens, 0);
    // Pas de coût ni de tokens → rien à enregistrer (ex: phase failed à vide).
    if (cost <= 0 && inputTokens <= 0 && outputTokens <= 0 && tokens <= 0) return;

    // workspace_id du ledger est uuid : corr.workspaceId s'il est un UUID,
    // sinon résolution via runs.workspace_id (TEXT, idéalement un uuid en P5).
    let wsUuid = asUuid(workspaceId);
    if (!wsUuid) {
      const runRow = await db
        .select({ ws: runs.workspaceId })
        .from(runs)
        .where(eq(runs.coreRunId, coreRunId))
        .limit(1);
      wsUuid = asUuid(runRow[0]?.ws ?? null);
    }

    const res = await db
      .insert(costLedger)
      .values({
        eventId: evt.id,
        runId: coreRunId,
        phaseId,
        workspaceId: wsUuid,
        agent: typeof p.agent === 'string' ? p.agent : null,
        model: typeof p.model === 'string' ? p.model : null,
        tier: typeof p.tier === 'number' ? p.tier : null,
        inputTokens,
        outputTokens,
        cost: String(cost),
        ts: new Date(evt.ts),
      })
      .onConflictDoNothing({ target: costLedger.eventId })
      .returning({ id: costLedger.id });

    // Doublon (déjà ingéré) → pas de ré-émission d'event (G3 idempotence).
    if (res.length === 0) return;

    // Cumul du run = SUM(cost) du ledger (exact, ordre-insensible).
    const cumRow = await db
      .select({ total: sql<string>`coalesce(sum(${costLedger.cost}), 0)` })
      .from(costLedger)
      .where(eq(costLedger.runId, coreRunId));
    const cumulativeCost = Number(cumRow[0]?.total ?? 0);

    this.loopEvents?.emitRun(
      'cost.delta',
      { workspaceId: wsUuid, runId: coreRunId, phaseId, cost, cumulativeCost },
      { runId: coreRunId, workspaceId: wsUuid },
    );

    await this.maybeWarnBudget(coreRunId, wsUuid, cost, cumulativeCost);
  }

  /**
   * Relaie budget-guard via le RPC budget.check. Si un seuil est atteint
   * (action 'warn'/'stop'/'downgrade_tier' ou ok=false), émet budget.warning
   * {scope, spent, limit, pct} sur le bus. Dégrade en silence si le RPC échoue.
   */
  private async maybeWarnBudget(
    coreRunId: string,
    workspaceId: string | null,
    phaseCost: number,
    cumulativeCost: number,
  ): Promise<void> {
    if (!this.loopEvents) return;
    try {
      const res = await this.client.request<BudgetCheck>('budget.check', {
        runId: coreRunId,
        phaseCost,
        cumulCost: cumulativeCost,
      });
      if (res.ok && res.action === 'continue') return; // sous le seuil d'alerte
      const parsed = parseBudgetMessage(res.message ?? '');
      this.loopEvents.emitRun(
        'budget.warning',
        {
          scope: parsed.scope,
          spent: parsed.spent ?? cumulativeCost,
          limit: parsed.limit,
          pct: parsed.pct,
          action: res.action,
          message: res.message ?? '',
        },
        { runId: coreRunId, workspaceId },
      );
    } catch (err) {
      // budget.check lève BUDGET_EXCEEDED (action stop) côté control-server :
      // c'est un dépassement dur → on émet quand même un budget.warning 'stop'.
      const message = (err as Error).message ?? '';
      const parsed = parseBudgetMessage(message);
      this.loopEvents.emitRun(
        'budget.warning',
        {
          scope: parsed.scope,
          spent: parsed.spent ?? cumulativeCost,
          limit: parsed.limit,
          pct: parsed.pct,
          action: 'stop',
          message,
        },
        { runId: coreRunId, workspaceId },
      );
    }
  }

  private async ensureRun(db: Db, coreRunId: string): Promise<void> {
    await db
      .insert(runs)
      .values({ coreRunId, pipeline: 'unknown', status: 'running' })
      .onConflictDoNothing({ target: runs.coreRunId });
  }
}

function numberOr(v: unknown, fallback: number): number {
  return typeof v === 'number' && Number.isFinite(v) ? v : fallback;
}

interface BudgetCheck {
  ok: boolean;
  action: 'continue' | 'warn' | 'stop' | 'downgrade_tier';
  message: string;
}

interface BudgetParsed {
  scope: 'run' | 'session' | 'day' | 'unknown';
  spent: number | null;
  limit: number | null;
  pct: number | null;
}

/**
 * Parse les messages budget-guard ("Budget run à 85% ($x / $y)",
 * "Budget journalier dépassé ($x / $y)", etc.) pour exposer scope/spent/limit/pct
 * sur l'event budget.warning. Best-effort : champs null si non parsables.
 */
function parseBudgetMessage(msg: string): BudgetParsed {
  let scope: BudgetParsed['scope'] = 'unknown';
  if (/journalier/i.test(msg)) scope = 'day';
  else if (/session/i.test(msg)) scope = 'session';
  else if (/run/i.test(msg)) scope = 'run';

  const money = msg.match(/\$([\d.]+)\s*\/\s*\$([\d.]+)/);
  const spent = money ? Number(money[1]) : null;
  const limit = money ? Number(money[2]) : null;

  const pctMatch = msg.match(/(\d+)%/);
  let pct: number | null = pctMatch ? Number(pctMatch[1]) : null;
  if (pct === null && spent !== null && limit && limit > 0) {
    pct = Math.round((spent / limit) * 100);
  }
  return { scope, spent, limit, pct };
}
