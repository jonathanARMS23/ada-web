/* eslint-disable no-console */
import pg from 'pg';
import * as fs from 'node:fs';
import * as path from 'node:path';

const { Pool } = pg;

/**
 * Standalone migration runner: `npm run db:migrate`.
 * Applies the idempotent DDL in src/persistence/migrations in order.
 */
async function main(): Promise<void> {
  const url = process.env.DATABASE_URL;
  if (!url) {
    console.error('DATABASE_URL absent — rien à migrer.');
    process.exit(1);
  }
  const dir = path.join(__dirname, 'migrations');
  const files = fs
    .readdirSync(dir)
    .filter((f) => f.endsWith('.sql'))
    .sort();

  const pool = new Pool({ connectionString: url });
  try {
    for (const f of files) {
      const sql = fs.readFileSync(path.join(dir, f), 'utf8');
      await pool.query(sql);
      console.log(`✓ ${f}`);
    }
    console.log('Migrations appliquées.');
  } finally {
    await pool.end();
  }
}

main().catch((err) => {
  console.error('Migration échouée:', err.message);
  process.exit(1);
});
