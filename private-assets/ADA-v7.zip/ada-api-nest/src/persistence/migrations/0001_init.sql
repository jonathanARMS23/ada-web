-- P1 schema (subset of ADR-017): events, runs, run_phases.
-- Idempotent: safe to run repeatedly. pgcrypto provides gen_random_uuid().
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS runs (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  core_run_id   text NOT NULL UNIQUE,
  pipeline      text NOT NULL,
  feature       text,
  name          text,
  topology      text,
  status        text NOT NULL DEFAULT 'pending',
  phases_total  integer,
  phases_done   integer NOT NULL DEFAULT 0,
  total_tokens  bigint  NOT NULL DEFAULT 0,
  total_cost    numeric(12,6) NOT NULL DEFAULT 0,
  state         jsonb   NOT NULL DEFAULT '{}',
  started_at    timestamptz,
  completed_at  timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_runs_status   ON runs(status);
CREATE INDEX IF NOT EXISTS idx_runs_pipeline ON runs(pipeline, created_at DESC);

CREATE TABLE IF NOT EXISTS run_phases (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  core_run_id   text NOT NULL,
  phase_id      text NOT NULL,
  phase_type    text,
  agent         text,
  tier          integer,
  model         text,
  required      boolean NOT NULL DEFAULT true,
  status        text NOT NULL DEFAULT 'pending',
  retry_count   integer NOT NULL DEFAULT 0,
  tokens        bigint  NOT NULL DEFAULT 0,
  cost          numeric(12,6) NOT NULL DEFAULT 0,
  duration_ms   integer,
  summary       text,
  error         text,
  retryable     boolean,
  started_at    timestamptz,
  completed_at  timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_phases_run   ON run_phases(core_run_id);
CREATE INDEX IF NOT EXISTS idx_phases_agent ON run_phases(agent, status);
CREATE UNIQUE INDEX IF NOT EXISTS uq_phases_attempt ON run_phases(core_run_id, phase_id, retry_count);

-- Replayable journal (ADR-014 G1/G3/G4). id supplied by emitter -> idempotent.
CREATE TABLE IF NOT EXISTS events (
  id              uuid PRIMARY KEY,
  type            text NOT NULL,
  core_run_id     text,
  workspace_id    text,
  conversation_id text,
  origin          text NOT NULL DEFAULT 'control_server'
                  CHECK (origin IN ('orchestration_loop','control_server','client')),
  payload         jsonb NOT NULL DEFAULT '{}',
  seq             bigserial,
  ts              timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_events_run  ON events(core_run_id, seq);
CREATE INDEX IF NOT EXISTS idx_events_type ON events(type, ts DESC);
CREATE INDEX IF NOT EXISTS idx_events_seq  ON events(seq);
