-- P2 streaming surface (ADR-017): messages + tool_calls.
-- Idempotent: safe to run repeatedly.
CREATE TABLE IF NOT EXISTS messages (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  core_run_id text NOT NULL,
  phase_id    text NOT NULL,
  role        text NOT NULL DEFAULT 'assistant',
  content     text NOT NULL,
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_messages_run ON messages(core_run_id, phase_id);

CREATE TABLE IF NOT EXISTS tool_calls (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  core_run_id text NOT NULL,
  phase_id    text NOT NULL,
  tool        text NOT NULL,
  input       jsonb NOT NULL DEFAULT '{}',
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_tool_calls_run ON tool_calls(core_run_id, phase_id);
