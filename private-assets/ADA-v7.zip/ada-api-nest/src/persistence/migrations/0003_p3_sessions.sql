-- P3 interactive sessions + Permission Broker (ADR-016 §6/§6bis, ADR-017).
-- Idempotent: safe to run repeatedly.

-- Interactive Claude Code sessions (Mode B / bidirectional).
CREATE TABLE IF NOT EXISTS sessions (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  -- The claude `session_id` captured from the system/init stream-json event.
  -- NULL until the first init event arrives; used for --resume.
  claude_session_id text,
  profile         text NOT NULL,
  workspace_id    text,
  conversation_id text,
  -- Optional link to an ada-core run (free-form sessions usually have none).
  core_run_id     text,
  permission_mode text NOT NULL DEFAULT 'default',
  status          text NOT NULL DEFAULT 'active',
  cwd             text,
  total_tokens    bigint NOT NULL DEFAULT 0,
  total_cost      numeric(12,6) NOT NULL DEFAULT 0,
  last_message_at timestamptz,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_sessions_workspace ON sessions(workspace_id, created_at);
CREATE UNIQUE INDEX IF NOT EXISTS uq_sessions_claude_id ON sessions(claude_session_id)
  WHERE claude_session_id IS NOT NULL;

-- The P2 `messages` table is keyed by (core_run_id, phase_id). Sessions reuse
-- it with a session_id column added so user/assistant turns persist for both.
ALTER TABLE messages ADD COLUMN IF NOT EXISTS session_id uuid;
ALTER TABLE messages ADD COLUMN IF NOT EXISTS turn integer;
-- core_run_id/phase_id may be absent for free-form session turns.
ALTER TABLE messages ALTER COLUMN core_run_id DROP NOT NULL;
ALTER TABLE messages ALTER COLUMN phase_id   DROP NOT NULL;
CREATE INDEX IF NOT EXISTS idx_messages_session ON messages(session_id, turn);

-- tool_calls likewise gains an optional session link (P3 sessions also emit tools).
ALTER TABLE tool_calls ADD COLUMN IF NOT EXISTS session_id uuid;
ALTER TABLE tool_calls ALTER COLUMN core_run_id DROP NOT NULL;
ALTER TABLE tool_calls ALTER COLUMN phase_id   DROP NOT NULL;
CREATE INDEX IF NOT EXISTS idx_tool_calls_session ON tool_calls(session_id);

-- Per-profile permission policy (mirror of Claude Code settings.json
-- permissions.allow/deny/ask). One row per (profile, tool).
CREATE TABLE IF NOT EXISTS permission_policies (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile     text NOT NULL,
  tool        text NOT NULL,
  -- 'allow' (auto-approve, no UI), 'deny' (auto-reject), 'ask' (broker UI flow).
  decision    text NOT NULL,
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_policy_profile_tool ON permission_policies(profile, tool);

-- Audit of every permission decision (broker request/response).
CREATE TABLE IF NOT EXISTS permission_requests (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  request_id    text NOT NULL UNIQUE,
  session_id    uuid,
  core_run_id   text,
  profile       text NOT NULL,
  tool          text NOT NULL,
  input         jsonb NOT NULL DEFAULT '{}',
  -- 'allow' | 'deny' | 'allow_always'
  decision      text,
  -- how it was resolved: 'policy' (auto) | 'user' | 'timeout' | 'mode'
  resolved_by   text,
  updated_input jsonb,
  created_at    timestamptz NOT NULL DEFAULT now(),
  resolved_at   timestamptz
);
CREATE INDEX IF NOT EXISTS idx_perm_requests_session ON permission_requests(session_id, created_at);

-- Plan-mode plans + their steps.
CREATE TABLE IF NOT EXISTS plans (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id  uuid,
  core_run_id text,
  status      text NOT NULL DEFAULT 'pending', -- pending | approved | edited | rejected
  feedback    text,
  created_at  timestamptz NOT NULL DEFAULT now(),
  resolved_at timestamptz
);
CREATE INDEX IF NOT EXISTS idx_plans_session ON plans(session_id, created_at);

CREATE TABLE IF NOT EXISTS plan_steps (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_id     uuid NOT NULL,
  ordinal     integer NOT NULL,
  content     text NOT NULL,
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_plan_steps_plan ON plan_steps(plan_id, ordinal);

-- Clarification questions asked before/while routing.
CREATE TABLE IF NOT EXISTS clarifications (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id  uuid,
  core_run_id text,
  questions   jsonb NOT NULL DEFAULT '[]',
  answers     jsonb,
  status      text NOT NULL DEFAULT 'pending', -- pending | answered
  created_at  timestamptz NOT NULL DEFAULT now(),
  resolved_at timestamptz
);
CREATE INDEX IF NOT EXISTS idx_clarifications_session ON clarifications(session_id, created_at);
