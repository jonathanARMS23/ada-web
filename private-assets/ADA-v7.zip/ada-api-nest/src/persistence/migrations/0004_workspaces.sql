-- P5 — Workspaces & conversations (ADR-017 §1.2/§1.3 ; portage de la couche
-- Fastify ada-api/src/routes/workspaces.js + conversations.js).
-- Idempotent : sûr à rejouer (IF NOT EXISTS partout, ADD CONSTRAINT gardé).
--
-- Divergence assumée vs ADR-017 : pas de table `profiles` dans le périmètre
-- NestJS standalone — `profile` reste un TEXT libre (comme `sessions.profile`),
-- et `slug` est UNIQUE global (pas UNIQUE (profile_id, slug)). Les colonnes de
-- corrélation TEXT existantes (events/sessions.workspace_id, messages.*) sont
-- conservées telles quelles ; on ajoute des FK uuid réelles là où c'est cohérent
-- (conversations→workspaces, messages.conversation_id) et des index ailleurs.

-- ── workspaces ───────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS workspaces (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name        text NOT NULL,
  slug        text NOT NULL UNIQUE,
  profile     text NOT NULL DEFAULT 'claude-pro',
  color       text NOT NULL DEFAULT '#6366f1',
  description text,
  project_dir text,
  pinned      boolean NOT NULL DEFAULT false,
  archived    boolean NOT NULL DEFAULT false,
  run_count   integer NOT NULL DEFAULT 0,
  config      jsonb   NOT NULL DEFAULT '{}',
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_workspaces_updated ON workspaces(updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_workspaces_profile ON workspaces(profile);

-- ── conversations ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS conversations (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  title        text NOT NULL DEFAULT '',
  summary      text,
  pinned       boolean NOT NULL DEFAULT false,
  archived     boolean NOT NULL DEFAULT false,
  run_count    integer NOT NULL DEFAULT 0,
  last_run_id  uuid,
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_conversations_workspace ON conversations(workspace_id);
CREATE INDEX IF NOT EXISTS idx_conversations_updated   ON conversations(workspace_id, updated_at DESC);

-- ── messages : extension conversationnelle ───────────────────────────────────
-- La table `messages` (P2/P3) sert les chunks assistant (core_run_id/phase_id)
-- et les tours de session (session_id/turn). P5 la réutilise pour l'historique
-- conversationnel : ajout d'un lien conversation + type de contenu + metadata.
ALTER TABLE messages ADD COLUMN IF NOT EXISTS conversation_id uuid;
ALTER TABLE messages ADD COLUMN IF NOT EXISTS content_type    text NOT NULL DEFAULT 'text';
ALTER TABLE messages ADD COLUMN IF NOT EXISTS metadata        jsonb;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'fk_messages_conversation'
  ) THEN
    ALTER TABLE messages
      ADD CONSTRAINT fk_messages_conversation
      FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE;
  END IF;
END $$;
CREATE INDEX IF NOT EXISTS idx_messages_conversation ON messages(conversation_id, created_at);

-- ── FK différée conversations.last_run_id → runs.id (cycle résolu après coup) ──
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'fk_conversations_last_run'
  ) THEN
    ALTER TABLE conversations
      ADD CONSTRAINT fk_conversations_last_run
      FOREIGN KEY (last_run_id) REFERENCES runs(id) ON DELETE SET NULL;
  END IF;
END $$;

-- ── Corrélation runs/sessions/events ↔ workspaces ─────────────────────────────
-- Ces colonnes sont du TEXT (id de corrélation libre émis par le Control Server),
-- pas des uuid : on ne peut pas poser de FK uuid sans réécrire l'ingestion. On
-- garde donc TEXT + index pour les agrégats workspace (stats, scoping).
--
-- `runs` (0001) n'avait pas de colonne workspace_id (corrélation via events).
-- On l'ajoute (TEXT, nullable) pour que les stats workspace agrègent runs/coûts
-- directement sans jointure sur events.
ALTER TABLE runs ADD COLUMN IF NOT EXISTS workspace_id text;
CREATE INDEX IF NOT EXISTS idx_runs_workspace   ON runs(workspace_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_events_workspace ON events(workspace_id, seq);
-- idx_sessions_workspace existe déjà (0003).
