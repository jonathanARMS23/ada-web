-- P5 — Logs persistés (stockage + ingestion + rétention).
-- Remplace le stockage FS éphémère (events.ndjson / daemon.log) par une table
-- requêtable (filtres + pagination) alimentée par LogIngestionService.
-- Idempotent : sûr à rejouer.

CREATE TABLE IF NOT EXISTS logs (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ts           timestamptz NOT NULL DEFAULT now(),
  level        text NOT NULL DEFAULT 'info'
               CHECK (level IN ('debug','info','warn','error')),
  source       text NOT NULL DEFAULT 'unknown',
  core_run_id  text,
  workspace_id uuid,
  message      text NOT NULL,
  payload      jsonb,
  -- Clé de dédup d'ingestion (ex: "events.ndjson:<offset>" ou event id) ;
  -- ON CONFLICT DO NOTHING garantit l'idempotence du tail rejouable.
  dedup_key    text UNIQUE,
  created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_logs_ts     ON logs(ts DESC);
CREATE INDEX IF NOT EXISTS idx_logs_source ON logs(source, ts DESC);
CREATE INDEX IF NOT EXISTS idx_logs_level  ON logs(level, ts DESC);
CREATE INDEX IF NOT EXISTS idx_logs_run    ON logs(core_run_id);
