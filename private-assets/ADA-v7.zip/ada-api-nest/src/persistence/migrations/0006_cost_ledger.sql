-- P6 — cost_ledger : grand-livre des coûts LLM par phase, alimenté en continu.
-- Une ligne par phase terminée (run.phase.completed / failed avec coût), corrélée
-- au workspace via runs.workspace_id. Source des agrégats dashboard (overview /
-- activity / timeline) et des events WS de coût live (cost.delta).
-- Idempotent : sûr à rejouer (CREATE TABLE/INDEX IF NOT EXISTS).
--
-- La dédup d'ingestion se fait par l'event id source : event_id UNIQUE rend
-- l'insertion idempotente (ON CONFLICT DO NOTHING) face au double flux
-- OrchestrationLoop + Control Server (G3).

CREATE TABLE IF NOT EXISTS cost_ledger (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  -- event source ayant produit la ligne (dédup d'ingestion). NULL toléré pour
  -- des insertions manuelles/seed, mais l'ingestion fournit toujours l'id.
  event_id      uuid UNIQUE,
  run_id        text NOT NULL,
  phase_id      text,
  workspace_id  uuid,
  agent         text,
  model         text,
  tier          integer,
  input_tokens  bigint NOT NULL DEFAULT 0,
  output_tokens bigint NOT NULL DEFAULT 0,
  cost          numeric(12,6) NOT NULL DEFAULT 0,
  ts            timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_cost_ledger_workspace ON cost_ledger(workspace_id, ts);
CREATE INDEX IF NOT EXISTS idx_cost_ledger_run       ON cost_ledger(run_id);
CREATE INDEX IF NOT EXISTS idx_cost_ledger_ts        ON cost_ledger(ts DESC);
CREATE INDEX IF NOT EXISTS idx_cost_ledger_model     ON cost_ledger(model);
