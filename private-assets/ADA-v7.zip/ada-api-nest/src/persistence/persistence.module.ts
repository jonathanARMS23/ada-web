import { Global, Module } from '@nestjs/common';
import { DatabaseService } from './database.service.js';
import { EventIngestionService } from './event-ingestion.service.js';
import { ControlPlaneModule } from '../control-plane/control-plane.module.js';

@Global()
@Module({
  imports: [ControlPlaneModule],
  providers: [DatabaseService, EventIngestionService],
  exports: [DatabaseService, EventIngestionService],
})
export class PersistenceModule {}
