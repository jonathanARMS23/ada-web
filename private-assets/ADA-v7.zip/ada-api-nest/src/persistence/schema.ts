import {
  pgTable,
  uuid,
  text,
  jsonb,
  timestamp,
  integer,
  bigint,
  boolean,
  numeric,
  bigserial,
  index,
  uniqueIndex,
} from 'drizzle-orm/pg-core';
import { sql } from 'drizzle-orm';

/**
 * P1 subset of ADR-017. Only the tables needed for event ingestion + read:
 * `events`, `runs`, `run_phases`.
 *
 * Divergence from ADR-017 (documented): for the standalone read-only P1, the
 * full workspace/profile/conversation graph is NOT bootstrapped, so the FKs
 * those columns carry in ADR-017 are dropped here and the columns made nullable
 * (events arrive correlated by a TEXT core run id, not a uuid FK). The columns
 * are kept so P2 can add the FKs back once the graph exists.
 */

export const events = pgTable(
  'events',
  {
    // id provided by the emitter (control-server) — NO default (ADR-017 §1.11).
    id: uuid('id').primaryKey(),
    type: text('type').notNull(),
    // Raw correlation as emitted (control-server corr.runId is a TEXT core id).
    coreRunId: text('core_run_id'),
    workspaceId: text('workspace_id'),
    conversationId: text('conversation_id'),
    origin: text('origin', {
      enum: ['orchestration_loop', 'control_server', 'client'],
    })
      .notNull()
      .default('control_server'),
    payload: jsonb('payload').notNull().default({}),
    seq: bigserial('seq', { mode: 'number' }),
    ts: timestamp('ts', { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    byRun: index('idx_events_run').on(t.coreRunId, t.seq),
    byType: index('idx_events_type').on(t.type),
    bySeq: index('idx_events_seq').on(t.seq),
  }),
);

export const runs = pgTable(
  'runs',
  {
    id: uuid('id')
      .primaryKey()
      .default(sql`gen_random_uuid()`),
    coreRunId: text('core_run_id').notNull().unique(),
    pipeline: text('pipeline').notNull(),
    feature: text('feature'),
    name: text('name'),
    topology: text('topology'),
    status: text('status').notNull().default('pending'),
    phasesTotal: integer('phases_total'),
    phasesDone: integer('phases_done').notNull().default(0),
    totalTokens: bigint('total_tokens', { mode: 'number' }).notNull().default(0),
    totalCost: numeric('total_cost', { precision: 12, scale: 6 }).notNull().default('0'),
    state: jsonb('state').notNull().default({}),
    // P5: corrélation workspace (TEXT, ajoutée en 0004) pour les stats agrégées.
    workspaceId: text('workspace_id'),
    startedAt: timestamp('started_at', { withTimezone: true }),
    completedAt: timestamp('completed_at', { withTimezone: true }),
    createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    byStatus: index('idx_runs_status').on(t.status),
    byPipeline: index('idx_runs_pipeline').on(t.pipeline, t.createdAt),
    byWorkspace: index('idx_runs_workspace').on(t.workspaceId, t.createdAt),
  }),
);

export const runPhases = pgTable(
  'run_phases',
  {
    id: uuid('id')
      .primaryKey()
      .default(sql`gen_random_uuid()`),
    coreRunId: text('core_run_id').notNull(),
    phaseId: text('phase_id').notNull(),
    phaseType: text('phase_type'),
    agent: text('agent'),
    tier: integer('tier'),
    model: text('model'),
    required: boolean('required').notNull().default(true),
    status: text('status').notNull().default('pending'),
    retryCount: integer('retry_count').notNull().default(0),
    tokens: bigint('tokens', { mode: 'number' }).notNull().default(0),
    cost: numeric('cost', { precision: 12, scale: 6 }).notNull().default('0'),
    durationMs: integer('duration_ms'),
    summary: text('summary'),
    error: text('error'),
    retryable: boolean('retryable'),
    startedAt: timestamp('started_at', { withTimezone: true }),
    completedAt: timestamp('completed_at', { withTimezone: true }),
    createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    byRun: index('idx_phases_run').on(t.coreRunId),
    byAgent: index('idx_phases_agent').on(t.agent, t.status),
    uniqAttempt: uniqueIndex('uq_phases_attempt').on(t.coreRunId, t.phaseId, t.retryCount),
  }),
);

/**
 * P2 additions (ADR-017 streaming surface): `messages` (assistant text chunks)
 * and `tool_calls` (tool-use). Correlated by core run id + phase id.
 */
export const messages = pgTable(
  'messages',
  {
    id: uuid('id')
      .primaryKey()
      .default(sql`gen_random_uuid()`),
    // Nullable in P3: free-form session turns carry a sessionId instead.
    coreRunId: text('core_run_id'),
    phaseId: text('phase_id'),
    sessionId: uuid('session_id'),
    // P5: lien conversationnel (FK conversations, ajouté en 0004).
    conversationId: uuid('conversation_id'),
    turn: integer('turn'),
    role: text('role').notNull().default('assistant'),
    content: text('content').notNull(),
    contentType: text('content_type').notNull().default('text'),
    metadata: jsonb('metadata'),
    createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    byRun: index('idx_messages_run').on(t.coreRunId, t.phaseId),
    bySession: index('idx_messages_session').on(t.sessionId, t.turn),
    byConversation: index('idx_messages_conversation').on(t.conversationId, t.createdAt),
  }),
);

export const toolCalls = pgTable(
  'tool_calls',
  {
    id: uuid('id')
      .primaryKey()
      .default(sql`gen_random_uuid()`),
    coreRunId: text('core_run_id'),
    phaseId: text('phase_id'),
    sessionId: uuid('session_id'),
    tool: text('tool').notNull(),
    input: jsonb('input').notNull().default({}),
    createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    byRun: index('idx_tool_calls_run').on(t.coreRunId, t.phaseId),
    bySession: index('idx_tool_calls_session').on(t.sessionId),
  }),
);

/**
 * P3 interactive sessions (ADR-016 §6/§6bis, ADR-017). One row per Mode B
 * bidirectional Claude Code session; `claudeSessionId` captured from the
 * stream-json system/init event drives `--resume`.
 */
export const sessions = pgTable(
  'sessions',
  {
    id: uuid('id')
      .primaryKey()
      .default(sql`gen_random_uuid()`),
    claudeSessionId: text('claude_session_id'),
    profile: text('profile').notNull(),
    workspaceId: text('workspace_id'),
    conversationId: text('conversation_id'),
    coreRunId: text('core_run_id'),
    permissionMode: text('permission_mode').notNull().default('default'),
    status: text('status').notNull().default('active'),
    cwd: text('cwd'),
    totalTokens: bigint('total_tokens', { mode: 'number' }).notNull().default(0),
    totalCost: numeric('total_cost', { precision: 12, scale: 6 }).notNull().default('0'),
    lastMessageAt: timestamp('last_message_at', { withTimezone: true }),
    createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    byWorkspace: index('idx_sessions_workspace').on(t.workspaceId, t.createdAt),
    byClaudeId: uniqueIndex('uq_sessions_claude_id').on(t.claudeSessionId),
  }),
);

/** Per-profile permission policy (Fork #2 default + edits). */
export const permissionPolicies = pgTable(
  'permission_policies',
  {
    id: uuid('id')
      .primaryKey()
      .default(sql`gen_random_uuid()`),
    profile: text('profile').notNull(),
    tool: text('tool').notNull(),
    decision: text('decision', { enum: ['allow', 'deny', 'ask'] }).notNull(),
    createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    uniqProfileTool: uniqueIndex('uq_policy_profile_tool').on(t.profile, t.tool),
  }),
);

/** Audit of every permission broker decision. */
export const permissionRequests = pgTable(
  'permission_requests',
  {
    id: uuid('id')
      .primaryKey()
      .default(sql`gen_random_uuid()`),
    requestId: text('request_id').notNull().unique(),
    sessionId: uuid('session_id'),
    coreRunId: text('core_run_id'),
    profile: text('profile').notNull(),
    tool: text('tool').notNull(),
    input: jsonb('input').notNull().default({}),
    decision: text('decision'),
    resolvedBy: text('resolved_by'),
    updatedInput: jsonb('updated_input'),
    createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
    resolvedAt: timestamp('resolved_at', { withTimezone: true }),
  },
  (t) => ({
    bySession: index('idx_perm_requests_session').on(t.sessionId, t.createdAt),
  }),
);

/** Plan-mode plans + steps (ADR-016 §6bis C). */
export const plans = pgTable(
  'plans',
  {
    id: uuid('id')
      .primaryKey()
      .default(sql`gen_random_uuid()`),
    sessionId: uuid('session_id'),
    coreRunId: text('core_run_id'),
    status: text('status').notNull().default('pending'),
    feedback: text('feedback'),
    createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
    resolvedAt: timestamp('resolved_at', { withTimezone: true }),
  },
  (t) => ({
    bySession: index('idx_plans_session').on(t.sessionId, t.createdAt),
  }),
);

export const planSteps = pgTable(
  'plan_steps',
  {
    id: uuid('id')
      .primaryKey()
      .default(sql`gen_random_uuid()`),
    planId: uuid('plan_id').notNull(),
    ordinal: integer('ordinal').notNull(),
    content: text('content').notNull(),
    createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    byPlan: index('idx_plan_steps_plan').on(t.planId, t.ordinal),
  }),
);

/** Clarification questions/answers (ADR-016 §6bis C). */
export const clarifications = pgTable(
  'clarifications',
  {
    id: uuid('id')
      .primaryKey()
      .default(sql`gen_random_uuid()`),
    sessionId: uuid('session_id'),
    coreRunId: text('core_run_id'),
    questions: jsonb('questions').notNull().default([]),
    answers: jsonb('answers'),
    status: text('status').notNull().default('pending'),
    createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
    resolvedAt: timestamp('resolved_at', { withTimezone: true }),
  },
  (t) => ({
    bySession: index('idx_clarifications_session').on(t.sessionId, t.createdAt),
  }),
);

/**
 * P5 — Workspaces & conversations (ADR-017 §1.2/§1.3 ; portage Fastify).
 * `slug` UNIQUE global, `profile` TEXT libre (pas de table profiles standalone).
 */
export const workspaces = pgTable(
  'workspaces',
  {
    id: uuid('id')
      .primaryKey()
      .default(sql`gen_random_uuid()`),
    name: text('name').notNull(),
    slug: text('slug').notNull().unique(),
    profile: text('profile').notNull().default('claude-pro'),
    color: text('color').notNull().default('#6366f1'),
    description: text('description'),
    projectDir: text('project_dir'),
    pinned: boolean('pinned').notNull().default(false),
    archived: boolean('archived').notNull().default(false),
    runCount: integer('run_count').notNull().default(0),
    config: jsonb('config').notNull().default({}),
    createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    byUpdated: index('idx_workspaces_updated').on(t.updatedAt),
    byProfile: index('idx_workspaces_profile').on(t.profile),
  }),
);

export const conversations = pgTable(
  'conversations',
  {
    id: uuid('id')
      .primaryKey()
      .default(sql`gen_random_uuid()`),
    workspaceId: uuid('workspace_id')
      .notNull()
      .references(() => workspaces.id, { onDelete: 'cascade' }),
    title: text('title').notNull().default(''),
    summary: text('summary'),
    pinned: boolean('pinned').notNull().default(false),
    archived: boolean('archived').notNull().default(false),
    runCount: integer('run_count').notNull().default(0),
    lastRunId: uuid('last_run_id'),
    createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    byWorkspace: index('idx_conversations_workspace').on(t.workspaceId),
    byUpdated: index('idx_conversations_updated').on(t.workspaceId, t.updatedAt),
  }),
);

/**
 * P5 — Logs persistés. Alimentée par LogIngestionService (bus OrchestrationEvents
 * + tail events.ndjson). `dedupKey` UNIQUE rend le tail rejouable idempotent.
 */
export const logs = pgTable(
  'logs',
  {
    id: uuid('id')
      .primaryKey()
      .default(sql`gen_random_uuid()`),
    ts: timestamp('ts', { withTimezone: true }).notNull().defaultNow(),
    level: text('level', { enum: ['debug', 'info', 'warn', 'error'] })
      .notNull()
      .default('info'),
    source: text('source').notNull().default('unknown'),
    coreRunId: text('core_run_id'),
    workspaceId: uuid('workspace_id'),
    message: text('message').notNull(),
    payload: jsonb('payload'),
    dedupKey: text('dedup_key').unique(),
    createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    byTs: index('idx_logs_ts').on(t.ts),
    bySource: index('idx_logs_source').on(t.source, t.ts),
    byLevel: index('idx_logs_level').on(t.level, t.ts),
    byRun: index('idx_logs_run').on(t.coreRunId),
  }),
);

/**
 * P6 — cost_ledger : grand-livre des coûts LLM par phase, alimenté en continu
 * par EventIngestionService sur run.phase.completed/failed. `eventId` UNIQUE
 * rend l'ingestion idempotente (dédup par event id, G3). Source des agrégats
 * dashboard (overview/activity/timeline) + des events WS cost.delta.
 */
export const costLedger = pgTable(
  'cost_ledger',
  {
    id: uuid('id')
      .primaryKey()
      .default(sql`gen_random_uuid()`),
    eventId: uuid('event_id').unique(),
    runId: text('run_id').notNull(),
    phaseId: text('phase_id'),
    workspaceId: uuid('workspace_id'),
    agent: text('agent'),
    model: text('model'),
    tier: integer('tier'),
    inputTokens: bigint('input_tokens', { mode: 'number' }).notNull().default(0),
    outputTokens: bigint('output_tokens', { mode: 'number' }).notNull().default(0),
    cost: numeric('cost', { precision: 12, scale: 6 }).notNull().default('0'),
    ts: timestamp('ts', { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({
    byWorkspace: index('idx_cost_ledger_workspace').on(t.workspaceId, t.ts),
    byRun: index('idx_cost_ledger_run').on(t.runId),
    byTs: index('idx_cost_ledger_ts').on(t.ts),
    byModel: index('idx_cost_ledger_model').on(t.model),
  }),
);

export const schema = {
  events,
  runs,
  runPhases,
  messages,
  toolCalls,
  sessions,
  permissionPolicies,
  permissionRequests,
  plans,
  planSteps,
  clarifications,
  workspaces,
  conversations,
  logs,
  costLedger,
};
