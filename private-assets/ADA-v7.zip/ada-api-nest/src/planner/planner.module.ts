import { Module } from '@nestjs/common';
import { TaskRouterService } from './task-router.service.js';

/** Planner (TaskRouter) — instruction -> executable plan (ADR-016 §0). */
@Module({
  providers: [TaskRouterService],
  exports: [TaskRouterService],
})
export class PlannerModule {}
