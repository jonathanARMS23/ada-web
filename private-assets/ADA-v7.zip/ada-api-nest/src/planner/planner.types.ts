/** Planner output types (ADR-016 §0, Décision Fork #1 — Planner hybride). */

export type TaskMode = 'auto' | 'pipeline' | 'freeform';

export type PlanStrategy = 'pipeline' | 'freeform';

/** Flags passed to run.init (mirrors run.js cmdInit flags). */
export interface PlanOpts {
  backend?: 'nestjs' | 'drf';
  apiOnly?: boolean;
  noDeploy?: boolean;
  flags?: string[];
}

/** A concrete, executable plan derived from a free-form instruction. */
export interface TaskPlan {
  strategy: PlanStrategy;
  /** Set when strategy === 'pipeline'. Must exist in pipelines.json. */
  pipeline?: string;
  /** Feature/run name (sanitised slug) for run.init. */
  feature: string;
  /** Detected profile from the routing table (informational). */
  profile?: string;
  opts: PlanOpts;
  /** How the decision was reached (audit/observability). */
  decidedBy: 'keywords' | 'llm' | 'forced';
  /** Human-readable rationale. */
  rationale: string;
}

/** Returned instead of a plan when clarification is required (ADR-016 §6bis C). */
export interface ClarificationRequest {
  kind: 'clarification';
  questions: string[];
}

export type PlanResult = TaskPlan | ClarificationRequest;

export function isClarification(r: PlanResult): r is ClarificationRequest {
  return (r as ClarificationRequest).kind === 'clarification';
}
