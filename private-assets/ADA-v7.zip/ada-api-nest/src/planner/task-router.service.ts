import { Injectable, Logger } from '@nestjs/common';
import { ControlPlaneClient } from '../control-plane/control-plane.client.js';
import type {
  ClarificationRequest,
  PlanOpts,
  PlanResult,
  TaskMode,
} from './planner.types.js';

/**
 * Hybrid Planner (Décision Fork #1, ADR-016 §0).
 *
 * mode=auto:
 *   1. Keyword routing from the CLAUDE.md table (instruction -> pipeline).
 *   2. If no clear match (or ambiguous between several), fall back to a tier-1
 *      LLM classification via provider.complete to pick {strategy, pipeline?}.
 * mode=pipeline: forces a structured pipeline (keyword match or default `feature`).
 * mode=freeform: forces a free-form session plan. The interactive free-form
 *   session itself is P3, so P2 returns a `freeform` plan that the loop reports
 *   cleanly as "not implemented in P2" rather than spawning anything.
 *
 * Deterministic and unit-testable: the LLM fallback goes through the injected
 * ControlPlaneClient and is mockable.
 */
@Injectable()
export class TaskRouterService {
  private readonly log = new Logger(TaskRouterService.name);

  /**
   * Keyword routing rules distilled from the CLAUDE.md table. Each rule maps a
   * set of keywords to a pipeline that EXISTS in pipelines.json. Order matters:
   * the first rule whose keywords all/any-match wins.
   */
  private static readonly RULES: Array<{
    pipeline: string;
    profile: string;
    any: string[];
  }> = [
    { pipeline: 'security-audit', profile: 'review', any: ['owasp', 'sécurité', 'security audit', 'vulnérab'] },
    { pipeline: 'perf-audit', profile: 'review', any: ['perf', 'performance', 'n+1', 'profilage', 'bundle'] },
    { pipeline: 'review', profile: 'review', any: ['review', 'audit', 'revue de code', 'code review'] },
    { pipeline: 'hotfix', profile: 'backend-nestjs', any: ['hotfix', 'urgent', 'production down', 'incident'] },
    { pipeline: 'bug-fix', profile: 'backend-nestjs', any: ['bug', 'fix', 'corrige', 'régression', 'erreur'] },
    { pipeline: 'migration', profile: 'data', any: ['migration sans downtime', 'expand/contract', 'expand contract'] },
    { pipeline: 'data-migration', profile: 'data', any: ['migration de données', 'data migration', 'migrer les données'] },
    { pipeline: 'db-migrate', profile: 'data', any: ['migration', 'migrate', 'sql', 'schema', 'schéma', 'table'] },
    { pipeline: 'api-design', profile: 'strategy', any: ['openapi', 'contrat api', 'conception api', 'api design'] },
    { pipeline: 'saas-bootstrap', profile: 'saas-builder', any: ['saas', 'bootstrap', 'startup', 'nouveau projet'] },
    { pipeline: 'mobile', profile: 'mobile-rn', any: ['react native', 'expo', 'mobile', 'android', 'ios'] },
    { pipeline: 'test', profile: 'backend-nestjs', any: ['tests', 'coverage', 'test suite', 'lance les tests'] },
    { pipeline: 'feature', profile: 'fullstack', any: ['feature', 'fonctionnalité', 'endpoint', 'crud', 'module', 'ajoute', 'crée', 'implémente'] },
  ];

  constructor(private readonly client: ControlPlaneClient) {}

  /**
   * Plans a task from a free-form instruction.
   * Returns a TaskPlan or a ClarificationRequest (never throws on routing).
   */
  async plan(instruction: string, mode: TaskMode = 'auto'): Promise<PlanResult> {
    const feature = slugify(instruction);
    const opts = deriveOpts(instruction);

    if (mode === 'freeform') {
      return {
        strategy: 'freeform',
        feature,
        opts,
        decidedBy: 'forced',
        rationale: 'mode=freeform forcé (session interactive : P3)',
      };
    }

    const match = this.matchKeywords(instruction);

    if (mode === 'pipeline') {
      return {
        strategy: 'pipeline',
        pipeline: match?.pipeline ?? 'feature',
        feature,
        profile: match?.profile ?? 'fullstack',
        opts,
        decidedBy: match ? 'keywords' : 'forced',
        rationale: match
          ? `mode=pipeline : mots-clés -> ${match.pipeline}`
          : 'mode=pipeline forcé sans match : défaut feature',
      };
    }

    // mode=auto
    if (match && match.score >= 2) {
      return {
        strategy: 'pipeline',
        pipeline: match.pipeline,
        feature,
        profile: match.profile,
        opts,
        decidedBy: 'keywords',
        rationale: `routing mots-clés (${match.matched.join(', ')}) -> ${match.pipeline}`,
      };
    }

    // Ambiguous / weak match -> tier-1 LLM arbitration.
    return this.llmArbitrate(instruction, feature, opts, match?.pipeline);
  }

  // ── Keyword routing ─────────────────────────────────────────────────────────

  private matchKeywords(
    instruction: string,
  ): { pipeline: string; profile: string; score: number; matched: string[] } | null {
    const text = instruction.toLowerCase();
    let best: { pipeline: string; profile: string; score: number; matched: string[] } | null = null;
    for (const rule of TaskRouterService.RULES) {
      const matched = rule.any.filter((kw) => text.includes(kw));
      if (matched.length === 0) continue;
      // Longer keyword hits weigh more (e.g. "security audit" > "fix").
      const score = matched.reduce((s, kw) => s + (kw.includes(' ') ? 2 : 1), 0);
      if (!best || score > best.score) {
        best = { pipeline: rule.pipeline, profile: rule.profile, score, matched };
      }
    }
    return best;
  }

  // ── LLM fallback (tier 1 / haiku via provider.complete) ─────────────────────

  private async llmArbitrate(
    instruction: string,
    feature: string,
    opts: PlanOpts,
    hint?: string,
  ): Promise<PlanResult> {
    const pipelines = TaskRouterService.RULES.map((r) => r.pipeline);
    const uniquePipelines = [...new Set(pipelines)];
    const prompt =
      `Classe cette instruction de développement.\n` +
      `Réponds UNIQUEMENT par un objet JSON: ` +
      `{"strategy":"pipeline"|"freeform","pipeline":<nom|null>,"clarify":<string[]|null>}.\n` +
      `Pipelines valides: ${uniquePipelines.join(', ')}.\n` +
      `Si l'instruction est claire et structurable, strategy="pipeline" + pipeline.\n` +
      `Si exploratoire/hors pipeline, strategy="freeform".\n` +
      `Si trop ambiguë pour décider, mets clarify=[1 à 3 questions].\n` +
      `Instruction: ${instruction}`;

    try {
      const res = await this.client.request<{ content?: string }>('provider.complete', {
        messages: [{ role: 'user', content: prompt }],
        opts: { tier: 1 },
      });
      const parsed = parseLlmJson(res.content ?? '');
      if (parsed?.clarify && parsed.clarify.length > 0) {
        const clar: ClarificationRequest = { kind: 'clarification', questions: parsed.clarify.slice(0, 3) };
        return clar;
      }
      if (parsed?.strategy === 'freeform') {
        return {
          strategy: 'freeform',
          feature,
          opts,
          decidedBy: 'llm',
          rationale: 'repli LLM tier1 -> freeform',
        };
      }
      const pipeline =
        parsed?.pipeline && uniquePipelines.includes(parsed.pipeline)
          ? parsed.pipeline
          : (hint ?? 'feature');
      return {
        strategy: 'pipeline',
        pipeline,
        feature,
        opts,
        decidedBy: 'llm',
        rationale: `repli LLM tier1 -> ${pipeline}`,
      };
    } catch (err) {
      // LLM unreachable -> conservative default (keyword hint or feature).
      this.log.warn(`Repli LLM indisponible (${(err as Error).message}) — défaut pipeline`);
      return {
        strategy: 'pipeline',
        pipeline: hint ?? 'feature',
        feature,
        opts,
        decidedBy: 'keywords',
        rationale: `repli LLM échoué : défaut ${hint ?? 'feature'}`,
      };
    }
  }
}

// ── Pure helpers (deterministic, unit-tested) ─────────────────────────────────

export function slugify(instruction: string): string {
  const base = instruction
    .toLowerCase()
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 48);
  const trimmed = base.replace(/-+$/g, '');
  // run.js requires ^[a-z0-9][a-z0-9-]{2,59}$ (>= 3 chars).
  if (trimmed.length >= 3) return trimmed;
  return `task-${trimmed || 'x'}`;
}

export function deriveOpts(instruction: string): PlanOpts {
  const text = instruction.toLowerCase();
  const flags: string[] = [];
  const opts: PlanOpts = { flags };
  if (/\bapi[- ]only\b|\bsans (le )?front/.test(text)) {
    opts.apiOnly = true;
    flags.push('--api-only');
  }
  if (/\bsans d[ée]ploi|\bno[- ]deploy\b|\bpas de d[ée]ploi/.test(text)) {
    opts.noDeploy = true;
    flags.push('--no-deploy');
  }
  if (/\bdrf\b|\bdjango\b/.test(text)) {
    opts.backend = 'drf';
    flags.push('--backend', 'drf');
  } else if (/\bnestjs\b/.test(text)) {
    opts.backend = 'nestjs';
  }
  return opts;
}

interface LlmDecision {
  strategy?: 'pipeline' | 'freeform';
  pipeline?: string | null;
  clarify?: string[] | null;
}

function parseLlmJson(content: string): LlmDecision | null {
  const m = content.match(/\{[\s\S]*\}/);
  if (!m) return null;
  try {
    const obj = JSON.parse(m[0]) as Record<string, unknown>;
    return {
      strategy: obj.strategy === 'freeform' ? 'freeform' : obj.strategy === 'pipeline' ? 'pipeline' : undefined,
      pipeline: typeof obj.pipeline === 'string' ? obj.pipeline : null,
      clarify: Array.isArray(obj.clarify) ? obj.clarify.filter((q): q is string => typeof q === 'string') : null,
    };
  } catch {
    return null;
  }
}
