import { IsIn, IsOptional, IsString, MaxLength, MinLength } from 'class-validator';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { PERMISSION_MODES, type PermissionMode } from '../session.types.js';

/**
 * POST /sessions body (ADR-016 §6/§6bis, ROADMAP P3). Creates a new interactive
 * session or resumes one. All fields optional except an effective profile
 * (defaults to the configured active profile).
 */
export class CreateSessionDto {
  @ApiPropertyOptional({ description: 'Premier message utilisateur à envoyer après le démarrage.' })
  @IsOptional()
  @IsString()
  @MinLength(1)
  @MaxLength(100_000)
  message?: string;

  @ApiPropertyOptional({ description: 'Profil ada-core (défaut: profil actif).' })
  @IsOptional()
  @IsString()
  profile?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  workspaceId?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  conversationId?: string;

  @ApiPropertyOptional({ description: 'Lier la session à un run ada-core existant.' })
  @IsOptional()
  @IsString()
  coreRunId?: string;

  @ApiPropertyOptional({ enum: PERMISSION_MODES })
  @IsOptional()
  @IsIn(PERMISSION_MODES as unknown as string[])
  permissionMode?: PermissionMode;

  @ApiPropertyOptional({ description: 'Répertoire de travail du process claude.' })
  @IsOptional()
  @IsString()
  cwd?: string;

  @ApiPropertyOptional({ description: 'Reprendre une session existante (sessionId interne).' })
  @IsOptional()
  @IsString()
  resumeSessionId?: string;
}
