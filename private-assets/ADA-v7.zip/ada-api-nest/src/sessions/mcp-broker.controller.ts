import { Body, Controller, Post } from '@nestjs/common';
import { ApiExcludeController } from '@nestjs/swagger';
import { Public } from '../auth/public.decorator.js';
import { PermissionBrokerService, ApproveToolInput } from './permission-broker.service.js';

interface McpRpc {
  jsonrpc?: string;
  id?: string | number | null;
  method?: string;
  params?: Record<string, unknown>;
}

/**
 * @deprecated P3.5 — ABANDONED binding. The `--permission-prompt-tool` + custom
 * MCP server mechanism does NOT intercept permissions in headless `-p` mode
 * (the server stays `pending` and `approve` is never called — see the live
 * validation in docs/SESSIONS-permission-broker.md). Interception now happens
 * in-process via the Claude Agent SDK **`PreToolUse` hook**
 * ({@link SdkInteractiveSession}). This controller is retained ONLY so the
 * decision engine + request/response flow stay covered by unit tests and the
 * route does not 404 if an old client probes it; it is NOT on the live path and
 * MUST NOT be relied upon. Slated for removal once nothing references it.
 *
 * MCP Permission Broker server, HTTP transport (legacy, ADR-016 §6bis B).
 *
 * Hosts the `approve` tool that the spawned `claude` process reached via
 *   --permission-prompt-tool mcp__ada__approve --mcp-config <file>
 * where <file> pointed an HTTP MCP server at POST /api/mcp/broker.
 *
 * It speaks the minimal MCP JSON-RPC surface a permission-prompt tool needs:
 *   - `initialize`        -> protocol/capabilities handshake
 *   - `tools/list`        -> advertises the single `approve` tool
 *   - `tools/call`        -> runs `approve`, returns the allow/deny decision
 *
 * The tool result follows the Claude Code permission-prompt-tool contract: the
 * decision JSON ({behavior:"allow",updatedInput} | {behavior:"deny",message})
 * is returned as the tool's text content.
 *
 * This endpoint is @Public (no JWT): the local claude child reaches it on
 * loopback. Security note (ADR-016 §9): bind loopback only; a shared broker
 * token can be added once the live MCP transport is validated (see SESSIONS
 * doc). The decision flow itself is mediated by the policy engine + UI, so an
 * unauthorised caller can at most trigger an `ask` the user can deny.
 *
 * MCP wiring is UNTESTED against a live claude (no SDK / no claude in CI). The
 * decision engine + event flow are exercised via PermissionBrokerService unit
 * tests; this controller is the documented branch point for live validation.
 */
/** @deprecated P3.5 — legacy MCP broker; not on the live permission path. */
@ApiExcludeController()
@Controller('mcp/broker')
export class McpBrokerController {
  constructor(private readonly broker: PermissionBrokerService) {}

  @Post()
  @Public()
  async handle(@Body() body: McpRpc): Promise<unknown> {
    const id = body.id ?? null;
    switch (body.method) {
      case 'initialize':
        return this.rpc(id, {
          protocolVersion: '2024-11-05',
          serverInfo: { name: 'ada-permission-broker', version: '1.0.0' },
          capabilities: { tools: {} },
        });

      case 'notifications/initialized':
        // Notification: no response body required.
        return this.rpc(id, {});

      case 'tools/list':
        return this.rpc(id, {
          tools: [
            {
              name: 'approve',
              description:
                'ADA permission broker. Approve or deny a guarded tool call per the profile policy and user decision.',
              inputSchema: {
                type: 'object',
                properties: {
                  tool_name: { type: 'string' },
                  input: { type: 'object' },
                  session_id: { type: 'string' },
                },
                required: ['tool_name', 'input'],
              },
            },
          ],
        });

      case 'tools/call': {
        const params = body.params ?? {};
        const name = params.name;
        if (name !== 'approve') {
          return this.rpcError(id, -32601, `unknown tool: ${String(name)}`);
        }
        const args = (params.arguments as ApproveToolInput | undefined) ?? {
          tool_name: '',
          input: {},
        };
        const result = await this.broker.approve(args);
        // MCP tool result: the permission-prompt decision as JSON text content.
        return this.rpc(id, {
          content: [{ type: 'text', text: JSON.stringify(result) }],
          isError: false,
        });
      }

      default:
        return this.rpcError(id, -32601, `method not found: ${String(body.method)}`);
    }
  }

  private rpc(id: string | number | null, result: unknown): McpRpc & { result: unknown } {
    return { jsonrpc: '2.0', id, result };
  }

  private rpcError(id: string | number | null, code: number, message: string) {
    return { jsonrpc: '2.0', id, error: { code, message } };
  }
}
