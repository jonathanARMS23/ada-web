import { Injectable } from '@nestjs/common';
import { randomUUID } from 'node:crypto';
import { StreamParser } from '../orchestration/stream-parser.js';
import type {
  InteractiveSession,
  InteractiveSessionFactory,
  SessionStartOptions,
} from './session.types.js';

/**
 * Mock bidirectional session (ADR-016 §6/§6bis A, P3 tests/dev).
 *
 * Reproduces the bidirectional contract WITHOUT spawning `claude`:
 *  - On start, emits a canned `system/init` frame (so the real StreamParser
 *    captures a `session_id`), then a first assistant turn + `result`.
 *  - `send()` (a `task.message` follow-up) produces another assistant turn +
 *    `result`, exactly like writing a user message to claude's stdin.
 *  - `--resume`: if `resumeClaudeSessionId` is given, that id is reused as the
 *    session_id, proving resume threads the same conversation.
 *
 * Every NDJSON line is fed through the REAL StreamParser, so the whole
 * session_id-capture + output/tool/usage path is exercised in tests.
 */
@Injectable()
export class MockInteractiveSessionFactory implements InteractiveSessionFactory {
  readonly kind = 'mock' as const;
  start(opts: SessionStartOptions): InteractiveSession {
    return new MockInteractiveSession(opts);
  }
}

class MockInteractiveSession implements InteractiveSession {
  readonly sessionId: string;
  private _claudeSessionId: string | null = null;
  private _closed = false;
  private turn = 0;
  private readonly parser: StreamParser;

  constructor(private readonly opts: SessionStartOptions) {
    this.sessionId = opts.sessionId;
    // Resume reuses the prior claude session_id; otherwise a fresh one is minted
    // (mirrors claude emitting a new session_id in system/init).
    const sid = opts.resumeClaudeSessionId ?? `claude-${randomUUID()}`;
    this.parser = new StreamParser((e) => {
      this.opts.onEvent({ ...e, sessionId: this.sessionId });
    });
    // First frame: system/init with the session_id.
    queueMicrotask(() => {
      this.feed(JSON.stringify({ type: 'system', subtype: 'init', session_id: sid }));
      if (this.parser.sessionId && this.parser.sessionId !== this._claudeSessionId) {
        this._claudeSessionId = this.parser.sessionId;
        this.opts.onEvent({ kind: 'session_id', sessionId: this.sessionId, claudeSessionId: this._claudeSessionId });
      }
      // Initial assistant greeting turn (no user message yet for a fresh start
      // resumed sessions also greet to confirm liveness).
      void this.emitAssistantTurn('[mock] session prête');
    });
  }

  get claudeSessionId(): string | null {
    return this._claudeSessionId;
  }
  get closed(): boolean {
    return this._closed;
  }

  async send(content: string): Promise<void> {
    if (this._closed) throw new Error('session fermée');
    // Echo a deterministic assistant turn referencing the user content.
    await this.emitAssistantTurn(`[mock] réponse à: ${content.slice(0, 60)}`);
  }

  interrupt(): void {
    // Mock: surface an interrupt as an output marker (no real signal).
    if (!this._closed) {
      this.opts.onEvent({ kind: 'output', chunk: '[mock] interrupted', sessionId: this.sessionId });
    }
  }

  async cancel(): Promise<void> {
    if (this._closed) return;
    this._closed = true;
    this.opts.onEvent({ kind: 'closed', sessionId: this.sessionId, code: 0 });
  }

  private async emitAssistantTurn(text: string): Promise<void> {
    this.turn++;
    const tokens = 40 + text.length;
    const cost = Number((tokens * 0.000003).toFixed(6));
    this.feed(
      JSON.stringify({ type: 'assistant', message: { content: [{ type: 'text', text }] } }),
    );
    this.feed(
      JSON.stringify({
        type: 'result',
        subtype: 'success',
        is_error: false,
        result: text,
        session_id: this._claudeSessionId,
        usage: { input_tokens: Math.floor(tokens / 2), output_tokens: Math.ceil(tokens / 2) },
        total_cost_usd: cost,
      }),
    );
    await Promise.resolve();
    this.opts.onEvent({
      kind: 'turn_complete',
      sessionId: this.sessionId,
      summary: this.parser.summary,
      tokens: this.parser.usage.tokens,
      cost: this.parser.usage.cost,
    });
  }

  private feed(line: string): void {
    this.parser.push(line + '\n');
  }
}
