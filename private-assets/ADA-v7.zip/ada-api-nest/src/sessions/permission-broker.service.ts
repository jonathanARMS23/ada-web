import { Injectable, Logger } from '@nestjs/common';
import { PermissionPolicyService } from './permission-policy.service.js';
import { SessionManager } from './session-manager.service.js';
import { AppConfigService } from '../config/app-config.service.js';
import type { BrokerResult, PermissionRequestContext } from './permission.types.js';
import type { PermissionMode } from './session.types.js';

/** Arguments the MCP `approve` tool receives from claude. */
export interface ApproveToolInput {
  /** Tool the model wants to use (Bash/Write/Edit/...). */
  tool_name: string;
  /** Tool input the model proposes. */
  input: Record<string, unknown>;
  /**
   * The ada session id, threaded via the MCP server URL/header so the broker
   * can correlate. Optional: when absent we fall back to the default profile.
   */
  session_id?: string;
}

/**
 * @deprecated P3.5 — entry point of the ABANDONED MCP `approve` binding (the
 * live permission path is now the SDK `PreToolUse` hook in
 * {@link SdkInteractiveSession}, which calls {@link PermissionPolicyService}
 * directly). Kept only so the legacy {@link McpBrokerController} and the policy
 * request/response flow remain unit-tested. Not on the live path.
 *
 * Permission Broker service (legacy, ADR-016 §6bis B). Builds a
 * PermissionRequestContext from the approve args + the owning session's
 * correlation, then delegates to the policy engine.
 */
@Injectable()
export class PermissionBrokerService {
  private readonly log = new Logger(PermissionBrokerService.name);

  constructor(
    private readonly policy: PermissionPolicyService,
    private readonly sessions: SessionManager,
    private readonly config: AppConfigService,
  ) {}

  /** MCP tool name exposed to claude (`--permission-prompt-tool`). */
  get toolName(): string {
    return this.config.permissionPromptTool;
  }

  /**
   * Evaluates an `approve` tool call. Returns the broker result the MCP layer
   * serialises back to claude.
   */
  async approve(args: ApproveToolInput): Promise<BrokerResult> {
    const tool = args.tool_name;
    const input = args.input ?? {};
    const sessionId = args.session_id ?? null;

    const corr = sessionId ? this.sessions.corrOf(sessionId) : null;
    const mode: PermissionMode =
      (sessionId ? this.sessions.getMode(sessionId) : null) ?? 'default';

    const ctx: PermissionRequestContext = {
      requestId: PermissionPolicyService.newRequestId(),
      sessionId,
      coreRunId: corr?.coreRunId ?? null,
      profile: this.config.profile,
      workspaceId: corr?.workspaceId ?? null,
      conversationId: corr?.conversationId ?? null,
      permissionMode: mode,
      tool,
      input,
    };

    this.log.debug(`approve(${tool}) session=${sessionId ?? '-'} mode=${mode}`);
    return this.policy.evaluate(ctx);
  }
}
