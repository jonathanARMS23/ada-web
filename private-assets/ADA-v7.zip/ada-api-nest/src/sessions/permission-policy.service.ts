import { Injectable, Logger } from '@nestjs/common';
import { randomUUID } from 'node:crypto';
import { and, eq } from 'drizzle-orm';
import { DatabaseService } from '../persistence/database.service.js';
import { permissionPolicies, permissionRequests } from '../persistence/schema.js';
import { OrchestrationEvents } from '../orchestration/orchestration-events.js';
import { AppConfigService } from '../config/app-config.service.js';
import {
  BrokerResult,
  PermissionDecision,
  PermissionRequestContext,
  PolicyDecision,
  ResolvedBy,
  defaultDecisionForTool,
} from './permission.types.js';

interface PendingPermission {
  ctx: PermissionRequestContext;
  resolve: (r: { decision: PermissionDecision; updatedInput?: Record<string, unknown> }) => void;
  timer: NodeJS.Timeout;
}

/**
 * Permission Broker policy engine (ADR-016 §6bis B, Décision Fork #2).
 *
 * For every guarded tool call (routed here by the MCP `approve` tool), it:
 *   1. Honours the permission MODE first: bypassPermissions -> allow,
 *      plan -> deny (no mutation in plan mode).
 *   2. Resolves the effective policy: per-profile DB override (allow|deny|ask),
 *      falling back to the Fork #2 default (Read/Grep/... = allow, the rest =
 *      ask). acceptEdits upgrades Edit/Write/MultiEdit to allow.
 *   3. `allow`/`deny` resolve IMMEDIATELY with no UI round-trip (risk #3
 *      short-circuit). `ask` emits `task.permission_request` via the
 *      StreamGateway bus and AWAITS `task.permission_response`, with a
 *      configurable timeout that defaults to `deny`.
 *
 * `allow_always` from the user persists an `allow` rule into permission_policies
 * for that (profile, tool). Every decision is audited in permission_requests.
 *
 * The engine is transport-agnostic: it emits/consumes events on the in-process
 * OrchestrationEvents bus, so it is fully unit-testable without a live socket,
 * MCP server, or claude process.
 */
@Injectable()
export class PermissionPolicyService {
  private readonly log = new Logger(PermissionPolicyService.name);
  private readonly pending = new Map<string, PendingPermission>();
  /** In-memory policy cache when the DB is down/disabled. profile -> tool -> decision. */
  private readonly memPolicy = new Map<string, Map<string, PolicyDecision>>();

  constructor(
    private readonly database: DatabaseService,
    private readonly events: OrchestrationEvents,
    private readonly config: AppConfigService,
  ) {}

  /**
   * Evaluates a guarded tool call and returns the broker result for the MCP
   * `approve` tool. Never throws: on any internal error it denies safely.
   */
  async evaluate(ctx: PermissionRequestContext): Promise<BrokerResult> {
    try {
      return await this.evaluateInner(ctx);
    } catch (err) {
      this.log.warn(`Évaluation permission ${ctx.requestId} échouée: ${(err as Error).message}`);
      await this.audit(ctx, 'deny', 'policy');
      return { behavior: 'deny', message: 'permission evaluation error' };
    }
  }

  private async evaluateInner(ctx: PermissionRequestContext): Promise<BrokerResult> {
    // 1. Mode overrides (ADR-016 §6bis B modes).
    if (ctx.permissionMode === 'bypassPermissions') {
      await this.audit(ctx, 'allow', 'mode');
      return { behavior: 'allow', updatedInput: ctx.input };
    }
    if (ctx.permissionMode === 'plan') {
      await this.audit(ctx, 'deny', 'mode');
      return { behavior: 'deny', message: 'plan mode: aucune mutation autorisée' };
    }

    // 2. Effective policy.
    const policy = await this.resolvePolicy(ctx.profile, ctx.tool, ctx.permissionMode);

    if (policy === 'allow') {
      await this.audit(ctx, 'allow', 'policy');
      return { behavior: 'allow', updatedInput: ctx.input };
    }
    if (policy === 'deny') {
      await this.audit(ctx, 'deny', 'policy');
      return { behavior: 'deny', message: `outil ${ctx.tool} refusé par politique` };
    }

    // 3. ask -> emit request, await response (timeout -> deny).
    return this.askUser(ctx);
  }

  /**
   * Resolves the effective decision for (profile, tool) under a mode.
   * acceptEdits upgrades edit-class tools to allow.
   */
  async resolvePolicy(
    profile: string,
    tool: string,
    mode: import('./session.types.js').PermissionMode = 'default',
  ): Promise<PolicyDecision> {
    if (mode === 'acceptEdits' && (tool === 'Edit' || tool === 'Write' || tool === 'MultiEdit')) {
      return 'allow';
    }
    const override = await this.lookupPolicy(profile, tool);
    return override ?? defaultDecisionForTool(tool);
  }

  /** Emits task.permission_request and waits for task.permission_response. */
  private askUser(ctx: PermissionRequestContext): Promise<BrokerResult> {
    return new Promise<BrokerResult>((resolve) => {
      const timeoutMs = this.config.permissionTimeoutMs;
      const timer = setTimeout(() => {
        const p = this.pending.get(ctx.requestId);
        if (!p) return;
        this.pending.delete(ctx.requestId);
        void this.audit(ctx, 'deny', 'timeout');
        this.log.warn(`Permission ${ctx.requestId} (${ctx.tool}) expirée -> deny`);
        resolve({ behavior: 'deny', message: `timeout (${timeoutMs}ms): refus par défaut` });
      }, timeoutMs);
      timer.unref?.();

      this.pending.set(ctx.requestId, {
        ctx,
        timer,
        resolve: ({ decision, updatedInput }) => {
          void this.persistAllowAlways(ctx, decision);
          void this.audit(ctx, decision, 'user', updatedInput);
          if (decision === 'deny') {
            resolve({ behavior: 'deny', message: 'refusé par l’utilisateur' });
          } else {
            resolve({ behavior: 'allow', updatedInput: updatedInput ?? ctx.input });
          }
        },
      });

      // Emit the request to the UI (StreamGateway forwards by workspace room).
      this.events.emitRun(
        'task.permission_request',
        { requestId: ctx.requestId, sessionId: ctx.sessionId, tool: ctx.tool, input: ctx.input },
        { runId: ctx.coreRunId, workspaceId: ctx.workspaceId, conversationId: ctx.conversationId },
      );
    });
  }

  /**
   * Handles an inbound task.permission_response (§3.C). Returns true if a
   * pending request matched. Called by the SessionGateway.
   */
  resolvePermission(
    requestId: string,
    decision: PermissionDecision,
    updatedInput?: Record<string, unknown>,
  ): boolean {
    const p = this.pending.get(requestId);
    if (!p) return false;
    this.pending.delete(requestId);
    clearTimeout(p.timer);
    p.resolve({ decision, updatedInput });
    return true;
  }

  get pendingCount(): number {
    return this.pending.size;
  }

  // ── Policy storage ──────────────────────────────────────────────────────────

  private async lookupPolicy(profile: string, tool: string): Promise<PolicyDecision | null> {
    const db = this.database.db;
    if (db && this.database.isUp) {
      const rows = await db
        .select()
        .from(permissionPolicies)
        .where(and(eq(permissionPolicies.profile, profile), eq(permissionPolicies.tool, tool)))
        .limit(1);
      const d = rows[0]?.decision;
      return d === 'allow' || d === 'deny' || d === 'ask' ? d : null;
    }
    return this.memPolicy.get(profile)?.get(tool) ?? null;
  }

  /** Persists an `allow` rule for allow_always (DB or in-memory fallback). */
  private async persistAllowAlways(
    ctx: PermissionRequestContext,
    decision: PermissionDecision,
  ): Promise<void> {
    if (decision !== 'allow_always') return;
    await this.upsertPolicy(ctx.profile, ctx.tool, 'allow');
  }

  /** Public: edit a profile policy (REST/PUT and allow_always). */
  async upsertPolicy(profile: string, tool: string, decision: PolicyDecision): Promise<void> {
    const db = this.database.db;
    if (db && this.database.isUp) {
      await db
        .insert(permissionPolicies)
        .values({ profile, tool, decision })
        .onConflictDoUpdate({
          target: [permissionPolicies.profile, permissionPolicies.tool],
          set: { decision, updatedAt: new Date() },
        });
      return;
    }
    let m = this.memPolicy.get(profile);
    if (!m) {
      m = new Map();
      this.memPolicy.set(profile, m);
    }
    m.set(tool, decision);
  }

  /** Returns the effective policy table for a profile (defaults + overrides). */
  async listPolicy(profile: string): Promise<Array<{ tool: string; decision: PolicyDecision; source: 'default' | 'override' }>> {
    const tools = new Set<string>([
      ...['Read', 'Grep', 'Glob', 'LS', 'NotebookRead'],
      ...['Bash', 'Write', 'Edit', 'MultiEdit', 'WebFetch'],
    ]);
    const overrides = new Map<string, PolicyDecision>();
    const db = this.database.db;
    if (db && this.database.isUp) {
      const rows = await db.select().from(permissionPolicies).where(eq(permissionPolicies.profile, profile));
      for (const r of rows) {
        if (r.decision === 'allow' || r.decision === 'deny' || r.decision === 'ask') {
          overrides.set(r.tool, r.decision);
          tools.add(r.tool);
        }
      }
    } else {
      for (const [tool, decision] of this.memPolicy.get(profile)?.entries() ?? []) {
        overrides.set(tool, decision);
        tools.add(tool);
      }
    }
    return [...tools].map((tool) => {
      const override = overrides.get(tool);
      return override
        ? { tool, decision: override, source: 'override' as const }
        : { tool, decision: defaultDecisionForTool(tool), source: 'default' as const };
    });
  }

  // ── Audit ───────────────────────────────────────────────────────────────────

  private async audit(
    ctx: PermissionRequestContext,
    decision: PermissionDecision,
    resolvedBy: ResolvedBy,
    updatedInput?: Record<string, unknown>,
  ): Promise<void> {
    const db = this.database.db;
    if (!db || !this.database.isUp) return; // degraded: audit dropped, decision still served
    try {
      await db
        .insert(permissionRequests)
        .values({
          requestId: ctx.requestId,
          sessionId: ctx.sessionId,
          coreRunId: ctx.coreRunId,
          profile: ctx.profile,
          tool: ctx.tool,
          input: ctx.input,
          decision,
          resolvedBy,
          updatedInput: updatedInput ?? null,
          resolvedAt: new Date(),
        })
        .onConflictDoUpdate({
          target: permissionRequests.requestId,
          set: { decision, resolvedBy, updatedInput: updatedInput ?? null, resolvedAt: new Date() },
        });
    } catch (err) {
      this.log.debug(`Audit permission ${ctx.requestId} échoué: ${(err as Error).message}`);
    }
  }

  /** Builds a fresh requestId (used by the MCP broker entry point). */
  static newRequestId(): string {
    return randomUUID();
  }
}
