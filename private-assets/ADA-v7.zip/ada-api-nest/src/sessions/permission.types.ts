/** Permission Broker types (ADR-016 §6bis B, Décision Fork #2). */

export type PolicyDecision = 'allow' | 'deny' | 'ask';

/** A user/broker decision on a pending permission request (§3.C response). */
export type PermissionDecision = 'allow' | 'deny' | 'allow_always';

/**
 * Result the broker hands back to the MCP `approve` tool. `behavior` mirrors the
 * Claude Code permission-prompt-tool contract: `allow` (optionally with a
 * modified `updatedInput`) or `deny` (with a `message`).
 */
export interface BrokerResult {
  behavior: 'allow' | 'deny';
  updatedInput?: Record<string, unknown>;
  message?: string;
}

/** How a permission request was resolved (audit). */
export type ResolvedBy = 'policy' | 'user' | 'timeout' | 'mode';

/** A permission request the broker is evaluating. */
export interface PermissionRequestContext {
  requestId: string;
  sessionId: string | null;
  coreRunId: string | null;
  profile: string;
  workspaceId: string | null;
  conversationId: string | null;
  permissionMode: import('./session.types.js').PermissionMode;
  tool: string;
  input: Record<string, unknown>;
}

/**
 * Décision Fork #2 (verrouillée) — default per-tool policy.
 * Read-only tools auto-approve (no UI round-trip); mutating tools ask.
 */
export const DEFAULT_AUTO_ALLOW_TOOLS: readonly string[] = [
  'Read',
  'Grep',
  'Glob',
  'LS',
  'NotebookRead',
];

export const DEFAULT_ASK_TOOLS: readonly string[] = [
  'Bash',
  'Write',
  'Edit',
  'MultiEdit',
  'WebFetch',
];

/**
 * Resolves the default decision for a tool name (Fork #2). MCP tools
 * (`mcp__*`) default to `ask`. Unknown tools default to `ask` (safe).
 */
export function defaultDecisionForTool(tool: string): PolicyDecision {
  if (DEFAULT_AUTO_ALLOW_TOOLS.includes(tool)) return 'allow';
  // Everything else (Bash/Write/Edit/MultiEdit/WebFetch/MCP/unknown) -> ask.
  return 'ask';
}
