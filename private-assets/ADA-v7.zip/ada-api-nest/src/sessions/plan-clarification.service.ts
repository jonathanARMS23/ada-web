import { Injectable, Logger } from '@nestjs/common';
import { randomUUID } from 'node:crypto';
import { eq } from 'drizzle-orm';
import { DatabaseService } from '../persistence/database.service.js';
import { plans, planSteps, clarifications } from '../persistence/schema.js';
import { OrchestrationEvents } from '../orchestration/orchestration-events.js';

interface PendingPlan {
  resolve: (r: { decision: 'approve' | 'edit'; feedback?: string }) => void;
  corr: Corr;
  sessionId: string | null;
  coreRunId: string | null;
}
interface PendingClarification {
  resolve: (answers: Record<string, string>) => void;
  corr: Corr;
  sessionId: string | null;
  coreRunId: string | null;
}
interface Corr {
  runId: string | null;
  workspaceId: string | null;
  conversationId: string | null;
}

/**
 * Plan mode + clarifications (ADR-016 §6bis C, §3.C).
 *
 * - askPlan(steps) -> emits `task.plan {planId, steps}`, awaits
 *   `task.plan_response {approve|edit, feedback?}`.
 * - askClarification(questions) -> emits `task.clarification {clarificationId,
 *   questions}`, awaits `task.clarification_response {answers}`.
 *
 * Both persist to `plans`/`plan_steps` and `clarifications`. The resolve side is
 * driven by the SessionGateway forwarding the inbound WS messages. Like the
 * permission broker, it is transport-agnostic and unit-testable.
 */
@Injectable()
export class PlanClarificationService {
  private readonly log = new Logger(PlanClarificationService.name);
  private readonly pendingPlans = new Map<string, PendingPlan>();
  private readonly pendingClar = new Map<string, PendingClarification>();

  constructor(
    private readonly database: DatabaseService,
    private readonly events: OrchestrationEvents,
  ) {}

  // ── Plan mode ─────────────────────────────────────────────────────────────

  async askPlan(args: {
    steps: string[];
    sessionId?: string | null;
    coreRunId?: string | null;
    workspaceId?: string | null;
    conversationId?: string | null;
  }): Promise<{ planId: string; decision: 'approve' | 'edit'; feedback?: string }> {
    const planId = randomUUID();
    const corr: Corr = {
      runId: args.coreRunId ?? null,
      workspaceId: args.workspaceId ?? null,
      conversationId: args.conversationId ?? null,
    };
    await this.persistPlan(planId, args.sessionId ?? null, args.coreRunId ?? null, args.steps);
    return new Promise((resolve) => {
      this.pendingPlans.set(planId, {
        corr,
        sessionId: args.sessionId ?? null,
        coreRunId: args.coreRunId ?? null,
        resolve: ({ decision, feedback }) => resolve({ planId, decision, feedback }),
      });
      this.events.emitRun('task.plan', { planId, steps: args.steps, sessionId: args.sessionId ?? null }, corr);
    });
  }

  /** §3.C task.plan_response. Returns true if a pending plan matched. */
  resolvePlan(planId: string, decision: 'approve' | 'edit', feedback?: string): boolean {
    const p = this.pendingPlans.get(planId);
    if (!p) return false;
    this.pendingPlans.delete(planId);
    void this.setPlanStatus(planId, decision === 'approve' ? 'approved' : 'edited', feedback);
    p.resolve({ decision, feedback });
    return true;
  }

  // ── Clarifications ──────────────────────────────────────────────────────────

  async askClarification(args: {
    questions: string[];
    sessionId?: string | null;
    coreRunId?: string | null;
    workspaceId?: string | null;
    conversationId?: string | null;
  }): Promise<{ clarificationId: string; answers: Record<string, string> }> {
    const clarificationId = randomUUID();
    const corr: Corr = {
      runId: args.coreRunId ?? null,
      workspaceId: args.workspaceId ?? null,
      conversationId: args.conversationId ?? null,
    };
    await this.persistClarification(clarificationId, args.sessionId ?? null, args.coreRunId ?? null, args.questions);
    return new Promise((resolve) => {
      this.pendingClar.set(clarificationId, {
        corr,
        sessionId: args.sessionId ?? null,
        coreRunId: args.coreRunId ?? null,
        resolve: (answers) => resolve({ clarificationId, answers }),
      });
      this.events.emitRun(
        'task.clarification',
        { clarificationId, questions: args.questions, sessionId: args.sessionId ?? null },
        corr,
      );
    });
  }

  /** §3.C task.clarification_response. */
  resolveClarification(clarificationId: string, answers: Record<string, string>): boolean {
    const p = this.pendingClar.get(clarificationId);
    if (!p) return false;
    this.pendingClar.delete(clarificationId);
    void this.setClarificationAnswers(clarificationId, answers);
    p.resolve(answers);
    return true;
  }

  get pendingPlanCount(): number {
    return this.pendingPlans.size;
  }
  get pendingClarificationCount(): number {
    return this.pendingClar.size;
  }

  // ── Persistence (best-effort) ────────────────────────────────────────────────

  private async persistPlan(planId: string, sessionId: string | null, coreRunId: string | null, steps: string[]): Promise<void> {
    const db = this.database.db;
    if (!db || !this.database.isUp) return;
    try {
      await db.insert(plans).values({ id: planId, sessionId, coreRunId, status: 'pending' });
      if (steps.length > 0) {
        await db.insert(planSteps).values(steps.map((content, i) => ({ planId, ordinal: i, content })));
      }
    } catch (err) {
      this.log.debug(`persistPlan ${planId} échoué: ${(err as Error).message}`);
    }
  }

  private async setPlanStatus(planId: string, status: string, feedback?: string): Promise<void> {
    const db = this.database.db;
    if (!db || !this.database.isUp) return;
    try {
      await db
        .update(plans)
        .set({ status, feedback: feedback ?? null, resolvedAt: new Date() })
        .where(eq(plans.id, planId));
    } catch (err) {
      this.log.debug(`setPlanStatus ${planId} échoué: ${(err as Error).message}`);
    }
  }

  private async persistClarification(id: string, sessionId: string | null, coreRunId: string | null, questions: string[]): Promise<void> {
    const db = this.database.db;
    if (!db || !this.database.isUp) return;
    try {
      await db.insert(clarifications).values({ id, sessionId, coreRunId, questions, status: 'pending' });
    } catch (err) {
      this.log.debug(`persistClarification ${id} échoué: ${(err as Error).message}`);
    }
  }

  private async setClarificationAnswers(id: string, answers: Record<string, string>): Promise<void> {
    const db = this.database.db;
    if (!db || !this.database.isUp) return;
    try {
      await db
        .update(clarifications)
        .set({ answers, status: 'answered', resolvedAt: new Date() })
        .where(eq(clarifications.id, id));
    } catch (err) {
      this.log.debug(`setClarificationAnswers ${id} échoué: ${(err as Error).message}`);
    }
  }
}
