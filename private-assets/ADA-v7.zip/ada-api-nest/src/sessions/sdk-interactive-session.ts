import { Injectable, Logger } from '@nestjs/common';
import {
  query,
  type Query,
  type Options as SdkOptions,
  type SDKMessage,
  type SDKUserMessage,
  type HookInput,
  type HookJSONOutput,
  type PermissionMode as SdkPermissionMode,
} from '@anthropic-ai/claude-agent-sdk';
import { AppConfigService } from '../config/app-config.service.js';
import { PermissionPolicyService } from './permission-policy.service.js';
import type { PermissionRequestContext } from './permission.types.js';
import type {
  InteractiveSession,
  InteractiveSessionFactory,
  SessionStartOptions,
} from './session.types.js';

/**
 * Real interactive Claude Code session backed by the **Claude Agent SDK**
 * (`@anthropic-ai/claude-agent-sdk`, P3.5). This is the mechanism VALIDATED
 * live (see docs/SESSIONS-permission-broker.md): the SDK `query()` with a
 * **`PreToolUse` hook** intercepts every guarded tool BEFORE execution and lets
 * us allow/deny it via {@link PermissionPolicyService}. The abandoned
 * `--permission-prompt-tool` MCP binding and `canUseTool` callback are gone.
 *
 * Streaming input: `query({ prompt })` receives an async generator of
 * `SDKUserMessage`. We keep that generator open for the whole session so each
 * `task.message` follow-up is pushed as a new user turn (multi-turn). The
 * generator only ends on `cancel()`.
 *
 * SDK message mapping -> existing SessionEvents:
 *   - system/init                 -> `session_id`
 *   - assistant text block        -> `output`
 *   - assistant tool_use block    -> `tool`
 *   - result                      -> `turn_complete` {tokens, cost}
 *   - SDK error / abort           -> `error` then `closed`
 *
 * `interrupt()` calls `q.interrupt()` (ESC equivalent). `cancel()` aborts the
 * AbortController and ends the input generator (the SDK tears the child down).
 *
 * NOT exercised against a live `claude` in tests: the SDK `query` is injected
 * via {@link SDK_QUERY} so a fake driver can emit a canned message sequence and
 * trigger the hook. Enable the real one with ADA_EXECUTOR=sdk (or `cli`).
 *
 * ── ADR (auth OAuth abonnement, P3.5) ──────────────────────────────────────
 * Parité avec le terminal `ada launch`, qui fait `spawn('claude')` en
 * SUPPRIMANT `ANTHROPIC_API_KEY` et en fixant `CLAUDE_CONFIG_DIR=profileDir`
 * pour forcer l'auth OAuth Claude.ai (abonnement) plutôt qu'une clé API.
 *
 * Le SDK `query()` accepte `options.env` (cf. sdk.d.ts) : quand fourni, cette
 * valeur REMPLACE INTÉGRALEMENT l'environnement du sous-process (elle n'est PAS
 * fusionnée avec `process.env`). On reconstruit donc l'env manuellement :
 *   1. on part de `{ ...process.env }` (préserve PATH, HOME, etc.),
 *   2. on `delete env.ANTHROPIC_API_KEY` (force OAuth, pas de clé API),
 *   3. on fixe `env.CLAUDE_CONFIG_DIR = profileDir` (sélection du profil OAuth).
 * C'est l'équivalent SDK exact du `spawn('claude')` de `ada launch`. On NE
 * FABRIQUE PAS de clé API. Conséquence : si le profil n'a jamais été connecté
 * via OAuth (`claude`/`ada launch`), le sous-process échouera à l'auth — c'est
 * le comportement attendu (parité terminal), surfacé en `session.error`.
 */

/** Injectable seam over the SDK `query()` so tests can supply a fake driver. */
export type SdkQueryFn = typeof query;

@Injectable()
export class SdkInteractiveSessionFactory implements InteractiveSessionFactory {
  readonly kind = 'sdk' as const;

  constructor(
    private readonly config: AppConfigService,
    private readonly policy: PermissionPolicyService,
    /** Overridable in tests; defaults to the real SDK `query`. */
    private readonly queryFn: SdkQueryFn = query,
  ) {}

  start(opts: SessionStartOptions): InteractiveSession {
    return new SdkInteractiveSession(opts, this.config, this.policy, this.queryFn);
  }
}

/** A user turn queued for the streaming-input generator. */
interface QueuedTurn {
  resolve: (m: IteratorResult<SDKUserMessage, void>) => void;
}

class SdkInteractiveSession implements InteractiveSession {
  readonly sessionId: string;
  private _claudeSessionId: string | null = null;
  private _closed = false;
  private readonly log = new Logger('SdkInteractiveSession');
  private readonly abort = new AbortController();
  private q: Query | null = null;

  // Streaming-input queue: pending user messages and a parked next() waiter.
  private readonly queue: SDKUserMessage[] = [];
  private waiter: QueuedTurn | null = null;
  private inputEnded = false;

  constructor(
    private readonly opts: SessionStartOptions,
    private readonly config: AppConfigService,
    private readonly policy: PermissionPolicyService,
    private readonly queryFn: SdkQueryFn,
  ) {
    this.sessionId = opts.sessionId;
    // Un claudeSessionId valide est un UUID nu (format émis par `claude` dans
    // system/init). Les ids legacy/mock (`claude-<uuid>`) sont rejetés par
    // `claude -p --resume` → on les ignore et on démarre une session fraîche.
    if (opts.resumeClaudeSessionId && !isUuid(opts.resumeClaudeSessionId)) {
      this.log.warn(`resume ignoré: "${opts.resumeClaudeSessionId}" n'est pas un UUID — nouvelle session`);
    }
    this._claudeSessionId = isUuid(opts.resumeClaudeSessionId) ? opts.resumeClaudeSessionId : null;
    this.startQuery();
  }

  get claudeSessionId(): string | null {
    return this._claudeSessionId;
  }
  get closed(): boolean {
    return this._closed;
  }

  // ── Streaming input generator ────────────────────────────────────────────

  /** Async generator the SDK pulls user messages from (kept open per session). */
  private async *userMessages(): AsyncGenerator<SDKUserMessage, void> {
    while (!this.inputEnded) {
      const next = this.queue.shift();
      if (next) {
        yield next;
        continue;
      }
      const result = await new Promise<IteratorResult<SDKUserMessage, void>>((resolve) => {
        this.waiter = { resolve };
      });
      if (result.done) return;
      yield result.value;
    }
  }

  private enqueueUser(content: string): void {
    const msg: SDKUserMessage = {
      type: 'user',
      message: { role: 'user', content: [{ type: 'text', text: content }] },
      parent_tool_use_id: null,
      session_id: this._claudeSessionId ?? undefined,
    };
    if (this.waiter) {
      const w = this.waiter;
      this.waiter = null;
      w.resolve({ done: false, value: msg });
    } else {
      this.queue.push(msg);
    }
  }

  private endInput(): void {
    this.inputEnded = true;
    if (this.waiter) {
      const w = this.waiter;
      this.waiter = null;
      w.resolve({ done: true, value: undefined });
    }
  }

  // ── PreToolUse hook: the only validated interception point (P3.5) ──────────

  /**
   * Bound to `options.hooks.PreToolUse`. Maps the SDK hook input to a
   * PermissionRequestContext and delegates to the policy engine (Fork #2):
   * read-only -> allow instantly, mutating -> ask (UI round-trip) / timeout
   * deny, allow_always persists. Returns the SDK `permissionDecision`.
   */
  private readonly preToolUse = async (input: HookInput): Promise<HookJSONOutput> => {
    if (input.hook_event_name !== 'PreToolUse') return {};
    const tool = input.tool_name;
    const toolInput =
      input.tool_input && typeof input.tool_input === 'object'
        ? (input.tool_input as Record<string, unknown>)
        : {};

    const ctx: PermissionRequestContext = {
      requestId: PermissionPolicyService.newRequestId(),
      sessionId: this.sessionId,
      coreRunId: this.opts.permissionCtx.coreRunId,
      profile: this.opts.permissionCtx.profile,
      workspaceId: this.opts.permissionCtx.workspaceId,
      conversationId: this.opts.permissionCtx.conversationId,
      permissionMode: this.opts.permissionMode,
      tool,
      input: toolInput,
    };

    const result = await this.policy.evaluate(ctx);
    if (result.behavior === 'allow') {
      return {
        hookSpecificOutput: {
          hookEventName: 'PreToolUse',
          permissionDecision: 'allow',
          permissionDecisionReason: 'autorisé par la politique ADA',
          ...(result.updatedInput ? { updatedInput: result.updatedInput } : {}),
        },
      };
    }
    return {
      hookSpecificOutput: {
        hookEventName: 'PreToolUse',
        permissionDecision: 'deny',
        permissionDecisionReason: result.message ?? `outil ${tool} refusé`,
      },
    };
  };

  // ── Query lifecycle ────────────────────────────────────────────────────────

  /**
   * OAuth subscription env for the SDK sub-process (see ADR header). Starts from
   * `process.env`, drops `ANTHROPIC_API_KEY` (force OAuth, never an API key), and
   * pins `CLAUDE_CONFIG_DIR` to the profile dir. `options.env` REPLACES the
   * sub-process env entirely, so the spread is mandatory to keep PATH/HOME.
   */
  private buildSdkEnv(): Record<string, string | undefined> {
    const env: Record<string, string | undefined> = { ...process.env };
    delete env.ANTHROPIC_API_KEY;
    env.CLAUDE_CONFIG_DIR = this.opts.profileDir;
    return env;
  }

  private startQuery(): void {
    const sdkMode = this.opts.permissionMode as SdkPermissionMode;
    const sdkOptions: SdkOptions = {
      cwd: this.opts.cwd ?? this.opts.profileDir,
      // VALIDATED: 'default' lets the PreToolUse hook drive the decision.
      permissionMode: sdkMode,
      settingSources: this.config.settingSources,
      abortController: this.abort,
      // OAuth abonnement (parité `ada launch`) — voir ADR en tête de fichier.
      env: this.buildSdkEnv(),
      hooks: { PreToolUse: [{ hooks: [this.preToolUse] }] },
      ...(this.config.sessionMaxTurns ? { maxTurns: this.config.sessionMaxTurns } : {}),
      // _claudeSessionId est déjà validé UUID dans le constructeur (sinon null).
      ...(this._claudeSessionId ? { resume: this._claudeSessionId } : {}),
      stderr: (d: string) => this.log.debug(`stderr[${this.sessionId}]: ${d.slice(0, 200)}`),
    };

    try {
      this.q = this.queryFn({ prompt: this.userMessages(), options: sdkOptions });
    } catch (err) {
      this.fail(`SDK query() échoué: ${(err as Error).message}`);
      return;
    }
    void this.consume(this.q);
  }

  private async consume(q: Query): Promise<void> {
    try {
      for await (const msg of q) {
        if (this._closed) break;
        this.onSdkMessage(msg);
      }
    } catch (err) {
      if (!this._closed) this.opts.onEvent({ kind: 'error', sessionId: this.sessionId, error: `SDK: ${(err as Error).message}` });
    } finally {
      if (!this._closed) {
        this._closed = true;
        this.opts.onEvent({ kind: 'closed', sessionId: this.sessionId, code: 0 });
      }
    }
  }

  private onSdkMessage(msg: SDKMessage): void {
    switch (msg.type) {
      case 'system': {
        if (msg.subtype === 'init' && msg.session_id && msg.session_id !== this._claudeSessionId) {
          this._claudeSessionId = msg.session_id;
          this.opts.onEvent({ kind: 'session_id', sessionId: this.sessionId, claudeSessionId: msg.session_id });
        }
        return;
      }
      case 'assistant': {
        const content = msg.message.content;
        if (Array.isArray(content)) {
          for (const block of content) {
            const b = block as { type?: string; text?: string; name?: string; input?: unknown };
            if (b.type === 'text' && typeof b.text === 'string') {
              this.opts.onEvent({ kind: 'output', chunk: b.text, sessionId: this.sessionId });
            } else if (b.type === 'tool_use' && typeof b.name === 'string') {
              this.opts.onEvent({ kind: 'tool', tool: b.name, input: (b.input as Record<string, unknown>) ?? {}, sessionId: this.sessionId });
            }
          }
        }
        return;
      }
      case 'result': {
        const usage = msg.usage;
        const tokens = num(usage?.input_tokens) + num(usage?.output_tokens);
        const cost = num(msg.total_cost_usd);
        const summary = msg.subtype === 'success' && typeof msg.result === 'string' ? msg.result : '';
        if (msg.is_error) {
          const reason =
            msg.subtype !== 'success' && Array.isArray(msg.errors) && msg.errors.length
              ? msg.errors.join('; ')
              : `result error (${msg.subtype})`;
          this.opts.onEvent({ kind: 'error', sessionId: this.sessionId, error: reason });
        }
        this.opts.onEvent({ kind: 'turn_complete', sessionId: this.sessionId, summary, tokens, cost });
        return;
      }
      default:
        return;
    }
  }

  private fail(error: string): void {
    this._closed = true;
    this.opts.onEvent({ kind: 'error', sessionId: this.sessionId, error });
    this.opts.onEvent({ kind: 'closed', sessionId: this.sessionId, code: null });
  }

  // ── InteractiveSession API ─────────────────────────────────────────────────

  async send(content: string): Promise<void> {
    if (this._closed) throw new Error('session fermée');
    this.enqueueUser(content);
    await Promise.resolve();
  }

  interrupt(): void {
    if (this._closed || !this.q) return;
    void this.q.interrupt?.().catch((err: unknown) => this.log.debug(`interrupt: ${(err as Error).message}`));
  }

  async cancel(): Promise<void> {
    if (this._closed) return;
    this._closed = true;
    this.endInput();
    try {
      this.abort.abort();
    } catch {
      /* ignore */
    }
    this.opts.onEvent({ kind: 'closed', sessionId: this.sessionId, code: 0 });
  }
}

function num(v: unknown): number {
  return typeof v === 'number' && Number.isFinite(v) ? v : 0;
}

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
/** True si `v` est un UUID nu — le seul format accepté par `claude -p --resume`. */
function isUuid(v: string | null | undefined): v is string {
  return typeof v === 'string' && UUID_RE.test(v);
}
