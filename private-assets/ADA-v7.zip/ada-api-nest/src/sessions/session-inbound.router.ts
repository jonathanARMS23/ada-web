import { Injectable, Logger } from '@nestjs/common';
import { SessionManager } from './session-manager.service.js';
import { PermissionPolicyService } from './permission-policy.service.js';
import { PlanClarificationService } from './plan-clarification.service.js';
import { isPermissionMode } from './session.types.js';
import type { PermissionDecision } from './permission.types.js';

export interface InboundMessage {
  type: string;
  [k: string]: unknown;
}

/**
 * Routes inbound WS messages (ADR-016 §3.C) to the right P3 service. Injected
 * OPTIONALLY into the StreamGateway (which owns the sockets) so the
 * orchestration module stays free of a hard dependency on the sessions module.
 *
 * Handled inbound types:
 *   task.message                 -> SessionManager.sendMessage
 *   task.interrupt               -> SessionManager.interrupt
 *   task.cancel                  -> SessionManager.cancel
 *   task.permission_response     -> PermissionPolicyService.resolvePermission
 *   task.plan_response           -> PlanClarificationService.resolvePlan
 *   task.clarification_response  -> PlanClarificationService.resolveClarification
 *   task.set_mode                -> (extension) records the session mode
 */
@Injectable()
export class SessionInboundRouter {
  private readonly log = new Logger(SessionInboundRouter.name);

  constructor(
    private readonly sessions: SessionManager,
    private readonly policy: PermissionPolicyService,
    private readonly planClar: PlanClarificationService,
  ) {}

  async handle(msg: InboundMessage): Promise<void> {
    switch (msg.type) {
      case 'task.message': {
        const sessionId = str(msg.sessionId);
        const content = str(msg.content);
        if (sessionId && content) await this.sessions.sendMessage(sessionId, content);
        break;
      }
      case 'task.interrupt': {
        const sessionId = str(msg.sessionId);
        if (sessionId) this.sessions.interrupt(sessionId);
        break;
      }
      case 'task.cancel': {
        const sessionId = str(msg.sessionId) ?? str(msg.runId);
        if (sessionId) await this.sessions.cancel(sessionId);
        break;
      }
      case 'task.permission_response': {
        const requestId = str(msg.requestId);
        const decision = msg.decision;
        if (requestId && isPermissionDecision(decision)) {
          const updatedInput =
            decision !== 'deny' && isRecord(msg.updatedInput) ? msg.updatedInput : undefined;
          const ok = this.policy.resolvePermission(requestId, decision, updatedInput);
          if (!ok) this.log.debug(`permission_response sans requête en attente: ${requestId}`);
        }
        break;
      }
      case 'task.plan_response': {
        const planId = str(msg.planId);
        const decision = msg.decision === 'edit' ? 'edit' : msg.decision === 'approve' ? 'approve' : null;
        if (planId && decision) this.planClar.resolvePlan(planId, decision, str(msg.feedback) ?? undefined);
        break;
      }
      case 'task.clarification_response': {
        const clarificationId = str(msg.clarificationId);
        const answers = isRecord(msg.answers) ? coerceAnswers(msg.answers) : null;
        if (clarificationId && answers) this.planClar.resolveClarification(clarificationId, answers);
        break;
      }
      case 'task.set_mode': {
        // Validated for completeness; mode changes mid-session apply to the next
        // spawn/resume (claude --permission-mode is set at process start).
        const mode = msg.mode;
        if (!isPermissionMode(mode)) this.log.debug(`set_mode invalide: ${String(mode)}`);
        break;
      }
      default:
        this.log.debug(`Message entrant ignoré: ${msg.type}`);
        break;
    }
  }
}

function str(v: unknown): string | null {
  return typeof v === 'string' && v.length > 0 ? v : null;
}
function isRecord(v: unknown): v is Record<string, unknown> {
  return typeof v === 'object' && v !== null && !Array.isArray(v);
}
function isPermissionDecision(v: unknown): v is PermissionDecision {
  return v === 'allow' || v === 'deny' || v === 'allow_always';
}
function coerceAnswers(v: Record<string, unknown>): Record<string, string> {
  const out: Record<string, string> = {};
  for (const [k, val] of Object.entries(v)) out[k] = typeof val === 'string' ? val : String(val);
  return out;
}
