import { Inject, Injectable, Logger } from '@nestjs/common';
import { randomUUID } from 'node:crypto';
import { eq, desc, and, isNotNull } from 'drizzle-orm';
import { DatabaseService } from '../persistence/database.service.js';
import { sessions, messages, toolCalls, workspaces } from '../persistence/schema.js';
import { OrchestrationEvents } from '../orchestration/orchestration-events.js';
import { AppConfigService } from '../config/app-config.service.js';
import { softValidateWorkspace } from '../workspaces/workspace-link.js';
import {
  INTERACTIVE_SESSION_FACTORY,
  InteractiveSession,
  InteractiveSessionFactory,
  PermissionMode,
  SessionEvent,
} from './session.types.js';

interface SessionRecord {
  id: string;
  claudeSessionId: string | null;
  profile: string;
  workspaceId: string | null;
  conversationId: string | null;
  coreRunId: string | null;
  permissionMode: PermissionMode;
  cwd: string | null;
  turn: number;
  live: InteractiveSession | null;
  totalTokens: number;
  totalCost: number;
}

export interface CreateSessionParams {
  profile?: string;
  workspaceId?: string | null;
  conversationId?: string | null;
  coreRunId?: string | null;
  permissionMode?: PermissionMode;
  cwd?: string | null;
  /** Resume an existing session by our internal sessionId. */
  resumeSessionId?: string | null;
  /** Initial user message to send right after start (optional). */
  initialMessage?: string | null;
}

/**
 * SessionManager (ADR-016 §6/§6bis A, ROADMAP P3). Owns the lifecycle of
 * interactive Claude Code sessions:
 *  - create/resume: persists a row in `sessions`, starts the InteractiveSession
 *    factory (mock|cli), and on `session_id` capture stores the claude
 *    session_id for `--resume`.
 *  - relays session stream events onto the OrchestrationEvents bus as
 *    `session.*` / `run.phase.*`-shaped events so the StreamGateway streams them
 *    and the persistence projector records messages/tool_calls.
 *  - send/interrupt/cancel map the §3.C inbound messages to the live process.
 *
 * In-memory session map is the source of truth for live processes; the DB row
 * mirrors it for history/resume and degrades gracefully when the DB is down.
 */
@Injectable()
export class SessionManager {
  private readonly log = new Logger(SessionManager.name);
  private readonly map = new Map<string, SessionRecord>();

  constructor(
    private readonly database: DatabaseService,
    private readonly events: OrchestrationEvents,
    private readonly config: AppConfigService,
    @Inject(INTERACTIVE_SESSION_FACTORY) private readonly factory: InteractiveSessionFactory,
  ) {}

  /** Creates a new session (or resumes an existing one by internal sessionId). */
  async create(params: CreateSessionParams): Promise<{ sessionId: string; resumed: boolean }> {
    if (params.resumeSessionId) {
      const resumed = await this.resume(params.resumeSessionId, params.initialMessage ?? null);
      if (resumed) return { sessionId: params.resumeSessionId, resumed: true };
      this.log.warn(`Session ${params.resumeSessionId} introuvable — création d’une nouvelle`);
    }

    // P5: mémoire conversationnelle continue (parité `ada launch`). Sans
    // resumeSessionId explicite, si une session existe déjà pour cette
    // conversation, on la REPREND (même claudeSessionId) au lieu d'en créer une
    // nouvelle — rouvrir une discussion = continuer la même session Claude.
    if (!params.resumeSessionId && params.conversationId) {
      const existing = await this.latestSessionIdForConversation(params.conversationId);
      if (existing) {
        const resumed = await this.resume(existing, params.initialMessage ?? null);
        if (resumed) return { sessionId: existing, resumed: true };
        this.log.warn(`Reprise conversation ${params.conversationId} (session ${existing}) échouée — nouvelle session`);
      }
    }

    // P5 §5: soft-validate the workspace link (never blocks session creation).
    await softValidateWorkspace(this.database, params.workspaceId);

    const sessionId = randomUUID();
    const profile = params.profile ?? this.config.profile;
    const permissionMode: PermissionMode = params.permissionMode ?? 'default';
    // cwd = répertoire projet du workspace (parité `ada launch <dir>`). Lookup
    // côté backend (jamais le frontend) ; fallback cwd explicite puis profileDir.
    const cwd = await this.resolveCwd(params.workspaceId ?? null, params.cwd ?? null);
    const rec: SessionRecord = {
      id: sessionId,
      claudeSessionId: null,
      profile,
      workspaceId: params.workspaceId ?? null,
      conversationId: params.conversationId ?? null,
      coreRunId: params.coreRunId ?? null,
      permissionMode,
      cwd,
      turn: 0,
      live: null,
      totalTokens: 0,
      totalCost: 0,
    };
    this.map.set(sessionId, rec);
    await this.persistNew(rec);

    rec.live = this.factory.start({
      sessionId,
      profileDir: this.config.profileDir,
      cwd: rec.cwd ?? undefined,
      permissionMode,
      resumeClaudeSessionId: null,
      permissionCtx: {
        profile: rec.profile,
        workspaceId: rec.workspaceId,
        conversationId: rec.conversationId,
        coreRunId: rec.coreRunId,
      },
      onEvent: (e) => this.onSessionEvent(e),
    });

    this.events.emitRun(
      'session.started',
      { sessionId, profile, permissionMode },
      { runId: rec.coreRunId, workspaceId: rec.workspaceId, conversationId: rec.conversationId },
    );

    if (params.initialMessage) {
      await this.sendMessage(sessionId, params.initialMessage);
    }
    return { sessionId, resumed: false };
  }

  /** Resumes a known session: re-spawn with --resume <claudeSessionId>. */
  private async resume(sessionId: string, initialMessage: string | null): Promise<boolean> {
    let rec = this.map.get(sessionId);
    if (!rec) {
      const loaded = await this.load(sessionId);
      if (!loaded) return false;
      rec = loaded;
      this.map.set(sessionId, rec);
    }
    if (rec.live && !rec.live.closed) {
      // Already live — just optionally send.
      if (initialMessage) await this.sendMessage(sessionId, initialMessage);
      return true;
    }
    rec.live = this.factory.start({
      sessionId,
      profileDir: this.config.profileDir,
      cwd: rec.cwd ?? undefined,
      permissionMode: rec.permissionMode,
      resumeClaudeSessionId: rec.claudeSessionId,
      permissionCtx: {
        profile: rec.profile,
        workspaceId: rec.workspaceId,
        conversationId: rec.conversationId,
        coreRunId: rec.coreRunId,
      },
      onEvent: (e) => this.onSessionEvent(e),
    });
    this.events.emitRun(
      'session.resumed',
      { sessionId, claudeSessionId: rec.claudeSessionId },
      { runId: rec.coreRunId, workspaceId: rec.workspaceId, conversationId: rec.conversationId },
    );
    if (initialMessage) await this.sendMessage(sessionId, initialMessage);
    return true;
  }

  /** §3.C task.message — write a user turn to the live process. */
  async sendMessage(sessionId: string, content: string): Promise<void> {
    const rec = this.require(sessionId);
    if (!rec.live || rec.live.closed) throw new Error('session non active');
    rec.turn++;
    await this.persistMessage(rec, 'user', content);
    this.events.emitRun(
      'session.message',
      { sessionId, role: 'user', content, turn: rec.turn },
      { runId: rec.coreRunId, workspaceId: rec.workspaceId, conversationId: rec.conversationId },
    );
    await rec.live.send(content);
  }

  /** §3.C task.interrupt. */
  interrupt(sessionId: string): void {
    const rec = this.map.get(sessionId);
    rec?.live?.interrupt();
  }

  /** §3.C task.cancel. */
  async cancel(sessionId: string): Promise<void> {
    const rec = this.map.get(sessionId);
    if (!rec) return;
    await rec.live?.cancel();
    await this.setStatus(sessionId, 'cancelled');
    this.events.emitRun(
      'session.cancelled',
      { sessionId },
      { runId: rec.coreRunId, workspaceId: rec.workspaceId, conversationId: rec.conversationId },
    );
  }

  getMode(sessionId: string): PermissionMode | null {
    return this.map.get(sessionId)?.permissionMode ?? null;
  }

  /** Returns the workspace correlation for a session (used by gateways). */
  corrOf(sessionId: string): { coreRunId: string | null; workspaceId: string | null; conversationId: string | null } | null {
    const rec = this.map.get(sessionId);
    if (!rec) return null;
    return { coreRunId: rec.coreRunId, workspaceId: rec.workspaceId, conversationId: rec.conversationId };
  }

  has(sessionId: string): boolean {
    return this.map.has(sessionId);
  }

  // ── Session event relay ──────────────────────────────────────────────────────

  private onSessionEvent(e: SessionEvent): void {
    const rec = this.map.get(e.sessionId);
    if (!rec) return;
    const corr = { runId: rec.coreRunId, workspaceId: rec.workspaceId, conversationId: rec.conversationId };

    switch (e.kind) {
      case 'session_id': {
        rec.claudeSessionId = e.claudeSessionId;
        void this.persistClaudeSessionId(rec.id, e.claudeSessionId);
        break;
      }
      case 'output': {
        this.events.emitRun('session.output', { sessionId: e.sessionId, chunk: e.chunk, turn: rec.turn }, corr);
        void this.persistMessage(rec, 'assistant', e.chunk);
        break;
      }
      case 'tool': {
        this.events.emitRun('session.tool', { sessionId: e.sessionId, tool: e.tool, input: e.input }, corr);
        void this.persistTool(rec, e.tool, e.input);
        break;
      }
      case 'turn_complete': {
        rec.totalTokens += e.tokens;
        rec.totalCost += e.cost;
        void this.bumpUsage(rec);
        this.events.emitRun(
          'session.turn_complete',
          { sessionId: e.sessionId, summary: e.summary, tokens: e.tokens, cost: e.cost, turn: rec.turn },
          corr,
        );
        break;
      }
      case 'error': {
        this.events.emitRun('session.error', { sessionId: e.sessionId, error: e.error }, corr);
        break;
      }
      case 'closed': {
        void this.setStatus(e.sessionId, 'closed');
        this.events.emitRun('session.closed', { sessionId: e.sessionId, code: e.code }, corr);
        break;
      }
      default:
        break;
    }
  }

  // ── Persistence (best-effort, degrades when DB down) ─────────────────────────

  private require(sessionId: string): SessionRecord {
    const rec = this.map.get(sessionId);
    if (!rec) throw new Error(`session inconnue: ${sessionId}`);
    return rec;
  }

  private async persistNew(rec: SessionRecord): Promise<void> {
    const db = this.database.db;
    if (!db || !this.database.isUp) return;
    try {
      await db.insert(sessions).values({
        id: rec.id,
        profile: rec.profile,
        workspaceId: rec.workspaceId,
        conversationId: rec.conversationId,
        coreRunId: rec.coreRunId,
        permissionMode: rec.permissionMode,
        cwd: rec.cwd,
        status: 'active',
      });
    } catch (err) {
      this.log.debug(`persistNew ${rec.id} échoué: ${(err as Error).message}`);
    }
  }

  private async persistClaudeSessionId(sessionId: string, claudeSessionId: string): Promise<void> {
    const db = this.database.db;
    if (!db || !this.database.isUp) return;
    try {
      await db
        .update(sessions)
        .set({ claudeSessionId, updatedAt: new Date() })
        .where(eq(sessions.id, sessionId));
    } catch (err) {
      this.log.debug(`persistClaudeSessionId ${sessionId} échoué: ${(err as Error).message}`);
    }
  }

  private async persistMessage(rec: SessionRecord, role: 'user' | 'assistant', content: string): Promise<void> {
    const db = this.database.db;
    if (!db || !this.database.isUp || !content) return;
    try {
      await db.insert(messages).values({
        sessionId: rec.id,
        coreRunId: rec.coreRunId,
        // P5 bug fix : sans conversationId, GET /conversations/:id/messages
        // (filtre par conversationId) renvoyait TOUJOURS un historique vide.
        conversationId: rec.conversationId,
        turn: rec.turn,
        role,
        content,
      });
    } catch (err) {
      this.log.debug(`persistMessage ${rec.id} échoué: ${(err as Error).message}`);
    }
  }

  private async persistTool(rec: SessionRecord, tool: string, input: unknown): Promise<void> {
    const db = this.database.db;
    if (!db || !this.database.isUp) return;
    try {
      await db.insert(toolCalls).values({
        sessionId: rec.id,
        coreRunId: rec.coreRunId,
        tool,
        input: (input as Record<string, unknown>) ?? {},
      });
    } catch (err) {
      this.log.debug(`persistTool ${rec.id} échoué: ${(err as Error).message}`);
    }
  }

  private async bumpUsage(rec: SessionRecord): Promise<void> {
    const db = this.database.db;
    if (!db || !this.database.isUp) return;
    try {
      await db
        .update(sessions)
        .set({
          totalTokens: rec.totalTokens,
          totalCost: String(rec.totalCost),
          lastMessageAt: new Date(),
          updatedAt: new Date(),
        })
        .where(eq(sessions.id, rec.id));
    } catch (err) {
      this.log.debug(`bumpUsage ${rec.id} échoué: ${(err as Error).message}`);
    }
  }

  private async setStatus(sessionId: string, status: string): Promise<void> {
    const db = this.database.db;
    if (!db || !this.database.isUp) return;
    try {
      await db.update(sessions).set({ status, updatedAt: new Date() }).where(eq(sessions.id, sessionId));
    } catch (err) {
      this.log.debug(`setStatus ${sessionId} échoué: ${(err as Error).message}`);
    }
  }

  /**
   * Resolves the session cwd (parité `ada launch <dir>`): workspace.projectDir
   * if the workspace exists and has one, else the explicit cwd, else null (the
   * SDK session falls back to profileDir). Best-effort: DB down => explicit/null.
   */
  private async resolveCwd(workspaceId: string | null, explicitCwd: string | null): Promise<string | null> {
    if (!workspaceId) return explicitCwd;
    const db = this.database.db;
    if (!db || !this.database.isUp) return explicitCwd;
    try {
      const rows = await db
        .select({ projectDir: workspaces.projectDir })
        .from(workspaces)
        .where(eq(workspaces.id, workspaceId))
        .limit(1);
      return rows[0]?.projectDir ?? explicitCwd;
    } catch (err) {
      this.log.debug(`resolveCwd ${workspaceId} échoué: ${(err as Error).message}`);
      return explicitCwd;
    }
  }

  /**
   * Most recent session id bound to a conversation (active preferred, then any),
   * for conversational resume (mémoire continue). Keyset desc on createdAt.
   * Returns null when none / DB down.
   */
  private async latestSessionIdForConversation(conversationId: string): Promise<string | null> {
    const db = this.database.db;
    if (!db || !this.database.isUp) return null;
    try {
      // On ne reprend QUE les sessions dont le claudeSessionId est un UUID nu
      // (sessions SDK réelles). Les vestiges mock/legacy (`claude-<uuid>`) sont
      // ignorés — sinon `claude -p --resume` plante. Tri actif-d'abord puis récent.
      const rows = await db
        .select({ id: sessions.id, claudeSessionId: sessions.claudeSessionId, status: sessions.status })
        .from(sessions)
        .where(and(eq(sessions.conversationId, conversationId), isNotNull(sessions.claudeSessionId)))
        .orderBy(desc(sessions.createdAt), desc(sessions.id))
        .limit(20);
      const usable = rows.filter((r) => isUuidStr(r.claudeSessionId));
      return (usable.find((r) => r.status === 'active') ?? usable[0])?.id ?? null;
    } catch (err) {
      this.log.debug(`latestSessionIdForConversation ${conversationId} échoué: ${(err as Error).message}`);
      return null;
    }
  }

  /** Loads a persisted session (for resume after a restart). */
  private async load(sessionId: string): Promise<SessionRecord | null> {
    const db = this.database.db;
    if (!db || !this.database.isUp) return null;
    try {
      const rows = await db
        .select()
        .from(sessions)
        .where(eq(sessions.id, sessionId))
        .orderBy(desc(sessions.createdAt))
        .limit(1);
      const row = rows[0];
      if (!row) return null;
      return {
        id: row.id,
        claudeSessionId: row.claudeSessionId,
        profile: row.profile,
        workspaceId: row.workspaceId,
        conversationId: row.conversationId,
        coreRunId: row.coreRunId,
        permissionMode: (row.permissionMode as PermissionMode) ?? 'default',
        cwd: row.cwd,
        turn: 0,
        live: null,
        totalTokens: row.totalTokens,
        totalCost: Number(row.totalCost),
      };
    } catch (err) {
      this.log.debug(`load ${sessionId} échoué: ${(err as Error).message}`);
      return null;
    }
  }
}

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
/** True si `v` est un UUID nu — seul format repris par `claude -p --resume`. */
function isUuidStr(v: string | null | undefined): v is string {
  return typeof v === 'string' && UUID_RE.test(v);
}
