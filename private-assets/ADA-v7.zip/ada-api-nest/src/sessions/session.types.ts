/**
 * P3 interactive session types (ADR-016 §6/§6bis A, §3.C).
 *
 * An interactive session wraps a long-lived `claude -p --input-format
 * stream-json --output-format stream-json` process that stays alive across
 * multiple user turns. The same stream events (output/tool) used by the P2
 * PhaseExecutor are reused; sessions add `session_id` capture and stdin writes.
 */
import type { PhaseStreamEvent } from '../orchestration/phase-executor.js';

export type PermissionMode = 'default' | 'acceptEdits' | 'bypassPermissions' | 'plan';

export const PERMISSION_MODES: readonly PermissionMode[] = [
  'default',
  'acceptEdits',
  'bypassPermissions',
  'plan',
];

export function isPermissionMode(v: unknown): v is PermissionMode {
  return typeof v === 'string' && (PERMISSION_MODES as readonly string[]).includes(v);
}

/** Events an interactive session surfaces to the manager. */
export type SessionEvent =
  | (PhaseStreamEvent & { sessionId: string })
  | { kind: 'session_id'; sessionId: string; claudeSessionId: string }
  | { kind: 'turn_complete'; sessionId: string; summary: string; tokens: number; cost: number }
  | { kind: 'error'; sessionId: string; error: string }
  | { kind: 'closed'; sessionId: string; code: number | null };

/**
 * Correlation + profile context the PreToolUse hook needs to build a
 * PermissionRequestContext for the policy engine (P3.5). Carried on the start
 * options so the hook can evaluate before the session is registered anywhere.
 */
export interface SessionPermissionContext {
  profile: string;
  workspaceId: string | null;
  conversationId: string | null;
  coreRunId: string | null;
}

/** Options to start (or resume) an interactive session process. */
export interface SessionStartOptions {
  /** Our internal session id (uuid); distinct from the claude session_id. */
  sessionId: string;
  profileDir: string;
  /** Working directory for the SDK query (cwd). */
  cwd?: string;
  permissionMode: PermissionMode;
  /** claude session_id to --resume, when reconnecting/continuing. */
  resumeClaudeSessionId?: string | null;
  /**
   * Profile + correlation used by the PreToolUse hook to evaluate permissions
   * against the PermissionPolicyService (P3.5). The mock ignores it.
   */
  permissionCtx: SessionPermissionContext;
  /** Per-event callback (output/tool/session_id/turn_complete/error/closed). */
  onEvent: (e: SessionEvent) => void;
}

/**
 * A live interactive session. Implementations: MockInteractiveSession (tests),
 * SdkInteractiveSession (real Claude Agent SDK + PreToolUse hook, P3.5).
 */
export interface InteractiveSession {
  readonly sessionId: string;
  /** claude session_id once captured (null before the first init frame). */
  readonly claudeSessionId: string | null;
  /** Writes a user message to the process stdin as a stream-json user turn. */
  send(content: string): Promise<void>;
  /** Interrupts the current generation (ESC equivalent). */
  interrupt(): void;
  /** Kills the process cleanly. */
  cancel(): Promise<void>;
  readonly closed: boolean;
}

/** Factory: chooses Mock vs SDK per ADA_EXECUTOR (same switch as PhaseExecutor). */
export interface InteractiveSessionFactory {
  readonly kind: 'mock' | 'sdk';
  start(opts: SessionStartOptions): InteractiveSession;
}

export const INTERACTIVE_SESSION_FACTORY = Symbol('INTERACTIVE_SESSION_FACTORY');
