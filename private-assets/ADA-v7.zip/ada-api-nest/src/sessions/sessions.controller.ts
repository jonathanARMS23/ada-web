import { Body, Controller, Get, HttpCode, Param, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/jwt-auth.guard.js';
import { TaskRateLimitGuard } from '../tasks/task-rate-limit.guard.js';
import { SessionManager } from './session-manager.service.js';
import { PermissionPolicyService } from './permission-policy.service.js';
import { CreateSessionDto } from './dto/create-session.dto.js';

/**
 * Interactive session entry point (ADR-016 §6bis D — the route that replaces
 * `ada launch`). POST /sessions creates/resumes a bidirectional Claude Code
 * session; the live flow (output, tools, permission requests, follow-ups) runs
 * over the /ws WebSocket (§3.C). GET endpoints expose the effective permission
 * policy. JWT on all routes; the spawn-bearing POST is rate-limited.
 */
@ApiTags('sessions')
@ApiBearerAuth()
@Controller('sessions')
@UseGuards(JwtAuthGuard)
export class SessionsController {
  constructor(
    private readonly sessions: SessionManager,
    private readonly policy: PermissionPolicyService,
  ) {}

  @Post()
  @HttpCode(201)
  @UseGuards(TaskRateLimitGuard)
  @ApiOperation({ summary: 'Crée ou reprend une session interactive (Mode B). Flux via WS /ws.' })
  @ApiResponse({ status: 201, description: '{sessionId, resumed} — interagir ensuite via WS.' })
  async create(@Body() dto: CreateSessionDto): Promise<{ sessionId: string; resumed: boolean }> {
    return this.sessions.create({
      profile: dto.profile,
      workspaceId: dto.workspaceId ?? null,
      conversationId: dto.conversationId ?? null,
      coreRunId: dto.coreRunId ?? null,
      permissionMode: dto.permissionMode,
      cwd: dto.cwd ?? null,
      resumeSessionId: dto.resumeSessionId ?? null,
      initialMessage: dto.message ?? null,
    });
  }

  @Get('policy/:profile')
  @ApiOperation({ summary: 'Politique de permissions effective d’un profil (défauts + overrides).' })
  async getPolicy(@Param('profile') profile: string) {
    return { profile, policy: await this.policy.listPolicy(profile) };
  }
}
