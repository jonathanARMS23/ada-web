import { Global, Module } from '@nestjs/common';
import { AppConfigService } from '../config/app-config.service.js';
import { SessionManager } from './session-manager.service.js';
import { PermissionPolicyService } from './permission-policy.service.js';
import { PermissionBrokerService } from './permission-broker.service.js';
import { PlanClarificationService } from './plan-clarification.service.js';
import { SessionInboundRouter } from './session-inbound.router.js';
import { SessionsController } from './sessions.controller.js';
import { McpBrokerController } from './mcp-broker.controller.js';
import { MockInteractiveSessionFactory } from './mock-interactive-session.js';
import { SdkInteractiveSessionFactory } from './sdk-interactive-session.js';
import { PermissionPolicyService as PermissionPolicy } from './permission-policy.service.js';
import { INTERACTIVE_SESSION_FACTORY } from './session.types.js';

/**
 * P3 interactive sessions + Permission Broker module (ADR-016 §6/§6bis).
 *
 * Global so the SessionInboundRouter is resolvable by the StreamGateway (in the
 * orchestration module) as an optional dependency without a circular import —
 * the gateway owns the WS sockets; this module owns the session/broker logic.
 *
 * The InteractiveSession factory is selected at composition time by ADA_EXECUTOR
 * (mock default, sdk for the real Claude Agent SDK — P3.5), exactly like the P2
 * PhaseExecutor. The legacy MCP broker controller is kept @deprecated only.
 */
@Global()
@Module({
  controllers: [SessionsController, McpBrokerController],
  providers: [
    SessionManager,
    PermissionPolicyService,
    PermissionBrokerService,
    PlanClarificationService,
    SessionInboundRouter,
    MockInteractiveSessionFactory,
    {
      provide: SdkInteractiveSessionFactory,
      useFactory: (config: AppConfigService, policy: PermissionPolicy) =>
        new SdkInteractiveSessionFactory(config, policy),
      inject: [AppConfigService, PermissionPolicy],
    },
    {
      provide: INTERACTIVE_SESSION_FACTORY,
      useFactory: (
        config: AppConfigService,
        mock: MockInteractiveSessionFactory,
        sdk: SdkInteractiveSessionFactory,
      ) => (config.useSdkSession ? sdk : mock),
      inject: [AppConfigService, MockInteractiveSessionFactory, SdkInteractiveSessionFactory],
    },
  ],
  exports: [
    SessionManager,
    PermissionPolicyService,
    PermissionBrokerService,
    PlanClarificationService,
    SessionInboundRouter,
  ],
})
export class SessionsModule {}
