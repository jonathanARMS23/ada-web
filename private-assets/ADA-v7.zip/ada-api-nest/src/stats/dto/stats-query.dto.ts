import { Type } from 'class-transformer';
import { IsInt, IsOptional, IsUUID, Max, Min } from 'class-validator';

/** Scoping workspace optionnel, partagé par overview/activity/timeline (P5/P6). */
export class WorkspaceScopeDto {
  @IsOptional()
  @IsUUID()
  workspaceId?: string;
}

export class ActivityQueryDto extends WorkspaceScopeDto {
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(365)
  days?: number = 90;
}

export class TimelineQueryDto extends WorkspaceScopeDto {
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(200)
  limit?: number = 20;
}
