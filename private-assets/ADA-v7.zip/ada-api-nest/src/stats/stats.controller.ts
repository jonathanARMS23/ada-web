import { Controller, Get, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/jwt-auth.guard.js';
import { StatsService } from './stats.service.js';
import { ActivityQueryDto, TimelineQueryDto, WorkspaceScopeDto } from './dto/stats-query.dto.js';

/**
 * Surface dashboard agrégée (P6, ADR-017 feature #1/#2). JWT sur toutes les
 * routes. 100% lecture : agrégats Postgres + relais RPC live, dégradation
 * gracieuse (jamais de crash si DB/Control Server indisponible).
 */
@ApiTags('stats')
@ApiBearerAuth()
@Controller('stats')
@UseGuards(JwtAuthGuard)
export class StatsController {
  constructor(private readonly service: StatsService) {}

  @Get('overview')
  @ApiOperation({ summary: 'KPIs dashboard agrégés (runs + phases + cost_ledger + router)' })
  overview(@Query() q: WorkspaceScopeDto) {
    return this.service.overview(q.workspaceId);
  }

  @Get('activity')
  @ApiOperation({ summary: 'Heatmap activité : runs + coût groupés par jour (cost_ledger)' })
  activity(@Query() q: ActivityQueryDto) {
    return this.service.activity(q.days ?? 90, q.workspaceId);
  }

  @Get('budget')
  @ApiOperation({ summary: 'Statut + config budget (relais budget.check live)' })
  budget() {
    return this.service.budget();
  }

  @Get('runs/timeline')
  @ApiOperation({ summary: 'Timeline structurée des runs récents (status/durée/coût/phases)' })
  timeline(@Query() q: TimelineQueryDto) {
    return this.service.timeline(q.limit ?? 20, q.workspaceId);
  }
}
