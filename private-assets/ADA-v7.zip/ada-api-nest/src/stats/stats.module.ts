import { Module } from '@nestjs/common';
import { ControlPlaneModule } from '../control-plane/control-plane.module.js';
import { StatsController } from './stats.controller.js';
import { StatsService } from './stats.service.js';

/**
 * P6 — dashboard agrégé & coûts. DatabaseService est global (PersistenceModule) ;
 * on importe ControlPlaneModule pour les relais RPC (router.stats/budget.check/
 * cost.report) en dégradation gracieuse.
 */
@Module({
  imports: [ControlPlaneModule],
  controllers: [StatsController],
  providers: [StatsService],
})
export class StatsModule {}
