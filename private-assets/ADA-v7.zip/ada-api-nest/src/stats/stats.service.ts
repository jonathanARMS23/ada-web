import { Injectable, Logger } from '@nestjs/common';
import { and, desc, eq, gte, inArray, sql } from 'drizzle-orm';
import { ControlPlaneClient } from '../control-plane/control-plane.client.js';
import { DatabaseService, Db } from '../persistence/database.service.js';
import { costLedger, runPhases, runs } from '../persistence/schema.js';

export interface OverviewStats {
  totalRuns: number;
  byStatus: Record<string, number>;
  successRate: number;
  topAgents: Array<{ agent: string; runs: number; cost: number }>;
  totalCost: number;
  totalTokens: number;
  activeRuns: number;
  source: 'postgres' | 'live' | 'empty';
  degraded: boolean;
}

export interface ActivityBucket {
  day: string;
  runs: number;
  cost: number;
}
export interface ActivityStats {
  days: number;
  buckets: ActivityBucket[];
  source: 'postgres' | 'empty';
  degraded: boolean;
}

export interface TimelineItem {
  runId: string;
  pipeline: string;
  name: string | null;
  status: string;
  startedAt: string | null;
  completedAt: string | null;
  durationMs: number | null;
  cost: number;
  phases: Array<{ phaseId: string; agent: string | null; status: string; cost: number; durationMs: number | null }>;
}
export interface TimelineStats {
  items: TimelineItem[];
  source: 'postgres' | 'empty';
  degraded: boolean;
}

export interface BudgetStats {
  config: Record<string, unknown> | null;
  check: Record<string, unknown> | null;
  source: 'live' | 'empty';
  degraded: boolean;
}

const ACTIVE_STATUSES = ['running', 'pending'];

/**
 * Agrégats dashboard (P6, ADR-017 feature #1/#2). 100% lecture :
 *  - source primaire = Postgres (runs / run_phases / cost_ledger) ;
 *  - router.stats / budget.check relayés en live depuis le Control Server ;
 *  - DÉGRADATION GRACIEUSE : DB down → payload calculable via RPC ou vide annoté,
 *    jamais de crash (P1 read-only ne bloque jamais).
 */
@Injectable()
export class StatsService {
  private readonly log = new Logger(StatsService.name);

  constructor(
    private readonly database: DatabaseService,
    private readonly client: ControlPlaneClient,
  ) {}

  private get db(): Db | null {
    return this.database.isUp ? this.database.db : null;
  }

  async overview(workspaceId?: string): Promise<OverviewStats> {
    const db = this.db;
    if (!db) return this.overviewDegraded();

    const runFilter = workspaceId ? eq(runs.workspaceId, workspaceId) : undefined;

    try {
      const statusRows = await db
        .select({ status: runs.status, n: sql<number>`count(*)::int` })
        .from(runs)
        .where(runFilter)
        .groupBy(runs.status);

      const byStatus: Record<string, number> = {};
      let totalRuns = 0;
      let activeRuns = 0;
      let completed = 0;
      for (const r of statusRows) {
        byStatus[r.status] = r.n;
        totalRuns += r.n;
        if (ACTIVE_STATUSES.includes(r.status)) activeRuns += r.n;
        if (r.status === 'completed') completed += r.n;
      }
      const successRate = totalRuns > 0 ? Math.round((completed / totalRuns) * 1000) / 1000 : 0;

      // top agents (run_phases joints aux runs pour le scoping workspace).
      const phaseFilter = workspaceId
        ? inArray(
            runPhases.coreRunId,
            db.select({ id: runs.coreRunId }).from(runs).where(eq(runs.workspaceId, workspaceId)),
          )
        : undefined;
      const agentRows = await db
        .select({
          agent: runPhases.agent,
          n: sql<number>`count(*)::int`,
          cost: sql<string>`coalesce(sum(${runPhases.cost}), 0)`,
        })
        .from(runPhases)
        .where(phaseFilter)
        .groupBy(runPhases.agent)
        .orderBy(desc(sql`count(*)`))
        .limit(5);
      const topAgents = agentRows
        .filter((a) => a.agent)
        .map((a) => ({ agent: a.agent as string, runs: a.n, cost: Number(a.cost) }));

      // coûts/tokens depuis le grand-livre (source de vérité P6).
      const ledgerFilter = workspaceId ? eq(costLedger.workspaceId, workspaceId) : undefined;
      const ledgerRow = await db
        .select({
          cost: sql<string>`coalesce(sum(${costLedger.cost}), 0)`,
          tokens: sql<string>`coalesce(sum(${costLedger.inputTokens} + ${costLedger.outputTokens}), 0)`,
        })
        .from(costLedger)
        .where(ledgerFilter);
      const totalCost = Number(ledgerRow[0]?.cost ?? 0);
      const totalTokens = Number(ledgerRow[0]?.tokens ?? 0);

      const routerStats = await this.routerStatsSafe();

      return {
        totalRuns,
        byStatus,
        successRate,
        topAgents,
        totalCost,
        totalTokens,
        activeRuns,
        source: 'postgres',
        degraded: false,
        ...(routerStats ? { router: routerStats } : {}),
      } as OverviewStats & { router?: unknown };
    } catch (err) {
      this.log.warn(`overview SQL échoué, dégradation: ${(err as Error).message}`);
      return this.overviewDegraded();
    }
  }

  /** Heatmap : runs + coût groupés par jour sur N jours (cost_ledger.ts). */
  async activity(days = 90, workspaceId?: string): Promise<ActivityStats> {
    const db = this.db;
    if (!db) return { days, buckets: [], source: 'empty', degraded: true };
    const since = new Date(Date.now() - days * 86_400_000);

    try {
      const ledgerFilter = workspaceId
        ? and(gte(costLedger.ts, since), eq(costLedger.workspaceId, workspaceId))
        : gte(costLedger.ts, since);
      const rows = await db
        .select({
          day: sql<string>`to_char(date_trunc('day', ${costLedger.ts}), 'YYYY-MM-DD')`,
          runs: sql<number>`count(distinct ${costLedger.runId})::int`,
          cost: sql<string>`coalesce(sum(${costLedger.cost}), 0)`,
        })
        .from(costLedger)
        .where(ledgerFilter)
        .groupBy(sql`date_trunc('day', ${costLedger.ts})`)
        .orderBy(sql`date_trunc('day', ${costLedger.ts})`);
      const buckets = rows.map((r) => ({ day: r.day, runs: r.runs, cost: Number(r.cost) }));
      return { days, buckets, source: 'postgres', degraded: false };
    } catch (err) {
      this.log.warn(`activity SQL échoué, dégradation: ${(err as Error).message}`);
      return { days, buckets: [], source: 'empty', degraded: true };
    }
  }

  /** Timeline des runs récents (status/durée/coût + phases). */
  async timeline(limit = 20, workspaceId?: string): Promise<TimelineStats> {
    const db = this.db;
    if (!db) return { items: [], source: 'empty', degraded: true };

    try {
      const runFilter = workspaceId ? eq(runs.workspaceId, workspaceId) : undefined;
      const runRows = await db
        .select()
        .from(runs)
        .where(runFilter)
        .orderBy(desc(runs.createdAt))
        .limit(limit);
      if (runRows.length === 0) return { items: [], source: 'postgres', degraded: false };

      const ids = runRows.map((r) => r.coreRunId);
      const phaseRows = await db
        .select({
          coreRunId: runPhases.coreRunId,
          phaseId: runPhases.phaseId,
          agent: runPhases.agent,
          status: runPhases.status,
          cost: runPhases.cost,
          durationMs: runPhases.durationMs,
        })
        .from(runPhases)
        .where(inArray(runPhases.coreRunId, ids));
      const phasesByRun = new Map<string, TimelineItem['phases']>();
      for (const p of phaseRows) {
        const arr = phasesByRun.get(p.coreRunId) ?? [];
        arr.push({
          phaseId: p.phaseId,
          agent: p.agent,
          status: p.status,
          cost: Number(p.cost),
          durationMs: p.durationMs,
        });
        phasesByRun.set(p.coreRunId, arr);
      }

      const items: TimelineItem[] = runRows.map((r) => {
        const startedAt = r.startedAt ? new Date(r.startedAt).toISOString() : null;
        const completedAt = r.completedAt ? new Date(r.completedAt).toISOString() : null;
        const durationMs =
          r.startedAt && r.completedAt
            ? new Date(r.completedAt).getTime() - new Date(r.startedAt).getTime()
            : null;
        return {
          runId: r.coreRunId,
          pipeline: r.pipeline,
          name: r.name,
          status: r.status,
          startedAt,
          completedAt,
          durationMs,
          cost: Number(r.totalCost),
          phases: phasesByRun.get(r.coreRunId) ?? [],
        };
      });
      return { items, source: 'postgres', degraded: false };
    } catch (err) {
      this.log.warn(`timeline SQL échoué, dégradation: ${(err as Error).message}`);
      return { items: [], source: 'empty', degraded: true };
    }
  }

  /** Relaie budget.check (live) + config budget. Dégrade en payload vide. */
  async budget(): Promise<BudgetStats> {
    try {
      const check = await this.client.request<Record<string, unknown>>('budget.check', {
        runId: '__dashboard__',
        phaseCost: 0,
        cumulCost: 0,
      });
      return {
        config: (check.config as Record<string, unknown> | undefined) ?? null,
        check,
        source: 'live',
        degraded: false,
      };
    } catch (err) {
      this.log.warn(`budget.check indisponible: ${(err as Error).message}`);
      return { config: null, check: null, source: 'empty', degraded: true };
    }
  }

  /** Overview en mode dégradé : tente cost.report (live), sinon payload vide. */
  private async overviewDegraded(): Promise<OverviewStats> {
    let totalCost = 0;
    let source: OverviewStats['source'] = 'empty';
    try {
      const report = await this.client.request<Record<string, unknown>>('cost.report');
      const tc = (report.totalCost ?? report.total) as number | undefined;
      if (typeof tc === 'number' && Number.isFinite(tc)) {
        totalCost = tc;
        source = 'live';
      }
    } catch {
      /* control plane down too → payload vide annoté */
    }
    return {
      totalRuns: 0,
      byStatus: {},
      successRate: 0,
      topAgents: [],
      totalCost,
      totalTokens: 0,
      activeRuns: 0,
      source,
      degraded: true,
    };
  }

  private async routerStatsSafe(): Promise<unknown | null> {
    try {
      return await this.client.request('router.stats');
    } catch {
      return null;
    }
  }
}
