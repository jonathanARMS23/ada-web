import { IsIn, IsOptional, IsString, MaxLength, MinLength } from 'class-validator';

/** Body of POST /tasks (ADR-016 §0). */
export class CreateTaskDto {
  @IsString()
  @MinLength(3)
  @MaxLength(2000)
  instruction!: string;

  @IsString()
  @MinLength(1)
  @MaxLength(64)
  profile!: string;

  @IsOptional()
  @IsIn(['auto', 'pipeline', 'freeform'])
  mode?: 'auto' | 'pipeline' | 'freeform';

  @IsOptional()
  @IsString()
  @MaxLength(128)
  workspaceId?: string;

  @IsOptional()
  @IsString()
  @MaxLength(128)
  conversationId?: string;
}
