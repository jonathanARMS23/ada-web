import { CanActivate, ExecutionContext, HttpException, HttpStatus, Injectable } from '@nestjs/common';
import type { FastifyRequest } from 'fastify';

/**
 * Dedicated rate limiter for POST /tasks (ADR-016 §9). A spawn-bearing endpoint
 * must not be hammered. Fixed-window, in-memory, keyed by JWT subject (else IP).
 * Defaults: 10 task creations / 60s / key.
 */
@Injectable()
export class TaskRateLimitGuard implements CanActivate {
  private static readonly WINDOW_MS = 60_000;
  private static readonly MAX = 10;
  private readonly hits = new Map<string, { count: number; resetAt: number }>();

  canActivate(context: ExecutionContext): boolean {
    const req = context.switchToHttp().getRequest<FastifyRequest & { user?: { sub?: string } }>();
    const key = req.user?.sub ?? req.ip ?? 'anon';
    const now = Date.now();
    const entry = this.hits.get(key);

    if (!entry || now >= entry.resetAt) {
      this.hits.set(key, { count: 1, resetAt: now + TaskRateLimitGuard.WINDOW_MS });
      return true;
    }
    if (entry.count >= TaskRateLimitGuard.MAX) {
      const retryAfter = Math.ceil((entry.resetAt - now) / 1000);
      throw new HttpException(
        { error: 'RATE_LIMITED', message: `Trop de tâches — réessayez dans ${retryAfter}s`, retryAfter },
        HttpStatus.TOO_MANY_REQUESTS,
      );
    }
    entry.count++;
    return true;
  }
}
