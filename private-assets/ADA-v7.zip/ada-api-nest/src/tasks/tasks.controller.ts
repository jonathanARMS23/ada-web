import { Body, Controller, Get, HttpCode, Param, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/jwt-auth.guard.js';
import { TaskRateLimitGuard } from './task-rate-limit.guard.js';
import { TasksService } from './tasks.service.js';
import { CreateTaskDto } from './dto/create-task.dto.js';

/**
 * Task entry point (ADR-016 §0). POST /tasks plans + enqueues an autonomous run
 * and returns 202 {runId}. GET /tasks/:runId reports status. JWT on all routes,
 * plus a dedicated rate limit on the spawn-bearing POST.
 */
@ApiTags('tasks')
@ApiBearerAuth()
@Controller('tasks')
@UseGuards(JwtAuthGuard)
export class TasksController {
  constructor(private readonly service: TasksService) {}

  @Post()
  @HttpCode(202)
  @UseGuards(TaskRateLimitGuard)
  @ApiOperation({ summary: 'Planifie et lance une tâche autonome (Planner + OrchestrationLoop)' })
  @ApiResponse({ status: 202, description: 'Tâche acceptée — {runId} ou clarification requise' })
  create(@Body() dto: CreateTaskDto) {
    return this.service.createTask(dto);
  }

  @Get(':runId')
  @ApiOperation({ summary: 'Statut d’un run (run.status + projection Postgres)' })
  get(@Param('runId') runId: string) {
    return this.service.getTask(runId);
  }
}
