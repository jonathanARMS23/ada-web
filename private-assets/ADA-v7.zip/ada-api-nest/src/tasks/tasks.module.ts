import { Module } from '@nestjs/common';
import { TasksController } from './tasks.controller.js';
import { TasksService } from './tasks.service.js';
import { TaskRateLimitGuard } from './task-rate-limit.guard.js';
import { PlannerModule } from '../planner/planner.module.js';
import { OrchestrationModule } from '../orchestration/orchestration.module.js';

@Module({
  imports: [PlannerModule, OrchestrationModule],
  controllers: [TasksController],
  providers: [TasksService, TaskRateLimitGuard],
})
export class TasksModule {}
