import { BadRequestException, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { eq } from 'drizzle-orm';
import { ControlPlaneClient } from '../control-plane/control-plane.client.js';
import { TaskRouterService } from '../planner/task-router.service.js';
import { isClarification } from '../planner/planner.types.js';
import { JobQueueService } from '../orchestration/job-queue.service.js';
import { DatabaseService } from '../persistence/database.service.js';
import { SessionManager } from '../sessions/session-manager.service.js';
import { runs as runsTable } from '../persistence/schema.js';
import { softValidateWorkspace } from '../workspaces/workspace-link.js';
import type { CreateTaskDto } from './dto/create-task.dto.js';

export interface TaskAccepted {
  runId: string;
  pipeline: string;
  strategy: 'pipeline' | 'freeform';
  decidedBy: string;
  rationale: string;
}

export interface SessionAccepted {
  sessionId: string;
  strategy: 'freeform';
  resumed: boolean;
  decidedBy: string;
  rationale: string;
}

export interface ClarificationNeeded {
  status: 'clarification_required';
  questions: string[];
}

export type TaskResult = TaskAccepted | SessionAccepted | ClarificationNeeded;

/**
 * POST /tasks pipeline (ADR-016 §0/§5): Planner -> run.init (RPC, never writes
 * state) -> enqueue OrchestrationLoop -> 202 {runId}. freeform plans are P3 and
 * are rejected cleanly here.
 */
@Injectable()
export class TasksService {
  private readonly log = new Logger(TasksService.name);

  constructor(
    private readonly planner: TaskRouterService,
    private readonly client: ControlPlaneClient,
    private readonly queue: JobQueueService,
    private readonly database: DatabaseService,
    private readonly sessions: SessionManager,
  ) {}

  async createTask(dto: CreateTaskDto): Promise<TaskResult> {
    // P5 §5: soft-validate the workspace link (never blocks the run).
    await softValidateWorkspace(this.database, dto.workspaceId);

    const plan = await this.planner.plan(dto.instruction, dto.mode ?? 'auto');

    if (isClarification(plan)) {
      return { status: 'clarification_required', questions: plan.questions };
    }

    if (plan.strategy === 'freeform') {
      // Mode B (P3): route to an interactive Claude Code session. The
      // instruction becomes the first user message; the live flow runs over WS.
      const { sessionId, resumed } = await this.sessions.create({
        profile: dto.profile,
        workspaceId: dto.workspaceId ?? null,
        conversationId: dto.conversationId ?? null,
        initialMessage: dto.instruction,
      });
      this.log.log(`Session free-form acceptée sessionId=${sessionId} (${plan.decidedBy})`);
      return {
        sessionId,
        strategy: 'freeform',
        resumed,
        decidedBy: plan.decidedBy,
        rationale: plan.rationale,
      };
    }

    const pipeline = plan.pipeline ?? 'feature';

    // run.init via RPC — the Control Server is the ONLY writer of state.json.
    const init = await this.client.runInit({
      pipeline,
      feature: plan.feature,
      flags: plan.opts.flags ?? [],
      correlation: { workspaceId: dto.workspaceId, conversationId: dto.conversationId },
    });
    const runId = init.runId;
    if (!runId) {
      throw new BadRequestException({
        error: 'RUN_INIT_FAILED',
        message: `run.init n’a pas renvoyé de runId (pipeline=${pipeline})`,
      });
    }

    await this.queue.enqueue({
      runId,
      instruction: dto.instruction,
      pipeline,
      feature: plan.feature,
      workspaceId: dto.workspaceId ?? null,
      conversationId: dto.conversationId ?? null,
    });

    this.log.log(`Tâche acceptée runId=${runId} pipeline=${pipeline} (${plan.decidedBy})`);
    return {
      runId,
      pipeline,
      strategy: 'pipeline',
      decidedBy: plan.decidedBy,
      rationale: plan.rationale,
    };
  }

  /** GET /tasks/:runId — live state from the Control Server, DB summary if up. */
  async getTask(runId: string): Promise<unknown> {
    try {
      const res = await this.client.request<{ state: unknown }>('run.status', { runId });
      const db = this.database.db;
      let summary: unknown = null;
      if (this.database.isUp && db) {
        const rows = await db.select().from(runsTable).where(eq(runsTable.coreRunId, runId)).limit(1);
        summary = rows[0] ?? null;
      }
      return { runId, state: res.state, summary };
    } catch (err) {
      if ((err as { code?: number }).code === 1001) {
        throw new NotFoundException({ error: 'RUN_NOT_FOUND', message: `Run inconnu: ${runId}` });
      }
      throw err;
    }
  }
}
