import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  Param,
  Patch,
  Post,
  Query,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/jwt-auth.guard.js';
import { WorkspacesService } from './workspaces.service.js';
import {
  CreateMessageDto,
  CursorPageQueryDto,
  UpdateConversationDto,
} from './dto/workspace.dto.js';

/**
 * Conversation-scoped CRUD + messages (P5). Backed by the same service as
 * workspaces. JWT on every route. 503 when DB down.
 */
@ApiTags('conversations')
@ApiBearerAuth()
@Controller('conversations')
@UseGuards(JwtAuthGuard)
export class ConversationsController {
  constructor(private readonly service: WorkspacesService) {}

  @Get(':id')
  @ApiOperation({ summary: 'Récupère une conversation (avec messageCount)' })
  get(@Param('id') id: string) {
    return this.service.getConversation(id);
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Met à jour une conversation' })
  update(@Param('id') id: string, @Body() dto: UpdateConversationDto) {
    return this.service.updateConversation(id, dto);
  }

  @Delete(':id')
  @HttpCode(204)
  @ApiOperation({ summary: 'Supprime une conversation (cascade messages)' })
  remove(@Param('id') id: string) {
    return this.service.removeConversation(id);
  }

  @Get(':id/messages')
  @ApiOperation({ summary: 'Liste paginée des messages' })
  listMessages(@Param('id') id: string, @Query() q: CursorPageQueryDto) {
    return this.service.listMessages(id, {
      limit: q.limit,
      cursor: q.cursor,
      contentType: q.contentType,
    });
  }

  @Post(':id/messages')
  @HttpCode(201)
  @ApiOperation({ summary: 'Ajoute un message à une conversation' })
  createMessage(@Param('id') id: string, @Body() dto: CreateMessageDto) {
    return this.service.createMessage(id, dto);
  }
}
