import {
  IsBoolean,
  IsHexColor,
  IsObject,
  IsOptional,
  IsString,
  MaxLength,
  MinLength,
} from 'class-validator';
import { Type } from 'class-transformer';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

/** Body of POST /workspaces. */
export class CreateWorkspaceDto {
  @ApiProperty({ example: 'Facturation SaaS' })
  @IsString()
  @MinLength(1)
  @MaxLength(255)
  name!: string;

  @ApiPropertyOptional({ example: 'claude-pro' })
  @IsOptional()
  @IsString()
  @MaxLength(64)
  profile?: string;

  @ApiPropertyOptional({ example: '#6366f1' })
  @IsOptional()
  @IsHexColor()
  color?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(2000)
  description?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(1024)
  projectDir?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  pinned?: boolean;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  archived?: boolean;

  @ApiPropertyOptional()
  @IsOptional()
  @IsObject()
  config?: Record<string, unknown>;
}

/** Body of PATCH /workspaces/:id — slug is NEVER updated. */
export class UpdateWorkspaceDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MinLength(1)
  @MaxLength(255)
  name?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(64)
  profile?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsHexColor()
  color?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(2000)
  description?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(1024)
  projectDir?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  pinned?: boolean;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  archived?: boolean;

  @ApiPropertyOptional()
  @IsOptional()
  @IsObject()
  config?: Record<string, unknown>;
}

/** Query of GET /workspaces. */
export class ListWorkspacesQueryDto {
  @ApiPropertyOptional({ description: 'Inclure les archivés (true)', example: 'false' })
  @IsOptional()
  @IsString()
  archived?: string;

  @ApiPropertyOptional({ description: 'Filtrer sur les épinglés (true)', example: 'false' })
  @IsOptional()
  @IsString()
  pinned?: string;
}

/** Body of POST /workspaces/:wid/conversations. */
export class CreateConversationDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(500)
  title?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(10_000)
  summary?: string;
}

/** Body of PATCH /conversations/:id. */
export class UpdateConversationDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(500)
  title?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(10_000)
  summary?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  pinned?: boolean;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  archived?: boolean;
}

/** Body of POST /conversations/:id/messages. */
export class CreateMessageDto {
  @ApiProperty({ enum: ['user', 'assistant', 'system', 'tool', 'error'] })
  @IsString()
  role!: string;

  @ApiProperty()
  @IsString()
  @MaxLength(100_000)
  content!: string;

  @ApiPropertyOptional({ enum: ['text', 'code', 'run_status', 'phase_log'] })
  @IsOptional()
  @IsString()
  contentType?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsObject()
  metadata?: Record<string, unknown>;
}

/** Cursor pagination query (conversations + messages). */
export class CursorPageQueryDto {
  @ApiPropertyOptional({ example: 20 })
  @IsOptional()
  @Type(() => Number)
  limit?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  cursor?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  archived?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  pinned?: string;

  @ApiPropertyOptional({ description: 'Filtre type de contenu (messages)' })
  @IsOptional()
  @IsString()
  contentType?: string;
}

/** Query of GET /workspaces/:wid/search. */
export class SearchConversationsQueryDto {
  @ApiProperty({ description: 'Terme de recherche', example: 'migration' })
  @IsString()
  @MinLength(1)
  @MaxLength(200)
  q!: string;
}
