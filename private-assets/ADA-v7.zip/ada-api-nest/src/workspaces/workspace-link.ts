import { Logger } from '@nestjs/common';
import { eq } from 'drizzle-orm';
import type { DatabaseService } from '../persistence/database.service.js';
import { workspaces } from '../persistence/schema.js';

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const log = new Logger('WorkspaceLink');

/**
 * Soft validation of a workspaceId at task/session creation (P5 §5).
 *
 * Intentionally lenient: never blocks a run. When the DB is up and the id is a
 * UUID that doesn't resolve, we only warn (the correlation column stays TEXT and
 * tolerates orphan ids — the room/scoping just won't aggregate). Returns the id
 * unchanged so callers keep their existing flow.
 */
export async function softValidateWorkspace(
  database: DatabaseService,
  workspaceId: string | null | undefined,
): Promise<void> {
  if (!workspaceId) return;
  const db = database.db;
  if (!db || !database.isUp) return; // degraded: skip, never block
  if (!UUID_RE.test(workspaceId)) return; // non-uuid correlation id (legacy/free)
  try {
    const rows = await db
      .select({ id: workspaces.id })
      .from(workspaces)
      .where(eq(workspaces.id, workspaceId))
      .limit(1);
    if (rows.length === 0) {
      log.warn(`workspaceId=${workspaceId} inconnu — run accepté sans liaison workspace réelle.`);
    }
  } catch (err) {
    log.debug(`Validation workspace ignorée: ${(err as Error).message}`);
  }
}
