import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  Param,
  Patch,
  Post,
  Query,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/jwt-auth.guard.js';
import { WorkspacesService } from './workspaces.service.js';
import {
  CreateConversationDto,
  CreateWorkspaceDto,
  CursorPageQueryDto,
  ListWorkspacesQueryDto,
  SearchConversationsQueryDto,
  UpdateWorkspaceDto,
} from './dto/workspace.dto.js';

/**
 * Workspaces CRUD + stats + nested conversations/search (P5, ADR-017 §1.2).
 * JWT on every route. All data is Postgres-backed (503 when DB down).
 */
@ApiTags('workspaces')
@ApiBearerAuth()
@Controller('workspaces')
@UseGuards(JwtAuthGuard)
export class WorkspacesController {
  constructor(private readonly service: WorkspacesService) {}

  @Post()
  @HttpCode(201)
  @ApiOperation({ summary: 'Crée un workspace (slug auto-unique)' })
  create(@Body() dto: CreateWorkspaceDto) {
    return this.service.create(dto);
  }

  @Get()
  @ApiOperation({ summary: 'Liste les workspaces (filtres archived/pinned)' })
  async list(@Query() q: ListWorkspacesQueryDto) {
    const items = await this.service.list({
      archived: q.archived === 'true',
      pinned: q.pinned === 'true',
    });
    return { items, total: items.length };
  }

  @Get(':id')
  @ApiOperation({ summary: 'Récupère un workspace par UUID ou slug' })
  get(@Param('id') id: string) {
    return this.service.get(id);
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Met à jour un workspace (slug immuable)' })
  update(@Param('id') id: string, @Body() dto: UpdateWorkspaceDto) {
    return this.service.update(id, dto);
  }

  @Delete(':id')
  @HttpCode(204)
  @ApiOperation({ summary: 'Supprime un workspace (cascade conversations/messages)' })
  remove(@Param('id') id: string) {
    return this.service.remove(id);
  }

  @Get(':id/stats')
  @ApiOperation({ summary: 'Stats agrégées (runs, coûts, tokens, conversations, messages)' })
  stats(@Param('id') id: string) {
    return this.service.stats(id);
  }

  @Get(':id/conversations')
  @ApiOperation({ summary: 'Liste paginée des conversations du workspace' })
  listConversations(@Param('id') id: string, @Query() q: CursorPageQueryDto) {
    return this.service.listConversations(id, {
      limit: q.limit,
      cursor: q.cursor,
      archived: q.archived === 'true',
      pinned: q.pinned === undefined ? undefined : q.pinned === 'true',
    });
  }

  @Post(':id/conversations')
  @HttpCode(201)
  @ApiOperation({ summary: 'Crée une conversation dans le workspace' })
  createConversation(@Param('id') id: string, @Body() dto: CreateConversationDto) {
    return this.service.createConversation(id, dto);
  }

  @Get(':id/search')
  @ApiOperation({ summary: 'Recherche plein-texte dans les messages du workspace' })
  search(@Param('id') id: string, @Query() q: SearchConversationsQueryDto) {
    return this.service.search(id, q.q);
  }
}
