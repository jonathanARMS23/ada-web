import { Module } from '@nestjs/common';
import { WorkspacesController } from './workspaces.controller.js';
import { ConversationsController } from './conversations.controller.js';
import { WorkspacesService } from './workspaces.service.js';

/**
 * P5 — Workspaces & conversations. DatabaseService is global (PersistenceModule),
 * so this module only wires the controllers + service.
 */
@Module({
  controllers: [WorkspacesController, ConversationsController],
  providers: [WorkspacesService],
  exports: [WorkspacesService],
})
export class WorkspacesModule {}
