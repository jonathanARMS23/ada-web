import {
  BadRequestException,
  Injectable,
  NotFoundException,
  ServiceUnavailableException,
} from '@nestjs/common';
import { and, desc, eq, inArray, lt, sql } from 'drizzle-orm';
import { DatabaseService, Db } from '../persistence/database.service.js';
import {
  conversations,
  messages,
  runs,
  workspaces,
} from '../persistence/schema.js';
import {
  CreateConversationDto,
  CreateMessageDto,
  CreateWorkspaceDto,
  UpdateConversationDto,
  UpdateWorkspaceDto,
} from './dto/workspace.dto.js';

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const VALID_ROLES = ['user', 'assistant', 'system', 'tool', 'error'];
const VALID_CONTENT_TYPES = ['text', 'code', 'run_status', 'phase_log'];

type WorkspaceRow = typeof workspaces.$inferSelect;
type ConversationRow = typeof conversations.$inferSelect;
type MessageRow = typeof messages.$inferSelect;

/**
 * Workspaces & conversations CRUD (P5). Ports the Fastify business logic
 * (slug, stats, cascade, search) onto Drizzle/Postgres.
 *
 * Degradation: every method requires the DB to be up; when down/disabled it
 * raises 503 (workspaces are a pure Postgres-backed product surface — there is
 * no live fallback, unlike logs). The app still boots without a DB.
 */
@Injectable()
export class WorkspacesService {
  constructor(private readonly database: DatabaseService) {}

  private requireDb(): Db {
    const db = this.database.db;
    if (!db || !this.database.isUp) {
      throw new ServiceUnavailableException({
        error: 'DB_UNAVAILABLE',
        message: 'Persistance indisponible — workspaces nécessitent Postgres.',
      });
    }
    return db;
  }

  // ── Slug ───────────────────────────────────────────────────────────────────
  private slugify(name: string): string {
    return name
      .normalize('NFD')
      .replace(/[̀-ͯ]/g, '')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');
  }

  private async uniqueSlug(db: Db, base: string): Promise<string> {
    const root = base || 'workspace';
    let candidate = root;
    let counter = 2;
    for (;;) {
      const hit = await db
        .select({ id: workspaces.id })
        .from(workspaces)
        .where(eq(workspaces.slug, candidate))
        .limit(1);
      if (hit.length === 0) return candidate;
      candidate = `${root}-${counter++}`;
    }
  }

  // ── Workspaces CRUD ──────────────────────────────────────────────────────────
  async create(dto: CreateWorkspaceDto): Promise<WorkspaceRow> {
    const db = this.requireDb();
    const name = dto.name.trim();
    if (!name) throw new BadRequestException({ error: 'VALIDATION_ERROR', message: 'name is required' });
    const slug = await this.uniqueSlug(db, this.slugify(name));
    const rows = await db
      .insert(workspaces)
      .values({
        name,
        slug,
        profile: dto.profile ?? 'claude-pro',
        color: dto.color ?? '#6366f1',
        description: dto.description ?? null,
        projectDir: dto.projectDir ?? null,
        pinned: dto.pinned ?? false,
        archived: dto.archived ?? false,
        config: dto.config ?? {},
      })
      .returning();
    return rows[0];
  }

  async list(opts: { archived?: boolean; pinned?: boolean }): Promise<WorkspaceRow[]> {
    const db = this.requireDb();
    const conditions = [];
    if (!opts.archived) conditions.push(eq(workspaces.archived, false));
    if (opts.pinned) conditions.push(eq(workspaces.pinned, true));
    const where = conditions.length ? and(...conditions) : undefined;
    return db.select().from(workspaces).where(where).orderBy(desc(workspaces.updatedAt));
  }

  /** Resolve by UUID or slug. Returns null when absent. */
  private async findOne(db: Db, idOrSlug: string): Promise<WorkspaceRow | null> {
    const where = UUID_RE.test(idOrSlug)
      ? eq(workspaces.id, idOrSlug)
      : eq(workspaces.slug, idOrSlug);
    const rows = await db.select().from(workspaces).where(where).limit(1);
    return rows[0] ?? null;
  }

  async get(idOrSlug: string): Promise<WorkspaceRow> {
    const db = this.requireDb();
    const row = await this.findOne(db, idOrSlug);
    if (!row) throw new NotFoundException({ error: 'WORKSPACE_NOT_FOUND', message: 'Workspace not found' });
    return row;
  }

  async update(idOrSlug: string, dto: UpdateWorkspaceDto): Promise<WorkspaceRow> {
    const db = this.requireDb();
    const existing = await this.findOne(db, idOrSlug);
    if (!existing) throw new NotFoundException({ error: 'WORKSPACE_NOT_FOUND', message: 'Workspace not found' });

    // slug is NEVER updated (Fastify parity).
    const patch: Partial<WorkspaceRow> = { updatedAt: new Date() };
    if (dto.name !== undefined) patch.name = dto.name.trim();
    if (dto.profile !== undefined) patch.profile = dto.profile;
    if (dto.color !== undefined) patch.color = dto.color;
    if (dto.description !== undefined) patch.description = dto.description;
    if (dto.projectDir !== undefined) patch.projectDir = dto.projectDir;
    if (dto.pinned !== undefined) patch.pinned = dto.pinned;
    if (dto.archived !== undefined) patch.archived = dto.archived;
    if (dto.config !== undefined) patch.config = dto.config;

    const rows = await db
      .update(workspaces)
      .set(patch)
      .where(eq(workspaces.id, existing.id))
      .returning();
    return rows[0];
  }

  async remove(idOrSlug: string): Promise<void> {
    const db = this.requireDb();
    const existing = await this.findOne(db, idOrSlug);
    if (!existing) throw new NotFoundException({ error: 'WORKSPACE_NOT_FOUND', message: 'Workspace not found' });
    // ON DELETE CASCADE removes conversations + their messages.
    await db.delete(workspaces).where(eq(workspaces.id, existing.id));
  }

  // ── Stats ─────────────────────────────────────────────────────────────────
  async stats(idOrSlug: string): Promise<{
    totalRuns: number;
    totalCost: number;
    totalTokens: number;
    conversationCount: number;
    totalMessages: number;
    lastRunAt: string | null;
  }> {
    const db = this.requireDb();
    const ws = await this.findOne(db, idOrSlug);
    if (!ws) throw new NotFoundException({ error: 'WORKSPACE_NOT_FOUND', message: 'Workspace not found' });

    const runAgg = await db
      .select({
        totalRuns: sql<number>`count(*)::int`,
        totalCost: sql<string>`coalesce(sum(${runs.totalCost}), 0)`,
        totalTokens: sql<number>`coalesce(sum(${runs.totalTokens}), 0)::bigint`,
        lastRunAt: sql<string | null>`max(${runs.completedAt})`,
      })
      .from(runs)
      .where(eq(runs.workspaceId, ws.id));

    const convAgg = await db
      .select({ conversationCount: sql<number>`count(*)::int` })
      .from(conversations)
      .where(eq(conversations.workspaceId, ws.id));

    const msgAgg = await db
      .select({ totalMessages: sql<number>`count(${messages.id})::int` })
      .from(messages)
      .innerJoin(conversations, eq(conversations.id, messages.conversationId))
      .where(eq(conversations.workspaceId, ws.id));

    return {
      totalRuns: runAgg[0]?.totalRuns ?? 0,
      totalCost: Number(runAgg[0]?.totalCost ?? 0),
      totalTokens: Number(runAgg[0]?.totalTokens ?? 0),
      conversationCount: convAgg[0]?.conversationCount ?? 0,
      totalMessages: msgAgg[0]?.totalMessages ?? 0,
      lastRunAt: runAgg[0]?.lastRunAt ?? null,
    };
  }

  // ── Conversations ────────────────────────────────────────────────────────────
  async listConversations(
    idOrSlug: string,
    opts: { limit?: number; cursor?: string; archived?: boolean; pinned?: boolean },
  ): Promise<{
    items: (ConversationRow & { messageCount: number })[];
    nextCursor: string | null;
    hasMore: boolean;
    total: number;
  }> {
    const db = this.requireDb();
    const ws = await this.findOne(db, idOrSlug);
    if (!ws) throw new NotFoundException({ error: 'WORKSPACE_NOT_FOUND', message: 'Workspace not found' });

    const limit = Math.min(Math.max(1, opts.limit ?? 20), 100);
    const conditions = [eq(conversations.workspaceId, ws.id), eq(conversations.archived, opts.archived ?? false)];
    if (opts.pinned !== undefined) conditions.push(eq(conversations.pinned, opts.pinned));

    const totalRow = await db
      .select({ cnt: sql<number>`count(*)::int` })
      .from(conversations)
      .where(and(...conditions));
    const total = totalRow[0]?.cnt ?? 0;

    if (opts.cursor) {
      const cur = await db
        .select({ updatedAt: conversations.updatedAt })
        .from(conversations)
        .where(and(eq(conversations.id, opts.cursor), eq(conversations.workspaceId, ws.id)))
        .limit(1);
      if (cur[0]) conditions.push(lt(conversations.updatedAt, cur[0].updatedAt));
    }

    const rows = await db
      .select()
      .from(conversations)
      .where(and(...conditions))
      .orderBy(desc(conversations.updatedAt))
      .limit(limit + 1);

    const hasMore = rows.length > limit;
    const page = hasMore ? rows.slice(0, limit) : rows;

    // Batch message counts for the page (avoids N+1 and correlated-subquery aliasing).
    const counts = new Map<string, number>();
    if (page.length > 0) {
      const ids = page.map((r) => r.id);
      const countRows = await db
        .select({ conversationId: messages.conversationId, cnt: sql<number>`count(*)::int` })
        .from(messages)
        .where(inArray(messages.conversationId, ids))
        .groupBy(messages.conversationId);
      for (const cr of countRows) if (cr.conversationId) counts.set(cr.conversationId, cr.cnt);
    }

    const items = page.map((r) => ({ ...r, messageCount: counts.get(r.id) ?? 0 }));
    const nextCursor = hasMore ? page[page.length - 1].id : null;
    return { items, nextCursor, hasMore, total };
  }

  async createConversation(idOrSlug: string, dto: CreateConversationDto): Promise<ConversationRow> {
    const db = this.requireDb();
    const ws = await this.findOne(db, idOrSlug);
    if (!ws) throw new NotFoundException({ error: 'WORKSPACE_NOT_FOUND', message: 'Workspace not found' });
    const rows = await db
      .insert(conversations)
      .values({ workspaceId: ws.id, title: dto.title ?? '', summary: dto.summary ?? null })
      .returning();
    await db.update(workspaces).set({ updatedAt: new Date() }).where(eq(workspaces.id, ws.id));
    return rows[0];
  }

  private async requireConversation(db: Db, id: string): Promise<ConversationRow> {
    if (!UUID_RE.test(id)) {
      throw new NotFoundException({ error: 'CONVERSATION_NOT_FOUND', message: 'Conversation not found' });
    }
    const rows = await db.select().from(conversations).where(eq(conversations.id, id)).limit(1);
    if (!rows[0]) throw new NotFoundException({ error: 'CONVERSATION_NOT_FOUND', message: 'Conversation not found' });
    return rows[0];
  }

  async getConversation(id: string): Promise<ConversationRow & { messageCount: number }> {
    const db = this.requireDb();
    const conv = await this.requireConversation(db, id);
    const cnt = await db
      .select({ cnt: sql<number>`count(*)::int` })
      .from(messages)
      .where(eq(messages.conversationId, id));
    return { ...conv, messageCount: cnt[0]?.cnt ?? 0 };
  }

  async updateConversation(id: string, dto: UpdateConversationDto): Promise<ConversationRow> {
    const db = this.requireDb();
    await this.requireConversation(db, id);
    const patch: Partial<ConversationRow> = { updatedAt: new Date() };
    if (dto.title !== undefined) patch.title = dto.title;
    if (dto.summary !== undefined) patch.summary = dto.summary;
    if (dto.pinned !== undefined) patch.pinned = dto.pinned;
    if (dto.archived !== undefined) patch.archived = dto.archived;
    const rows = await db.update(conversations).set(patch).where(eq(conversations.id, id)).returning();
    return rows[0];
  }

  async removeConversation(id: string): Promise<void> {
    const db = this.requireDb();
    await this.requireConversation(db, id);
    await db.delete(conversations).where(eq(conversations.id, id));
  }

  // ── Messages ────────────────────────────────────────────────────────────────
  async createMessage(id: string, dto: CreateMessageDto): Promise<MessageRow> {
    const db = this.requireDb();
    const conv = await this.requireConversation(db, id);
    if (!VALID_ROLES.includes(dto.role)) {
      throw new BadRequestException({
        error: 'VALIDATION_ERROR',
        message: `role must be one of: ${VALID_ROLES.join(', ')}`,
      });
    }
    const contentType = VALID_CONTENT_TYPES.includes(dto.contentType ?? '') ? dto.contentType! : 'text';
    const rows = await db
      .insert(messages)
      .values({
        conversationId: conv.id,
        role: dto.role,
        content: dto.content,
        contentType,
        metadata: dto.metadata ?? null,
      })
      .returning();
    await db.update(conversations).set({ updatedAt: new Date() }).where(eq(conversations.id, conv.id));
    return rows[0];
  }

  async listMessages(
    id: string,
    opts: { limit?: number; cursor?: string; contentType?: string },
  ): Promise<{ items: MessageRow[]; nextCursor: string | null; hasMore: boolean }> {
    const db = this.requireDb();
    await this.requireConversation(db, id);
    const limit = Math.min(Math.max(1, opts.limit ?? 50), 200);
    const conditions = [eq(messages.conversationId, id)];
    if (opts.contentType && VALID_CONTENT_TYPES.includes(opts.contentType)) {
      conditions.push(eq(messages.contentType, opts.contentType));
    }
    if (opts.cursor && UUID_RE.test(opts.cursor)) {
      const cur = await db
        .select({ createdAt: messages.createdAt })
        .from(messages)
        .where(eq(messages.id, opts.cursor))
        .limit(1);
      if (cur[0]) conditions.push(lt(messages.createdAt, cur[0].createdAt));
    }
    const rows = await db
      .select()
      .from(messages)
      .where(and(...conditions))
      .orderBy(desc(messages.createdAt))
      .limit(limit + 1);
    const hasMore = rows.length > limit;
    const page = hasMore ? rows.slice(0, limit) : rows;
    const nextCursor = hasMore ? page[page.length - 1].id : null;
    return { items: page, nextCursor, hasMore };
  }

  // ── Search ──────────────────────────────────────────────────────────────────
  async search(
    idOrSlug: string,
    term: string,
  ): Promise<{
    items: {
      messageId: string;
      conversationId: string | null;
      conversationTitle: string;
      content: string;
      createdAt: Date;
    }[];
    total: number;
  }> {
    const db = this.requireDb();
    const ws = await this.findOne(db, idOrSlug);
    if (!ws) throw new NotFoundException({ error: 'WORKSPACE_NOT_FOUND', message: 'Workspace not found' });
    const q = term.trim();
    if (!q) throw new BadRequestException({ error: 'VALIDATION_ERROR', message: 'q is required' });
    const rows = await db
      .select({
        messageId: messages.id,
        conversationId: messages.conversationId,
        conversationTitle: conversations.title,
        content: messages.content,
        createdAt: messages.createdAt,
      })
      .from(messages)
      .innerJoin(conversations, eq(conversations.id, messages.conversationId))
      .where(and(eq(conversations.workspaceId, ws.id), sql`${messages.content} ILIKE ${'%' + q + '%'}`))
      .orderBy(desc(messages.createdAt))
      .limit(50);
    return { items: rows, total: rows.length };
  }
}
