import { describe, it, expect, vi } from 'vitest';
import { AdaController } from '../src/ada/ada.controller.js';
import { AdaService } from '../src/ada/ada.service.js';
import { ConfigService } from '../src/ada/config.service.js';
import type { AgentAccessService } from '../src/ada/agent-access.service.js';
import {
  McpController,
  PipelinesController,
  SettingsController,
  TeamsController,
} from '../src/ada/config.controllers.js';
import type { ControlPlaneClient } from '../src/control-plane/control-plane.client.js';

/**
 * P4a — AdaController/AdaService relay the full CLI surface to the Control Server.
 * We stub ControlPlaneClient.request and assert each route forwards the right RPC
 * method + params (read vs mutation), mirroring the planner.spec stub style.
 */
function makeController(requestImpl?: (m: string, p: Record<string, unknown>) => Promise<unknown>) {
  const request = vi.fn(requestImpl ?? (async () => ({ ok: true })));
  const client = { request } as unknown as ControlPlaneClient;
  const service = new AdaService(client);
  const access = makeAgentAccessStub();
  const config = new ConfigService(client, access);
  const controller = new AdaController(service, config);
  return { controller, config, request };
}

/** P7 — wire ConfigService + a config controller over a stubbed client. */
function makeConfig(requestImpl?: (m: string, p: Record<string, unknown>) => Promise<unknown>) {
  const request = vi.fn(requestImpl ?? (async () => ({ ok: true })));
  const client = { request } as unknown as ControlPlaneClient;
  const config = new ConfigService(client, makeAgentAccessStub());
  return { config, request };
}

/** Stub AgentAccessService : renvoie l'ensemble fourni (équiv. "All tools"). */
function makeAgentAccessStub(): AgentAccessService {
  return {
    resolveMcps: (_slug: string, mcps: string[]) => mcps,
    resolveSkills: (_slug: string, skills: string[]) => skills,
  } as unknown as AgentAccessService;
}

describe('AdaController (surface CLI — P4a)', () => {
  it('GET /agents relaie agents.list (avec category)', async () => {
    const { controller, request } = makeController(async () => ({ agents: [{ name: 'nestjs' }], total: 1 }));
    const res = (await controller.agents({ category: 'ada' })) as { total: number };
    expect(request).toHaveBeenCalledWith('agents.list', { category: 'ada' });
    expect(res.total).toBe(1);
  });

  it('GET /agents sans category passe un params vide', async () => {
    const { controller, request } = makeController();
    await controller.agents({});
    expect(request).toHaveBeenCalledWith('agents.list', {});
  });

  it('GET /skills relaie skills.list', async () => {
    const { controller, request } = makeController(async () => ({ installed: [], available: [], counts: { installed: 0, available: 0 } }));
    await controller.skills();
    expect(request).toHaveBeenCalledWith('skills.list');
  });

  it('GET /skills/search relaie skills.search avec la requête', async () => {
    const { controller, request } = makeController(async () => ({ results: [], total: 0, query: 'jwt' }));
    await controller.searchSkills({ q: 'jwt' });
    expect(request).toHaveBeenCalledWith('skills.search', { query: 'jwt' });
  });

  it('GET /daemon relaie daemon.status', async () => {
    const { controller, request } = makeController(async () => ({ running: false, schedule: {}, workers: {} }));
    const res = (await controller.daemon()) as { running: boolean };
    expect(request).toHaveBeenCalledWith('daemon.status');
    expect(res.running).toBe(false);
  });

  it('GET /providers relaie providers.status', async () => {
    const { controller, request } = makeController(async () => ({ mode: 'claude-code', available: [], all: [] }));
    await controller.providers();
    expect(request).toHaveBeenCalledWith('providers.status');
  });

  it('GET /logs (DB down) relaie logs.tail via LogsService', async () => {
    // P5: GET /logs a migré vers LogsController/LogsService. En mode dégradé
    // (DB down/disabled) le service relaie le tail live `logs.tail`.
    const request = vi.fn(async () => ({ source: 'events', lines: [], count: 0 }));
    const client = { request } as unknown as ControlPlaneClient;
    const database = { db: null, isUp: false } as unknown as import('../src/persistence/database.service.js').DatabaseService;
    const { LogsService } = await import('../src/logs/logs.service.js');
    const svc = new LogsService(database, client);
    const res = await svc.query({ source: 'daemon', limit: 50 });
    expect(request).toHaveBeenCalledWith('logs.tail', { source: 'daemon', lines: 50 });
    expect(res.source).toBe('live');
  });

  it('PUT /providers relaie providers.set (mutation)', async () => {
    const { controller, request } = makeController(async () => ({ ok: true, mode: 'api' }));
    const res = (await controller.setProvider({ mode: 'api' })) as { mode: string };
    expect(request).toHaveBeenCalledWith('providers.set', { mode: 'api' });
    expect(res.mode).toBe('api');
  });

  it('POST /schedules relaie schedules.add (mutation)', async () => {
    const { controller, request } = makeController(async () => ({ ok: true, schedule: { id: 'abc' } }));
    await controller.addSchedule({ pipeline: 'feature', cron: '0 9 * * 1', name: 'lundi' });
    expect(request).toHaveBeenCalledWith('schedules.add', { pipeline: 'feature', cron: '0 9 * * 1', name: 'lundi' });
  });

  it('POST /skills relaie skill.install (mutation rate-limitée)', async () => {
    const { controller, request } = makeController(async () => ({ installed: true }));
    const res = (await controller.installSkill({ name: 'create-module' })) as { installed: boolean };
    expect(request).toHaveBeenCalledWith('skill.install', { name: 'create-module' });
    expect(res.installed).toBe(true);
  });

  it('propage l\'erreur RPC (ex. control plane indisponible)', async () => {
    const { controller } = makeController(async () => {
      throw new Error('CONTROL_PLANE_UNAVAILABLE');
    });
    await expect(controller.profiles()).rejects.toThrow('CONTROL_PLANE_UNAVAILABLE');
  });
});

describe('P7 — features de configuration (relais RPC)', () => {
  it('GET /pipelines relaie pipelines.list', async () => {
    const { config, request } = makeConfig(async () => ({ pipelines: [{ name: 'feature' }], total: 1 }));
    const ctrl = new PipelinesController(config);
    const res = (await ctrl.list()) as { total: number };
    expect(request).toHaveBeenCalledWith('pipelines.list');
    expect(res.total).toBe(1);
  });

  it('GET /pipelines/:name relaie pipelines.get avec le nom', async () => {
    const { config, request } = makeConfig(async () => ({ pipeline: { name: 'feature' } }));
    const ctrl = new PipelinesController(config);
    await ctrl.get('feature');
    expect(request).toHaveBeenCalledWith('pipelines.get', { name: 'feature' });
  });

  it('GET /mcp/connectors relaie mcp.list', async () => {
    const { config, request } = makeConfig(async () => ({ connectors: [], total: 0 }));
    const ctrl = new McpController(config);
    await ctrl.listConnectors();
    expect(request).toHaveBeenCalledWith('mcp.list');
  });

  it('GET /mcp/registry relaie mcp.registry', async () => {
    const { config, request } = makeConfig(async () => ({ catalog: [], total: 0 }));
    const ctrl = new McpController(config);
    await ctrl.registry();
    expect(request).toHaveBeenCalledWith('mcp.registry');
  });

  it('POST /mcp/connectors relaie mcp.add (mutation)', async () => {
    const { config, request } = makeConfig(async () => ({ ok: true, id: 'github' }));
    const ctrl = new McpController(config);
    await ctrl.addConnector({ id: 'github', command: 'npx', args: ['-y', 'srv'], env: { T: 'x' } });
    expect(request).toHaveBeenCalledWith('mcp.add', { id: 'github', command: 'npx', args: ['-y', 'srv'], env: { T: 'x' } });
  });

  it('PATCH /mcp/connectors/:id relaie mcp.update (mutation)', async () => {
    const { config, request } = makeConfig(async () => ({ ok: true, id: 'github' }));
    const ctrl = new McpController(config);
    await ctrl.updateConnector('github', { enabled: false });
    expect(request).toHaveBeenCalledWith('mcp.update', { id: 'github', enabled: false });
  });

  it('DELETE /mcp/connectors/:id relaie mcp.remove (mutation)', async () => {
    const { config, request } = makeConfig(async () => ({ ok: true, removed: 1 }));
    const ctrl = new McpController(config);
    const res = (await ctrl.removeConnector('github')) as { removed: number };
    expect(request).toHaveBeenCalledWith('mcp.remove', { id: 'github' });
    expect(res.removed).toBe(1);
  });

  it('GET /teams relaie teams.list', async () => {
    const { config, request } = makeConfig(async () => ({ teams: [{ id: 'x', name: 'fullstack' }], total: 1 }));
    const ctrl = new TeamsController(config);
    const res = (await ctrl.list()) as { total: number };
    expect(request).toHaveBeenCalledWith('teams.list');
    expect(res.total).toBe(1);
  });

  it('POST /teams relaie teams.create (mutation)', async () => {
    const { config, request } = makeConfig(async () => ({ ok: true, team: { id: 'uuid' } }));
    const ctrl = new TeamsController(config);
    await ctrl.create({ name: 'mobile', agents: ['react-native', 'api-designer'] });
    expect(request).toHaveBeenCalledWith('teams.create', { name: 'mobile', agents: ['react-native', 'api-designer'] });
  });

  it('PATCH /teams/:id relaie teams.update (mutation)', async () => {
    const { config, request } = makeConfig(async () => ({ ok: true, team: { id: 'uuid' } }));
    const ctrl = new TeamsController(config);
    await ctrl.update('uuid', { name: 'renamed' });
    expect(request).toHaveBeenCalledWith('teams.update', { id: 'uuid', name: 'renamed' });
  });

  it('GET /settings relaie settings.get', async () => {
    const { config, request } = makeConfig(async () => ({ settings: { providerMode: 'claude-code' } }));
    const ctrl = new SettingsController(config);
    await ctrl.get();
    expect(request).toHaveBeenCalledWith('settings.get');
  });

  it('PUT /settings relaie settings.set (mutation)', async () => {
    const { config, request } = makeConfig(async () => ({ ok: true, settings: {} }));
    const ctrl = new SettingsController(config);
    await ctrl.set({ providerMode: 'api' });
    expect(request).toHaveBeenCalledWith('settings.set', { providerMode: 'api' });
  });

  it('GET /agents/:slug relaie agents.info', async () => {
    const { controller, request } = makeController(async () => ({ agent: { slug: 'nestjs' } }));
    await controller.agentInfo('nestjs');
    expect(request).toHaveBeenCalledWith('agents.info', { slug: 'nestjs' });
  });

  it('PUT /profiles/active relaie profiles.switch (mutation)', async () => {
    const { controller, request } = makeController(async () => ({ ok: true, active: 'claude-pro' }));
    await controller.switchProfile({ profile: 'pro' });
    expect(request).toHaveBeenCalledWith('profiles.switch', { profile: 'pro' });
  });

  it('POST /profiles relaie profiles.create (mutation)', async () => {
    const { controller, request } = makeController(async () => ({ ok: true, profile: { name: 'client-x' } }));
    await controller.createProfile({ name: 'client-x', activate: true });
    expect(request).toHaveBeenCalledWith('profiles.create', { name: 'client-x', activate: true });
  });
});
