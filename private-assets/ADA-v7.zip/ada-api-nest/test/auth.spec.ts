import { describe, it, expect } from 'vitest';
import { JwtService } from '../src/auth/jwt.service.js';
import { AuthController } from '../src/auth/auth.controller.js';
import type { AppConfigService } from '../src/config/app-config.service.js';

const fakeConfig = (secret = 'test-secret-1234567890') =>
  ({ jwtSecret: secret }) as unknown as AppConfigService;

describe('P6 auth — émission + vérification JWT (jose HS256)', () => {
  it('sign() émet un jeton Bearer vérifiable par verify()', async () => {
    const svc = new JwtService(fakeConfig());
    const issued = await svc.sign();
    expect(issued.tokenType).toBe('Bearer');
    expect(typeof issued.token).toBe('string');
    expect(issued.token.split('.')).toHaveLength(3); // header.payload.signature
    expect(Date.parse(issued.expiresAt)).toBeGreaterThan(Date.now());

    const payload = await svc.verify(issued.token);
    expect(payload.sub).toBe('local');
    expect(payload.exp).toBeGreaterThan(Math.floor(Date.now() / 1000));
  });

  it('verify() rejette une signature forgée avec un autre secret', async () => {
    const issuer = new JwtService(fakeConfig('secret-A-1234567890'));
    const other = new JwtService(fakeConfig('secret-B-1234567890'));
    const { token } = await issuer.sign();
    await expect(other.verify(token)).rejects.toMatchObject({ code: 'INVALID_TOKEN' });
  });

  it('verify() signale TOKEN_EXPIRED sur un TTL passé', async () => {
    const svc = new JwtService(fakeConfig());
    const { token } = await svc.sign({}, -1); // déjà expiré
    await expect(svc.verify(token)).rejects.toMatchObject({ code: 'TOKEN_EXPIRED' });
  });

  it('AuthController.token() délègue à sign() et renvoie un Bearer', async () => {
    const svc = new JwtService(fakeConfig());
    const ctrl = new AuthController(svc);
    const issued = await ctrl.token();
    expect(issued.tokenType).toBe('Bearer');
    const payload = await svc.verify(issued.token);
    expect(payload.sub).toBe('local');
  });

  it('AuthController.refresh() ré-émet un jeton valide', async () => {
    const svc = new JwtService(fakeConfig());
    const ctrl = new AuthController(svc);
    const issued = await ctrl.refresh();
    await expect(svc.verify(issued.token)).resolves.toMatchObject({ sub: 'local' });
  });
});
