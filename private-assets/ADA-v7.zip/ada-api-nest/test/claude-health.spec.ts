import { describe, it, expect, vi } from 'vitest';
import { ClaudeService } from '../src/claude/claude.service.js';
import { HealthProbeService } from '../src/control-plane/health-probe.service.js';
import type { ControlPlaneClient } from '../src/control-plane/control-plane.client.js';
import type { CapabilityDiscoveryService } from '../src/control-plane/capability-discovery.service.js';
import type { DatabaseService } from '../src/persistence/database.service.js';
import type { ControlHealth } from '../src/control-plane/health-probe.service.js';

/**
 * P1-2 — GET /api/health surfaces the memory-layer health relayed by the core's
 * health.probe (memory: { ollama, recallDegraded, lastRecallDegradedAt }).
 *
 * Contract assertions:
 *  - memory is mapped to { ollama:'up'|'down', degraded:boolean } on the response;
 *  - memory.degraded is INFORMATIVE: it never flips the global `status`.
 */

function makeService(opts: {
  reachable: boolean;
  probe?: ControlHealth;
  db: 'up' | 'down' | 'disabled';
}): ClaudeService {
  // Client only needs ready/connectionState/server for HealthProbeService.status().
  const client = {
    ready: opts.reachable,
    connectionState: opts.reachable ? 'ready' : 'closed',
    server: { protocolVersion: '1.0.0', serverPid: 123 },
    request: vi.fn(async () => {
      if (!opts.probe) throw new Error('no probe');
      return opts.probe;
    }),
  } as unknown as ControlPlaneClient;

  const healthProbe = new HealthProbeService(client);
  const capabilities = {} as CapabilityDiscoveryService;
  const database = {
    status: opts.db,
    lastError: null,
    db: null,
    isUp: opts.db === 'up',
  } as unknown as DatabaseService;

  return new ClaudeService(client, capabilities, healthProbe, database);
}

describe('ClaudeService.getHealth — memory health (P1-2)', () => {
  it('maps memory.ollama up + degraded=false when Ollama is up', async () => {
    const svc = makeService({
      reachable: true,
      db: 'up',
      probe: {
        status: 'ok',
        uptimeMs: 10,
        pid: 1,
        memory: { ollama: 'up', recallDegraded: false, lastRecallDegradedAt: null },
      },
    });
    const res = await svc.getHealth();
    expect(res.memory).toEqual({ ollama: 'up', degraded: false });
    expect(res.status).toBe('ok');
  });

  it('memory.degraded is INFORMATIVE — does NOT flip status to degraded', async () => {
    const svc = makeService({
      reachable: true,
      db: 'up',
      probe: {
        status: 'ok',
        uptimeMs: 10,
        pid: 1,
        memory: { ollama: 'down', recallDegraded: true, lastRecallDegradedAt: '2026-06-18T00:00:00.000Z' },
      },
    });
    const res = await svc.getHealth();
    expect(res.memory).toEqual({ ollama: 'down', degraded: true });
    // Recall degraded (TF-IDF) is still functional → global status stays ok.
    expect(res.status).toBe('ok');
  });

  it('defaults memory to down/degraded when the probe omits the memory block', async () => {
    const svc = makeService({
      reachable: true,
      db: 'up',
      probe: { status: 'ok', uptimeMs: 10, pid: 1 }, // legacy core, no memory
    });
    const res = await svc.getHealth();
    expect(res.memory).toEqual({ ollama: 'down', degraded: true });
    expect(res.status).toBe('ok');
  });

  it('status is degraded when db is down — independent of memory health', async () => {
    const svc = makeService({
      reachable: true,
      db: 'down',
      probe: {
        status: 'ok',
        uptimeMs: 10,
        pid: 1,
        memory: { ollama: 'up', recallDegraded: false, lastRecallDegradedAt: null },
      },
    });
    const res = await svc.getHealth();
    expect(res.status).toBe('degraded');
    expect(res.memory.ollama).toBe('up');
  });
});
