import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import * as fs from 'node:fs';
import { ControlPlaneClient } from '../src/control-plane/control-plane.client.js';
import type { AppConfigService } from '../src/config/app-config.service.js';
import type { ControlEvent } from '../src/control-plane/control-plane.types.js';
import {
  startControlServer,
  controlServerAvailable,
  HarnessHandle,
} from './control-server.harness.js';

/**
 * Validates the ControlPlaneClient against the REAL control-server.js:
 *  - handshake `hello` (protocolVersion 1.0.0, profile match)
 *  - an RPC method (health.probe / capabilities.list)
 *  - HMAC signing/verification end-to-end (byte-identical canonical form)
 *  - reception of an event (appended to events.ndjson, picked up by replay)
 */

function fakeConfig(h: HarnessHandle): AppConfigService {
  return {
    profile: h.profile,
    profileDir: h.profileDir,
    controlTcpPort: h.tcpPort,
    controlSocketPath: '/nonexistent.sock',
    eventsLogPath: h.eventsLog,
    ipcSecret: h.secret,
    reconnectMinMs: 200,
    reconnectMaxMs: 1000,
  } as unknown as AppConfigService;
}

function waitFor(pred: () => boolean, timeoutMs = 6000, stepMs = 50): Promise<void> {
  return new Promise((resolve, reject) => {
    const start = Date.now();
    const tick = () => {
      if (pred()) return resolve();
      if (Date.now() - start > timeoutMs) return reject(new Error('waitFor timeout'));
      setTimeout(tick, stepMs);
    };
    tick();
  });
}

const maybe = controlServerAvailable() ? describe : describe.skip;

maybe('ControlPlaneClient ↔ real control-server', () => {
  let harness: HarnessHandle;
  let client: ControlPlaneClient;

  beforeAll(async () => {
    harness = await startControlServer();
    client = new ControlPlaneClient(fakeConfig(harness));
    client.onModuleInit();
    await waitFor(() => client.ready);
  });

  afterAll(async () => {
    client?.onModuleDestroy();
    await harness?.stop();
  });

  it('handshakes and reports server info (HMAC verified end-to-end)', () => {
    expect(client.ready).toBe(true);
    expect(client.server?.protocolVersion).toBe('1.0.0');
    expect(client.server?.profile).toBe(harness.profile);
    expect(typeof client.server?.serverPid).toBe('number');
  });

  it('calls health.probe (RPC round-trip)', async () => {
    const probe = await client.request<{ status: string; pid: number }>('health.probe');
    expect(probe.status).toBe('ok');
    expect(typeof probe.pid).toBe('number');
  });

  it('calls capabilities.list and sees read methods', async () => {
    const caps = await client.request<{ methods: string[]; protocolVersion: string }>(
      'capabilities.list',
    );
    expect(caps.protocolVersion).toBe('1.0.0');
    expect(caps.methods).toContain('run.list');
    expect(caps.methods).toContain('health.probe');
  });

  it('is rejected by the server when the HMAC secret is wrong (AUTH_FAILED)', async () => {
    // A bad secret makes the server reject our `hello` frame -> never ready.
    const badConfig = { ...fakeConfig(harness), ipcSecret: 'wrong-secret' } as AppConfigService;
    const bad = new ControlPlaneClient(badConfig);
    bad.onModuleInit();
    await expect(waitFor(() => bad.ready, 1500)).rejects.toThrow();
    expect(bad.ready).toBe(false);
    bad.onModuleDestroy();
  });

  it('receives an event appended to events.ndjson (replay cursor)', async () => {
    const received: ControlEvent[] = [];
    client.on('event', (e: ControlEvent) => received.push(e));

    const evt = {
      id: '11111111-1111-4111-8111-111111111111',
      ts: Date.now(),
      type: 'run.started',
      corr: { runId: 'feature-test-evt', workspaceId: null, conversationId: null },
      payload: { runId: 'feature-test-evt', pipeline: 'feature', name: 'evt-test' },
    };
    fs.appendFileSync(harness.eventsLog, JSON.stringify(evt) + '\n');

    await waitFor(() => received.some((e) => e.id === evt.id));
    const got = received.find((e) => e.id === evt.id)!;
    expect(got.type).toBe('run.started');
    expect(got.corr?.runId).toBe('feature-test-evt');
  });
});
