import { spawn, ChildProcess } from 'node:child_process';
import * as fs from 'node:fs';
import * as os from 'node:os';
import * as path from 'node:path';

const SERVER = path.resolve(
  __dirname,
  '..',
  '..',
  '.claude',
  'coordinator',
  'control-server.js',
);

export interface HarnessHandle {
  proc: ChildProcess;
  profileDir: string;
  profile: string;
  tcpPort: number;
  secret: string;
  eventsLog: string;
  stop: () => Promise<void>;
}

/** Returns true if the real control-server.js is present (skip tests otherwise). */
export function controlServerAvailable(): boolean {
  return fs.existsSync(SERVER);
}

let portSeq = 41000 + Math.floor(Math.random() * 2000);

/**
 * Spawns the REAL ada-core control-server over TCP loopback in an isolated temp
 * profile dir, with a known HMAC secret. Resolves once it is listening.
 */
export async function startControlServer(): Promise<HarnessHandle> {
  const profileDir = fs.mkdtempSync(path.join(os.tmpdir(), 'ada-cp-'));
  const profile = path.basename(profileDir).replace(/^\./, '');
  const tcpPort = portSeq++;
  const secret = 'test-secret-' + Math.random().toString(36).slice(2);
  const eventsLog = path.join(profileDir, 'events.ndjson');

  const proc = spawn(process.execPath, [SERVER, 'start'], {
    env: {
      ...process.env,
      CLAUDE_CONFIG_DIR: profileDir,
      ADA_CONTROL_TCP: String(tcpPort),
      ADA_IPC_HMAC_SECRET: secret,
      ADA_EVENTS_LOG: eventsLog,
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });

  await new Promise<void>((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('control-server start timeout')), 8000);
    let out = '';
    proc.stdout?.on('data', (d) => {
      out += String(d);
      if (out.includes('"started":true')) {
        clearTimeout(timer);
        resolve();
      }
    });
    proc.once('exit', (code) => {
      clearTimeout(timer);
      reject(new Error(`control-server exited early (code ${code})`));
    });
  });

  const stop = async (): Promise<void> => {
    if (proc.exitCode !== null) return;
    await new Promise<void>((resolve) => {
      proc.once('exit', () => resolve());
      proc.kill('SIGTERM');
      setTimeout(() => {
        if (proc.exitCode === null) proc.kill('SIGKILL');
        resolve();
      }, 3000);
    });
  };

  return { proc, profileDir, profile, tcpPort, secret, eventsLog, stop };
}
