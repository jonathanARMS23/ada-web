import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import type { NestFastifyApplication } from '@nestjs/platform-fastify';
import {
  startControlServer,
  controlServerAvailable,
  HarnessHandle,
} from '../control-server.harness.js';

/**
 * e2e: boots the NestJS app pointed at a real control-server (TCP, no DB =
 * degraded mode) and exercises read-only endpoints via Fastify inject.
 *  - GET /api/health is public (no JWT) and reports control plane + db:down.
 *  - GET /api/capabilities requires JWT (401 without) and relays the manifest.
 */
const maybe = controlServerAvailable() ? describe : describe.skip;

maybe('read-only endpoints e2e', () => {
  let harness: HarnessHandle;
  let app: NestFastifyApplication;

  beforeAll(async () => {
    harness = await startControlServer();

    process.env.NODE_ENV = 'test';
    process.env.ADA_ACTIVE_PROFILE = harness.profile;
    process.env.CLAUDE_CONFIG_DIR = harness.profileDir;
    process.env.ADA_CONTROL_TCP = String(harness.tcpPort);
    process.env.ADA_IPC_HMAC_SECRET = harness.secret;
    process.env.ADA_EVENTS_LOG = harness.eventsLog;
    process.env.JWT_SECRET = 'e2e-test-secret-abcdefgh';
    process.env.ADA_RECONNECT_MIN_MS = '200';
    // Hermetic: force the degraded/auth-on config regardless of an ambient .env.
    // SET reliably overrides the inherited env; `delete` does not (the validated
    // config retains the inherited DATABASE_URL), so pin an empty value instead.
    process.env.DATABASE_URL = ''; // force degraded DB mode (status 'disabled' -> db:down)
    process.env.AUTH_DISABLED = 'false'; // never inherit an ambient auth bypass

    const { buildApp } = await import('../../src/main.js');
    app = await buildApp();
    await app.init();
    await app.getHttpAdapter().getInstance().ready();

    // Give the control plane client a moment to handshake.
    await new Promise((r) => setTimeout(r, 1000));
  });

  afterAll(async () => {
    await app?.close();
    await harness?.stop();
  });

  it('GET /api/health is public and reports control plane + db:down (degraded)', async () => {
    const res = await app.inject({ method: 'GET', url: '/api/health' });
    expect(res.statusCode).toBe(200);
    const body = res.json();
    expect(body.controlPlane.reachable).toBe(true);
    expect(body.controlPlane.protocolVersion).toBe('1.0.0');
    expect(body.db).toBe('down'); // no DATABASE_URL -> disabled, reported as down
    // P1-2 — memory health surfaced (informative). Ollama is typically down in CI;
    // assert the SHAPE, not the value.
    expect(body.memory).toBeDefined();
    expect(['up', 'down']).toContain(body.memory.ollama);
    expect(typeof body.memory.degraded).toBe('boolean');
  });

  it('GET /api/capabilities without JWT -> 401', async () => {
    const res = await app.inject({ method: 'GET', url: '/api/capabilities' });
    expect(res.statusCode).toBe(401);
  });

  it('GET /api/capabilities with valid JWT -> live manifest', async () => {
    const token = await mintToken('e2e-test-secret-abcdefgh');
    const res = await app.inject({
      method: 'GET',
      url: '/api/capabilities',
      headers: { authorization: `Bearer ${token}` },
    });
    expect(res.statusCode).toBe(200);
    const body = res.json();
    expect(body.protocolVersion).toBe('1.0.0');
    expect(Array.isArray(body.methods)).toBe(true);
    expect(body.methods).toContain('capabilities.list');
  });
});

async function mintToken(secret: string): Promise<string> {
  const { SignJWT } = await import('jose');
  const key = new TextEncoder().encode(secret);
  return new SignJWT({ sub: 'e2e' })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime('5m')
    .sign(key);
}
