import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import pg from 'pg';
import { drizzle } from 'drizzle-orm/node-postgres';
import { eq } from 'drizzle-orm';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { schema, events, runs } from '../src/persistence/schema.js';
import { EventIngestionService } from '../src/persistence/event-ingestion.service.js';
import type { DatabaseService } from '../src/persistence/database.service.js';
import type { ControlPlaneClient } from '../src/control-plane/control-plane.client.js';
import type { ControlEvent } from '../src/control-plane/control-plane.types.js';

/**
 * Postgres ingestion test. Skips cleanly when DATABASE_URL is absent so the
 * suite stays green in environments without a database.
 *  - upsert into `events` is idempotent (ON CONFLICT (id) DO NOTHING)
 *  - lifecycle events project into `runs`
 */
const { Pool } = pg;
const DB_URL = process.env.DATABASE_URL;
const maybe = DB_URL ? describe : describe.skip;

maybe('EventIngestionService → Postgres', () => {
  let pool: pg.Pool;
  let db: ReturnType<typeof drizzle<typeof schema>>;
  let service: EventIngestionService;

  beforeAll(async () => {
    pool = new Pool({ connectionString: DB_URL });
    // Apply migrations (idempotent).
    const dir = path.resolve(__dirname, '..', 'src', 'persistence', 'migrations');
    for (const f of fs.readdirSync(dir).filter((x) => x.endsWith('.sql')).sort()) {
      await pool.query(fs.readFileSync(path.join(dir, f), 'utf8'));
    }
    db = drizzle(pool, { schema });

    const fakeDb = { db, isUp: true, status: 'up' } as unknown as DatabaseService;
    const fakeClient = { on: () => undefined } as unknown as ControlPlaneClient;
    service = new EventIngestionService(fakeClient, fakeDb);
  });

  afterAll(async () => {
    await pool?.end();
  });

  it('ingests an event idempotently and projects a run', async () => {
    const id = '22222222-2222-4222-8222-' + Date.now().toString().padStart(12, '0').slice(-12);
    const coreRunId = 'feature-ingest-' + Date.now();
    const evt: ControlEvent = {
      id,
      ts: Date.now(),
      type: 'run.started',
      corr: { runId: coreRunId },
      payload: { runId: coreRunId, pipeline: 'feature', name: 'ingest-test' },
    };

    expect(await service.ingest(evt)).toBe(true);
    // Second ingest of the same id is a no-op (no throw, no duplicate).
    expect(await service.ingest(evt)).toBe(true);

    const rows = await db.select().from(events).where(eq(events.id, id));
    expect(rows.length).toBe(1);
    expect(rows[0].type).toBe('run.started');
    expect(rows[0].coreRunId).toBe(coreRunId);

    const runRows = await db.select().from(runs).where(eq(runs.coreRunId, coreRunId));
    expect(runRows.length).toBe(1);
    expect(runRows[0].pipeline).toBe('feature');
    expect(runRows[0].status).toBe('running');
  });
});
