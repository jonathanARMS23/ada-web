import { describe, it, expect, vi } from 'vitest';
import { MockInteractiveSessionFactory } from '../src/sessions/mock-interactive-session.js';
import type { SessionEvent } from '../src/sessions/session.types.js';

describe('InteractiveSession (mock) — capture session_id + --resume', () => {
  it('émet un session_id sur le frame system/init', async () => {
    const events: SessionEvent[] = [];
    const factory = new MockInteractiveSessionFactory();
    const session = factory.start({
      sessionId: 'internal-1',
      profileDir: '/tmp/pro',
      permissionMode: 'default',
      resumeClaudeSessionId: null,
      permissionCtx: { profile: 'pro', workspaceId: null, conversationId: null, coreRunId: null },
      onEvent: (e) => events.push(e),
    });
    await vi.waitFor(() => expect(events.some((e) => e.kind === 'session_id')).toBe(true));
    const idEvt = events.find((e) => e.kind === 'session_id');
    expect(idEvt && 'claudeSessionId' in idEvt && idEvt.claudeSessionId).toBeTruthy();
    expect(session.claudeSessionId).toBeTruthy();
  });

  it('--resume réutilise le claude session_id fourni', async () => {
    const events: SessionEvent[] = [];
    const factory = new MockInteractiveSessionFactory();
    const session = factory.start({
      sessionId: 'internal-2',
      profileDir: '/tmp/pro',
      permissionMode: 'default',
      resumeClaudeSessionId: 'claude-RESUMED-xyz',
      permissionCtx: { profile: 'pro', workspaceId: null, conversationId: null, coreRunId: null },
      onEvent: (e) => events.push(e),
    });
    await vi.waitFor(() => expect(session.claudeSessionId).toBe('claude-RESUMED-xyz'));
    const idEvt = events.find((e) => e.kind === 'session_id');
    expect(idEvt && 'claudeSessionId' in idEvt && idEvt.claudeSessionId).toBe('claude-RESUMED-xyz');
  });

  it('send() produit un nouveau tour (assistant + turn_complete)', async () => {
    const events: SessionEvent[] = [];
    const factory = new MockInteractiveSessionFactory();
    const session = factory.start({
      sessionId: 'internal-3',
      profileDir: '/tmp/pro',
      permissionMode: 'default',
      resumeClaudeSessionId: null,
      permissionCtx: { profile: 'pro', workspaceId: null, conversationId: null, coreRunId: null },
      onEvent: (e) => events.push(e),
    });
    await vi.waitFor(() => expect(events.some((e) => e.kind === 'turn_complete')).toBe(true));
    const before = events.filter((e) => e.kind === 'turn_complete').length;
    await session.send('refais-le');
    await vi.waitFor(() => expect(events.filter((e) => e.kind === 'turn_complete').length).toBe(before + 1));
    expect(events.some((e) => e.kind === 'output' && String((e as { chunk?: string }).chunk).includes('refais-le'))).toBe(true);
  });
});
