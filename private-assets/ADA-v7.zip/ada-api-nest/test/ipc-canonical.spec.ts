import { describe, it, expect } from 'vitest';
import { createRequire } from 'node:module';
import * as path from 'node:path';
import { canonicalStringify, sign, verify, attachSignature } from '../src/control-plane/ipc-canonical.js';

/**
 * Cross-checks the TS port against the REAL coordinator/ipc-canonical.js so the
 * client's signatures are byte-identical to the Control Server's verifier.
 */
const require = createRequire(__filename);
const REAL = path.resolve(__dirname, '..', '..', '.claude', 'coordinator', 'ipc-canonical.js');

describe('ipc-canonical TS port parity with ada-core', () => {
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  const real = require(REAL) as {
    canonicalStringify: (v: unknown) => string;
    sign: (p: object, s: string) => string;
    verify: (f: object, s: string) => boolean;
  };

  const secret = 'shared-secret-xyz';
  const samples: unknown[] = [
    { jsonrpc: '2.0', id: 'abc', method: 'hello', params: { protocolVersion: '1.0.0', profile: 'pro' } },
    { z: 1, a: 2, nested: { y: [3, 2, 1], x: 'é\n"' } },
    { jsonrpc: '2.0', id: '1', result: { topology: 'parallel_mesh', ready: [] } },
    { n: 1.5, b: true, nul: null, undef: undefined },
  ];

  it('produces identical canonical strings', () => {
    for (const s of samples) {
      expect(canonicalStringify(s)).toBe(real.canonicalStringify(s));
    }
  });

  it('produces identical signatures', () => {
    for (const s of samples) {
      expect(sign(s as Record<string, unknown>, secret)).toBe(real.sign(s as object, secret));
    }
  });

  it('TS-signed frames verify under the real verifier and vice-versa', () => {
    const frame = { jsonrpc: '2.0', id: 'x', method: 'health.probe', params: {} };
    const tsSigned = attachSignature(frame, secret);
    expect(real.verify(tsSigned, secret)).toBe(true);
    expect(verify(tsSigned, secret)).toBe(true);

    const realSigned = { ...frame, _sig: real.sign(frame, secret) };
    expect(verify(realSigned, secret)).toBe(true);
  });
});
