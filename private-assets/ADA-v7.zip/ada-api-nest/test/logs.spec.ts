import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import pg from 'pg';
import { drizzle } from 'drizzle-orm/node-postgres';
import { sql } from 'drizzle-orm';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { schema, logs } from '../src/persistence/schema.js';
import { LogIngestionService } from '../src/logs/log-ingestion.service.js';
import { LogsService } from '../src/logs/logs.service.js';
import type { DatabaseService } from '../src/persistence/database.service.js';
import type { ControlPlaneClient } from '../src/control-plane/control-plane.client.js';
import type { AppConfigService } from '../src/config/app-config.service.js';
import type { ControlEvent } from '../src/control-plane/control-plane.types.js';

const { Pool } = pg;
const DB_URL = process.env.DATABASE_URL;
const maybe = DB_URL ? describe : describe.skip;

maybe('Logs: ingestion + query + rétention → Postgres', () => {
  let pool: pg.Pool;
  let db: ReturnType<typeof drizzle<typeof schema>>;
  let ingestion: LogIngestionService;
  let query: LogsService;
  const runId = 'log-run-' + Date.now();

  beforeAll(async () => {
    pool = new Pool({ connectionString: DB_URL });
    const dir = path.resolve(__dirname, '..', 'src', 'persistence', 'migrations');
    for (const f of fs.readdirSync(dir).filter((x) => x.endsWith('.sql')).sort()) {
      await pool.query(fs.readFileSync(path.join(dir, f), 'utf8'));
    }
    db = drizzle(pool, { schema });
    const fakeDb = { db, isUp: true, status: 'up' } as unknown as DatabaseService;
    const fakeClient = { on: () => undefined, request: async () => ({}) } as unknown as ControlPlaneClient;
    const fakeConfig = { eventsLogPath: path.join('/tmp', 'nonexistent-events-' + Date.now() + '.ndjson') } as unknown as AppConfigService;
    ingestion = new LogIngestionService(fakeConfig, fakeDb, fakeClient);
    query = new LogsService(fakeDb, fakeClient);
  });

  afterAll(async () => {
    await pool?.end();
  });

  it('ingère un event du bus → ligne en base (idempotent)', async () => {
    const evt: ControlEvent = {
      id: 'aaaaaaaa-aaaa-4aaa-8aaa-' + Date.now().toString().padStart(12, '0').slice(-12),
      ts: Date.now(),
      type: 'run.phase.failed',
      corr: { runId, workspaceId: null },
      payload: { phaseId: 'apply', agent: 'db', error: 'boom' },
    };
    expect(await ingestion.ingestEvent(evt)).toBe(true);
    // Second ingest of same id is a no-op (dedup_key UNIQUE).
    expect(await ingestion.ingestEvent(evt)).toBe(true);

    const rows = await db.select().from(logs).where(sql`${logs.dedupKey} = ${'event:' + evt.id}`);
    expect(rows.length).toBe(1);
    expect(rows[0].level).toBe('error'); // *.failed -> error
    expect(rows[0].source).toBe('orchestration');
    expect(rows[0].coreRunId).toBe(runId);
  });

  it('GET /logs filtré (level/source/run) + pagination', async () => {
    // Per-run unique source so re-runs don't pollute exact-count assertions.
    const base = Date.now();
    const src = `test-seed-${base}`;
    for (let i = 0; i < 5; i++) {
      await ingestion.write({
        level: i % 2 === 0 ? 'info' : 'warn',
        source: src,
        message: `seed message ${i} alpha`,
        coreRunId: runId,
        payload: null,
        ts: new Date(base + i * 1000),
        dedupKey: `${src}:${i}`,
      });
    }

    // Filter by source + level (2 warns among the 5).
    const warns = await query.query({ source: src, level: 'warn' });
    expect(warns.source).toBe('postgres');
    expect(Array.isArray(warns.items)).toBe(true);
    expect((warns.items as unknown[]).length).toBe(2);

    // Filter by source + text search.
    const byText = await query.query({ q: 'alpha', source: src });
    expect((byText.items as unknown[]).length).toBe(5);

    // Pagination: page size 2 over the 5 seed rows.
    const p1 = await query.query({ source: src, limit: 2 });
    expect((p1.items as unknown[]).length).toBe(2);
    expect(p1.hasMore).toBe(true);
    expect(p1.nextCursor).toBeTruthy();
    const p2 = await query.query({ source: src, limit: 2, cursor: p1.nextCursor! });
    expect((p2.items as unknown[]).length).toBe(2);
  });

  it('rétention: supprime les logs au-delà de N jours', async () => {
    const src = `retention-test-${Date.now()}`;
    // Insert an old log (40 days ago) + a fresh one, both under a unique source.
    const old = new Date(Date.now() - 40 * 24 * 60 * 60 * 1000);
    await ingestion.write({
      level: 'info',
      source: src,
      message: 'vieux log',
      payload: null,
      ts: old,
      dedupKey: `${src}:old`,
    });
    await ingestion.write({
      level: 'info',
      source: src,
      message: 'log récent',
      payload: null,
      ts: new Date(),
      dedupKey: `${src}:new`,
    });

    const deleted = await query.purgeOlderThan(30);
    expect(deleted).toBeGreaterThanOrEqual(1);

    const remaining = await query.query({ source: src });
    // Only the fresh row survives the 30-day purge (scoped to this run's source).
    expect((remaining.items as unknown[]).length).toBe(1);
  });
});

/** Degraded mode: ingestion + query never throw without a DB. */
describe('Logs — mode dégradé (DB down)', () => {
  it('ingestEvent = no-op, query relaie le tail live', async () => {
    const fakeDb = { db: null, isUp: false, status: 'down' } as unknown as DatabaseService;
    const request = (await import('vitest')).vi.fn(async () => ({ lines: [] }));
    const fakeClient = { on: () => undefined, request } as unknown as ControlPlaneClient;
    const fakeConfig = { eventsLogPath: '/tmp/none.ndjson' } as unknown as AppConfigService;
    const ingestion = new LogIngestionService(fakeConfig, fakeDb, fakeClient);
    const evt: ControlEvent = { id: 'x', ts: Date.now(), type: 'run.started', payload: {} };
    expect(await ingestion.ingestEvent(evt)).toBe(false);

    const query = new LogsService(fakeDb, fakeClient);
    const res = await query.query({ source: 'events', limit: 10 });
    expect(res.source).toBe('live');
    expect(request).toHaveBeenCalledWith('logs.tail', { source: 'events', lines: 10 });
  });
});
