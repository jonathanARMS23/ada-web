import { describe, it, expect, vi } from 'vitest';
import { BadRequestException, NotFoundException } from '@nestjs/common';
import { MemoryController } from '../src/memory/memory.controller.js';
import { MemoryService } from '../src/memory/memory.service.js';
import type { ControlPlaneClient } from '../src/control-plane/control-plane.client.js';

/**
 * P8 — MemoryController/MemoryService relay the rich-memory RPC surface to the
 * Control Server. We stub ControlPlaneClient.request and assert each route
 * forwards the right RPC method + params (read-only), mirroring ada.controller.spec.
 */
function makeController(requestImpl?: (m: string, p?: Record<string, unknown>) => Promise<unknown>) {
  const request = vi.fn(requestImpl ?? (async () => ({ ok: true })));
  const client = { request } as unknown as ControlPlaneClient;
  const service = new MemoryService(client);
  const controller = new MemoryController(service);
  return { controller, request };
}

describe('MemoryController (P8 — mémoire riche)', () => {
  it('GET /memory/graph relaie memory.graph (sans options → params vide)', async () => {
    const { controller, request } = makeController(async () => ({ nodes: [], edges: [], stats: {} }));
    await controller.graph({});
    expect(request).toHaveBeenCalledWith('memory.graph', {});
  });

  it('GET /memory/graph relaie pagerank + top', async () => {
    const { controller, request } = makeController(async () => ({ nodes: [], edges: [], stats: {}, pagerank: true }));
    const res = (await controller.graph({ pagerank: true, top: 50 })) as { pagerank: boolean };
    expect(request).toHaveBeenCalledWith('memory.graph', { pagerank: true, top: 50 });
    expect(res.pagerank).toBe(true);
  });

  it('GET /memory/wiki relaie obsidian.wiki', async () => {
    const { controller, request } = makeController(async () => ({ topics: [], totalSessions: 0, empty: true }));
    const res = (await controller.wiki()) as { empty: boolean };
    expect(request).toHaveBeenCalledWith('obsidian.wiki');
    expect(res.empty).toBe(true);
  });

  it('GET /memory/notes/:file relaie obsidian.note avec le slug', async () => {
    const { controller, request } = makeController(async () => ({ file: 'session-001.md', dir: 'sessions', content: '# x' }));
    const res = (await controller.note({ file: 'session-001.md' })) as { file: string };
    expect(request).toHaveBeenCalledWith('obsidian.note', { file: 'session-001.md' });
    expect(res.file).toBe('session-001.md');
  });

  it('GET /memory/notes/:file mappe l\'erreur 1001 (note absente) en 404', async () => {
    const { controller } = makeController(async () => {
      const e = new Error('Note introuvable') as Error & { code?: number };
      e.code = 1001;
      throw e;
    });
    await expect(controller.note({ file: 'ghost.md' })).rejects.toBeInstanceOf(NotFoundException);
  });

  it('GET /memory/notes/:file mappe INVALID_PARAMS (-32602) en 400', async () => {
    const { controller } = makeController(async () => {
      const e = new Error('Chemin hors vault') as Error & { code?: number };
      e.code = -32602;
      throw e;
    });
    await expect(controller.note({ file: 'evil.md' })).rejects.toBeInstanceOf(BadRequestException);
  });

  it('propage les autres erreurs RPC (ex. control plane indisponible)', async () => {
    const { controller } = makeController(async () => {
      throw new Error('CONTROL_PLANE_UNAVAILABLE');
    });
    await expect(controller.wiki()).rejects.toThrow('CONTROL_PLANE_UNAVAILABLE');
  });
});

/**
 * Anti path-traversal: the NoteSlugParamDto regex must reject any name that
 * could escape the vault. Validated here at the DTO level (defense in depth;
 * the Control Server re-validates with the same allowlist).
 */
describe('NoteSlugParamDto — anti path-traversal', () => {
  it('accepte un slug .md valide et rejette les chemins dangereux', async () => {
    const { validate } = await import('class-validator');
    const { plainToInstance } = await import('class-transformer');
    const { NoteSlugParamDto } = await import('../src/memory/dto/memory.dto.js');

    const ok = plainToInstance(NoteSlugParamDto, { file: 'project_ada-interface.md' });
    expect(await validate(ok)).toHaveLength(0);

    for (const bad of ['../../etc/passwd', 'sub/dir.md', '/abs.md', 'note.txt', '..md', 'a/../b.md', 'note.md/..']) {
      const dto = plainToInstance(NoteSlugParamDto, { file: bad });
      const errors = await validate(dto);
      expect(errors.length, `attendu rejet pour "${bad}"`).toBeGreaterThan(0);
    }
  });
});
