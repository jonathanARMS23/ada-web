import { describe, it, expect, vi } from 'vitest';
import { OrchestrationLoop } from '../src/orchestration/orchestration-loop.service.js';
import { OrchestrationEvents } from '../src/orchestration/orchestration-events.js';
import type { ControlPlaneClient } from '../src/control-plane/control-plane.client.js';
import type { AppConfigService } from '../src/config/app-config.service.js';
import type { AgentPromptService } from '../src/orchestration/agent-prompt.service.js';
import type { JobQueueService, OrchestrateJob } from '../src/orchestration/job-queue.service.js';
import type {
  PhaseExecutor,
  PhaseResult,
  PhaseRunContext,
} from '../src/orchestration/phase-executor.js';
import type { ControlEvent, ReadyPhase, RunNextResult } from '../src/control-plane/control-plane.types.js';

function phase(id: string): ReadyPhase {
  return { phaseId: id, agent: 'tester', tier: 1, model: 'm', required: true };
}

const job: OrchestrateJob = {
  runId: 'run-1',
  instruction: 'do it',
  pipeline: 'feature',
  feature: 'feat',
  workspaceId: 'ws-1',
  conversationId: null,
};

function buildLoop(opts: {
  nextSequence: RunNextResult[];
  executor: PhaseExecutor;
  concurrency?: number;
}) {
  const calls: string[] = [];
  let nextIdx = 0;
  const client = {
    runNext: vi.fn(async () => opts.nextSequence[nextIdx++] ?? { runId: 'run-1', topology: 'sequential', ready: [], parallelizable: [] }),
    runStart: vi.fn(async (_r: string, phaseId: string) => {
      calls.push(`start:${phaseId}`);
      return { ok: true };
    }),
    runDone: vi.fn(async (p: { phaseId: string }) => {
      calls.push(`done:${p.phaseId}`);
      return { ok: true };
    }),
    runFail: vi.fn(async (p: { phaseId: string }) => {
      calls.push(`fail:${p.phaseId}`);
      return { ok: true };
    }),
  } as unknown as ControlPlaneClient;

  const config = {
    phaseConcurrency: opts.concurrency ?? 3,
    profileDir: '/tmp/x',
  } as unknown as AppConfigService;
  const events = new OrchestrationEvents();
  const prompts = {
    buildPhasePrompt: () => 'prompt',
    resolveAgentPrompt: () => null,
  } as unknown as AgentPromptService;
  const queue = { registerHandler: vi.fn() } as unknown as JobQueueService;

  const loop = new OrchestrationLoop(client, config, events, prompts, queue, opts.executor);
  return { loop, calls, client, events };
}

describe('OrchestrationLoop', () => {
  it('exécute les phases séquentielles dans l’ordre et appelle run.done via RPC', async () => {
    const executor: PhaseExecutor = {
      kind: 'mock',
      execute: async (): Promise<PhaseResult> => ({ ok: true, summary: 's', usage: { tokens: 10, cost: 0.1 } }),
    };
    const { loop, calls, client } = buildLoop({
      executor,
      nextSequence: [
        { runId: 'run-1', topology: 'sequential', ready: [phase('a')], parallelizable: ['a'] },
        { runId: 'run-1', topology: 'sequential', ready: [phase('b')], parallelizable: ['b'] },
      ],
    });
    await loop.run(job);
    expect(calls).toEqual(['start:a', 'done:a', 'start:b', 'done:b']);
    expect(client.runDone).toHaveBeenCalledTimes(2);
    expect(client.runFail).not.toHaveBeenCalled();
  });

  it('parallel_mesh : 2 phases prêtes exécutées en concurrence (bornée)', async () => {
    let active = 0;
    let maxActive = 0;
    const executor: PhaseExecutor = {
      kind: 'mock',
      execute: async (_ctx: PhaseRunContext): Promise<PhaseResult> => {
        active++;
        maxActive = Math.max(maxActive, active);
        await new Promise((r) => setTimeout(r, 30));
        active--;
        return { ok: true, summary: 's', usage: { tokens: 1, cost: 0 } };
      },
    };
    const { loop, client } = buildLoop({
      concurrency: 3,
      executor,
      nextSequence: [
        { runId: 'run-1', topology: 'parallel_mesh', ready: [phase('scan'), phase('deps')], parallelizable: ['scan', 'deps'] },
      ],
    });
    await loop.run(job);
    expect(maxActive).toBe(2); // both ran concurrently
    expect(client.runStart).toHaveBeenCalledTimes(2);
    expect(client.runDone).toHaveBeenCalledTimes(2);
  });

  it('respecte la borne de concurrence (3 phases, limite 2 -> max 2 simultanées)', async () => {
    let active = 0;
    let maxActive = 0;
    const executor: PhaseExecutor = {
      kind: 'mock',
      execute: async (): Promise<PhaseResult> => {
        active++;
        maxActive = Math.max(maxActive, active);
        await new Promise((r) => setTimeout(r, 20));
        active--;
        return { ok: true, summary: 's', usage: { tokens: 1, cost: 0 } };
      },
    };
    const { loop } = buildLoop({
      concurrency: 2,
      executor,
      nextSequence: [
        {
          runId: 'run-1',
          topology: 'parallel_mesh',
          ready: [phase('p1'), phase('p2'), phase('p3')],
          parallelizable: ['p1', 'p2', 'p3'],
        },
      ],
    });
    await loop.run(job);
    expect(maxActive).toBe(2);
  });

  it('une phase en échec -> run.fail RPC + event run.phase.failed', async () => {
    const seen: ControlEvent[] = [];
    const executor: PhaseExecutor = {
      kind: 'mock',
      execute: async (): Promise<PhaseResult> => ({
        ok: false,
        summary: '',
        usage: { tokens: 0, cost: 0 },
        error: 'boom',
        retryable: true,
      }),
    };
    const { loop, client, events } = buildLoop({
      executor,
      nextSequence: [{ runId: 'run-1', topology: 'sequential', ready: [phase('a')], parallelizable: ['a'] }],
    });
    events.onEvent((e) => seen.push(e));
    await loop.run(job);
    expect(client.runFail).toHaveBeenCalledTimes(1);
    expect(seen.some((e) => e.type === 'run.phase.failed')).toBe(true);
  });
});
