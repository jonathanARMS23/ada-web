import { describe, it, expect, vi } from 'vitest';
import { PermissionBrokerService } from '../src/sessions/permission-broker.service.js';
import { PermissionPolicyService } from '../src/sessions/permission-policy.service.js';
import { SessionManager } from '../src/sessions/session-manager.service.js';
import { MockInteractiveSessionFactory } from '../src/sessions/mock-interactive-session.js';
import { OrchestrationEvents } from '../src/orchestration/orchestration-events.js';
import { McpBrokerController } from '../src/sessions/mcp-broker.controller.js';
import type { DatabaseService } from '../src/persistence/database.service.js';
import type { AppConfigService } from '../src/config/app-config.service.js';
import type { ControlEvent } from '../src/control-plane/control-plane.types.js';

function dbDown(): DatabaseService {
  return { db: null, isUp: false } as unknown as DatabaseService;
}
function config(timeoutMs = 5000): AppConfigService {
  return {
    profile: 'pro',
    profileDir: '/tmp/pro',
    permissionTimeoutMs: timeoutMs,
    permissionPromptTool: 'mcp__ada__approve',
    mcpBrokerConfigPath: null,
  } as unknown as AppConfigService;
}

function build(timeoutMs = 5000) {
  const events = new OrchestrationEvents();
  const seen: ControlEvent[] = [];
  events.onEvent((e) => seen.push(e));
  const cfg = config(timeoutMs);
  const policy = new PermissionPolicyService(dbDown(), events, cfg);
  const sessions = new SessionManager(dbDown(), events, cfg, new MockInteractiveSessionFactory());
  const broker = new PermissionBrokerService(policy, sessions, cfg);
  return { broker, policy, sessions, events, seen };
}

describe('Permission Broker — flux MCP approve (P3)', () => {
  it('approve(Read) -> allow immédiat, aucun event UI', async () => {
    const { broker, seen } = build();
    const res = await broker.approve({ tool_name: 'Read', input: { path: 'a.ts' } });
    expect(res.behavior).toBe('allow');
    expect(seen.some((e) => e.type === 'task.permission_request')).toBe(false);
  });

  it('approve(Bash) -> émet request, résolu par task.permission_response allow', async () => {
    const { broker, policy, seen } = build();
    const pending = broker.approve({ tool_name: 'Bash', input: { command: 'rm -rf x' }, session_id: 'sess-x' });

    let requestId = '';
    await vi.waitFor(() => {
      const req = seen.find((e) => e.type === 'task.permission_request');
      expect(req).toBeDefined();
      requestId = String(req!.payload?.requestId);
    });
    // Simulate the UI responding (what SessionInboundRouter would call).
    expect(policy.resolvePermission(requestId, 'allow')).toBe(true);

    const res = await pending;
    expect(res.behavior).toBe('allow');
  });

  it('via le contrôleur MCP : tools/call approve renvoie la décision JSON', async () => {
    const { broker, policy, seen } = build();
    const controller = new McpBrokerController(broker);

    // initialize + tools/list sanity.
    const init = (await controller.handle({ jsonrpc: '2.0', id: 1, method: 'initialize' })) as { result: unknown };
    expect(init.result).toBeTruthy();
    const list = (await controller.handle({ jsonrpc: '2.0', id: 2, method: 'tools/list' })) as {
      result: { tools: Array<{ name: string }> };
    };
    expect(list.result.tools[0].name).toBe('approve');

    // tools/call approve(Bash) -> pending until we respond.
    const callP = controller.handle({
      jsonrpc: '2.0',
      id: 3,
      method: 'tools/call',
      params: { name: 'approve', arguments: { tool_name: 'Bash', input: { command: 'ls' }, session_id: 's' } },
    }) as Promise<{ result: { content: Array<{ text: string }> } }>;

    let requestId = '';
    await vi.waitFor(() => {
      const req = seen.find((e) => e.type === 'task.permission_request');
      expect(req).toBeDefined();
      requestId = String(req!.payload?.requestId);
    });
    policy.resolvePermission(requestId, 'deny');

    const call = await callP;
    const decision = JSON.parse(call.result.content[0].text) as { behavior: string };
    expect(decision.behavior).toBe('deny');
  });

  it('timeout -> deny', async () => {
    const { broker } = build(20);
    const res = await broker.approve({ tool_name: 'Write', input: {}, session_id: 's' });
    expect(res.behavior).toBe('deny');
  });
});
