import { describe, it, expect, vi } from 'vitest';
import { PermissionPolicyService } from '../src/sessions/permission-policy.service.js';
import { OrchestrationEvents } from '../src/orchestration/orchestration-events.js';
import type { DatabaseService } from '../src/persistence/database.service.js';
import type { AppConfigService } from '../src/config/app-config.service.js';
import type { ControlEvent } from '../src/control-plane/control-plane.types.js';
import type { PermissionRequestContext } from '../src/sessions/permission.types.js';

/** DB stub: degraded (no db) so the service uses its in-memory policy path. */
function dbDown(): DatabaseService {
  return { db: null, isUp: false } as unknown as DatabaseService;
}

function config(timeoutMs = 50): AppConfigService {
  return { permissionTimeoutMs: timeoutMs } as unknown as AppConfigService;
}

function ctx(over: Partial<PermissionRequestContext> = {}): PermissionRequestContext {
  return {
    requestId: PermissionPolicyService.newRequestId(),
    sessionId: 'sess-1',
    coreRunId: null,
    profile: 'pro',
    workspaceId: 'ws-1',
    conversationId: null,
    permissionMode: 'default',
    tool: 'Bash',
    input: { command: 'ls' },
    ...over,
  };
}

describe('PermissionPolicyService (Fork #2)', () => {
  it('Read est auto-approuvé immédiatement, SANS event UI', async () => {
    const events = new OrchestrationEvents();
    const seen: ControlEvent[] = [];
    events.onEvent((e) => seen.push(e));
    const svc = new PermissionPolicyService(dbDown(), events, config());

    const res = await svc.evaluate(ctx({ tool: 'Read', input: { path: 'a.ts' } }));
    expect(res.behavior).toBe('allow');
    expect(seen.some((e) => e.type === 'task.permission_request')).toBe(false);
  });

  it('Grep/Glob/LS/NotebookRead auto-allow', async () => {
    const svc = new PermissionPolicyService(dbDown(), new OrchestrationEvents(), config());
    for (const tool of ['Grep', 'Glob', 'LS', 'NotebookRead']) {
      const res = await svc.evaluate(ctx({ tool }));
      expect(res.behavior, tool).toBe('allow');
    }
  });

  it('Bash => ask : émet task.permission_request et se résout sur la réponse allow', async () => {
    const events = new OrchestrationEvents();
    const requests: ControlEvent[] = [];
    events.onEvent((e) => {
      if (e.type === 'task.permission_request') requests.push(e);
    });
    const svc = new PermissionPolicyService(dbDown(), events, config(5000));

    const c = ctx({ tool: 'Bash' });
    const pending = svc.evaluate(c);

    // The request event must have been emitted with the requestId/tool/input.
    await vi.waitFor(() => expect(requests).toHaveLength(1));
    expect(requests[0].payload?.requestId).toBe(c.requestId);
    expect(requests[0].payload?.tool).toBe('Bash');
    expect(svc.pendingCount).toBe(1);

    // User approves with a modified input.
    const ok = svc.resolvePermission(c.requestId, 'allow', { command: 'ls -la' });
    expect(ok).toBe(true);

    const res = await pending;
    expect(res.behavior).toBe('allow');
    expect(res.updatedInput).toEqual({ command: 'ls -la' });
    expect(svc.pendingCount).toBe(0);
  });

  it('réponse deny => behavior deny', async () => {
    const svc = new PermissionPolicyService(dbDown(), new OrchestrationEvents(), config(5000));
    const c = ctx({ tool: 'Write' });
    const pending = svc.evaluate(c);
    await vi.waitFor(() => expect(svc.pendingCount).toBe(1));
    svc.resolvePermission(c.requestId, 'deny');
    const res = await pending;
    expect(res.behavior).toBe('deny');
  });

  it('timeout sur ask => deny par défaut', async () => {
    const svc = new PermissionPolicyService(dbDown(), new OrchestrationEvents(), config(20));
    const res = await svc.evaluate(ctx({ tool: 'Bash' }));
    expect(res.behavior).toBe('deny');
    expect(res.message).toMatch(/timeout/i);
  });

  it('allow_always persiste une règle allow pour l’outil du profil', async () => {
    const svc = new PermissionPolicyService(dbDown(), new OrchestrationEvents(), config(5000));
    const c = ctx({ tool: 'Bash', profile: 'pro' });
    const pending = svc.evaluate(c);
    await vi.waitFor(() => expect(svc.pendingCount).toBe(1));
    svc.resolvePermission(c.requestId, 'allow_always');
    await pending;

    // Now Bash for profile "pro" resolves to allow with no UI round-trip.
    expect(await svc.resolvePolicy('pro', 'Bash')).toBe('allow');
    const res2 = await svc.evaluate(ctx({ tool: 'Bash', profile: 'pro' }));
    expect(res2.behavior).toBe('allow');
  });

  it('mode bypassPermissions => allow sans flux', async () => {
    const svc = new PermissionPolicyService(dbDown(), new OrchestrationEvents(), config());
    const res = await svc.evaluate(ctx({ tool: 'Bash', permissionMode: 'bypassPermissions' }));
    expect(res.behavior).toBe('allow');
  });

  it('mode plan => deny (aucune mutation)', async () => {
    const svc = new PermissionPolicyService(dbDown(), new OrchestrationEvents(), config());
    const res = await svc.evaluate(ctx({ tool: 'Write', permissionMode: 'plan' }));
    expect(res.behavior).toBe('deny');
  });

  it('mode acceptEdits => Edit/Write/MultiEdit auto-allow', async () => {
    const svc = new PermissionPolicyService(dbDown(), new OrchestrationEvents(), config());
    for (const tool of ['Edit', 'Write', 'MultiEdit']) {
      const res = await svc.evaluate(ctx({ tool, permissionMode: 'acceptEdits' }));
      expect(res.behavior, tool).toBe('allow');
    }
    // Bash still asks even in acceptEdits.
    expect(await svc.resolvePolicy('pro', 'Bash', 'acceptEdits')).toBe('ask');
  });

  it('listPolicy expose défauts + overrides', async () => {
    const svc = new PermissionPolicyService(dbDown(), new OrchestrationEvents(), config());
    await svc.upsertPolicy('pro', 'Bash', 'allow');
    const table = await svc.listPolicy('pro');
    const bash = table.find((t) => t.tool === 'Bash');
    const read = table.find((t) => t.tool === 'Read');
    expect(bash).toEqual({ tool: 'Bash', decision: 'allow', source: 'override' });
    expect(read).toEqual({ tool: 'Read', decision: 'allow', source: 'default' });
  });
});
