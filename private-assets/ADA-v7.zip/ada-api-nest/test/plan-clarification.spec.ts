import { describe, it, expect, vi } from 'vitest';
import { PlanClarificationService } from '../src/sessions/plan-clarification.service.js';
import { OrchestrationEvents } from '../src/orchestration/orchestration-events.js';
import type { DatabaseService } from '../src/persistence/database.service.js';
import type { ControlEvent } from '../src/control-plane/control-plane.types.js';

function dbDown(): DatabaseService {
  return { db: null, isUp: false } as unknown as DatabaseService;
}

describe('PlanClarificationService (P3)', () => {
  it('askPlan émet task.plan et se résout sur approve', async () => {
    const events = new OrchestrationEvents();
    const seen: ControlEvent[] = [];
    events.onEvent((e) => seen.push(e));
    const svc = new PlanClarificationService(dbDown(), events);

    const pending = svc.askPlan({ steps: ['a', 'b'], sessionId: 'sess-1', workspaceId: 'ws-1' });
    let planId = '';
    await vi.waitFor(() => {
      const ev = seen.find((e) => e.type === 'task.plan');
      expect(ev).toBeDefined();
      planId = String(ev!.payload?.planId);
    });
    expect(seen.find((e) => e.type === 'task.plan')?.payload?.steps).toEqual(['a', 'b']);
    expect(svc.resolvePlan(planId, 'approve')).toBe(true);
    const res = await pending;
    expect(res.decision).toBe('approve');
    expect(res.planId).toBe(planId);
  });

  it('askPlan edit retourne le feedback', async () => {
    const events = new OrchestrationEvents();
    const seen: ControlEvent[] = [];
    events.onEvent((e) => seen.push(e));
    const svc = new PlanClarificationService(dbDown(), events);
    const pending = svc.askPlan({ steps: ['x'] });
    let planId = '';
    await vi.waitFor(() => {
      planId = String(seen.find((e) => e.type === 'task.plan')?.payload?.planId);
      expect(planId).not.toBe('undefined');
    });
    svc.resolvePlan(planId, 'edit', 'change step 1');
    const res = await pending;
    expect(res.decision).toBe('edit');
    expect(res.feedback).toBe('change step 1');
  });

  it('askClarification émet task.clarification et retourne les réponses', async () => {
    const events = new OrchestrationEvents();
    const seen: ControlEvent[] = [];
    events.onEvent((e) => seen.push(e));
    const svc = new PlanClarificationService(dbDown(), events);
    const pending = svc.askClarification({ questions: ['stack ?'], sessionId: 'sess-1' });
    let id = '';
    await vi.waitFor(() => {
      id = String(seen.find((e) => e.type === 'task.clarification')?.payload?.clarificationId);
      expect(id).not.toBe('undefined');
    });
    svc.resolveClarification(id, { 'stack ?': 'NestJS' });
    const res = await pending;
    expect(res.answers).toEqual({ 'stack ?': 'NestJS' });
  });
});
