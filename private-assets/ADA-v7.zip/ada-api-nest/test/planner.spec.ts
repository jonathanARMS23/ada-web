import { describe, it, expect, vi } from 'vitest';
import { TaskRouterService, slugify, deriveOpts } from '../src/planner/task-router.service.js';
import { isClarification } from '../src/planner/planner.types.js';
import type { ControlPlaneClient } from '../src/control-plane/control-plane.client.js';

/** Builds a TaskRouter with a stubbed ControlPlaneClient.request. */
function makeRouter(requestImpl?: (m: string, p: Record<string, unknown>) => Promise<unknown>) {
  const request = vi.fn(requestImpl ?? (async () => ({})));
  const client = { request } as unknown as ControlPlaneClient;
  return { router: new TaskRouterService(client), request };
}

describe('TaskRouterService (Planner hybride)', () => {
  it('route une instruction claire via mots-clés sans toucher au LLM', async () => {
    const { router, request } = makeRouter();
    const plan = await router.plan('Ajoute un endpoint CRUD pour la feature factures', 'auto');
    expect(isClarification(plan)).toBe(false);
    if (isClarification(plan)) return;
    expect(plan.strategy).toBe('pipeline');
    expect(plan.pipeline).toBe('feature');
    expect(plan.decidedBy).toBe('keywords');
    expect(request).not.toHaveBeenCalled(); // pas de repli LLM
  });

  it('route un audit sécurité vers security-audit', async () => {
    const { router } = makeRouter();
    const plan = await router.plan('Fais un audit de sécurité OWASP complet', 'auto');
    if (isClarification(plan)) throw new Error('unexpected clarification');
    expect(plan.pipeline).toBe('security-audit');
    expect(plan.decidedBy).toBe('keywords');
  });

  it('replie sur le LLM tier1 quand ambigu et applique sa décision', async () => {
    const { router, request } = makeRouter(async (method) => {
      expect(method).toBe('provider.complete');
      return { content: '{"strategy":"pipeline","pipeline":"review","clarify":null}' };
    });
    const plan = await router.plan('analyse ça stp', 'auto');
    if (isClarification(plan)) throw new Error('unexpected clarification');
    expect(request).toHaveBeenCalledTimes(1);
    expect(plan.decidedBy).toBe('llm');
    expect(plan.pipeline).toBe('review');
  });

  it('renvoie une clarification quand le LLM le demande', async () => {
    const { router } = makeRouter(async () => ({
      content: '{"strategy":"pipeline","pipeline":null,"clarify":["Quelle table ?","Quel endpoint ?"]}',
    }));
    const plan = await router.plan('zzz', 'auto');
    expect(isClarification(plan)).toBe(true);
    if (!isClarification(plan)) return;
    expect(plan.questions).toHaveLength(2);
  });

  it('mode=freeform renvoie un plan freeform (P3) sans LLM', async () => {
    const { router, request } = makeRouter();
    const plan = await router.plan('explore le repo', 'freeform');
    if (isClarification(plan)) throw new Error('unexpected');
    expect(plan.strategy).toBe('freeform');
    expect(request).not.toHaveBeenCalled();
  });

  it('mode=pipeline force le structuré (défaut feature si pas de match)', async () => {
    const { router } = makeRouter();
    const plan = await router.plan('quelque chose de vague', 'pipeline');
    if (isClarification(plan)) throw new Error('unexpected');
    expect(plan.strategy).toBe('pipeline');
    expect(plan.pipeline).toBe('feature');
  });

  it('défaut conservateur si le LLM est injoignable', async () => {
    const { router } = makeRouter(async () => {
      throw new Error('control plane down');
    });
    const plan = await router.plan('truc indéterminé', 'auto');
    if (isClarification(plan)) throw new Error('unexpected');
    expect(plan.strategy).toBe('pipeline');
    expect(plan.pipeline).toBe('feature');
  });
});

describe('helpers Planner', () => {
  it('slugify produit un runId valide (^[a-z0-9][a-z0-9-]{2,59}$)', () => {
    expect(slugify('Ajoute un module Factures !')).toMatch(/^[a-z0-9][a-z0-9-]{2,59}$/);
    expect(slugify('é')).toMatch(/^[a-z0-9][a-z0-9-]{2,59}$/);
  });

  it('deriveOpts détecte --api-only / --no-deploy / drf', () => {
    const o = deriveOpts('crée la feature api-only sans déploiement en drf');
    expect(o.apiOnly).toBe(true);
    expect(o.noDeploy).toBe(true);
    expect(o.backend).toBe('drf');
    expect(o.flags).toContain('--api-only');
    expect(o.flags).toContain('--no-deploy');
  });
});
