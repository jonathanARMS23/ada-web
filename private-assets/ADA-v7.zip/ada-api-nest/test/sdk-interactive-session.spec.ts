import { describe, it, expect, vi } from 'vitest';
import {
  SdkInteractiveSessionFactory,
  type SdkQueryFn,
} from '../src/sessions/sdk-interactive-session.js';
import { PermissionPolicyService } from '../src/sessions/permission-policy.service.js';
import { OrchestrationEvents } from '../src/orchestration/orchestration-events.js';
import type { SessionEvent, SessionStartOptions } from '../src/sessions/session.types.js';
import type { DatabaseService } from '../src/persistence/database.service.js';
import type { AppConfigService } from '../src/config/app-config.service.js';
import type { ControlEvent } from '../src/control-plane/control-plane.types.js';

/**
 * Drives SdkInteractiveSession WITHOUT a live `claude`/SDK. A fake `query()`
 * emits a canned system/assistant/result sequence AND fires the PreToolUse hook
 * on a chosen tool, so we can assert the decision returned to the SDK + the
 * mapping of SDK messages to SessionEvents. Streaming input is exercised by
 * pulling the user-message generator across turns.
 */

function dbDown(): DatabaseService {
  return { db: null, isUp: false } as unknown as DatabaseService;
}
function config(timeoutMs = 5000): AppConfigService {
  return {
    profile: 'pro',
    profileDir: '/tmp/pro',
    permissionTimeoutMs: timeoutMs,
    settingSources: ['user', 'project', 'local'],
    sessionMaxTurns: undefined,
  } as unknown as AppConfigService;
}

type HookFn = (input: unknown) => Promise<{ hookSpecificOutput?: { permissionDecision?: string; permissionDecisionReason?: string; updatedInput?: Record<string, unknown> } }>;

interface FakeQueryControl {
  /** Decision the hook returned for the last tool fired (set by the test). */
  lastDecision?: string;
  lastReason?: string;
  fireTool: (toolName: string, toolInput: Record<string, unknown>) => Promise<void>;
  emit: (msg: unknown) => void;
  endStream: () => void;
  interrupted: boolean;
  sawResume?: string;
  sawSettingSources?: unknown;
}

/**
 * Builds a fake SdkQueryFn. The returned `control` lets the test inject SDK
 * messages, fire the PreToolUse hook, and observe interrupt()/resume.
 */
function fakeQuery(): { queryFn: SdkQueryFn; control: FakeQueryControl } {
  const outQueue: unknown[] = [];
  let outWaiter: ((r: IteratorResult<unknown>) => void) | null = null;
  let done = false;

  const control: FakeQueryControl = {
    interrupted: false,
    async fireTool(toolName, toolInput) {
      const out = await hook!({
        hook_event_name: 'PreToolUse',
        tool_name: toolName,
        tool_input: toolInput,
        tool_use_id: 'tu-1',
        session_id: 'claude-1',
      });
      control.lastDecision = out.hookSpecificOutput?.permissionDecision;
      control.lastReason = out.hookSpecificOutput?.permissionDecisionReason;
    },
    emit(msg) {
      if (outWaiter) {
        const w = outWaiter;
        outWaiter = null;
        w({ done: false, value: msg });
      } else {
        outQueue.push(msg);
      }
    },
    endStream() {
      done = true;
      if (outWaiter) {
        const w = outWaiter;
        outWaiter = null;
        w({ done: true, value: undefined });
      }
    },
  };

  let hook: HookFn | null = null;

  const queryFn = ((params: { prompt: unknown; options?: Record<string, unknown> }) => {
    const opts = params.options ?? {};
    control.sawResume = opts.resume as string | undefined;
    control.sawSettingSources = opts.settingSources;
    const hooks = opts.hooks as { PreToolUse?: Array<{ hooks: HookFn[] }> } | undefined;
    hook = hooks?.PreToolUse?.[0]?.hooks?.[0] ?? null;

    // Drain the streaming-input generator in the background to simulate the SDK
    // pulling user turns (so send() resolves and multi-turn works).
    const input = params.prompt as AsyncGenerator<unknown>;
    void (async () => {
      for await (const _user of input) {
        void _user;
      }
    })();

    const gen: AsyncGenerator<unknown, void> & { interrupt?: () => Promise<void> } = {
      async next(): Promise<IteratorResult<unknown, void>> {
        const queued = outQueue.shift();
        if (queued !== undefined) return { done: false, value: queued };
        if (done) return { done: true, value: undefined };
        return new Promise((resolve) => {
          outWaiter = resolve as (r: IteratorResult<unknown>) => void;
        });
      },
      async return(): Promise<IteratorResult<unknown, void>> {
        done = true;
        return { done: true, value: undefined };
      },
      async throw(e): Promise<IteratorResult<unknown, void>> {
        throw e;
      },
      [Symbol.asyncIterator]() {
        return this;
      },
      interrupt: async () => {
        control.interrupted = true;
      },
    };
    return gen as unknown as ReturnType<SdkQueryFn>;
  }) as SdkQueryFn;

  return { queryFn, control };
}

function policyFor(timeoutMs = 5000) {
  const events = new OrchestrationEvents();
  const seen: ControlEvent[] = [];
  events.onEvent((e) => seen.push(e));
  const policy = new PermissionPolicyService(dbDown(), events, config(timeoutMs));
  return { policy, events, seen };
}

const baseCtx = { profile: 'pro', workspaceId: 'ws-1', conversationId: null, coreRunId: null };

function startSession(
  policy: PermissionPolicyService,
  queryFn: SdkQueryFn,
  overrides: Partial<SessionStartOptions> = {},
) {
  const factory = new SdkInteractiveSessionFactory(config(), policy, queryFn);
  const events: SessionEvent[] = [];
  const session = factory.start({
    sessionId: 'internal-1',
    profileDir: '/tmp/pro',
    permissionMode: 'default',
    resumeClaudeSessionId: null,
    permissionCtx: baseCtx,
    onEvent: (e) => events.push(e),
    ...overrides,
  });
  return { session, events };
}

describe('SdkInteractiveSession — PreToolUse hook (P3.5)', () => {
  it('Read -> allow sans aucun event de permission UI', async () => {
    const { policy, seen } = policyFor();
    const { queryFn, control } = fakeQuery();
    startSession(policy, queryFn);

    await control.fireTool('Read', { file_path: 'a.ts' });
    expect(control.lastDecision).toBe('allow');
    expect(seen.some((e) => e.type === 'task.permission_request')).toBe(false);
  });

  it('Bash -> ask : émet task.permission_request puis allow sur réponse', async () => {
    const { policy, seen } = policyFor();
    const { queryFn, control } = fakeQuery();
    startSession(policy, queryFn);

    const fired = control.fireTool('Bash', { command: 'rm -rf x' });
    let requestId = '';
    await vi.waitFor(() => {
      const req = seen.find((e) => e.type === 'task.permission_request');
      expect(req).toBeDefined();
      requestId = String(req!.payload?.requestId);
    });
    expect(policy.resolvePermission(requestId, 'allow')).toBe(true);
    await fired;
    expect(control.lastDecision).toBe('allow');
  });

  it('Bash -> ask : deny sur timeout', async () => {
    const { policy } = policyFor(20);
    const { queryFn, control } = fakeQuery();
    startSession(policy, queryFn);

    await control.fireTool('Write', { file_path: 'x', content: 'y' });
    expect(control.lastDecision).toBe('deny');
    expect(control.lastReason).toContain('timeout');
  });

  it('allow_always persiste la policy (réponse suivante = allow immédiat)', async () => {
    const { policy, seen } = policyFor();
    const { queryFn, control } = fakeQuery();
    startSession(policy, queryFn);

    const fired = control.fireTool('Bash', { command: 'ls' });
    let requestId = '';
    await vi.waitFor(() => {
      const req = seen.find((e) => e.type === 'task.permission_request');
      requestId = String(req!.payload?.requestId);
    });
    policy.resolvePermission(requestId, 'allow_always');
    await fired;
    expect(control.lastDecision).toBe('allow');

    // Now the policy is persisted -> a second Bash is allowed without a UI ask.
    const before = seen.filter((e) => e.type === 'task.permission_request').length;
    await control.fireTool('Bash', { command: 'pwd' });
    expect(control.lastDecision).toBe('allow');
    expect(seen.filter((e) => e.type === 'task.permission_request').length).toBe(before);
  });

  it('mappe les messages SDK : system/init -> session_id, assistant -> output, result -> turn_complete', async () => {
    const { policy } = policyFor();
    const { queryFn, control } = fakeQuery();
    const { events } = startSession(policy, queryFn);

    control.emit({ type: 'system', subtype: 'init', session_id: 'claude-1' });
    control.emit({ type: 'assistant', message: { content: [{ type: 'text', text: 'bonjour' }] } });
    control.emit({
      type: 'result',
      subtype: 'success',
      is_error: false,
      result: 'bonjour',
      usage: { input_tokens: 10, output_tokens: 20 },
      total_cost_usd: 0.0012,
    });

    await vi.waitFor(() => expect(events.some((e) => e.kind === 'turn_complete')).toBe(true));
    const idEvt = events.find((e) => e.kind === 'session_id');
    expect(idEvt && 'claudeSessionId' in idEvt && idEvt.claudeSessionId).toBe('claude-1');
    expect(events.some((e) => e.kind === 'output' && (e as { chunk?: string }).chunk === 'bonjour')).toBe(true);
    const tc = events.find((e) => e.kind === 'turn_complete') as { tokens: number; cost: number } | undefined;
    expect(tc?.tokens).toBe(30);
    expect(tc?.cost).toBe(0.0012);
  });

  it('assistant tool_use -> event tool', async () => {
    const { policy } = policyFor();
    const { queryFn, control } = fakeQuery();
    const { events } = startSession(policy, queryFn);
    control.emit({ type: 'assistant', message: { content: [{ type: 'tool_use', name: 'Bash', input: { command: 'ls' } }] } });
    await vi.waitFor(() => expect(events.some((e) => e.kind === 'tool')).toBe(true));
    const toolEvt = events.find((e) => e.kind === 'tool') as { tool?: string } | undefined;
    expect(toolEvt?.tool).toBe('Bash');
  });

  it('multi-tours : send() pousse un follow-up, 2e result -> 2e turn_complete', async () => {
    const { policy } = policyFor();
    const { queryFn, control } = fakeQuery();
    const { session, events } = startSession(policy, queryFn);

    control.emit({ type: 'system', subtype: 'init', session_id: 'claude-1' });
    control.emit({ type: 'result', subtype: 'success', is_error: false, result: 't1', usage: { input_tokens: 1, output_tokens: 1 }, total_cost_usd: 0.0001 });
    await vi.waitFor(() => expect(events.filter((e) => e.kind === 'turn_complete').length).toBe(1));

    await session.send('continue stp');
    control.emit({ type: 'result', subtype: 'success', is_error: false, result: 't2', usage: { input_tokens: 1, output_tokens: 1 }, total_cost_usd: 0.0001 });
    await vi.waitFor(() => expect(events.filter((e) => e.kind === 'turn_complete').length).toBe(2));
    expect(session.claudeSessionId).toBe('claude-1');
  });

  it('--resume passe le claude session_id au SDK (option resume) quand c\'est un UUID valide', async () => {
    const { policy } = policyFor();
    const { queryFn, control } = fakeQuery();
    const validUuid = '11111111-1111-4111-8111-111111111111';
    startSession(policy, queryFn, { resumeClaudeSessionId: validUuid });
    expect(control.sawResume).toBe(validUuid);
    expect(control.sawSettingSources).toEqual(['user', 'project', 'local']);
  });

  it('--resume ignore un claude session_id non-UUID (legacy/mock) et démarre une session fraîche', async () => {
    const { policy } = policyFor();
    const { queryFn, control } = fakeQuery();
    const { session } = startSession(policy, queryFn, { resumeClaudeSessionId: 'claude-RESUMED' });
    expect(control.sawResume).toBeUndefined();
    expect(session.claudeSessionId).toBeNull();
  });

  it('interrupt() appelle q.interrupt() ; cancel() ferme la session', async () => {
    const { policy } = policyFor();
    const { queryFn, control } = fakeQuery();
    const { session, events } = startSession(policy, queryFn);
    session.interrupt();
    await vi.waitFor(() => expect(control.interrupted).toBe(true));
    await session.cancel();
    expect(session.closed).toBe(true);
    expect(events.some((e) => e.kind === 'closed')).toBe(true);
  });
});
