import { describe, it, expect, vi } from 'vitest';
import { SessionInboundRouter } from '../src/sessions/session-inbound.router.js';
import type { SessionManager } from '../src/sessions/session-manager.service.js';
import type { PermissionPolicyService } from '../src/sessions/permission-policy.service.js';
import type { PlanClarificationService } from '../src/sessions/plan-clarification.service.js';

describe('SessionInboundRouter — dispatch §3.C', () => {
  function build() {
    const sessions = {
      sendMessage: vi.fn(async () => undefined),
      interrupt: vi.fn(),
      cancel: vi.fn(async () => undefined),
    } as unknown as SessionManager;
    const policy = { resolvePermission: vi.fn(() => true) } as unknown as PermissionPolicyService;
    const planClar = {
      resolvePlan: vi.fn(() => true),
      resolveClarification: vi.fn(() => true),
    } as unknown as PlanClarificationService;
    return { router: new SessionInboundRouter(sessions, policy, planClar), sessions, policy, planClar };
  }

  it('task.message -> sendMessage', async () => {
    const { router, sessions } = build();
    await router.handle({ type: 'task.message', sessionId: 's1', content: 'hello' });
    expect(sessions.sendMessage).toHaveBeenCalledWith('s1', 'hello');
  });

  it('task.interrupt -> interrupt', async () => {
    const { router, sessions } = build();
    await router.handle({ type: 'task.interrupt', sessionId: 's1' });
    expect(sessions.interrupt).toHaveBeenCalledWith('s1');
  });

  it('task.cancel -> cancel (sessionId ou runId)', async () => {
    const { router, sessions } = build();
    await router.handle({ type: 'task.cancel', runId: 's2' });
    expect(sessions.cancel).toHaveBeenCalledWith('s2');
  });

  it('task.permission_response allow avec updatedInput', async () => {
    const { router, policy } = build();
    await router.handle({
      type: 'task.permission_response',
      requestId: 'r1',
      decision: 'allow',
      updatedInput: { command: 'ls' },
    });
    expect(policy.resolvePermission).toHaveBeenCalledWith('r1', 'allow', { command: 'ls' });
  });

  it('task.permission_response deny ignore updatedInput', async () => {
    const { router, policy } = build();
    await router.handle({ type: 'task.permission_response', requestId: 'r2', decision: 'deny', updatedInput: { x: 1 } });
    expect(policy.resolvePermission).toHaveBeenCalledWith('r2', 'deny', undefined);
  });

  it('décision de permission invalide ignorée', async () => {
    const { router, policy } = build();
    await router.handle({ type: 'task.permission_response', requestId: 'r3', decision: 'maybe' });
    expect(policy.resolvePermission).not.toHaveBeenCalled();
  });

  it('task.plan_response -> resolvePlan', async () => {
    const { router, planClar } = build();
    await router.handle({ type: 'task.plan_response', planId: 'p1', decision: 'edit', feedback: 'fix' });
    expect(planClar.resolvePlan).toHaveBeenCalledWith('p1', 'edit', 'fix');
  });

  it('task.clarification_response -> resolveClarification', async () => {
    const { router, planClar } = build();
    await router.handle({ type: 'task.clarification_response', clarificationId: 'c1', answers: { q: 'a' } });
    expect(planClar.resolveClarification).toHaveBeenCalledWith('c1', { q: 'a' });
  });

  it('type inconnu ne lève pas', async () => {
    const { router } = build();
    await expect(router.handle({ type: 'task.unknown' })).resolves.toBeUndefined();
  });
});
