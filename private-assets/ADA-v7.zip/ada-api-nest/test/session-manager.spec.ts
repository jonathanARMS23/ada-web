import { describe, it, expect, vi } from 'vitest';
import { SessionManager } from '../src/sessions/session-manager.service.js';
import { MockInteractiveSessionFactory } from '../src/sessions/mock-interactive-session.js';
import { OrchestrationEvents } from '../src/orchestration/orchestration-events.js';
import type { DatabaseService } from '../src/persistence/database.service.js';
import type { AppConfigService } from '../src/config/app-config.service.js';
import type { ControlEvent } from '../src/control-plane/control-plane.types.js';

function dbDown(): DatabaseService {
  return { db: null, isUp: false } as unknown as DatabaseService;
}
function config(): AppConfigService {
  return {
    profile: 'pro',
    profileDir: '/tmp/pro',
    mcpBrokerConfigPath: null,
    permissionPromptTool: 'mcp__ada__approve',
  } as unknown as AppConfigService;
}

function build() {
  const events = new OrchestrationEvents();
  const seen: ControlEvent[] = [];
  events.onEvent((e) => seen.push(e));
  const mgr = new SessionManager(dbDown(), events, config(), new MockInteractiveSessionFactory());
  return { mgr, seen };
}

describe('SessionManager — session bidirectionnelle (P3)', () => {
  it('message initial -> réponse, follow-up -> 2e réponse (multi-tours)', async () => {
    const { mgr, seen } = build();
    const { sessionId } = await mgr.create({ workspaceId: 'ws-1', initialMessage: 'bonjour' });

    // Let the canned init + first turns flush.
    await vi.waitFor(() =>
      expect(seen.filter((e) => e.type === 'session.turn_complete').length).toBeGreaterThanOrEqual(2),
    );

    // session_id captured + relayed.
    expect(seen.some((e) => e.type === 'session.started')).toBe(true);
    const outputs = seen.filter((e) => e.type === 'session.output');
    expect(outputs.length).toBeGreaterThanOrEqual(2);
    // The user follow-up turn was echoed.
    expect(outputs.some((e) => String(e.payload?.chunk).includes('bonjour'))).toBe(true);

    // Second follow-up.
    const before = seen.filter((e) => e.type === 'session.turn_complete').length;
    await mgr.sendMessage(sessionId, 'continue stp');
    await vi.waitFor(() =>
      expect(seen.filter((e) => e.type === 'session.turn_complete').length).toBe(before + 1),
    );
    expect(seen.some((e) => e.type === 'session.output' && String(e.payload?.chunk).includes('continue stp'))).toBe(true);
  });

  it('émet session.message (user) avant l’envoi au process', async () => {
    const { mgr, seen } = build();
    const { sessionId } = await mgr.create({ workspaceId: 'ws-1' });
    await mgr.sendMessage(sessionId, 'salut');
    const userMsg = seen.find((e) => e.type === 'session.message' && e.payload?.role === 'user');
    expect(userMsg?.payload?.content).toBe('salut');
  });

  it('cancel ferme la session et émet session.cancelled', async () => {
    const { mgr, seen } = build();
    const { sessionId } = await mgr.create({ workspaceId: 'ws-1' });
    await mgr.cancel(sessionId);
    expect(seen.some((e) => e.type === 'session.cancelled')).toBe(true);
  });

  it('corrélation workspace propagée sur les events', async () => {
    const { mgr, seen } = build();
    await mgr.create({ workspaceId: 'ws-42', initialMessage: 'x' });
    await vi.waitFor(() => expect(seen.some((e) => e.type === 'session.turn_complete')).toBe(true));
    expect(seen.every((e) => e.corr?.workspaceId === 'ws-42')).toBe(true);
  });
});
