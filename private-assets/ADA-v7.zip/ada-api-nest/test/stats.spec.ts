import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import pg from 'pg';
import { drizzle } from 'drizzle-orm/node-postgres';
import { eq } from 'drizzle-orm';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { randomUUID } from 'node:crypto';
import { schema, costLedger, runs, runPhases } from '../src/persistence/schema.js';
import { EventIngestionService } from '../src/persistence/event-ingestion.service.js';
import { StatsService } from '../src/stats/stats.service.js';
import type { DatabaseService } from '../src/persistence/database.service.js';
import type { ControlPlaneClient } from '../src/control-plane/control-plane.client.js';
import type { OrchestrationEvents } from '../src/orchestration/orchestration-events.js';
import type { ControlEvent } from '../src/control-plane/control-plane.types.js';

const { Pool } = pg;
const DB_URL = process.env.DATABASE_URL;
const maybe = DB_URL ? describe : describe.skip;

/** Capteur d'events émis sur le bus (cost.delta / budget.warning). */
function fakeBus(): { events: ControlEvent[]; svc: OrchestrationEvents } {
  const events: ControlEvent[] = [];
  const svc = {
    emitRun(type: string, payload: Record<string, unknown>, corr: Record<string, unknown>) {
      const evt: ControlEvent = { id: randomUUID(), ts: Date.now(), type, corr, payload };
      events.push(evt);
      return evt;
    },
    onEvent() {},
  } as unknown as OrchestrationEvents;
  return { events, svc };
}

maybe('P6 cost_ledger ingestion + stats → Postgres', () => {
  let pool: pg.Pool;
  let db: ReturnType<typeof drizzle<typeof schema>>;
  let fakeDb: DatabaseService;

  beforeAll(async () => {
    pool = new Pool({ connectionString: DB_URL });
    const dir = path.resolve(__dirname, '..', 'src', 'persistence', 'migrations');
    for (const f of fs.readdirSync(dir).filter((x) => x.endsWith('.sql')).sort()) {
      await pool.query(fs.readFileSync(path.join(dir, f), 'utf8'));
    }
    db = drizzle(pool, { schema });
    fakeDb = { db, isUp: true, status: 'up' } as unknown as DatabaseService;
  });

  afterAll(async () => {
    await pool?.end();
  });

  it('run.phase.completed → ligne cost_ledger (idempotent) + cost.delta émis', async () => {
    const coreRunId = 'cost-run-' + Date.now();
    // budget.check stub: continue (pas de warning).
    const fakeClient = {
      on: () => undefined,
      request: async () => ({ ok: true, action: 'continue', message: '' }),
    } as unknown as ControlPlaneClient;
    const { events, svc } = fakeBus();
    const ingestion = new EventIngestionService(fakeClient, fakeDb, svc);

    const evtId = randomUUID();
    const evt: ControlEvent = {
      id: evtId,
      ts: Date.now(),
      type: 'run.phase.completed',
      corr: { runId: coreRunId, workspaceId: null },
      payload: { phaseId: 'impl', agent: 'nestjs', model: 'opus', tier: 3, cost: 0.42, inputTokens: 1000, outputTokens: 500 },
    };

    expect(await ingestion.ingest(evt)).toBe(true);
    // Rejeu du même event id → no-op (dédup eventId UNIQUE).
    expect(await ingestion.ingest(evt)).toBe(true);

    const rows = await db.select().from(costLedger).where(eq(costLedger.runId, coreRunId));
    expect(rows.length).toBe(1);
    expect(Number(rows[0].cost)).toBeCloseTo(0.42);
    expect(rows[0].agent).toBe('nestjs');
    expect(rows[0].inputTokens).toBe(1000);
    expect(rows[0].outputTokens).toBe(500);

    // cost.delta émis une seule fois (le rejeu ne ré-émet pas).
    const deltas = events.filter((e) => e.type === 'cost.delta');
    expect(deltas.length).toBe(1);
    expect(deltas[0].payload?.cost).toBeCloseTo(0.42);
    expect(deltas[0].payload?.cumulativeCost).toBeCloseTo(0.42);
    expect(deltas[0].payload?.runId).toBe(coreRunId);
  });

  it('budget.check dépassement → budget.warning émis', async () => {
    const coreRunId = 'budget-run-' + Date.now();
    const fakeClient = {
      on: () => undefined,
      request: async () => ({ ok: false, action: 'warn', message: 'Budget run à 85% ($4.2500 / $5)' }),
    } as unknown as ControlPlaneClient;
    const { events, svc } = fakeBus();
    const ingestion = new EventIngestionService(fakeClient, fakeDb, svc);
    const evt: ControlEvent = {
      id: randomUUID(),
      ts: Date.now(),
      type: 'run.phase.completed',
      corr: { runId: coreRunId, workspaceId: null },
      payload: { phaseId: 'p1', agent: 'db', cost: 4.25 },
    };
    await ingestion.ingest(evt);

    const warn = events.find((e) => e.type === 'budget.warning');
    expect(warn).toBeTruthy();
    expect(warn!.payload?.scope).toBe('run');
    expect(warn!.payload?.pct).toBe(85);
    expect(Number(warn!.payload?.limit)).toBe(5);
  });

  it('GET /stats/overview agrège runs + phases + cost_ledger (+ scoping workspace)', async () => {
    const wsId = randomUUID();
    const runA = 'ov-a-' + Date.now();
    const runB = 'ov-b-' + Date.now();
    await db.insert(runs).values([
      { coreRunId: runA, pipeline: 'feature', status: 'completed', workspaceId: wsId, totalCost: '1.0' },
      { coreRunId: runB, pipeline: 'feature', status: 'running', workspaceId: wsId },
    ]);
    await db.insert(runPhases).values([
      { coreRunId: runA, phaseId: 'p1', agent: 'nestjs', status: 'completed', cost: '0.6' },
      { coreRunId: runB, phaseId: 'p1', agent: 'nestjs', status: 'running', cost: '0' },
    ]);
    await db.insert(costLedger).values([
      { eventId: randomUUID(), runId: runA, phaseId: 'p1', workspaceId: wsId, agent: 'nestjs', cost: '0.6', inputTokens: 100, outputTokens: 50 },
    ]);

    const fakeClient = {
      on: () => undefined,
      request: async () => ({ thompson: {} }),
    } as unknown as ControlPlaneClient;
    const stats = new StatsService(fakeDb, fakeClient);

    const ov = await stats.overview(wsId);
    expect(ov.source).toBe('postgres');
    expect(ov.degraded).toBe(false);
    expect(ov.totalRuns).toBe(2);
    expect(ov.byStatus.completed).toBe(1);
    expect(ov.byStatus.running).toBe(1);
    expect(ov.activeRuns).toBe(1);
    expect(ov.successRate).toBe(0.5);
    expect(ov.totalCost).toBeCloseTo(0.6);
    expect(ov.totalTokens).toBe(150);
    expect(ov.topAgents[0].agent).toBe('nestjs');
  });

  it('GET /stats/activity → heatmap par jour (scopée workspace)', async () => {
    const wsId = randomUUID();
    const runId = 'act-' + Date.now();
    await db.insert(costLedger).values([
      { eventId: randomUUID(), runId, workspaceId: wsId, cost: '0.10', ts: new Date() },
      { eventId: randomUUID(), runId, workspaceId: wsId, cost: '0.20', ts: new Date() },
    ]);
    const fakeClient = { on: () => undefined, request: async () => ({}) } as unknown as ControlPlaneClient;
    const stats = new StatsService(fakeDb, fakeClient);

    const act = await stats.activity(90, wsId);
    expect(act.source).toBe('postgres');
    expect(act.buckets.length).toBe(1);
    expect(act.buckets[0].runs).toBe(1);
    expect(act.buckets[0].cost).toBeCloseTo(0.3);
  });

  it('GET /stats/runs/timeline → runs récents + phases (scopé workspace)', async () => {
    const wsId = randomUUID();
    const runId = 'tl-' + Date.now();
    const started = new Date(Date.now() - 5000);
    const completed = new Date();
    await db.insert(runs).values({
      coreRunId: runId, pipeline: 'feature', status: 'completed', workspaceId: wsId,
      totalCost: '0.9', startedAt: started, completedAt: completed,
    });
    await db.insert(runPhases).values({ coreRunId: runId, phaseId: 'p1', agent: 'db', status: 'completed', cost: '0.9' });
    const fakeClient = { on: () => undefined, request: async () => ({}) } as unknown as ControlPlaneClient;
    const stats = new StatsService(fakeDb, fakeClient);

    const tl = await stats.timeline(20, wsId);
    expect(tl.source).toBe('postgres');
    expect(tl.items.length).toBe(1);
    expect(tl.items[0].runId).toBe(runId);
    expect(tl.items[0].cost).toBeCloseTo(0.9);
    expect(tl.items[0].durationMs).toBeGreaterThan(0);
    expect(tl.items[0].phases.length).toBe(1);
    expect(tl.items[0].phases[0].agent).toBe('db');
  });

  it('GET /stats/budget → relaie budget.check (mock RPC)', async () => {
    const fakeClient = {
      on: () => undefined,
      request: async (method: string) => {
        expect(method).toBe('budget.check');
        return { ok: true, action: 'continue', message: '', config: { perRun: 5, perDay: 50 } };
      },
    } as unknown as ControlPlaneClient;
    const stats = new StatsService(fakeDb, fakeClient);

    const b = await stats.budget();
    expect(b.source).toBe('live');
    expect(b.degraded).toBe(false);
    expect((b.config as { perRun: number }).perRun).toBe(5);
  });
});

/** Dégradation gracieuse : aucun endpoint ne crashe sans DB. */
describe('P6 stats — mode dégradé (DB down)', () => {
  const dbDown = { db: null, isUp: false, status: 'down' } as unknown as DatabaseService;

  it('overview relaie cost.report live, sinon payload vide annoté', async () => {
    const fakeClient = {
      on: () => undefined,
      request: async (m: string) => (m === 'cost.report' ? { totalCost: 12.5 } : {}),
    } as unknown as ControlPlaneClient;
    const stats = new StatsService(dbDown, fakeClient);
    const ov = await stats.overview();
    expect(ov.degraded).toBe(true);
    expect(ov.source).toBe('live');
    expect(ov.totalCost).toBe(12.5);
    expect(ov.totalRuns).toBe(0);
  });

  it('activity/timeline renvoient un payload vide sans crash', async () => {
    const fakeClient = { on: () => undefined, request: async () => ({}) } as unknown as ControlPlaneClient;
    const stats = new StatsService(dbDown, fakeClient);
    const act = await stats.activity(30);
    expect(act.degraded).toBe(true);
    expect(act.buckets).toEqual([]);
    const tl = await stats.timeline(10);
    expect(tl.degraded).toBe(true);
    expect(tl.items).toEqual([]);
  });

  it('budget dégrade si le Control Server est down', async () => {
    const fakeClient = {
      on: () => undefined,
      request: async () => {
        throw new Error('control plane down');
      },
    } as unknown as ControlPlaneClient;
    const stats = new StatsService(dbDown, fakeClient);
    const b = await stats.budget();
    expect(b.degraded).toBe(true);
    expect(b.source).toBe('empty');
    expect(b.check).toBeNull();
  });

  it('ingestion cost = no-op silencieux sans DB', async () => {
    const fakeClient = { on: () => undefined, request: async () => ({}) } as unknown as ControlPlaneClient;
    const { events, svc } = fakeBus();
    const ingestion = new EventIngestionService(fakeClient, dbDown, svc);
    const evt: ControlEvent = {
      id: randomUUID(), ts: Date.now(), type: 'run.phase.completed',
      corr: { runId: 'x' }, payload: { phaseId: 'p1', cost: 1 },
    };
    expect(await ingestion.ingest(evt)).toBe(false);
    expect(events.length).toBe(0);
  });
});
