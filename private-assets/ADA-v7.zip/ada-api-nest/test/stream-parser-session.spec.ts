import { describe, it, expect } from 'vitest';
import { StreamParser } from '../src/orchestration/stream-parser.js';

describe('StreamParser — capture session_id (P3)', () => {
  it('capture session_id depuis {type:"system",subtype:"init"}', () => {
    const p = new StreamParser(() => undefined);
    p.push(
      JSON.stringify({ type: 'system', subtype: 'init', session_id: 'sess-abc-123', cwd: '/x' }) + '\n',
    );
    expect(p.sessionId).toBe('sess-abc-123');
  });

  it('reconfirme session_id depuis le frame result final', () => {
    const p = new StreamParser(() => undefined);
    p.push(JSON.stringify({ type: 'system', subtype: 'init', session_id: 'sess-1' }) + '\n');
    p.push(
      JSON.stringify({
        type: 'result',
        is_error: false,
        result: 'ok',
        session_id: 'sess-1',
        usage: { input_tokens: 3, output_tokens: 2 },
        total_cost_usd: 0.0001,
      }) + '\n',
    );
    expect(p.sessionId).toBe('sess-1');
    expect(p.usage).toEqual({ tokens: 5, cost: 0.0001 });
  });

  it('le frame system n’émet aucun event de sortie', () => {
    const seen: unknown[] = [];
    const p = new StreamParser((e) => seen.push(e));
    p.push(JSON.stringify({ type: 'system', subtype: 'init', session_id: 's' }) + '\n');
    expect(seen).toHaveLength(0);
  });
});
