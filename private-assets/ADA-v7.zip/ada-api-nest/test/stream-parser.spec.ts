import { describe, it, expect } from 'vitest';
import { StreamParser } from '../src/orchestration/stream-parser.js';
import type { PhaseStreamEvent } from '../src/orchestration/phase-executor.js';

describe('StreamParser', () => {
  it('parse texte, tool_use et result(usage) depuis le NDJSON stream-json', () => {
    const seen: PhaseStreamEvent[] = [];
    const p = new StreamParser((e) => seen.push(e));
    p.push(JSON.stringify({ type: 'assistant', message: { content: [{ type: 'text', text: 'hello' }] } }) + '\n');
    p.push(
      JSON.stringify({
        type: 'assistant',
        message: { content: [{ type: 'tool_use', name: 'Bash', input: { cmd: 'ls' } }] },
      }) + '\n',
    );
    p.push(
      JSON.stringify({
        type: 'result',
        is_error: false,
        result: 'done',
        usage: { input_tokens: 10, output_tokens: 5 },
        total_cost_usd: 0.0012,
      }) + '\n',
    );
    p.end();

    expect(seen.filter((e) => e.kind === 'output')).toHaveLength(1);
    const tool = seen.find((e) => e.kind === 'tool');
    expect(tool).toBeDefined();
    expect(p.resultSeen).toBe(true);
    expect(p.usage).toEqual({ tokens: 15, cost: 0.0012 });
    expect(p.summary).toBe('done');
    expect(p.error).toBeNull();
  });

  it('gère les content_block_delta (token streaming)', () => {
    const seen: PhaseStreamEvent[] = [];
    const p = new StreamParser((e) => seen.push(e));
    p.push(JSON.stringify({ type: 'content_block_delta', delta: { type: 'text_delta', text: 'a' } }) + '\n');
    p.push(JSON.stringify({ type: 'content_block_delta', delta: { type: 'text_delta', text: 'b' } }) + '\n');
    expect(seen.map((e) => (e.kind === 'output' ? e.chunk : ''))).toEqual(['a', 'b']);
  });

  it('détecte une erreur depuis result.is_error', () => {
    const p = new StreamParser(() => undefined);
    p.push(JSON.stringify({ type: 'result', is_error: true, result: 'boom' }) + '\n');
    p.end();
    expect(p.error).toBe('boom');
  });

  it('ignore les lignes non-JSON sans planter', () => {
    const p = new StreamParser(() => undefined);
    expect(() => {
      p.push('not json\n');
      p.end();
    }).not.toThrow();
  });
});
