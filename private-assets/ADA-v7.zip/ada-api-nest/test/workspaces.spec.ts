import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import pg from 'pg';
import { drizzle } from 'drizzle-orm/node-postgres';
import { eq } from 'drizzle-orm';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { schema, runs } from '../src/persistence/schema.js';
import { WorkspacesService } from '../src/workspaces/workspaces.service.js';
import type { DatabaseService } from '../src/persistence/database.service.js';

/**
 * P5 — WorkspacesService against Postgres. Skips cleanly without DATABASE_URL
 * (same hermetic pattern as event-ingestion.spec). Forces a real URL when one
 * is present so the suite is deterministic.
 */
const { Pool } = pg;
const DB_URL = process.env.DATABASE_URL;
const maybe = DB_URL ? describe : describe.skip;

maybe('WorkspacesService → Postgres', () => {
  let pool: pg.Pool;
  let service: WorkspacesService;
  let db: ReturnType<typeof drizzle<typeof schema>>;

  beforeAll(async () => {
    pool = new Pool({ connectionString: DB_URL });
    const dir = path.resolve(__dirname, '..', 'src', 'persistence', 'migrations');
    for (const f of fs.readdirSync(dir).filter((x) => x.endsWith('.sql')).sort()) {
      await pool.query(fs.readFileSync(path.join(dir, f), 'utf8'));
    }
    db = drizzle(pool, { schema });
    const fakeDb = { db, isUp: true, status: 'up' } as unknown as DatabaseService;
    service = new WorkspacesService(fakeDb);
  });

  afterAll(async () => {
    await pool?.end();
  });

  it('CRUD workspace + slug auto-unique', async () => {
    // Unique base per run so re-runs don't collide with leftover rows.
    const tag = Date.now();
    const name = `P5 Démo Été ${tag}`;
    const expectedSlug = `p5-demo-ete-${tag}`;
    const a = await service.create({ name });
    expect(a.slug).toBe(expectedSlug); // diacritics stripped, accents folded
    const b = await service.create({ name });
    expect(b.slug).toBe(`${expectedSlug}-2`); // collision → -2

    const got = await service.get(a.id);
    expect(got.name).toBe(name);
    // lookup by slug works too
    const bySlug = await service.get(expectedSlug);
    expect(bySlug.id).toBe(a.id);

    const upd = await service.update(a.id, { color: '#ff0000', pinned: true });
    expect(upd.color).toBe('#ff0000');
    expect(upd.pinned).toBe(true);
    expect(upd.slug).toBe(a.slug); // slug immuable

    await service.remove(b.id);
    await expect(service.get(b.id)).rejects.toThrow();
  });

  it('conversations + messages + stats + search', async () => {
    const ws = await service.create({ name: 'WS Conv ' + Date.now() });

    const conv = await service.createConversation(ws.id, { title: 'Auth flow' });
    expect(conv.workspaceId).toBe(ws.id);

    await service.createMessage(conv.id, { role: 'user', content: 'Comment gérer la migration invoices ?' });
    await service.createMessage(conv.id, { role: 'assistant', content: 'On crée une table idempotente.' });

    const got = await service.getConversation(conv.id);
    expect(got.messageCount).toBe(2);

    const msgs = await service.listMessages(conv.id, { limit: 10 });
    expect(msgs.items.length).toBe(2);
    expect(msgs.hasMore).toBe(false);

    const list = await service.listConversations(ws.id, { limit: 10 });
    expect(list.total).toBe(1);
    expect(list.items[0].messageCount).toBe(2);

    // Seed a run linked to the workspace for stats aggregation.
    await db.insert(runs).values({
      coreRunId: 'ws-stats-' + Date.now(),
      pipeline: 'feature',
      status: 'completed',
      totalTokens: 1200,
      totalCost: '0.42',
      workspaceId: ws.id,
      completedAt: new Date(),
    });

    const stats = await service.stats(ws.id);
    expect(stats.conversationCount).toBe(1);
    expect(stats.totalMessages).toBe(2);
    expect(stats.totalRuns).toBe(1);
    expect(stats.totalCost).toBeCloseTo(0.42, 5);
    expect(stats.totalTokens).toBe(1200);

    const search = await service.search(ws.id, 'migration');
    expect(search.total).toBe(1);
    expect(search.items[0].content).toContain('migration');

    // cascade: delete workspace removes conversation + messages.
    await service.remove(ws.id);
    const orphan = await db.select().from(schema.conversations).where(eq(schema.conversations.id, conv.id));
    expect(orphan.length).toBe(0);
  });
});

/** Degraded mode: no DB -> 503, never a crash. */
describe('WorkspacesService — mode dégradé (DB down)', () => {
  it('lève 503 sans planter', async () => {
    const fakeDb = { db: null, isUp: false, status: 'down' } as unknown as DatabaseService;
    const svc = new WorkspacesService(fakeDb);
    await expect(svc.list({})).rejects.toMatchObject({ status: 503 });
  });
});
