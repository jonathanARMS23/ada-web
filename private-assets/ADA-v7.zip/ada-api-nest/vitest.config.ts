import { defineConfig } from 'vitest/config';
import swc from 'unplugin-swc';

// SWC transforms NestJS decorators + emitDecoratorMetadata for Vitest.
export default defineConfig({
  test: {
    globals: true,
    include: ['test/**/*.{test,spec}.ts', 'src/**/*.{test,spec}.ts'],
    testTimeout: 30000,
    hookTimeout: 30000,
    pool: 'forks', // each suite in its own process (sockets/servers isolation)
  },
  plugins: [swc.vite()],
});
