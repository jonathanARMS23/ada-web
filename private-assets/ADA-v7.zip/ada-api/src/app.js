/**
 * src/app.js
 * Fastify application factory.
 * Assembles plugins, middleware, and routes.
 */
import Fastify from 'fastify';
import cors from '@fastify/cors';
import websocket from '@fastify/websocket';
import rateLimit from '@fastify/rate-limit';
import { randomBytes } from 'crypto';
import { mkdirSync, writeFileSync } from 'fs';
import { join } from 'path';
import { homedir } from 'os';
import { db, sqlite } from './db/client.js';
import { env } from './config/env.js';
import { createAuthMiddleware } from './auth/middleware.js';
import { authRoutes } from './routes/auth.js';
import { healthRoutes } from './routes/health.js';
import { workspaceRoutes } from './routes/workspaces.js';
import { conversationRoutes } from './routes/conversations.js';
import { runsRoutes } from './routes/runs.js';
import { statsRoutes } from './routes/stats.js';
import { WsRooms } from './ws/rooms.js';
import { wsGateway } from './ws/gateway.js';

/**
 * Create and configure a Fastify instance.
 *
 * @param {object} [options]
 * @param {object|boolean} [options.logger]         - Fastify logger config (false disables)
 * @param {'local'|'server'} [options.authMode]     - Override AUTH_MODE (for tests)
 * @param {string}  [options.authPassword]          - Override AUTH_PASSWORD (for tests)
 * @param {number}  [options.jwtTtlSeconds]         - Override JWT TTL in seconds (for tests)
 * @returns {Promise<import('fastify').FastifyInstance>}
 */
export async function createApp(options = {}) {
  const authMode      = options.authMode      ?? env.AUTH_MODE;
  const authPassword  = options.authPassword  ?? env.ADA_AUTH_PASSWORD;
  const jwtSecret     = env.ADA_JWT_SECRET;
  const jwtTtlSeconds = options.jwtTtlSeconds ?? env.ADA_JWT_TTL_SECONDS;

  const fastify = Fastify({
    logger: options.logger !== undefined ? options.logger : { level: env.LOG_LEVEL },
  });

  // ─── CORS ──────────────────────────────────────────────────────────────────
  await fastify.register(cors, {
    origin: env.CORS_ORIGINS.split(',').map((s) => s.trim()),
    credentials: true,
  });

  // ─── WebSocket ─────────────────────────────────────────────────────────────
  await fastify.register(websocket, {
    options: { maxPayload: 1024 * 1024 }, // 1 MB
  });

  // ─── Decorators ────────────────────────────────────────────────────────────
  fastify.decorate('wsRooms', new WsRooms());
  fastify.decorate('ipcConnected', false);
  fastify.decorate('wsTickets', new Map()); // partagé entre authRoutes et wsGateway

  // Expose sqlite instance and config to route plugins
  fastify.decorate('sqlite', sqlite);
  fastify.decorate('jwtSecret', jwtSecret);
  fastify.decorate('jwtTtlSeconds', jwtTtlSeconds);
  fastify.decorate('authMode', authMode);
  fastify.decorate('authPassword', authPassword ?? null);

  // ─── Auth middleware ────────────────────────────────────────────────────────
  // Applied on all /api/** routes except public ones
  const authMiddleware = createAuthMiddleware(sqlite, jwtSecret);

  fastify.addHook('preHandler', async (request, reply) => {
    const url = request.url.split('?')[0]; // strip query string

    // Only guard /api/** routes
    if (!url.startsWith('/api/')) return;

    // Public routes — skip auth
    if (url === '/api/health' || url.startsWith('/api/health/')) return;
    if (url === '/api/auth/token') return;

    return authMiddleware(request, reply);
  });

  // ─── Rate limiting ─────────────────────────────────────────────────────────
  await fastify.register(rateLimit, {
    global: false, // ne s'applique que là où on le configure explicitement
  });

  // ─── Routes ────────────────────────────────────────────────────────────────
  await fastify.register(authRoutes);
  await fastify.register(healthRoutes);
  await fastify.register(workspaceRoutes);
  await fastify.register(conversationRoutes);
  await fastify.register(runsRoutes);
  await fastify.register(statsRoutes);
  await fastify.register(wsGateway);

  // ─── IPC HMAC secret ───────────────────────────────────────────────────────
  // Généré une seule fois au démarrage ; écrit dans ~/.ada/ipc.secret (mode 0o600)
  // pour que ipc-emit.js puisse le lire si ADA_IPC_HMAC_SECRET n'est pas défini.
  if (!process.env.ADA_IPC_HMAC_SECRET) {
    try {
      const secret = randomBytes(32).toString('hex');
      const dir = join(homedir(), '.ada');
      mkdirSync(dir, { recursive: true });
      const secretFile = join(dir, 'ipc.secret');
      writeFileSync(secretFile, secret, { encoding: 'utf8', mode: 0o600 });
      process.env.ADA_IPC_HMAC_SECRET = secret;
      fastify.log.info({ msg: 'IPC HMAC secret generated', path: secretFile });
    } catch (err) {
      fastify.log.warn({ msg: 'Could not write IPC secret — HMAC disabled', err: err.message });
    }
  }

  return fastify;
}
