/**
 * src/auth/jwt.js
 * Pure JWT helpers using jose (HS256).
 * No dependency on env — secrets are passed as parameters.
 */
import { SignJWT, jwtVerify } from 'jose';
import crypto, { randomUUID } from 'crypto';

// ─── sign ─────────────────────────────────────────────────────────────────────

/**
 * Sign a JWT token.
 * @param {object} payload   - Additional claims (sub, etc.)
 * @param {string} secret    - HS256 raw secret string
 * @param {number} ttlSeconds - Expiry in seconds
 * @returns {Promise<{token: string, expiresAt: string, exp: number}>}
 */
export async function signToken(payload, secret, ttlSeconds) {
  const key = new TextEncoder().encode(secret);

  // Ensure sub is present; add jti for uniqueness across rapid calls
  const claims = { sub: 'local', jti: randomUUID(), ...payload };

  const token = await new SignJWT(claims)
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime(`${ttlSeconds}s`)
    .sign(key);

  // Decode to extract exp for the response
  const parts = token.split('.');
  const decoded = JSON.parse(Buffer.from(parts[1], 'base64url').toString());
  const exp = decoded.exp;
  const expiresAt = new Date(exp * 1000).toISOString();

  return { token, expiresAt, exp };
}

// ─── verify ───────────────────────────────────────────────────────────────────

/**
 * Verify and decode a JWT token.
 * @param {string} token
 * @param {string} secret
 * @returns {Promise<{payload: object}>}
 * @throws {{ code: 'TOKEN_EXPIRED' | 'INVALID_TOKEN' }}
 */
export async function verifyToken(token, secret) {
  const key = new TextEncoder().encode(secret);

  try {
    const { payload } = await jwtVerify(token, key, { algorithms: ['HS256'] });
    return { payload };
  } catch (err) {
    // JWTExpired has a specific code from jose
    if (err.code === 'ERR_JWT_EXPIRED') {
      throw { code: 'TOKEN_EXPIRED' };
    }
    // All other jose errors → INVALID_TOKEN
    throw { code: 'INVALID_TOKEN' };
  }
}

// ─── hash ─────────────────────────────────────────────────────────────────────

/**
 * SHA-256 hash of the raw JWT string (hex, 64 chars).
 * @param {string} token
 * @returns {string}
 */
export function hashToken(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}
