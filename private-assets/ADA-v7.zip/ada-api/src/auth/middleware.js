/**
 * src/auth/middleware.js
 * Fastify preHandler that validates Bearer JWT tokens.
 * Routes excluded: /api/health, /api/auth/token (handled in app.js hook)
 */
import { verifyToken, hashToken } from './jwt.js';

/**
 * @param {import('better-sqlite3').Database} sqliteInstance  - raw better-sqlite3 DB
 * @param {string} jwtSecret
 */
export function createAuthMiddleware(sqliteInstance, jwtSecret) {
  const stmtFind = sqliteInstance.prepare(
    'SELECT id FROM sessions WHERE token_hash = ?'
  );

  return async function authMiddleware(request, reply) {
    const authHeader = request.headers.authorization;

    // 1. Check header presence and format
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return reply.code(401).send({
        error: 'UNAUTHORIZED',
        message: 'Missing or invalid Authorization header',
      });
    }

    const token = authHeader.slice(7);

    // 2. Verify JWT signature and expiry
    let payload;
    try {
      ({ payload } = await verifyToken(token, jwtSecret));
    } catch (err) {
      if (err.code === 'TOKEN_EXPIRED') {
        return reply.code(401).send({
          error: 'TOKEN_EXPIRED',
          message: 'Token has expired',
        });
      }
      return reply.code(401).send({
        error: 'INVALID_TOKEN',
        message: 'Token signature invalid',
      });
    }

    // 3. Check hash presence in sessions table
    const tokenHash = hashToken(token);
    const row = stmtFind.get(tokenHash);

    if (!row) {
      return reply.code(401).send({
        error: 'TOKEN_REVOKED',
        message: 'Token has been revoked',
      });
    }

    // 4. Attach user to request
    request.user = {
      sub: payload.sub,
      iat: payload.iat,
      exp: payload.exp,
    };
  };
}
