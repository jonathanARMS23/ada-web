/**
 * src/config/env.js
 * Validates and exports all environment variables with safe defaults.
 */
import { randomBytes } from 'crypto';
import { homedir } from 'os';

// ─── TTL parser ───────────────────────────────────────────────────────────────
/**
 * Parse a duration string like '7d', '1h', '30m' into seconds.
 * @param {string} ttl
 * @returns {number} seconds
 */
function parseTtlSeconds(ttl) {
  const match = String(ttl).match(/^(\d+)(d|h|m|s)$/i);
  if (!match) {
    throw new Error(`ADA_JWT_TTL invalid format: "${ttl}" — expected e.g. '7d', '1h', '30m'`);
  }
  const value = parseInt(match[1], 10);
  const unit = match[2].toLowerCase();
  const multipliers = { d: 86400, h: 3600, m: 60, s: 1 };
  return value * multipliers[unit];
}

// ─── Integer parser ───────────────────────────────────────────────────────────
function parseIntEnv(key, defaultValue) {
  const raw = process.env[key];
  if (raw === undefined || raw === '') return defaultValue;
  const parsed = parseInt(raw, 10);
  if (isNaN(parsed)) {
    throw new Error(`Environment variable ${key} must be an integer, got: "${raw}"`);
  }
  return parsed;
}

// ─── Build env object ─────────────────────────────────────────────────────────
function buildEnv() {
  const NODE_ENV = process.env.NODE_ENV || 'development';
  const PORT = parseIntEnv('PORT', 3001);
  const HOST = process.env.HOST || '127.0.0.1';
  const DB_PATH = process.env.DB_PATH || `${homedir()}/.ada/ada-api.db`;

  // Auth mode — ADA_AUTH_MODE takes precedence, then AUTH_MODE, then default
  const AUTH_MODE = process.env.ADA_AUTH_MODE || process.env.AUTH_MODE || 'local';
  if (!['local', 'server'].includes(AUTH_MODE)) {
    throw new Error(`ADA_AUTH_MODE must be 'local' or 'server', got: "${AUTH_MODE}"`);
  }

  const ADA_AUTH_PASSWORD = process.env.ADA_AUTH_PASSWORD || undefined;
  if (AUTH_MODE === 'server' && !ADA_AUTH_PASSWORD) {
    throw new Error('ADA_AUTH_PASSWORD is required when ADA_AUTH_MODE=server');
  }

  // JWT secret — auto-generate if absent in local mode
  let ADA_JWT_SECRET = process.env.ADA_JWT_SECRET;
  if (!ADA_JWT_SECRET) {
    if (AUTH_MODE === 'local') {
      ADA_JWT_SECRET = randomBytes(32).toString('hex');
      console.warn('[ada-api] WARN: ADA_JWT_SECRET not set — auto-generated ephemeral secret. Set ADA_JWT_SECRET for persistence.');
    } else {
      throw new Error('ADA_JWT_SECRET is required when ADA_AUTH_MODE=server');
    }
  }

  // JWT TTL
  const ADA_JWT_TTL_RAW = process.env.ADA_JWT_TTL || '7d';
  const ADA_JWT_TTL = ADA_JWT_TTL_RAW;           // raw string (for jose)
  const ADA_JWT_TTL_SECONDS = parseTtlSeconds(ADA_JWT_TTL_RAW);

  // IPC
  const ADA_IPC_MODE = process.env.ADA_IPC_MODE || 'unix';
  if (!['unix', 'tcp'].includes(ADA_IPC_MODE)) {
    throw new Error(`ADA_IPC_MODE must be 'unix' or 'tcp', got: "${ADA_IPC_MODE}"`);
  }
  const ADA_IPC_SOCKET = process.env.ADA_IPC_SOCKET || '.claude/ada-core.sock';
  const ADA_IPC_HOST = process.env.ADA_IPC_HOST || '127.0.0.1';
  const ADA_IPC_PORT = parseIntEnv('ADA_IPC_PORT', 3099);
  const ADA_IPC_RECONNECT_DELAY = parseIntEnv('ADA_IPC_RECONNECT_DELAY', 5000);

  // CORS — ada-ui tourne sur 7777 en dev, accessible via localhost ou 127.0.0.1
  const CORS_ORIGINS = process.env.CORS_ORIGINS || 'http://localhost:7777,http://127.0.0.1:7777';

  // Logging
  const LOG_LEVEL = process.env.LOG_LEVEL || 'info';

  return {
    NODE_ENV,
    PORT,
    HOST,
    DB_PATH,
    AUTH_MODE,
    ADA_AUTH_MODE: AUTH_MODE,   // alias for spec compatibility
    ADA_AUTH_PASSWORD,
    ADA_JWT_SECRET,
    ADA_JWT_TTL,
    ADA_JWT_TTL_SECONDS,
    ADA_IPC_MODE,
    ADA_IPC_SOCKET,
    ADA_IPC_HOST,
    ADA_IPC_PORT,
    ADA_IPC_RECONNECT_DELAY,
    CORS_ORIGINS,
    LOG_LEVEL,
  };
}

export const env = buildEnv();
