/**
 * src/db/client.js
 * Singleton Drizzle + better-sqlite3 client with performance PRAGMAs.
 */
import Database from 'better-sqlite3';
import { drizzle } from 'drizzle-orm/better-sqlite3';
import * as schema from './schema.js';
import { env } from '../config/env.js';
import { mkdirSync } from 'fs';
import { dirname } from 'path';

function createClient() {
  // :memory: is a special SQLite path — no directory creation needed
  if (env.DB_PATH !== ':memory:') {
    mkdirSync(dirname(env.DB_PATH), { recursive: true });
  }

  const sqlite = new Database(env.DB_PATH);

  // Performance & safety PRAGMAs
  sqlite.pragma('journal_mode = WAL');
  sqlite.pragma('synchronous = NORMAL');
  sqlite.pragma('foreign_keys = ON');
  sqlite.pragma('temp_store = MEMORY');
  sqlite.pragma('mmap_size = 268435456');
  sqlite.pragma('cache_size = -16000');

  const drizzleDb = drizzle(sqlite, { schema });
  return { db: drizzleDb, sqlite };
}

const { db: _db, sqlite: _sqlite } = createClient();
export const db = _db;
// Expose the underlying better-sqlite3 instance for raw SQL access
export const sqlite = _sqlite;
