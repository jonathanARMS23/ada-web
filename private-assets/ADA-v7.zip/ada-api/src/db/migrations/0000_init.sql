-- Migration 0000_init.sql
-- ada-api — initial schema
-- Generated for SQLite (better-sqlite3 / Drizzle ORM)

-- ─── workspaces ───────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `workspaces` (
  `id`          TEXT PRIMARY KEY NOT NULL,
  `name`        TEXT NOT NULL,
  `slug`        TEXT NOT NULL,
  `profile`     TEXT NOT NULL,
  `description` TEXT,
  `color`       TEXT NOT NULL DEFAULT '#6366f1',
  `project_dir` TEXT,
  `pinned`      INTEGER NOT NULL DEFAULT 0,
  `archived`    INTEGER NOT NULL DEFAULT 0,
  `run_count`   INTEGER NOT NULL DEFAULT 0,
  `config`      TEXT NOT NULL DEFAULT '{}',
  `created_at`  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  `updated_at`  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE UNIQUE INDEX IF NOT EXISTS `idx_workspaces_slug`    ON `workspaces` (`slug`);
CREATE        INDEX IF NOT EXISTS `idx_workspaces_profile` ON `workspaces` (`profile`);

-- Auto-update updated_at on workspaces
CREATE TRIGGER IF NOT EXISTS trg_workspaces_updated_at
AFTER UPDATE ON `workspaces`
FOR EACH ROW
BEGIN
  UPDATE `workspaces`
  SET `updated_at` = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
  WHERE `id` = OLD.id;
END;

-- ─── conversations ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `conversations` (
  `id`           TEXT PRIMARY KEY NOT NULL,
  `workspace_id` TEXT NOT NULL REFERENCES `workspaces`(`id`) ON DELETE CASCADE,
  `title`        TEXT NOT NULL,
  `summary`      TEXT,
  `pinned`       INTEGER NOT NULL DEFAULT 0,
  `archived`     INTEGER NOT NULL DEFAULT 0,
  `run_count`    INTEGER NOT NULL DEFAULT 0,
  `last_run_id`  TEXT,
  `created_at`   TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  `updated_at`   TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE INDEX IF NOT EXISTS `idx_conversations_workspace_id` ON `conversations` (`workspace_id`);
CREATE INDEX IF NOT EXISTS `idx_conversations_updated_at`   ON `conversations` (`updated_at`);

-- Auto-update updated_at on conversations
CREATE TRIGGER IF NOT EXISTS trg_conversations_updated_at
AFTER UPDATE ON `conversations`
FOR EACH ROW
BEGIN
  UPDATE `conversations`
  SET `updated_at` = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
  WHERE `id` = OLD.id;
END;

-- ─── messages ─────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `messages` (
  `id`              TEXT PRIMARY KEY NOT NULL,
  `conversation_id` TEXT NOT NULL REFERENCES `conversations`(`id`) ON DELETE CASCADE,
  `role`            TEXT NOT NULL CHECK(`role` IN ('user','assistant','system','tool','error')),
  `content`         TEXT NOT NULL,
  `content_type`    TEXT NOT NULL DEFAULT 'text' CHECK(`content_type` IN ('text','code','run_status','phase_log')),
  `metadata`        TEXT NOT NULL DEFAULT '{}',
  `created_at`      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE INDEX IF NOT EXISTS `idx_messages_conversation_id` ON `messages` (`conversation_id`);
CREATE INDEX IF NOT EXISTS `idx_messages_created_at`      ON `messages` (`conversation_id`, `created_at`);

-- ─── run_links ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `run_links` (
  `run_id`          TEXT PRIMARY KEY NOT NULL,
  `conversation_id` TEXT REFERENCES `conversations`(`id`) ON DELETE RESTRICT,
  `workspace_id`    TEXT NOT NULL REFERENCES `workspaces`(`id`) ON DELETE RESTRICT,
  `pipeline`        TEXT NOT NULL,
  `status`          TEXT NOT NULL DEFAULT 'running'
                      CHECK(`status` IN ('running','completed','failed','cancelled','completed_with_errors')),
  `phases`          TEXT NOT NULL DEFAULT '{}',
  `total_cost`      REAL NOT NULL DEFAULT 0,
  `total_tokens`    INTEGER NOT NULL DEFAULT 0,
  `started_at`      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  `completed_at`    TEXT
);

-- ─── sessions ─────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `sessions` (
  `id`         TEXT PRIMARY KEY NOT NULL,
  `token_hash` TEXT NOT NULL,
  `expires_at` TEXT NOT NULL,
  `created_at` TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE UNIQUE INDEX IF NOT EXISTS `idx_sessions_token_hash` ON `sessions` (`token_hash`);
CREATE        INDEX IF NOT EXISTS `idx_sessions_expires_at` ON `sessions` (`expires_at`);

-- ─── workspace_settings ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `workspace_settings` (
  `workspace_id` TEXT NOT NULL REFERENCES `workspaces`(`id`) ON DELETE CASCADE,
  `key`          TEXT NOT NULL,
  `value`        TEXT,
  PRIMARY KEY (`workspace_id`, `key`)
);

-- ─── ipc_events ───────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `ipc_events` (
  `id`         TEXT PRIMARY KEY NOT NULL,
  `type`       TEXT NOT NULL,
  `payload`    TEXT NOT NULL,
  `processed`  INTEGER NOT NULL DEFAULT 0,
  `created_at` TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE INDEX IF NOT EXISTS `idx_ipc_events_processed` ON `ipc_events` (`processed`, `created_at`);
CREATE INDEX IF NOT EXISTS `idx_ipc_events_type`      ON `ipc_events` (`type`);
