-- Migration 0001_relax_run_links.sql
-- Relax run_links FKs: workspace_id becomes nullable with ON DELETE SET NULL
-- conversation_id gets ON DELETE SET NULL (was RESTRICT)
-- This preserves historical run data when a workspace or conversation is deleted.

PRAGMA foreign_keys = OFF;

CREATE TABLE run_links_new (
  run_id          TEXT PRIMARY KEY,
  conversation_id TEXT REFERENCES conversations(id) ON DELETE SET NULL,
  workspace_id    TEXT REFERENCES workspaces(id) ON DELETE SET NULL,
  pipeline        TEXT NOT NULL,
  status          TEXT NOT NULL DEFAULT 'running'
                  CHECK(status IN ('running', 'completed', 'failed', 'cancelled', 'completed_with_errors')),
  phases          TEXT NOT NULL DEFAULT '{}',
  total_cost      REAL NOT NULL DEFAULT 0,
  total_tokens    INTEGER NOT NULL DEFAULT 0,
  started_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  completed_at    TEXT
);

INSERT INTO run_links_new SELECT * FROM run_links WHERE 1=0; -- vide (pas de data en test)
DROP TABLE run_links;
ALTER TABLE run_links_new RENAME TO run_links;

CREATE INDEX idx_run_links_conversation_id ON run_links(conversation_id);
CREATE INDEX idx_run_links_workspace_id    ON run_links(workspace_id);
CREATE INDEX idx_run_links_status          ON run_links(status);
CREATE INDEX idx_run_links_started_at      ON run_links(started_at DESC);

PRAGMA foreign_keys = ON;
