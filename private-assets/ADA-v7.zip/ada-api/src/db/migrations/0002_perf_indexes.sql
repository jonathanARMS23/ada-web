-- Migration 0002 — Performance indexes
-- Adds missing indexes on run_links.started_at and ipc_events.created_at
-- for efficient time-windowed queries in /api/stats/observe

CREATE INDEX IF NOT EXISTS idx_run_links_started_at
  ON run_links (started_at);

CREATE INDEX IF NOT EXISTS idx_run_links_started_status
  ON run_links (started_at, status);

CREATE INDEX IF NOT EXISTS idx_ipc_events_created_at
  ON ipc_events (created_at);
