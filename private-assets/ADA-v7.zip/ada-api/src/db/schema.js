/**
 * src/db/schema.js
 * Drizzle ORM schema — 7 tables for ada-api
 */
import {
  sqliteTable,
  text,
  integer,
  real,
  primaryKey,
  index,
  uniqueIndex,
} from 'drizzle-orm/sqlite-core';
import { sql } from 'drizzle-orm';

const now = sql`(strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))`;

// ─── workspaces ───────────────────────────────────────────────────────────────
export const workspaces = sqliteTable('workspaces', {
  id:          text('id').primaryKey(),
  name:        text('name').notNull(),
  slug:        text('slug').notNull().unique(),
  profile:     text('profile').notNull(),
  description: text('description'),
  color:       text('color').notNull().default('#6366f1'),
  project_dir: text('project_dir'),
  pinned:      integer('pinned', { mode: 'boolean' }).notNull().default(false),
  archived:    integer('archived', { mode: 'boolean' }).notNull().default(false),
  run_count:   integer('run_count').notNull().default(0),
  config:      text('config').notNull().default('{}'),
  created_at:  text('created_at').notNull().default(now),
  updated_at:  text('updated_at').notNull().default(now),
}, (t) => ({
  slugIdx:    uniqueIndex('idx_workspaces_slug').on(t.slug),
  profileIdx: index('idx_workspaces_profile').on(t.profile),
}));

// ─── conversations ────────────────────────────────────────────────────────────
export const conversations = sqliteTable('conversations', {
  id:           text('id').primaryKey(),
  workspace_id: text('workspace_id').notNull().references(() => workspaces.id, { onDelete: 'cascade' }),
  title:        text('title').notNull(),
  summary:      text('summary'),
  pinned:       integer('pinned', { mode: 'boolean' }).notNull().default(false),
  archived:     integer('archived', { mode: 'boolean' }).notNull().default(false),
  run_count:    integer('run_count').notNull().default(0),
  last_run_id:  text('last_run_id'),
  created_at:   text('created_at').notNull().default(now),
  updated_at:   text('updated_at').notNull().default(now),
}, (t) => ({
  workspaceIdx: index('idx_conversations_workspace_id').on(t.workspace_id),
  updatedAtIdx: index('idx_conversations_updated_at').on(t.updated_at),
}));

// ─── messages ─────────────────────────────────────────────────────────────────
export const messages = sqliteTable('messages', {
  id:              text('id').primaryKey(),
  conversation_id: text('conversation_id').notNull().references(() => conversations.id, { onDelete: 'cascade' }),
  role:            text('role', { enum: ['user', 'assistant', 'system', 'tool', 'error'] }).notNull(),
  content:         text('content').notNull(),
  content_type:    text('content_type', { enum: ['text', 'code', 'run_status', 'phase_log'] }).notNull().default('text'),
  metadata:        text('metadata').notNull().default('{}'),
  created_at:      text('created_at').notNull().default(now),
}, (t) => ({
  conversationIdx: index('idx_messages_conversation_id').on(t.conversation_id),
  createdAtIdx:    index('idx_messages_created_at').on(t.conversation_id, t.created_at),
}));

// ─── run_links ────────────────────────────────────────────────────────────────
export const run_links = sqliteTable('run_links', {
  run_id:          text('run_id').primaryKey(),
  conversation_id: text('conversation_id').references(() => conversations.id, { onDelete: 'set null' }),
  workspace_id:    text('workspace_id').references(() => workspaces.id, { onDelete: 'set null' }),
  pipeline:        text('pipeline').notNull(),
  status:          text('status', { enum: ['running', 'completed', 'failed', 'cancelled', 'completed_with_errors'] }).notNull().default('running'),
  phases:          text('phases').notNull().default('{}'),
  total_cost:      real('total_cost').notNull().default(0),
  total_tokens:    integer('total_tokens').notNull().default(0),
  started_at:      text('started_at').notNull().default(now),
  completed_at:    text('completed_at'),
});

// ─── sessions ─────────────────────────────────────────────────────────────────
export const sessions = sqliteTable('sessions', {
  id:         text('id').primaryKey(),
  token_hash: text('token_hash').notNull().unique(),
  expires_at: text('expires_at').notNull(),
  created_at: text('created_at').notNull().default(now),
}, (t) => ({
  tokenHashIdx: uniqueIndex('idx_sessions_token_hash').on(t.token_hash),
  expiresAtIdx: index('idx_sessions_expires_at').on(t.expires_at),
}));

// ─── workspace_settings ───────────────────────────────────────────────────────
export const workspace_settings = sqliteTable('workspace_settings', {
  workspace_id: text('workspace_id').notNull().references(() => workspaces.id, { onDelete: 'cascade' }),
  key:          text('key').notNull(),
  value:        text('value'),
}, (t) => ({
  pk: primaryKey({ columns: [t.workspace_id, t.key] }),
}));

// ─── ipc_events ───────────────────────────────────────────────────────────────
export const ipc_events = sqliteTable('ipc_events', {
  id:         text('id').primaryKey(),
  type:       text('type').notNull(),
  payload:    text('payload').notNull(),
  processed:  integer('processed', { mode: 'boolean' }).notNull().default(false),
  created_at: text('created_at').notNull().default(now),
}, (t) => ({
  processedIdx: index('idx_ipc_events_processed').on(t.processed, t.created_at),
  typeIdx:      index('idx_ipc_events_type').on(t.type),
}));
