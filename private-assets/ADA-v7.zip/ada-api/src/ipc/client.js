/**
 * src/ipc/client.js
 * IPC client — Unix socket → TCP fallback → file fallback.
 * Auto-reconnects on connection loss.
 */
import net from 'net';
import { EventEmitter } from 'events';
import { NdjsonParser } from './parser.js';

const HELLO = JSON.stringify({ type: 'hello', version: '1.0', service: 'ada-api' }) + '\n';

export class IpcClient extends EventEmitter {
  /**
   * @param {object} config
   * @param {string}  config.socketPath       - Unix socket path
   * @param {'unix'|'tcp'} config.mode        - connection mode
   * @param {string}  [config.tcpHost]        - TCP host
   * @param {number}  [config.tcpPort]        - TCP port
   * @param {number}  [config.reconnectDelay] - ms between reconnect attempts
   * @param {boolean} [config.tcpFallback]    - whether to attempt TCP fallback (default true)
   */
  constructor(config = {}) {
    super();
    this._socketPath = config.socketPath || '.claude/ada-core.sock';
    this._mode = config.mode || 'unix';
    this._tcpHost = config.tcpHost || '127.0.0.1';
    this._tcpPort = config.tcpPort || 3099;
    this._reconnectDelay = config.reconnectDelay ?? 5000;
    this._tcpFallback = config.tcpFallback !== false; // default true

    this._socket = null;
    this._parser = new NdjsonParser();
    this._reconnectTimer = null;
    this._destroyed = false;
    this.connected = false;
  }

  // ─── Public API ─────────────────────────────────────────────────────────────

  connect() {
    if (this._destroyed) return;
    this._tryUnix();
  }

  disconnect() {
    this._destroyed = true;
    this._clearReconnect();
    if (this._socket) {
      this._socket.destroy();
      this._socket = null;
    }
    this.connected = false;
  }

  // ─── Private ────────────────────────────────────────────────────────────────

  _tryUnix() {
    if (this._destroyed) return;
    const sock = net.createConnection({ path: this._socketPath });
    this._attachHandlers(sock, 'unix');
    sock.once('error', (err) => {
      if (['ENOENT', 'ECONNREFUSED'].includes(err.code)) {
        sock.destroy();
        if (this._tcpFallback) {
          this._tryTcp();
        } else {
          console.info('[ada-api] INFO: IPC: fallback mode active (no socket, tcpFallback=false)');
          this.emit('fallback:file');
          this._scheduleReconnect();
        }
      }
      // other errors are swallowed — the 'close' handler will reconnect
    });
  }

  _tryTcp() {
    if (this._destroyed) return;
    const sock = net.createConnection({ host: this._tcpHost, port: this._tcpPort });
    this._attachHandlers(sock, 'tcp');
    sock.once('error', (err) => {
      if (['ECONNREFUSED', 'ETIMEDOUT', 'ENOTFOUND'].includes(err.code)) {
        console.info('[ada-api] INFO: IPC: fallback mode active (events.ndjson)');
        this.emit('fallback:file');
        this._scheduleReconnect();
      }
    });
  }

  _attachHandlers(sock, label) {
    this._socket = sock;

    sock.once('connect', () => {
      this.connected = true;
      this._parser.reset();
      sock.write(HELLO);
      this.emit('connect', label);
    });

    sock.on('data', (chunk) => {
      const messages = this._parser.feed(chunk);
      for (const { parsed, rawLine } of messages) {
        this.emit('message', parsed, rawLine);
      }
    });

    sock.once('close', () => {
      this.connected = false;
      this.emit('disconnect');
      if (!this._destroyed) {
        this._scheduleReconnect();
      }
    });

    // Prevent unhandled error events from crashing the process
    sock.on('error', (err) => {
      // errors handled per-connect-attempt above; here we just absorb
      if (!['ENOENT', 'ECONNREFUSED', 'ETIMEDOUT', 'ENOTFOUND'].includes(err.code)) {
        console.warn(`[ada-api] WARN: IPC socket error (${label}): ${err.message}`);
      }
    });
  }

  _scheduleReconnect() {
    if (this._destroyed || this._reconnectTimer) return;
    this._reconnectTimer = setTimeout(() => {
      this._reconnectTimer = null;
      if (!this._destroyed) {
        this._tryUnix();
      }
    }, this._reconnectDelay);
  }

  _clearReconnect() {
    if (this._reconnectTimer) {
      clearTimeout(this._reconnectTimer);
      this._reconnectTimer = null;
    }
  }
}
