/**
 * src/ipc/handler.js
 * Dispatches IPC events → DB writes + WebSocket broadcast.
 */
import { eq, and } from 'drizzle-orm';
import { v4 as uuidv4 } from 'uuid';
import { sql } from 'drizzle-orm';
import { createHmac } from 'crypto';
import * as schema from '../db/schema.js';

// Final statuses — do not overwrite once reached
const FINAL_STATUSES = new Set(['completed', 'failed', 'cancelled', 'completed_with_errors']);

export class IpcHandler {
  /**
   * @param {import('drizzle-orm/better-sqlite3').BetterSQLite3Database} db
   * @param {function(object): void} broadcast  - WS broadcast callback
   */
  constructor(db, broadcast) {
    this._db = db;
    this._broadcast = broadcast;
  }

  /**
   * Handle a parsed IPC event.
   * @param {object} event
   * @param {string|null} [rawLine] - Original NDJSON line (before parsing) for HMAC verification
   */
  async handle(event, rawLine = null) {
    if (!event || !event.type) return;

    // ── HMAC verification ────────────────────────────────────────────────────
    const secret = process.env.ADA_IPC_HMAC_SECRET;
    if (secret && rawLine) {
      const sig = event._sig;
      if (!sig) {
        console.warn('[ada-api] WARN: IPC event missing _sig — rejected');
        return;
      }
      // Reconstituer la ligne sans _sig pour vérifier (même construction que ipc-emit)
      const { _sig: _removed, ...eventWithoutSig } = event;
      const expectedLine = JSON.stringify(eventWithoutSig) + '\n';
      const expected = createHmac('sha256', secret).update(expectedLine).digest('hex');
      if (sig !== expected) {
        console.warn('[ada-api] WARN: IPC event invalid signature — rejected');
        return;
      }
    }

    // Persist all IPC events for stats/audit
    try {
      this._db.insert(schema.ipc_events).values({
        id:      uuidv4(),
        type:    event.type,
        payload: JSON.stringify(event),
      }).run();
    } catch { /* best-effort */ }

    switch (event.type) {
      case 'run.started':
        await this._onRunStarted(event);
        break;
      case 'run.phase.started':
        this._broadcast(event);
        break;
      case 'run.phase.log':
        this._broadcast(event);
        break;
      case 'run.phase.done':
        this._broadcast(event);
        break;
      case 'run.done':
        await this._onRunDone(event);
        break;
      default:
        console.warn(`[ada-api] WARN: IPC: unknown event type: ${event.type}`);
    }
  }

  // ─── Handlers ───────────────────────────────────────────────────────────────

  async _onRunStarted(event) {
    const data = event.payload ?? event;   // unwrap IPC envelope
    const {
      runId,
      pipeline,
      workspaceId,
      conversationId = null,
    } = data;

    if (!runId || !pipeline || !workspaceId) {
      console.warn('[ada-api] WARN: run.started missing required fields:', event);
      return;
    }

    // Idempotent upsert using INSERT OR REPLACE
    this._db.insert(schema.run_links).values({
      run_id:          runId,
      conversation_id: conversationId || null,
      workspace_id:    workspaceId,
      pipeline,
      status:          'running',
    }).onConflictDoNothing().run();

    // If conversationId present, touch updated_at
    if (conversationId) {
      this._db.update(schema.conversations)
        .set({ updated_at: sql`(strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))` })
        .where(eq(schema.conversations.id, conversationId))
        .run();
    }

    this._broadcast(event);
  }

  async _onRunDone(event) {
    const data = event.payload ?? event;   // unwrap IPC envelope
    const {
      runId,
      status = 'completed',
      totalCost = 0,
      totalTokens = 0,
      conversationId = null,
    } = data;

    if (!runId) {
      console.warn('[ada-api] WARN: run.done missing runId:', event);
      return;
    }

    // Check current status — don't overwrite a final status
    const existing = this._db.select().from(schema.run_links)
      .where(eq(schema.run_links.run_id, runId))
      .get();

    if (!existing) {
      // run.done arrived before run.started — just broadcast
      this._broadcast(event);
      return;
    }

    if (!FINAL_STATUSES.has(existing.status)) {
      // Update to final state
      this._db.update(schema.run_links)
        .set({
          status,
          total_cost:   totalCost,
          total_tokens: totalTokens,
          completed_at: sql`(strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))`,
        })
        .where(eq(schema.run_links.run_id, runId))
        .run();
    }

    // Create run_status message if conversationId is present
    if (conversationId) {
      // Check for duplicate message (idempotence) — O(1) targeted query
      const duplicate = this._db.select({ id: schema.messages.id })
        .from(schema.messages)
        .where(
          and(
            eq(schema.messages.conversation_id, conversationId),
            eq(schema.messages.content_type, 'run_status'),
            sql`json_extract(${schema.messages.metadata}, '$.runId') = ${runId}`
          )
        )
        .get();

      if (!duplicate) {
        this._db.insert(schema.messages).values({
          id:              uuidv4(),
          conversation_id: conversationId,
          role:            'assistant',
          content:         JSON.stringify({ runId, status, totalCost, totalTokens }),
          content_type:    'run_status',
          metadata:        JSON.stringify({ runId }),
        }).run();

        // Increment run_count
        this._db.update(schema.conversations)
          .set({
            run_count:   sql`run_count + 1`,
            last_run_id: runId,
            updated_at:  sql`(strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))`,
          })
          .where(eq(schema.conversations.id, conversationId))
          .run();
      }
    }

    this._broadcast(event);
  }
}
