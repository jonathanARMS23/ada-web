/**
 * src/ipc/parser.js
 * NDJSON stream parser — handles TCP partial chunks and multi-message chunks.
 */

const MAX_BUFFER_SIZE = 1024 * 1024; // 1 MB — protection contre les senders malveillants

export class NdjsonParser {
  constructor() {
    this._buffer = '';
  }

  /**
   * Feed a raw chunk string (or Buffer) received from the socket.
   * Returns an array of parsed JSON objects (may be empty).
   *
   * @param {string|Buffer} chunk
   * @returns {Array<{parsed: object, rawLine: string}>}
   */
  feed(chunk) {
    this._buffer += typeof chunk === 'string' ? chunk : chunk.toString('utf8');

    if (this._buffer.length > MAX_BUFFER_SIZE) {
      console.warn(`[ada-api] WARN: NDJSON buffer overflow (${this._buffer.length} bytes) — resetting`);
      this._buffer = '';
      return [];
    }

    const results = [];
    let newlineIdx;

    // Process all complete lines delimited by \n
    while ((newlineIdx = this._buffer.indexOf('\n')) !== -1) {
      const line = this._buffer.slice(0, newlineIdx);
      this._buffer = this._buffer.slice(newlineIdx + 1);

      // Skip empty lines
      if (line.trim() === '') continue;

      try {
        const parsed = JSON.parse(line);
        // Attach rawLine (with trailing \n) so handle() can verify HMAC
        results.push({ parsed, rawLine: line + '\n' });
      } catch {
        console.warn(`[ada-api] WARN: NDJSON parse error — invalid JSON line: ${line}`);
      }
    }

    return results;
  }

  /**
   * Reset the internal buffer (e.g. on reconnect).
   */
  reset() {
    this._buffer = '';
  }
}
