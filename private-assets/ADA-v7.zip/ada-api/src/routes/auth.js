/**
 * src/routes/auth.js
 * Auth routes: token issuance, refresh, and session deletion.
 *
 * POST   /api/auth/token    — issue token (public)
 * POST   /api/auth/refresh  — refresh token (protected)
 * DELETE /api/auth/session  — logout (protected)
 */
import { v4 as uuidv4 } from 'uuid';
import { timingSafeEqual } from 'crypto';
import { signToken, hashToken } from '../auth/jwt.js';

/**
 * @param {import('fastify').FastifyInstance} fastify
 * @param {object} options
 */
export async function authRoutes(fastify, options) {
  const { sqlite, jwtSecret, jwtTtlSeconds, authMode, authPassword } = fastify;

  // Prepared statements (reused across requests)
  const stmtInsertSession = sqlite.prepare(
    'INSERT INTO sessions (id, token_hash, expires_at) VALUES (?, ?, ?)'
  );
  const stmtDeleteSession = sqlite.prepare(
    'DELETE FROM sessions WHERE token_hash = ?'
  );

  // ─── Helper: issue token and persist hash ──────────────────────────────────
  async function issueToken() {
    const { token, expiresAt, exp } = await signToken({}, jwtSecret, jwtTtlSeconds);
    const tokenHash = hashToken(token);
    stmtInsertSession.run(uuidv4(), tokenHash, new Date(exp * 1000).toISOString());
    return { token, expiresAt, tokenType: 'Bearer' };
  }

  // ─── POST /api/auth/token ──────────────────────────────────────────────────
  fastify.post('/api/auth/token', {
    config: {
      skipAuth: true,
      rateLimit: {
        max: 10,
        timeWindow: '15 minutes',
        // Bypass rate-limit from loopback addresses (tests, local dev)
        allowList: ['127.0.0.1', '::1', '::ffff:127.0.0.1'],
      },
    },
  }, async (request, reply) => {
    if (authMode === 'server') {
      const { password } = request.body ?? {};

      if (!password) {
        return reply.code(400).send({
          error: 'PASSWORD_REQUIRED',
          message: 'Password is required in server mode',
        });
      }

      const pwBuf   = Buffer.from(password);
      const authBuf = Buffer.from(authPassword);
      // Pad both buffers to the same length before timingSafeEqual to avoid
      // leaking password length via short-circuit timing.
      const maxLen  = Math.max(pwBuf.length, authBuf.length);
      const padPw   = Buffer.alloc(maxLen);
      const padAuth = Buffer.alloc(maxLen);
      pwBuf.copy(padPw);
      authBuf.copy(padAuth);
      const match = timingSafeEqual(padPw, padAuth) && pwBuf.length === authBuf.length;
      if (!match) {
        return reply.code(401).send({
          error: 'INVALID_PASSWORD',
          message: 'Invalid password',
        });
      }
    }

    const result = await issueToken();
    return reply.code(200).send(result);
  });

  // ─── POST /api/auth/refresh ────────────────────────────────────────────────
  fastify.post('/api/auth/refresh', async (request, reply) => {
    // authMiddleware has already validated T1 and attached request.user
    // Extract old token hash from the Authorization header
    const oldToken = request.headers.authorization.slice(7);
    const oldHash = hashToken(oldToken);

    // Issue T2
    const { token: newToken, expiresAt, exp } = await signToken({}, jwtSecret, jwtTtlSeconds);
    const newHash = hashToken(newToken);

    // Atomic swap: delete T1, insert T2
    const swap = sqlite.transaction(() => {
      stmtDeleteSession.run(oldHash);
      stmtInsertSession.run(uuidv4(), newHash, new Date(exp * 1000).toISOString());
    });
    swap();

    return reply.code(200).send({ token: newToken, expiresAt, tokenType: 'Bearer' });
  });

  // ─── DELETE /api/auth/session ──────────────────────────────────────────────
  fastify.delete('/api/auth/session', async (request, reply) => {
    // authMiddleware validated the token already
    const token = request.headers.authorization.slice(7);
    const tokenHash = hashToken(token);

    // Idempotent: delete may affect 0 rows — that's fine
    stmtDeleteSession.run(tokenHash);

    return reply.code(204).send();
  });

  // ─── GET /api/ws/ticket ────────────────────────────────────────────────────
  // wsTickets est décoré au niveau racine dans app.js — partagé avec wsGateway
  const wsTickets = fastify.wsTickets;

  // Nettoyage périodique des tickets expirés
  const ticketCleanupInterval = setInterval(() => {
    const now = Date.now();
    for (const [id, t] of wsTickets.entries()) {
      if (t.expiresAt < now) wsTickets.delete(id);
    }
  }, 5 * 60 * 1000);
  if (ticketCleanupInterval.unref) ticketCleanupInterval.unref();

  fastify.get('/api/ws/ticket', {
    config: { rateLimit: { max: 60, timeWindow: '1 minute' } },
  }, async (request, reply) => {
    const authHeader = request.headers.authorization ?? '';
    const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : '';
    if (!token) return reply.code(401).send({ error: 'UNAUTHORIZED' });

    const tokenHash = hashToken(token);
    const session = sqlite.prepare('SELECT id FROM sessions WHERE token_hash = ?').get(tokenHash);
    if (!session) return reply.code(401).send({ error: 'TOKEN_REVOKED' });

    // Cleanup expired tickets (best-effort)
    const now = Date.now();
    for (const [id, t] of wsTickets.entries()) {
      if (t.expiresAt < now) wsTickets.delete(id);
    }

    const ticketId = uuidv4();
    wsTickets.set(ticketId, { tokenHash, expiresAt: now + 30_000 });

    return reply.code(200).send({
      ticket: ticketId,
      expiresAt: new Date(now + 30_000).toISOString(),
    });
  });
}
