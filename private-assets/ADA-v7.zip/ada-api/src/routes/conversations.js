/**
 * src/routes/conversations.js
 * Fastify plugin — conversations + messages CRUD + workspace search.
 *
 * All routes are protected by the global authMiddleware defined in app.js.
 *
 * Routes:
 *   POST   /api/workspaces/:wid/conversations
 *   GET    /api/workspaces/:wid/conversations
 *   GET    /api/workspaces/:wid/search
 *   GET    /api/conversations/:id
 *   PATCH  /api/conversations/:id
 *   DELETE /api/conversations/:id
 *   POST   /api/conversations/:id/messages
 *   GET    /api/conversations/:id/messages
 */

import { v4 as uuidv4 } from 'uuid';
import { formatConversation, formatMessage } from '../services/conversation.js';

const VALID_ROLES        = ['user', 'assistant', 'system', 'tool', 'error'];
const VALID_CONTENT_TYPES = ['text', 'code', 'run_status', 'phase_log'];

/**
 * @param {import('fastify').FastifyInstance} fastify
 * @param {object} _options
 */
export async function conversationRoutes(fastify, _options) {
  const { sqlite } = fastify;

  // ─── Prepared statements ─────────────────────────────────────────────────────

  // Workspaces
  const stmtFindWorkspace = sqlite.prepare(
    'SELECT id FROM workspaces WHERE id = ?'
  );
  const stmtTouchWorkspace = sqlite.prepare(
    "UPDATE workspaces SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?"
  );

  // Conversations
  const stmtInsertConversation = sqlite.prepare(
    'INSERT INTO conversations (id, workspace_id, title) VALUES (?, ?, ?)'
  );
  const stmtFindConversation = sqlite.prepare(
    'SELECT * FROM conversations WHERE id = ?'
  );
  const stmtDeleteConversation = sqlite.prepare(
    'DELETE FROM conversations WHERE id = ?'
  );
  const stmtCountMessages = sqlite.prepare(
    'SELECT COUNT(*) AS cnt FROM messages WHERE conversation_id = ?'
  );
  const stmtTouchConversation = sqlite.prepare(
    "UPDATE conversations SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?"
  );

  // Messages
  const stmtInsertMessage = sqlite.prepare(
    'INSERT INTO messages (id, conversation_id, role, content, content_type, metadata) VALUES (?, ?, ?, ?, ?, ?)'
  );
  const stmtFindMessage = sqlite.prepare(
    'SELECT * FROM messages WHERE id = ?'
  );

  // ─── Helper: fetch conversation or 404 ───────────────────────────────────────
  function requireConversation(id, reply) {
    const row = stmtFindConversation.get(id);
    if (!row) {
      reply.code(404).send({ error: 'CONVERSATION_NOT_FOUND', message: 'Conversation not found' });
      return null;
    }
    return row;
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // POST /api/workspaces/:wid/conversations
  // ═══════════════════════════════════════════════════════════════════════════
  fastify.post('/api/workspaces/:wid/conversations', async (request, reply) => {
    const { wid } = request.params;

    // Verify workspace exists
    const ws = stmtFindWorkspace.get(wid);
    if (!ws) {
      return reply.code(404).send({ error: 'WORKSPACE_NOT_FOUND', message: 'Workspace not found' });
    }

    const { title = null, description = null } = request.body ?? {};

    if (title && title.length > 500) {
      return reply.code(400).send({ error: 'VALIDATION_ERROR', message: 'title exceeds 500 chars limit' });
    }

    const id = uuidv4();
    // title is NOT NULL in DB — use empty string when not provided
    stmtInsertConversation.run(id, wid, title ?? '');

    // Touch workspace.updated_at
    stmtTouchWorkspace.run(wid);

    const row = stmtFindConversation.get(id);
    return reply.code(201).send(formatConversation(row, 0));
  });

  // ═══════════════════════════════════════════════════════════════════════════
  // GET /api/workspaces/:wid/conversations
  // ═══════════════════════════════════════════════════════════════════════════
  fastify.get('/api/workspaces/:wid/conversations', async (request, reply) => {
    const { wid } = request.params;
    const {
      limit: rawLimit = '20',
      cursor,
      archived: rawArchived = 'false',
      pinned: rawPinned,
    } = request.query;

    const limit    = Math.min(Math.max(1, parseInt(rawLimit, 10) || 20), 100);
    const archived = rawArchived === 'true';

    // Build WHERE conditions
    const conditions  = ['workspace_id = ?'];
    const countParams = [wid];
    const listParams  = [wid];

    if (rawPinned !== undefined) {
      const pinned = rawPinned === 'true';
      conditions.push('pinned = ?');
      countParams.push(pinned ? 1 : 0);
      listParams.push(pinned ? 1 : 0);
    }

    // Archived filter: default false → show non-archived; true → show archived
    conditions.push('archived = ?');
    countParams.push(archived ? 1 : 0);
    listParams.push(archived ? 1 : 0);

    const whereClause = conditions.join(' AND ');

    // Total count (without cursor pagination — for display purposes)
    const { cnt: total } = sqlite
      .prepare(`SELECT COUNT(*) AS cnt FROM conversations WHERE ${whereClause}`)
      .get(...countParams);

    // Cursor pagination: find updated_at of cursor item
    let cursorCondition = '';
    if (cursor) {
      const cursorRow = sqlite
        .prepare('SELECT updated_at FROM conversations WHERE id = ? AND workspace_id = ?')
        .get(cursor, wid);
      if (cursorRow) {
        cursorCondition = 'AND c.updated_at < ?';
        listParams.push(cursorRow.updated_at);
      }
    }

    // Fetch limit+1 avec COUNT inline pour éviter N+1
    const rows = sqlite
      .prepare(
        `SELECT c.*,
           (SELECT COUNT(*) FROM messages m WHERE m.conversation_id = c.id) AS message_count
         FROM conversations c
         WHERE ${whereClause} ${cursorCondition}
         ORDER BY c.updated_at DESC
         LIMIT ?`
      )
      .all(...listParams, limit + 1);

    const hasMore    = rows.length > limit;
    const pageRows   = hasMore ? rows.slice(0, limit) : rows;
    const nextCursor = hasMore ? pageRows[pageRows.length - 1].id : null;

    const items = pageRows.map((row) => formatConversation(row, row.message_count ?? 0));

    return reply.code(200).send({ items, nextCursor, hasMore, total });
  });

  // ═══════════════════════════════════════════════════════════════════════════
  // GET /api/conversations/:id
  // ═══════════════════════════════════════════════════════════════════════════
  fastify.get('/api/conversations/:id', async (request, reply) => {
    const { id } = request.params;
    const row = requireConversation(id, reply);
    if (!row) return;

    const { cnt } = stmtCountMessages.get(id);
    return reply.code(200).send(formatConversation(row, cnt));
  });

  // ═══════════════════════════════════════════════════════════════════════════
  // PATCH /api/conversations/:id
  // ═══════════════════════════════════════════════════════════════════════════
  fastify.patch('/api/conversations/:id', async (request, reply) => {
    const { id } = request.params;
    const row = requireConversation(id, reply);
    if (!row) return;

    const body = request.body ?? {};
    const patchableFields = ['title', 'pinned', 'archived', 'summary'];

    // Build SET clause dynamically from provided fields
    const sets   = [];
    const params = [];

    for (const field of patchableFields) {
      if (!(field in body)) continue;
      const val = body[field];

      // Type + length validation per field
      if ((field === 'pinned' || field === 'archived') && typeof val !== 'boolean') {
        return reply.code(400).send({ error: 'VALIDATION_ERROR', message: `${field} must be boolean` });
      }
      if (field === 'title') {
        if (typeof val !== 'string') return reply.code(400).send({ error: 'VALIDATION_ERROR', message: 'title must be a string' });
        if (val.length > 500)        return reply.code(400).send({ error: 'VALIDATION_ERROR', message: 'title exceeds 500 chars' });
      }
      if (field === 'summary') {
        if (typeof val !== 'string') return reply.code(400).send({ error: 'VALIDATION_ERROR', message: 'summary must be a string' });
        if (val.length > 10_000)     return reply.code(400).send({ error: 'VALIDATION_ERROR', message: 'summary exceeds 10KB' });
      }

      sets.push(`${field} = ?`);
      // Boolean fields stored as 0/1 in SQLite
      params.push(typeof val === 'boolean' ? (val ? 1 : 0) : val);
    }

    if (sets.length > 0) {
      // Always touch updated_at on patch
      sets.push("updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')");
      params.push(id);
      sqlite.prepare(`UPDATE conversations SET ${sets.join(', ')} WHERE id = ?`).run(...params);
    }

    const updated = stmtFindConversation.get(id);
    const { cnt }  = stmtCountMessages.get(id);
    return reply.code(200).send(formatConversation(updated, cnt));
  });

  // ═══════════════════════════════════════════════════════════════════════════
  // DELETE /api/conversations/:id
  // ═══════════════════════════════════════════════════════════════════════════
  fastify.delete('/api/conversations/:id', async (request, reply) => {
    const { id } = request.params;
    const row = requireConversation(id, reply);
    if (!row) return;

    stmtDeleteConversation.run(id);
    return reply.code(204).send();
  });

  // ═══════════════════════════════════════════════════════════════════════════
  // POST /api/conversations/:id/messages
  // ═══════════════════════════════════════════════════════════════════════════
  fastify.post('/api/conversations/:id/messages', async (request, reply) => {
    const { id } = request.params;
    const row = requireConversation(id, reply);
    if (!row) return;

    const { role, content, contentType = 'text', metadata } = request.body ?? {};

    // Validation: role
    if (!role || !VALID_ROLES.includes(role)) {
      return reply.code(400).send({
        error:   'VALIDATION_ERROR',
        message: 'role must be one of: user, assistant, system, tool, error',
      });
    }

    // Validation: content
    if (!content && content !== 0) {
      return reply.code(400).send({
        error:   'VALIDATION_ERROR',
        message: 'content is required',
      });
    }

    if (typeof content === 'string' && content.length > 100_000) {
      return reply.code(400).send({ error: 'VALIDATION_ERROR', message: 'content exceeds 100KB limit' });
    }

    // Validation: contentType
    const resolvedContentType = VALID_CONTENT_TYPES.includes(contentType) ? contentType : 'text';

    // Serialize metadata
    const metadataStr =
      metadata && typeof metadata === 'object' ? JSON.stringify(metadata) : '{}';

    const msgId = uuidv4();
    stmtInsertMessage.run(msgId, id, role, content, resolvedContentType, metadataStr);

    // Touch conversation.updated_at
    stmtTouchConversation.run(id);

    const msgRow = stmtFindMessage.get(msgId);
    const formatted = formatMessage(msgRow);

    // WS broadcast — fire-and-forget, must not crash if room is empty
    try {
      fastify.wsRooms.broadcast(row.workspace_id, {
        type:           'message.new',
        conversationId: id,
        message:        formatted,
      });
    } catch {
      // Ignore broadcast errors
    }

    return reply.code(201).send(formatted);
  });

  // ═══════════════════════════════════════════════════════════════════════════
  // GET /api/conversations/:id/messages
  // ═══════════════════════════════════════════════════════════════════════════
  fastify.get('/api/conversations/:id/messages', async (request, reply) => {
    const { id } = request.params;
    const row = requireConversation(id, reply);
    if (!row) return;

    const {
      limit: rawLimit = '50',
      cursor,
      contentType,
    } = request.query;

    const limit = Math.min(Math.max(1, parseInt(rawLimit, 10) || 50), 200);

    // Build WHERE conditions
    const conditions  = ['conversation_id = ?'];
    const listParams  = [id];

    if (contentType && VALID_CONTENT_TYPES.includes(contentType)) {
      conditions.push('content_type = ?');
      listParams.push(contentType);
    }

    // Cursor pagination: find created_at of cursor message
    if (cursor) {
      const cursorMsg = sqlite
        .prepare('SELECT created_at FROM messages WHERE id = ?')
        .get(cursor);
      if (cursorMsg) {
        conditions.push('created_at < ?');
        listParams.push(cursorMsg.created_at);
      }
    }

    const whereClause = conditions.join(' AND ');

    // Fetch limit+1 to determine hasMore without a separate COUNT query
    const rows = sqlite
      .prepare(
        `SELECT * FROM messages WHERE ${whereClause} ORDER BY created_at DESC LIMIT ?`
      )
      .all(...listParams, limit + 1);

    const hasMore    = rows.length > limit;
    const pageRows   = hasMore ? rows.slice(0, limit) : rows;
    const nextCursor = hasMore ? pageRows[pageRows.length - 1].id : null;
    const items      = pageRows.map(formatMessage);

    return reply.code(200).send({ items, nextCursor, hasMore });
  });

  // ═══════════════════════════════════════════════════════════════════════════
  // GET /api/workspaces/:wid/search
  // ═══════════════════════════════════════════════════════════════════════════
  fastify.get('/api/workspaces/:wid/search', async (request, reply) => {
    const { wid } = request.params;
    const { q } = request.query;

    // Validate q param
    if (!q || q.trim() === '') {
      return reply.code(400).send({
        error:   'VALIDATION_ERROR',
        message: 'Query param "q" is required',
      });
    }

    // Verify workspace exists
    const ws = stmtFindWorkspace.get(wid);
    if (!ws) {
      return reply.code(404).send({ error: 'WORKSPACE_NOT_FOUND', message: 'Workspace not found' });
    }

    const term = q.trim();

    if (term.length > 200) {
      return reply.code(400).send({ error: 'VALIDATION_ERROR', message: 'q exceeds 200 chars' });
    }

    const rows = sqlite
      .prepare(
        `SELECT m.id AS message_id, m.conversation_id, c.title AS conversation_title,
                m.content, m.created_at
         FROM messages m
         JOIN conversations c ON c.id = m.conversation_id
         WHERE c.workspace_id = ? AND m.content LIKE '%' || ? || '%'
         ORDER BY m.created_at DESC
         LIMIT 50`
      )
      .all(wid, term);

    const items = rows.map((r) => ({
      messageId:         r.message_id,
      conversationId:    r.conversation_id,
      conversationTitle: r.conversation_title,
      content:           r.content,
      createdAt:         r.created_at,
    }));

    return reply.code(200).send({ items, total: items.length });
  });
}
