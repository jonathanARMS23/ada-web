/**
 * src/routes/health.js
 * Health check routes — all public (no auth required).
 *
 * GET /api/health       — full status (DB, IPC, WS, version, uptime)
 * GET /api/health/live  — liveness probe (always 200 if process is alive)
 * GET /api/health/ready — readiness probe (503 if DB unavailable)
 */

import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const pkg       = JSON.parse(readFileSync(join(__dirname, '../../package.json'), 'utf-8'));

/** Module-level start timestamp — singleton per Vitest worker / process. */
const startedAt = Date.now();

/**
 * @param {import('fastify').FastifyInstance} fastify
 */
export async function healthRoutes(fastify) {

  // ─── GET /api/health ──────────────────────────────────────────────────────
  fastify.get('/api/health', async (req, reply) => {
    // DB check
    let dbStatus = 'ok';
    let dbError;
    try {
      fastify.sqlite.prepare('SELECT 1').run();
    } catch (err) {
      dbStatus = 'error';
      dbError  = err.message;
    }

    const ipcOnline = fastify.ipcConnected === true;
    const overall   = (dbStatus === 'ok' && ipcOnline) ? 'ok' : 'degraded';

    const body = {
      status:  overall,
      version: pkg.version,
      uptime:  Math.floor((Date.now() - startedAt) / 1000),
      db:      dbStatus,
      core:    ipcOnline ? 'online' : 'offline',
      ws: {
        activeConnections: fastify.wsRooms?.activeConnections ?? 0,
        activeRooms:       fastify.wsRooms?.activeRooms       ?? 0,
      },
      ts: new Date().toISOString(),
    };

    if (dbError !== undefined) body.dbError = dbError;

    return reply.code(200).send(body);
  });

  // ─── GET /api/health/live ─────────────────────────────────────────────────
  fastify.get('/api/health/live', async (req, reply) => {
    return reply.code(200).send({ alive: true });
  });

  // ─── GET /api/health/ready ────────────────────────────────────────────────
  fastify.get('/api/health/ready', async (req, reply) => {
    try {
      fastify.sqlite.prepare('SELECT 1').run();
      return reply.code(200).send({ ready: true });
    } catch {
      return reply.code(503).send({ ready: false, reason: 'database unavailable' });
    }
  });
}
