/**
 * src/routes/runs.js
 * Fastify plugin — /api/runs routes.
 *
 * All routes are protected by the global authMiddleware registered in app.js.
 */
import { v4 as uuidv4 } from 'uuid';
import { eq, and } from 'drizzle-orm';
import { drizzle } from 'drizzle-orm/better-sqlite3';
import * as schema from '../db/schema.js';
import { spawnRun, cancelRun, formatRun } from '../services/run.js';

const FINAL_STATUSES = new Set(['completed', 'failed', 'cancelled', 'completed_with_errors']);
const PIPELINE_RE = /^[a-zA-Z][a-zA-Z0-9_-]{0,63}$/;
const SAFE_ARG_RE = /^[a-zA-Z0-9_\-:@=]{1,128}$/;
const VALID_STATUSES = new Set(['running', 'completed', 'failed', 'cancelled', 'completed_with_errors']);

/**
 * @param {import('fastify').FastifyInstance} fastify
 */
export async function runsRoutes(fastify) {
  // Build a Drizzle instance bound to the shared sqlite connection
  const db = drizzle(fastify.sqlite, { schema });

  // ─── POST /api/runs ─────────────────────────────────────────────────────────
  fastify.post('/api/runs', async (request, reply) => {
    const { pipeline, args, workspaceId, conversationId } = request.body ?? {};

    // ── Validation ──────────────────────────────────────────────────────────
    if (!pipeline || typeof pipeline !== 'string' || pipeline.trim() === '') {
      return reply.code(400).send({
        error: 'VALIDATION_ERROR',
        message: 'pipeline is required',
      });
    }

    if (!PIPELINE_RE.test(pipeline.trim())) {
      return reply.code(400).send({
        error: 'VALIDATION_ERROR',
        message: 'pipeline must match /^[a-zA-Z][a-zA-Z0-9_-]{0,63}$/',
      });
    }

    if (!workspaceId) {
      return reply.code(400).send({
        error: 'VALIDATION_ERROR',
        message: 'workspaceId is required',
      });
    }

    // ── Workspace existence check ────────────────────────────────────────────
    const workspace = fastify.sqlite
      .prepare('SELECT id FROM workspaces WHERE id = ?')
      .get(workspaceId);

    if (!workspace) {
      return reply.code(404).send({
        error: 'WORKSPACE_NOT_FOUND',
        message: `Workspace "${workspaceId}" not found`,
      });
    }

    // ── IPC availability check ───────────────────────────────────────────────
    if (fastify.ipcConnected === false) {
      return reply.code(503).send({
        error: 'ADA_CORE_OFFLINE',
        message: 'Ada-core is not reachable. Start ada-core and retry.',
      });
    }

    // ── Create run ───────────────────────────────────────────────────────────
    const runId = uuidv4();
    const safeConversationId = conversationId || null;
    const safeArgs = Array.isArray(args)
      ? args.filter(a => typeof a === 'string' && SAFE_ARG_RE.test(a))
      : [];

    // Insert run_links row
    fastify.sqlite.prepare(
      `INSERT INTO run_links (run_id, pipeline, workspace_id, conversation_id, status)
       VALUES (?, ?, ?, ?, 'running')`
    ).run(runId, pipeline.trim(), workspaceId, safeConversationId);

    // Insert system message when conversationId is provided
    if (safeConversationId) {
      fastify.sqlite.prepare(
        `INSERT INTO messages (id, conversation_id, role, content, content_type)
         VALUES (?, ?, 'system', ?, 'text')`
      ).run(uuidv4(), safeConversationId, `Run ${pipeline} démarré`);
    }

    // ── Spawn process ────────────────────────────────────────────────────────
    // SPEC 22: args passed as array, shell: false enforced inside spawnRun
    spawnRun({
      pipeline: pipeline.trim(),
      args: [...safeArgs, '--run-id', runId],
      runId,
      workspaceDir: null,
    });

    // ── Timeout watchdog (SPEC 23) ───────────────────────────────────────────
    const timeoutMs = parseInt(process.env.ADA_RUN_TIMEOUT, 10) || 30000;

    const timer = setTimeout(() => {
      // Check if status is still 'running' (i.e. no IPC run.started received)
      const current = fastify.sqlite
        .prepare("SELECT status FROM run_links WHERE run_id = ?")
        .get(runId);

      if (current && current.status === 'running') {
        fastify.sqlite
          .prepare("UPDATE run_links SET status = 'failed' WHERE run_id = ?")
          .run(runId);

        fastify.log.error(
          { runId, pipeline },
          '[ada-api] ERROR: run timed out — no run.started event received'
        );

        // Fire-and-forget broadcast
        fastify.wsRooms.broadcast(workspaceId, {
          type: 'run.cancelled',
          runId,
          reason: 'timeout',
        });
      }
    }, timeoutMs);

    // Don't keep the Node process alive just for the watchdog
    if (timer.unref) timer.unref();

    // ── WS broadcast ─────────────────────────────────────────────────────────
    fastify.wsRooms.broadcast(workspaceId, {
      type: 'run.started',
      runId,
      pipeline,
    });

    return reply.code(202).send({
      runId,
      status: 'starting',
      pipeline,
    });
  });

  // ─── GET /api/runs/:id ──────────────────────────────────────────────────────
  fastify.get('/api/runs/:id', async (request, reply) => {
    const { id } = request.params;

    const row = fastify.sqlite
      .prepare('SELECT * FROM run_links WHERE run_id = ?')
      .get(id);

    if (!row) {
      return reply.code(404).send({
        error: 'RUN_NOT_FOUND',
        message: `Run "${id}" not found`,
      });
    }

    return reply.code(200).send(formatRun(row));
  });

  // ─── GET /api/runs ──────────────────────────────────────────────────────────
  fastify.get('/api/runs', async (request, reply) => {
    const { workspaceId, conversationId, status, limit } = request.query ?? {};
    const maxRows = Math.min(Math.max(1, parseInt(limit, 10) || 20), 200);

    // Build dynamic WHERE clause
    const conditions = [];
    const params = [];

    if (workspaceId) {
      conditions.push('workspace_id = ?');
      params.push(workspaceId);
    }
    if (conversationId) {
      conditions.push('conversation_id = ?');
      params.push(conversationId);
    }
    if (status && VALID_STATUSES.has(status)) {
      conditions.push('status = ?');
      params.push(status);
    }

    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

    const total = fastify.sqlite
      .prepare(`SELECT COUNT(*) as c FROM run_links ${where}`)
      .get(...params).c;

    const rows = fastify.sqlite
      .prepare(`SELECT * FROM run_links ${where} ORDER BY started_at DESC LIMIT ?`)
      .all(...params, maxRows);

    return reply.code(200).send({
      items: rows.map(formatRun),
      total,
    });
  });

  // ─── DELETE /api/runs/:id ───────────────────────────────────────────────────
  fastify.delete('/api/runs/:id', async (request, reply) => {
    const { id } = request.params;

    const row = fastify.sqlite
      .prepare('SELECT * FROM run_links WHERE run_id = ?')
      .get(id);

    if (!row) {
      return reply.code(404).send({
        error: 'RUN_NOT_FOUND',
        message: `Run "${id}" not found`,
      });
    }

    // Idempotent — don't touch already-final runs
    if (FINAL_STATUSES.has(row.status)) {
      return reply.code(204).send();
    }

    // Send SIGTERM to the process if it's still tracked
    cancelRun(id);

    // Update status
    fastify.sqlite
      .prepare("UPDATE run_links SET status = 'cancelled' WHERE run_id = ?")
      .run(id);

    // Fire-and-forget WS broadcast
    if (row.workspace_id) {
      fastify.wsRooms.broadcast(row.workspace_id, {
        type: 'run.cancelled',
        runId: id,
      });
    }

    return reply.code(204).send();
  });
}
