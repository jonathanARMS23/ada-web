/**
 * src/routes/stats.js
 * Fastify plugin — GET /api/stats/observe
 *
 * Retourne ObserveData calculé depuis run_links + ipc_events (SQLite).
 * Protégé par le global authMiddleware (Bearer JWT) défini dans app.js.
 */
import { drizzle } from 'drizzle-orm/better-sqlite3';
import * as schema from '../db/schema.js';
import { gte } from 'drizzle-orm';

const VALID_WINDOWS = new Set(['7d', '30d', 'session']);

/**
 * Retourne la date ISO coupure selon la fenêtre demandée.
 * @param {'7d'|'30d'|'session'} w
 * @returns {string} ISO 8601
 */
function windowCutoff(w) {
  const now = new Date();
  const days = w === '30d' ? 30 : w === 'session' ? 1 : 7;
  now.setDate(now.getDate() - days);
  return now.toISOString();
}

/**
 * Mappe le status run_links → status ObserveRun.
 * @param {string} status
 * @returns {'running'|'done'|'failed'|'partial'}
 */
function mapStatus(status) {
  switch (status) {
    case 'completed':       return 'done';
    case 'failed':          return 'failed';
    case 'cancelled':       return 'cancelled';
    case 'completed_with_errors': return 'partial';
    case 'running':         return 'running';
    default:                return 'running';
  }
}

/**
 * @param {import('fastify').FastifyInstance} fastify
 */
export async function statsRoutes(fastify) {
  // Drizzle instance liée à la connexion SQLite partagée
  const db = drizzle(fastify.sqlite, { schema });

  // ─── GET /api/stats/observe ────────────────────────────────────────────────
  fastify.get('/api/stats/observe', async (request, reply) => {
    const window = request.query.window ?? '7d';

    if (!VALID_WINDOWS.has(window)) {
      return reply.code(400).send({ error: 'Invalid window parameter' });
    }

    const cutoff = windowCutoff(window);

    // ── 1. Runs dans la fenêtre ───────────────────────────────────────────────
    const runs = db
      .select()
      .from(schema.run_links)
      .where(gte(schema.run_links.started_at, cutoff))
      .all();

    // ── 2. Summary ────────────────────────────────────────────────────────────
    const totalRuns = runs.length;
    const successCount = runs.filter(r => r.status === 'completed').length;
    const successRate = totalRuns ? successCount / totalRuns : 0;
    const totalCostUsd = runs.reduce((s, r) => s + (r.total_cost ?? 0), 0);
    const avgCostPerRun = totalRuns ? totalCostUsd / totalRuns : 0;

    // ── 3. Phase events depuis ipc_events ─────────────────────────────────────
    const phaseEventTypes = new Set(['run.phase.completed', 'run.phase.failed']);

    const allEvents = db
      .select()
      .from(schema.ipc_events)
      .where(gte(schema.ipc_events.created_at, cutoff))
      .all();

    // Aggregate agent stats
    // ipc_events.payload structure : JSON encodé avec champ "type" + "payload" interne
    // Exemple : {"id":"...","ts":1234,"type":"run.phase.completed","payload":{"agent":"nestjs","cost":0.01,"durationMs":500}}
    const agentMap = new Map();

    for (const ev of allEvents) {
      if (!phaseEventTypes.has(ev.type)) continue;

      let outer;
      try { outer = JSON.parse(ev.payload); } catch { continue; }

      // Le payload peut être directement l'objet ou enveloppé dans .payload
      const inner = outer?.payload ?? outer;
      const agent = inner?.agent;
      if (!agent) continue;

      const success = ev.type === 'run.phase.completed';
      const cost = inner?.cost ?? inner?.costUsd ?? 0;
      const dur = inner?.durationMs ?? 0;

      if (!agentMap.has(agent)) {
        agentMap.set(agent, { runs: 0, successes: 0, totalCost: 0, totalDur: 0 });
      }
      const s = agentMap.get(agent);
      s.runs++;
      if (success) s.successes++;
      s.totalCost += cost ?? 0;
      s.totalDur += dur ?? 0;
    }

    const agentStats = [...agentMap.entries()]
      .map(([agent, s]) => ({
        agent,
        winRate: s.runs ? s.successes / s.runs : 0,
        alpha: s.successes + 1,
        beta: (s.runs - s.successes) + 1,
        totalRuns: s.runs,
        avgCostUsd: s.runs ? s.totalCost / s.runs : 0,
        avgDurationMs: s.runs ? s.totalDur / s.runs : 0,
      }))
      .sort((a, b) => b.winRate - a.winRate);

    const topAgent = agentStats[0]?.agent ?? '';
    const worstAgent = agentStats[agentStats.length - 1]?.agent ?? '';

    // ── 4. Cost timeline (groupé par date) ───────────────────────────────────
    // Pré-remplir les jours de la fenêtre avec totalUsd=0
    const daysBack = window === 'session' ? 1 : window === '30d' ? 30 : 7;
    const timelineMap = new Map();
    const today = new Date();
    for (let d = daysBack - 1; d >= 0; d--) {
      const dt = new Date(today);
      dt.setDate(dt.getDate() - d);
      const dateStr = dt.toISOString().slice(0, 10);
      timelineMap.set(dateStr, { date: dateStr, totalUsd: 0, byAgent: {} });
    }

    for (const run of runs) {
      const date = run.started_at.slice(0, 10);
      if (!timelineMap.has(date)) continue;
      const entry = timelineMap.get(date);
      entry.totalUsd += run.total_cost ?? 0;

      // Ajouter par agent si phases disponibles
      let phases = {};
      try { phases = JSON.parse(run.phases ?? '{}'); } catch {}
      for (const ph of Object.values(phases)) {
        const ag = ph?.agent;
        if (ag) {
          entry.byAgent[ag] = (entry.byAgent[ag] ?? 0) + (ph.cost ?? 0);
        }
      }
    }

    const costTimeline = [...timelineMap.values()];

    // ── 5. Runs list (50 max, phases parsées) ─────────────────────────────────
    const runsOut = runs.slice(0, 50).map(r => {
      let phases = [];
      try {
        const parsed = JSON.parse(r.phases ?? '{}');
        phases = Object.entries(parsed).map(([id, ph]) => ({
          id,
          agent: ph?.agent ?? '',
          tier: ph?.tier ?? 2,
          costUsd: ph?.cost ?? 0,
          durationMs:
            ph?.completedAt && ph?.startedAt
              ? new Date(ph.completedAt) - new Date(ph.startedAt)
              : 0,
          status: ph?.status ?? 'unknown',
        }));
      } catch {}

      const dur =
        r.completed_at && r.started_at
          ? new Date(r.completed_at) - new Date(r.started_at)
          : 0;

      return {
        id: r.run_id,
        pipeline: r.pipeline,
        status: mapStatus(r.status),
        startedAt: r.started_at,
        durationMs: Math.max(0, dur),
        totalCostUsd: r.total_cost ?? 0,
        phases,
      };
    });

    // ── 6. Active alerts ──────────────────────────────────────────────────────
    const activeAlerts = [];

    const failureRate = totalRuns > 0 ? 1 - successRate : 0;
    if (failureRate > 0.3 && totalRuns >= 3) {
      activeAlerts.push({
        type: 'high_failure_rate',
        message: `Taux d'échec élevé : ${Math.round(failureRate * 100)}% des runs ont échoué (${window})`,
        severity: failureRate > 0.5 ? 'error' : 'warning',
      });
    }

    if (totalCostUsd > 10) {
      activeAlerts.push({
        type: 'budget_warning',
        message: `Coût total élevé sur la période : $${totalCostUsd.toFixed(2)}`,
        severity: 'info',
      });
    }

    return reply.send({
      summary: { totalRuns, successRate, totalCostUsd, avgCostPerRun, topAgent, worstAgent },
      agentStats,
      costTimeline,
      runs: runsOut,
      activeAlerts,
    });
  });
}
