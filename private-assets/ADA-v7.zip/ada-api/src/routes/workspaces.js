/**
 * src/routes/workspaces.js
 * Fastify plugin — workspace CRUD routes.
 *
 * All routes are protected by the authMiddleware registered in app.js.
 *
 * POST   /api/workspaces          — create
 * GET    /api/workspaces          — list (with filters)
 * GET    /api/workspaces/:id      — get by UUID or slug
 * PATCH  /api/workspaces/:id      — partial update
 * DELETE /api/workspaces/:id      — delete (cascade)
 * GET    /api/workspaces/:id/stats — aggregate stats
 */
import { v4 as uuidv4 } from 'uuid';
import { slugify, generateUniqueSlug, formatWorkspace, getWorkspaceStats } from '../services/workspace.js';

// UUID v4 regex
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const COLOR_RE = /^#[0-9a-fA-F]{6}$/;

/**
 * @param {import('fastify').FastifyInstance} fastify
 */
export async function workspaceRoutes(fastify) {
  const sqlite = fastify.sqlite;

  // ─── Prepared statements ─────────────────────────────────────────────────────
  const stmtInsert = sqlite.prepare(`
    INSERT INTO workspaces (id, name, slug, profile, color, description, project_dir, pinned, archived)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const stmtFindById = sqlite.prepare(`
    SELECT w.*,
           MAX(c.updated_at) AS last_activity
    FROM workspaces w
    LEFT JOIN conversations c ON c.workspace_id = w.id
    WHERE w.id = ?
    GROUP BY w.id
  `);

  const stmtFindBySlug = sqlite.prepare(`
    SELECT w.*,
           MAX(c.updated_at) AS last_activity
    FROM workspaces w
    LEFT JOIN conversations c ON c.workspace_id = w.id
    WHERE w.slug = ?
    GROUP BY w.id
  `);

  const stmtDeleteById = sqlite.prepare('DELETE FROM workspaces WHERE id = ?');

  // ─── POST /api/workspaces ─────────────────────────────────────────────────────
  fastify.post('/api/workspaces', async (request, reply) => {
    const body = request.body ?? {};
    const { name, profile, color, description, projectDir, pinned, archived } = body;

    // Validation
    if (!name || typeof name !== 'string' || name.trim() === '') {
      return reply.code(400).send({ error: 'VALIDATION_ERROR', message: 'name is required' });
    }
    if (name.length > 255) {
      return reply.code(400).send({ error: 'VALIDATION_ERROR', message: 'name must be ≤ 255 characters' });
    }
    if (color !== undefined && !COLOR_RE.test(color)) {
      return reply.code(400).send({ error: 'VALIDATION_ERROR', message: 'color must be a valid hex color (#rrggbb)' });
    }

    const id = uuidv4();
    const baseSlug = slugify(name.trim());
    const slug = generateUniqueSlug(sqlite, baseSlug);

    stmtInsert.run(
      id,
      name.trim(),
      slug,
      profile ?? 'claude-pro',
      color ?? '#6366f1',
      description ?? null,
      projectDir ?? null,
      pinned ? 1 : 0,
      archived ? 1 : 0,
    );

    const row = stmtFindById.get(id);
    return reply.code(201).send(formatWorkspace(row));
  });

  // ─── GET /api/workspaces ──────────────────────────────────────────────────────
  fastify.get('/api/workspaces', async (request, reply) => {
    const { archived, pinned } = request.query ?? {};

    // archived param: string 'true' → include archived, default = exclude
    const showArchived = archived === 'true';
    // pinned param: filter by pinned if provided
    const filterPinned = pinned === 'true';

    let sql = `
      SELECT w.*,
             MAX(c.updated_at) AS last_activity
      FROM workspaces w
      LEFT JOIN conversations c ON c.workspace_id = w.id
    `;
    const conditions = [];
    const params = [];

    if (!showArchived) {
      conditions.push('w.archived = 0');
    }
    if (filterPinned) {
      conditions.push('w.pinned = 1');
    }

    if (conditions.length > 0) {
      sql += ' WHERE ' + conditions.join(' AND ');
    }

    sql += ' GROUP BY w.id ORDER BY w.updated_at DESC';

    const rows = sqlite.prepare(sql).all(...params);
    const items = rows.map(formatWorkspace);

    return reply.code(200).send({ items, total: items.length });
  });

  // ─── GET /api/workspaces/:id ──────────────────────────────────────────────────
  fastify.get('/api/workspaces/:id', async (request, reply) => {
    const { id } = request.params;

    // Lookup by UUID or slug
    let row;
    if (UUID_RE.test(id)) {
      row = stmtFindById.get(id);
    } else {
      row = stmtFindBySlug.get(id);
    }

    if (!row) {
      return reply.code(404).send({ error: 'WORKSPACE_NOT_FOUND', message: 'Workspace not found' });
    }

    return reply.code(200).send(formatWorkspace(row));
  });

  // ─── PATCH /api/workspaces/:id ────────────────────────────────────────────────
  fastify.patch('/api/workspaces/:id', async (request, reply) => {
    const { id } = request.params;
    const body = request.body ?? {};

    // Check workspace exists
    const existing = stmtFindById.get(id);
    if (!existing) {
      return reply.code(404).send({ error: 'WORKSPACE_NOT_FOUND', message: 'Workspace not found' });
    }

    // Validate patchable fields
    if (body.color !== undefined && !COLOR_RE.test(body.color)) {
      return reply.code(400).send({ error: 'VALIDATION_ERROR', message: 'color must be a valid hex color (#rrggbb)' });
    }
    if (body.name !== undefined) {
      if (typeof body.name !== 'string' || body.name.trim() === '') {
        return reply.code(400).send({ error: 'VALIDATION_ERROR', message: 'name is required' });
      }
      if (body.name.length > 255) {
        return reply.code(400).send({ error: 'VALIDATION_ERROR', message: 'name must be ≤ 255 characters' });
      }
    }

    // Build dynamic SET clause — slug is NEVER updated
    const patchable = ['name', 'color', 'profile', 'description', 'pinned', 'archived', 'project_dir'];
    const setClauses = [];
    const values = [];

    // Map camelCase body fields to snake_case DB columns
    const fieldMap = {
      name:        'name',
      color:       'color',
      profile:     'profile',
      description: 'description',
      pinned:      'pinned',
      archived:    'archived',
      projectDir:  'project_dir',
    };

    for (const [bodyKey, dbCol] of Object.entries(fieldMap)) {
      if (body[bodyKey] !== undefined) {
        setClauses.push(`\`${dbCol}\` = ?`);
        let val = body[bodyKey];
        // Boolean → integer for SQLite
        if (typeof val === 'boolean') val = val ? 1 : 0;
        values.push(val);
      }
    }

    if (setClauses.length > 0) {
      values.push(id);
      sqlite.prepare(`UPDATE workspaces SET ${setClauses.join(', ')} WHERE id = ?`).run(...values);
    }

    const updated = stmtFindById.get(id);
    return reply.code(200).send(formatWorkspace(updated));
  });

  // ─── DELETE /api/workspaces/:id ───────────────────────────────────────────────
  fastify.delete('/api/workspaces/:id', async (request, reply) => {
    const { id } = request.params;

    const existing = sqlite.prepare('SELECT id FROM workspaces WHERE id = ?').get(id);
    if (!existing) {
      return reply.code(404).send({ error: 'WORKSPACE_NOT_FOUND', message: 'Workspace not found' });
    }

    stmtDeleteById.run(id);
    return reply.code(204).send();
  });

  // ─── GET /api/workspaces/:id/stats ───────────────────────────────────────────
  fastify.get('/api/workspaces/:id/stats', async (request, reply) => {
    const { id } = request.params;

    const existing = sqlite.prepare('SELECT id FROM workspaces WHERE id = ?').get(id);
    if (!existing) {
      return reply.code(404).send({ error: 'WORKSPACE_NOT_FOUND', message: 'Workspace not found' });
    }

    const stats = getWorkspaceStats(sqlite, id);
    return reply.code(200).send(stats);
  });
}
