/**
 * src/server.js
 * Entry point — runs migrations, starts Fastify, connects IPC.
 */
import { readFileSync, readdirSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { createApp } from './app.js';
import { db, sqlite } from './db/client.js';
import { env } from './config/env.js';
import { IpcClient } from './ipc/client.js';
import { IpcHandler } from './ipc/handler.js';

const __dirname = dirname(fileURLToPath(import.meta.url));

// ─── Migrations ───────────────────────────────────────────────────────────────
function applyMigrations() {
  // Table de suivi des migrations appliquées
  sqlite.exec(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      version TEXT PRIMARY KEY,
      applied_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `);

  // Lire tous les fichiers .sql triés lexicographiquement (0000_ < 0001_ < 0002_)
  const migrationsDir = join(__dirname, 'db', 'migrations');
  const files = readdirSync(migrationsDir)
    .filter(f => f.endsWith('.sql'))
    .sort();

  const stmtApplied = sqlite.prepare('SELECT version FROM schema_migrations WHERE version = ?');
  const stmtInsert  = sqlite.prepare('INSERT INTO schema_migrations (version) VALUES (?)');

  for (const file of files) {
    const version = file.replace(/\.sql$/, '');
    if (stmtApplied.get(version)) continue; // déjà appliquée

    const sqlPath = join(migrationsDir, file);
    const ddl = readFileSync(sqlPath, 'utf-8');

    sqlite.exec(ddl);
    stmtInsert.run(version);
    console.info(`[ada-api] Migration applied: ${version}`);
  }
}

// ─── Session cleanup ──────────────────────────────────────────────────────────
function cleanExpiredSessions() {
  sqlite.prepare("DELETE FROM sessions WHERE expires_at < datetime('now')").run();
}

// ─── Main ─────────────────────────────────────────────────────────────────────
async function main() {
  // 1. Apply SQL migrations
  try {
    applyMigrations();
  } catch (err) {
    console.error('[ada-api] ERROR: Migration failed:', err.message);
    process.exit(1);
  }

  // 2. Create and start Fastify
  const app = await createApp();

  // 3. Expired session cleanup (on startup + hourly)
  cleanExpiredSessions();
  setInterval(cleanExpiredSessions, 3600 * 1000).unref();

  // 4. Connect IPC
  const broadcast = (event) => app.wsRooms.broadcastAll(event);
  const handler = new IpcHandler(db, broadcast);
  const ipcClient = new IpcClient({
    socketPath:     env.ADA_IPC_SOCKET,
    mode:           env.ADA_IPC_MODE,
    tcpHost:        env.ADA_IPC_HOST,
    tcpPort:        env.ADA_IPC_PORT,
    reconnectDelay: env.ADA_IPC_RECONNECT_DELAY,
  });

  ipcClient.on('message', (event, rawLine) => handler.handle(event, rawLine));
  ipcClient.on('connect', () => {
    app.ipcConnected = true;
    console.info('[ada-api] INFO: IPC connected');
  });
  ipcClient.on('disconnect', () => {
    app.ipcConnected = false;
    console.info('[ada-api] INFO: IPC disconnected');
  });

  ipcClient.connect();

  // 5. Listen
  await app.listen({ port: env.PORT, host: env.HOST });
  console.log(`[ada-api] listening on ${env.HOST}:${env.PORT}`);

  // Graceful shutdown
  const shutdown = async (signal) => {
    console.log(`[ada-api] ${signal} received — shutting down`);
    ipcClient.disconnect();
    await app.close();
    process.exit(0);
  };
  process.once('SIGTERM', () => shutdown('SIGTERM'));
  process.once('SIGINT',  () => shutdown('SIGINT'));
}

main().catch((err) => {
  console.error('[ada-api] fatal:', err);
  process.exit(1);
});
