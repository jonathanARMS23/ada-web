/**
 * src/services/conversation.js
 * Pure formatting helpers for conversation and message rows.
 * No DB access — receives raw rows, returns clean API objects.
 */

/**
 * Format a raw conversation DB row into an API response object.
 *
 * @param {object} row           - Raw SQLite row
 * @param {number} messageCount  - Pre-computed message count
 * @returns {object}
 */
export function formatConversation(row, messageCount = 0) {
  return {
    id:           row.id,
    workspaceId:  row.workspace_id,
    title:        row.title ?? null,
    summary:      row.summary ?? null,
    pinned:       Boolean(row.pinned),
    archived:     Boolean(row.archived),
    runCount:     row.run_count ?? 0,
    lastRunId:    row.last_run_id ?? null,
    messageCount: messageCount,
    createdAt:    row.created_at,
    updatedAt:    row.updated_at,
  };
}

/**
 * Format a raw message DB row into an API response object.
 *
 * @param {object} row - Raw SQLite row
 * @returns {object}
 */
export function formatMessage(row) {
  let metadata = null;
  try {
    const parsed = JSON.parse(row.metadata);
    // Return null for empty objects `{}` — treat as "no metadata"
    if (parsed && typeof parsed === 'object' && Object.keys(parsed).length > 0) {
      metadata = parsed;
    }
  } catch {
    metadata = null;
  }

  return {
    id:             row.id,
    conversationId: row.conversation_id,
    role:           row.role,
    content:        row.content,
    contentType:    row.content_type,
    metadata:       metadata,
    createdAt:      row.created_at,
  };
}
