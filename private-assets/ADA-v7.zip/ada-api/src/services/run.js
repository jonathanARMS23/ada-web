/**
 * src/services/run.js
 * Run service — spawns ada-core processes and tracks active runs.
 *
 * SECURITY (SPEC 22): spawn is ALWAYS called with an args array and shell: false.
 * No shell interpolation is ever used.
 */
import { spawn } from 'child_process';
import { v4 as uuidv4 } from 'uuid';

// ─── Active process registry ──────────────────────────────────────────────────
/** @type {Map<string, import('child_process').ChildProcess>} */
const _activeProcesses = new Map();

// ─── Test helper — exposed only in test environment ──────────────────────────
/**
 * Inject a mock process into the active registry (test-only).
 * @param {string} runId
 * @param {object} mockProcess
 */
export function _setActiveProcessForTest(runId, mockProcess) {
  _activeProcesses.set(runId, mockProcess);
}

// ─── Public API ───────────────────────────────────────────────────────────────

/**
 * Spawn an ada-core process for the given pipeline.
 *
 * @param {object} opts
 * @param {string}   opts.pipeline      - Pipeline name (e.g. 'fullstack')
 * @param {string[]} [opts.args=[]]     - Additional CLI arguments
 * @param {string}   opts.runId         - Unique run identifier
 * @param {string|null} opts.workspaceDir - cwd for the spawned process (null = inherit)
 * @returns {import('child_process').ChildProcess}
 */
export function spawnRun({ pipeline, args = [], runId, workspaceDir }) {
  // SPEC 22 — always a flat args array, never shell interpolation
  const cmdArgs = [pipeline, ...args];

  // --run-id is injected by the route before calling spawnRun; if caller
  // already included it we skip adding again (idempotent check)
  if (!cmdArgs.includes('--run-id')) {
    cmdArgs.push('--run-id', runId);
  }

  const spawnOpts = {
    shell: false, // SPEC 22 — explicit, never allow shell expansion
    stdio: ['ignore', 'ignore', 'ignore'],
  };

  if (workspaceDir) {
    spawnOpts.cwd = workspaceDir;
  }

  const child = spawn('ada', cmdArgs, spawnOpts);

  _activeProcesses.set(runId, child);

  child.on('close', () => {
    _activeProcesses.delete(runId);
  });

  return child;
}

/**
 * Send SIGTERM to the active process for a run.
 *
 * @param {string} runId
 * @returns {boolean} true if a process existed and received SIGTERM
 */
export function cancelRun(runId) {
  const proc = _activeProcesses.get(runId);
  if (!proc) return false;

  proc.kill('SIGTERM');
  _activeProcesses.delete(runId);
  return true;
}

/**
 * Retrieve the active ChildProcess for a run (undefined if not running).
 *
 * @param {string} runId
 * @returns {import('child_process').ChildProcess|undefined}
 */
export function getActiveProcess(runId) {
  return _activeProcesses.get(runId);
}

/**
 * Serialize a run_links DB row into the API response shape.
 *
 * @param {object} row - Raw DB row from run_links
 * @returns {object}
 */
export function formatRun(row) {
  return {
    runId:          row.run_id,
    pipeline:       row.pipeline,
    status:         row.status,
    workspaceId:    row.workspace_id   ?? null,
    conversationId: row.conversation_id ?? null,
    totalCost:      row.total_cost     ?? 0,
    totalTokens:    row.total_tokens   ?? 0,
    completedAt:    row.completed_at   ?? null,
    startedAt:      row.started_at,
  };
}
