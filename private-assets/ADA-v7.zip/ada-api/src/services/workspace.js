/**
 * src/services/workspace.js
 * Business logic for workspace management.
 */

/**
 * Convert a workspace name to a URL-safe slug.
 * - Lowercase
 * - NFD decomposition → remove diacritics (é→e, ê→e, etc.)
 * - Replace [^a-z0-9]+ with '-'
 * - Trim leading/trailing '-'
 *
 * @param {string} name
 * @returns {string}
 */
export function slugify(name) {
  return name
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '') // strip diacritic combining characters
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

/**
 * Generate a unique slug in DB.
 * If baseSlug exists, try baseSlug-2, baseSlug-3, etc.
 *
 * @param {import('better-sqlite3').Database} sqliteInstance
 * @param {string} baseSlug
 * @returns {string}
 */
export function generateUniqueSlug(sqliteInstance, baseSlug) {
  const stmt = sqliteInstance.prepare('SELECT id FROM workspaces WHERE slug = ?');

  let candidate = baseSlug;
  let counter = 2;

  while (stmt.get(candidate)) {
    candidate = `${baseSlug}-${counter}`;
    counter++;
  }

  return candidate;
}

/**
 * Format a DB row into the API workspace object shape.
 *
 * @param {object} row
 * @returns {object}
 */
export function formatWorkspace(row) {
  return {
    id:          row.id,
    name:        row.name,
    slug:        row.slug,
    profile:     row.profile,
    color:       row.color,
    description: row.description ?? null,
    projectDir:  row.project_dir ?? null,
    pinned:      Boolean(row.pinned),
    archived:    Boolean(row.archived),
    runCount:    row.run_count ?? 0,
    createdAt:   row.created_at,
    updatedAt:   row.updated_at,
    lastActivity: row.last_activity ?? null,
  };
}

/**
 * Compute aggregate stats for a workspace.
 *
 * @param {import('better-sqlite3').Database} sqliteInstance
 * @param {string} workspaceId
 * @returns {{ totalCost: number, totalRuns: number, totalMessages: number, totalTokens: number, conversationCount: number, lastRunAt: string|null }}
 */
export function getWorkspaceStats(sqliteInstance, workspaceId) {
  const row = sqliteInstance.prepare(`
    WITH
      runs AS (
        SELECT
          COALESCE(SUM(CASE WHEN status IN ('completed','failed') THEN total_cost ELSE 0 END), 0) AS total_cost,
          COUNT(*)                                                                                  AS total_runs,
          COALESCE(SUM(total_tokens), 0)                                                           AS total_tokens,
          MAX(completed_at)                                                                         AS last_run_at
        FROM run_links
        WHERE workspace_id = ?
      ),
      convs AS (
        SELECT COUNT(*) AS conversation_count
        FROM conversations
        WHERE workspace_id = ?
      ),
      msgs AS (
        SELECT COUNT(m.id) AS total_messages
        FROM messages m
        INNER JOIN conversations c ON c.id = m.conversation_id
        WHERE c.workspace_id = ?
      )
    SELECT
      runs.total_cost,
      runs.total_runs,
      runs.total_tokens,
      runs.last_run_at,
      convs.conversation_count,
      msgs.total_messages
    FROM runs, convs, msgs
  `).get(workspaceId, workspaceId, workspaceId);

  return {
    totalCost:         row.total_cost,
    totalRuns:         row.total_runs,
    totalMessages:     row.total_messages,
    totalTokens:       row.total_tokens,
    conversationCount: row.conversation_count,
    lastRunAt:         row.last_run_at ?? null,
  };
}
