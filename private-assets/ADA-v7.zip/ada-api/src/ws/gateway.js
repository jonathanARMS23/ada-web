/**
 * src/ws/gateway.js
 * Fastify WebSocket gateway — route GET /ws
 *
 * Auth: JWT token passed as query param ?token=<jwt>
 * Protocol messages: workspace.join · workspace.leave · run.spawn
 */
import { v4 as uuidv4 } from 'uuid';
import { env } from '../config/env.js';
import { startHeartbeat } from './heartbeat.js';
import { spawnRun } from '../services/run.js';

const HEARTBEAT_INTERVAL = Math.max(
  5000,
  parseInt(process.env.ADA_WS_HEARTBEAT_INTERVAL ?? '', 10) || 30000,
);
const PIPELINE_RE = /^[a-zA-Z][a-zA-Z0-9_-]{0,63}$/;
const SAFE_ARG_RE = /^[a-zA-Z0-9_\-:@=]{1,128}$/;

/**
 * @param {import('fastify').FastifyInstance} fastify
 */
export async function wsGateway(fastify) {
  // Prepared statements — compilés une fois par plugin registration
  let stmtGetSession, stmtGetWorkspace, stmtInsertRun, stmtInsertMsg, stmtGetRunStatus, stmtTimeoutRun;

  fastify.addHook('onReady', async () => {
    stmtGetSession   = fastify.sqlite.prepare('SELECT id FROM sessions WHERE token_hash = ?');
    stmtGetWorkspace = fastify.sqlite.prepare('SELECT id FROM workspaces WHERE id = ?');
    stmtInsertRun    = fastify.sqlite.prepare(
      `INSERT INTO run_links (run_id, pipeline, workspace_id, conversation_id, status) VALUES (?, ?, ?, ?, 'running')`
    );
    stmtInsertMsg    = fastify.sqlite.prepare(
      `INSERT INTO messages (id, conversation_id, role, content, content_type) VALUES (?, ?, 'system', ?, 'text')`
    );
    stmtGetRunStatus = fastify.sqlite.prepare("SELECT status FROM run_links WHERE run_id = ?");
    stmtTimeoutRun   = fastify.sqlite.prepare("UPDATE run_links SET status = 'failed' WHERE run_id = ?");
  });

  fastify.get('/ws', { websocket: true }, async (connection, request) => {
    const socket = connection.socket;

    // ─── Auth ─────────────────────────────────────────────────────────────────
    const ticketId = request.query.ticket;
    const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    // Aucun ticket fourni → UNAUTHORIZED (SPEC 02). Ticket présent mais malformé
    // (non-UUID) → INVALID_TICKET (SPEC 03), comme un ticket inconnu/expiré.
    if (!ticketId) {
      socket.close(4001, 'UNAUTHORIZED');
      return;
    }
    if (!UUID_RE.test(ticketId)) {
      socket.close(4001, 'INVALID_TICKET');
      return;
    }

    const wsTickets = fastify.wsTickets;
    const ticketData = wsTickets?.get(ticketId);
    if (!ticketData || ticketData.expiresAt < Date.now()) {
      socket.close(4001, 'INVALID_TICKET');
      return;
    }
    wsTickets.delete(ticketId); // one-time use

    const session = stmtGetSession.get(ticketData.tokenHash);
    if (!session) {
      socket.close(4001, 'TOKEN_REVOKED');
      return;
    }

    // ─── Connection accepted ──────────────────────────────────────────────────
    fastify.wsRooms.addConnection(socket);
    let currentWorkspaceId = null;

    const stopHeartbeat = startHeartbeat(socket, HEARTBEAT_INTERVAL);

    try {
      socket.send(
        JSON.stringify({ type: 'connected', workspaceId: null, ts: new Date().toISOString() })
      );
    } catch {
      // Socket already closed
    }

    // ─── Message handler ──────────────────────────────────────────────────────
    socket.on('message', async (raw) => {
      let msg;
      try {
        msg = JSON.parse(raw.toString());
      } catch {
        try {
          socket.send(JSON.stringify({ type: 'error', code: 'INVALID_JSON' }));
        } catch { /* closed */ }
        return;
      }

      const send = (payload) => {
        try {
          socket.send(JSON.stringify(payload));
        } catch { /* closed */ }
      };

      switch (msg.type) {
        // ── workspace.join ────────────────────────────────────────────────────
        case 'workspace.join': {
          const wid = msg.payload?.workspaceId;
          const ws = stmtGetWorkspace.get(wid);
          if (!ws) {
            send({ type: 'error', code: 'WORKSPACE_NOT_FOUND' });
            return;
          }
          if (currentWorkspaceId) {
            fastify.wsRooms.leave(currentWorkspaceId, socket);
          }
          currentWorkspaceId = wid;
          fastify.wsRooms.join(wid, socket);
          send({ type: 'workspace.joined', workspaceId: wid });
          break;
        }

        // ── workspace.leave ───────────────────────────────────────────────────
        case 'workspace.leave': {
          if (currentWorkspaceId) {
            fastify.wsRooms.leave(currentWorkspaceId, socket);
            currentWorkspaceId = null;
          }
          send({ type: 'workspace.left' });
          break;
        }

        // ── run.spawn ─────────────────────────────────────────────────────────
        case 'run.spawn': {
          if (!currentWorkspaceId) {
            send({ type: 'error', code: 'NO_WORKSPACE', message: 'Join a workspace first' });
            return;
          }

          const payload = msg.payload || {};
          const { pipeline, args, conversationId } = payload;

          if (!pipeline || typeof pipeline !== 'string' || pipeline.trim() === '') {
            send({ type: 'error', code: 'VALIDATION_ERROR', message: 'pipeline is required' });
            return;
          }

          if (!PIPELINE_RE.test(pipeline.trim())) {
            send({ type: 'error', code: 'VALIDATION_ERROR', message: 'pipeline must match /^[a-zA-Z][a-zA-Z0-9_-]{0,63}$/' });
            return;
          }

          // Workspace exists (we're already in a room — double-check)
          const workspace = stmtGetWorkspace.get(currentWorkspaceId);
          if (!workspace) {
            send({ type: 'error', code: 'WORKSPACE_NOT_FOUND' });
            return;
          }

          // IPC non requis pour spawner un run — spawnRun() passe par spawn() direct.
          // ipcConnected reste false jusqu'à implémentation du serveur socket ada-core.

          const runId = uuidv4();
          const safeConversationId = conversationId || null;
          const safeArgs = Array.isArray(args)
            ? args.filter(a => typeof a === 'string' && SAFE_ARG_RE.test(a))
            : [];

          // Insert run_links row
          stmtInsertRun.run(runId, pipeline.trim(), currentWorkspaceId, safeConversationId);

          // Optional system message
          if (safeConversationId) {
            stmtInsertMsg.run(uuidv4(), safeConversationId, `Run ${pipeline} démarré`);
          }

          // Spawn process
          spawnRun({
            pipeline: pipeline.trim(),
            args: [...safeArgs, '--run-id', runId],
            runId,
            workspaceDir: null,
          });

          // Timeout watchdog
          const timeoutMs = parseInt(process.env.ADA_RUN_TIMEOUT, 10) || 30000;
          const timer = setTimeout(() => {
            const current = stmtGetRunStatus.get(runId);
            if (current && current.status === 'running') {
              stmtTimeoutRun.run(runId);
              fastify.wsRooms.broadcast(currentWorkspaceId, {
                type: 'run.cancelled',
                runId,
                reason: 'timeout',
              });
            }
          }, timeoutMs);
          if (timer.unref) timer.unref();

          // Broadcast to room and reply to client
          fastify.wsRooms.broadcast(currentWorkspaceId, {
            type: 'run.started',
            runId,
            pipeline: pipeline.trim(),
          });
          break;
        }

        // ── Unknown ───────────────────────────────────────────────────────────
        default:
          send({ type: 'error', code: 'UNKNOWN_MESSAGE_TYPE' });
      }
    });

    // ─── Cleanup ──────────────────────────────────────────────────────────────
    let cleaned = false;
    const cleanup = () => {
      if (cleaned) return;
      cleaned = true;
      stopHeartbeat();
      fastify.wsRooms.removeConnection(socket);
      if (currentWorkspaceId) {
        fastify.wsRooms.leave(currentWorkspaceId, socket);
        currentWorkspaceId = null;
      }
    };

    socket.on('close', cleanup);
    socket.on('error', cleanup);
  });
}
