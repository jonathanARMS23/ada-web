/**
 * src/ws/heartbeat.js
 * Periodic heartbeat helper for a WebSocket connection.
 */

/**
 * Start a heartbeat for a WebSocket connection.
 * Sends { type: 'heartbeat', ts } every `intervalMs` milliseconds.
 *
 * @param {import('ws').WebSocket} socket
 * @param {number} intervalMs
 * @returns {() => void} cleanup function — call on socket close
 */
export function startHeartbeat(socket, intervalMs) {
  const timer = setInterval(() => {
    if (socket.readyState === socket.OPEN) {
      try {
        socket.send(JSON.stringify({ type: 'heartbeat', ts: new Date().toISOString() }));
      } catch {
        // Socket closed between readyState check and send — ignore
      }
    }
  }, intervalMs);

  // Do not keep the Node.js event loop alive just for heartbeat
  if (timer.unref) timer.unref();

  return () => clearInterval(timer);
}
