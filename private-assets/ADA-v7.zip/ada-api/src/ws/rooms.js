/**
 * src/ws/rooms.js
 * WebSocket room manager keyed by workspace_id.
 */

export class WsRooms {
  constructor() {
    /** @type {Map<string, Set<WebSocket>>} */
    this._rooms = new Map();
    /** @type {Set<WebSocket>} — all connected sockets (even without a room) */
    this._connections = new Set();
  }

  /**
   * Track a newly connected socket (before it joins any room).
   * @param {WebSocket} socket
   */
  addConnection(socket) {
    this._connections.add(socket);
  }

  /**
   * Remove a socket from the global connection tracker.
   * @param {WebSocket} socket
   */
  removeConnection(socket) {
    this._connections.delete(socket);
  }

  /** Total number of open sockets tracked by this instance. */
  get activeConnections() {
    return this._connections.size;
  }

  /** Total number of non-empty rooms. */
  get activeRooms() {
    return this._rooms.size;
  }

  /**
   * Add a socket to a workspace room.
   * @param {string} workspaceId
   * @param {WebSocket} socket
   */
  join(workspaceId, socket) {
    if (!this._rooms.has(workspaceId)) {
      this._rooms.set(workspaceId, new Set());
    }
    this._rooms.get(workspaceId).add(socket);
  }

  /**
   * Remove a socket from a workspace room.
   * Cleans up empty rooms so activeRooms stays accurate.
   * @param {string} workspaceId
   * @param {WebSocket} socket
   */
  leave(workspaceId, socket) {
    const room = this._rooms.get(workspaceId);
    if (!room) return;
    room.delete(socket);
    if (room.size === 0) {
      this._rooms.delete(workspaceId);
    }
  }

  /**
   * Broadcast a message to all sockets in a workspace room.
   * @param {string} workspaceId
   * @param {object|string} message - will be JSON.stringified if object
   */
  broadcast(workspaceId, message) {
    const room = this._rooms.get(workspaceId);
    if (!room || room.size === 0) return;
    const data = typeof message === 'string' ? message : JSON.stringify(message);
    for (const socket of room) {
      try {
        socket.send(data);
      } catch {
        // Socket likely closed — ignore
      }
    }
  }

  /**
   * Broadcast to all rooms.
   * @param {object|string} message
   */
  broadcastAll(message) {
    const data = typeof message === 'string' ? message : JSON.stringify(message);
    for (const room of this._rooms.values()) {
      for (const socket of room) {
        try {
          socket.send(data);
        } catch {
          // Socket likely closed — ignore
        }
      }
    }
  }

  /**
   * Number of sockets in a room.
   * @param {string} workspaceId
   * @returns {number}
   */
  size(workspaceId) {
    const room = this._rooms.get(workspaceId);
    return room ? room.size : 0;
  }
}
