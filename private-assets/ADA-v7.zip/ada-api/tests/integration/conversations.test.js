/**
 * TDD — RED phase
 * Integration tests for conversations + messages routes (HTTP + SQLite in-memory)
 * 33 specs covering CRUD conversations, messages, pagination cursors, and search.
 */

// ─── Configure env BEFORE any module import ──────────────────────────────────
process.env.DB_PATH = ':memory:';
process.env.ADA_JWT_SECRET = 'test-secret-conversations-32chars!!';
process.env.ADA_AUTH_MODE = 'local';
process.env.NODE_ENV = 'test';

import { describe, it, expect, beforeAll, afterAll, beforeEach } from 'vitest';
import supertest from 'supertest';
import { readFileSync } from 'fs';
import { v4 as uuidv4 } from 'uuid';

const { createApp } = await import('../../src/app.js');
const { db, sqlite } = await import('../../src/db/client.js');

// ─── Helpers ─────────────────────────────────────────────────────────────────

function applyMigrations(sqliteInstance) {
  const sqlPath = new URL('../../src/db/migrations/0000_init.sql', import.meta.url).pathname;
  const ddl = readFileSync(sqlPath, 'utf-8');
  sqliteInstance.exec(ddl);
}

function makeWorkspace(overrides = {}) {
  return {
    id: uuidv4(),
    name: 'Test Workspace',
    slug: `ws-${Date.now()}-${Math.random().toString(36).slice(2)}`,
    profile: 'fullstack',
    ...overrides,
  };
}

function insertWorkspace(ws) {
  sqlite
    .prepare(
      'INSERT INTO workspaces (id, name, slug, profile) VALUES (?, ?, ?, ?)'
    )
    .run(ws.id, ws.name, ws.slug, ws.profile);
  return ws;
}

// ─── App + token setup ───────────────────────────────────────────────────────
let app;
let request;
let token;

beforeAll(async () => {
  applyMigrations(sqlite);
  app = await createApp({ logger: false });
  await app.ready();
  request = supertest(app.server);

  // Get auth token (local mode — no password required)
  const { body } = await supertest(app.server).post('/api/auth/token').send({});
  token = body.token;
});

afterAll(async () => {
  if (app) await app.close();
});

beforeEach(() => {
  sqlite.exec(
    'DELETE FROM messages; DELETE FROM run_links; DELETE FROM conversations; DELETE FROM workspace_settings; DELETE FROM workspaces; DELETE FROM sessions;'
  );
  // Re-insert the session for our token
  // We need to re-obtain a token each beforeEach since sessions are wiped
});

// ─── Helper: fresh token after beforeEach wipes sessions ─────────────────────
async function getToken() {
  const { body } = await request.post('/api/auth/token').send({});
  return body.token;
}

// ═══════════════════════════════════════════════════════════════════════════════
// CONVERSATIONS
// ═══════════════════════════════════════════════════════════════════════════════

describe('SPEC 01 — POST conversation with title → 201 + workspace.updated_at refreshed', () => {
  it('creates conversation and refreshes workspace.updated_at', async () => {
    const tk = await getToken();
    const ws = insertWorkspace(makeWorkspace());

    // Capture updated_at before
    const before = sqlite.prepare('SELECT updated_at FROM workspaces WHERE id = ?').get(ws.id);

    // Small delay to ensure timestamps differ
    await new Promise((r) => setTimeout(r, 5));

    const res = await request
      .post(`/api/workspaces/${ws.id}/conversations`)
      .set('Authorization', `Bearer ${tk}`)
      .send({ title: 'My Conversation' });

    expect(res.status).toBe(201);
    expect(res.body.title).toBe('My Conversation');
    expect(res.body.workspaceId).toBe(ws.id);
    expect(res.body).toHaveProperty('id');
    expect(res.body).toHaveProperty('createdAt');
    expect(res.body).toHaveProperty('updatedAt');

    const after = sqlite.prepare('SELECT updated_at FROM workspaces WHERE id = ?').get(ws.id);
    expect(after.updated_at).not.toBe(before.updated_at);
  });
});

describe('SPEC 02 — POST conversation without title → 201 (no error)', () => {
  it('creates conversation with null title', async () => {
    const tk = await getToken();
    const ws = insertWorkspace(makeWorkspace());

    const res = await request
      .post(`/api/workspaces/${ws.id}/conversations`)
      .set('Authorization', `Bearer ${tk}`)
      .send({});

    expect(res.status).toBe(201);
    expect(res.body).toHaveProperty('id');
  });
});

describe('SPEC 03 — POST conversation for non-existent workspace → 404', () => {
  it('returns 404 WORKSPACE_NOT_FOUND', async () => {
    const tk = await getToken();

    const res = await request
      .post(`/api/workspaces/${uuidv4()}/conversations`)
      .set('Authorization', `Bearer ${tk}`)
      .send({ title: 'Ghost' });

    expect(res.status).toBe(404);
    expect(res.body.error).toBe('WORKSPACE_NOT_FOUND');
  });
});

describe('SPEC 04 — GET conversations empty → { items: [], nextCursor: null, total: 0 }', () => {
  it('returns empty list', async () => {
    const tk = await getToken();
    const ws = insertWorkspace(makeWorkspace());

    const res = await request
      .get(`/api/workspaces/${ws.id}/conversations`)
      .set('Authorization', `Bearer ${tk}`);

    expect(res.status).toBe(200);
    expect(res.body.items).toEqual([]);
    expect(res.body.nextCursor).toBeNull();
    expect(res.body.total).toBe(0);
  });
});

describe('SPEC 05 — GET 50 conversations, limit=20 → 20 items + nextCursor + hasMore=true', () => {
  it('paginates correctly', async () => {
    const tk = await getToken();
    const ws = insertWorkspace(makeWorkspace());

    // Insert 50 conversations
    for (let i = 0; i < 50; i++) {
      sqlite
        .prepare(
          'INSERT INTO conversations (id, workspace_id, title, updated_at) VALUES (?, ?, ?, ?)'
        )
        .run(uuidv4(), ws.id, `Conv ${i}`, new Date(Date.now() + i * 1000).toISOString());
    }

    const res = await request
      .get(`/api/workspaces/${ws.id}/conversations?limit=20`)
      .set('Authorization', `Bearer ${tk}`);

    expect(res.status).toBe(200);
    expect(res.body.items).toHaveLength(20);
    expect(res.body.nextCursor).toBeTruthy();
    expect(res.body.hasMore).toBe(true);
    expect(res.body.total).toBe(50);
  });
});

describe('SPEC 06 — GET page suivante avec cursor', () => {
  it('returns next page using cursor', async () => {
    const tk = await getToken();
    const ws = insertWorkspace(makeWorkspace());

    for (let i = 0; i < 30; i++) {
      sqlite
        .prepare(
          'INSERT INTO conversations (id, workspace_id, title, updated_at) VALUES (?, ?, ?, ?)'
        )
        .run(uuidv4(), ws.id, `Conv ${i}`, new Date(Date.now() + i * 1000).toISOString());
    }

    const page1 = await request
      .get(`/api/workspaces/${ws.id}/conversations?limit=10`)
      .set('Authorization', `Bearer ${tk}`);

    expect(page1.body.items).toHaveLength(10);
    const cursor = page1.body.nextCursor;
    expect(cursor).toBeTruthy();

    const page2 = await request
      .get(`/api/workspaces/${ws.id}/conversations?limit=10&cursor=${cursor}`)
      .set('Authorization', `Bearer ${tk}`);

    expect(page2.status).toBe(200);
    expect(page2.body.items).toHaveLength(10);
    // Items on page 2 should not overlap with page 1
    const ids1 = page1.body.items.map((c) => c.id);
    const ids2 = page2.body.items.map((c) => c.id);
    expect(ids1.some((id) => ids2.includes(id))).toBe(false);
  });
});

describe('SPEC 07 — GET dernière page → nextCursor=null, hasMore=false', () => {
  it('last page has no cursor', async () => {
    const tk = await getToken();
    const ws = insertWorkspace(makeWorkspace());

    for (let i = 0; i < 5; i++) {
      sqlite
        .prepare(
          'INSERT INTO conversations (id, workspace_id, title, updated_at) VALUES (?, ?, ?, ?)'
        )
        .run(uuidv4(), ws.id, `Conv ${i}`, new Date(Date.now() + i * 1000).toISOString());
    }

    const res = await request
      .get(`/api/workspaces/${ws.id}/conversations?limit=10`)
      .set('Authorization', `Bearer ${tk}`);

    expect(res.status).toBe(200);
    expect(res.body.items).toHaveLength(5);
    expect(res.body.nextCursor).toBeNull();
    expect(res.body.hasMore).toBe(false);
  });
});

describe('SPEC 08 — GET filtre archived=false par défaut', () => {
  it('does not return archived conversations by default', async () => {
    const tk = await getToken();
    const ws = insertWorkspace(makeWorkspace());

    sqlite
      .prepare('INSERT INTO conversations (id, workspace_id, title, archived) VALUES (?, ?, ?, ?)')
      .run(uuidv4(), ws.id, 'Active', 0);
    sqlite
      .prepare('INSERT INTO conversations (id, workspace_id, title, archived) VALUES (?, ?, ?, ?)')
      .run(uuidv4(), ws.id, 'Archived', 1);

    const res = await request
      .get(`/api/workspaces/${ws.id}/conversations`)
      .set('Authorization', `Bearer ${tk}`);

    expect(res.status).toBe(200);
    expect(res.body.items).toHaveLength(1);
    expect(res.body.items[0].title).toBe('Active');
    expect(res.body.total).toBe(1);
  });
});

describe('SPEC 09 — GET ?archived=true inclut archivées', () => {
  it('returns archived conversations when filter is true', async () => {
    const tk = await getToken();
    const ws = insertWorkspace(makeWorkspace());

    sqlite
      .prepare('INSERT INTO conversations (id, workspace_id, title, archived) VALUES (?, ?, ?, ?)')
      .run(uuidv4(), ws.id, 'Active', 0);
    sqlite
      .prepare('INSERT INTO conversations (id, workspace_id, title, archived) VALUES (?, ?, ?, ?)')
      .run(uuidv4(), ws.id, 'Archived', 1);

    const res = await request
      .get(`/api/workspaces/${ws.id}/conversations?archived=true`)
      .set('Authorization', `Bearer ${tk}`);

    expect(res.status).toBe(200);
    expect(res.body.items).toHaveLength(1);
    expect(res.body.items[0].title).toBe('Archived');
  });
});

describe('SPEC 10 — GET ?pinned=true', () => {
  it('returns only pinned conversations', async () => {
    const tk = await getToken();
    const ws = insertWorkspace(makeWorkspace());

    sqlite
      .prepare('INSERT INTO conversations (id, workspace_id, title, pinned) VALUES (?, ?, ?, ?)')
      .run(uuidv4(), ws.id, 'Pinned', 1);
    sqlite
      .prepare('INSERT INTO conversations (id, workspace_id, title, pinned) VALUES (?, ?, ?, ?)')
      .run(uuidv4(), ws.id, 'Normal', 0);

    const res = await request
      .get(`/api/workspaces/${ws.id}/conversations?pinned=true`)
      .set('Authorization', `Bearer ${tk}`);

    expect(res.status).toBe(200);
    expect(res.body.items).toHaveLength(1);
    expect(res.body.items[0].title).toBe('Pinned');
  });
});

describe('SPEC 11 — GET /:id → détail + messageCount', () => {
  it('returns conversation detail with message count', async () => {
    const tk = await getToken();
    const ws = insertWorkspace(makeWorkspace());
    const convId = uuidv4();

    sqlite
      .prepare('INSERT INTO conversations (id, workspace_id, title) VALUES (?, ?, ?)')
      .run(convId, ws.id, 'Detailed Conv');

    // Insert 3 messages
    for (let i = 0; i < 3; i++) {
      sqlite
        .prepare(
          'INSERT INTO messages (id, conversation_id, role, content) VALUES (?, ?, ?, ?)'
        )
        .run(uuidv4(), convId, 'user', `Message ${i}`);
    }

    const res = await request
      .get(`/api/conversations/${convId}`)
      .set('Authorization', `Bearer ${tk}`);

    expect(res.status).toBe(200);
    expect(res.body.id).toBe(convId);
    expect(res.body.title).toBe('Detailed Conv');
    expect(res.body.messageCount).toBe(3);
  });
});

describe('SPEC 12 — GET /:id inexistant → 404', () => {
  it('returns 404 CONVERSATION_NOT_FOUND', async () => {
    const tk = await getToken();

    const res = await request
      .get(`/api/conversations/${uuidv4()}`)
      .set('Authorization', `Bearer ${tk}`);

    expect(res.status).toBe(404);
    expect(res.body.error).toBe('CONVERSATION_NOT_FOUND');
  });
});

describe('SPEC 13 — PATCH title', () => {
  it('updates conversation title', async () => {
    const tk = await getToken();
    const ws = insertWorkspace(makeWorkspace());
    const convId = uuidv4();

    sqlite
      .prepare('INSERT INTO conversations (id, workspace_id, title) VALUES (?, ?, ?)')
      .run(convId, ws.id, 'Old Title');

    const res = await request
      .patch(`/api/conversations/${convId}`)
      .set('Authorization', `Bearer ${tk}`)
      .send({ title: 'New Title' });

    expect(res.status).toBe(200);
    expect(res.body.title).toBe('New Title');
  });
});

describe('SPEC 14 — PATCH pinned=true', () => {
  it('sets conversation as pinned', async () => {
    const tk = await getToken();
    const ws = insertWorkspace(makeWorkspace());
    const convId = uuidv4();

    sqlite
      .prepare('INSERT INTO conversations (id, workspace_id, title) VALUES (?, ?, ?)')
      .run(convId, ws.id, 'Conv');

    const res = await request
      .patch(`/api/conversations/${convId}`)
      .set('Authorization', `Bearer ${tk}`)
      .send({ pinned: true });

    expect(res.status).toBe(200);
    expect(res.body.pinned).toBe(true);
  });
});

describe('SPEC 15 — PATCH pinned=false', () => {
  it('unpins conversation', async () => {
    const tk = await getToken();
    const ws = insertWorkspace(makeWorkspace());
    const convId = uuidv4();

    sqlite
      .prepare('INSERT INTO conversations (id, workspace_id, title, pinned) VALUES (?, ?, ?, ?)')
      .run(convId, ws.id, 'Conv', 1);

    const res = await request
      .patch(`/api/conversations/${convId}`)
      .set('Authorization', `Bearer ${tk}`)
      .send({ pinned: false });

    expect(res.status).toBe(200);
    expect(res.body.pinned).toBe(false);
  });
});

describe('SPEC 16 — PATCH archived=true → n\'apparaît plus dans listing défaut', () => {
  it('archived conversation disappears from default listing', async () => {
    const tk = await getToken();
    const ws = insertWorkspace(makeWorkspace());
    const convId = uuidv4();

    sqlite
      .prepare('INSERT INTO conversations (id, workspace_id, title) VALUES (?, ?, ?)')
      .run(convId, ws.id, 'To Archive');

    await request
      .patch(`/api/conversations/${convId}`)
      .set('Authorization', `Bearer ${tk}`)
      .send({ archived: true });

    const res = await request
      .get(`/api/workspaces/${ws.id}/conversations`)
      .set('Authorization', `Bearer ${tk}`);

    expect(res.body.items.find((c) => c.id === convId)).toBeUndefined();
  });
});

describe('SPEC 17 — PATCH archived=false → réapparaît dans listing', () => {
  it('unarchived conversation reappears in default listing', async () => {
    const tk = await getToken();
    const ws = insertWorkspace(makeWorkspace());
    const convId = uuidv4();

    sqlite
      .prepare('INSERT INTO conversations (id, workspace_id, title, archived) VALUES (?, ?, ?, ?)')
      .run(convId, ws.id, 'Was Archived', 1);

    await request
      .patch(`/api/conversations/${convId}`)
      .set('Authorization', `Bearer ${tk}`)
      .send({ archived: false });

    const res = await request
      .get(`/api/workspaces/${ws.id}/conversations`)
      .set('Authorization', `Bearer ${tk}`);

    expect(res.body.items.find((c) => c.id === convId)).toBeDefined();
  });
});

describe('SPEC 18 — PATCH inexistant → 404', () => {
  it('returns 404 CONVERSATION_NOT_FOUND', async () => {
    const tk = await getToken();

    const res = await request
      .patch(`/api/conversations/${uuidv4()}`)
      .set('Authorization', `Bearer ${tk}`)
      .send({ title: 'Ghost' });

    expect(res.status).toBe(404);
    expect(res.body.error).toBe('CONVERSATION_NOT_FOUND');
  });
});

describe('SPEC 19 — DELETE → 204 + messages supprimés en cascade', () => {
  it('deletes conversation and cascades to messages', async () => {
    const tk = await getToken();
    const ws = insertWorkspace(makeWorkspace());
    const convId = uuidv4();

    sqlite
      .prepare('INSERT INTO conversations (id, workspace_id, title) VALUES (?, ?, ?)')
      .run(convId, ws.id, 'To Delete');

    // Insert message
    sqlite
      .prepare('INSERT INTO messages (id, conversation_id, role, content) VALUES (?, ?, ?, ?)')
      .run(uuidv4(), convId, 'user', 'Hello');

    const res = await request
      .delete(`/api/conversations/${convId}`)
      .set('Authorization', `Bearer ${tk}`);

    expect(res.status).toBe(204);

    // Messages should be deleted
    const msgs = sqlite
      .prepare('SELECT * FROM messages WHERE conversation_id = ?')
      .all(convId);
    expect(msgs).toHaveLength(0);

    // Conversation should be gone
    const conv = sqlite.prepare('SELECT * FROM conversations WHERE id = ?').get(convId);
    expect(conv).toBeUndefined();
  });
});

describe('SPEC 20 — DELETE inexistant → 404', () => {
  it('returns 404 CONVERSATION_NOT_FOUND', async () => {
    const tk = await getToken();

    const res = await request
      .delete(`/api/conversations/${uuidv4()}`)
      .set('Authorization', `Bearer ${tk}`);

    expect(res.status).toBe(404);
    expect(res.body.error).toBe('CONVERSATION_NOT_FOUND');
  });
});

// ═══════════════════════════════════════════════════════════════════════════════
// MESSAGES
// ═══════════════════════════════════════════════════════════════════════════════

describe('SPEC 21 — POST message user → 201 + updated_at refreshed + WS broadcast (no crash)', () => {
  it('creates message and refreshes conversation.updated_at', async () => {
    const tk = await getToken();
    const ws = insertWorkspace(makeWorkspace());
    const convId = uuidv4();

    sqlite
      .prepare('INSERT INTO conversations (id, workspace_id, title) VALUES (?, ?, ?)')
      .run(convId, ws.id, 'Conv');

    const before = sqlite
      .prepare('SELECT updated_at FROM conversations WHERE id = ?')
      .get(convId);

    await new Promise((r) => setTimeout(r, 5));

    const res = await request
      .post(`/api/conversations/${convId}/messages`)
      .set('Authorization', `Bearer ${tk}`)
      .send({ role: 'user', content: 'Hello world' });

    expect(res.status).toBe(201);
    expect(res.body.role).toBe('user');
    expect(res.body.content).toBe('Hello world');
    expect(res.body.contentType).toBe('text');
    expect(res.body.conversationId).toBe(convId);

    const after = sqlite
      .prepare('SELECT updated_at FROM conversations WHERE id = ?')
      .get(convId);
    expect(after.updated_at).not.toBe(before.updated_at);
  });
});

describe('SPEC 22 — POST message assistant avec metadata', () => {
  it('stores and returns metadata as object', async () => {
    const tk = await getToken();
    const ws = insertWorkspace(makeWorkspace());
    const convId = uuidv4();

    sqlite
      .prepare('INSERT INTO conversations (id, workspace_id, title) VALUES (?, ?, ?)')
      .run(convId, ws.id, 'Conv');

    const meta = { tokens: 123, model: 'claude-sonnet' };

    const res = await request
      .post(`/api/conversations/${convId}/messages`)
      .set('Authorization', `Bearer ${tk}`)
      .send({ role: 'assistant', content: 'Response', metadata: meta });

    expect(res.status).toBe(201);
    expect(res.body.metadata).toEqual(meta);
  });
});

describe('SPEC 23 — POST message conversation inexistante → 404', () => {
  it('returns 404 CONVERSATION_NOT_FOUND', async () => {
    const tk = await getToken();

    const res = await request
      .post(`/api/conversations/${uuidv4()}/messages`)
      .set('Authorization', `Bearer ${tk}`)
      .send({ role: 'user', content: 'Hello' });

    expect(res.status).toBe(404);
    expect(res.body.error).toBe('CONVERSATION_NOT_FOUND');
  });
});

describe('SPEC 24 — role invalide → 400', () => {
  it('returns 400 VALIDATION_ERROR for invalid role', async () => {
    const tk = await getToken();
    const ws = insertWorkspace(makeWorkspace());
    const convId = uuidv4();

    sqlite
      .prepare('INSERT INTO conversations (id, workspace_id, title) VALUES (?, ?, ?)')
      .run(convId, ws.id, 'Conv');

    const res = await request
      .post(`/api/conversations/${convId}/messages`)
      .set('Authorization', `Bearer ${tk}`)
      .send({ role: 'robot', content: 'Hello' });

    expect(res.status).toBe(400);
    expect(res.body.error).toBe('VALIDATION_ERROR');
    expect(res.body.message).toMatch(/role must be one of/);
  });
});

describe('SPEC 25 — content absent → 400', () => {
  it('returns 400 VALIDATION_ERROR when content missing', async () => {
    const tk = await getToken();
    const ws = insertWorkspace(makeWorkspace());
    const convId = uuidv4();

    sqlite
      .prepare('INSERT INTO conversations (id, workspace_id, title) VALUES (?, ?, ?)')
      .run(convId, ws.id, 'Conv');

    const res = await request
      .post(`/api/conversations/${convId}/messages`)
      .set('Authorization', `Bearer ${tk}`)
      .send({ role: 'user' });

    expect(res.status).toBe(400);
    expect(res.body.error).toBe('VALIDATION_ERROR');
    expect(res.body.message).toMatch(/content is required/);
  });
});

describe('SPEC 26 — GET messages vide → { items: [], nextCursor: null, hasMore: false }', () => {
  it('returns empty list', async () => {
    const tk = await getToken();
    const ws = insertWorkspace(makeWorkspace());
    const convId = uuidv4();

    sqlite
      .prepare('INSERT INTO conversations (id, workspace_id, title) VALUES (?, ?, ?)')
      .run(convId, ws.id, 'Conv');

    const res = await request
      .get(`/api/conversations/${convId}/messages`)
      .set('Authorization', `Bearer ${tk}`);

    expect(res.status).toBe(200);
    expect(res.body.items).toEqual([]);
    expect(res.body.nextCursor).toBeNull();
    expect(res.body.hasMore).toBe(false);
  });
});

describe('SPEC 27 — GET 100 messages, limit=50 → 50 items + nextCursor', () => {
  it('paginates messages', async () => {
    const tk = await getToken();
    const ws = insertWorkspace(makeWorkspace());
    const convId = uuidv4();

    sqlite
      .prepare('INSERT INTO conversations (id, workspace_id, title) VALUES (?, ?, ?)')
      .run(convId, ws.id, 'Conv');

    for (let i = 0; i < 100; i++) {
      sqlite
        .prepare(
          'INSERT INTO messages (id, conversation_id, role, content, created_at) VALUES (?, ?, ?, ?, ?)'
        )
        .run(
          uuidv4(),
          convId,
          'user',
          `Message ${i}`,
          new Date(Date.now() + i * 1000).toISOString()
        );
    }

    const res = await request
      .get(`/api/conversations/${convId}/messages?limit=50`)
      .set('Authorization', `Bearer ${tk}`);

    expect(res.status).toBe(200);
    expect(res.body.items).toHaveLength(50);
    expect(res.body.nextCursor).toBeTruthy();
    expect(res.body.hasMore).toBe(true);
  });
});

describe('SPEC 28 — GET page suivante messages → 50 items restants + nextCursor=null', () => {
  it('returns second page of messages without next cursor', async () => {
    const tk = await getToken();
    const ws = insertWorkspace(makeWorkspace());
    const convId = uuidv4();

    sqlite
      .prepare('INSERT INTO conversations (id, workspace_id, title) VALUES (?, ?, ?)')
      .run(convId, ws.id, 'Conv');

    for (let i = 0; i < 100; i++) {
      sqlite
        .prepare(
          'INSERT INTO messages (id, conversation_id, role, content, created_at) VALUES (?, ?, ?, ?, ?)'
        )
        .run(
          uuidv4(),
          convId,
          'user',
          `Message ${i}`,
          new Date(Date.now() + i * 1000).toISOString()
        );
    }

    const page1 = await request
      .get(`/api/conversations/${convId}/messages?limit=50`)
      .set('Authorization', `Bearer ${tk}`);

    const cursor = page1.body.nextCursor;
    expect(cursor).toBeTruthy();

    const page2 = await request
      .get(`/api/conversations/${convId}/messages?limit=50&cursor=${cursor}`)
      .set('Authorization', `Bearer ${tk}`);

    expect(page2.status).toBe(200);
    expect(page2.body.items).toHaveLength(50);
    expect(page2.body.nextCursor).toBeNull();
    expect(page2.body.hasMore).toBe(false);
  });
});

describe('SPEC 29 — GET ?contentType=run_status filter', () => {
  it('filters messages by contentType', async () => {
    const tk = await getToken();
    const ws = insertWorkspace(makeWorkspace());
    const convId = uuidv4();

    sqlite
      .prepare('INSERT INTO conversations (id, workspace_id, title) VALUES (?, ?, ?)')
      .run(convId, ws.id, 'Conv');

    sqlite
      .prepare(
        'INSERT INTO messages (id, conversation_id, role, content, content_type) VALUES (?, ?, ?, ?, ?)'
      )
      .run(uuidv4(), convId, 'user', 'Regular message', 'text');

    sqlite
      .prepare(
        'INSERT INTO messages (id, conversation_id, role, content, content_type) VALUES (?, ?, ?, ?, ?)'
      )
      .run(uuidv4(), convId, 'assistant', 'Run started', 'run_status');

    const res = await request
      .get(`/api/conversations/${convId}/messages?contentType=run_status`)
      .set('Authorization', `Bearer ${tk}`);

    expect(res.status).toBe(200);
    expect(res.body.items).toHaveLength(1);
    expect(res.body.items[0].contentType).toBe('run_status');
  });
});

describe('SPEC 30 — GET messages conversation archivée → toujours accessibles', () => {
  it('messages of archived conversation are still accessible', async () => {
    const tk = await getToken();
    const ws = insertWorkspace(makeWorkspace());
    const convId = uuidv4();

    sqlite
      .prepare('INSERT INTO conversations (id, workspace_id, title, archived) VALUES (?, ?, ?, ?)')
      .run(convId, ws.id, 'Archived Conv', 1);

    sqlite
      .prepare('INSERT INTO messages (id, conversation_id, role, content) VALUES (?, ?, ?, ?)')
      .run(uuidv4(), convId, 'user', 'Old message');

    const res = await request
      .get(`/api/conversations/${convId}/messages`)
      .set('Authorization', `Bearer ${tk}`);

    expect(res.status).toBe(200);
    expect(res.body.items).toHaveLength(1);
  });
});

// ═══════════════════════════════════════════════════════════════════════════════
// SEARCH
// ═══════════════════════════════════════════════════════════════════════════════

describe('SPEC 31 — Search ?q=stripe → résultats multi-conversations', () => {
  it('finds messages matching query across conversations', async () => {
    const tk = await getToken();
    const ws = insertWorkspace(makeWorkspace());

    // Conv 1
    const conv1Id = uuidv4();
    sqlite
      .prepare('INSERT INTO conversations (id, workspace_id, title) VALUES (?, ?, ?)')
      .run(conv1Id, ws.id, 'Payments Conv');
    sqlite
      .prepare('INSERT INTO messages (id, conversation_id, role, content) VALUES (?, ?, ?, ?)')
      .run(uuidv4(), conv1Id, 'user', 'Integrate stripe checkout');

    // Conv 2
    const conv2Id = uuidv4();
    sqlite
      .prepare('INSERT INTO conversations (id, workspace_id, title) VALUES (?, ?, ?)')
      .run(conv2Id, ws.id, 'Billing Conv');
    sqlite
      .prepare('INSERT INTO messages (id, conversation_id, role, content) VALUES (?, ?, ?, ?)')
      .run(uuidv4(), conv2Id, 'assistant', 'Stripe webhooks need signing secret');

    // Irrelevant message
    sqlite
      .prepare('INSERT INTO messages (id, conversation_id, role, content) VALUES (?, ?, ?, ?)')
      .run(uuidv4(), conv1Id, 'user', 'unrelated message');

    const res = await request
      .get(`/api/workspaces/${ws.id}/search?q=stripe`)
      .set('Authorization', `Bearer ${tk}`);

    expect(res.status).toBe(200);
    expect(res.body.items).toHaveLength(2);
    expect(res.body.total).toBe(2);
    // Both items should have required fields
    expect(res.body.items[0]).toHaveProperty('messageId');
    expect(res.body.items[0]).toHaveProperty('conversationId');
    expect(res.body.items[0]).toHaveProperty('conversationTitle');
    expect(res.body.items[0]).toHaveProperty('content');
    expect(res.body.items[0]).toHaveProperty('createdAt');
  });
});

describe('SPEC 32 — Search sans résultats → { items: [], total: 0 }', () => {
  it('returns empty results', async () => {
    const tk = await getToken();
    const ws = insertWorkspace(makeWorkspace());

    const res = await request
      .get(`/api/workspaces/${ws.id}/search?q=nonexistentterm12345`)
      .set('Authorization', `Bearer ${tk}`);

    expect(res.status).toBe(200);
    expect(res.body.items).toEqual([]);
    expect(res.body.total).toBe(0);
  });
});

describe('SPEC 33 — Search sans q → 400', () => {
  it('returns 400 when q param is missing', async () => {
    const tk = await getToken();
    const ws = insertWorkspace(makeWorkspace());

    const res = await request
      .get(`/api/workspaces/${ws.id}/search`)
      .set('Authorization', `Bearer ${tk}`);

    expect(res.status).toBe(400);
  });
});
