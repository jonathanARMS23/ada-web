/**
 * Tests d'intégration E2E — flux complets end-to-end
 *
 * SPEC I-01 — Flux complet feature run (happy path)
 * SPEC I-02 — Run échoué
 * SPEC I-03 — Annulation + event IPC tardif
 * SPEC I-06 — Multi-device temps réel
 * SPEC I-07 — Isolation entre workspaces
 * SPEC I-08 — Cycle de vie workspace complet
 * SPEC I-09 — Cycle token complet
 *
 * IMPORTANT : les variables d'environnement DOIVENT être positionnées
 * avant tout import local (singleton db/client.js).
 */

// ─── Env FIRST ────────────────────────────────────────────────────────────────
process.env.DB_PATH               = ':memory:';
process.env.ADA_JWT_SECRET        = 'test-secret-e2e-flows-32chars-min!!';
process.env.ADA_AUTH_MODE         = 'local';
process.env.NODE_ENV              = 'test';
process.env.ADA_RUN_TIMEOUT       = '500';
process.env.ADA_WS_HEARTBEAT_INTERVAL = '99999'; // désactivé en pratique

// ─── Mock child_process.spawn (ada-core absent en tests) ─────────────────────
import { vi, describe, it, expect, beforeAll, afterAll, beforeEach } from 'vitest';

vi.mock('child_process', () => {
  const mockProcess = {
    pid:    99999,
    kill:   vi.fn(),
    on:     vi.fn(() => mockProcess),
    stdout: { on: vi.fn() },
    stderr: { on: vi.fn() },
  };
  return { spawn: vi.fn(() => mockProcess) };
});

import supertest from 'supertest';
import { WebSocket } from 'ws';
import { v4 as uuidv4 } from 'uuid';
import { readFileSync } from 'fs';

// ─── Imports locaux (après env + mock) ───────────────────────────────────────
const { createApp }             = await import('../../src/app.js');
const { db, sqlite }            = await import('../../src/db/client.js');
const { IpcHandler }            = await import('../../src/ipc/handler.js');
const { signToken, hashToken }  = await import('../../src/auth/jwt.js');

// ─── DDL : lire le vrai fichier de migration ──────────────────────────────────
function applyMigrations() {
  const sqlPath = new URL('../../src/db/migrations/0000_init.sql', import.meta.url).pathname;
  const ddl = readFileSync(sqlPath, 'utf-8');
  sqlite.exec(ddl);
}

// ─── État global partagé ──────────────────────────────────────────────────────
let app;
let port;
let token;
let ipcHandler;

// ─── Helper : créer un token valide et l'insérer en sessions ─────────────────
async function createAuthToken() {
  const secret = process.env.ADA_JWT_SECRET;
  const { token: t, expiresAt } = await signToken({}, secret, 7 * 86400);
  const hash = hashToken(t);
  sqlite
    .prepare('INSERT OR REPLACE INTO sessions (id, token_hash, expires_at) VALUES (?, ?, ?)')
    .run(uuidv4(), hash, expiresAt);
  return t;
}

// ─── Helper : créer un ticket one-time WS via l'API ──────────────────────────
async function createTicket(tok) {
  const res = await supertest(app.server)
    .get('/api/ws/ticket')
    .set('Authorization', `Bearer ${tok}`);
  if (res.status !== 200) throw new Error(`createTicket failed: ${res.status}`);
  return res.body.ticket;
}

// ─── Helper WS ────────────────────────────────────────────────────────────────
function connectWs(tok) {
  // Retourne un client avec waitOpen() — la création du ticket est asynchrone
  // mais le client peut être initialisé avant l'ouverture
  const ticketPromise = tok ? createTicket(tok) : Promise.resolve(null);

  const messageQueue = [];
  const waiters = [];

  // Proxy client qui attend le ticket avant d'ouvrir
  let _client = null;

  const clientProxy = {
    _ready: ticketPromise.then((ticketId) => {
      const url = ticketId
        ? `ws://127.0.0.1:${port}/ws?ticket=${ticketId}`
        : `ws://127.0.0.1:${port}/ws`;
      _client = new WebSocket(url);

      _client.on('message', (data) => {
        const msg = JSON.parse(data.toString());
        if (waiters.length > 0) {
          waiters.shift()(msg);
        } else {
          messageQueue.push(msg);
        }
      });

      return _client;
    }),

    nextMessage: (timeout = 2000) =>
      new Promise((resolve, reject) => {
        if (messageQueue.length > 0) return resolve(messageQueue.shift());
        const timer = setTimeout(
          () => reject(new Error('WS message timeout')),
          timeout,
        );
        waiters.push((msg) => {
          clearTimeout(timer);
          resolve(msg);
        });
      }),

    sendJSON: (obj) => _client.send(JSON.stringify(obj)),

    waitOpen: () =>
      clientProxy._ready.then(
        (client) =>
          new Promise((resolve, reject) => {
            if (client.readyState === WebSocket.OPEN) return resolve();
            client.once('open', resolve);
            client.once('error', reject);
          }),
      ),

    waitClose: (timeout = 1000) =>
      clientProxy._ready.then(
        (client) =>
          new Promise((resolve) => {
            if (client.readyState === WebSocket.CLOSED) return resolve({ code: 0 });
            const timer = setTimeout(() => resolve({ code: -1 }), timeout);
            client.once('close', (code, reason) => {
              clearTimeout(timer);
              resolve({ code, reason: reason.toString() });
            });
          }),
      ),

    close: () => _client?.close(),
  };

  return clientProxy;
}

// ─── Setup / teardown ─────────────────────────────────────────────────────────

beforeAll(async () => {
  applyMigrations();

  app = await createApp({ logger: false });
  app.ipcConnected = true; // simuler IPC connecté

  await app.listen({ port: 0 });
  port = app.server.address().port;

  token = await createAuthToken();

  // IpcHandler branché sur le même db + wsRooms du serveur
  ipcHandler = new IpcHandler(db, (event) => app.wsRooms.broadcastAll(event));
});

afterAll(async () => {
  if (app) await app.close();
});

beforeEach(() => {
  sqlite.exec('DELETE FROM run_links');
  sqlite.exec('DELETE FROM messages');
  sqlite.exec('DELETE FROM conversations');
  sqlite.exec('DELETE FROM workspaces');
  vi.clearAllMocks();
});

// ─────────────────────────────────────────────────────────────────────────────
// SPEC I-01 — Flux complet feature run (happy path)
// ─────────────────────────────────────────────────────────────────────────────
describe('SPEC I-01 — Flux complet feature run', () => {
  it('crée workspace + conversation, spawne run, reçoit events IPC via WS', async () => {
    const http = supertest(app.server);
    const auth = { Authorization: `Bearer ${token}` };

    // 1. Créer workspace
    const wsRes = await http
      .post('/api/workspaces')
      .set(auth)
      .send({ name: 'Mon Projet' });
    expect(wsRes.status).toBe(201);
    const wsId = wsRes.body.id;

    // 2. Créer conversation
    const convRes = await http
      .post(`/api/workspaces/${wsId}/conversations`)
      .set(auth)
      .send({ title: 'Sprint 1' });
    expect(convRes.status).toBe(201);
    const convId = convRes.body.id;

    // 3. Connecter client WS et rejoindre la room
    const client = connectWs(token);
    await client.waitOpen();
    const connectedMsg = await client.nextMessage();
    expect(connectedMsg.type).toBe('connected');

    client.sendJSON({ type: 'workspace.join', payload: { workspaceId: wsId } });
    const joinedMsg = await client.nextMessage();
    expect(joinedMsg.type).toBe('workspace.joined');

    // 4. Envoyer message utilisateur
    const msgRes = await http
      .post(`/api/conversations/${convId}/messages`)
      .set(auth)
      .send({ role: 'user', content: '/feature stripe-billing' });
    expect(msgRes.status).toBe(201);

    const msgNew = await client.nextMessage();
    expect(msgNew.type).toBe('message.new');
    expect(msgNew.message.content).toBe('/feature stripe-billing');

    // 5. Spawner le run
    const runRes = await http
      .post('/api/runs')
      .set(auth)
      .send({
        pipeline:       'feature',
        args:           ['--name', 'stripe-billing'],
        workspaceId:    wsId,
        conversationId: convId,
      });
    expect(runRes.status).toBe(202);
    const runId = runRes.body.runId;

    const runStarted = await client.nextMessage();
    expect(runStarted.type).toBe('run.started');
    expect(runStarted.runId).toBe(runId);

    // 6. Simuler events IPC ada-core
    await ipcHandler.handle({ type: 'run.phase.started', runId, phaseId: 'schema' });
    const phaseStarted = await client.nextMessage();
    expect(phaseStarted.type).toBe('run.phase.started');

    await ipcHandler.handle({
      type:    'run.phase.log',
      runId,
      phaseId: 'schema',
      line:    'Création table payments...',
    });
    const phaseLog = await client.nextMessage();
    expect(phaseLog.type).toBe('run.phase.log');

    await ipcHandler.handle({
      type:    'run.phase.done',
      runId,
      phaseId: 'schema',
      status:  'success',
    });
    const phaseDone = await client.nextMessage();
    expect(phaseDone.type).toBe('run.phase.done');

    await ipcHandler.handle({
      type:       'run.done',
      runId,
      status:     'completed',
      totalCost:  0.18,
      summary:    'Feature stripe-billing livrée.',
    });
    const runDone = await client.nextMessage();
    expect(runDone.type).toBe('run.done');

    // 7. Vérifier état final en DB
    const runStatus = await http.get(`/api/runs/${runId}`).set(auth);
    expect(runStatus.body.status).toBe('completed');
    expect(runStatus.body.totalCost).toBe(0.18);

    // Vérifier messages (user + system run démarré)
    const msgs = await http.get(`/api/conversations/${convId}/messages`).set(auth);
    expect(msgs.body.items.length).toBeGreaterThanOrEqual(2);

    // Vérifier stats workspace
    const stats = await http.get(`/api/workspaces/${wsId}/stats`).set(auth);
    expect(stats.body.totalRuns).toBe(1);
    expect(stats.body.totalCost).toBeCloseTo(0.18, 2);

    client.close();
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// SPEC I-02 — Run échoué
// ─────────────────────────────────────────────────────────────────────────────
describe('SPEC I-02 — Run échoué', () => {
  it('run.done status=failed → run_links.status=failed', async () => {
    const http = supertest(app.server);
    const auth = { Authorization: `Bearer ${token}` };

    const wsRes = await http
      .post('/api/workspaces')
      .set(auth)
      .send({ name: 'Projet Failed' });
    const convRes = await http
      .post(`/api/workspaces/${wsRes.body.id}/conversations`)
      .set(auth)
      .send({ title: 'Test' });

    const client = connectWs(token);
    await client.waitOpen();
    await client.nextMessage(); // connected

    client.sendJSON({ type: 'workspace.join', payload: { workspaceId: wsRes.body.id } });
    await client.nextMessage(); // joined

    const runRes = await http
      .post('/api/runs')
      .set(auth)
      .send({
        pipeline:       'feature',
        workspaceId:    wsRes.body.id,
        conversationId: convRes.body.id,
      });
    expect(runRes.status).toBe(202);
    const runId = runRes.body.runId;

    await client.nextMessage(); // run.started broadcast

    await ipcHandler.handle({
      type:      'run.done',
      runId,
      status:    'failed',
      totalCost: 0.03,
      summary:   'Échec: timeout backend.',
    });
    const doneMsg = await client.nextMessage();
    expect(doneMsg.type).toBe('run.done');

    const runStatus = await http.get(`/api/runs/${runId}`).set(auth);
    expect(runStatus.body.status).toBe('failed');

    client.close();
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// SPEC I-03 — Annulation + event IPC tardif
// ─────────────────────────────────────────────────────────────────────────────
describe('SPEC I-03 — Annulation + event IPC tardif', () => {
  it('DELETE run → cancelled ; run.done tardif ne réécrase pas le status', async () => {
    const http = supertest(app.server);
    const auth = { Authorization: `Bearer ${token}` };

    const wsRes = await http
      .post('/api/workspaces')
      .set(auth)
      .send({ name: 'Projet Cancel' });
    const convRes = await http
      .post(`/api/workspaces/${wsRes.body.id}/conversations`)
      .set(auth)
      .send({ title: 'Test' });

    const client = connectWs(token);
    await client.waitOpen();
    await client.nextMessage(); // connected

    client.sendJSON({ type: 'workspace.join', payload: { workspaceId: wsRes.body.id } });
    await client.nextMessage(); // joined

    const runRes = await http
      .post('/api/runs')
      .set(auth)
      .send({
        pipeline:       'feature',
        workspaceId:    wsRes.body.id,
        conversationId: convRes.body.id,
      });
    expect(runRes.status).toBe(202);
    const runId = runRes.body.runId;

    await client.nextMessage(); // run.started

    // Annuler le run
    const cancelRes = await http.delete(`/api/runs/${runId}`).set(auth);
    expect(cancelRes.status).toBe(204);

    const cancelBroadcast = await client.nextMessage();
    expect(cancelBroadcast.type).toBe('run.cancelled');

    // Vérifier status cancelled
    const afterCancel = await http.get(`/api/runs/${runId}`).set(auth);
    expect(afterCancel.body.status).toBe('cancelled');

    // Event IPC tardif — ne doit pas écraser le status cancelled
    await ipcHandler.handle({
      type:      'run.done',
      runId,
      status:    'completed',
      totalCost: 0.10,
      summary:   'OK',
    });

    const afterLate = await http.get(`/api/runs/${runId}`).set(auth);
    expect(afterLate.body.status).toBe('cancelled'); // statut final inchangé

    client.close();
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// SPEC I-06 — Multi-device temps réel
// ─────────────────────────────────────────────────────────────────────────────
describe('SPEC I-06 — Multi-device temps réel', () => {
  it('message POST → reçu par browser ET mobile dans la même room', async () => {
    const http = supertest(app.server);
    const auth = { Authorization: `Bearer ${token}` };

    const wsRes = await http
      .post('/api/workspaces')
      .set(auth)
      .send({ name: 'Multi Device' });
    const convRes = await http
      .post(`/api/workspaces/${wsRes.body.id}/conversations`)
      .set(auth)
      .send({ title: 'Test' });

    const browser = connectWs(token);
    const mobile  = connectWs(token);
    await browser.waitOpen();
    await mobile.waitOpen();
    await browser.nextMessage(); // connected
    await mobile.nextMessage();  // connected

    browser.sendJSON({ type: 'workspace.join', payload: { workspaceId: wsRes.body.id } });
    mobile.sendJSON({ type: 'workspace.join', payload: { workspaceId: wsRes.body.id } });
    await browser.nextMessage(); // joined
    await mobile.nextMessage();  // joined

    // POST message — les deux clients doivent le recevoir
    await http
      .post(`/api/conversations/${convRes.body.id}/messages`)
      .set(auth)
      .send({ role: 'user', content: 'Hello depuis browser' });

    const [bMsg, mMsg] = await Promise.all([
      browser.nextMessage(),
      mobile.nextMessage(),
    ]);
    expect(bMsg.type).toBe('message.new');
    expect(mMsg.type).toBe('message.new');
    expect(bMsg.message.content).toBe('Hello depuis browser');
    expect(mMsg.message.content).toBe('Hello depuis browser');

    // Mobile se déconnecte
    mobile.close();
    await new Promise((r) => setTimeout(r, 80));

    // Second message → seulement browser reçoit
    await http
      .post(`/api/conversations/${convRes.body.id}/messages`)
      .set(auth)
      .send({ role: 'user', content: 'Message 2' });

    const bMsg2 = await browser.nextMessage();
    expect(bMsg2.message.content).toBe('Message 2');

    browser.close();
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// SPEC I-07 — Isolation entre workspaces
// ─────────────────────────────────────────────────────────────────────────────
describe('SPEC I-07 — Isolation entre workspaces', () => {
  it('messages dans ws-abc ne parviennent pas à client dans ws-xyz', async () => {
    const http = supertest(app.server);
    const auth = { Authorization: `Bearer ${token}` };

    const wsA = await http
      .post('/api/workspaces')
      .set(auth)
      .send({ name: 'WS Alpha' });
    const wsB = await http
      .post('/api/workspaces')
      .set(auth)
      .send({ name: 'WS Beta' });

    const convA = await http
      .post(`/api/workspaces/${wsA.body.id}/conversations`)
      .set(auth)
      .send({ title: 'A' });
    // convB created but not needed for the broadcast assertion
    await http
      .post(`/api/workspaces/${wsB.body.id}/conversations`)
      .set(auth)
      .send({ title: 'B' });

    const clientA = connectWs(token);
    const clientB = connectWs(token);
    await clientA.waitOpen();
    await clientB.waitOpen();
    await clientA.nextMessage(); // connected
    await clientB.nextMessage(); // connected

    clientA.sendJSON({ type: 'workspace.join', payload: { workspaceId: wsA.body.id } });
    clientB.sendJSON({ type: 'workspace.join', payload: { workspaceId: wsB.body.id } });
    await clientA.nextMessage(); // joined
    await clientB.nextMessage(); // joined

    // Message pour ws-alpha → seul client A reçoit
    await http
      .post(`/api/conversations/${convA.body.id}/messages`)
      .set(auth)
      .send({ role: 'user', content: 'Pour ws-abc' });

    const msgA = await clientA.nextMessage();
    expect(msgA.type).toBe('message.new');
    expect(msgA.conversationId).toBe(convA.body.id);

    // Client B ne doit PAS avoir reçu ce message
    let bReceived = false;
    clientB.nextMessage(200).then(() => { bReceived = true; }).catch(() => {});
    await new Promise((r) => setTimeout(r, 300));
    expect(bReceived).toBe(false);

    clientA.close();
    clientB.close();
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// SPEC I-08 — Cycle de vie workspace complet
// ─────────────────────────────────────────────────────────────────────────────
describe('SPEC I-08 — Cycle de vie workspace : création → utilisation → archivage → suppression', () => {
  it('full lifecycle', async () => {
    const http = supertest(app.server);
    const auth = { Authorization: `Bearer ${token}` };

    // 1. Création
    const wsRes = await http
      .post('/api/workspaces')
      .set(auth)
      .send({ name: 'Projet Test' });
    expect(wsRes.status).toBe(201);
    const wsId = wsRes.body.id;

    // 2. Utilisation
    const convRes = await http
      .post(`/api/workspaces/${wsId}/conversations`)
      .set(auth)
      .send({ title: 'Sprint 1' });
    const convId = convRes.body.id;

    await http
      .post(`/api/conversations/${convId}/messages`)
      .set(auth)
      .send({ role: 'user', content: 'Démarrage' });

    const stats1 = await http.get(`/api/workspaces/${wsId}/stats`).set(auth);
    expect(stats1.body.totalMessages).toBe(1);

    // 3. Archivage conversation
    const archiveRes = await http
      .patch(`/api/conversations/${convId}`)
      .set(auth)
      .send({ archived: true });
    expect(archiveRes.body.archived).toBe(true);

    // Liste sans param → exclut les archivées par défaut
    const listRes = await http
      .get(`/api/workspaces/${wsId}/conversations`)
      .set(auth);
    expect(listRes.body.total).toBe(0);

    // Accessible directement par ID
    const msgsRes = await http
      .get(`/api/conversations/${convId}/messages`)
      .set(auth);
    expect(msgsRes.status).toBe(200);

    // 4. Suppression workspace (cascade)
    const delRes = await http.delete(`/api/workspaces/${wsId}`).set(auth);
    expect(delRes.status).toBe(204);

    expect(
      (await http.get(`/api/workspaces/${wsId}`).set(auth)).status
    ).toBe(404);

    expect(
      (await http.get(`/api/conversations/${convId}`).set(auth)).status
    ).toBe(404);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// SPEC I-09 — Cycle token complet
// ─────────────────────────────────────────────────────────────────────────────
describe('SPEC I-09 — Cycle token : génération → utilisation → refresh → révocation', () => {
  it('full auth lifecycle', async () => {
    const http = supertest(app.server);

    // 1. Générer T1
    const t1Res = await http.post('/api/auth/token').send({});
    expect(t1Res.status).toBe(200);
    const T1 = t1Res.body.token;
    expect(T1).toBeTruthy();

    // 2. Utiliser T1
    const wsList = await http
      .get('/api/workspaces')
      .set('Authorization', `Bearer ${T1}`);
    expect(wsList.status).toBe(200);

    // 3. Refresh → T2
    const refreshRes = await http
      .post('/api/auth/refresh')
      .set('Authorization', `Bearer ${T1}`);
    expect(refreshRes.status).toBe(200);
    const T2 = refreshRes.body.token;
    expect(T2).not.toBe(T1);

    // T1 révoqué après refresh
    const t1After = await http
      .get('/api/workspaces')
      .set('Authorization', `Bearer ${T1}`);
    expect(t1After.status).toBe(401);
    expect(t1After.body.error).toBe('TOKEN_REVOKED');

    // 4. T2 fonctionne
    const t2Check = await http
      .get('/api/workspaces')
      .set('Authorization', `Bearer ${T2}`);
    expect(t2Check.status).toBe(200);

    // Révoquer T2
    const logoutRes = await http
      .delete('/api/auth/session')
      .set('Authorization', `Bearer ${T2}`);
    expect(logoutRes.status).toBe(204);

    const t2After = await http
      .get('/api/workspaces')
      .set('Authorization', `Bearer ${T2}`);
    expect(t2After.status).toBe(401);
    expect(t2After.body.error).toBe('TOKEN_REVOKED');

    // Sans token
    const noToken = await http.get('/api/workspaces');
    expect(noToken.status).toBe(401);
    expect(noToken.body.error).toBe('UNAUTHORIZED');
  });
});
