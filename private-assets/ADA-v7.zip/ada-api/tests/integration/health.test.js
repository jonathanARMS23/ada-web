/**
 * TDD — RED phase
 * Integration tests for health routes (Sprint 3)
 * SPEC 01–10
 *
 * Env MUST be set before any local import (singleton DB_PATH)
 */

// ─── Env FIRST ───────────────────────────────────────────────────────────────
process.env.DB_PATH = ':memory:';
process.env.ADA_JWT_SECRET = 'test-secret-health-check-32chars!!';
process.env.ADA_AUTH_MODE = 'local';
process.env.NODE_ENV = 'test';

import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import supertest from 'supertest';
import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __dirname = dirname(fileURLToPath(import.meta.url));

// ─── Lazy imports (after env) ─────────────────────────────────────────────────
const { createApp } = await import('../../src/app.js');
const { sqlite }    = await import('../../src/db/client.js');

// ─── Helpers ──────────────────────────────────────────────────────────────────
function applyMigrations(db) {
  const sqlPath = join(__dirname, '../../src/db/migrations/0000_init.sql');
  db.exec(readFileSync(sqlPath, 'utf-8'));
}

const pkg = JSON.parse(
  readFileSync(join(__dirname, '../../package.json'), 'utf-8'),
);

// ─── Shared app instance ──────────────────────────────────────────────────────
let app;
let request;

beforeAll(async () => {
  applyMigrations(sqlite);
  app     = await createApp({ logger: false });
  await app.ready();
  request = supertest(app.server);
});

afterAll(async () => {
  if (app) await app.close();
});

// ─── SPEC 01 — GET /api/health shape ─────────────────────────────────────────
describe('SPEC 01 — GET /api/health shape', () => {
  it('returns 200 with required fields (ipcConnected=false → degraded)', async () => {
    const res = await request.get('/api/health');

    expect(res.status).toBe(200);
    expect(res.headers['content-type']).toMatch(/application\/json/);

    const b = res.body;
    // status degraded because IPC offline
    expect(b.status).toBe('degraded');
    expect(b.db).toBe('ok');
    expect(b.core).toBe('offline');

    // ws object with numeric fields
    expect(b.ws).toBeDefined();
    expect(typeof b.ws.activeConnections).toBe('number');
    expect(typeof b.ws.activeRooms).toBe('number');
    expect(b.ws.activeConnections).toBeGreaterThanOrEqual(0);
    expect(b.ws.activeRooms).toBeGreaterThanOrEqual(0);

    // version semver
    expect(b.version).toMatch(/^\d+\.\d+\.\d+/);

    // uptime integer >= 0
    expect(typeof b.uptime).toBe('number');
    expect(Number.isInteger(b.uptime)).toBe(true);
    expect(b.uptime).toBeGreaterThanOrEqual(0);

    // ts ISO-8601
    expect(b.ts).toBeDefined();
    expect(() => new Date(b.ts).toISOString()).not.toThrow();
    expect(b.ts).toMatch(/^\d{4}-\d{2}-\d{2}T/);
  });
});

// ─── SPEC 02 — uptime croissant ───────────────────────────────────────────────
describe('SPEC 02 — uptime', () => {
  it('uptime >= 0 and is an integer (seconds)', async () => {
    // Wait briefly so module-level startedAt is definitely in the past
    await new Promise((r) => setTimeout(r, 200));

    const res = await request.get('/api/health');
    expect(res.status).toBe(200);

    const { uptime } = res.body;
    expect(typeof uptime).toBe('number');
    expect(Number.isInteger(uptime)).toBe(true);
    expect(uptime).toBeGreaterThanOrEqual(0);
  });
});

// ─── SPEC 03 — version = package.json ────────────────────────────────────────
describe('SPEC 03 — version matches package.json', () => {
  it('version field equals package.json version', async () => {
    const res = await request.get('/api/health');
    expect(res.status).toBe(200);
    expect(res.body.version).toBe(pkg.version);
  });
});

// ─── SPEC 04 — IPC offline ───────────────────────────────────────────────────
describe('SPEC 04 — IPC offline', () => {
  it('status=degraded, core=offline, db=ok when ipcConnected=false', async () => {
    // app.ipcConnected is false by default (set in createApp)
    const res = await request.get('/api/health');
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('degraded');
    expect(res.body.core).toBe('offline');
    expect(res.body.db).toBe('ok');
  });
});

// ─── SPEC 05 — DB inaccessible ───────────────────────────────────────────────
describe('SPEC 05 — DB error on /api/health', () => {
  it('returns 200 status=degraded, db=error, dbError present', async () => {
    // Mock sqlite.prepare to throw
    const originalPrepare = app.sqlite.prepare.bind(app.sqlite);
    app.sqlite.prepare = () => { throw new Error('DB unavailable'); };

    try {
      const res = await request.get('/api/health');
      expect(res.status).toBe(200);
      expect(res.body.status).toBe('degraded');
      expect(res.body.db).toBe('error');
      expect(res.body.dbError).toBeDefined();
      expect(typeof res.body.dbError).toBe('string');
    } finally {
      app.sqlite.prepare = originalPrepare;
    }
  });
});

// ─── SPEC 06 — Tous services down ────────────────────────────────────────────
describe('SPEC 06 — All services down', () => {
  it('IPC offline + DB error → status=degraded, db=error, core=offline', async () => {
    // ipcConnected stays false (default); mock DB
    const originalPrepare = app.sqlite.prepare.bind(app.sqlite);
    app.sqlite.prepare = () => { throw new Error('DB gone'); };

    try {
      const res = await request.get('/api/health');
      expect(res.status).toBe(200);
      expect(res.body.status).toBe('degraded');
      expect(res.body.db).toBe('error');
      expect(res.body.core).toBe('offline');
    } finally {
      app.sqlite.prepare = originalPrepare;
    }
  });
});

// ─── SPEC 07 — Zéro WS ───────────────────────────────────────────────────────
describe('SPEC 07 — WS stats at zero', () => {
  it('ws.activeConnections=0 and ws.activeRooms=0 with no clients connected', async () => {
    const res = await request.get('/api/health');
    expect(res.status).toBe(200);
    expect(res.body.ws.activeConnections).toBe(0);
    expect(res.body.ws.activeRooms).toBe(0);
  });
});

// ─── SPEC 08 — GET /api/health/live ──────────────────────────────────────────
describe('SPEC 08 — GET /api/health/live', () => {
  it('returns 200 { alive: true } without auth token', async () => {
    const res = await request.get('/api/health/live');
    expect(res.status).toBe(200);
    expect(res.body).toEqual({ alive: true });
  });

  it('responds quickly (< 500ms)', async () => {
    const start = Date.now();
    await request.get('/api/health/live');
    expect(Date.now() - start).toBeLessThan(500);
  });
});

// ─── SPEC 09 — GET /api/health/ready — DB ok ─────────────────────────────────
describe('SPEC 09 — GET /api/health/ready (DB accessible)', () => {
  it('returns 200 { ready: true }', async () => {
    const res = await request.get('/api/health/ready');
    expect(res.status).toBe(200);
    expect(res.body).toEqual({ ready: true });
  });
});

// ─── SPEC 10 — GET /api/health/ready — DB inaccessible ───────────────────────
describe('SPEC 10 — GET /api/health/ready (DB inaccessible)', () => {
  it('returns 503 { ready: false, reason: "database unavailable" }', async () => {
    const originalPrepare = app.sqlite.prepare.bind(app.sqlite);
    app.sqlite.prepare = () => { throw new Error('DB unavailable'); };

    try {
      const res = await request.get('/api/health/ready');
      expect(res.status).toBe(503);
      expect(res.body.ready).toBe(false);
      expect(res.body.reason).toBe('database unavailable');
    } finally {
      app.sqlite.prepare = originalPrepare;
    }
  });
});
