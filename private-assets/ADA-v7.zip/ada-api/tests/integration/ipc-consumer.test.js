/**
 * TDD — RED phase
 * Integration tests for IPC consumer (IpcClient + IpcHandler)
 * Uses in-memory SQLite and a local net.Server mock.
 *
 * DB_PATH is overridden per-test via env before importing db/client.
 */
import { describe, it, expect, vi, beforeEach, afterEach, beforeAll } from 'vitest';
import net from 'net';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { randomBytes } from 'crypto';

// ─── Test DB helper ───────────────────────────────────────────────────────────
import Database from 'better-sqlite3';
import { drizzle } from 'drizzle-orm/better-sqlite3';
import * as schema from '../../src/db/schema.js';
import { eq, and, isNull } from 'drizzle-orm';

function createTestDb() {
  const sqlite = new Database(':memory:');
  sqlite.pragma('journal_mode = WAL');
  sqlite.pragma('foreign_keys = ON');

  // Apply schema via raw SQL (same as migration 0000_init.sql)
  sqlite.exec(`
    CREATE TABLE IF NOT EXISTS workspaces (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      slug TEXT NOT NULL UNIQUE,
      profile TEXT NOT NULL,
      description TEXT,
      color TEXT NOT NULL DEFAULT '#6366f1',
      project_dir TEXT,
      pinned INTEGER NOT NULL DEFAULT 0,
      archived INTEGER NOT NULL DEFAULT 0,
      run_count INTEGER NOT NULL DEFAULT 0,
      config TEXT NOT NULL DEFAULT '{}',
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
      updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );

    CREATE TABLE IF NOT EXISTS conversations (
      id TEXT PRIMARY KEY,
      workspace_id TEXT NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
      title TEXT NOT NULL,
      summary TEXT,
      pinned INTEGER NOT NULL DEFAULT 0,
      archived INTEGER NOT NULL DEFAULT 0,
      run_count INTEGER NOT NULL DEFAULT 0,
      last_run_id TEXT,
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
      updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );

    CREATE TABLE IF NOT EXISTS messages (
      id TEXT PRIMARY KEY,
      conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
      role TEXT NOT NULL CHECK(role IN ('user','assistant','system','tool','error')),
      content TEXT NOT NULL,
      content_type TEXT NOT NULL DEFAULT 'text' CHECK(content_type IN ('text','code','run_status','phase_log')),
      metadata TEXT NOT NULL DEFAULT '{}',
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );

    CREATE TABLE IF NOT EXISTS run_links (
      run_id TEXT PRIMARY KEY,
      conversation_id TEXT REFERENCES conversations(id) ON DELETE RESTRICT,
      workspace_id TEXT NOT NULL REFERENCES workspaces(id) ON DELETE RESTRICT,
      pipeline TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'running' CHECK(status IN ('running','completed','failed','cancelled','completed_with_errors')),
      phases TEXT NOT NULL DEFAULT '{}',
      total_cost REAL NOT NULL DEFAULT 0,
      total_tokens INTEGER NOT NULL DEFAULT 0,
      started_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
      completed_at TEXT
    );

    CREATE TABLE IF NOT EXISTS sessions (
      id TEXT PRIMARY KEY,
      token_hash TEXT NOT NULL UNIQUE,
      expires_at TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );

    CREATE TABLE IF NOT EXISTS workspace_settings (
      workspace_id TEXT NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
      key TEXT NOT NULL,
      value TEXT,
      PRIMARY KEY (workspace_id, key)
    );

    CREATE TABLE IF NOT EXISTS ipc_events (
      id TEXT PRIMARY KEY,
      type TEXT NOT NULL,
      payload TEXT NOT NULL,
      processed INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );
  `);

  const db = drizzle(sqlite, { schema });
  return { db, sqlite };
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function tmpSock() {
  return path.join(os.tmpdir(), `test-ada-${randomBytes(6).toString('hex')}.sock`);
}

function sendLine(socket, obj) {
  socket.write(JSON.stringify(obj) + '\n');
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// ─── Mock server factory ──────────────────────────────────────────────────────
function createMockServer(sockPath) {
  const connections = [];
  const received = [];

  const server = net.createServer((conn) => {
    connections.push(conn);
    conn.on('data', (buf) => {
      buf.toString().split('\n').filter(Boolean).forEach((line) => {
        try { received.push(JSON.parse(line)); } catch {}
      });
    });
  });

  return new Promise((resolve, reject) => {
    server.listen(sockPath, () => {
      resolve({
        server,
        connections,
        received,
        send(obj) {
          connections.forEach((c) => sendLine(c, obj));
        },
        close() {
          return new Promise((res) => server.close(res));
        },
      });
    });
    server.on('error', reject);
  });
}

// ─── Suites ───────────────────────────────────────────────────────────────────
describe('IPC Consumer — Integration', () => {
  let mockServer;
  let sockPath;
  let testDb;
  let broadcasts;
  let IpcClient, IpcHandler;

  beforeAll(async () => {
    // Dynamic import so env is read at test time
    ({ IpcClient } = await import('../../src/ipc/client.js'));
    ({ IpcHandler } = await import('../../src/ipc/handler.js'));
  });

  beforeEach(async () => {
    sockPath = tmpSock();
    mockServer = await createMockServer(sockPath);
    testDb = createTestDb();
    broadcasts = [];

    // Seed a workspace (needed for FK in run_links)
    testDb.db.insert(schema.workspaces).values({
      id: 'ws-test-001',
      name: 'Test Workspace',
      slug: 'test-workspace',
      profile: 'fullstack',
    }).run();
  });

  afterEach(async () => {
    await mockServer.close();
    try { fs.unlinkSync(sockPath); } catch {}
    testDb.sqlite.close();
  });

  // ─── SPEC 01: Hello handshake ─────────────────────────────────────────────
  it('SPEC 01 — connects via Unix socket and sends HELLO message', async () => {
    const client = new IpcClient({ socketPath: sockPath, mode: 'unix', reconnectDelay: 500 });
    client.connect();

    await delay(200);

    expect(mockServer.received).toEqual(
      expect.arrayContaining([
        expect.objectContaining({ type: 'hello', service: 'ada-api' }),
      ])
    );

    client.disconnect();
  });

  // ─── SPEC 04: Auto-reconnect ──────────────────────────────────────────────
  it('SPEC 04 — reconnects automatically after socket.destroy()', async () => {
    const client = new IpcClient({ socketPath: sockPath, mode: 'unix', reconnectDelay: 100 });
    client.connect();

    await delay(150);
    expect(mockServer.connections).toHaveLength(1);

    // Kill first connection
    mockServer.connections[0].destroy();
    await delay(400);

    // Should have reconnected
    expect(mockServer.connections.length).toBeGreaterThanOrEqual(2);

    client.disconnect();
  });

  // ─── SPEC 06: No crash if ada-core absent ────────────────────────────────
  it('SPEC 06 — starts without crash if ada-core socket does not exist', async () => {
    const absentPath = tmpSock(); // never bound
    const client = new IpcClient({
      socketPath: absentPath,
      mode: 'unix',
      reconnectDelay: 100,
      tcpFallback: false,
    });

    expect(() => client.connect()).not.toThrow();
    await delay(300);
    client.disconnect();
  });

  // ─── SPEC 07: run.started → run_links created ────────────────────────────
  it('SPEC 07 — run.started creates a run_links row in DB', async () => {
    const handler = new IpcHandler(testDb.db, (msg) => broadcasts.push(msg));
    const client = new IpcClient({ socketPath: sockPath, mode: 'unix', reconnectDelay: 500 });
    client.on('message', (event) => handler.handle(event));
    client.connect();

    await delay(150);

    mockServer.send({
      type: 'run.started',
      runId: 'run-spec07',
      pipeline: 'fullstack',
      workspaceId: 'ws-test-001',
      // no conversationId — avoids FK constraint (conversation not seeded in this test)
    });

    await delay(200);

    const rows = testDb.db.select().from(schema.run_links)
      .where(eq(schema.run_links.run_id, 'run-spec07')).all();

    expect(rows).toHaveLength(1);
    expect(rows[0].status).toBe('running');
    expect(rows[0].pipeline).toBe('fullstack');

    client.disconnect();
  });

  // ─── SPEC 08: run.started without conversationId ─────────────────────────
  it('SPEC 08 — run.started without conversationId stores null in DB', async () => {
    const handler = new IpcHandler(testDb.db, (msg) => broadcasts.push(msg));
    const client = new IpcClient({ socketPath: sockPath, mode: 'unix', reconnectDelay: 500 });
    client.on('message', (event) => handler.handle(event));
    client.connect();

    await delay(150);

    mockServer.send({
      type: 'run.started',
      runId: 'run-spec08',
      pipeline: 'frontend',
      workspaceId: 'ws-test-001',
    });

    await delay(200);

    const rows = testDb.db.select().from(schema.run_links)
      .where(eq(schema.run_links.run_id, 'run-spec08')).all();

    expect(rows).toHaveLength(1);
    expect(rows[0].conversation_id).toBeNull();

    client.disconnect();
  });

  // ─── SPEC 10: run.phase.log → broadcast only ─────────────────────────────
  it('SPEC 10 — run.phase.log broadcasts but does NOT write to DB', async () => {
    const handler = new IpcHandler(testDb.db, (msg) => broadcasts.push(msg));
    const client = new IpcClient({ socketPath: sockPath, mode: 'unix', reconnectDelay: 500 });
    client.on('message', (event) => handler.handle(event));
    client.connect();

    await delay(150);

    mockServer.send({
      type: 'run.phase.log',
      runId: 'run-spec10',
      phaseId: 'phase-1',
      log: 'doing something...',
    });

    await delay(200);

    // No DB write for run_links (run never started)
    const rows = testDb.db.select().from(schema.run_links).all();
    expect(rows).toHaveLength(0);

    // But broadcast happened
    const phaseLogBroadcasts = broadcasts.filter((b) => b.type === 'run.phase.log');
    expect(phaseLogBroadcasts).toHaveLength(1);

    client.disconnect();
  });

  // ─── SPEC 11: run.done → update + message + run_count ────────────────────
  it('SPEC 11 — run.done updates run_links, creates message, increments run_count', async () => {
    // Seed conversation
    testDb.db.insert(schema.conversations).values({
      id: 'conv-spec11',
      workspace_id: 'ws-test-001',
      title: 'Test conversation',
    }).run();

    const handler = new IpcHandler(testDb.db, (msg) => broadcasts.push(msg));
    const client = new IpcClient({ socketPath: sockPath, mode: 'unix', reconnectDelay: 500 });
    client.on('message', (event) => handler.handle(event));
    client.connect();

    await delay(150);

    // First: start the run
    mockServer.send({
      type: 'run.started',
      runId: 'run-spec11',
      pipeline: 'fullstack',
      workspaceId: 'ws-test-001',
      conversationId: 'conv-spec11',
    });

    await delay(150);

    // Then: complete it
    mockServer.send({
      type: 'run.done',
      runId: 'run-spec11',
      status: 'completed',
      totalCost: 0.042,
      totalTokens: 8500,
      conversationId: 'conv-spec11',
    });

    await delay(200);

    // run_links updated
    const runs = testDb.db.select().from(schema.run_links)
      .where(eq(schema.run_links.run_id, 'run-spec11')).all();
    expect(runs[0].status).toBe('completed');
    expect(runs[0].total_cost).toBeCloseTo(0.042);
    expect(runs[0].completed_at).not.toBeNull();

    // message created
    const msgs = testDb.db.select().from(schema.messages)
      .where(eq(schema.messages.conversation_id, 'conv-spec11')).all();
    expect(msgs).toHaveLength(1);
    expect(msgs[0].content_type).toBe('run_status');

    // run_count incremented
    const convs = testDb.db.select().from(schema.conversations)
      .where(eq(schema.conversations.id, 'conv-spec11')).all();
    expect(convs[0].run_count).toBe(1);

    client.disconnect();
  });

  // ─── SPEC 14: Partial NDJSON chunk ───────────────────────────────────────
  it('SPEC 14 — partial NDJSON message split across 2 TCP chunks is handled correctly', async () => {
    const handler = new IpcHandler(testDb.db, (msg) => broadcasts.push(msg));
    const client = new IpcClient({ socketPath: sockPath, mode: 'unix', reconnectDelay: 500 });
    client.on('message', (event) => handler.handle(event));
    client.connect();

    await delay(150);

    const event = {
      type: 'run.started',
      runId: 'run-spec14',
      pipeline: 'fullstack',
      workspaceId: 'ws-test-001',
    };
    const full = JSON.stringify(event) + '\n';
    const half = Math.floor(full.length / 2);

    // Send in two chunks with a gap
    mockServer.connections[0].write(full.slice(0, half));
    await delay(50);
    mockServer.connections[0].write(full.slice(half));

    await delay(200);

    const rows = testDb.db.select().from(schema.run_links)
      .where(eq(schema.run_links.run_id, 'run-spec14')).all();
    expect(rows).toHaveLength(1);

    client.disconnect();
  });

  // ─── SPEC 15: Multiple messages in one chunk ──────────────────────────────
  it('SPEC 15 — two messages in one TCP chunk are both processed', async () => {
    const handler = new IpcHandler(testDb.db, (msg) => broadcasts.push(msg));
    const client = new IpcClient({ socketPath: sockPath, mode: 'unix', reconnectDelay: 500 });
    client.on('message', (event) => handler.handle(event));
    client.connect();

    await delay(150);

    const e1 = { type: 'run.started', runId: 'run-spec15a', pipeline: 'fp', workspaceId: 'ws-test-001' };
    const e2 = { type: 'run.started', runId: 'run-spec15b', pipeline: 'bp', workspaceId: 'ws-test-001' };
    const combined = JSON.stringify(e1) + '\n' + JSON.stringify(e2) + '\n';
    mockServer.connections[0].write(combined);

    await delay(300);

    const rows = testDb.db.select().from(schema.run_links).all();
    const ids = rows.map((r) => r.run_id);
    expect(ids).toContain('run-spec15a');
    expect(ids).toContain('run-spec15b');

    client.disconnect();
  });

  // ─── SPEC 16: Malformed JSON → WARN, no crash ────────────────────────────
  it('SPEC 16 — malformed JSON logs WARN and does not crash', async () => {
    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});
    const handler = new IpcHandler(testDb.db, (msg) => broadcasts.push(msg));
    const client = new IpcClient({ socketPath: sockPath, mode: 'unix', reconnectDelay: 500 });
    client.on('message', (event) => handler.handle(event));
    client.connect();

    await delay(150);

    mockServer.connections[0].write('{ definitely not json }\n');
    await delay(200);

    expect(warnSpy).toHaveBeenCalled();
    // Client is still alive
    expect(client.connected).toBe(true);

    warnSpy.mockRestore();
    client.disconnect();
  });

  // ─── SPEC 17: Unknown event type → WARN, no action ───────────────────────
  it('SPEC 17 — unknown event type logs WARN and takes no DB action', async () => {
    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});
    const handler = new IpcHandler(testDb.db, (msg) => broadcasts.push(msg));
    const client = new IpcClient({ socketPath: sockPath, mode: 'unix', reconnectDelay: 500 });
    client.on('message', (event) => handler.handle(event));
    client.connect();

    await delay(150);

    mockServer.send({ type: 'totally.unknown.event', data: 'whatever' });
    await delay(200);

    const rows = testDb.db.select().from(schema.run_links).all();
    expect(rows).toHaveLength(0);
    expect(warnSpy).toHaveBeenCalledWith(
      expect.stringContaining('totally.unknown.event')
    );

    warnSpy.mockRestore();
    client.disconnect();
  });

  // ─── SPEC 19: Idempotent run.started ─────────────────────────────────────
  it('SPEC 19 — duplicate run.started is idempotent (no duplicate row)', async () => {
    const handler = new IpcHandler(testDb.db, (msg) => broadcasts.push(msg));
    const client = new IpcClient({ socketPath: sockPath, mode: 'unix', reconnectDelay: 500 });
    client.on('message', (event) => handler.handle(event));
    client.connect();

    await delay(150);

    const event = {
      type: 'run.started',
      runId: 'run-spec19',
      pipeline: 'fullstack',
      workspaceId: 'ws-test-001',
    };

    mockServer.send(event);
    await delay(150);
    mockServer.send(event); // duplicate
    await delay(150);

    const rows = testDb.db.select().from(schema.run_links)
      .where(eq(schema.run_links.run_id, 'run-spec19')).all();
    expect(rows).toHaveLength(1);

    client.disconnect();
  });

  // ─── SPEC 20: Idempotent run.done ────────────────────────────────────────
  it('SPEC 20 — duplicate run.done does not create duplicate messages', async () => {
    testDb.db.insert(schema.conversations).values({
      id: 'conv-spec20',
      workspace_id: 'ws-test-001',
      title: 'Idempotence test',
    }).run();

    const handler = new IpcHandler(testDb.db, (msg) => broadcasts.push(msg));
    const client = new IpcClient({ socketPath: sockPath, mode: 'unix', reconnectDelay: 500 });
    client.on('message', (event) => handler.handle(event));
    client.connect();

    await delay(150);

    mockServer.send({
      type: 'run.started',
      runId: 'run-spec20',
      pipeline: 'fullstack',
      workspaceId: 'ws-test-001',
      conversationId: 'conv-spec20',
    });

    await delay(150);

    const doneEvent = {
      type: 'run.done',
      runId: 'run-spec20',
      status: 'completed',
      totalCost: 0.01,
      totalTokens: 1000,
      conversationId: 'conv-spec20',
    };

    mockServer.send(doneEvent);
    await delay(150);
    mockServer.send(doneEvent); // duplicate
    await delay(150);

    const msgs = testDb.db.select().from(schema.messages)
      .where(eq(schema.messages.conversation_id, 'conv-spec20')).all();
    expect(msgs).toHaveLength(1); // exactly one, not two

    client.disconnect();
  });
});
