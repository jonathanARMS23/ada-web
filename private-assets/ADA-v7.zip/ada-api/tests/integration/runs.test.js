/**
 * TDD — RED phase
 * Integration tests for /api/runs routes (23 specs)
 *
 * DB_PATH is set BEFORE any local import (module singleton pattern).
 */

// ─── Env override (must be first) ────────────────────────────────────────────
process.env.DB_PATH = ':memory:';
process.env.ADA_JWT_SECRET = 'test-secret-runs-service-32chars-m';
process.env.ADA_AUTH_MODE = 'local';
process.env.NODE_ENV = 'test';
process.env.ADA_RUN_TIMEOUT = '200'; // 200ms for fast timeout tests

// ─── Mock child_process.spawn ─────────────────────────────────────────────────
import { describe, it, expect, beforeAll, afterAll, beforeEach, vi } from 'vitest';

vi.mock('child_process', () => {
  const mockProcess = {
    pid: 12345,
    kill: vi.fn(),
    on: vi.fn((event, cb) => mockProcess),
    stdout: { on: vi.fn() },
    stderr: { on: vi.fn() },
  };
  return { spawn: vi.fn(() => mockProcess), __mockProcess: mockProcess };
});

import supertest from 'supertest';
import { v4 as uuidv4 } from 'uuid';
import * as childProcess from 'child_process';

// ─── App + DB imports ─────────────────────────────────────────────────────────
const { createApp } = await import('../../src/app.js');
const { sqlite } = await import('../../src/db/client.js');
const { IpcHandler } = await import('../../src/ipc/handler.js');
import { drizzle } from 'drizzle-orm/better-sqlite3';
import * as schema from '../../src/db/schema.js';

// ─── DDL for in-memory DB ─────────────────────────────────────────────────────
const DDL = `
  CREATE TABLE IF NOT EXISTS workspaces (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    slug TEXT NOT NULL UNIQUE,
    profile TEXT NOT NULL,
    description TEXT,
    color TEXT NOT NULL DEFAULT '#6366f1',
    project_dir TEXT,
    config TEXT NOT NULL DEFAULT '{}',
    pinned INTEGER NOT NULL DEFAULT 0,
    archived INTEGER NOT NULL DEFAULT 0,
    run_count INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  );

  CREATE TABLE IF NOT EXISTS conversations (
    id TEXT PRIMARY KEY,
    workspace_id TEXT NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    summary TEXT,
    pinned INTEGER NOT NULL DEFAULT 0,
    archived INTEGER NOT NULL DEFAULT 0,
    run_count INTEGER NOT NULL DEFAULT 0,
    last_run_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  );

  CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY,
    conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    role TEXT NOT NULL CHECK(role IN ('user','assistant','system','tool','error')),
    content TEXT NOT NULL,
    content_type TEXT NOT NULL DEFAULT 'text' CHECK(content_type IN ('text','code','run_status','phase_log')),
    metadata TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  );

  CREATE TABLE IF NOT EXISTS run_links (
    run_id TEXT PRIMARY KEY,
    conversation_id TEXT REFERENCES conversations(id) ON DELETE SET NULL,
    workspace_id TEXT REFERENCES workspaces(id) ON DELETE SET NULL,
    pipeline TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'running' CHECK(status IN ('running','completed','failed','cancelled','completed_with_errors')),
    phases TEXT NOT NULL DEFAULT '{}',
    total_cost REAL NOT NULL DEFAULT 0,
    total_tokens INTEGER NOT NULL DEFAULT 0,
    started_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    completed_at TEXT
  );

  CREATE TABLE IF NOT EXISTS sessions (
    id TEXT PRIMARY KEY,
    token_hash TEXT NOT NULL UNIQUE,
    expires_at TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  );

  CREATE TABLE IF NOT EXISTS workspace_settings (
    workspace_id TEXT NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
    key TEXT NOT NULL,
    value TEXT,
    PRIMARY KEY (workspace_id, key)
  );

  CREATE TABLE IF NOT EXISTS ipc_events (
    id TEXT PRIMARY KEY,
    type TEXT NOT NULL,
    payload TEXT NOT NULL,
    processed INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  );
`;

// ─── Globals ──────────────────────────────────────────────────────────────────
let app;
let request;
let token;
const db = drizzle(sqlite, { schema });

// ─── Fixtures ─────────────────────────────────────────────────────────────────
const WS_ID = 'ws-test-0001';
const WS_ID_2 = 'ws-test-0002';
const CONV_ID = 'conv-test-0001';

function insertWorkspace(id = WS_ID, slug = 'test-ws') {
  sqlite.prepare(
    'INSERT OR IGNORE INTO workspaces (id, name, slug, profile) VALUES (?, ?, ?, ?)'
  ).run(id, 'Test WS', slug, 'fullstack');
}

function insertConversation(id = CONV_ID, wsId = WS_ID) {
  sqlite.prepare(
    'INSERT OR IGNORE INTO conversations (id, workspace_id, title) VALUES (?, ?, ?)'
  ).run(id, wsId, 'Test Conv');
}

// ─── beforeAll ────────────────────────────────────────────────────────────────
beforeAll(async () => {
  sqlite.exec(DDL);

  app = await createApp({ logger: false });

  // Simulate IPC connected for most tests
  app.ipcConnected = true;

  await app.ready();
  request = supertest(app.server);

  // Get auth token
  const res = await request.post('/api/auth/token').send({});
  token = res.body.token;
});

afterAll(async () => {
  if (app) await app.close();
});

beforeEach(() => {
  // Clear mutable tables between tests
  sqlite.exec('DELETE FROM run_links');
  sqlite.exec('DELETE FROM messages');
  sqlite.exec('DELETE FROM conversations');
  sqlite.exec('DELETE FROM workspaces');
  vi.clearAllMocks();
});

// ─── Helpers ─────────────────────────────────────────────────────────────────
function authHeader() {
  return { Authorization: `Bearer ${token}` };
}

async function postRun(body) {
  return request
    .post('/api/runs')
    .set(authHeader())
    .send(body);
}

async function getRun(id) {
  return request
    .get(`/api/runs/${id}`)
    .set(authHeader());
}

// ─── SPEC 01 — POST run → 202, run_links créé, message system ajouté, WS broadcast ──
describe('SPEC 01 — POST /api/runs → 202, run_links + message system + broadcast', () => {
  it('returns 202 with runId, status=starting, pipeline', async () => {
    insertWorkspace();
    insertConversation();

    const res = await postRun({
      pipeline: 'fullstack',
      workspaceId: WS_ID,
      conversationId: CONV_ID,
    });

    expect(res.status).toBe(202);
    expect(res.body).toHaveProperty('runId');
    expect(res.body.status).toBe('starting');
    expect(res.body.pipeline).toBe('fullstack');
  });

  it('run_links row is created with status=running', async () => {
    insertWorkspace();
    insertConversation();

    const res = await postRun({
      pipeline: 'fullstack',
      workspaceId: WS_ID,
      conversationId: CONV_ID,
    });

    const row = sqlite.prepare('SELECT * FROM run_links WHERE run_id = ?').get(res.body.runId);
    expect(row).toBeTruthy();
    expect(row.status).toBe('running');
    expect(row.pipeline).toBe('fullstack');
    expect(row.workspace_id).toBe(WS_ID);
    expect(row.conversation_id).toBe(CONV_ID);
  });

  it('system message is inserted when conversationId is provided', async () => {
    insertWorkspace();
    insertConversation();

    const res = await postRun({
      pipeline: 'fullstack',
      workspaceId: WS_ID,
      conversationId: CONV_ID,
    });

    const msg = sqlite.prepare(
      "SELECT * FROM messages WHERE conversation_id = ? AND role = 'system'"
    ).get(CONV_ID);
    expect(msg).toBeTruthy();
    expect(msg.content).toContain('fullstack');
  });
});

// ─── SPEC 02 — runId transmis à spawn comme --run-id <runId> ──────────────────
describe('SPEC 02 — spawn reçoit --run-id <runId> dans les args', () => {
  it('spawn is called with --run-id matching the returned runId', async () => {
    insertWorkspace();

    const res = await postRun({ pipeline: 'backend', workspaceId: WS_ID });

    expect(res.status).toBe(202);
    const { spawn } = childProcess;
    expect(spawn).toHaveBeenCalled();

    const spawnArgs = spawn.mock.calls[0];
    const argsArray = spawnArgs[1]; // second argument = args array
    const runIdIdx = argsArray.indexOf('--run-id');
    expect(runIdIdx).toBeGreaterThan(-1);
    expect(argsArray[runIdIdx + 1]).toBe(res.body.runId);
  });
});

// ─── SPEC 03 — POST sans conversationId → run_links.conversation_id=null ──────
describe('SPEC 03 — POST sans conversationId → conversation_id=null, pas de message', () => {
  it('run_links.conversation_id is null', async () => {
    insertWorkspace();

    const res = await postRun({ pipeline: 'backend', workspaceId: WS_ID });

    const row = sqlite.prepare('SELECT * FROM run_links WHERE run_id = ?').get(res.body.runId);
    expect(row.conversation_id).toBeNull();
  });

  it('no system message is inserted', async () => {
    insertWorkspace();

    await postRun({ pipeline: 'backend', workspaceId: WS_ID });

    const count = sqlite.prepare('SELECT COUNT(*) as c FROM messages').get();
    expect(count.c).toBe(0);
  });
});

// ─── SPEC 04 — pipeline absent → 400 ─────────────────────────────────────────
describe('SPEC 04 — pipeline absent → 400 VALIDATION_ERROR', () => {
  it('returns 400 with VALIDATION_ERROR when pipeline is missing', async () => {
    const res = await postRun({ workspaceId: WS_ID });
    expect(res.status).toBe(400);
    expect(res.body.error).toBe('VALIDATION_ERROR');
    expect(res.body.message).toMatch(/pipeline/i);
  });

  it('returns 400 when pipeline is empty string', async () => {
    const res = await postRun({ pipeline: '', workspaceId: WS_ID });
    expect(res.status).toBe(400);
    expect(res.body.error).toBe('VALIDATION_ERROR');
  });
});

// ─── SPEC 05 — workspaceId absent → 400 ──────────────────────────────────────
describe('SPEC 05 — workspaceId absent → 400 VALIDATION_ERROR', () => {
  it('returns 400 with VALIDATION_ERROR when workspaceId is missing', async () => {
    const res = await postRun({ pipeline: 'backend' });
    expect(res.status).toBe(400);
    expect(res.body.error).toBe('VALIDATION_ERROR');
    expect(res.body.message).toMatch(/workspaceId/i);
  });
});

// ─── SPEC 06 — workspace inexistant → 404 ────────────────────────────────────
describe('SPEC 06 — workspace inexistant → 404 WORKSPACE_NOT_FOUND', () => {
  it('returns 404 when workspaceId does not exist in DB', async () => {
    const res = await postRun({ pipeline: 'backend', workspaceId: 'nonexistent-ws' });
    expect(res.status).toBe(404);
    expect(res.body.error).toBe('WORKSPACE_NOT_FOUND');
  });
});

// ─── SPEC 07 — IPC offline → 503 ADA_CORE_OFFLINE ───────────────────────────
describe('SPEC 07 — IPC offline → 503', () => {
  it('returns 503 ADA_CORE_OFFLINE when ipcConnected is false', async () => {
    insertWorkspace();
    app.ipcConnected = false;

    try {
      const res = await postRun({ pipeline: 'backend', workspaceId: WS_ID });
      expect(res.status).toBe(503);
      expect(res.body.error).toBe('ADA_CORE_OFFLINE');
    } finally {
      app.ipcConnected = true;
    }
  });
});

// ─── SPEC 08 — GET /:id run en cours → 200 avec tous les champs ──────────────
describe('SPEC 08 — GET /api/runs/:id run en cours → 200', () => {
  it('returns 200 with all required fields for a running run', async () => {
    insertWorkspace();
    const runId = uuidv4();
    sqlite.prepare(
      'INSERT INTO run_links (run_id, workspace_id, pipeline, status) VALUES (?, ?, ?, ?)'
    ).run(runId, WS_ID, 'fullstack', 'running');

    const res = await getRun(runId);
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty('runId');
    expect(res.body).toHaveProperty('pipeline');
    expect(res.body).toHaveProperty('status', 'running');
    expect(res.body).toHaveProperty('workspaceId');
    expect(res.body).toHaveProperty('totalCost');
    expect(res.body).toHaveProperty('totalTokens');
    expect(res.body).toHaveProperty('startedAt');
  });
});

// ─── SPEC 09 — GET /:id run complété → status=completed, totalCost présent ───
describe('SPEC 09 — GET /api/runs/:id run complété', () => {
  it('returns status=completed and totalCost', async () => {
    insertWorkspace();
    const runId = uuidv4();
    sqlite.prepare(
      'INSERT INTO run_links (run_id, workspace_id, pipeline, status, total_cost, completed_at) VALUES (?, ?, ?, ?, ?, ?)'
    ).run(runId, WS_ID, 'backend', 'completed', 1.23, new Date().toISOString());

    const res = await getRun(runId);
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('completed');
    expect(res.body.totalCost).toBe(1.23);
    expect(res.body).toHaveProperty('completedAt');
  });
});

// ─── SPEC 10 — GET /:id inexistant → 404 ─────────────────────────────────────
describe('SPEC 10 — GET /api/runs/:id inexistant → 404', () => {
  it('returns 404 RUN_NOT_FOUND', async () => {
    const res = await getRun('nonexistent-run-id');
    expect(res.status).toBe(404);
    expect(res.body.error).toBe('RUN_NOT_FOUND');
  });
});

// ─── SPEC 11 — GET ?workspaceId=ws-abc → 3 runs filtrés ─────────────────────
describe('SPEC 11 — GET /api/runs?workspaceId → filtre par workspace', () => {
  it('returns only runs for the given workspaceId', async () => {
    insertWorkspace(WS_ID, 'ws-1');
    insertWorkspace(WS_ID_2, 'ws-2');

    // 3 runs for WS_ID, 1 for WS_ID_2
    for (let i = 0; i < 3; i++) {
      sqlite.prepare(
        'INSERT INTO run_links (run_id, workspace_id, pipeline) VALUES (?, ?, ?)'
      ).run(uuidv4(), WS_ID, 'fullstack');
    }
    sqlite.prepare(
      'INSERT INTO run_links (run_id, workspace_id, pipeline) VALUES (?, ?, ?)'
    ).run(uuidv4(), WS_ID_2, 'backend');

    const res = await request
      .get(`/api/runs?workspaceId=${WS_ID}`)
      .set(authHeader());

    expect(res.status).toBe(200);
    expect(res.body.items).toHaveLength(3);
    expect(res.body.total).toBe(3);
    expect(res.body.items.every((r) => r.workspaceId === WS_ID)).toBe(true);
  });
});

// ─── SPEC 12 — GET ?status=running → 1 run filtré ────────────────────────────
describe('SPEC 12 — GET /api/runs?status=running → filtre par status', () => {
  it('returns only running runs', async () => {
    insertWorkspace();

    sqlite.prepare(
      'INSERT INTO run_links (run_id, workspace_id, pipeline, status) VALUES (?, ?, ?, ?)'
    ).run(uuidv4(), WS_ID, 'p1', 'running');
    sqlite.prepare(
      'INSERT INTO run_links (run_id, workspace_id, pipeline, status) VALUES (?, ?, ?, ?)'
    ).run(uuidv4(), WS_ID, 'p2', 'completed');
    sqlite.prepare(
      'INSERT INTO run_links (run_id, workspace_id, pipeline, status) VALUES (?, ?, ?, ?)'
    ).run(uuidv4(), WS_ID, 'p3', 'failed');

    const res = await request.get('/api/runs?status=running').set(authHeader());

    expect(res.status).toBe(200);
    expect(res.body.items).toHaveLength(1);
    expect(res.body.items[0].status).toBe('running');
  });
});

// ─── SPEC 13 — GET ?conversationId=conv-xyz → 2 runs filtrés ─────────────────
describe('SPEC 13 — GET /api/runs?conversationId → filtre par conversationId', () => {
  it('returns only runs for the given conversationId', async () => {
    insertWorkspace();
    const convId2 = 'conv-test-0002';
    insertConversation(CONV_ID, WS_ID);
    insertConversation(convId2, WS_ID);

    sqlite.prepare(
      'INSERT INTO run_links (run_id, workspace_id, conversation_id, pipeline) VALUES (?, ?, ?, ?)'
    ).run(uuidv4(), WS_ID, CONV_ID, 'p1');
    sqlite.prepare(
      'INSERT INTO run_links (run_id, workspace_id, conversation_id, pipeline) VALUES (?, ?, ?, ?)'
    ).run(uuidv4(), WS_ID, CONV_ID, 'p2');
    sqlite.prepare(
      'INSERT INTO run_links (run_id, workspace_id, conversation_id, pipeline) VALUES (?, ?, ?, ?)'
    ).run(uuidv4(), WS_ID, convId2, 'p3');

    const res = await request
      .get(`/api/runs?conversationId=${CONV_ID}`)
      .set(authHeader());

    expect(res.status).toBe(200);
    expect(res.body.items).toHaveLength(2);
    expect(res.body.items.every((r) => r.conversationId === CONV_ID)).toBe(true);
  });
});

// ─── SPEC 14 — Event IPC run.phase.started → broadcast (pas de DB write) ─────
describe('SPEC 14 — IPC run.phase.started → broadcast seulement', () => {
  it('handler broadcasts and does NOT write to DB', async () => {
    insertWorkspace();
    const runId = uuidv4();
    sqlite.prepare(
      'INSERT INTO run_links (run_id, workspace_id, pipeline, status) VALUES (?, ?, ?, ?)'
    ).run(runId, WS_ID, 'fullstack', 'running');

    const broadcasts = [];
    const handler = new IpcHandler(db, (event) => broadcasts.push(event));

    await handler.handle({ type: 'run.phase.started', runId, phase: 'backend' });

    // Broadcast was called
    expect(broadcasts).toHaveLength(1);
    expect(broadcasts[0].type).toBe('run.phase.started');

    // Status unchanged in DB
    const row = sqlite.prepare('SELECT status FROM run_links WHERE run_id = ?').get(runId);
    expect(row.status).toBe('running');
  });
});

// ─── SPEC 15 — Event IPC run.done → run_links.status=completed ───────────────
describe('SPEC 15 — IPC run.done → status=completed en DB', () => {
  it('handler updates run_links.status to completed', async () => {
    insertWorkspace();
    const runId = uuidv4();
    sqlite.prepare(
      'INSERT INTO run_links (run_id, workspace_id, pipeline, status) VALUES (?, ?, ?, ?)'
    ).run(runId, WS_ID, 'fullstack', 'running');

    const handler = new IpcHandler(db, () => {});

    await handler.handle({
      type: 'run.done',
      runId,
      status: 'completed',
      totalCost: 0.5,
      totalTokens: 1000,
    });

    const row = sqlite.prepare('SELECT * FROM run_links WHERE run_id = ?').get(runId);
    expect(row.status).toBe('completed');
    expect(row.total_cost).toBe(0.5);
    expect(row.total_tokens).toBe(1000);
    expect(row.completed_at).toBeTruthy();
  });
});

// ─── SPEC 16 — DELETE run running → 204, SIGTERM, status=cancelled, broadcast ─
describe('SPEC 16 — DELETE /api/runs/:id running → 204 + SIGTERM + cancelled', () => {
  it('returns 204, sends SIGTERM, updates status to cancelled', async () => {
    insertWorkspace();
    const runId = uuidv4();
    sqlite.prepare(
      'INSERT INTO run_links (run_id, workspace_id, pipeline, status) VALUES (?, ?, ?, ?)'
    ).run(runId, WS_ID, 'fullstack', 'running');

    // Register an active process for this runId
    const { _setActiveProcessForTest } = await import('../../src/services/run.js');
    const mockKill = vi.fn();
    _setActiveProcessForTest(runId, { pid: 99999, kill: mockKill });

    const res = await request
      .delete(`/api/runs/${runId}`)
      .set(authHeader());

    expect(res.status).toBe(204);

    // Status updated in DB
    const row = sqlite.prepare('SELECT status FROM run_links WHERE run_id = ?').get(runId);
    expect(row.status).toBe('cancelled');

    // SIGTERM sent
    expect(mockKill).toHaveBeenCalledWith('SIGTERM');
  });
});

// ─── SPEC 17 — DELETE run completed → 204 idempotent ─────────────────────────
describe('SPEC 17 — DELETE run completed → 204 idempotent', () => {
  it('returns 204 without modifying status when already completed', async () => {
    insertWorkspace();
    const runId = uuidv4();
    sqlite.prepare(
      'INSERT INTO run_links (run_id, workspace_id, pipeline, status) VALUES (?, ?, ?, ?)'
    ).run(runId, WS_ID, 'fullstack', 'completed');

    const res = await request
      .delete(`/api/runs/${runId}`)
      .set(authHeader());

    expect(res.status).toBe(204);

    const row = sqlite.prepare('SELECT status FROM run_links WHERE run_id = ?').get(runId);
    expect(row.status).toBe('completed');
  });
});

// ─── SPEC 18 — DELETE run cancelled → 204 idempotent ─────────────────────────
describe('SPEC 18 — DELETE run cancelled → 204 idempotent', () => {
  it('returns 204 without modifying status when already cancelled', async () => {
    insertWorkspace();
    const runId = uuidv4();
    sqlite.prepare(
      'INSERT INTO run_links (run_id, workspace_id, pipeline, status) VALUES (?, ?, ?, ?)'
    ).run(runId, WS_ID, 'fullstack', 'cancelled');

    const res = await request
      .delete(`/api/runs/${runId}`)
      .set(authHeader());

    expect(res.status).toBe(204);

    const row = sqlite.prepare('SELECT status FROM run_links WHERE run_id = ?').get(runId);
    expect(row.status).toBe('cancelled');
  });
});

// ─── SPEC 19 — DELETE inexistant → 404 ───────────────────────────────────────
describe('SPEC 19 — DELETE /api/runs/:id inexistant → 404', () => {
  it('returns 404 RUN_NOT_FOUND', async () => {
    const res = await request
      .delete('/api/runs/nonexistent-run')
      .set(authHeader());

    expect(res.status).toBe(404);
    expect(res.body.error).toBe('RUN_NOT_FOUND');
  });
});

// ─── SPEC 20 — run.done pour runId orphelin → WARN loggé, pas de DB write ────
describe('SPEC 20 — run.done pour runId orphelin → WARN, pas de DB write', () => {
  it('does not write to DB when runId does not exist', async () => {
    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});
    const broadcasts = [];
    const handler = new IpcHandler(db, (event) => broadcasts.push(event));

    const orphanRunId = 'orphan-run-' + uuidv4();
    await handler.handle({
      type: 'run.done',
      runId: orphanRunId,
      status: 'completed',
    });

    // No row inserted
    const row = sqlite.prepare('SELECT * FROM run_links WHERE run_id = ?').get(orphanRunId);
    expect(row).toBeUndefined();

    // Broadcast still happens (handler forwards it)
    expect(broadcasts).toHaveLength(1);

    warnSpy.mockRestore();
  });
});

// ─── SPEC 21 — Deux runs parallèles → deux runIds distincts ──────────────────
describe('SPEC 21 — Deux runs parallèles → deux runIds distincts', () => {
  it('two concurrent POST /api/runs return different runIds', async () => {
    insertWorkspace();

    const [res1, res2] = await Promise.all([
      postRun({ pipeline: 'frontend', workspaceId: WS_ID }),
      postRun({ pipeline: 'backend', workspaceId: WS_ID }),
    ]);

    expect(res1.status).toBe(202);
    expect(res2.status).toBe(202);
    expect(res1.body.runId).not.toBe(res2.body.runId);

    // Both exist in DB
    const rows = sqlite.prepare('SELECT run_id FROM run_links').all();
    expect(rows).toHaveLength(2);
  });
});

// ─── SPEC 22 — args avec chars spéciaux → spawn avec tableau (shell=false) ───
describe('SPEC 22 — spawn avec shell=false et args en tableau', () => {
  it('spawn is called with shell: false and args as array (never string)', async () => {
    insertWorkspace();

    const res = await postRun({
      pipeline: 'backend',
      args: ['--foo', 'bar-baz', '--qux'],
      workspaceId: WS_ID,
    });

    expect(res.status).toBe(202);

    const { spawn } = childProcess;
    expect(spawn).toHaveBeenCalled();

    const [cmd, args, opts] = spawn.mock.calls[0];
    // Command as string (not array)
    expect(typeof cmd).toBe('string');
    // Args as array, never joined as a string
    expect(Array.isArray(args)).toBe(true);
    // shell: false explicitly
    expect(opts.shell).toBe(false);
    // Verify args are preserved as separate elements (no spaces allowed)
    expect(args).toContain('--foo');
    expect(args).toContain('bar-baz');
  });
});

// ─── SPEC 23 — Timeout 30s → run_links.status=failed, broadcast timeout ──────
describe('SPEC 23 — Timeout (ADA_RUN_TIMEOUT=200ms) → status=failed + broadcast', () => {
  it('sets status=failed after timeout when no run.started IPC event arrives', async () => {
    insertWorkspace();

    const res = await postRun({ pipeline: 'slow-pipeline', workspaceId: WS_ID });
    expect(res.status).toBe(202);

    const runId = res.body.runId;

    // Wait longer than ADA_RUN_TIMEOUT (200ms) to let the timeout fire
    await new Promise((resolve) => setTimeout(resolve, 400));

    const row = sqlite.prepare('SELECT status FROM run_links WHERE run_id = ?').get(runId);
    expect(row.status).toBe('failed');
  });
});
