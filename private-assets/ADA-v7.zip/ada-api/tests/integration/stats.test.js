/**
 * TDD — Integration tests for GET /api/stats/observe
 *
 * Strategy : env vars AVANT tout import (singleton DB_PATH).
 * Les migrations SQL sont appliquées sur le DB in-memory.
 */

// ─── Env override (must be first) ────────────────────────────────────────────
process.env.DB_PATH = ':memory:';
process.env.ADA_JWT_SECRET = 'test-secret-stats-service-32chars-ok!';
process.env.ADA_AUTH_MODE = 'local';
process.env.NODE_ENV = 'test';

import { describe, it, expect, beforeAll, afterAll, beforeEach } from 'vitest';
import supertest from 'supertest';
import { readFileSync } from 'fs';
import { v4 as uuidv4 } from 'uuid';

const { createApp } = await import('../../src/app.js');
const { sqlite } = await import('../../src/db/client.js');

// ─── Apply migrations ─────────────────────────────────────────────────────────
function applyMigrations() {
  const base = new URL('../../src/db/migrations/', import.meta.url).pathname;
  sqlite.exec(readFileSync(`${base}0000_init.sql`, 'utf-8'));
  sqlite.exec(readFileSync(`${base}0001_relax_run_links.sql`, 'utf-8'));
}

// ─── Globals ──────────────────────────────────────────────────────────────────
let app;
let request;
let token;

beforeAll(async () => {
  applyMigrations();
  app = await createApp({ logger: false });
  await app.ready();
  request = supertest(app.server);

  // Récupérer un token valide
  const res = await request.post('/api/auth/token').send({});
  token = res.body.token;
});

afterAll(async () => {
  if (app) await app.close();
});

beforeEach(() => {
  // Nettoyer les données métier entre les tests (sessions préservées → token reste valide)
  sqlite.exec('DELETE FROM ipc_events');
  sqlite.exec('DELETE FROM run_links');
});

// ─── Helpers ──────────────────────────────────────────────────────────────────
function authHeader() {
  return { Authorization: `Bearer ${token}` };
}

function insertRun({ runId = uuidv4(), pipeline = 'fullstack', status = 'completed', totalCost = 0.5, startedAt, completedAt } = {}) {
  const now = new Date().toISOString();
  sqlite.prepare(
    `INSERT INTO run_links (run_id, pipeline, status, total_cost, started_at, completed_at)
     VALUES (?, ?, ?, ?, ?, ?)`
  ).run(runId, pipeline, status, totalCost, startedAt ?? now, completedAt ?? now);
  return runId;
}

function insertIpcEvent({ type = 'run.phase.completed', agent = 'nestjs', cost = 0.01, durationMs = 500, createdAt } = {}) {
  const id = uuidv4();
  const now = new Date().toISOString();
  const payload = JSON.stringify({
    id,
    ts: Date.now(),
    type,
    payload: { agent, cost, durationMs },
  });
  sqlite.prepare(
    `INSERT INTO ipc_events (id, type, payload, created_at) VALUES (?, ?, ?, ?)`
  ).run(id, type, payload, createdAt ?? now);
  return id;
}

// ─── Tests ────────────────────────────────────────────────────────────────────

describe('GET /api/stats/observe — structure de réponse (DB vide)', () => {
  it('retourne tous les champs ObserveData avec totalRuns=0', async () => {
    const res = await request
      .get('/api/stats/observe?window=7d')
      .set(authHeader());

    expect(res.status).toBe(200);
    const body = res.body;
    expect(body).toHaveProperty('summary');
    expect(body).toHaveProperty('agentStats');
    expect(body).toHaveProperty('costTimeline');
    expect(body).toHaveProperty('runs');
    expect(body).toHaveProperty('activeAlerts');

    expect(body.summary.totalRuns).toBe(0);
    expect(body.summary.successRate).toBe(0);
    expect(body.summary.totalCostUsd).toBe(0);
    expect(body.summary.avgCostPerRun).toBe(0);
    expect(body.summary.topAgent).toBe('');
    expect(body.summary.worstAgent).toBe('');

    expect(Array.isArray(body.agentStats)).toBe(true);
    expect(Array.isArray(body.costTimeline)).toBe(true);
    expect(Array.isArray(body.runs)).toBe(true);
    expect(Array.isArray(body.activeAlerts)).toBe(true);
  });
});

describe('GET /api/stats/observe — validation paramètre window', () => {
  it('rejette window=invalid avec 400', async () => {
    const res = await request
      .get('/api/stats/observe?window=invalid')
      .set(authHeader());

    expect(res.status).toBe(400);
    expect(res.body).toHaveProperty('error');
  });

  it('accepte window=7d', async () => {
    const res = await request.get('/api/stats/observe?window=7d').set(authHeader());
    expect(res.status).toBe(200);
  });

  it('accepte window=30d', async () => {
    const res = await request.get('/api/stats/observe?window=30d').set(authHeader());
    expect(res.status).toBe(200);
  });

  it('accepte window=session', async () => {
    const res = await request.get('/api/stats/observe?window=session').set(authHeader());
    expect(res.status).toBe(200);
  });

  it('utilise 7d par défaut si window absent', async () => {
    const res = await request.get('/api/stats/observe').set(authHeader());
    expect(res.status).toBe(200);
  });
});

describe('GET /api/stats/observe — exige un token', () => {
  it('retourne 401 sans Authorization header', async () => {
    const res = await request.get('/api/stats/observe');
    expect(res.status).toBe(401);
  });

  it('retourne 401 avec token invalide', async () => {
    const res = await request
      .get('/api/stats/observe')
      .set({ Authorization: 'Bearer invalid-token-here' });
    expect(res.status).toBe(401);
  });
});

describe('GET /api/stats/observe — calcul summary avec données réelles', () => {
  it('totalRuns=2, successRate=0.5 (1 completed, 1 failed)', async () => {
    insertRun({ pipeline: 'fullstack', status: 'completed', totalCost: 1.0 });
    insertRun({ pipeline: 'backend', status: 'failed', totalCost: 0.5 });

    const res = await request.get('/api/stats/observe?window=7d').set(authHeader());
    expect(res.status).toBe(200);

    const { summary } = res.body;
    expect(summary.totalRuns).toBe(2);
    expect(summary.successRate).toBe(0.5);
    expect(summary.totalCostUsd).toBeCloseTo(1.5, 5);
    expect(summary.avgCostPerRun).toBeCloseTo(0.75, 5);
  });

  it('successRate=1 si tous les runs sont completed', async () => {
    insertRun({ status: 'completed', totalCost: 0.2 });
    insertRun({ status: 'completed', totalCost: 0.3 });

    const res = await request.get('/api/stats/observe?window=7d').set(authHeader());
    expect(res.body.summary.successRate).toBe(1);
    expect(res.body.summary.totalRuns).toBe(2);
  });
});

describe('GET /api/stats/observe — agentStats depuis ipc_events', () => {
  it('agrège correctement les stats agent depuis les events', async () => {
    insertIpcEvent({ type: 'run.phase.completed', agent: 'nestjs', cost: 0.1, durationMs: 400 });
    insertIpcEvent({ type: 'run.phase.completed', agent: 'nestjs', cost: 0.2, durationMs: 600 });
    insertIpcEvent({ type: 'run.phase.failed', agent: 'nestjs', cost: 0.05, durationMs: 100 });

    const res = await request.get('/api/stats/observe?window=7d').set(authHeader());
    expect(res.status).toBe(200);

    const nestjsStat = res.body.agentStats.find(s => s.agent === 'nestjs');
    expect(nestjsStat).toBeDefined();
    expect(nestjsStat.totalRuns).toBe(3);
    // 2 succès sur 3
    expect(nestjsStat.winRate).toBeCloseTo(2 / 3, 5);
    expect(nestjsStat.alpha).toBe(3);  // successes+1
    expect(nestjsStat.beta).toBe(2);   // failures+1
    expect(nestjsStat.avgCostUsd).toBeCloseTo((0.1 + 0.2 + 0.05) / 3, 5);
    expect(nestjsStat.avgDurationMs).toBeCloseTo((400 + 600 + 100) / 3, 5);
  });

  it('topAgent = agent avec winRate le plus élevé', async () => {
    insertIpcEvent({ type: 'run.phase.completed', agent: 'nestjs' });
    insertIpcEvent({ type: 'run.phase.completed', agent: 'nestjs' });
    insertIpcEvent({ type: 'run.phase.failed', agent: 'drf' });

    const res = await request.get('/api/stats/observe?window=7d').set(authHeader());
    expect(res.body.summary.topAgent).toBe('nestjs');
  });
});

describe('GET /api/stats/observe — costTimeline', () => {
  it('inclut une entrée par jour de la fenêtre', async () => {
    const res = await request.get('/api/stats/observe?window=7d').set(authHeader());
    expect(res.status).toBe(200);

    const { costTimeline } = res.body;
    // La fenêtre 7d doit avoir au moins 1 entrée (aujourd'hui)
    expect(costTimeline.length).toBeGreaterThanOrEqual(1);
    // Chaque entrée a les bons champs
    for (const entry of costTimeline) {
      expect(entry).toHaveProperty('date');
      expect(entry).toHaveProperty('totalUsd');
      expect(entry).toHaveProperty('byAgent');
      expect(typeof entry.date).toBe('string');
      expect(entry.date).toMatch(/^\d{4}-\d{2}-\d{2}$/);
    }
  });

  it('additionne les coûts dans la timeline depuis les runs', async () => {
    const today = new Date().toISOString();
    insertRun({ totalCost: 0.8, startedAt: today, completedAt: today });
    insertRun({ totalCost: 0.2, startedAt: today, completedAt: today });

    const res = await request.get('/api/stats/observe?window=7d').set(authHeader());
    const todayStr = today.slice(0, 10);
    const entry = res.body.costTimeline.find(e => e.date === todayStr);
    expect(entry).toBeDefined();
    expect(entry.totalUsd).toBeCloseTo(1.0, 5);
  });
});

describe('GET /api/stats/observe — runs list', () => {
  it('retourne les runs avec les bons champs', async () => {
    insertRun({ pipeline: 'fullstack', status: 'completed', totalCost: 0.42 });

    const res = await request.get('/api/stats/observe?window=7d').set(authHeader());
    expect(res.status).toBe(200);
    expect(res.body.runs).toHaveLength(1);

    const run = res.body.runs[0];
    expect(run).toHaveProperty('id');
    expect(run).toHaveProperty('pipeline', 'fullstack');
    expect(run).toHaveProperty('status', 'done');
    expect(run).toHaveProperty('startedAt');
    expect(run).toHaveProperty('durationMs');
    expect(run).toHaveProperty('totalCostUsd', 0.42);
    expect(run).toHaveProperty('phases');
    expect(Array.isArray(run.phases)).toBe(true);
  });

  it('mappe les status correctement', async () => {
    insertRun({ status: 'completed' });
    insertRun({ status: 'failed' });
    insertRun({ status: 'cancelled' });
    insertRun({ status: 'completed_with_errors' });
    insertRun({ status: 'running' });

    const res = await request.get('/api/stats/observe?window=7d').set(authHeader());
    const statuses = res.body.runs.map(r => r.status).sort();
    expect(statuses).toContain('done');
    expect(statuses).toContain('failed');
    expect(statuses).toContain('partial');
    expect(statuses).toContain('running');
  });
});

describe('GET /api/stats/observe — activeAlerts', () => {
  it('déclenche high_failure_rate si taux > 30% et >= 3 runs', async () => {
    // 1 success, 3 failed → taux 75%
    insertRun({ status: 'completed' });
    insertRun({ status: 'failed' });
    insertRun({ status: 'failed' });
    insertRun({ status: 'failed' });

    const res = await request.get('/api/stats/observe?window=7d').set(authHeader());
    const alert = res.body.activeAlerts.find(a => a.type === 'high_failure_rate');
    expect(alert).toBeDefined();
    expect(['warning', 'error']).toContain(alert.severity);
  });

  it("ne déclenche pas d'alerte si moins de 3 runs", async () => {
    insertRun({ status: 'failed' });
    insertRun({ status: 'failed' });

    const res = await request.get('/api/stats/observe?window=7d').set(authHeader());
    const alert = res.body.activeAlerts.find(a => a.type === 'high_failure_rate');
    expect(alert).toBeUndefined();
  });
});
