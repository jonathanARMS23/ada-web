/**
 * TDD — Sprint 3 — WebSocket Gateway
 * Integration tests for WS /ws route.
 *
 * Strategy: spawn a real Fastify server on port 0 (random), use `ws` npm client.
 * env vars set BEFORE any module import.
 */
import { describe, it, expect, beforeAll, afterAll, beforeEach, afterEach } from 'vitest';
import supertest from 'supertest';
import { readFileSync } from 'fs';
import { WebSocket } from 'ws';
import { v4 as uuidv4 } from 'uuid';

// ─── env BEFORE any local import ─────────────────────────────────────────────
process.env.DB_PATH = ':memory:';
process.env.ADA_JWT_SECRET = 'test-secret-websocket-32chars-min!!';
process.env.ADA_AUTH_MODE = 'local';
process.env.ADA_WS_HEARTBEAT_INTERVAL = '5000';
process.env.ADA_RUN_TIMEOUT = '30000';

// ─── Now import app + db ──────────────────────────────────────────────────────
const { createApp } = await import('../../src/app.js');
const { sqlite } = await import('../../src/db/client.js');
const { signToken, hashToken } = await import('../../src/auth/jwt.js');
const { env } = await import('../../src/config/env.js');

// ─── DDL helper ───────────────────────────────────────────────────────────────
function applyMigrations(db) {
  const sqlPath = new URL('../../src/db/migrations/0000_init.sql', import.meta.url).pathname;
  const ddl = readFileSync(sqlPath, 'utf-8');
  db.exec(ddl);
}

// ─── State ────────────────────────────────────────────────────────────────────
let app;
let port;

// ─── Test helpers ─────────────────────────────────────────────────────────────

/** Create a valid JWT, insert it into sessions, and return a one-time WS ticket */
async function createValidToken() {
  const { token, expiresAt } = await signToken({}, env.ADA_JWT_SECRET, 3600);
  const hash = hashToken(token);
  sqlite
    .prepare('INSERT INTO sessions (id, token_hash, expires_at) VALUES (?, ?, ?)')
    .run(uuidv4(), hash, expiresAt);
  return token;
}

/**
 * Fetch a one-time WS ticket via the HTTP API.
 * Returns the ticketId to pass as ?ticket=<id>.
 */
async function createTicket(token) {
  const res = await supertest(app.server)
    .get('/api/ws/ticket')
    .set('Authorization', `Bearer ${token}`);
  if (res.status !== 200) throw new Error(`createTicket failed: ${res.status} ${JSON.stringify(res.body)}`);
  return res.body.ticket;
}

/**
 * Open a WebSocket connection using a one-time ticket.
 * Messages are buffered immediately from 'open' so none are lost.
 * Resolves with an enhanced ws object that has a `nextMessage()` method.
 */
async function connectWs(token) {
  const ticketId = token ? await createTicket(token) : null;
  const url = ticketId
    ? `ws://127.0.0.1:${port}/ws?ticket=${ticketId}`
    : `ws://127.0.0.1:${port}/ws`;
  const ws = new WebSocket(url);

  // ─── Message buffer + waiters queue ───────────────────────────────────────
  const _buffer = [];
  const _waiters = [];

  ws.on('message', (raw) => {
    const msg = JSON.parse(raw.toString());
    if (_waiters.length > 0) {
      const resolve = _waiters.shift();
      resolve(msg);
    } else {
      _buffer.push(msg);
    }
  });

  /** Returns a Promise for the next message (buffered or future). */
  ws.nextMessage = (timeout = 2000) => {
    if (_buffer.length > 0) {
      return Promise.resolve(_buffer.shift());
    }
    return new Promise((resolve, reject) => {
      const timer = setTimeout(
        () => {
          const idx = _waiters.indexOf(resolve);
          if (idx !== -1) _waiters.splice(idx, 1);
          reject(new Error('WS message timeout'));
        },
        timeout
      );
      _waiters.push((msg) => {
        clearTimeout(timer);
        resolve(msg);
      });
    });
  };

  return new Promise((resolve, reject) => {
    ws.on('open', () => resolve(ws));
    ws.on('error', reject);
    ws.on('unexpected-response', (_, res) =>
      reject(new Error(`HTTP ${res.statusCode}`))
    );
  });
}

/** Wait for the next message on a socket */
function waitForMessage(ws, timeout = 2000) {
  // Use buffered nextMessage if available, else fallback
  if (typeof ws.nextMessage === 'function') {
    return ws.nextMessage(timeout);
  }
  return new Promise((resolve, reject) => {
    const timer = setTimeout(
      () => reject(new Error('WS message timeout')),
      timeout
    );
    ws.once('message', (data) => {
      clearTimeout(timer);
      resolve(JSON.parse(data.toString()));
    });
  });
}

/** Wait for socket close */
function waitForClose(ws, timeout = 2000) {
  return new Promise((resolve) => {
    const timer = setTimeout(() => resolve({ code: -1, reason: '' }), timeout);
    ws.once('close', (code, reason) => {
      clearTimeout(timer);
      resolve({ code, reason: reason.toString() });
    });
  });
}

/** Send a JSON message and wait for the next buffered response */
function sendAndWait(ws, msg, timeout = 2000) {
  ws.send(JSON.stringify(msg));
  return waitForMessage(ws, timeout);
}

/** Drain the first message (the 'connected' ack) */
async function drainConnected(ws) {
  return waitForMessage(ws, 2000);
}

/** Close ws if still open */
function safeClose(ws) {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.close();
  }
}

// ─── Lifecycle ────────────────────────────────────────────────────────────────

beforeAll(async () => {
  applyMigrations(sqlite);
  app = await createApp({ logger: false });
  await app.listen({ port: 0, host: '127.0.0.1' });
  port = app.server.address().port;
});

afterAll(async () => {
  if (app) await app.close();
});

beforeEach(() => {
  sqlite.exec('DELETE FROM sessions');
  sqlite.exec('DELETE FROM run_links');
  sqlite.exec('DELETE FROM conversations');
  sqlite.exec('DELETE FROM workspaces');
});

// ─── SPEC 01 — valid token → 101 + { type: "connected" } ─────────────────────
describe('SPEC 01 — valid token → connected', () => {
  it('receives { type: "connected", workspaceId: null } after connect', async () => {
    const token = await createValidToken();
    const ws = await connectWs(token);
    const msg = await waitForMessage(ws);
    expect(msg.type).toBe('connected');
    expect(msg.workspaceId).toBeNull();
    expect(msg).toHaveProperty('ts');
    safeClose(ws);
  });
});

// ─── SPEC 02 — no token → close 4001 UNAUTHORIZED ────────────────────────────
describe('SPEC 02 — no token → 4001 UNAUTHORIZED', () => {
  it('socket closes with code 4001 and reason UNAUTHORIZED', async () => {
    const ws = new WebSocket(`ws://127.0.0.1:${port}/ws`);
    const result = await waitForClose(ws, 2000);
    expect(result.code).toBe(4001);
    expect(result.reason).toContain('UNAUTHORIZED');
  });
});

// ─── SPEC 03 — missing/unknown ticket → 4001 INVALID_TICKET ─────────────────
describe('SPEC 03 — invalid ticket → 4001 INVALID_TICKET', () => {
  it('socket closes with code 4001 and reason INVALID_TICKET', async () => {
    const ws = new WebSocket(`ws://127.0.0.1:${port}/ws?ticket=not-a-valid-ticket-id`);
    const result = await waitForClose(ws, 2000);
    expect(result.code).toBe(4001);
    expect(result.reason).toContain('INVALID_TICKET');
  });
});

// ─── SPEC 04 — unknown ticket (simulates expired) → 4001 INVALID_TICKET ──────
describe('SPEC 04 — expired ticket → 4001 INVALID_TICKET', () => {
  it('socket closes with code 4001 and reason INVALID_TICKET', async () => {
    // A UUID that was never registered acts the same as an expired ticket
    const unknownTicket = uuidv4();
    const ws = new WebSocket(`ws://127.0.0.1:${port}/ws?ticket=${unknownTicket}`);
    const result = await waitForClose(ws, 2000);
    expect(result.code).toBe(4001);
    expect(result.reason).toContain('INVALID_TICKET');
  });
});

// ─── SPEC 05 — ticket with revoked session → 4001 TOKEN_REVOKED ──────────────
describe('SPEC 05 — revoked token → 4001 TOKEN_REVOKED', () => {
  it('socket closes with code 4001 and reason TOKEN_REVOKED', async () => {
    // Create a valid token + ticket, then revoke the session
    const token = await createValidToken();
    const ticketId = await createTicket(token);
    // Remove the session so the gateway sees TOKEN_REVOKED
    sqlite.exec('DELETE FROM sessions');
    const ws = new WebSocket(`ws://127.0.0.1:${port}/ws?ticket=${ticketId}`);
    const result = await waitForClose(ws, 2000);
    expect(result.code).toBe(4001);
    expect(result.reason).toContain('TOKEN_REVOKED');
  });
});

// ─── SPEC 06 — 2 simultaneous connections, same token → both accepted ─────────
describe('SPEC 06 — two connections with same token', () => {
  it('both connections receive connected message', async () => {
    const token = await createValidToken();
    const [ws1, ws2] = await Promise.all([connectWs(token), connectWs(token)]);
    const [m1, m2] = await Promise.all([
      waitForMessage(ws1),
      waitForMessage(ws2),
    ]);
    expect(m1.type).toBe('connected');
    expect(m2.type).toBe('connected');
    safeClose(ws1);
    safeClose(ws2);
  });
});

// ─── SPEC 07 — workspace.join existing workspace ─────────────────────────────
describe('SPEC 07 — workspace.join existing workspace', () => {
  it('responds with { type: "workspace.joined", workspaceId }', async () => {
    const wid = uuidv4();
    sqlite
      .prepare(
        `INSERT INTO workspaces (id, name, slug, profile) VALUES (?, ?, ?, ?)`
      )
      .run(wid, 'Test WS', 'test-ws-07', 'frontend');

    const token = await createValidToken();
    const ws = await connectWs(token);
    await drainConnected(ws);

    const reply = await sendAndWait(ws, {
      type: 'workspace.join',
      payload: { workspaceId: wid },
    });
    expect(reply.type).toBe('workspace.joined');
    expect(reply.workspaceId).toBe(wid);
    safeClose(ws);
  });
});

// ─── SPEC 08 — workspace.join non-existent → WORKSPACE_NOT_FOUND ─────────────
describe('SPEC 08 — workspace.join non-existent', () => {
  it('responds with { type: "error", code: "WORKSPACE_NOT_FOUND" }', async () => {
    const token = await createValidToken();
    const ws = await connectWs(token);
    await drainConnected(ws);

    const reply = await sendAndWait(ws, {
      type: 'workspace.join',
      payload: { workspaceId: 'does-not-exist' },
    });
    expect(reply.type).toBe('error');
    expect(reply.code).toBe('WORKSPACE_NOT_FOUND');
    safeClose(ws);
  });
});

// ─── SPEC 09 — change room → leave old, join new ─────────────────────────────
describe('SPEC 09 — change room', () => {
  it('joining a second workspace leaves the first', async () => {
    const wid1 = uuidv4();
    const wid2 = uuidv4();
    sqlite
      .prepare(`INSERT INTO workspaces (id, name, slug, profile) VALUES (?, ?, ?, ?)`)
      .run(wid1, 'WS1', 'ws-09a', 'frontend');
    sqlite
      .prepare(`INSERT INTO workspaces (id, name, slug, profile) VALUES (?, ?, ?, ?)`)
      .run(wid2, 'WS2', 'ws-09b', 'frontend');

    const token = await createValidToken();
    const ws = await connectWs(token);
    await drainConnected(ws);

    // Join first workspace
    await sendAndWait(ws, { type: 'workspace.join', payload: { workspaceId: wid1 } });

    // Join second workspace
    const reply = await sendAndWait(ws, { type: 'workspace.join', payload: { workspaceId: wid2 } });
    expect(reply.type).toBe('workspace.joined');
    expect(reply.workspaceId).toBe(wid2);

    // Room 1 should be empty → activeRooms reflects only room2
    expect(app.wsRooms.size(wid1)).toBe(0);
    expect(app.wsRooms.size(wid2)).toBe(1);
    safeClose(ws);
  });
});

// ─── SPEC 10 — workspace.leave ────────────────────────────────────────────────
describe('SPEC 10 — workspace.leave', () => {
  it('responds with { type: "workspace.left" }', async () => {
    const wid = uuidv4();
    sqlite
      .prepare(`INSERT INTO workspaces (id, name, slug, profile) VALUES (?, ?, ?, ?)`)
      .run(wid, 'WS Leave', 'ws-10-leave', 'frontend');

    const token = await createValidToken();
    const ws = await connectWs(token);
    await drainConnected(ws);

    await sendAndWait(ws, { type: 'workspace.join', payload: { workspaceId: wid } });

    const reply = await sendAndWait(ws, { type: 'workspace.leave' });
    expect(reply.type).toBe('workspace.left');
    safeClose(ws);
  });
});

// ─── SPEC 11 — broadcast limited to room (client B different room) ────────────
describe('SPEC 11 — broadcast limited to room', () => {
  it('client B in different room does not receive broadcast to room A', async () => {
    const wid1 = uuidv4();
    const wid2 = uuidv4();
    sqlite
      .prepare(`INSERT INTO workspaces (id, name, slug, profile) VALUES (?, ?, ?, ?)`)
      .run(wid1, 'Room A', 'ws-11a', 'frontend');
    sqlite
      .prepare(`INSERT INTO workspaces (id, name, slug, profile) VALUES (?, ?, ?, ?)`)
      .run(wid2, 'Room B', 'ws-11b', 'frontend');

    const tokenA = await createValidToken();
    const tokenB = await createValidToken();
    const wsA = await connectWs(tokenA);
    const wsB = await connectWs(tokenB);
    await drainConnected(wsA);
    await drainConnected(wsB);

    // A joins room 1, B joins room 2
    await sendAndWait(wsA, { type: 'workspace.join', payload: { workspaceId: wid1 } });
    await sendAndWait(wsB, { type: 'workspace.join', payload: { workspaceId: wid2 } });

    // Broadcast to room 1 only
    const testPayload = { type: 'test.event', data: 'hello-room1' };

    // Collect messages from B for a short time
    const messagesB = [];
    const listener = (raw) => messagesB.push(JSON.parse(raw.toString()));
    wsB.on('message', listener);

    app.wsRooms.broadcast(wid1, testPayload);

    await new Promise((r) => setTimeout(r, 300));
    wsB.off('message', listener);

    expect(messagesB.some((m) => m.type === 'test.event')).toBe(false);
    safeClose(wsA);
    safeClose(wsB);
  });
});

// ─── SPEC 12 — broadcast to all clients in same room ─────────────────────────
describe('SPEC 12 — broadcast to all clients in same room', () => {
  it('A, B, C all receive broadcast in same workspace room', async () => {
    const wid = uuidv4();
    sqlite
      .prepare(`INSERT INTO workspaces (id, name, slug, profile) VALUES (?, ?, ?, ?)`)
      .run(wid, 'Room ABC', 'ws-12-abc', 'frontend');

    const [tA, tB, tC] = await Promise.all([
      createValidToken(),
      createValidToken(),
      createValidToken(),
    ]);
    const [wsA, wsB, wsC] = await Promise.all([
      connectWs(tA),
      connectWs(tB),
      connectWs(tC),
    ]);
    await Promise.all([drainConnected(wsA), drainConnected(wsB), drainConnected(wsC)]);

    await sendAndWait(wsA, { type: 'workspace.join', payload: { workspaceId: wid } });
    await sendAndWait(wsB, { type: 'workspace.join', payload: { workspaceId: wid } });
    await sendAndWait(wsC, { type: 'workspace.join', payload: { workspaceId: wid } });

    const received = { A: false, B: false, C: false };
    const p = Promise.all([
      new Promise((r) => wsA.once('message', (d) => { received.A = JSON.parse(d.toString()).type === 'test.broadcast'; r(); })),
      new Promise((r) => wsB.once('message', (d) => { received.B = JSON.parse(d.toString()).type === 'test.broadcast'; r(); })),
      new Promise((r) => wsC.once('message', (d) => { received.C = JSON.parse(d.toString()).type === 'test.broadcast'; r(); })),
    ]);

    app.wsRooms.broadcast(wid, { type: 'test.broadcast' });
    await p;

    expect(received.A).toBe(true);
    expect(received.B).toBe(true);
    expect(received.C).toBe(true);
    safeClose(wsA);
    safeClose(wsB);
    safeClose(wsC);
  });
});

// ─── SPEC 15 — heartbeat received after interval ─────────────────────────────
describe('SPEC 15 — heartbeat after interval', () => {
  it('receives { type: "heartbeat" } within 6000ms (interval=5000ms)', async () => {
    const token = await createValidToken();
    const ws = await connectWs(token);
    await drainConnected(ws); // consume connected msg

    // Collect messages for 6000ms (interval is 5000ms, floored by Math.max)
    const messages = [];
    const listener = (raw) => messages.push(JSON.parse(raw.toString()));
    ws.on('message', listener);

    await new Promise((r) => setTimeout(r, 6000));
    ws.off('message', listener);

    expect(messages.some((m) => m.type === 'heartbeat')).toBe(true);
    safeClose(ws);
  }, 10000);
});

// ─── SPEC 16 — heartbeat stops on disconnect (no error) ──────────────────────
describe('SPEC 16 — heartbeat stopped on disconnect', () => {
  it('server does not throw after client disconnects', async () => {
    const token = await createValidToken();
    const ws = await connectWs(token);
    await drainConnected(ws);

    ws.close();
    // Wait a couple heartbeat cycles — no error expected
    await new Promise((r) => setTimeout(r, 500));
    // If server had thrown, the process would have crashed or app.close would fail
    expect(true).toBe(true);
  }, 5000);
});

// ─── SPEC 17 — disconnect A → B stays, broadcast reaches B ───────────────────
describe('SPEC 17 — disconnect A, B remains', () => {
  it('after A disconnects, broadcast still reaches B', async () => {
    const wid = uuidv4();
    sqlite
      .prepare(`INSERT INTO workspaces (id, name, slug, profile) VALUES (?, ?, ?, ?)`)
      .run(wid, 'Room AB', 'ws-17-ab', 'frontend');

    const [tA, tB] = await Promise.all([createValidToken(), createValidToken()]);
    const [wsA, wsB] = await Promise.all([connectWs(tA), connectWs(tB)]);
    await Promise.all([drainConnected(wsA), drainConnected(wsB)]);

    await sendAndWait(wsA, { type: 'workspace.join', payload: { workspaceId: wid } });
    await sendAndWait(wsB, { type: 'workspace.join', payload: { workspaceId: wid } });

    // Disconnect A
    safeClose(wsA);
    await new Promise((r) => setTimeout(r, 100));

    // Broadcast to room — B should receive it
    const p = waitForMessage(wsB, 2000);
    app.wsRooms.broadcast(wid, { type: 'test.after.disconnect' });
    const msg = await p;

    expect(msg.type).toBe('test.after.disconnect');
    safeClose(wsB);
  });
});

// ─── SPEC 18 — socket.destroy() does not crash server ────────────────────────
describe('SPEC 18 — socket.destroy() does not crash server', () => {
  it('server stays alive after abrupt client disconnect', async () => {
    const token = await createValidToken();
    const ws = await connectWs(token);
    await drainConnected(ws);

    // Abruptly terminate the underlying TCP socket
    ws.terminate();
    await new Promise((r) => setTimeout(r, 200));

    // Server should still be reachable
    const res = await supertest(app.server).get('/api/health');
    expect(res.status).toBe(200);
  });
});

// ─── SPEC 19 — last disconnect → room removed from Map ───────────────────────
describe('SPEC 19 — last disconnect removes room', () => {
  it('activeRooms returns 0 after last client leaves room', async () => {
    const wid = uuidv4();
    sqlite
      .prepare(`INSERT INTO workspaces (id, name, slug, profile) VALUES (?, ?, ?, ?)`)
      .run(wid, 'Temp Room', 'ws-19-temp', 'frontend');

    const token = await createValidToken();
    const ws = await connectWs(token);
    await drainConnected(ws);

    await sendAndWait(ws, { type: 'workspace.join', payload: { workspaceId: wid } });
    expect(app.wsRooms.size(wid)).toBe(1);

    const closePromise = new Promise((r) => ws.once('close', r));
    ws.close();
    await closePromise;
    await new Promise((r) => setTimeout(r, 100));

    expect(app.wsRooms.activeRooms).toBe(0);
  });
});

// ─── SPEC 21 — run.spawn without room → NO_WORKSPACE ─────────────────────────
describe('SPEC 21 — run.spawn without workspace', () => {
  it('responds with { type: "error", code: "NO_WORKSPACE" }', async () => {
    const token = await createValidToken();
    const ws = await connectWs(token);
    await drainConnected(ws);

    const reply = await sendAndWait(ws, {
      type: 'run.spawn',
      payload: { pipeline: 'fullstack' },
    });
    expect(reply.type).toBe('error');
    expect(reply.code).toBe('NO_WORKSPACE');
    safeClose(ws);
  });
});

// ─── SPEC 22 — unknown message type ──────────────────────────────────────────
describe('SPEC 22 — unknown message type', () => {
  it('responds with { type: "error", code: "UNKNOWN_MESSAGE_TYPE" }', async () => {
    const token = await createValidToken();
    const ws = await connectWs(token);
    await drainConnected(ws);

    const reply = await sendAndWait(ws, { type: 'something.weird' });
    expect(reply.type).toBe('error');
    expect(reply.code).toBe('UNKNOWN_MESSAGE_TYPE');
    safeClose(ws);
  });
});

// ─── SPEC 23 — malformed JSON ─────────────────────────────────────────────────
describe('SPEC 23 — malformed JSON', () => {
  it('responds with { type: "error", code: "INVALID_JSON" }', async () => {
    const token = await createValidToken();
    const ws = await connectWs(token);
    await drainConnected(ws);

    const p = waitForMessage(ws, 2000);
    ws.send('this is not { json');
    const reply = await p;

    expect(reply.type).toBe('error');
    expect(reply.code).toBe('INVALID_JSON');
    safeClose(ws);
  });
});

// ─── SPEC 24 — GET /api/health includes ws.activeConnections ─────────────────
describe('SPEC 24 — health includes ws.activeConnections', () => {
  it('returns ws.activeConnections ≥ 1 when a socket is connected', async () => {
    const token = await createValidToken();
    const ws = await connectWs(token);
    await drainConnected(ws);

    const res = await supertest(app.server).get('/api/health');
    expect(res.status).toBe(200);
    expect(res.body.ws).toBeDefined();
    expect(typeof res.body.ws.activeConnections).toBe('number');
    expect(res.body.ws.activeConnections).toBeGreaterThanOrEqual(1);
    safeClose(ws);
  });
});

// ─── SPEC 25 — GET /api/health includes ws.activeRooms ───────────────────────
describe('SPEC 25 — health includes ws.activeRooms', () => {
  it('returns ws.activeRooms = 1 after joining a room', async () => {
    const wid = uuidv4();
    sqlite
      .prepare(`INSERT INTO workspaces (id, name, slug, profile) VALUES (?, ?, ?, ?)`)
      .run(wid, 'Health Room', 'ws-25-health', 'frontend');

    const token = await createValidToken();
    const ws = await connectWs(token);
    await drainConnected(ws);
    await sendAndWait(ws, { type: 'workspace.join', payload: { workspaceId: wid } });

    const res = await supertest(app.server).get('/api/health');
    expect(res.status).toBe(200);
    expect(res.body.ws).toBeDefined();
    expect(typeof res.body.ws.activeRooms).toBe('number');
    expect(res.body.ws.activeRooms).toBeGreaterThanOrEqual(1);
    safeClose(ws);
  });
});
