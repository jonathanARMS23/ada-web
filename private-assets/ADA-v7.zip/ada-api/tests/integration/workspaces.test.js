/**
 * TDD — RED phase then GREEN
 * Integration tests for workspace routes (HTTP + SQLite in-memory)
 * 30 specs covering CRUD + stats + cascade
 */

// ─── Configure env BEFORE any import ─────────────────────────────────────────
process.env.DB_PATH = ':memory:';
process.env.ADA_JWT_SECRET = 'test-secret-workspace-32chars-min!!';
process.env.ADA_AUTH_MODE = 'local';
process.env.NODE_ENV = 'test';

import { describe, it, expect, beforeAll, afterAll, beforeEach } from 'vitest';
import supertest from 'supertest';
import { readFileSync } from 'fs';
import { v4 as uuidv4 } from 'uuid';

// Import AFTER setting env vars
const { createApp } = await import('../../src/app.js');
const { sqlite } = await import('../../src/db/client.js');

// ─── DDL helpers ──────────────────────────────────────────────────────────────
function applySchema(sqliteInstance) {
  const sqlPath = new URL('../../src/db/migrations/0000_init.sql', import.meta.url).pathname;
  const ddl = readFileSync(sqlPath, 'utf-8');
  // Apply the base schema, but replace run_links to use nullable FKs (0001 migration)
  const ddlRelaxed = ddl.replace(
    /CREATE TABLE IF NOT EXISTS `run_links`[\s\S]*?;/m,
    `CREATE TABLE IF NOT EXISTS \`run_links\` (
  \`run_id\`          TEXT PRIMARY KEY NOT NULL,
  \`conversation_id\` TEXT REFERENCES \`conversations\`(\`id\`) ON DELETE SET NULL,
  \`workspace_id\`    TEXT REFERENCES \`workspaces\`(\`id\`) ON DELETE SET NULL,
  \`pipeline\`        TEXT NOT NULL,
  \`status\`          TEXT NOT NULL DEFAULT 'running'
                    CHECK(\`status\` IN ('running','completed','failed','cancelled','completed_with_errors')),
  \`phases\`          TEXT NOT NULL DEFAULT '{}',
  \`total_cost\`      REAL NOT NULL DEFAULT 0,
  \`total_tokens\`    INTEGER NOT NULL DEFAULT 0,
  \`started_at\`      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  \`completed_at\`    TEXT
);`
  );
  sqliteInstance.exec(ddlRelaxed);
}

// ─── Shared state ─────────────────────────────────────────────────────────────
let app;
let request;
let authToken;

beforeAll(async () => {
  applySchema(sqlite);
  app = await createApp({ logger: false });
  await app.ready();
  request = supertest(app.server);

  // Get auth token (local mode — no password required)
  const res = await request.post('/api/auth/token').send({});
  authToken = res.body.token;
});

afterAll(async () => {
  if (app) await app.close();
});

beforeEach(() => {
  // Isolation: clean all business tables between tests
  sqlite.exec('DELETE FROM run_links');
  sqlite.exec('DELETE FROM messages');
  sqlite.exec('DELETE FROM conversations');
  sqlite.exec('DELETE FROM workspace_settings');
  sqlite.exec('DELETE FROM workspaces');
});

// ─── Helper: authenticated request builder ────────────────────────────────────
function auth(req) {
  return req.set('Authorization', `Bearer ${authToken}`);
}

async function createWorkspace(body = {}) {
  const res = await auth(request.post('/api/workspaces')).send({ name: 'Test WS', ...body });
  return res;
}

// ─── SPEC 01 — POST minimal → 201 + slug auto + defaults ─────────────────────
describe('SPEC 01 — POST minimal → 201 + slug auto + defaults', () => {
  it('returns 201 with id, slug, default profile and color', async () => {
    const res = await auth(request.post('/api/workspaces')).send({ name: 'Mon Projet' });
    expect(res.status).toBe(201);
    expect(res.body).toHaveProperty('id');
    expect(res.body.name).toBe('Mon Projet');
    expect(res.body.slug).toBe('mon-projet');
    expect(res.body.profile).toBe('claude-pro');
    expect(res.body.color).toBe('#6366f1');
    expect(res.body).toHaveProperty('createdAt');
    expect(res.body).toHaveProperty('updatedAt');
  });
});

// ─── SPEC 02 — POST avec tous les champs ─────────────────────────────────────
describe('SPEC 02 — POST avec tous les champs', () => {
  it('creates workspace with all optional fields', async () => {
    const res = await auth(request.post('/api/workspaces')).send({
      name: 'Full Workspace',
      profile: 'claude-opus',
      color: '#ff5733',
      description: 'A full workspace',
      projectDir: '/home/user/project',
      pinned: true,
      archived: false,
    });
    expect(res.status).toBe(201);
    expect(res.body.profile).toBe('claude-opus');
    expect(res.body.color).toBe('#ff5733');
    expect(res.body.description).toBe('A full workspace');
    expect(res.body.projectDir).toBe('/home/user/project');
    expect(res.body.pinned).toBe(true);
    expect(res.body.archived).toBe(false);
  });
});

// ─── SPEC 03 — Slug depuis accents/special chars ──────────────────────────────
describe('SPEC 03 — Slug depuis accents/special chars', () => {
  it('"Projet Éolien & Solaire!" → slug "projet-eolien-solaire"', async () => {
    const res = await auth(request.post('/api/workspaces')).send({ name: 'Projet Éolien & Solaire!' });
    expect(res.status).toBe(201);
    expect(res.body.slug).toBe('projet-eolien-solaire');
  });
});

// ─── SPEC 04 — Collision slug → "mon-saas-2" ─────────────────────────────────
describe('SPEC 04 — Collision slug → "mon-saas-2"', () => {
  it('second workspace with same name gets slug-2', async () => {
    await auth(request.post('/api/workspaces')).send({ name: 'Mon SaaS' });
    const res = await auth(request.post('/api/workspaces')).send({ name: 'Mon SaaS' });
    expect(res.status).toBe(201);
    expect(res.body.slug).toBe('mon-saas-2');
  });
});

// ─── SPEC 05 — Plusieurs collisions → "mon-saas-4" ───────────────────────────
describe('SPEC 05 — Plusieurs collisions → "mon-saas-4"', () => {
  it('fourth workspace with same name gets slug-4', async () => {
    await auth(request.post('/api/workspaces')).send({ name: 'Mon SaaS' });
    await auth(request.post('/api/workspaces')).send({ name: 'Mon SaaS' });
    await auth(request.post('/api/workspaces')).send({ name: 'Mon SaaS' });
    const res = await auth(request.post('/api/workspaces')).send({ name: 'Mon SaaS' });
    expect(res.status).toBe(201);
    expect(res.body.slug).toBe('mon-saas-4');
  });
});

// ─── SPEC 06 — name absent → 400 VALIDATION_ERROR ────────────────────────────
describe('SPEC 06 — name absent → 400 VALIDATION_ERROR', () => {
  it('returns 400 with VALIDATION_ERROR when name is missing', async () => {
    const res = await auth(request.post('/api/workspaces')).send({});
    expect(res.status).toBe(400);
    expect(res.body.error).toBe('VALIDATION_ERROR');
  });
});

// ─── SPEC 07 — name > 255 chars → 400 ────────────────────────────────────────
describe('SPEC 07 — name > 255 chars → 400', () => {
  it('returns 400 when name exceeds 255 chars', async () => {
    const longName = 'A'.repeat(256);
    const res = await auth(request.post('/api/workspaces')).send({ name: longName });
    expect(res.status).toBe(400);
    expect(res.body.error).toBe('VALIDATION_ERROR');
  });
});

// ─── SPEC 08 — color invalide → 400 ─────────────────────────────────────────
describe('SPEC 08 — color invalide → 400', () => {
  it('returns 400 for invalid hex color', async () => {
    const res = await auth(request.post('/api/workspaces')).send({ name: 'WS', color: 'red' });
    expect(res.status).toBe(400);
    expect(res.body.error).toBe('VALIDATION_ERROR');
  });

  it('returns 400 for short hex color', async () => {
    const res = await auth(request.post('/api/workspaces')).send({ name: 'WS', color: '#fff' });
    expect(res.status).toBe(400);
    expect(res.body.error).toBe('VALIDATION_ERROR');
  });
});

// ─── SPEC 09 — GET vide → { items: [], total: 0 } ────────────────────────────
describe('SPEC 09 — GET vide → { items: [], total: 0 }', () => {
  it('returns empty list when no workspaces exist', async () => {
    const res = await auth(request.get('/api/workspaces'));
    expect(res.status).toBe(200);
    expect(res.body.items).toEqual([]);
    expect(res.body.total).toBe(0);
  });
});

// ─── SPEC 10 — GET ordre updatedAt DESC ──────────────────────────────────────
describe('SPEC 10 — GET ordre updatedAt DESC', () => {
  it('returns workspaces ordered by updatedAt DESC', async () => {
    const r1 = await auth(request.post('/api/workspaces')).send({ name: 'Alpha' });
    // Patch r1 to bump updatedAt
    await auth(request.patch(`/api/workspaces/${r1.body.id}`)).send({ description: 'updated' });
    const r2 = await auth(request.post('/api/workspaces')).send({ name: 'Beta' });

    const res = await auth(request.get('/api/workspaces'));
    expect(res.status).toBe(200);
    expect(res.body.items.length).toBe(2);
    // Beta was created after r1 was patched, so Beta should be first
    expect(res.body.items[0].name).toBe('Beta');
  });
});

// ─── SPEC 11 — GET filtre archived=false par défaut ──────────────────────────
describe('SPEC 11 — GET filtre archived=false par défaut', () => {
  it('excludes archived workspaces by default', async () => {
    await auth(request.post('/api/workspaces')).send({ name: 'Active WS' });
    const r2 = await auth(request.post('/api/workspaces')).send({ name: 'Archived WS' });
    await auth(request.patch(`/api/workspaces/${r2.body.id}`)).send({ archived: true });

    const res = await auth(request.get('/api/workspaces'));
    expect(res.status).toBe(200);
    expect(res.body.items).toHaveLength(1);
    expect(res.body.items[0].name).toBe('Active WS');
    expect(res.body.total).toBe(1);
  });
});

// ─── SPEC 12 — GET ?archived=true inclut tous ────────────────────────────────
describe('SPEC 12 — GET ?archived=true inclut tous', () => {
  it('includes archived workspaces when archived=true', async () => {
    await auth(request.post('/api/workspaces')).send({ name: 'Active WS' });
    const r2 = await auth(request.post('/api/workspaces')).send({ name: 'Archived WS' });
    await auth(request.patch(`/api/workspaces/${r2.body.id}`)).send({ archived: true });

    const res = await auth(request.get('/api/workspaces?archived=true'));
    expect(res.status).toBe(200);
    expect(res.body.items).toHaveLength(2);
    expect(res.body.total).toBe(2);
  });
});

// ─── SPEC 13 — GET ?pinned=true ──────────────────────────────────────────────
describe('SPEC 13 — GET ?pinned=true', () => {
  it('returns only pinned workspaces when pinned=true', async () => {
    await auth(request.post('/api/workspaces')).send({ name: 'Normal WS' });
    const r2 = await auth(request.post('/api/workspaces')).send({ name: 'Pinned WS', pinned: true });

    const res = await auth(request.get('/api/workspaces?pinned=true'));
    expect(res.status).toBe(200);
    expect(res.body.items).toHaveLength(1);
    expect(res.body.items[0].name).toBe('Pinned WS');
  });
});

// ─── SPEC 14 — lastActivity depuis dernière conversation ──────────────────────
describe('SPEC 14 — lastActivity depuis dernière conversation', () => {
  it('lastActivity reflects max conversations.updated_at', async () => {
    const r1 = await auth(request.post('/api/workspaces')).send({ name: 'WS With Conv' });
    const wsId = r1.body.id;

    // Insert a conversation directly
    const convId = uuidv4();
    sqlite.prepare(
      `INSERT INTO conversations (id, workspace_id, title) VALUES (?, ?, ?)`
    ).run(convId, wsId, 'Test Conversation');

    const res = await auth(request.get('/api/workspaces'));
    expect(res.status).toBe(200);
    const ws = res.body.items.find((w) => w.id === wsId);
    expect(ws).toBeTruthy();
    expect(ws.lastActivity).not.toBeNull();
  });

  it('lastActivity is null when no conversation', async () => {
    await auth(request.post('/api/workspaces')).send({ name: 'WS No Conv' });

    const res = await auth(request.get('/api/workspaces'));
    expect(res.status).toBe(200);
    const ws = res.body.items[0];
    expect(ws.lastActivity).toBeNull();
  });
});

// ─── SPEC 15 — GET /:id par ID ───────────────────────────────────────────────
describe('SPEC 15 — GET /:id par ID', () => {
  it('returns workspace by UUID', async () => {
    const created = await auth(request.post('/api/workspaces')).send({ name: 'Find Me' });
    const res = await auth(request.get(`/api/workspaces/${created.body.id}`));
    expect(res.status).toBe(200);
    expect(res.body.id).toBe(created.body.id);
    expect(res.body.name).toBe('Find Me');
  });
});

// ─── SPEC 16 — GET /:id inexistant → 404 ─────────────────────────────────────
describe('SPEC 16 — GET /:id inexistant → 404', () => {
  it('returns 404 for unknown UUID', async () => {
    const res = await auth(request.get(`/api/workspaces/${uuidv4()}`));
    expect(res.status).toBe(404);
    expect(res.body.error).toBe('WORKSPACE_NOT_FOUND');
  });
});

// ─── SPEC 17 — GET /:slug (lookup par slug) ──────────────────────────────────
describe('SPEC 17 — GET /:slug (lookup par slug)', () => {
  it('returns workspace by slug', async () => {
    await auth(request.post('/api/workspaces')).send({ name: 'My Slug WS' });
    const res = await auth(request.get('/api/workspaces/my-slug-ws'));
    expect(res.status).toBe(200);
    expect(res.body.slug).toBe('my-slug-ws');
    expect(res.body.name).toBe('My Slug WS');
  });
});

// ─── SPEC 18 — PATCH name → updatedAt rafraîchi, slug inchangé ───────────────
describe('SPEC 18 — PATCH name → updatedAt rafraîchi, slug inchangé', () => {
  it('patching name updates updatedAt but keeps slug', async () => {
    const created = await auth(request.post('/api/workspaces')).send({ name: 'Original Name' });
    const originalSlug = created.body.slug;
    const originalUpdatedAt = created.body.updatedAt;

    // Small delay to ensure timestamp changes
    await new Promise((r) => setTimeout(r, 10));

    const res = await auth(request.patch(`/api/workspaces/${created.body.id}`)).send({ name: 'New Name' });
    expect(res.status).toBe(200);
    expect(res.body.name).toBe('New Name');
    expect(res.body.slug).toBe(originalSlug);
  });
});

// ─── SPEC 19 — PATCH color ───────────────────────────────────────────────────
describe('SPEC 19 — PATCH color', () => {
  it('patches color successfully', async () => {
    const created = await auth(request.post('/api/workspaces')).send({ name: 'Color WS' });
    const res = await auth(request.patch(`/api/workspaces/${created.body.id}`)).send({ color: '#abcdef' });
    expect(res.status).toBe(200);
    expect(res.body.color).toBe('#abcdef');
  });
});

// ─── SPEC 20 — PATCH pinned=true ─────────────────────────────────────────────
describe('SPEC 20 — PATCH pinned=true', () => {
  it('patches pinned to true', async () => {
    const created = await auth(request.post('/api/workspaces')).send({ name: 'Pin WS' });
    const res = await auth(request.patch(`/api/workspaces/${created.body.id}`)).send({ pinned: true });
    expect(res.status).toBe(200);
    expect(res.body.pinned).toBe(true);
  });
});

// ─── SPEC 21 — PATCH partiel (champs non fournis inchangés) ──────────────────
describe('SPEC 21 — PATCH partiel (champs non fournis inchangés)', () => {
  it('only updates specified fields, leaves others intact', async () => {
    const created = await auth(request.post('/api/workspaces')).send({
      name: 'Partial WS',
      color: '#aabbcc',
      description: 'original desc',
    });

    const res = await auth(request.patch(`/api/workspaces/${created.body.id}`)).send({ description: 'new desc' });
    expect(res.status).toBe(200);
    expect(res.body.description).toBe('new desc');
    expect(res.body.color).toBe('#aabbcc');
    expect(res.body.name).toBe('Partial WS');
  });
});

// ─── SPEC 22 — PATCH inexistant → 404 ────────────────────────────────────────
describe('SPEC 22 — PATCH inexistant → 404', () => {
  it('returns 404 for unknown workspace', async () => {
    const res = await auth(request.patch(`/api/workspaces/${uuidv4()}`)).send({ name: 'X' });
    expect(res.status).toBe(404);
    expect(res.body.error).toBe('WORKSPACE_NOT_FOUND');
  });
});

// ─── SPEC 23 — PATCH color invalide → 400 ────────────────────────────────────
describe('SPEC 23 — PATCH color invalide → 400', () => {
  it('returns 400 for invalid color in patch', async () => {
    const created = await auth(request.post('/api/workspaces')).send({ name: 'Color Test' });
    const res = await auth(request.patch(`/api/workspaces/${created.body.id}`)).send({ color: 'blue' });
    expect(res.status).toBe(400);
    expect(res.body.error).toBe('VALIDATION_ERROR');
  });
});

// ─── SPEC 24 — DELETE → 204 ──────────────────────────────────────────────────
describe('SPEC 24 — DELETE → 204', () => {
  it('deletes workspace and returns 204', async () => {
    const created = await auth(request.post('/api/workspaces')).send({ name: 'To Delete' });
    const res = await auth(request.delete(`/api/workspaces/${created.body.id}`));
    expect(res.status).toBe(204);
  });
});

// ─── SPEC 25 — DELETE → conversations et messages supprimés en cascade ────────
describe('SPEC 25 — DELETE → conversations et messages supprimés en cascade', () => {
  it('deleting workspace cascades to conversations and messages', async () => {
    const created = await auth(request.post('/api/workspaces')).send({ name: 'Cascade WS' });
    const wsId = created.body.id;

    const convId = uuidv4();
    sqlite.prepare(`INSERT INTO conversations (id, workspace_id, title) VALUES (?, ?, ?)`).run(convId, wsId, 'Conv');
    const msgId = uuidv4();
    sqlite.prepare(`INSERT INTO messages (id, conversation_id, role, content) VALUES (?, ?, ?, ?)`).run(msgId, convId, 'user', 'Hello');

    await auth(request.delete(`/api/workspaces/${wsId}`));

    const conv = sqlite.prepare('SELECT * FROM conversations WHERE id = ?').get(convId);
    const msg = sqlite.prepare('SELECT * FROM messages WHERE id = ?').get(msgId);
    expect(conv).toBeFalsy();
    expect(msg).toBeFalsy();
  });
});

// ─── SPEC 26 — DELETE → run_links.workspace_id = null (SET NULL via FK) ───────
describe('SPEC 26 — DELETE → run_links.workspace_id = null (SET NULL via FK)', () => {
  it('run_links.workspace_id becomes NULL after workspace deletion', async () => {
    const created = await auth(request.post('/api/workspaces')).send({ name: 'FK NULL WS' });
    const wsId = created.body.id;

    // Insert a run_link referencing this workspace
    const runId = uuidv4();
    sqlite.prepare(
      `INSERT INTO run_links (run_id, workspace_id, pipeline, status) VALUES (?, ?, ?, ?)`
    ).run(runId, wsId, 'test-pipeline', 'completed');

    // Delete the workspace
    await auth(request.delete(`/api/workspaces/${wsId}`));

    // run_link should still exist but workspace_id should be NULL
    const row = sqlite.prepare('SELECT workspace_id FROM run_links WHERE run_id = ?').get(runId);
    expect(row).toBeTruthy();
    expect(row.workspace_id).toBeNull();
  });
});

// ─── SPEC 27 — DELETE inexistant → 404 ───────────────────────────────────────
describe('SPEC 27 — DELETE inexistant → 404', () => {
  it('returns 404 for unknown workspace', async () => {
    const res = await auth(request.delete(`/api/workspaces/${uuidv4()}`));
    expect(res.status).toBe(404);
    expect(res.body.error).toBe('WORKSPACE_NOT_FOUND');
  });
});

// ─── SPEC 28 — GET /:id/stats workspace vide ─────────────────────────────────
describe('SPEC 28 — GET /:id/stats workspace vide', () => {
  it('returns zero stats for empty workspace', async () => {
    const created = await auth(request.post('/api/workspaces')).send({ name: 'Empty Stats WS' });
    const res = await auth(request.get(`/api/workspaces/${created.body.id}/stats`));
    expect(res.status).toBe(200);
    expect(res.body.totalCost).toBe(0);
    expect(res.body.totalRuns).toBe(0);
    expect(res.body.totalMessages).toBe(0);
    expect(res.body.totalTokens).toBe(0);
    expect(res.body.conversationCount).toBe(0);
    expect(res.body.lastRunAt).toBeNull();
  });
});

// ─── SPEC 29 — GET /:id/stats avec données ───────────────────────────────────
describe('SPEC 29 — GET /:id/stats avec données', () => {
  it('returns correct stats with data', async () => {
    const created = await auth(request.post('/api/workspaces')).send({ name: 'Stats WS' });
    const wsId = created.body.id;

    const convId = uuidv4();
    sqlite.prepare(`INSERT INTO conversations (id, workspace_id, title) VALUES (?, ?, ?)`).run(convId, wsId, 'Conv 1');

    const msgId = uuidv4();
    sqlite.prepare(`INSERT INTO messages (id, conversation_id, role, content) VALUES (?, ?, ?, ?)`).run(msgId, convId, 'user', 'Hello');

    const runId = uuidv4();
    sqlite.prepare(
      `INSERT INTO run_links (run_id, workspace_id, pipeline, status, total_cost, total_tokens, completed_at)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    ).run(runId, wsId, 'test-pipe', 'completed', 1.5, 500, new Date().toISOString());

    const res = await auth(request.get(`/api/workspaces/${wsId}/stats`));
    expect(res.status).toBe(200);
    expect(res.body.totalCost).toBe(1.5);
    expect(res.body.totalRuns).toBe(1);
    expect(res.body.totalMessages).toBe(1);
    expect(res.body.totalTokens).toBe(500);
    expect(res.body.conversationCount).toBe(1);
    expect(res.body.lastRunAt).not.toBeNull();
  });
});

// ─── SPEC 30 — GET /:id/stats inexistant → 404 ───────────────────────────────
describe('SPEC 30 — GET /:id/stats inexistant → 404', () => {
  it('returns 404 for unknown workspace stats', async () => {
    const res = await auth(request.get(`/api/workspaces/${uuidv4()}/stats`));
    expect(res.status).toBe(404);
    expect(res.body.error).toBe('WORKSPACE_NOT_FOUND');
  });
});
