/**
 * TDD — RED phase
 * Tests for src/auth/jwt.js: signToken, verifyToken, hashToken
 */
import { describe, it, expect } from 'vitest';
import { signToken, verifyToken, hashToken } from '../../src/auth/jwt.js';

const SECRET = 'test-secret-min-32-chars-long-here!!';

describe('signToken', () => {
  it('1. returns { token, expiresAt } with a valid JWT', async () => {
    const result = await signToken({}, SECRET, 3600);
    expect(result).toHaveProperty('token');
    expect(result).toHaveProperty('expiresAt');
    expect(typeof result.token).toBe('string');
    // JWT has 3 dot-separated parts
    expect(result.token.split('.')).toHaveLength(3);
    // expiresAt is ISO 8601
    expect(() => new Date(result.expiresAt)).not.toThrow();
    expect(result.expiresAt).toMatch(/^\d{4}-\d{2}-\d{2}T/);
  });

  it('2. ttl=3600 → exp - iat ≈ 3600 (±5s)', async () => {
    const before = Math.floor(Date.now() / 1000);
    const { token } = await signToken({}, SECRET, 3600);
    const parts = token.split('.');
    const payload = JSON.parse(Buffer.from(parts[1], 'base64url').toString());
    expect(Math.abs(payload.exp - payload.iat - 3600)).toBeLessThanOrEqual(5);
  });

  it('3. ttl=604800 → exp - iat ≈ 604800 (±5s)', async () => {
    const { token } = await signToken({}, SECRET, 604800);
    const parts = token.split('.');
    const payload = JSON.parse(Buffer.from(parts[1], 'base64url').toString());
    expect(Math.abs(payload.exp - payload.iat - 604800)).toBeLessThanOrEqual(5);
  });

  it('4. injects sub: local when not provided', async () => {
    const { token } = await signToken({}, SECRET, 3600);
    const parts = token.split('.');
    const payload = JSON.parse(Buffer.from(parts[1], 'base64url').toString());
    expect(payload.sub).toBe('local');
  });

  it('5. preserves custom sub when provided', async () => {
    const { token } = await signToken({ sub: 'user-42' }, SECRET, 3600);
    const parts = token.split('.');
    const payload = JSON.parse(Buffer.from(parts[1], 'base64url').toString());
    expect(payload.sub).toBe('user-42');
  });
});

describe('verifyToken', () => {
  it('4. good secret → returns payload with sub, iat, exp', async () => {
    const { token } = await signToken({ sub: 'local' }, SECRET, 3600);
    const { payload } = await verifyToken(token, SECRET);
    expect(payload).toHaveProperty('sub', 'local');
    expect(payload).toHaveProperty('iat');
    expect(payload).toHaveProperty('exp');
  });

  it('5. wrong secret → throws { code: INVALID_TOKEN }', async () => {
    const { token } = await signToken({}, SECRET, 3600);
    await expect(verifyToken(token, 'totally-wrong-secret-32-chars-min!!')).rejects.toMatchObject({
      code: 'INVALID_TOKEN',
    });
  });

  it('6. expired token (ttl=1, wait 1100ms) → throws { code: TOKEN_EXPIRED }', async () => {
    const { token } = await signToken({}, SECRET, 1);
    await new Promise((r) => setTimeout(r, 1100));
    await expect(verifyToken(token, SECRET)).rejects.toMatchObject({
      code: 'TOKEN_EXPIRED',
    });
  }, 5000);
});

describe('hashToken', () => {
  it('7. returns a 64-char hex string', () => {
    const { token } = { token: 'some.jwt.token' };
    const hash = hashToken('some.jwt.token');
    expect(typeof hash).toBe('string');
    expect(hash).toHaveLength(64);
    expect(hash).toMatch(/^[0-9a-f]+$/);
  });

  it('8. deterministic: same input → same output', () => {
    const t = 'same.token.value';
    expect(hashToken(t)).toBe(hashToken(t));
  });

  it('9. different tokens → different hashes', async () => {
    const { token: t1 } = await signToken({ nonce: 1 }, SECRET, 3600);
    const { token: t2 } = await signToken({ nonce: 2 }, SECRET, 3600);
    expect(hashToken(t1)).not.toBe(hashToken(t2));
  });
});
