/**
 * TDD — RED phase
 * Tests for NdjsonParser (src/ipc/parser.js)
 */
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { NdjsonParser } from '../../src/ipc/parser.js';

describe('NdjsonParser', () => {
  let parser;

  beforeEach(() => {
    parser = new NdjsonParser();
    vi.restoreAllMocks();
  });

  it('1. parses a complete single message in one chunk', () => {
    const msg = { type: 'run.started', runId: 'abc-123' };
    const chunk = JSON.stringify(msg) + '\n';
    const result = parser.feed(chunk);
    expect(result).toHaveLength(1);
    expect(result[0].parsed).toEqual(msg);
    expect(result[0].rawLine).toBe(chunk);
  });

  it('2. buffers a partial message across two chunks', () => {
    const msg = { type: 'run.done', runId: 'xyz-456', status: 'completed' };
    const full = JSON.stringify(msg) + '\n';
    const half = Math.floor(full.length / 2);

    const first = parser.feed(full.slice(0, half));
    expect(first).toHaveLength(0);

    const second = parser.feed(full.slice(half));
    expect(second).toHaveLength(1);
    expect(second[0].parsed).toEqual(msg);
    expect(second[0].rawLine).toBe(full);
  });

  it('3. returns array of 2 when two messages arrive in one chunk', () => {
    const msg1 = { type: 'run.started', runId: 'r1' };
    const msg2 = { type: 'run.phase.log', phaseId: 'p1', log: 'hello' };
    const chunk = JSON.stringify(msg1) + '\n' + JSON.stringify(msg2) + '\n';
    const result = parser.feed(chunk);
    expect(result).toHaveLength(2);
    expect(result[0].parsed).toEqual(msg1);
    expect(result[1].parsed).toEqual(msg2);
  });

  it('4. returns [] and logs warn on invalid JSON line', () => {
    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});
    const result = parser.feed('{ not valid json }\n');
    expect(result).toHaveLength(0);
    expect(warnSpy).toHaveBeenCalledOnce();
    expect(warnSpy.mock.calls[0][0]).toMatch(/NDJSON.*parse/i);
  });

  it('5. ignores empty lines', () => {
    const result = parser.feed('\n\n\n');
    expect(result).toHaveLength(0);
  });

  it('6. reset() clears the buffer so leftover bytes are discarded', () => {
    // Feed a partial message without newline
    parser.feed('{"type":"run.');
    parser.reset();
    // After reset, the remaining bytes complete a DIFFERENT message — no bleed
    const msg = { type: 'run.done', runId: 'clean' };
    const full = JSON.stringify(msg) + '\n';
    const result = parser.feed(full);
    expect(result).toHaveLength(1);
    expect(result[0].parsed).toEqual(msg);
  });

  it('handles message with no trailing newline (buffered, not returned)', () => {
    const msg = { type: 'ping' };
    const partial = JSON.stringify(msg); // no \n
    const result = parser.feed(partial);
    expect(result).toHaveLength(0);
  });

  it('handles mixed valid + invalid lines in same chunk', () => {
    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});
    const valid = { type: 'run.started', runId: 'ok' };
    const chunk = JSON.stringify(valid) + '\n' + 'BROKEN\n';
    const result = parser.feed(chunk);
    expect(result).toHaveLength(1);
    expect(result[0].parsed).toEqual(valid);
    expect(warnSpy).toHaveBeenCalledOnce();
  });
});
