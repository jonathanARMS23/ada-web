# ADA UI — Dashboard v2

Interface web Next.js 15 pour piloter ADA depuis le navigateur.

## Stack
- Next.js 15 App Router + TypeScript
- TanStack Query v5 (fetching + mutations)
- Zustand (état global profil actif)
- shadcn/ui + Tailwind CSS
- SSE (chokidar file-watch → EventSource)

## Pages

| Route | Description |
|-------|-------------|
| `/dashboard` | Vue globale — runs récents, coût, état |
| `/auth` | Configuration auth Claude |
| `/agents` | Liste des agents avec hot-reload |
| `/teams` | Equipes et compositions |
| `/profile-types` | Types de profils de routing |
| `/pipelines` | Pipelines déclaratifs + phases |
| `/connectors` | Registre MCP — catalogue 15 serveurs, toggle |
| `/schedules` | Planification cron des pipelines |
| `/audit` | Journal d'audit NDJSON, auto-refresh 30s |
| `/settings` | Webhook config + paramètres |

## Démarrage

```bash
# Depuis le répertoire ada-ui
npm run dev        # dev server http://localhost:3000
npm run build      # build production
npm run start      # serveur production
```

Ou via la commande `ada` :
```bash
ada start          # démarre ada-ui en arrière-plan
ada open           # ouvre dans le navigateur
ada stop           # arrête le serveur
```

## SSE — Temps réel

L'endpoint `GET /api/events` émet des événements chokidar pour :
- Modifications de fichiers `state.json`, `runs/*`, `agents/`
- Sentinel `.last-modified` (hot-reload agents)

## API Routes

| Route | Méthodes | Description |
|-------|----------|-------------|
| `/api/mcp/registry` | GET, POST | Registre + catalogue MCP |
| `/api/mcp/registry/[id]` | PATCH, DELETE | Toggle/supprimer connecteur |
| `/api/runs` | GET | Liste des runs |
| `/api/runs/[id]` | GET | Détail run |
| `/api/runs/[id]/retry` | POST | Relancer phases échouées |
| `/api/stats/cost` | GET | Stats coût `?profile` |
| `/api/stats/audit` | GET | Journal audit `?profile&limit` |
| `/api/pipelines` | GET, POST | Pipelines |
| `/api/pipelines/[name]` | PATCH, DELETE | Modifier pipeline |
| `/api/schedules` | GET, POST | Schedules |
| `/api/schedules/[id]` | PATCH, DELETE | Modifier schedule |
| `/api/settings/webhook` | GET, POST, DELETE | Config webhook |
| `/api/events` | GET | SSE file-watch stream |
| `/api/agents` | GET | Liste agents |
| `/api/profiles` | GET | Profils installés |
| `/api/profiles/switch` | POST | Changer de profil |

## Variables d'environnement

Aucune variable requise — l'UI lit directement les fichiers du profil actif via `~/.ada.json`.
