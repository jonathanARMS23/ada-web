'use client'

import { useMemo, useState } from 'react'
import { useShallow } from 'zustand/react/shallow'
import { useAdaStore } from '@/store/ada-store'
import { Icon } from '@/lib/icons'
import { Card } from '@/components/ada/Card'
import { Button } from '@/components/ada/Button'
import { Table, Meter } from '@/components/ada/Table'
import { Tabs } from '@/components/ada/Tabs'
import { Drawer } from '@/components/ada/Drawer'
import { Avatar, TierBadge, toTier, type Tier } from '@/components/ada/TierBadge'
import { StatusBadge } from '@/components/ada/StatusBadge'
import { DashboardError } from '@/components/dashboard/States'
import { useAgents, useAgentDetail, type AgentInfo, type AgentDetail } from '@/hooks/use-agents'
import { useTeams } from '@/hooks/use-teams'
import { useProfiles, useSwitchProfile } from '@/hooks/use-profiles'

export default function AgentsPage() {
  const [tab, setTab] = useState('agents')
  const [search, setSearch] = useState('')
  const [openSlug, setOpenSlug] = useState<string | null>(null)

  const agents = useAgents()
  const teams = useTeams()
  const profiles = useProfiles()

  const list = useMemo(() => agents.data ?? [], [agents.data])
  const filtered = useMemo(
    () =>
      list.filter(
        (a) =>
          a.slug.toLowerCase().includes(search.toLowerCase()) ||
          (a.role ?? '').toLowerCase().includes(search.toLowerCase()),
      ),
    [list, search],
  )

  return (
    <>
      <div className="page-head fade-up">
        <div>
          <h1>Agents</h1>
          <div className="sub">
            {list.length} agents · {profiles.data?.profiles.length ?? 0} profils · liés à un tier de modèle
          </div>
        </div>
        <div className="page-head-actions">
          <div className="field" style={{ width: 240 }}>
            <Icon name="search" />
            <input
              placeholder="Rechercher un agent…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              aria-label="Rechercher un agent"
            />
          </div>
        </div>
      </div>

      <Tabs
        tabs={[
          { id: 'agents', label: 'Agents', count: list.length },
          { id: 'profiles', label: 'Profiles', count: profiles.data?.profiles.length },
          { id: 'teams', label: 'Teams', count: teams.data?.length },
        ]}
        active={tab}
        onChange={setTab}
      />

      {tab === 'agents' && (
        <div className="fade-up">
          {agents.isLoading ? (
            <Card className="skel" style={{ height: 320, border: 'none' }} aria-busy="true" />
          ) : agents.isError ? (
            <DashboardError onRetry={() => void agents.refetch()} />
          ) : filtered.length === 0 ? (
            <Card>
              <div className="empty" style={{ padding: '48px 20px' }}>
                <Icon name="agents" />
                <b>Aucun agent</b>
                <span>Aucun agent ne correspond à la recherche.</span>
              </div>
            </Card>
          ) : (
            <Card>
              <Table compact>
                <thead>
                  <tr>
                    <th>Agent</th>
                    <th>Tier</th>
                    <th>Rôle</th>
                    <th className="r">Runs</th>
                    <th style={{ width: 130 }}>Win rate</th>
                    <th className="r">Coût moy.</th>
                    <th />
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((a) => (
                    <AgentRow key={a.slug} agent={a} onOpen={() => setOpenSlug(a.slug)} />
                  ))}
                </tbody>
              </Table>
            </Card>
          )}
        </div>
      )}

      {tab === 'profiles' && (
        <div className="agent-grid fade-up">
          {(profiles.data?.profiles ?? []).map((p) => (
            <ProfileCardItem
              key={p.id}
              id={p.id}
              name={p.name}
              tier={toTier(p.tier)}
              active={p.id === profiles.data?.activeProfile}
            />
          ))}
          {profiles.isLoading && <Card className="skel" style={{ height: 180, border: 'none' }} />}
        </div>
      )}

      {tab === 'teams' && (
        <div className="agent-grid fade-up" id="team-grid">
          {teams.isError ? (
            <DashboardError onRetry={() => void teams.refetch()} />
          ) : (teams.data ?? []).length === 0 && !teams.isLoading ? (
            <Card>
              <div className="empty" style={{ padding: '48px 20px' }}>
                <Icon name="shield" />
                <b>Aucune team</b>
              </div>
            </Card>
          ) : (
            (teams.data ?? []).map((t) => (
              <Card key={t.id} className="card-pad">
                <div style={{ display: 'flex', alignItems: 'center', gap: 9, marginBottom: 10 }}>
                  <Icon name="shield" style={{ width: 18, height: 18, color: 'var(--muted)' }} />
                  <b style={{ fontSize: 14 }}>{t.name}</b>
                  {toTier(t.tier) && <span style={{ marginLeft: 'auto' }}><TierBadge tier={toTier(t.tier)!} /></span>}
                </div>
                <div className="dim mono" style={{ fontSize: 11.5, marginBottom: 12 }}>
                  {t.agents.join(' · ')}
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: 'var(--muted)' }}>
                  <span>{t.runs ?? 0} runs</span>
                </div>
              </Card>
            ))
          )}
        </div>
      )}

      <AgentDrawer slug={openSlug} onClose={() => setOpenSlug(null)} />
    </>
  )
}

function AgentRow({ agent, onOpen }: { agent: AgentInfo; onOpen: () => void }) {
  const tier = toTier(agent.tier) ?? 'sonnet'
  const pct = agent.winRate != null ? Math.round(agent.winRate * 100) : null
  return (
    <tr style={{ cursor: 'pointer' }} onClick={onOpen}>
      <td>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
          <Avatar tier={tier} name={agent.name} size="sm" />
          <span className="cell-strong">{agent.slug}</span>
        </div>
      </td>
      <td>
        <TierBadge tier={tier} />
      </td>
      <td className="dim">{agent.role ?? '—'}</td>
      <td className="r cell-mono dim">{agent.runs ?? '—'}</td>
      <td>
        {pct != null ? (
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <Meter value={pct} variant="win" style={{ flex: 1 }} />
            <span className="cell-mono" style={{ fontSize: 11, width: 28, textAlign: 'right' }}>
              {pct}%
            </span>
          </div>
        ) : (
          <span className="faint">—</span>
        )}
      </td>
      <td className="r cell-mono">{agent.avgCost != null ? `$${agent.avgCost.toFixed(2)}` : '—'}</td>
      <td className="r faint">
        <Icon name="chevron" style={{ width: 15, height: 15 }} />
      </td>
    </tr>
  )
}

function ProfileCardItem({
  id,
  name,
  tier,
  active,
}: {
  id: string
  name: string
  tier: 'haiku' | 'sonnet' | 'opus' | null
  active: boolean
}) {
  const setActiveProfile = useAdaStore(useShallow((s) => s.setActiveProfile))
  const switchProfile = useSwitchProfile()
  return (
    <Card className="card-pad">
      <div style={{ display: 'flex', alignItems: 'center', gap: 11 }}>
        <Avatar tier={tier ?? 'sonnet'} name={name} size="lg" />
        <div>
          <b style={{ fontSize: 15 }}>{name}</b>
          <div className="dim mono" style={{ fontSize: 11.5 }}>
            ~/.{id}
          </div>
        </div>
        <span style={{ marginLeft: 'auto' }}>
          <StatusBadge status={active ? 'running' : 'idle'} label="" />
        </span>
      </div>
      <hr className="sep-line" style={{ margin: '14px 0' }} />
      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, marginBottom: 7 }}>
        <span className="dim">Tier par défaut</span>
        {tier ? <TierBadge tier={tier} /> : <span className="faint">—</span>}
      </div>
      <Button
        size="sm"
        variant={active ? 'ghost' : 'primary'}
        disabled={active || switchProfile.isPending}
        style={{ width: '100%', marginTop: 14, justifyContent: 'center' }}
        onClick={async () => {
          await switchProfile.mutateAsync(id)
          setActiveProfile(id)
        }}
      >
        {active ? 'Profil actif' : 'Basculer'}
      </Button>
    </Card>
  )
}

function AgentDrawer({ slug, onClose }: { slug: string | null; onClose: () => void }) {
  const { data, isLoading } = useAgentDetail(slug)
  const tier = toTier(data?.tier) ?? 'sonnet'
  return (
    <Drawer
      open={!!slug}
      onClose={onClose}
      title={
        <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          {data && <Avatar tier={tier} name={data.name} size="sm" />}
          {slug}
        </span>
      }
    >
      {isLoading || !data ? (
        <div className="skel" style={{ height: 120 }} />
      ) : (
        <AgentDrawerBody data={data} tier={tier} />
      )}
    </Drawer>
  )
}

function DrawerSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div style={{ marginBottom: 18 }}>
      <h4
        style={{
          fontSize: 12,
          textTransform: 'uppercase',
          letterSpacing: '.06em',
          color: 'var(--muted)',
          margin: '0 0 8px',
        }}
      >
        {title}
      </h4>
      {children}
    </div>
  )
}

function AgentDrawerBody({ data, tier }: { data: AgentDetail; tier: Tier }) {
  // Réalité backend : aucun run encore exécuté → totalRuns === 0 est une donnée
  // honnête, pas un bug. On affiche alors « Aucun run » plutôt qu'un faux 0%.
  const runs = data.runs ?? 0
  const hasRuns = runs > 0
  const winPct = data.pWin != null ? Math.round(data.pWin * 100) : null
  const successPct = data.successRate != null ? Math.round(data.successRate * 100) : null

  return (
    <>
      <div style={{ display: 'flex', gap: 8, marginBottom: 16, alignItems: 'center' }}>
        <TierBadge tier={tier} />
        {data.title && <b style={{ fontSize: 14 }}>{data.title}</b>}
        <span style={{ marginLeft: 'auto' }}>
          <StatusBadge status={data.active === false ? 'idle' : 'running'} label={data.active === false ? 'inactif' : 'actif'} />
        </span>
      </div>

      {/* Description + Role (texte réel) */}
      <DrawerSection title="Description">
        <p style={{ fontSize: 13.5, color: 'var(--fg-dim)', lineHeight: 1.6, margin: 0 }}>
          {data.description?.trim() || '—'}
        </p>
        {data.role?.trim() ? (
          <div style={{ marginTop: 10, fontSize: 12.5, color: 'var(--muted)' }}>
            <span className="dim">Rôle : </span>
            <span style={{ color: 'var(--fg-dim)' }}>{data.role}</span>
          </div>
        ) : null}
      </DrawerSection>

      {/* Stats réelles (Thompson) */}
      <DrawerSection title="Statistiques">
        {hasRuns ? (
          <div className="bento cols-3">
            <Card className="kpi" style={{ padding: 12 }}>
              <div className="kpi-top" style={{ fontSize: 11 }}>Win rate</div>
              <div className="kpi-val num" style={{ fontSize: 22, color: 'var(--st-success)' }}>
                {winPct != null ? `${winPct}%` : '—'}
              </div>
            </Card>
            <Card className="kpi" style={{ padding: 12 }}>
              <div className="kpi-top" style={{ fontSize: 11 }}>Runs</div>
              <div className="kpi-val num" style={{ fontSize: 22 }}>{runs}</div>
            </Card>
            <Card className="kpi" style={{ padding: 12 }}>
              <div className="kpi-top" style={{ fontSize: 11 }}>Succès</div>
              <div className="kpi-val num" style={{ fontSize: 22 }}>
                {successPct != null ? `${successPct}%` : '—'}
              </div>
            </Card>
          </div>
        ) : (
          <Card className="card-pad">
            <div className="dim" style={{ fontSize: 13 }}>
              Aucun run — cet agent n&apos;a encore jamais été exécuté.
              {winPct != null ? ` Win rate a priori (Thompson) : ${winPct}%.` : ''}
            </div>
          </Card>
        )}
        {(data.alpha != null || data.beta != null) && (
          <Card
            className="card-pad"
            style={{ fontFamily: 'var(--font-mono)', fontSize: 12.5, color: 'var(--fg-dim)', marginTop: 10 }}
          >
            Prior Thompson (Beta) · α = {data.alpha != null ? Number(data.alpha.toFixed(2)) : '—'} · β ={' '}
            {data.beta != null ? Number(data.beta.toFixed(2)) : '—'}
            {data.pWin != null ? ` · pWin = ${data.pWin.toFixed(3)}` : ''}
          </Card>
        )}
      </DrawerSection>

      {/* Skills (string[]) — défensif : peut être absent le temps que le backend redémarre */}
      <DrawerSection title="Skills">
        {data.skills.length > 0 ? (
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {data.skills.map((s) => (
              <span key={s} className="chip">{s}</span>
            ))}
          </div>
        ) : (
          <span className="faint" style={{ fontSize: 13 }}>Aucun skill déclaré</span>
        )}
      </DrawerSection>

      {/* MCP (string[]) — serveurs susceptibles d'être utilisés */}
      <DrawerSection title="Serveurs MCP">
        {data.mcps.length > 0 ? (
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {data.mcps.map((m) => (
              <span key={m} className="chip">
                <Icon name="mcp" />
                {m}
              </span>
            ))}
          </div>
        ) : (
          <span className="faint" style={{ fontSize: 13 }}>Aucun MCP</span>
        )}
      </DrawerSection>
    </>
  )
}
