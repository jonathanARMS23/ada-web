'use client'

import { useShallow } from 'zustand/react/shallow'
import { useAdaStore } from '@/store/ada-store'
import {
  useOverview,
  useActivity,
  useTimeline,
  useBudget,
  useRouterStats,
} from '@/hooks/use-dashboard'
import { Button } from '@/components/ada/Button'
import { Icon } from '@/lib/icons'
import { KpiRow } from '@/components/dashboard/KpiRow'
import { ActivityHeatmap } from '@/components/dashboard/ActivityHeatmap'
import { ThompsonTable } from '@/components/dashboard/ThompsonTable'
import { RunsTimeline } from '@/components/dashboard/RunsTimeline'
import { CostBudget } from '@/components/dashboard/CostBudget'
import { DashboardSkeleton, DashboardError } from '@/components/dashboard/States'

/** Tendance pour la sparkline du KPI succès : derniers jours d'activité (runs). */
function trendFromActivity(buckets: { runs: number }[]): number[] {
  return buckets.slice(-14).map((b) => b.runs)
}

export default function DashboardPage() {
  const { activeProfile, wsConnected } = useAdaStore(
    useShallow((s) => ({ activeProfile: s.activeProfile, wsConnected: s.adaApiConnected })),
  )

  const overview = useOverview()
  const activity = useActivity(90)
  const timeline = useTimeline(8)
  const budget = useBudget()
  const router = useRouterStats()

  const loading = overview.isLoading
  const failed = overview.isError

  function retryAll() {
    void overview.refetch()
    void activity.refetch()
    void timeline.refetch()
    void budget.refetch()
    void router.refetch()
  }

  return (
    <>
      <div className="page-head fade-up">
        <div>
          <h1>Dashboard</h1>
          <div className="sub">
            Vue d'ensemble système
            {activeProfile && (
              <>
                {' · profil '}
                <b style={{ color: 'var(--fg)' }}>{activeProfile}</b>
              </>
            )}
          </div>
        </div>
        <div className="page-head-actions">
          <span
            className={wsConnected ? 'badge running' : 'badge idle'}
            role="status"
            aria-live="polite"
            title={wsConnected ? 'Flux temps réel connecté' : 'Flux temps réel déconnecté'}
          >
            {wsConnected ? <span className="dot" aria-hidden="true" /> : <Icon name="clock" />}
            {wsConnected ? 'live' : 'hors ligne'}
          </span>
          <Button size="sm" onClick={retryAll} disabled={overview.isFetching}>
            <Icon name="refresh" />
            Actualiser
          </Button>
        </div>
      </div>

      {loading ? (
        <DashboardSkeleton />
      ) : failed ? (
        <DashboardError onRetry={retryAll} />
      ) : (
        <>
          {overview.data && (
            <KpiRow
              overview={overview.data}
              router={router.data ?? overview.data.router}
              successTrend={trendFromActivity(activity.data?.buckets ?? [])}
            />
          )}

          {activity.data && <ActivityHeatmap data={activity.data} />}

          <section
            className="bento gap-lg fade-up"
            style={{ gridTemplateColumns: '1.1fr 1fr 1fr', marginBottom: 18 }}
          >
            <ThompsonTable router={router.data ?? overview.data?.router} overview={overview.data} />
            <RunsTimeline items={timeline.data?.items ?? []} />
            {overview.data && <CostBudget overview={overview.data} budget={budget.data} />}
          </section>
        </>
      )}
    </>
  )
}
