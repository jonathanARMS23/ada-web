'use client'

import { useEffect } from 'react'

export default function Error({
  error,
  unstable_retry,
}: {
  error: Error & { digest?: string }
  unstable_retry: () => void
}) {
  useEffect(() => {
    console.error('[ada-ui] page error:', error)
  }, [error])

  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        minHeight: '60vh',
        gap: 16,
        textAlign: 'center',
        padding: 24,
      }}
    >
      <p style={{ color: 'var(--muted)', fontSize: 14 }}>Une erreur est survenue lors du chargement de cette page.</p>
      <button className="btn btn-primary" onClick={unstable_retry}>
        Réessayer
      </button>
    </div>
  )
}
