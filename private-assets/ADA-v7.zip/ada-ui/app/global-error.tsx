'use client'

import { useEffect } from 'react'

export default function GlobalError({
  error,
  unstable_retry,
}: {
  error: Error & { digest?: string }
  unstable_retry: () => void
}) {
  useEffect(() => {
    console.error('[ada-ui] global error:', error)
  }, [error])

  return (
    <html lang="fr" data-theme="dark">
      <body style={{ background: '#08090D', color: '#828B9C', fontFamily: 'system-ui, sans-serif' }}>
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '100vh', gap: '16px', textAlign: 'center', padding: '24px' }}>
          <p style={{ fontSize: '14px' }}>Une erreur critique est survenue.</p>
          <button
            onClick={unstable_retry}
            style={{ padding: '8px 16px', fontSize: '14px', borderRadius: '7px', background: '#3B82F6', color: '#fff', border: 'none', cursor: 'pointer', fontWeight: 600 }}
          >
            Recharger
          </button>
        </div>
      </body>
    </html>
  )
}
