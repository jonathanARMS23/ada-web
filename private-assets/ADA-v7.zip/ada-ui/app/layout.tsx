export const dynamic = 'force-dynamic'

import type { Metadata } from 'next'
import './globals.css'
import { Providers } from './providers'
import { AppShell } from '@/components/layout/AppShell'

export const metadata: Metadata = {
  title: 'ADA · Mission control',
  description: "Interface d'orchestration locale ADA",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  // Le nonce CSP est injecté par proxy.ts dans le header Content-Security-Policy.
  // data-theme est posé par next-themes (defaultTheme dark) ; suppressHydrationWarning
  // évite le mismatch SSR sur l'attribut de thème.
  return (
    <html lang="fr" suppressHydrationWarning>
      <body>
        <Providers>
          <AppShell>{children}</AppShell>
        </Providers>
      </body>
    </html>
  )
}
