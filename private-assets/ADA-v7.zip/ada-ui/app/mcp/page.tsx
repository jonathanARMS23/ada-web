'use client'

import { Icon } from '@/lib/icons'
import { Card } from '@/components/ada/Card'
import { Button } from '@/components/ada/Button'
import { StatusBadge } from '@/components/ada/StatusBadge'
import { DashboardError } from '@/components/dashboard/States'
import {
  useMcpConnectors,
  useMcpRegistry,
  useCreateConnector,
  useDeleteConnector,
  type McpConnector,
} from '@/hooks/use-mcp'

function initials(name: string): string {
  return name.replace(/[^a-zA-Z]/g, '').slice(0, 2).toUpperCase() || 'MC'
}

export default function McpPage() {
  const connectors = useMcpConnectors()
  const registry = useMcpRegistry()
  const create = useCreateConnector()
  const remove = useDeleteConnector()

  const servers = connectors.data ?? []
  const totalTools = servers.reduce((s, c) => s + (c.toolCount ?? 0), 0)
  const healthy = servers.filter((c) => c.status === 'running').length

  async function onConnect(name: string) {
    const url = window.prompt(`URL ou commande du serveur « ${name} » ?`)?.trim()
    if (!url) return
    const isUrl = /^https?:\/\//.test(url)
    await create.mutateAsync({ name, ...(isUrl ? { url } : { command: url }) })
  }

  return (
    <>
      <div className="page-head fade-up">
        <div>
          <h1>MCP</h1>
          <div className="sub">
            Model Context Protocol · {servers.length} serveurs connectés · {totalTools} outils exposés
          </div>
        </div>
        <div className="page-head-actions">
          <Button size="sm" onClick={() => void connectors.refetch()}>
            <Icon name="refresh" />
            Sync
          </Button>
          <Button variant="primary" onClick={() => void onConnect('custom')} disabled={create.isPending}>
            <Icon name="plus" />
            Connecter un serveur
          </Button>
        </div>
      </div>

      <section className="bento cols-4 fade-up" style={{ marginBottom: 18 }}>
        <Card className="kpi">
          <div className="kpi-top">Serveurs</div>
          <div className="kpi-val num">
            {healthy} <small>/ {servers.length}</small>
          </div>
          <div className="kpi-foot">
            {servers.length > 0 && healthy === servers.length ? (
              <StatusBadge status="success" label="tous sains" />
            ) : (
              <span className="dim">{servers.length - healthy} dégradé(s)</span>
            )}
          </div>
        </Card>
        <Card className="kpi">
          <div className="kpi-top">Outils</div>
          <div className="kpi-val num">{totalTools}</div>
          <div className="kpi-foot">exposés aux agents</div>
        </Card>
        <Card className="kpi">
          <div className="kpi-top">Catalogue</div>
          <div className="kpi-val num">{registry.data?.length ?? 0}</div>
          <div className="kpi-foot">serveurs disponibles</div>
        </Card>
        <Card className="kpi">
          <div className="kpi-top">Transport</div>
          <div className="kpi-val num">{new Set(servers.map((s) => s.transport)).size}</div>
          <div className="kpi-foot">types actifs</div>
        </Card>
      </section>

      <h3 style={{ fontSize: 14, marginBottom: 12 }} className="fade-up">
        Serveurs connectés
      </h3>
      {connectors.isError ? (
        <DashboardError onRetry={() => void connectors.refetch()} />
      ) : connectors.isLoading ? (
        <div className="mcp-grid fade-up" style={{ marginBottom: 26 }}>
          {Array.from({ length: 3 }).map((_, i) => (
            <Card key={i} className="skel" style={{ height: 150, border: 'none' }} />
          ))}
        </div>
      ) : servers.length === 0 ? (
        <Card className="fade-up" style={{ marginBottom: 26 }}>
          <div className="empty" style={{ padding: '40px 20px' }}>
            <Icon name="mcp" />
            <b>Aucun serveur connecté</b>
            <span>Connectez un serveur depuis le catalogue ci-dessous.</span>
          </div>
        </Card>
      ) : (
        <div className="mcp-grid fade-up" style={{ marginBottom: 26 }}>
          {servers.map((s) => (
            <ConnectorCard key={s.id} connector={s} onRemove={() => void remove.mutate(s.id)} />
          ))}
        </div>
      )}

      <h3 style={{ fontSize: 14, marginBottom: 12 }} className="fade-up">
        Catalogue
      </h3>
      <div className="mcp-grid fade-up">
        {(registry.data ?? []).map((c) => (
          <Card key={c.id} className="card-pad" style={{ opacity: 0.92 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 11, marginBottom: 10 }}>
              <span className="srv-ic" style={{ color: 'var(--muted)' }}>
                {initials(c.name)}
              </span>
              <div style={{ flex: 1 }}>
                <b style={{ fontSize: 14 }}>{c.name}</b>
                <div className="dim" style={{ fontSize: 12 }}>
                  {c.description ?? '—'}
                </div>
              </div>
            </div>
            <Button
              size="sm"
              style={{ width: '100%', justifyContent: 'center' }}
              onClick={() => void onConnect(c.name)}
              disabled={create.isPending}
            >
              <Icon name="plus" />
              Connecter
            </Button>
          </Card>
        ))}
      </div>
    </>
  )
}

function ConnectorCard({ connector, onRemove }: { connector: McpConnector; onRemove: () => void }) {
  return (
    <Card className="card-pad">
      <div style={{ display: 'flex', alignItems: 'center', gap: 11, marginBottom: 12 }}>
        <span className="srv-ic">{initials(connector.name)}</span>
        <div style={{ flex: 1 }}>
          <b style={{ fontSize: 14 }}>{connector.name}</b>
          <div className="dim mono" style={{ fontSize: 11 }}>
            transport · {connector.transport}
          </div>
        </div>
        <StatusBadge status={connector.status === 'running' ? 'running' : connector.status === 'warning' ? 'warning' : 'idle'} label={connector.status === 'running' ? 'live' : connector.status} />
      </div>
      {connector.description && (
        <div className="dim" style={{ fontSize: 12.5, marginBottom: 12 }}>
          {connector.description}
        </div>
      )}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: 12 }}>
        <span className="cost">{connector.toolCount ?? 0} outils</span>
        <Button size="sm" onClick={onRemove} style={{ color: 'var(--st-error)' }}>
          <Icon name="x" style={{ width: 13, height: 13 }} />
          Retirer
        </Button>
      </div>
    </Card>
  )
}
