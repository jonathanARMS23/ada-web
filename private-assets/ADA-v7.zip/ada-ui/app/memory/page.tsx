'use client'

import { useEffect, useMemo, useState } from 'react'
import { Icon } from '@/lib/icons'
import { Card } from '@/components/ada/Card'
import { StatusBadge } from '@/components/ada/StatusBadge'
import { DashboardError } from '@/components/dashboard/States'
import { MemoryGraph3D, MEMORY_TYPE_COLOR } from '@/components/memory/MemoryGraph3D'
import { Markdown } from '@/components/memory/Markdown'
import { TierBadge, toTier } from '@/components/ada/TierBadge'
import {
  useMemoryGraph,
  useMemoryWiki,
  usePipelineDetail,
  type WikiTopic,
  type MemoryGraph,
} from '@/hooks/use-memory'
import { useAgentDetail } from '@/hooks/use-agents'
import { useHealth } from '@/hooks/use-dashboard'

/**
 * Sélection du panneau droit. Deux sources distinctes et séparées :
 *  - `topic`  → contenu markdown INLINE d'un topic du wiki (/memory/wiki).
 *  - `node`   → détail réel d'une entité du graphe (agent / pipeline / phase).
 */
type Selection =
  | { kind: 'topic'; slug: string }
  | { kind: 'node'; id: string }
  | null

export default function MemoryPage() {
  const [search, setSearch] = useState('')
  const [selection, setSelection] = useState<Selection>(null)

  const graph = useMemoryGraph(200)
  const wiki = useMemoryWiki()
  const { data: health } = useHealth()
  const recallDegraded = health?.memory?.degraded === true

  const topics = useMemo(() => wiki.data ?? [], [wiki.data])
  const filteredTopics = useMemo(() => {
    const q = search.trim().toLowerCase()
    if (!q) return topics
    return topics.filter(
      (t) => t.topic.toLowerCase().includes(q) || t.domain.toLowerCase().includes(q),
    )
  }, [topics, search])

  // Sélection par défaut : premier topic du wiki (contenu inline réel).
  useEffect(() => {
    if (!selection && topics.length > 0) setSelection({ kind: 'topic', slug: topics[0].slug })
  }, [selection, topics])

  const nodeCount = graph.data?.nodes.length ?? 0

  return (
    <>
      <div className="page-head fade-up">
        <div>
          <h1>Memory</h1>
          <div className="sub">
            Topologie · {nodeCount.toLocaleString('fr-FR')} nœuds · {topics.length} topics wiki
            {recallDegraded ? ' · recall dégradé (TF-IDF)' : ''}
          </div>
        </div>
        <div className="page-head-actions">
          {recallDegraded && (
            <StatusBadge status="warning" label="Recall dégradé — Ollama indisponible (mode TF-IDF)" />
          )}
          <div className="field" style={{ width: 240 }}>
            <Icon name="search" />
            <input
              placeholder="Filtrer les topics…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              aria-label="Filtrer les topics"
            />
          </div>
        </div>
      </div>

      {graph.isError ? (
        <DashboardError onRetry={() => void graph.refetch()} />
      ) : (
        <div className="mem-layout fade-up">
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            {/* Topologie (graphe) */}
            <Card style={{ padding: 0, overflow: 'hidden' }}>
              <div className="graph-wrap">
                {graph.isLoading ? (
                  <div className="skel" style={{ width: '100%', height: '100%' }} aria-busy="true" />
                ) : nodeCount === 0 ? (
                  <div className="empty" style={{ height: '100%', justifyContent: 'center' }}>
                    <Icon name="memory" />
                    <b>Graphe vide</b>
                    <span>Aucune entité indexée.</span>
                  </div>
                ) : (
                  <MemoryGraph3D
                    graph={graph.data!}
                    onSelect={(id) => setSelection({ kind: 'node', id })}
                  />
                )}
                <div className="graph-legend">
                  <span><span className="lg-dot" style={{ background: MEMORY_TYPE_COLOR.agent }} />agent</span>
                  <span><span className="lg-dot" style={{ background: MEMORY_TYPE_COLOR.phase }} />phase</span>
                  <span><span className="lg-dot" style={{ background: MEMORY_TYPE_COLOR.pipeline }} />pipeline</span>
                </div>
              </div>
            </Card>

            {/* Notes / topics réels du wiki — cliquables */}
            <Card className="card-pad">
              <h4 className="wiki" style={{ margin: '0 0 10px', fontSize: 13, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '.06em' }}>
                Notes du wiki
              </h4>
              {wiki.isLoading ? (
                <div className="skel" style={{ height: 120 }} />
              ) : filteredTopics.length === 0 ? (
                <div className="empty" style={{ padding: '24px 12px' }}>
                  <Icon name="book" />
                  <span>{topics.length === 0 ? 'Aucune note dans le wiki.' : 'Aucun topic ne correspond au filtre.'}</span>
                </div>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                  {filteredTopics.map((t) => {
                    const active = selection?.kind === 'topic' && selection.slug === t.slug
                    return (
                      <button
                        key={t.slug}
                        type="button"
                        onClick={() => setSelection({ kind: 'topic', slug: t.slug })}
                        className={active ? 'topic-row on' : 'topic-row'}
                      >
                        <div style={{ minWidth: 0 }}>
                          <div className="t" style={{ fontSize: 13.5, fontWeight: 550, color: 'var(--fg)' }}>{t.topic}</div>
                          <div className="dim" style={{ fontSize: 11.5 }}>
                            {t.domain} · {t.sessionCount} sessions{t.lastUpdated ? ` · ${t.lastUpdated}` : ''}
                          </div>
                        </div>
                        <Icon name="chevron" style={{ width: 14, height: 14, flexShrink: 0, color: 'var(--faint)' }} />
                      </button>
                    )
                  })}
                </div>
              )}
            </Card>
          </div>

          {/* Panneau droit : topic markdown OU détail d'entité (jamais vide après sélection valide) */}
          <Card className="card-pad wiki" style={{ position: 'sticky', top: 70 }}>
            <DetailPanel selection={selection} topics={topics} graph={graph.data} />
          </Card>
        </div>
      )}
    </>
  )
}

function DetailPanel({
  selection,
  topics,
  graph,
}: {
  selection: Selection
  topics: WikiTopic[]
  graph: MemoryGraph | undefined
}) {
  if (!selection) {
    return (
      <div className="empty" style={{ padding: '32px 12px' }}>
        <Icon name="book" />
        <span>Sélectionnez une note ou un nœud du graphe.</span>
      </div>
    )
  }
  if (selection.kind === 'topic') {
    return <TopicDetail topic={topics.find((t) => t.slug === selection.slug) ?? null} />
  }
  return <NodeDetail id={selection.id} graph={graph} />
}

/** Topic wiki : titre + métadonnées réelles + content markdown inline. */
function TopicDetail({ topic }: { topic: WikiTopic | null }) {
  if (!topic) {
    return (
      <div className="empty" style={{ padding: '32px 12px' }}>
        <Icon name="book" />
        <span>Note introuvable.</span>
      </div>
    )
  }
  return (
    <>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <span className="lg-dot" style={{ background: 'var(--tier-sonnet)', width: 11, height: 11 }} />
        <h3 style={{ fontSize: 16 }}>{topic.topic}</h3>
      </div>
      <div style={{ display: 'flex', gap: 6, marginTop: 10, flexWrap: 'wrap' }}>
        <span className="tag">{topic.domain}</span>
        <span className="tag">{topic.sessionCount} sessions</span>
        {topic.lastUpdated && <span className="tag">{topic.lastUpdated}</span>}
        {topic.projects.map((p) => (
          <span key={p} className="tag">{p}</span>
        ))}
      </div>
      <hr className="sep-line" style={{ margin: '14px 0' }} />
      <Markdown content={topic.content} />
    </>
  )
}

/** Nœud topologie : dispatch selon le préfixe de l'id (agent: / pipeline: / phase:). */
function NodeDetail({ id, graph }: { id: string; graph: MemoryGraph | undefined }) {
  const [prefix, ...rest] = id.split(':')
  const name = rest.join(':')
  if (prefix === 'agent') return <AgentNodeDetail slug={name} />
  if (prefix === 'pipeline') return <PipelineNodeDetail name={name} />
  return <PhaseNodeDetail id={id} label={name} graph={graph} />
}

function AgentNodeDetail({ slug }: { slug: string }) {
  const { data, isLoading } = useAgentDetail(slug)
  if (isLoading) return <div className="skel" style={{ height: 160 }} />
  if (!data) {
    return <div className="dim" style={{ fontSize: 13 }}>Contenu indisponible pour l&apos;agent « {slug} ».</div>
  }
  const tier = toTier(data.tier) ?? 'sonnet'
  const runs = data.runs ?? 0
  const winPct = data.pWin != null ? Math.round(data.pWin * 100) : null
  return (
    <>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <span className="lg-dot" style={{ background: MEMORY_TYPE_COLOR.agent, width: 11, height: 11 }} />
        <h3 style={{ fontSize: 16 }}>{data.name ?? slug}</h3>
        <span style={{ marginLeft: 'auto' }}><TierBadge tier={tier} /></span>
      </div>
      <div className="dim" style={{ fontSize: 11.5, marginTop: 4 }}>Agent</div>
      <hr className="sep-line" style={{ margin: '14px 0' }} />
      <p style={{ fontSize: 13.5, color: 'var(--fg-dim)', lineHeight: 1.6, margin: 0 }}>
        {data.description?.trim() || '—'}
      </p>
      {data.role?.trim() ? (
        <div style={{ marginTop: 8, fontSize: 12.5 }}>
          <span className="dim">Rôle : </span>
          <span style={{ color: 'var(--fg-dim)' }}>{data.role}</span>
        </div>
      ) : null}
      <div style={{ display: 'flex', gap: 14, marginTop: 14, fontSize: 13 }}>
        <span><span className="dim">Runs : </span>{runs > 0 ? runs : 'Aucun run'}</span>
        {runs > 0 && winPct != null && <span><span className="dim">Win : </span>{winPct}%</span>}
      </div>
    </>
  )
}

function PipelineNodeDetail({ name }: { name: string }) {
  const { data, isLoading } = usePipelineDetail(name)
  if (isLoading) return <div className="skel" style={{ height: 160 }} />
  if (!data) {
    return <div className="dim" style={{ fontSize: 13 }}>Contenu indisponible pour le pipeline « {name} ».</div>
  }
  return (
    <>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <span className="lg-dot" style={{ background: MEMORY_TYPE_COLOR.pipeline, width: 11, height: 11 }} />
        <h3 style={{ fontSize: 16 }}>{data.name}</h3>
      </div>
      <div className="dim" style={{ fontSize: 11.5, marginTop: 4 }}>Pipeline</div>
      {data.description && (
        <p style={{ fontSize: 13, color: 'var(--fg-dim)', lineHeight: 1.6, marginTop: 10 }}>{data.description}</p>
      )}
      <hr className="sep-line" style={{ margin: '14px 0' }} />
      <h4>Phases ({data.phases.length})</h4>
      {data.phases.length === 0 ? (
        <span className="faint" style={{ fontSize: 13 }}>Aucune phase déclarée.</span>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          {data.phases.map((ph, i) => (
            <div
              key={ph.id}
              style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, padding: '6px 0', borderBottom: '1px solid var(--border)' }}
            >
              <span className="cell-mono dim" style={{ fontSize: 11, width: 18 }}>{i + 1}</span>
              <div style={{ minWidth: 0 }}>
                <div style={{ color: 'var(--fg)' }}>{ph.label ?? ph.id}</div>
                {ph.agent && <div className="dim mono" style={{ fontSize: 11 }}>{ph.agent}</div>}
              </div>
            </div>
          ))}
        </div>
      )}
    </>
  )
}

/** Phase : pas de fetch dédié — on dérive pipelines/agents depuis les edges du graphe. */
function PhaseNodeDetail({ id, label, graph }: { id: string; label: string; graph: MemoryGraph | undefined }) {
  const links = graph?.links ?? []
  const agents = new Set<string>()
  const pipelines = new Set<string>()
  const nextPhases = new Set<string>()
  const prevPhases = new Set<string>()
  for (const l of links) {
    if (l.target === id && l.source.startsWith('agent:')) agents.add(l.source.slice('agent:'.length))
    if (l.source === id && l.target.startsWith('agent:')) agents.add(l.target.slice('agent:'.length))
    if (l.target === id && l.source.startsWith('pipeline:')) pipelines.add(l.source.slice('pipeline:'.length))
    if (l.source === id && l.target.startsWith('pipeline:')) pipelines.add(l.target.slice('pipeline:'.length))
    if (l.source === id && l.target.startsWith('phase:')) nextPhases.add(l.target.slice('phase:'.length))
    if (l.target === id && l.source.startsWith('phase:')) prevPhases.add(l.source.slice('phase:'.length))
  }
  return (
    <>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <span className="lg-dot" style={{ background: MEMORY_TYPE_COLOR.phase, width: 11, height: 11 }} />
        <h3 style={{ fontSize: 16 }}>{label}</h3>
      </div>
      <div className="dim" style={{ fontSize: 11.5, marginTop: 4 }}>Phase</div>
      <hr className="sep-line" style={{ margin: '14px 0' }} />
      <EdgeList title="Agents associés" items={[...agents]} empty="Aucun agent associé dans le graphe." />
      <EdgeList title="Pipelines" items={[...pipelines]} empty="Aucun pipeline associé dans le graphe." />
      <EdgeList title="Phase précédente" items={[...prevPhases]} empty="—" />
      <EdgeList title="Phase suivante" items={[...nextPhases]} empty="—" />
    </>
  )
}

function EdgeList({ title, items, empty }: { title: string; items: string[]; empty: string }) {
  return (
    <div style={{ marginBottom: 12 }}>
      <h4 style={{ margin: '0 0 6px' }}>{title}</h4>
      {items.length > 0 ? (
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {items.map((i) => (
            <span key={i} className="chip">{i}</span>
          ))}
        </div>
      ) : (
        <span className="faint" style={{ fontSize: 13 }}>{empty}</span>
      )}
    </div>
  )
}
