'use client'

import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { ReactQueryDevtools } from '@tanstack/react-query-devtools'
import { ThemeProvider } from 'next-themes'
import { useState, useEffect } from 'react'
import { useAdaStore } from '@/store/ada-store'
import { useAdaAuth } from '@/hooks/use-ada-auth'
import { useAdaWs } from '@/hooks/use-ada-ws'

/**
 * Réhydrate le store persisté (profil/workspace actifs) côté client puis
 * démarre l'auth (mint JWT via ada-api-nest) et la connexion WebSocket live.
 * Le JWT reste en mémoire (exclu du partialize du store).
 */
function ConnectionManager() {
  useEffect(() => {
    try {
      ;(useAdaStore as { persist?: { rehydrate?: () => void } }).persist?.rehydrate?.()
    } catch {
      /* localStorage indisponible */
    }
  }, [])
  useAdaAuth()
  useAdaWs()
  return null
}

export function Providers({ children }: { children: React.ReactNode }) {
  const [queryClient] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: { staleTime: 30_000, retry: 1, refetchOnWindowFocus: false },
        },
      }),
  )

  return (
    <ThemeProvider
      attribute="data-theme"
      defaultTheme="dark"
      enableSystem={false}
      themes={['dark', 'light']}
      disableTransitionOnChange
    >
      <QueryClientProvider client={queryClient}>
        <ConnectionManager />
        {children}
        {process.env.NODE_ENV !== 'production' && <ReactQueryDevtools initialIsOpen={false} />}
      </QueryClientProvider>
    </ThemeProvider>
  )
}
