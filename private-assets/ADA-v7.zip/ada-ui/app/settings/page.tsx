'use client'

import { useEffect, useState } from 'react'
import { useTheme } from 'next-themes'
import { useShallow } from 'zustand/react/shallow'
import { cn } from '@/lib/utils'
import { Icon } from '@/lib/icons'
import { Card, CardHead } from '@/components/ada/Card'
import { Button } from '@/components/ada/Button'
import { StatusBadge } from '@/components/ada/StatusBadge'
import { TierBadge, toTier, Avatar } from '@/components/ada/TierBadge'
import { useAdaStore } from '@/store/ada-store'
import { useSettings, useUpdateSettings, type AdaSettings } from '@/hooks/use-settings'
import { useProfiles, useSwitchProfile, useCreateProfile } from '@/hooks/use-profiles'
import { useObsidianStatus, useToggleObsidian } from '@/hooks/use-obsidian'

const SECTIONS = [
  { id: 'providers', label: 'Providers' },
  { id: 'budget', label: 'Budget' },
  { id: 'obsidian', label: 'Obsidian' },
  { id: 'profiles', label: 'Profils' },
  { id: 'appearance', label: 'Apparence' },
]

function Switch({
  on,
  onToggle,
  ariaLabel = 'Basculer',
}: {
  on: boolean
  onToggle: () => void
  ariaLabel?: string
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      className={cn('sw', on && 'on')}
      onClick={onToggle}
      aria-label={ariaLabel}
    />
  )
}

export default function SettingsPage() {
  const settings = useSettings()
  const update = useUpdateSettings()
  const profiles = useProfiles()
  const switchProfile = useSwitchProfile()
  const createProfile = useCreateProfile()
  const obsStatus = useObsidianStatus()
  const toggleObsidian = useToggleObsidian()
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)
  const setActiveProfile = useAdaStore(useShallow((s) => s.setActiveProfile))

  const [draft, setDraft] = useState<AdaSettings>({})
  useEffect(() => setMounted(true), [])
  useEffect(() => {
    if (settings.data) setDraft(settings.data)
  }, [settings.data])

  const budget = draft.budget ?? {}
  const obsidian = draft.obsidian ?? {}
  const webhook = draft.webhook ?? {}

  function save() {
    void update.mutate({ provider: draft.provider, budget, obsidian, webhook })
  }

  async function onCreateProfile() {
    const name = window.prompt('Nom du nouveau profil ?')?.trim()
    if (!name) return
    await createProfile.mutateAsync({ name })
  }

  return (
    <>
      <div className="page-head fade-up">
        <div>
          <h1>Settings</h1>
          <div className="sub">Providers · budget · Obsidian · profils</div>
        </div>
        <Button variant="primary" onClick={save} disabled={update.isPending}>
          <Icon name="check" />
          {update.isPending ? 'Enregistrement…' : 'Enregistrer'}
        </Button>
      </div>

      <div className="set-layout fade-up">
        <nav className="set-nav" aria-label="Sections des réglages">
          {SECTIONS.map((s, i) => (
            <a key={s.id} href={`#${s.id}`} className={cn(i === 0 && 'on')}>
              {s.label}
            </a>
          ))}
        </nav>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
          {/* Providers */}
          <Card id="providers">
            <CardHead icon="bolt" title="Providers LLM" />
            <div className="set-row">
              <div>
                <div className="lbl">Anthropic</div>
                <div className="hint mono">claude-opus-4-8 · claude-sonnet-4-6 · claude-haiku-4-5</div>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <StatusBadge status={draft.provider ? 'success' : 'idle'} label="configuré" />
                <Switch
                  on={draft.provider === 'api' || draft.provider === 'claude-code' || !!draft.provider}
                  onToggle={() => setDraft((d) => ({ ...d, provider: d.provider ? undefined : 'claude-code' }))}
                  ariaLabel="Basculer le fournisseur"
                />
              </div>
            </div>
            <div className="set-row">
              <div>
                <div className="lbl">Mode provider</div>
                <div className="hint">claude-code (CLI local) ou api (clé directe)</div>
              </div>
              <div style={{ display: 'flex', gap: 6 }}>
                {(['claude-code', 'api'] as const).map((m) => (
                  <button key={m} className={cn('chip', draft.provider === m && 'on')} style={{ height: 28 }} onClick={() => setDraft((d) => ({ ...d, provider: m }))}>
                    {m}
                  </button>
                ))}
              </div>
            </div>
          </Card>

          {/* Budget */}
          <Card id="budget">
            <CardHead icon="shield" title="Budget Guard" />
            <BudgetRow label="Plafond journalier" hint="par workspace · alerte à 80%" value={budget.dailyLimit} onChange={(v) => setDraft((d) => ({ ...d, budget: { ...budget, dailyLimit: v } }))} />
            <BudgetRow label="Plafond mensuel" hint="tous workspaces confondus" value={budget.monthlyLimit} onChange={(v) => setDraft((d) => ({ ...d, budget: { ...budget, monthlyLimit: v } }))} />
            <BudgetRow label="Pic horaire max" hint="throttle automatique au dépassement" value={budget.hourlyLimit} onChange={(v) => setDraft((d) => ({ ...d, budget: { ...budget, hourlyLimit: v } }))} />
            <div className="set-row">
              <div>
                <div className="lbl">Bloquer au plafond</div>
                <div className="hint">stoppe les runs plutôt que d&apos;alerter seulement</div>
              </div>
              <Switch
                on={!!budget.blockAtCap}
                onToggle={() => setDraft((d) => ({ ...d, budget: { ...budget, blockAtCap: !budget.blockAtCap } }))}
                ariaLabel="Basculer le blocage au plafond"
              />
            </div>
          </Card>

          {/* Obsidian — statut live (GET /obsidian/status), pas seulement le
              formulaire de config : la synchro bascule immédiatement (POST),
              indépendamment du bouton Enregistrer plus bas. */}
          <Card id="obsidian">
            <CardHead
              icon="memory"
              title={
                <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  Obsidian
                  {obsStatus.data && (
                    <StatusBadge
                      status={obsStatus.data.enabled ? 'running' : 'idle'}
                      label={obsStatus.data.enabled ? 'Actif' : 'Inactif'}
                    />
                  )}
                </span>
              }
              sub="Journalisation des sessions"
            />
            <div className="set-row">
              <div>
                <div className="lbl">Synchronisation vault</div>
                <div className="hint">graphe mémoire ↔ markdown</div>
              </div>
              <Switch
                on={!!obsStatus.data?.enabled}
                onToggle={() => toggleObsidian.mutate(!obsStatus.data?.enabled)}
                ariaLabel="Basculer la synchronisation Obsidian"
              />
            </div>

            {obsStatus.data?.enabled && !obsStatus.data.initialized ? (
              <div className="set-row" style={{ flexDirection: 'column', alignItems: 'flex-start', gap: 6 }}>
                <span className="dim">Vault non initialisé</span>
                <code className="mono" style={{ fontSize: 12 }}>ada obsidian init --all</code>
              </div>
            ) : obsStatus.data?.enabled && obsStatus.data.initialized ? (
              <div className="set-row">
                <div>
                  <div className="lbl mono" style={{ fontSize: 12 }}>{obsStatus.data.vaultDir}</div>
                  <div className="hint">{obsStatus.data.sessionCount} sessions</div>
                </div>
                <a href={obsStatus.data.uri} className="btn-p" style={{ fontSize: 12, padding: '6px 12px' }}>
                  Ouvrir
                </a>
              </div>
            ) : null}

            <div className="set-row">
              <div className="lbl">Chemin du vault (override)</div>
              <input
                className="inp mono"
                value={obsidian.vaultPath ?? ''}
                onChange={(e) => setDraft((d) => ({ ...d, obsidian: { ...obsidian, vaultPath: e.target.value } }))}
                aria-label="Chemin du vault Obsidian"
              />
            </div>
          </Card>

          {/* Profils */}
          <Card id="profiles">
            <CardHead
              icon="agents"
              title="Profils"
              right={
                <Button size="sm" onClick={onCreateProfile} disabled={createProfile.isPending}>
                  <Icon name="plus" />
                  Nouveau
                </Button>
              }
            />
            {(profiles.data?.profiles ?? []).map((p) => {
              const active = p.id === profiles.data?.activeProfile
              const tier = toTier(p.tier)
              return (
                <div key={p.id} className="set-row">
                  <div style={{ display: 'flex', alignItems: 'center', gap: 11 }}>
                    <Avatar tier={tier ?? 'sonnet'} name={p.name} size="sm" />
                    <div>
                      <div className="lbl">{p.name}</div>
                      <div className="hint mono">~/.{p.id}</div>
                    </div>
                    {tier && <TierBadge tier={tier} />}
                  </div>
                  <Button
                    size="sm"
                    variant={active ? 'ghost' : 'primary'}
                    disabled={active || switchProfile.isPending}
                    onClick={async () => {
                      await switchProfile.mutateAsync(p.id)
                      setActiveProfile(p.id)
                    }}
                  >
                    {active ? 'Actif' : 'Basculer'}
                  </Button>
                </div>
              )
            })}
          </Card>

          {/* Apparence */}
          <Card id="appearance">
            <CardHead icon="sun" title="Apparence" />
            <div className="set-row">
              <div>
                <div className="lbl">Thème</div>
                <div className="hint">dark par défaut (OLED) · toggle aussi en haut à droite</div>
              </div>
              <div style={{ display: 'flex', gap: 6 }}>
                {(['dark', 'light'] as const).map((t) => (
                  <button
                    key={t}
                    className={cn('chip', mounted && theme === t && 'on')}
                    style={{ height: 28 }}
                    onClick={() => setTheme(t)}
                  >
                    {t === 'dark' ? 'Dark' : 'Light'}
                  </button>
                ))}
              </div>
            </div>
          </Card>
        </div>
      </div>
    </>
  )
}

function BudgetRow({
  label,
  hint,
  value,
  onChange,
}: {
  label: string
  hint: string
  value?: number
  onChange: (v: number) => void
}) {
  return (
    <div className="set-row">
      <div>
        <div className="lbl">{label}</div>
        <div className="hint">{hint}</div>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <span className="dim">$</span>
        <input
          className="inp mono"
          style={{ minWidth: 110, textAlign: 'right' }}
          type="number"
          value={value ?? ''}
          onChange={(e) => onChange(Number(e.target.value))}
          aria-label={label}
        />
      </div>
    </div>
  )
}
