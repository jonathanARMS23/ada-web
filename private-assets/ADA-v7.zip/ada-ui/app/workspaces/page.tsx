'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { useShallow } from 'zustand/react/shallow'
import { useAdaStore } from '@/store/ada-store'
import { Icon } from '@/lib/icons'
import { Button } from '@/components/ada/Button'
import { Card } from '@/components/ada/Card'
import { StatusBadge, toRunStatus } from '@/components/ada/StatusBadge'
import { DashboardError } from '@/components/dashboard/States'
import { WorkspaceTree } from '@/components/workspaces/WorkspaceTree'
import { StreamConsole } from '@/components/workspaces/StreamConsole'
import { useWorkspaces, useWorkspaceStats, useCreateWorkspace } from '@/hooks/use-workspaces'
import { useConversations, useCreateConversation, useMessages } from '@/hooks/use-conversations'
import { useSessionStream } from '@/hooks/use-session-stream'

export default function WorkspacesPage() {
  const { activeProfile, activeWorkspaceId, setActiveWorkspaceId } = useAdaStore(
    useShallow((s) => ({
      activeProfile: s.activeProfile,
      activeWorkspaceId: s.activeWorkspaceId,
      setActiveWorkspaceId: s.setActiveWorkspaceId,
    })),
  )
  const [filter, setFilter] = useState('')
  const [convId, setConvId] = useState<string | null>(null)
  const [instruction, setInstruction] = useState('')

  const workspaces = useWorkspaces()
  const conversations = useConversations(activeWorkspaceId)
  const messages = useMessages(convId)
  const stats = useWorkspaceStats(activeWorkspaceId)
  const createWs = useCreateWorkspace()
  const createConv = useCreateConversation()
  const stream = useSessionStream(activeProfile)

  const items = useMemo(() => workspaces.data?.items ?? [], [workspaces.data])
  const convs = useMemo(() => conversations.data?.items ?? [], [conversations.data])

  const { seedHistory } = stream
  const seededConvRef = useRef<string | null>(null)
  // true au tout premier message d'une conversation (déclenche launch vs follow-up).
  const startedSessionRef = useRef(false)

  useEffect(() => {
    if (!activeWorkspaceId && items.length > 0) setActiveWorkspaceId(items[0].id)
  }, [activeWorkspaceId, items, setActiveWorkspaceId])

  useEffect(() => {
    if (convs.length > 0 && !convs.some((c) => c.id === convId)) setConvId(convs[0].id)
    if (convs.length === 0) setConvId(null)
  }, [convs, convId])

  // À l'ouverture/changement de conversation : charger l'historique persistant
  // puis l'afficher AVANT de (re)prendre la session. Filtrage WS rattaché à convId.
  useEffect(() => {
    if (!convId) return
    if (messages.isLoading) return
    if (seededConvRef.current === convId) return
    const history = (messages.data?.items ?? []).map((m) => ({
      role: m.role,
      content: m.content,
      createdAt: m.createdAt,
    }))
    seedHistory(convId, history)
    seededConvRef.current = convId
    startedSessionRef.current = false
  }, [convId, messages.isLoading, messages.data, seedHistory])

  const filtered = useMemo(
    () => items.filter((w) => w.name.toLowerCase().includes(filter.toLowerCase())),
    [items, filter],
  )
  const activeConv = convs.find((c) => c.id === convId) ?? null

  async function onCreateWorkspace() {
    const name = window.prompt('Nom du projet ?')?.trim()
    if (!name) return
    const ws = await createWs.mutateAsync({ name, profile: activeProfile ?? undefined })
    setActiveWorkspaceId(ws.id)
  }

  async function onCreateConversation() {
    if (!activeWorkspaceId) return
    const title = window.prompt('Titre de la conversation ?')?.trim()
    const conv = await createConv.mutateAsync({ workspaceId: activeWorkspaceId, title: title || undefined })
    setConvId(conv.id)
  }

  function onLaunch() {
    const text = instruction.trim()
    if (!text || !activeWorkspaceId) return
    // Premier message d'une session → POST /sessions (crée ou reprend).
    // Messages suivants → task.message sur le WS (même session, mémoire continue).
    if (!startedSessionRef.current || !stream.sessionId) {
      void stream.launch(text, activeWorkspaceId, convId ?? undefined)
      startedSessionRef.current = true
    } else {
      stream.sendFollowUp(text)
    }
    setInstruction('')
  }

  return (
    <>
      <div className="page-head fade-up">
        <div>
          <h1>Workspaces</h1>
          <div className="sub">Projets · conversations · tâches temps réel</div>
        </div>
        <div className="page-head-actions">
          <div className="field" style={{ width: 220 }}>
            <Icon name="search" />
            <input
              placeholder="Filtrer les projets…"
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              aria-label="Filtrer les projets"
            />
          </div>
          <Button variant="primary" onClick={onCreateWorkspace} disabled={createWs.isPending}>
            <Icon name="plus" />
            Projet
          </Button>
        </div>
      </div>

      {workspaces.isLoading ? (
        <Card className="skel" style={{ height: 480, border: 'none' }} aria-busy="true" />
      ) : workspaces.isError ? (
        <DashboardError onRetry={() => void workspaces.refetch()} />
      ) : items.length === 0 ? (
        <Card className="fade-up">
          <div className="empty" style={{ padding: '64px 20px' }}>
            <Icon name="workspaces" />
            <b>Aucun projet</b>
            <span>Créez un premier projet pour lancer des tâches.</span>
            <Button variant="primary" size="sm" onClick={onCreateWorkspace} style={{ marginTop: 8 }}>
              <Icon name="plus" />
              Nouveau projet
            </Button>
          </div>
        </Card>
      ) : (
        <div className="ws-layout fade-up">
          <WorkspaceTree
            workspaces={filtered}
            conversations={convs}
            activeWorkspaceId={activeWorkspaceId}
            activeConversationId={convId}
            onSelectWorkspace={(id) => {
              setActiveWorkspaceId(id)
              setConvId(null)
              seededConvRef.current = null
              startedSessionRef.current = false
              stream.reset()
            }}
            onSelectConversation={(id) => {
              if (id === convId) return
              setConvId(id)
              // Le seed effect rechargera l'historique + reprendra la session.
              seededConvRef.current = null
              startedSessionRef.current = false
            }}
          />

          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <Card className="card-pad" style={{ display: 'flex', alignItems: 'center', gap: 14, flexWrap: 'wrap' }}>
              <div style={{ flex: 1, minWidth: 200 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
                  <h3 style={{ fontSize: 16 }}>
                    {activeConv ? `#${activeConv.title ?? activeConv.id.slice(0, 8)}` : 'Aucune conversation'}
                  </h3>
                  {(stream.metrics.status !== 'idle' || activeConv) && (
                    <StatusBadge status={stream.metrics.status !== 'idle' ? toRunStatus(stream.metrics.status) : 'idle'} />
                  )}
                </div>
                <div className="dim" style={{ fontSize: 12.5, marginTop: 3 }}>
                  {activeConv?.summary ??
                    (activeConv ? 'Lancez une instruction ci-dessous.' : 'Sélectionnez ou créez une conversation.')}
                </div>
              </div>
              <div style={{ display: 'flex', gap: 18 }}>
                <Metric label="Tokens" value={stream.metrics.tokens.toLocaleString('fr-FR')} />
                <Metric label="Coût" value={`$${stream.metrics.cost.toFixed(2)}`} accent="var(--st-warning)" />
                <Metric label="Conversations" value={String(stats.data?.conversations ?? convs.length)} />
              </div>
              <Button size="sm" onClick={onCreateConversation} disabled={!activeWorkspaceId || createConv.isPending}>
                <Icon name="plus" />
                Conversation
              </Button>
            </Card>

            <StreamConsole
              lines={stream.lines}
              metrics={stream.metrics}
              pendingPermission={stream.pendingPermission}
              onPermissionDecision={stream.respondPermission}
            />

            <Card className="card-pad" style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
              <div className="field" style={{ flex: 1 }}>
                <Icon name="play" />
                <input
                  placeholder={
                    stream.sessionId
                      ? 'Continuer la conversation…'
                      : activeConv
                        ? 'Nouvelle instruction…'
                        : 'Sélectionnez une conversation'
                  }
                  value={instruction}
                  onChange={(e) => setInstruction(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') onLaunch()
                  }}
                  disabled={!activeWorkspaceId || stream.launching}
                  aria-label="Message"
                />
              </div>
              <Button
                variant="primary"
                onClick={onLaunch}
                disabled={!instruction.trim() || !activeWorkspaceId || stream.launching}
              >
                <Icon name="bolt" />
                {stream.launching ? 'Lancement…' : stream.sessionId ? 'Envoyer' : 'Lancer'}
              </Button>
            </Card>

            {stream.error && (
              <div className="badge error" style={{ alignSelf: 'flex-start' }}>
                <Icon name="alert" />
                {stream.error}
              </div>
            )}
          </div>
        </div>
      )}
    </>
  )
}

function Metric({ label, value, accent }: { label: string; value: string; accent?: string }) {
  return (
    <div>
      <div className="faint" style={{ fontSize: 11 }}>
        {label}
      </div>
      <div className="cost" style={{ fontSize: 15, color: accent }}>
        {value}
      </div>
    </div>
  )
}
