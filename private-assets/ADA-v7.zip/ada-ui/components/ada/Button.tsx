import { forwardRef, type ButtonHTMLAttributes } from 'react'
import { cn } from '@/lib/utils'

type Variant = 'primary' | 'ghost'

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant
  size?: 'sm' | 'md'
}

/** Bouton fidèle au design (.btn / .btn-primary|ghost / .btn-sm). */
export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  { variant = 'ghost', size = 'md', className, type = 'button', ...props },
  ref,
) {
  return (
    <button
      ref={ref}
      type={type}
      className={cn('btn', variant === 'primary' ? 'btn-primary' : 'btn-ghost', size === 'sm' && 'btn-sm', className)}
      {...props}
    />
  )
})
