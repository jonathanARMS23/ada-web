import type { HTMLAttributes, ReactNode } from 'react'
import { cn } from '@/lib/utils'
import { Icon, type IconName } from '@/lib/icons'

export function Card({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn('card', className)} {...props} />
}

export function CardHead({
  icon,
  title,
  sub,
  right,
}: {
  icon?: IconName
  title: ReactNode
  sub?: ReactNode
  right?: ReactNode
}) {
  return (
    <div className="card-head">
      {icon && <Icon name={icon} />}
      <h3>{title}</h3>
      {sub && <span className="sub">{sub}</span>}
      {right && <span className="right">{right}</span>}
    </div>
  )
}

export function CardPad({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn('card-pad', className)} {...props} />
}
