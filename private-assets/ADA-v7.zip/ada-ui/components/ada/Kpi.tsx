import type { ReactNode } from 'react'
import { Icon, type IconName } from '@/lib/icons'
import { Card } from './Card'

/**
 * Carte KPI (.card.kpi) : icône colorée + label, valeur (avec unité optionnelle),
 * et pied (delta / badge / sparkline) en slot libre.
 */
export function Kpi({
  icon,
  iconColor,
  label,
  value,
  unit,
  foot,
}: {
  icon: IconName
  iconColor?: string
  label: ReactNode
  value: ReactNode
  unit?: ReactNode
  foot?: ReactNode
}) {
  return (
    <Card className="kpi">
      <div className="kpi-top">
        <span className="ic" style={iconColor ? { color: iconColor } : undefined}>
          <Icon name={icon} />
        </span>
        {label}
      </div>
      <div className="kpi-val num">
        {value}
        {unit && <small> {unit}</small>}
      </div>
      {foot && <div className="kpi-foot">{foot}</div>}
    </Card>
  )
}
