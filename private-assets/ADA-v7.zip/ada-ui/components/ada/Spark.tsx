/**
 * Mini sparkline SVG (fidèle au design dashboard.html). Trace une ligne + aire
 * remplie. `color` accepte une var CSS (ex: 'var(--st-success)').
 */
export function Spark({
  points,
  color = 'var(--primary)',
  width = 120,
  height = 30,
  className = 'spark',
}: {
  points: number[]
  color?: string
  width?: number
  height?: number
  className?: string
}) {
  if (points.length < 2) {
    return <svg className={className} viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none" aria-hidden="true" />
  }
  const max = Math.max(...points)
  const min = Math.min(...points)
  const span = max - min || 1
  const line = points
    .map((p, i) => {
      const x = (i / (points.length - 1)) * width
      const y = height - 3 - ((p - min) / span) * (height - 6)
      return `${i ? 'L' : 'M'}${x.toFixed(1)} ${y.toFixed(1)}`
    })
    .join(' ')
  return (
    <svg className={className} viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none" aria-hidden="true">
      <path d={line} fill="none" stroke={color} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" />
      <path d={`${line} L${width} ${height} L0 ${height} Z`} fill={color} opacity={0.08} />
    </svg>
  )
}
