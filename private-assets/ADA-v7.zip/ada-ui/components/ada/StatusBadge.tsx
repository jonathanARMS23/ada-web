import { Icon } from '@/lib/icons'
import { cn } from '@/lib/utils'

export type RunStatus = 'idle' | 'running' | 'success' | 'warning' | 'error' | 'paused'

/** Mappe les statuts ada-core (completed/failed/pending…) vers le vocabulaire visuel. */
export function toRunStatus(raw: string): RunStatus {
  switch (raw) {
    case 'completed':
    case 'success':
      return 'success'
    case 'running':
    case 'in_progress':
      return 'running'
    case 'failed':
    case 'error':
      return 'error'
    case 'paused':
      return 'paused'
    case 'pending':
    case 'queued':
    case 'warning':
      return 'warning'
    default:
      return 'idle'
  }
}

const LABEL: Record<RunStatus, string> = {
  idle: 'en file',
  running: 'en cours',
  success: 'succès',
  warning: 'en attente',
  error: 'échec',
  paused: 'en pause',
}

const ICON: Record<RunStatus, 'check' | 'x' | 'alert' | 'pause' | 'clock' | null> = {
  success: 'check',
  error: 'x',
  warning: 'alert',
  paused: 'pause',
  idle: 'clock',
  running: null, // pulse dot
}

/** Badge statut sémantique : couleur + icône (jamais couleur seule — a11y). */
export function StatusBadge({ status, label }: { status: RunStatus; label?: string }) {
  const icon = ICON[status]
  return (
    <span className={cn('badge', status)}>
      {status === 'running' ? (
        <span className="dot" aria-hidden="true" />
      ) : icon === 'pause' ? (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true">
          <path d="M7 4h3v16H7zM14 4h3v16h-3z" />
        </svg>
      ) : icon ? (
        <Icon name={icon} />
      ) : null}
      {label ?? LABEL[status]}
    </span>
  )
}
