import type { HTMLAttributes, TableHTMLAttributes } from 'react'
import { cn } from '@/lib/utils'

/** Table fidèle au design (.tbl / .tbl-compact). Wrappers sémantiques fins. */
export function Table({ compact, className, ...props }: TableHTMLAttributes<HTMLTableElement> & { compact?: boolean }) {
  return <table className={cn('tbl', compact && 'tbl-compact', className)} {...props} />
}

export function Meter({
  value,
  variant,
  className,
  ...props
}: { value: number; variant?: 'win' | 'budget' | 'over' } & HTMLAttributes<HTMLDivElement>) {
  const pct = Math.max(0, Math.min(100, value))
  return (
    <div
      className={cn('meter', variant, className)}
      role="progressbar"
      aria-valuenow={Math.round(pct)}
      aria-valuemin={0}
      aria-valuemax={100}
      {...props}
    >
      <i style={{ width: `${pct}%` }} />
    </div>
  )
}
