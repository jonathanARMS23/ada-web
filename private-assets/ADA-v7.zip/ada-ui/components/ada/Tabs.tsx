'use client'

import { cn } from '@/lib/utils'

export interface TabDef {
  id: string
  label: string
  count?: number
}

/** Onglets fidèles au design (.tabs / .tab / .tab.on). Contrôlé. */
export function Tabs({
  tabs,
  active,
  onChange,
}: {
  tabs: TabDef[]
  active: string
  onChange: (id: string) => void
}) {
  return (
    <div className="tabs fade-up" role="tablist">
      {tabs.map((t) => (
        <button
          key={t.id}
          role="tab"
          aria-selected={t.id === active}
          className={cn('tab', t.id === active && 'on')}
          onClick={() => onChange(t.id)}
        >
          {t.label}
          {t.count != null && <span className="dim"> {t.count}</span>}
        </button>
      ))}
    </div>
  )
}
