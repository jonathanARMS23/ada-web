import { cn } from '@/lib/utils'

export type Tier = 'haiku' | 'sonnet' | 'opus'

/** Normalise un identifiant de modèle/tier vers haiku|sonnet|opus, sinon null. */
export function toTier(raw?: string | null): Tier | null {
  if (!raw) return null
  const v = raw.toLowerCase()
  if (v.includes('haiku')) return 'haiku'
  if (v.includes('sonnet')) return 'sonnet'
  if (v.includes('opus')) return 'opus'
  return null
}

export function TierBadge({ tier, label }: { tier: Tier; label?: string }) {
  return <span className={cn('tier', tier)}>{label ?? tier}</span>
}

/** Avatar carré coloré par tier (initiale de l'agent). */
export function Avatar({ tier, name, size = 'sm' }: { tier: Tier; name: string; size?: 'sm' | 'md' | 'lg' }) {
  return (
    <span className={cn('avatar', size === 'md' ? '' : size, tier)} aria-hidden="true">
      {name.charAt(0).toUpperCase()}
    </span>
  )
}
