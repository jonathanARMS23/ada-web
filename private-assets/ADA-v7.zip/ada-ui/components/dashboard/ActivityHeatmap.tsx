'use client'

import { Card, CardHead } from '@/components/ada/Card'
import type { ActivityStats } from '@/hooks/use-dashboard'

const RAMP = ['#14161E', '#155E75', '#0E7490', '#F59E0B', '#EF4444']

/** Niveau 0..4 selon le nombre de runs du jour (échelle relative au max). */
function level(runs: number, max: number): number {
  if (runs <= 0 || max <= 0) return 0
  return Math.min(4, 1 + Math.floor((runs / max) * 4 * 0.999))
}

/** Heatmap d'activité (runs/jour) — fidèle à dashboard.html (grille 7 lignes). */
export function ActivityHeatmap({ data }: { data: ActivityStats }) {
  const max = data.buckets.reduce((m, b) => Math.max(m, b.runs), 0)
  const hasData = data.buckets.some((b) => b.runs > 0)

  return (
    <section className="card fade-up" style={{ marginBottom: 18 }}>
      <CardHead
        icon="activity"
        title={`Activité — ${data.days} derniers jours`}
        right={
          <span style={{ fontSize: 11, color: 'var(--muted)', display: 'flex', alignItems: 'center', gap: 8 }}>
            moins
            <span style={{ display: 'inline-flex', gap: 3 }} aria-hidden="true">
              {RAMP.map((c) => (
                <span key={c} style={{ width: 11, height: 11, borderRadius: 3, background: c }} />
              ))}
            </span>
            plus
          </span>
        }
      />
      <div className="card-pad" style={{ overflowX: 'auto' }}>
        {hasData ? (
          <div
            style={{
              display: 'grid',
              gridAutoFlow: 'column',
              gridTemplateRows: 'repeat(7, 12px)',
              gap: 3,
              width: 'max-content',
            }}
          >
            {data.buckets.map((b) => (
              <div
                key={b.day}
                title={`${b.day} · ${b.runs} run(s) · $${b.cost.toFixed(2)}`}
                style={{ width: 12, height: 12, borderRadius: 3, background: RAMP[level(b.runs, max)] }}
              />
            ))}
          </div>
        ) : (
          <div className="empty">
            <span>Aucune activité enregistrée sur la période.</span>
          </div>
        )}
      </div>
    </section>
  )
}
