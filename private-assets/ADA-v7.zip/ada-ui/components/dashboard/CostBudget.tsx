'use client'

import { Card, CardHead } from '@/components/ada/Card'
import { Meter } from '@/components/ada/Table'
import { StatusBadge } from '@/components/ada/StatusBadge'
import type { OverviewStats, BudgetStats } from '@/hooks/use-dashboard'

function fmtUsd(n: number): string {
  return `$${n.toFixed(2)}`
}
function fmtInt(n: number): string {
  return new Intl.NumberFormat('fr-FR').format(n)
}

interface BudgetLine {
  scope: string
  spent: number
  limit: number
}

/** Extrait des lignes de budget exploitables depuis le payload live (best-effort). */
function budgetLines(budget?: BudgetStats): BudgetLine[] {
  const out: BudgetLine[] = []
  const src = (budget?.config ?? budget?.check) as Record<string, unknown> | null | undefined
  if (!src) return out
  const limits = (src.limits ?? src.budgets) as Array<Record<string, unknown>> | undefined
  if (Array.isArray(limits)) {
    for (const l of limits) {
      const spent = Number(l.spent ?? l.used ?? 0)
      const limit = Number(l.limit ?? l.max ?? 0)
      if (limit > 0) out.push({ scope: String(l.scope ?? l.window ?? 'budget'), spent, limit })
    }
  }
  return out
}

/** Coût LLM cumulé (overview) + Budget Guard (budget live). États dégradés gérés. */
export function CostBudget({ overview, budget }: { overview: OverviewStats; budget?: BudgetStats }) {
  const lines = budgetLines(budget)
  const alert = lines.some((l) => l.spent / l.limit >= 0.79)

  return (
    <Card className="fade-up">
      <CardHead
        icon="cost"
        title="Coût LLM & Budget"
        right={alert ? <StatusBadge status="warning" label="alerte budget" /> : <span className="faint">aujourd'hui</span>}
      />
      <div className="card-pad" style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'flex-end',
            paddingBottom: 14,
            borderBottom: '1px solid var(--border-soft)',
          }}
        >
          <div>
            <div className="faint" style={{ fontSize: 11 }}>
              Tokens cumulés
            </div>
            <div className="cost" style={{ fontSize: 18, marginTop: 2 }}>
              {fmtInt(overview.totalTokens)}
            </div>
          </div>
          <div style={{ textAlign: 'right' }}>
            <div className="faint" style={{ fontSize: 11 }}>
              Coût cumulé
            </div>
            <div className="cost-lg" style={{ fontSize: 24 }}>
              {fmtUsd(overview.totalCost)}
            </div>
          </div>
        </div>

        {lines.length === 0 ? (
          <div className="dim" style={{ fontSize: 12.5 }}>
            {budget?.degraded ? 'Budget Guard indisponible (Control Server hors ligne).' : 'Aucune limite de budget configurée.'}
          </div>
        ) : (
          lines.map((l) => {
            const pct = (l.spent / l.limit) * 100
            const variant = pct >= 100 ? 'over' : 'budget'
            return (
              <div key={l.scope}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, marginBottom: 6 }}>
                  <span className="dim">{l.scope}</span>
                  <span className="cost">
                    <b style={{ color: pct >= 100 ? 'var(--st-error)' : pct >= 79 ? 'var(--st-warning)' : 'var(--fg)' }}>
                      {fmtUsd(l.spent)}
                    </b>{' '}
                    / {fmtUsd(l.limit)}
                  </span>
                </div>
                <Meter value={pct} variant={variant} style={{ height: 8 }} />
              </div>
            )
          })
        )}
      </div>
    </Card>
  )
}
