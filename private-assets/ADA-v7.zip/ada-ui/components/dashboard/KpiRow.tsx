'use client'

import { Kpi } from '@/components/ada/Kpi'
import { Spark } from '@/components/ada/Spark'
import { StatusBadge } from '@/components/ada/StatusBadge'
import type { OverviewStats, RouterStats } from '@/hooks/use-dashboard'

function fmtInt(n: number): string {
  return new Intl.NumberFormat('fr-FR').format(n)
}

/** Rangée de 4 KPI (runs, taux de succès, agents actifs, maj routeur). */
export function KpiRow({
  overview,
  router,
  successTrend,
}: {
  overview: OverviewStats
  router?: RouterStats
  successTrend: number[]
}) {
  const successPct = (overview.successRate * 100).toFixed(1).replace('.', ',')
  const agentCount = router?.agents?.length
  const resamples = router?.resamples

  return (
    <section className="bento cols-4 fade-up" style={{ marginBottom: 14 }}>
      <Kpi
        icon="activity"
        iconColor="var(--primary)"
        label="Runs"
        value={fmtInt(overview.totalRuns)}
        foot={<span className="dim">{overview.source === 'postgres' ? 'depuis Postgres' : 'mode live'}</span>}
      />
      <Kpi
        icon="check"
        iconColor="var(--st-success)"
        label="Taux de succès"
        value={successPct}
        unit="%"
        foot={successTrend.length >= 2 ? <Spark points={successTrend} color="var(--st-success)" /> : undefined}
      />
      <Kpi
        icon="agents"
        iconColor="var(--st-running)"
        label="Agents actifs"
        value={fmtInt(overview.activeRuns)}
        unit={agentCount ? `/ ${agentCount}` : undefined}
        foot={
          overview.activeRuns > 0 ? (
            <StatusBadge status="running" label={`${overview.activeRuns} en exécution`} />
          ) : (
            <span className="dim">aucun run actif</span>
          )
        }
      />
      <Kpi
        icon="bolt"
        iconColor="var(--tier-opus)"
        label="Routeur · maj"
        value={resamples != null ? fmtInt(resamples) : '—'}
        foot={<span className="dim">Thompson sampling</span>}
      />
    </section>
  )
}
