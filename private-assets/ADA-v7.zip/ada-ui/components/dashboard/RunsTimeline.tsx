'use client'

import { Card, CardHead } from '@/components/ada/Card'
import { StatusBadge, toRunStatus } from '@/components/ada/StatusBadge'
import { TierBadge, toTier } from '@/components/ada/TierBadge'
import type { TimelineItem } from '@/hooks/use-dashboard'

function timeago(iso: string | null): string {
  if (!iso) return '—'
  const diff = Date.now() - new Date(iso).getTime()
  const s = Math.floor(diff / 1000)
  if (s < 60) return `${s} s`
  const m = Math.floor(s / 60)
  if (m < 60) return `${m} min`
  const h = Math.floor(m / 60)
  if (h < 24) return `${h} h`
  return `${Math.floor(h / 24)} j`
}

/** Tier dominant d'un run = celui de sa première phase identifiable. */
function runTier(item: TimelineItem): 'haiku' | 'sonnet' | 'opus' | null {
  for (const p of item.phases) {
    const t = toTier(p.agent)
    if (t) return t
  }
  return null
}

/** Liste des runs récents (lrow) — fidèle à dashboard.html "Runs récents". */
export function RunsTimeline({ items }: { items: TimelineItem[] }) {
  return (
    <Card>
      <CardHead icon="clock" title="Runs récents" right={<span className="faint">{items.length}</span>} />
      {items.length === 0 ? (
        <div className="empty">
          <span>Aucun run récent.</span>
        </div>
      ) : (
        <div>
          {items.map((r) => {
            const tier = runTier(r)
            return (
              <div key={r.runId} className="lrow">
                <StatusBadge status={toRunStatus(r.status)} label="" />
                <div className="grow">
                  <div className="t">{r.name ?? r.pipeline}</div>
                  <div className="s">{tier ? <TierBadge tier={tier} /> : <span className="faint">{r.pipeline}</span>}</div>
                </div>
                <span className="timeago">{timeago(r.completedAt ?? r.startedAt)}</span>
              </div>
            )
          })}
        </div>
      )}
    </Card>
  )
}
