'use client'

import { Icon } from '@/lib/icons'
import { Button } from '@/components/ada/Button'

/** Bloc squelette générique (shimmer) à hauteur paramétrable. */
export function SkeletonCard({ height = 120 }: { height?: number }) {
  return <div className="card skel" style={{ height, border: 'none' }} aria-hidden="true" />
}

export function DashboardSkeleton() {
  return (
    <div aria-busy="true" aria-label="Chargement du dashboard">
      <section className="bento cols-4" style={{ marginBottom: 14 }}>
        {Array.from({ length: 4 }).map((_, i) => (
          <SkeletonCard key={i} height={110} />
        ))}
      </section>
      <section className="bento gap-lg" style={{ gridTemplateColumns: '1fr 1.35fr', marginBottom: 18 }}>
        <SkeletonCard height={220} />
        <SkeletonCard height={220} />
      </section>
      <SkeletonCard height={160} />
    </div>
  )
}

/** État d'erreur global avec action de réessai. */
export function DashboardError({ onRetry }: { onRetry: () => void }) {
  return (
    <div className="card">
      <div className="empty">
        <Icon name="alert" />
        <b>Impossible de charger le dashboard</b>
        <span>ada-api-nest est-il démarré sur le port configuré&nbsp;?</span>
        <Button variant="primary" size="sm" onClick={onRetry} style={{ marginTop: 8 }}>
          <Icon name="refresh" />
          Réessayer
        </Button>
      </div>
    </div>
  )
}
