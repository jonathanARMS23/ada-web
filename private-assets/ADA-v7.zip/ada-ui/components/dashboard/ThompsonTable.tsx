'use client'

import { Card, CardHead } from '@/components/ada/Card'
import { Table, Meter } from '@/components/ada/Table'
import { Avatar, toTier } from '@/components/ada/TierBadge'
import type { RouterStats, OverviewStats } from '@/hooks/use-dashboard'

interface Row {
  agent: string
  runs: number
  winRate: number // 0..1
  tier: 'haiku' | 'sonnet' | 'opus'
}

/**
 * Construit les lignes Thompson depuis router.stats si disponible, sinon
 * dégrade sur overview.topAgents (sans win rate). Garantit un rendu utile même
 * quand le Control Server ne renvoie pas les priors.
 */
function buildRows(router?: RouterStats, overview?: OverviewStats): Row[] {
  if (router?.agents?.length) {
    return router.agents
      .map((a) => {
        const win =
          typeof a.winRate === 'number'
            ? a.winRate
            : typeof a.alpha === 'number' && typeof a.beta === 'number' && a.alpha + a.beta > 0
              ? a.alpha / (a.alpha + a.beta)
              : 0
        return { agent: a.agent, runs: a.runs ?? 0, winRate: win, tier: toTier(a.tier) ?? 'sonnet' }
      })
      .sort((a, b) => b.winRate - a.winRate)
  }
  return (overview?.topAgents ?? []).map((a) => ({ agent: a.agent, runs: a.runs, winRate: 0, tier: 'sonnet' as const }))
}

export function ThompsonTable({ router, overview }: { router?: RouterStats; overview?: OverviewStats }) {
  const rows = buildRows(router, overview)

  return (
    <Card>
      <CardHead icon="chart" title="Thompson Sampling" right={<span className="faint">priors agents</span>} />
      <div style={{ maxHeight: 320, overflowY: 'auto' }}>
        {rows.length === 0 ? (
          <div className="empty">
            <span>Aucune statistique de routeur disponible.</span>
          </div>
        ) : (
          <Table compact>
            <thead>
              <tr>
                <th>Agent</th>
                <th className="r">Runs</th>
                <th style={{ width: 120 }}>Win rate</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => {
                const pct = Math.round(r.winRate * 100)
                return (
                  <tr key={r.agent}>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <Avatar tier={r.tier} name={r.agent} size="sm" />
                        <span className="cell-strong" style={{ fontSize: 12.5 }}>
                          {r.agent}
                        </span>
                      </div>
                    </td>
                    <td className="r cell-mono dim">{r.runs}</td>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <Meter value={pct} variant="win" style={{ flex: 1 }} />
                        <span className="cell-mono" style={{ fontSize: 11.5, width: 30, textAlign: 'right' }}>
                          {pct}%
                        </span>
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </Table>
        )}
      </div>
    </Card>
  )
}
