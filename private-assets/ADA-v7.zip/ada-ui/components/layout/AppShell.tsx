'use client'

import { useCallback, useEffect, useState } from 'react'
import { Sidebar } from './Sidebar'
import { Topbar } from './Topbar'

const COLLAPSE_KEY = 'ada-collapsed'

/**
 * Coquille applicative (.app-shell) : sidebar sticky + main (topbar + contenu),
 * fidèle à dashboard.html. L'état replié est persisté en localStorage comme
 * dans le prototype (js/ada.js toggleCollapse).
 */
export function AppShell({ children }: { children: React.ReactNode }) {
  const [collapsed, setCollapsed] = useState(false)

  useEffect(() => {
    try {
      setCollapsed(localStorage.getItem(COLLAPSE_KEY) === '1')
    } catch {
      /* localStorage indisponible */
    }
  }, [])

  const toggle = useCallback(() => {
    setCollapsed((c) => {
      const next = !c
      try {
        localStorage.setItem(COLLAPSE_KEY, next ? '1' : '0')
      } catch {
        /* ignore */
      }
      return next
    })
  }, [])

  return (
    <div className="app-shell">
      <Sidebar collapsed={collapsed} />
      <div className="app-main">
        <Topbar onToggleCollapse={toggle} />
        <main className="content">{children}</main>
      </div>
    </div>
  )
}
