import { Card } from '@/components/ada/Card'
import { Icon, type IconName } from '@/lib/icons'

/**
 * Page placeholder fidèle au shell (page-head + état vide stylé) pour les routes
 * de la sidebar pas encore migrées. Remplacées en UI-P1→P8 par les vraies pages.
 */
export function PlaceholderPage({
  title,
  subtitle,
  icon,
  phase,
}: {
  title: string
  subtitle: string
  icon: IconName
  phase: string
}) {
  return (
    <>
      <div className="page-head fade-up">
        <div>
          <h1>{title}</h1>
          <div className="sub">{subtitle}</div>
        </div>
      </div>
      <Card className="fade-up">
        <div className="empty" style={{ padding: '64px 20px' }}>
          <Icon name={icon} />
          <b>{phase} — à venir</b>
          <span>Cette section sera câblée à ada-api-nest dans une prochaine phase de la refonte.</span>
        </div>
      </Card>
    </>
  )
}
