'use client'

import { useEffect, useState } from 'react'
import { useShallow } from 'zustand/react/shallow'
import { useAdaStore } from '@/store/ada-store'
import { useProfiles, useSwitchProfile } from '@/hooks/use-profiles'
import { TierBadge, toTier, Avatar } from '@/components/ada/TierBadge'
import { StatusBadge } from '@/components/ada/StatusBadge'
import { Button } from '@/components/ada/Button'
import { Drawer } from '@/components/ada/Drawer'

const STATUS_COLOR: Record<string, string> = {
  running: 'var(--st-running)',
  idle: 'var(--st-idle)',
  success: 'var(--st-success)',
  warning: 'var(--st-warning)',
  error: 'var(--st-error)',
  paused: 'var(--st-paused)',
}

/**
 * Carte profil en pied de sidebar : affiche le profil actif (tier/santé) et
 * ouvre un drawer de bascule de profil (PUT /profiles/active via useSwitchProfile).
 */
export function ProfileCard() {
  const { activeProfile, setActiveProfile } = useAdaStore(
    useShallow((s) => ({ activeProfile: s.activeProfile, setActiveProfile: s.setActiveProfile })),
  )
  const { data } = useProfiles()
  const switchProfile = useSwitchProfile()
  const [open, setOpen] = useState(false)

  // Aligne le profil actif du store sur celui annoncé par l'API au premier chargement.
  useEffect(() => {
    if (data?.activeProfile && data.activeProfile !== activeProfile) {
      setActiveProfile(data.activeProfile)
    }
  }, [data?.activeProfile, activeProfile, setActiveProfile])

  const currentId = activeProfile ?? data?.activeProfile ?? null
  const current = data?.profiles.find((p) => p.id === currentId) ?? data?.profiles[0]
  const name = current?.name ?? activeProfile ?? '—'
  const tier = toTier(current?.tier)
  const health = current?.health ?? 'idle'

  return (
    <>
      <button className="profile-card" title={`Profil ${name}`} onClick={() => setOpen(true)}>
        <span className="profile-dot" aria-hidden="true">
          ◐
        </span>
        <span className="profile-meta">
          <b>{name}</b>
          <span className="row">
            {tier && <TierBadge tier={tier} />}
            <span style={{ color: STATUS_COLOR[health] ?? 'var(--st-idle)' }} aria-hidden="true">
              ●
            </span>
          </span>
        </span>
      </button>

      <Drawer open={open} title="Profils" onClose={() => setOpen(false)}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {(data?.profiles ?? []).map((p) => {
            const active = p.id === currentId
            const pt = toTier(p.tier)
            return (
              <div key={p.id} className="card card-pad" style={{ display: 'flex', alignItems: 'center', gap: 11 }}>
                <Avatar tier={pt ?? 'sonnet'} name={p.name} size="sm" />
                <div style={{ flex: 1 }}>
                  <b style={{ fontSize: 13 }}>{p.name}</b>
                  <div className="dim mono" style={{ fontSize: 11 }}>
                    ~/.{p.id}
                  </div>
                </div>
                {active ? (
                  <StatusBadge status="running" label="actif" />
                ) : (
                  <Button
                    size="sm"
                    variant="primary"
                    disabled={switchProfile.isPending}
                    onClick={async () => {
                      await switchProfile.mutateAsync(p.id)
                      setActiveProfile(p.id)
                      setOpen(false)
                    }}
                  >
                    Basculer
                  </Button>
                )}
              </div>
            )
          })}
        </div>
      </Drawer>
    </>
  )
}
