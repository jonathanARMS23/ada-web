'use client'

import Link from 'next/link'
import Image from 'next/image'
import { usePathname } from 'next/navigation'
import { cn } from '@/lib/utils'
import { Icon, type IconName } from '@/lib/icons'
import { ProfileCard } from './ProfileCard'

interface NavItem {
  href: string
  label: string
  icon: IconName
  badge?: string
}

/** Navigation portée depuis docs/design/export/js/ada.js (NAV) → routes App Router. */
const NAV: NavItem[] = [
  { href: '/dashboard', label: 'Dashboard', icon: 'dashboard' },
  { href: '/workspaces', label: 'Workspaces', icon: 'workspaces' },
  { href: '/agents', label: 'Agents', icon: 'agents' },
  { href: '/memory', label: 'Memory', icon: 'memory' },
  { href: '/mcp', label: 'MCP', icon: 'mcp' },
  { href: '/logs', label: 'Logs', icon: 'logs' },
  { href: '/settings', label: 'Settings', icon: 'settings' },
]

export function Sidebar({ collapsed }: { collapsed: boolean }) {
  const pathname = usePathname()

  return (
    <aside className={cn('sidebar', collapsed && 'collapsed')} id="sidebar">
      <div className="brand">
        <div className="brand-mark" aria-hidden="true">
          <Image src="/ada-logo.png" alt="ADA" fill style={{ objectFit: 'cover', objectPosition: 'center' }} priority />
        </div>
        <div className="brand-text">
          <b>ADA</b>
          <span>Orchestrator</span>
        </div>
      </div>

      <nav className="nav" aria-label="Navigation principale">
        {NAV.map((n) => {
          const active = pathname === n.href || pathname.startsWith(`${n.href}/`)
          return (
            <Link
              key={n.href}
              href={n.href}
              className={cn('nav-item', active && 'active')}
              title={n.label}
              aria-current={active ? 'page' : undefined}
            >
              <Icon name={n.icon} />
              <span className="nav-label">{n.label}</span>
              {n.badge && <span className="nav-badge">{n.badge}</span>}
            </Link>
          )
        })}
      </nav>

      <div className="sidebar-foot">
        <ProfileCard />
        <a
          href="https://byarms.com"
          className="byarms-foot"
          target="_blank"
          rel="noreferrer"
          title="Powered by ByARMS"
        >
          <div className="byarms-foot-logo">
            <Image src="/byarms-logo.png" alt="ByARMS" fill style={{ objectFit: 'cover', objectPosition: 'center' }} />
          </div>
          <span className="byarms-foot-text">
            <span className="byarms-foot-label">Powered by</span>
            <span className="byarms-foot-name">ByARMS</span>
          </span>
        </a>
      </div>
    </aside>
  )
}
