'use client'

import { useTheme } from 'next-themes'
import { useEffect, useState } from 'react'
import { Icon } from '@/lib/icons'

/** Bascule dark/light persistante (next-themes, attribut data-theme). */
export function ThemeToggle() {
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)
  useEffect(() => setMounted(true), [])

  const isLight = mounted && theme === 'light'
  return (
    <button
      className="icon-btn"
      title="Basculer le thème"
      aria-label="Basculer le thème"
      onClick={() => setTheme(isLight ? 'dark' : 'light')}
    >
      {/* Avant montage : icône neutre pour éviter le mismatch SSR */}
      <Icon name={isLight ? 'moon' : 'sun'} />
    </button>
  )
}
