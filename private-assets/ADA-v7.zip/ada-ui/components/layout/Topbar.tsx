'use client'

import { usePathname } from 'next/navigation'
import { useShallow } from 'zustand/react/shallow'
import { Icon } from '@/lib/icons'
import { useAdaStore } from '@/store/ada-store'
import { useHealth } from '@/hooks/use-dashboard'
import { ThemeToggle } from './ThemeToggle'

const LABELS: Record<string, string> = {
  dashboard: 'Dashboard',
  workspaces: 'Workspaces',
  agents: 'Agents',
  memory: 'Memory',
  mcp: 'MCP',
  logs: 'Logs',
  settings: 'Settings',
}

function crumbs(pathname: string): string[] {
  const segs = pathname.split('/').filter(Boolean)
  if (segs.length === 0) return ['Dashboard']
  return segs.map((s) => LABELS[s] ?? s.charAt(0).toUpperCase() + s.slice(1))
}

/**
 * Topbar (54px) : bouton collapse, breadcrumb, déclencheur palette (visuel P0),
 * pilule de santé (daemon) reflétant /health + la connexion WS, toggle thème.
 */
export function Topbar({ onToggleCollapse }: { onToggleCollapse: () => void }) {
  const pathname = usePathname()
  const parts = crumbs(pathname)
  const { wsConnected } = useAdaStore(useShallow((s) => ({ wsConnected: s.adaApiConnected })))
  const { data: health } = useHealth()

  const online = wsConnected || health?.status === 'ok'
  // Recall mémoire en mode TF-IDF (Ollama down) : avertissement informatif, pas une panne.
  const recallDegraded = online && health?.memory?.degraded === true
  const pillClass = !online ? 'health-pill offline' : recallDegraded ? 'health-pill degraded' : 'health-pill'

  return (
    <header className="topbar">
      <button className="icon-btn" title="Replier la barre latérale" aria-label="Replier la barre latérale" onClick={onToggleCollapse}>
        <Icon name="sidebar" />
      </button>

      <nav className="crumb" aria-label="Fil d'Ariane">
        {parts.map((c, i) => {
          const last = i === parts.length - 1
          return (
            <span key={`${c}-${i}`} className="crumb-item">
              {i > 0 && (
                <span className="sep" aria-hidden="true">
                  <Icon name="chevron" style={{ width: 14, height: 14, display: 'inline' }} />
                </span>
              )}
              {last ? <b>{c}</b> : c}
            </span>
          )
        })}
      </nav>

      <div className="topbar-spacer" />

      <button className="cmdk-trigger" type="button" aria-label="Rechercher ou exécuter">
        <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <Icon name="search" />
          <span className="label">Rechercher ou exécuter…</span>
        </span>
        <kbd>⌘K</kbd>
      </button>

      <div
        className={pillClass}
        role="status"
        aria-live="polite"
        title={recallDegraded ? 'Recall mémoire dégradé — Ollama indisponible (mode TF-IDF)' : undefined}
      >
        <span className="pulse" aria-hidden="true" />
        {!online ? 'hors ligne' : recallDegraded ? 'recall dégradé' : 'daemon'}
      </div>

      <ThemeToggle />
    </header>
  )
}
