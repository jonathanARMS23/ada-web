'use client'

import { type ReactNode } from 'react'

/**
 * Rendu markdown minimal, sans dépendance (aucune lib markdown dans le projet).
 * Couvre ce qu'écrit le wiki mémoire : frontmatter YAML (strippé), titres,
 * listes, gras, code inline, séparateurs et paragraphes. Pas de HTML injecté
 * (on ne rend que du texte via React → pas de risque XSS).
 */

/** Retire le bloc frontmatter YAML en tête (--- … ---) s'il existe. */
function stripFrontmatter(md: string): string {
  if (!md.startsWith('---')) return md
  const end = md.indexOf('\n---', 3)
  if (end === -1) return md
  const after = md.indexOf('\n', end + 1)
  return after === -1 ? '' : md.slice(after + 1)
}

/** Rendu inline : **gras** et `code`. Retourne des fragments React. */
function renderInline(text: string, keyBase: string): ReactNode[] {
  const out: ReactNode[] = []
  // Découpe sur **…** et `…` en conservant les délimiteurs.
  const tokens = text.split(/(\*\*[^*]+\*\*|`[^`]+`)/g)
  tokens.forEach((tok, i) => {
    if (!tok) return
    const key = `${keyBase}-${i}`
    if (tok.startsWith('**') && tok.endsWith('**')) {
      out.push(<strong key={key}>{tok.slice(2, -2)}</strong>)
    } else if (tok.startsWith('`') && tok.endsWith('`')) {
      out.push(
        <code key={key} style={{ fontFamily: 'var(--font-mono)', fontSize: '0.92em' }}>
          {tok.slice(1, -1)}
        </code>,
      )
    } else {
      out.push(<span key={key}>{tok}</span>)
    }
  })
  return out
}

export function Markdown({ content }: { content: string }) {
  const body = stripFrontmatter(content).trim()
  if (!body) {
    return <p style={{ fontSize: 13.5, color: 'var(--muted)' }}>Contenu indisponible.</p>
  }

  const lines = body.split('\n')
  const blocks: ReactNode[] = []
  let list: string[] = []
  let para: string[] = []
  let inFence = false
  let fence: string[] = []

  const flushList = (k: string) => {
    if (list.length === 0) return
    const items = list
    list = []
    blocks.push(
      <ul key={`ul-${k}`} style={{ margin: '6px 0 10px', paddingLeft: 18, fontSize: 13.5, lineHeight: 1.6, color: 'var(--fg-dim)' }}>
        {items.map((it, i) => (
          <li key={i} style={{ marginBottom: 3 }}>{renderInline(it, `li-${k}-${i}`)}</li>
        ))}
      </ul>,
    )
  }
  const flushPara = (k: string) => {
    if (para.length === 0) return
    const txt = para.join(' ')
    para = []
    blocks.push(
      <p key={`p-${k}`} style={{ fontSize: 13.5, color: 'var(--fg-dim)', lineHeight: 1.65, margin: '0 0 10px' }}>
        {renderInline(txt, `p-${k}`)}
      </p>,
    )
  }

  lines.forEach((rawLine, idx) => {
    const line = rawLine.replace(/\s+$/, '')
    const k = String(idx)

    if (line.startsWith('```')) {
      if (inFence) {
        const code = fence.join('\n')
        fence = []
        inFence = false
        blocks.push(
          <pre
            key={`pre-${k}`}
            style={{
              fontFamily: 'var(--font-mono)',
              fontSize: 12,
              background: 'var(--muted-bg)',
              padding: '10px 12px',
              borderRadius: 8,
              overflowX: 'auto',
              margin: '0 0 10px',
            }}
          >
            <code>{code}</code>
          </pre>,
        )
      } else {
        flushPara(k)
        flushList(k)
        inFence = true
      }
      return
    }
    if (inFence) {
      fence.push(rawLine)
      return
    }

    const h = /^(#{1,4})\s+(.*)$/.exec(line)
    if (h) {
      flushPara(k)
      flushList(k)
      const level = h[1].length
      const size = level === 1 ? 17 : level === 2 ? 15 : 13.5
      blocks.push(
        <div
          key={`h-${k}`}
          style={{
            fontSize: size,
            fontWeight: 650,
            color: 'var(--fg)',
            margin: level <= 2 ? '14px 0 8px' : '12px 0 6px',
          }}
        >
          {renderInline(h[2], `h-${k}`)}
        </div>,
      )
      return
    }

    if (/^(\s*[-*]\s+)/.test(line)) {
      flushPara(k)
      list.push(line.replace(/^\s*[-*]\s+/, ''))
      return
    }

    if (/^(---|___|\*\*\*)\s*$/.test(line)) {
      flushPara(k)
      flushList(k)
      blocks.push(<hr key={`hr-${k}`} className="sep-line" style={{ margin: '12px 0' }} />)
      return
    }

    if (line.trim() === '') {
      flushPara(k)
      flushList(k)
      return
    }

    para.push(line)
  })

  flushList('end')
  flushPara('end')

  return <div className="mem-md">{blocks}</div>
}
