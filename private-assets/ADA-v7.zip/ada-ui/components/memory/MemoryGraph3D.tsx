'use client'

import dynamic from 'next/dynamic'
import { useEffect, useMemo, useRef, useState, type ComponentType } from 'react'
import type { MemoryGraph, MemoryNode } from '@/hooks/use-memory'

/**
 * Props que l'on transmet à react-force-graph-3d. On type le composant
 * dynamiquement importé de façon permissive (sans `any`) car next/dynamic
 * efface les génériques de la lib ; les accesseurs reçoivent nos nœuds.
 *
 * `width`/`height` sont CRITIQUES : sans elles, la lib se cale sur
 * window.innerWidth/innerHeight → le <canvas> déborde de sa colonne et
 * provoque un scroll horizontal. On les borne au conteneur mesuré.
 */
interface ForceGraphProps {
  graphData: { nodes: MemoryNode[]; links: Array<{ source: string; target: string }> }
  width?: number
  height?: number
  backgroundColor?: string
  nodeLabel?: (n: MemoryNode) => string
  nodeColor?: (n: MemoryNode) => string
  nodeRelSize?: number
  nodeVal?: (n: MemoryNode) => number
  linkColor?: () => string
  linkWidth?: number
  onNodeClick?: (n: MemoryNode) => void
  showNavInfo?: boolean
}

// WebGL/three → client only (pas de SSR). Cast permissif typé sur nos props.
const ForceGraph3D = dynamic(() => import('react-force-graph-3d'), {
  ssr: false,
}) as unknown as ComponentType<ForceGraphProps>

/**
 * Couleurs par type RÉEL de nœud du graphe mémoire (agent | phase | pipeline).
 * Source de vérité partagée avec la légende de la page Memory.
 */
export const MEMORY_TYPE_COLOR: Record<string, string> = {
  agent: '#3B82F6',
  phase: '#10B981',
  pipeline: '#FB923C',
}
const FALLBACK_COLOR = '#5B6473'

/** Graphe de connaissances 3D (force-directed) coloré par type de nœud. */
export function MemoryGraph3D({
  graph,
  onSelect,
}: {
  graph: MemoryGraph
  onSelect: (slug: string) => void
}) {
  const data = useMemo(
    () => ({
      nodes: graph.nodes.map((n) => ({ ...n })),
      links: graph.links.map((l) => ({ ...l })),
    }),
    [graph],
  )

  // Mesure le conteneur pour borner le canvas à la colonne (évite l'overflow-x
  // dû au fallback window.innerWidth de react-force-graph-3d).
  const wrapRef = useRef<HTMLDivElement>(null)
  const [size, setSize] = useState<{ w: number; h: number } | null>(null)

  useEffect(() => {
    const el = wrapRef.current
    if (!el) return
    const measure = () => {
      const r = el.getBoundingClientRect()
      // Arrondi vers le bas : ne jamais excéder la largeur réelle du conteneur.
      setSize({ w: Math.max(0, Math.floor(r.width)), h: Math.max(0, Math.floor(r.height)) })
    }
    measure()
    const ro = new ResizeObserver(measure)
    ro.observe(el)
    return () => ro.disconnect()
  }, [])

  return (
    <div ref={wrapRef} style={{ position: 'absolute', inset: 0, overflow: 'hidden' }}>
      {size && size.w > 0 && (
        <ForceGraph3D
          graphData={data}
          width={size.w}
          height={size.h}
          backgroundColor="rgba(0,0,0,0)"
          nodeLabel={(n) => n.label}
          nodeColor={(n) => MEMORY_TYPE_COLOR[n.type] ?? FALLBACK_COLOR}
          nodeRelSize={4}
          nodeVal={(n) => n.val ?? 1}
          linkColor={() => 'rgba(120,130,150,0.25)'}
          linkWidth={0.5}
          onNodeClick={(n) => onSelect(n.id)}
          showNavInfo={false}
        />
      )}
    </div>
  )
}
