'use client'

import { useEffect, useRef, useState } from 'react'
import { cn } from '@/lib/utils'
import { Icon } from '@/lib/icons'
import type {
  ConsoleLine,
  LineKind,
  SessionMetrics,
  PermissionRequest,
  PermissionDecision,
} from '@/hooks/use-session-stream'

const KIND_CLASS: Record<LineKind, string> = {
  sys: 'cl-sys',
  user: 'cl-agent',
  agent: 'cl-agent',
  output: '',
  tool: 'cl-tok',
  warn: 'cl-warn',
  err: 'cl-err',
  tok: 'cl-tok',
}

/** Préfixe terminal par type de ligne (esthétique ada · headless). */
const KIND_PREFIX: Partial<Record<LineKind, string>> = {
  user: '› ',
}

/**
 * StreamConsole — terminal de streaming temps réel fidèle à workspaces.html :
 * barre (feux + titre + pause/recherche/copier), corps mono avec lignes
 * animées (streamIn) + curseur live, pied de métriques (tok/s, total, coût).
 */
export function StreamConsole({
  lines,
  metrics,
  pendingPermission,
  onPermissionDecision,
}: {
  lines: ConsoleLine[]
  metrics: SessionMetrics
  pendingPermission?: PermissionRequest | null
  onPermissionDecision?: (decision: PermissionDecision) => void
}) {
  const [paused, setPaused] = useState(false)
  const bodyRef = useRef<HTMLDivElement>(null)
  const prevTokens = useRef(0)
  const [tokRate, setTokRate] = useState(0)

  // Auto-scroll en bas tant que non-pausé.
  useEffect(() => {
    if (paused) return
    const el = bodyRef.current
    if (el) el.scrollTop = el.scrollHeight
  }, [lines, paused])

  // Débit tokens/s (échantillonné chaque seconde).
  useEffect(() => {
    const t = setInterval(() => {
      const delta = metrics.tokens - prevTokens.current
      prevTokens.current = metrics.tokens
      setTokRate(metrics.status === 'running' && delta > 0 ? delta : 0)
    }, 1000)
    return () => clearInterval(t)
  }, [metrics.tokens, metrics.status])

  const visible = paused ? lines.slice(0, Math.max(1, lines.length)) : lines
  const streaming = metrics.status === 'running'

  async function copyAll() {
    try {
      await navigator.clipboard.writeText(lines.map((l) => l.text).join('\n'))
    } catch {
      /* clipboard indisponible */
    }
  }

  return (
    <div className="console">
      <div className="console-bar">
        <span style={{ display: 'flex', gap: 6 }} aria-hidden="true">
          <span style={{ width: 11, height: 11, borderRadius: '50%', background: '#FF5F57' }} />
          <span style={{ width: 11, height: 11, borderRadius: '50%', background: '#FEBC2E' }} />
          <span style={{ width: 11, height: 11, borderRadius: '50%', background: '#28C840' }} />
        </span>
        <span className="mono" style={{ fontSize: 12, color: 'var(--muted)', marginLeft: 4 }}>
          ada · headless{metrics.turn > 0 ? ` · tour ${metrics.turn}` : ''}
        </span>
        <span style={{ flex: 1 }} />
        <button className={cn('chip', paused && 'on')} style={{ height: 26 }} onClick={() => setPaused((v) => !v)}>
          {paused ? <Icon name="play" style={{ width: 13, height: 13 }} /> : (
            <svg viewBox="0 0 24 24" width={13} fill="none" stroke="currentColor" strokeWidth={2} aria-hidden="true">
              <path d="M7 4h3v16H7zM14 4h3v16h-3z" />
            </svg>
          )}
          {paused ? 'Reprendre' : 'Pause'}
        </button>
        <button className="chip" style={{ height: 26 }} onClick={copyAll} aria-label="Copier la sortie">
          <Icon name="copy" style={{ width: 13, height: 13 }} />
          Copier
        </button>
      </div>

      <div className="console-body" ref={bodyRef} role="log" aria-live={paused ? 'off' : 'polite'}>
        {visible.length === 0 ? (
          <span className="cl-tok">En attente d&apos;une instruction…</span>
        ) : (
          visible.map((l) => (
            <div key={l.id} className="console-line">
              {l.time && <span className="cl-time">[{l.time}] </span>}
              {l.agent && <span className="cl-agent">{l.agent}</span>}
              <span className={KIND_CLASS[l.kind]}>
                {(KIND_PREFIX[l.kind] ?? '') + (l.agent ? `  ${l.text}` : l.text)}
              </span>
            </div>
          ))
        )}
        {pendingPermission && (
          <div
            className="console-line"
            style={{
              marginTop: 8,
              padding: 10,
              border: '1px solid var(--st-warning)',
              borderRadius: 'var(--r-sm)',
              background: 'var(--card)',
            }}
            role="alertdialog"
            aria-label="Demande de permission"
          >
            <div className="cl-warn" style={{ marginBottom: 6 }}>
              ⚠ permission requise · {pendingPermission.tool}
            </div>
            {pendingPermission.input != null && (
              <div className="cl-tok" style={{ marginBottom: 8, whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>
                {JSON.stringify(pendingPermission.input)}
              </div>
            )}
            <div style={{ display: 'flex', gap: 8 }}>
              <button className="chip" style={{ height: 26 }} onClick={() => onPermissionDecision?.('allow')}>
                Autoriser
              </button>
              <button className="chip on" style={{ height: 26 }} onClick={() => onPermissionDecision?.('allow_always')}>
                Toujours
              </button>
              <button className="chip" style={{ height: 26 }} onClick={() => onPermissionDecision?.('deny')}>
                Refuser
              </button>
            </div>
          </div>
        )}
        {streaming && <span className="cursor" aria-hidden="true" />}
      </div>

      <div className="console-foot">
        <span className={streaming ? 'cl-sys' : 'cl-tok'} aria-hidden="true">
          ●
        </span>
        {streaming ? 'stream actif' : metrics.status === 'success' ? 'terminé' : metrics.status === 'error' ? 'erreur' : 'inactif'}
        <span style={{ flex: 1 }} />
        <span className="cost">{tokRate} tok/s</span>
        <span>·</span>
        <span className="cost">{metrics.tokens.toLocaleString('fr-FR')} tokens</span>
        <span>·</span>
        <span className="cost" style={{ color: 'var(--st-warning)' }}>
          ${metrics.cost.toFixed(2)}
        </span>
      </div>
    </div>
  )
}
