'use client'

import { cn } from '@/lib/utils'
import { StatusBadge, toRunStatus } from '@/components/ada/StatusBadge'
import type { Workspace } from '@/hooks/use-workspaces'
import type { Conversation } from '@/hooks/use-conversations'

const DOT: Record<string, string> = {
  running: 'var(--st-running)',
  success: 'var(--st-success)',
  error: 'var(--st-error)',
  idle: 'var(--st-idle)',
}

/**
 * Arbre projets → conversations (264px) fidèle à workspaces.html : projet actif
 * surligné + dot de santé, conversations indentées avec badge de statut.
 */
export function WorkspaceTree({
  workspaces,
  conversations,
  activeWorkspaceId,
  activeConversationId,
  onSelectWorkspace,
  onSelectConversation,
}: {
  workspaces: Workspace[]
  conversations: Conversation[]
  activeWorkspaceId: string | null
  activeConversationId: string | null
  onSelectWorkspace: (id: string) => void
  onSelectConversation: (id: string) => void
}) {
  return (
    <div className="card card-pad ws-list">
      {workspaces.map((w, idx) => {
        const isActive = w.id === activeWorkspaceId
        const dotColor = w.archived ? DOT.idle : DOT.running
        return (
          <div key={w.id}>
            {idx > 0 && <hr className="sep-line" style={{ margin: '8px 0' }} />}
            <button
              className={cn('ws-proj', isActive && 'active')}
              onClick={() => onSelectWorkspace(w.id)}
              aria-current={isActive ? 'true' : undefined}
              style={{ width: '100%', textAlign: 'left' }}
            >
              <span className="dot" style={{ background: dotColor }} aria-hidden="true" />
              <span className="grow" style={{ flex: 1, minWidth: 0 }}>
                <span className="t" style={{ fontSize: 13, fontWeight: 600, display: 'block' }}>
                  {w.name}
                </span>
                <span className="s" style={{ fontSize: 11, color: 'var(--muted)' }}>
                  {isActive ? `${conversations.length} conversation(s)` : (w.description ?? w.slug)}
                </span>
              </span>
            </button>

            {isActive && (
              <div className="conv">
                {conversations.length === 0 ? (
                  <div className="dim" style={{ fontSize: 12, padding: '6px 11px' }}>
                    Aucune conversation.
                  </div>
                ) : (
                  conversations.map((c) => {
                    const status = toRunStatus(c.lastRunStatus ?? c.status ?? 'idle')
                    const selected = c.id === activeConversationId
                    return (
                      <button
                        key={c.id}
                        className="lrow"
                        onClick={() => onSelectConversation(c.id)}
                        style={{
                          padding: '7px 11px',
                          border: 'none',
                          borderRadius: 8,
                          width: '100%',
                          textAlign: 'left',
                          background: selected ? 'var(--muted-bg)' : undefined,
                        }}
                        aria-current={selected ? 'true' : undefined}
                      >
                        <StatusBadge status={status} label="" />
                        <span
                          className="t"
                          style={{ fontSize: 12.5, color: selected ? 'var(--fg)' : 'var(--muted)' }}
                        >
                          #{c.title ?? c.id.slice(0, 8)}
                        </span>
                      </button>
                    )
                  })
                )}
              </div>
            )}
          </div>
        )
      })}
    </div>
  )
}
