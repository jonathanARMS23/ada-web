# Dette e2e connue (2026-08-13)

`obsidian.spec.ts` est désormais 100% vert (voir section "Obsidian — résolu"
en bas). Deux fichiers restent majoritairement en échec (`teams.spec.ts`,
`profile-types.spec.ts` — 13 échecs sur les 14 restants de la suite complète).
**Ce ne sont pas des sélecteurs/textes périmés** — chacun teste une
fonctionnalité réellement absente ou incomplète. Diagnostiqué le 2026-08-13,
pas corrigé (décision explicite : scope trop large pour cette session, à
traiter en session dédiée).

## teams.spec.ts (6 échecs)

- `/teams` n'existe pas comme route (`app/teams/` absent). Les teams sont
  affichées en lecture seule dans l'onglet "Teams" de `/agents`
  (`app/agents/page.tsx`, `tab === 'teams'`).
- **Backend prêt** : CRUD complet déjà en place —
  `ada-api-nest/src/ada/config.controllers.ts` `TeamsController`
  (`GET/POST /teams`, `GET/PATCH/DELETE /teams/:id`).
- Aucune UI de création ("New team" / modal) nulle part dans `ada-ui`.
- **À construire** : soit une vraie page `/teams` (list + bouton "New team" +
  modal de création via `POST /teams`), soit enrichir l'onglet Teams existant
  sur `/agents`. Le hook `useTeams()` (`hooks/use-teams.ts`) existe déjà et
  fonctionne (`GET /teams`) — il manque juste `useCreateTeam()` + la modal.

## profile-types.spec.ts (7 échecs)

- `/profile-types` n'existe pas comme route. Aucune trace de `RoutingTable`
  ou `RoutingTester` ailleurs dans `ada-ui`.
- **Backend absent** : aucun endpoint HTTP de classification. Le classifieur
  existe seulement en CLI (`.claude/coordinator/task-classifier.js`,
  `classifyTask(description, opts)` exporté).
- **À construire** (le plus gros des trois) :
  1. Nouvel endpoint `POST /classify` dans `ada-api-nest` wrappant
     `classifyTask()` (mirroring le pattern `AdaService` existant — voir
     comment `ada-bridge.js`/`run.js` sont déjà relayés).
  2. Nouvelle page `/profile-types` : table de routing (parser la table
     Markdown du CLAUDE.md racine — colonnes Profile/Keywords/Team/Priority
     attendues par les tests) + un "RoutingTester" (input + bouton "Test" +
     affichage du résultat de classification).

## Obsidian — résolu (2026-08-13, session suivante)

Implémenté bout en bout, 13/13 tests verts :

- Backend : route renommée `GET /obsidian` → `GET /obsidian/status` +
  nouvelle `POST /obsidian/status` (`ObsidianToggleDto`), nouveau RPC mutatif
  `obsidian.setEnabled` dans `control-handlers.js` (mute `~/.ada.json`,
  classé dans `mutativeMethods` + `capabilities.list`).
- Frontend : nouveau hook `hooks/use-obsidian.ts` (`useObsidianStatus` +
  `useToggleObsidian`, normalise `vaultDir→vaultName`, calcule l'URI
  `obsidian://open?vault=...`, tolère aussi une réponse déjà normalisée).
- Carte Settings (`#obsidian`) enrichie : badge Actif/Inactif live, chemin du
  vault + lien "Ouvrir" quand initialisé, compteur de sessions, message
  "Vault non initialisé" + `ada obsidian init --all` sinon. Le toggle appelle
  directement `POST /obsidian/status` (bascule immédiate, indépendante du
  bouton Enregistrer global). `Switch` a maintenant un `ariaLabel` distinct
  par usage (3 switches sur la page — l'ancien `aria-label="Basculer"`
  générique était ambigu).
- `/memory` : bouton "Obsidian · N" ajouté dans `page-head-actions`, visible
  seulement si `enabled && initialized`.
- Sidebar : lien renommé "Memory" → "Memory Graph" ; point indicateur
  (`nav-badge`) affiché quand Obsidian est actif — même requête
  `useObsidianStatus()` que Settings/Memory (cache react-query partagé).
- **Pas de scoping par profil** sur `obsidian.status` (comme les stats,
  contrairement à `/api/agents`) — le process control-server est pinné à un
  seul profil, pas de lecture cross-profil implémentée pour l'instant.
  Vérifié réellement (screenshot + suite e2e), pas seulement mocké.

## Progression mesurée cette session (2026-08-12/13)

| Étape | Échecs | Passés |
|---|---|---|
| Avant tout fix (bug connectivité control-plane non corrigé) | 51 | 5 |
| Après fix control-plane + scoping agents + fixes infra route() | 40 | 12 |
| Après réécriture agents/dashboard/profile-switcher/workspaces | 26 | 27 |
| Après implémentation Obsidian (statut live + toggle + bouton Memory) | **14** | **39** |

Fichiers 100% verts : `agents.spec.ts`, `dashboard.spec.ts`,
`profile-switcher.spec.ts`, `workspaces.spec.ts`, `obsidian.spec.ts`,
`profile-data-isolation.spec.ts` (sauf 1 test parfois flaky sous charge).

Restent : `teams.spec.ts` (6), `profile-types.spec.ts` (7) — voir sections
correspondantes plus haut.
