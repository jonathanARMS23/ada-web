import { test, expect } from '@playwright/test'
import { setActiveProfile } from './helpers'

test.describe('Agents page', () => {
  test.beforeEach(async ({ page }) => {
    await setActiveProfile(page, 'pro')
  })

  test('affiche le titre Agents', async ({ page }) => {
    await page.goto('/agents')

    await expect(page.getByRole('heading', { name: 'Agents' })).toBeVisible({ timeout: 10000 })
  })

  test('charge la liste des agents depuis /api/agents avec le profile param', async ({ page }) => {
    const agentsRequests: string[] = []

    await page.route('/api/agents*', async (route) => {
      const url = new URL(route.request().url())
      agentsRequests.push(url.searchParams.get('profile') ?? 'none')
      await route.continue()
    })

    // Set up response waiter BEFORE navigation so we don't miss the request
    const responsePromise = page.waitForResponse(
      (r) => r.url().includes('/api/agents'),
      { timeout: 15000 },
    )

    await page.goto('/agents')
    await responsePromise

    expect(agentsRequests.some((p) => p === 'pro')).toBe(true)
  })

  test('les agents ne sont pas des MOCK_AGENTS (slugs génériques)', async ({ page }) => {
    const agentsResponsePromise = page.waitForResponse(
      (r) => r.url().includes('/api/agents') && r.url().includes('profile=pro'),
      { timeout: 15000 },
    )

    await page.goto('/agents')

    try {
      const res = await agentsResponsePromise
      const data = await res.json() as { agents?: Array<{ slug: string; name: string }> }

      if (data.agents && data.agents.length > 0) {
        const allMock = data.agents.every((a) => /^mock-agent-\d+$/.test(a.slug))
        expect(allMock).toBe(false)

        for (const agent of data.agents) {
          expect(agent.slug).toBeTruthy()
          expect(agent.name).toBeTruthy()
        }
      }
    } catch {
      test.skip()
    }
  })

  test('affiche des AgentCards avec nom et slug', async ({ page }) => {
    // Wait for data BEFORE checking DOM
    const responsePromise = page.waitForResponse(
      (r) => r.url().includes('/api/agents'),
      { timeout: 15000 },
    )

    await page.goto('/agents')
    await responsePromise

    // Give React a tick to render after the response
    await page.waitForFunction(
      () => !document.querySelector('[data-slot="skeleton"]'),
      { timeout: 10000 },
    )

    const agentNames = page.locator('.bg-zinc-900.border.border-zinc-800.rounded-lg.p-4 p.text-sm.font-medium')
    const agentSlugs = page.locator('.bg-zinc-900.border.border-zinc-800.rounded-lg.p-4 p.font-mono')

    const nameCount = await agentNames.count()

    if (nameCount > 0) {
      const slugCount = await agentSlugs.count()
      expect(slugCount).toBeGreaterThan(0)
      expect(nameCount).toBe(slugCount)

      const firstName = await agentNames.first().textContent()
      const firstSlug = await agentSlugs.first().textContent()
      expect(firstName).toBeTruthy()
      expect(firstSlug).toBeTruthy()
    } else {
      await expect(page.getByText('No agents found')).toBeVisible({ timeout: 5000 })
    }
  })

  test('cliquer sur une AgentCard ouvre le AgentSheet (panneau détail)', async ({ page }) => {
    const responsePromise = page.waitForResponse(
      (r) => r.url().includes('/api/agents'),
      { timeout: 15000 },
    )

    await page.goto('/agents')
    await responsePromise

    await page.waitForFunction(
      () => !document.querySelector('[data-slot="skeleton"]'),
      { timeout: 10000 },
    )

    const firstCard = page.locator('.bg-zinc-900.border.border-zinc-800.rounded-lg.p-4').first()
    const count = await firstCard.count()

    if (count > 0) {
      await firstCard.click()
      await expect(page.locator('[data-slot="sheet-content"]')).toBeVisible({ timeout: 8000 })
    } else {
      test.skip()
    }
  })

  test('la barre de recherche filtre les agents', async ({ page }) => {
    const responsePromise = page.waitForResponse(
      (r) => r.url().includes('/api/agents'),
      { timeout: 15000 },
    )

    await page.goto('/agents')
    await responsePromise

    await page.waitForFunction(
      () => !document.querySelector('[data-slot="skeleton"]'),
      { timeout: 10000 },
    )

    const searchInput = page.getByPlaceholder('Search agents…')
    await expect(searchInput).toBeVisible()

    await searchInput.fill('xxxxxxxxxnonexistent')
    await expect(page.getByText('No agents found')).toBeVisible({ timeout: 5000 })
  })

  test('le filtre par catégorie "All" est sélectionné par défaut', async ({ page }) => {
    await page.goto('/agents')

    const allBadge = page.locator('[class*="bg-violet-600"]', { hasText: 'All' })
    await expect(allBadge).toBeVisible({ timeout: 10000 })
  })
})
