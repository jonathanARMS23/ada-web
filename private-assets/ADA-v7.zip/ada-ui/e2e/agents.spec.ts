import { test, expect } from '@playwright/test'
import { setActiveProfile } from './helpers'

test.describe('Agents page', () => {
  test.beforeEach(async ({ page }) => {
    await setActiveProfile(page, 'pro')
  })

  test('affiche le titre Agents', async ({ page }) => {
    await page.goto('/agents')

    await expect(page.getByRole('heading', { name: 'Agents' })).toBeVisible({ timeout: 10000 })
  })

  test('charge la liste des agents depuis /api/agents avec le profile param', async ({ page }) => {
    const agentsRequests: string[] = []

    await page.route('**/api/agents*', async (route) => {
      const url = new URL(route.request().url())
      agentsRequests.push(url.searchParams.get('profile') ?? 'none')
      await route.continue()
    })

    // Set up response waiter BEFORE navigation so we don't miss the request
    const responsePromise = page.waitForResponse(
      (r) => r.url().includes('/api/agents'),
      { timeout: 15000 },
    )

    await page.goto('/agents')
    await responsePromise

    expect(agentsRequests.some((p) => p === 'pro')).toBe(true)
  })

  test('les agents ne sont pas des MOCK_AGENTS (slugs génériques)', async ({ page }) => {
    const agentsResponsePromise = page.waitForResponse(
      (r) => r.url().includes('/api/agents') && r.url().includes('profile=pro'),
      { timeout: 15000 },
    )

    await page.goto('/agents')

    try {
      const res = await agentsResponsePromise
      const data = await res.json() as { agents?: Array<{ slug: string; name: string }> }

      if (data.agents && data.agents.length > 0) {
        const allMock = data.agents.every((a) => /^mock-agent-\d+$/.test(a.slug))
        expect(allMock).toBe(false)

        for (const agent of data.agents) {
          expect(agent.slug).toBeTruthy()
          expect(agent.name).toBeTruthy()
        }
      }
    } catch {
      test.skip()
    }
  })

  // La page réelle affiche les agents en LIGNES DE TABLEAU (AgentRow, colonnes
  // Agent/Tier/Rôle/Runs/Win rate/Coût moy.), pas en cards — et ouvre un Drawer
  // (pas un Sheet shadcn) au clic. Pas de filtre par catégorie ada/ruflo dans
  // l'UI (seulement les tabs Agents/Profiles/Teams). Tests réécrits en
  // conséquence le 2026-08-13 pour matcher app/agents/page.tsx.
  test('affiche les agents en lignes de tableau avec slug', async ({ page }) => {
    const responsePromise = page.waitForResponse((r) => r.url().includes('/api/agents'), { timeout: 15000 })

    await page.goto('/agents')
    await responsePromise
    await page.waitForFunction(() => !document.querySelector('.skel'), { timeout: 10000 })

    const rows = page.locator('table tbody tr')
    const count = await rows.count()

    if (count > 0) {
      const firstSlug = await rows.first().locator('.cell-strong').textContent()
      expect(firstSlug?.trim()).toBeTruthy()
    } else {
      await expect(page.getByText('Aucun agent')).toBeVisible({ timeout: 5000 })
    }
  })

  test('cliquer sur une ligne agent ouvre le Drawer de détail', async ({ page }) => {
    const responsePromise = page.waitForResponse((r) => r.url().includes('/api/agents'), { timeout: 15000 })

    await page.goto('/agents')
    await responsePromise
    await page.waitForFunction(() => !document.querySelector('.skel'), { timeout: 10000 })

    const firstRow = page.locator('table tbody tr').first()
    if (await firstRow.count() === 0) { test.skip(); return }

    await firstRow.click()
    await expect(page.locator('aside.drawer[role="dialog"]')).toBeVisible({ timeout: 8000 })
  })

  test('la barre de recherche filtre les agents', async ({ page }) => {
    const responsePromise = page.waitForResponse((r) => r.url().includes('/api/agents'), { timeout: 15000 })

    await page.goto('/agents')
    await responsePromise
    await page.waitForFunction(() => !document.querySelector('.skel'), { timeout: 10000 })

    const searchInput = page.getByPlaceholder('Rechercher un agent…')
    await expect(searchInput).toBeVisible()

    await searchInput.fill('xxxxxxxxxnonexistent')
    await expect(page.getByText('Aucun agent ne correspond à la recherche.')).toBeVisible({ timeout: 5000 })
  })

  test('l\'onglet "Agents" est sélectionné par défaut', async ({ page }) => {
    await page.goto('/agents')

    const agentsTab = page.getByRole('tab', { name: /^Agents/ })
    await expect(agentsTab).toBeVisible({ timeout: 10000 })
    await expect(agentsTab).toHaveAttribute('aria-selected', 'true')
  })
})
