import { test, expect } from '@playwright/test'
import { setActiveProfile } from './helpers'

test.describe('Dashboard', () => {
  test.beforeEach(async ({ page }) => {
    await setActiveProfile(page, 'pro')
  })

  test('affiche le titre Dashboard et la description', async ({ page }) => {
    await page.goto('/dashboard')

    await expect(page.getByRole('heading', { name: 'Dashboard' })).toBeVisible({ timeout: 10000 })
    await expect(page.getByText('ADA orchestrator overview')).toBeVisible()
  })

  test('StatsOverview affiche les 4 cartes de métriques', async ({ page }) => {
    await page.goto('/dashboard')

    // Attendre que les skeletons disparaissent (données chargées)
    await expect(page.getByText('Total Runs')).toBeVisible({ timeout: 15000 })
    await expect(page.getByText('Success Rate')).toBeVisible()
    await expect(page.getByText('Active Agents')).toBeVisible()
    await expect(page.getByText('Router Updates')).toBeVisible()
  })

  test('ActivityHeatmap est rendu avec la légende', async ({ page }) => {
    await page.goto('/dashboard')

    await expect(page.getByText('Activity — Last 90 days')).toBeVisible({ timeout: 15000 })
    // Vérifier la légende Less/More
    await expect(page.getByText('Less')).toBeVisible()
    await expect(page.getByText('More')).toBeVisible()
  })

  test('ActivityHeatmap contient des cellules avec aria-label de date', async ({ page }) => {
    await page.goto('/dashboard')

    // Attendre que le heatmap soit chargé (les cellules ont aria-label="date: N runs")
    await page.waitForFunction(
      () => document.querySelectorAll('[aria-label$="runs"]').length > 0,
      { timeout: 15000 },
    )

    const cells = page.locator('[aria-label$="runs"]')
    const count = await cells.count()
    // 90 jours = 90 cellules
    expect(count).toBeGreaterThanOrEqual(1)
  })

  test('ThompsonTable affiche le titre et le tableau', async ({ page }) => {
    await page.goto('/dashboard')

    await expect(page.getByText('Thompson Sampling — Agent Priors')).toBeVisible({ timeout: 15000 })

    // Le tableau doit avoir les colonnes Agent, Runs, Win rate
    await expect(page.getByRole('columnheader', { name: 'Agent' })).toBeVisible()
    await expect(page.getByRole('columnheader', { name: 'Runs' })).toBeVisible()
    await expect(page.getByRole('columnheader', { name: 'Win rate' })).toBeVisible()
  })

  test('RunsTimeline affiche le titre Recent Runs', async ({ page }) => {
    await page.goto('/dashboard')

    await expect(page.getByText('Recent Runs')).toBeVisible({ timeout: 15000 })
  })

  test('RunsTimeline affiche les runs ou le message vide', async ({ page }) => {
    await page.goto('/dashboard')

    // Attendre la fin du chargement (skeleton disparaît)
    await page.waitForFunction(
      () => {
        const skeletons = document.querySelectorAll('[data-slot="skeleton"]')
        return skeletons.length === 0
      },
      { timeout: 15000 },
    )

    const hasRuns = (await page.locator('.divide-y .flex.items-center.gap-3').count()) > 0
    const hasEmpty = (await page.getByText('No runs yet').count()) > 0
    expect(hasRuns || hasEmpty).toBe(true)
  })

  test('CRITIQUE: les données de /api/stats/overview ne sont pas des valeurs MOCK hardcodées', async ({ page }) => {
    let overviewData: Record<string, unknown> | null = null

    // Intercepter la réponse avant d'aller sur la page
    const responsePromise = page.waitForResponse(
      (r) => r.url().includes('/api/stats/overview') && r.url().includes('profile=pro'),
      { timeout: 15000 },
    )

    await page.goto('/dashboard')

    try {
      const res = await responsePromise
      overviewData = await res.json() as Record<string, unknown>
    } catch {
      // La requête n'a pas été faite avec profile=pro — le store n'était peut-être pas hydraté
      // On recharge après hydratation
      await page.waitForSelector('[data-testid="profile-select-trigger"]', { timeout: 10000 })
      const res2 = await page.waitForResponse(
        (r) => r.url().includes('/api/stats/overview'),
        { timeout: 10000 },
      )
      overviewData = await res2.json() as Record<string, unknown>
    }

    expect(overviewData).not.toBeNull()

    // Vérifier que les données ne sont pas les valeurs MOCK hardcodées
    // totalRuns=10 ET successRate=0.9 simultanément = MOCK data
    const isMock =
      overviewData!.totalRuns === 10 && overviewData!.successRate === 0.9

    expect(isMock).toBe(false)
  })

  test('CRITIQUE: /api/stats/overview est appelé avec le bon profile param', async ({ page }) => {
    const overviewRequests: string[] = []

    await page.route('/api/stats/overview*', async (route) => {
      const url = new URL(route.request().url())
      const profile = url.searchParams.get('profile')
      if (profile) overviewRequests.push(profile)
      await route.continue()
    })

    // Set up waiter BEFORE navigation so we don't miss the request
    const responsePromise = page.waitForResponse(
      (r) => r.url().includes('/api/stats/overview'),
      { timeout: 15000 },
    )

    await page.goto('/dashboard')
    await responsePromise

    expect(overviewRequests.length).toBeGreaterThan(0)
    expect(overviewRequests).toContain('pro')
  })
})
