import { test, expect } from '@playwright/test'
import { setActiveProfile } from './helpers'

test.describe('Dashboard', () => {
  test.beforeEach(async ({ page }) => {
    await setActiveProfile(page, 'pro')
  })

  // Les tests ci-dessous vérifiaient des textes EN d'une version antérieure de
  // l'UI ; la page réelle (app/dashboard/page.tsx + components/dashboard/*) est
  // en français. Réécrits le 2026-08-13 pour matcher le vrai rendu.
  test('affiche le titre Dashboard et la description', async ({ page }) => {
    await page.goto('/dashboard')

    await expect(page.getByRole('heading', { name: 'Dashboard' })).toBeVisible({ timeout: 10000 })
    await expect(page.getByText("Vue d'ensemble système")).toBeVisible()
  })

  test('StatsOverview affiche les 4 cartes de métriques', async ({ page }) => {
    await page.goto('/dashboard')

    // Attendre que les skeletons disparaissent (données chargées). .kpi-top
    // ciblé plutôt que getByText('Runs') : ThompsonTable a aussi une colonne
    // "Runs" exacte, ambigu en mode strict Playwright.
    await expect(page.locator('.kpi-top', { hasText: 'Runs' })).toBeVisible({ timeout: 15000 })
    await expect(page.locator('.kpi-top', { hasText: 'Taux de succès' })).toBeVisible()
    await expect(page.locator('.kpi-top', { hasText: 'Agents actifs' })).toBeVisible()
    await expect(page.locator('.kpi-top', { hasText: 'Routeur · maj' })).toBeVisible()
  })

  test('ActivityHeatmap est rendu avec la légende', async ({ page }) => {
    await page.goto('/dashboard')

    await expect(page.getByText('Activité — 90 derniers jours')).toBeVisible({ timeout: 15000 })
    // Vérifier la légende moins/plus
    await expect(page.getByText('moins')).toBeVisible()
    await expect(page.getByText('plus')).toBeVisible()
  })

  test('ActivityHeatmap contient des cellules avec un title de date', async ({ page }) => {
    await page.goto('/dashboard')

    // Les cellules portent un attribut title (pas aria-label) : "<jour> · N run(s) · $X.XX"
    await page.waitForFunction(
      () => document.querySelectorAll('[title*="run("]').length > 0,
      { timeout: 15000 },
    )

    const cells = page.locator('[title*="run("]')
    const count = await cells.count()
    // 90 jours = 90 cellules
    expect(count).toBeGreaterThanOrEqual(1)
  })

  test('ThompsonTable affiche le titre et le tableau', async ({ page }) => {
    await page.goto('/dashboard')

    await expect(page.getByRole('heading', { name: 'Thompson Sampling' })).toBeVisible({ timeout: 15000 })
    await expect(page.getByText('priors agents')).toBeVisible()

    // Le tableau doit avoir les colonnes Agent, Runs, Win rate
    await expect(page.getByRole('columnheader', { name: 'Agent' })).toBeVisible()
    await expect(page.getByRole('columnheader', { name: 'Runs' })).toBeVisible()
    await expect(page.getByRole('columnheader', { name: 'Win rate' })).toBeVisible()
  })

  test('RunsTimeline affiche le titre Runs récents', async ({ page }) => {
    await page.goto('/dashboard')

    await expect(page.getByText('Runs récents')).toBeVisible({ timeout: 15000 })
  })

  test('RunsTimeline affiche les runs ou le message vide', async ({ page }) => {
    await page.goto('/dashboard')

    // Attendre la fin du chargement (skeleton .skel disparaît)
    await page.waitForFunction(
      () => document.querySelectorAll('.skel').length === 0,
      { timeout: 15000 },
    )

    const hasRuns = (await page.locator('.lrow').count()) > 0
    const hasEmpty = (await page.getByText('Aucun run récent.').count()) > 0
    expect(hasRuns || hasEmpty).toBe(true)
  })

  test('CRITIQUE: les données de /api/stats/overview ne sont pas des valeurs MOCK hardcodées', async ({ page }) => {
    // /api/stats/overview est scopé par workspaceId (Postgres, ADR-017) — PAS par
    // profil CLI (voir décision 2026-08-13 : aucune colonne "profile" dans le
    // schéma, migration jugée disproportionnée par rapport au besoin). On
    // n'attend donc plus profile=pro dans l'URL ici, juste la vraie réponse.
    const responsePromise = page.waitForResponse(
      (r) => r.url().includes('/api/stats/overview'),
      { timeout: 15000 },
    )

    await page.goto('/dashboard')

    const res = await responsePromise
    const overviewData = await res.json() as Record<string, unknown>

    expect(overviewData).not.toBeNull()

    // Vérifier que les données ne sont pas les valeurs MOCK hardcodées
    // totalRuns=10 ET successRate=0.9 simultanément = MOCK data
    const isMock =
      overviewData.totalRuns === 10 && overviewData.successRate === 0.9

    expect(isMock).toBe(false)
  })
})
