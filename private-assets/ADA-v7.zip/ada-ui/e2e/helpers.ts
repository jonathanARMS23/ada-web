import { type Page } from '@playwright/test'

/**
 * Injecte un profil actif dans le localStorage Zustand avant navigation.
 * Doit être appelé depuis about:blank ou une URL du même domaine.
 */
export async function setActiveProfile(page: Page, profile: string): Promise<void> {
  // Charger d'abord une page du domaine pour avoir accès au localStorage
  await page.goto('/', { waitUntil: 'domcontentloaded' })
  await page.evaluate((p: string) => {
    localStorage.setItem(
      'ada-ui-store',
      JSON.stringify({
        state: { activeProfile: p, authStatus: 'authenticated' },
        version: 0,
      }),
    )
  }, profile)
}

/**
 * Vide le localStorage pour simuler un état initial sans profil.
 */
export async function clearStorage(page: Page): Promise<void> {
  await page.goto('/', { waitUntil: 'domcontentloaded' })
  await page.evaluate(() => localStorage.clear())
}

/**
 * Lit la valeur du store Zustand depuis localStorage.
 */
export async function getStoredProfile(page: Page): Promise<string | null> {
  return page.evaluate(() => {
    const raw = localStorage.getItem('ada-ui-store')
    if (!raw) return null
    try {
      const parsed = JSON.parse(raw)
      return parsed?.state?.activeProfile ?? null
    } catch {
      return null
    }
  })
}
