import { test, expect } from '@playwright/test'
import { setActiveProfile } from './helpers'

// ── Fixtures ──────────────────────────────────────────────────────────────────

const OBS_ENABLED = {
  enabled: true,
  initialized: true,
  vaultName: '_obsidian',
  vaultDir: '/Users/test/.claude-pro/_obsidian',
  uri: 'obsidian://open?vault=_obsidian',
  sessionCount: 3,
}

const OBS_DISABLED = { enabled: false }
const OBS_NOT_INIT = { enabled: true, initialized: false }

/** Minimal memory graph fixture so MemoryGraph3D renders instead of "Mémoire vide" */
const MEMORY_GRAPH = {
  nodes: [{ id: 'agent-1', label: 'nextjs', type: 'agent', group: 'frontend', val: 2 }],
  links: [],
  stats: { totalAgents: 1, totalPhases: 0, totalLessons: 0, totalConnections: 0 },
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function mockObsidianStatus(page: import('@playwright/test').Page, body: object) {
  return page.route('/api/obsidian/status*', async (route) => {
    if (route.request().method() === 'GET') {
      await route.fulfill({ json: body })
    } else {
      await route.continue()
    }
  })
}

// ── Settings card ─────────────────────────────────────────────────────────────

test.describe('Settings — ObsidianSettings card', () => {
  test.beforeEach(async ({ page }) => {
    await setActiveProfile(page, 'pro')
  })

  test('affiche la card Obsidian dans Settings', async ({ page }) => {
    await mockObsidianStatus(page, OBS_ENABLED)
    await page.goto('/settings')

    // Cible le card title qui contient exactement "Obsidian" (avec badge en enfant)
    await expect(page.locator('[data-slot="card-title"]').filter({ hasText: 'Obsidian' }).first()).toBeVisible({ timeout: 10000 })
    await expect(page.getByText('Journalisation des sessions')).toBeVisible()
  })

  test('badge Actif visible quand obsidian.enabled=true', async ({ page }) => {
    await mockObsidianStatus(page, OBS_ENABLED)
    await page.goto('/settings')

    await expect(page.getByText('Actif')).toBeVisible({ timeout: 10000 })
  })

  test('badge Inactif visible quand obsidian.enabled=false', async ({ page }) => {
    await mockObsidianStatus(page, OBS_DISABLED)
    await page.goto('/settings')

    await expect(page.getByText('Inactif')).toBeVisible({ timeout: 10000 })
  })

  test('affiche le vault path et le lien Ouvrir quand enabled + initialized', async ({ page }) => {
    await mockObsidianStatus(page, OBS_ENABLED)
    await page.goto('/settings')

    await expect(page.getByText('/Users/test/.claude-pro/_obsidian')).toBeVisible({ timeout: 10000 })
    await expect(page.getByRole('link', { name: 'Ouvrir' })).toBeVisible()

    const href = await page.getByRole('link', { name: 'Ouvrir' }).getAttribute('href')
    expect(href).toBe('obsidian://open?vault=_obsidian')
  })

  test('affiche le session count', async ({ page }) => {
    await mockObsidianStatus(page, OBS_ENABLED)
    await page.goto('/settings')

    await expect(page.getByText('3 sessions')).toBeVisible({ timeout: 10000 })
  })

  test('affiche le message CLI quand enabled mais vault non initialisé', async ({ page }) => {
    await mockObsidianStatus(page, OBS_NOT_INIT)
    await page.goto('/settings')

    await expect(page.getByText('Vault non initialisé')).toBeVisible({ timeout: 10000 })
    await expect(page.getByText('ada obsidian init --all')).toBeVisible()
  })

  test('le toggle envoie POST /api/obsidian/status avec enabled inversé', async ({ page }) => {
    await mockObsidianStatus(page, OBS_ENABLED)

    const postBodies: object[] = []
    await page.route('/api/obsidian/status', async (route) => {
      if (route.request().method() === 'POST') {
        const body = route.request().postDataJSON() as object
        postBodies.push(body)
        await route.fulfill({ json: { ok: true, enabled: false } })
      } else {
        await route.continue()
      }
    })

    await page.goto('/settings')
    await expect(page.getByText('Actif')).toBeVisible({ timeout: 10000 })

    // Click the toggle switch
    await page.getByRole('switch').click()

    // Verify POST was sent with enabled: false (inverting current true state)
    await expect.poll(() => postBodies.length, { timeout: 5000 }).toBeGreaterThan(0)
    expect(postBodies[0]).toMatchObject({ enabled: false })
  })
})

// ── Memory Graph Obsidian button ──────────────────────────────────────────────

test.describe('Memory Graph — bouton Obsidian', () => {
  test.beforeEach(async ({ page }) => {
    await setActiveProfile(page, 'pro')
    // Always provide memory data so MemoryGraph3D renders
    await page.route('/api/memory*', async (route) => {
      await route.fulfill({ json: MEMORY_GRAPH })
    })
  })

  test('affiche le bouton Obsidian quand enabled + initialized', async ({ page }) => {
    await mockObsidianStatus(page, OBS_ENABLED)
    await page.goto('/memory')

    // Cible directement le lien par son URI — évite le faux-positif avec le dot sidebar
    const obsBtn = page.locator('a[href="obsidian://open?vault=_obsidian"]').first()
    await expect(obsBtn).toBeVisible({ timeout: 15000 })
    await expect(obsBtn).toContainText('Obsidian')
  })

  test('affiche le session count dans le bouton', async ({ page }) => {
    await mockObsidianStatus(page, OBS_ENABLED)
    await page.goto('/memory')

    // Button contains "Obsidian" + count "3"
    await expect(page.getByRole('link', { name: /Obsidian/ })).toBeVisible({ timeout: 15000 })
    await expect(page.locator('a[href="obsidian://open?vault=_obsidian"]')).toContainText('3')
  })

  test('n\'affiche pas le bouton Obsidian quand disabled', async ({ page }) => {
    await mockObsidianStatus(page, OBS_DISABLED)
    await page.goto('/memory')

    // Wait for graph to render (controls visible)
    await expect(page.getByText('Recentrer')).toBeVisible({ timeout: 15000 })

    const obsBtn = page.locator('a[href^="obsidian://"]')
    await expect(obsBtn).toHaveCount(0)
  })

  test('n\'affiche pas le bouton quand enabled mais non initialisé', async ({ page }) => {
    await mockObsidianStatus(page, OBS_NOT_INIT)
    await page.goto('/memory')

    await expect(page.getByText('Recentrer')).toBeVisible({ timeout: 15000 })

    const obsBtn = page.locator('a[href^="obsidian://"]')
    await expect(obsBtn).toHaveCount(0)
  })
})

// ── Sidebar indicator ─────────────────────────────────────────────────────────

test.describe('Sidebar — indicateur Obsidian', () => {
  test.beforeEach(async ({ page }) => {
    await setActiveProfile(page, 'pro')
  })

  test('le lien Memory Graph est présent dans la sidebar', async ({ page }) => {
    await mockObsidianStatus(page, OBS_ENABLED)
    await page.goto('/dashboard')

    await expect(page.getByRole('link', { name: 'Memory Graph' })).toBeVisible({ timeout: 10000 })
  })

  test('requête GET /api/obsidian/status émise depuis la sidebar', async ({ page }) => {
    const obsRequests: string[] = []
    await page.route('/api/obsidian/status*', async (route) => {
      if (route.request().method() === 'GET') {
        obsRequests.push(route.request().url())
        await route.fulfill({ json: OBS_ENABLED })
      } else {
        await route.continue()
      }
    })

    await page.goto('/dashboard')

    // Wait for sidebar to mount and query to fire
    await expect(page.getByRole('link', { name: 'Memory Graph' })).toBeVisible({ timeout: 10000 })
    await expect.poll(() => obsRequests.length, { timeout: 5000 }).toBeGreaterThan(0)

    expect(obsRequests[0]).toContain('/api/obsidian/status')
    expect(obsRequests[0]).toContain('profile=pro')
  })
})
