import { test, expect } from '@playwright/test'
import { setActiveProfile } from './helpers'

/**
 * Ce fichier testait à l'origine une "isolation des stats par profil CLI"
 * (profile=pro / profile=jarvis retournant des données différentes). Décision
 * architecturale du 2026-08-13 : /api/stats/* est scopé par workspaceId
 * (Postgres, ADR-017), PAS par profil CLI — il n'existe aucune colonne
 * "profile" dans le schéma, et une migration pour en ajouter une a été jugée
 * disproportionnée par rapport au besoin réel (voir aussi /api/agents, qui LUI
 * est réellement scopé par profil car basé sur <profileDir>/agents/ sur disque).
 *
 * Les anciens tests référençaient aussi /api/stats/runs, qui n'existe pas
 * (les vraies routes sont /api/stats/overview, /api/stats/activity,
 * /api/stats/budget, /api/stats/runs/timeline).
 *
 * Ce qui reste légitime à vérifier ici : que /api/stats/overview ne retourne
 * jamais les valeurs MOCK hardcodées historiques (totalRuns=10, successRate=0.9),
 * quel que soit le profil actif — voir aussi dashboard.spec.ts pour le test
 * équivalent au niveau page.
 */
test.describe('Stats overview — pas de données MOCK, quel que soit le profil actif', () => {
  test('profil "pro" — /api/stats/overview ne retourne pas les valeurs MOCK hardcodées', async ({ page }) => {
    await setActiveProfile(page, 'pro')

    const responsePromise = page.waitForResponse(
      (r) => r.url().includes('/api/stats/overview'),
      { timeout: 15000 },
    )

    await page.goto('/dashboard')

    const res = await responsePromise
    const data = await res.json() as { totalRuns?: number; successRate?: number }

    const isMock = data.totalRuns === 10 && data.successRate === 0.9
    expect(isMock).toBe(false)
  })

  test('/api/agents (réellement scopé par profil, contrairement aux stats) — profil "pro" reçu tel quel', async ({ page }) => {
    await setActiveProfile(page, 'pro')

    const agentsRequests: string[] = []
    await page.route('**/api/agents*', async (route) => {
      const url = new URL(route.request().url())
      agentsRequests.push(url.searchParams.get('profile') ?? 'none')
      await route.continue()
    })

    const responsePromise = page.waitForResponse((r) => r.url().includes('/api/agents'), { timeout: 15000 })
    await page.goto('/agents')
    await responsePromise

    expect(agentsRequests).toContain('pro')
  })
})
