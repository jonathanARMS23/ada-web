import { test, expect } from '@playwright/test'
import { setActiveProfile, clearStorage } from './helpers'

test.describe('Profile data isolation', () => {
  test('profil "jarvis" — runs retournés depuis la vraie FS (pas MOCK totalRuns=10)', async ({ page }) => {
    await setActiveProfile(page, 'jarvis')

    const runsResponsePromise = page.waitForResponse(
      (r) => r.url().includes('/api/stats/runs') && r.url().includes('profile=jarvis'),
      { timeout: 15000 },
    )

    await page.goto('/dashboard')

    let runsData: unknown
    try {
      const res = await runsResponsePromise
      runsData = await res.json()
    } catch {
      // /api/stats/runs peut ne pas être appelé si jarvis n'a pas de runs — acceptable
      runsData = { runs: [] }
    }

    // Vérifier que totalRuns dans overview n'est pas la valeur MOCK hardcodée
    const overviewPromise = page.waitForResponse(
      (r) => r.url().includes('/api/stats/overview') && r.url().includes('profile=jarvis'),
      { timeout: 15000 },
    )

    await page.goto('/dashboard')

    try {
      const overviewRes = await overviewPromise
      const overview = await overviewRes.json() as { totalRuns?: number; successRate?: number }
      // jarvis est un profil récent/vide — il ne doit pas avoir 10 runs hardcodés
      const isMockData = overview.totalRuns === 10 && overview.successRate === 0.9
      expect(isMockData).toBe(false)
    } catch {
      // Si la requête ne part pas, c'est que le profil n'est pas trouvé — pas un échec de test
      test.skip()
    }
  })

  test('profil "pro" — stats/overview appelé avec profile=pro', async ({ page }) => {
    await setActiveProfile(page, 'pro')

    const requests: string[] = []
    await page.route('/api/stats/overview*', async (route) => {
      const url = new URL(route.request().url())
      requests.push(url.searchParams.get('profile') ?? 'none')
      await route.continue()
    })

    // Set up the waiter BEFORE navigation so we don't miss the request
    const responsePromise = page.waitForResponse(
      (r) => r.url().includes('/api/stats/overview'),
      { timeout: 15000 },
    )

    await page.goto('/dashboard')
    await responsePromise

    expect(requests.some((p) => p === 'pro')).toBe(true)
    // Aucune requête ne doit partir avec un autre profil
    expect(requests.every((p) => p === 'pro' || p === 'none')).toBe(true)
  })

  test('profil "pro" — runs.length retourné par /api/stats/runs est cohérent (pas plus de 10 hardcodés)', async ({ page }) => {
    await setActiveProfile(page, 'pro')

    const runsResponsePromise = page.waitForResponse(
      (r) => r.url().includes('/api/stats/runs') && r.url().includes('profile=pro'),
      { timeout: 20000 },
    )

    await page.goto('/dashboard')

    try {
      const res = await runsResponsePromise
      const data = await res.json() as { runs?: unknown[] }
      // Les données réelles peuvent avoir entre 0 et N runs
      // L'assertion critique : si exactement 10 runs avec des IDs génériques, c'est du MOCK
      if (data.runs && data.runs.length === 10) {
        const runs = data.runs as Array<{ id?: string }>
        const allMockIds = runs.every((r) => /^run-\d+$/.test(r.id ?? ''))
        expect(allMockIds).toBe(false)
      }
    } catch {
      // La requête peut ne pas avoir été interceptée si le profil est vide
      // Ce n'est pas un échec
    }
  })

  test('switcher de profil invalide le cache et reload les données avec le nouveau profil', async ({ page }) => {
    await setActiveProfile(page, 'pro')
    await page.goto('/dashboard')

    // Attendre le chargement initial
    await expect(page.getByText('Total Runs')).toBeVisible({ timeout: 15000 })

    const requestsAfterSwitch: string[] = []
    await page.route('/api/stats/overview*', async (route) => {
      const url = new URL(route.request().url())
      requestsAfterSwitch.push(url.searchParams.get('profile') ?? 'none')
      await route.continue()
    })

    // Switcher vers un autre profil via le sélecteur
    const trigger = page.locator('[data-testid="profile-select-trigger"]')
    await expect(trigger).toBeVisible({ timeout: 10000 })
    await trigger.dispatchEvent('click')

    const jarvisOption = page.locator('[role="option"]', { hasText: 'claude-jarvis' })
    if (await jarvisOption.count() > 0) {
      const reloadPromise = page.waitForResponse(
        (r) => r.url().includes('/api/stats/overview') && !r.url().includes('profile=pro'),
        { timeout: 10000 },
      )
      await jarvisOption.click()
      await reloadPromise

      // La requête de reload doit utiliser le nouveau profil, pas "pro"
      expect(requestsAfterSwitch.some((p) => p !== 'pro')).toBe(true)
    } else {
      test.skip()
    }
  })

  test("sans localStorage (état initial), les queries ne partent pas avant qu'un profil soit sélectionné", async ({ page }) => {
    await clearStorage(page)

    const statRequests: string[] = []
    await page.route('/api/stats/overview*', async (route) => {
      const url = new URL(route.request().url())
      statRequests.push(url.searchParams.get('profile') ?? 'none')
      await route.continue()
    })

    await page.goto('/dashboard')

    // Attendre que le composant se monte (500ms suffisent pour détecter un appel prématuré)
    await page.waitForSelector('[data-testid="profile-select-trigger"]', { timeout: 10000 })

    // À ce stade, le ProfileSwitcher est en train de détecter les profils.
    // Aucune requête stats ne devrait partir avec profile=null ou profile=undefined
    const invalidRequests = statRequests.filter((p) => p === 'null' || p === 'undefined' || p === 'none')
    expect(invalidRequests.length).toBe(0)
  })

  test('deux profils différents retournent des données différentes', async ({ page }) => {
    // Profil 1 : pro
    await setActiveProfile(page, 'pro')
    let proTotalRuns: number | null = null

    const proOverviewPromise = page.waitForResponse(
      (r) => r.url().includes('/api/stats/overview') && r.url().includes('profile=pro'),
      { timeout: 15000 },
    )
    await page.goto('/dashboard')
    try {
      const res = await proOverviewPromise
      const data = await res.json() as { totalRuns?: number }
      proTotalRuns = data.totalRuns ?? null
    } catch {
      test.skip()
      return
    }

    // Profil 2 : jarvis
    await setActiveProfile(page, 'jarvis')
    let jarvisTotalRuns: number | null = null

    const jarvisOverviewPromise = page.waitForResponse(
      (r) => r.url().includes('/api/stats/overview') && r.url().includes('profile=jarvis'),
      { timeout: 15000 },
    )
    await page.goto('/dashboard')
    try {
      const res = await jarvisOverviewPromise
      const data = await res.json() as { totalRuns?: number }
      jarvisTotalRuns = data.totalRuns ?? null
    } catch {
      test.skip()
      return
    }

    // Les deux profils doivent retourner leurs propres données.
    // Si les deux valeurs sont identiques et non nulles, ce peut être du MOCK.
    // On vérifie surtout qu'elles ne sont pas exactement les mêmes valeurs hardcodées.
    if (proTotalRuns !== null && jarvisTotalRuns !== null) {
      // Il est TRÈS improbable que deux profils réels aient exactement le même totalRuns
      // sauf si c'est MOCK — mais on ne peut pas forcer l'inégalité (profils vides = 0)
      // L'assertion utile : au moins un ne retourne pas les valeurs MOCK (10 + 0.9)
      const proIsMock = proTotalRuns === 10
      const jarvisIsMock = jarvisTotalRuns === 10
      // Les deux ne peuvent pas être 10 simultanément (ce serait 100% MOCK)
      expect(proIsMock && jarvisIsMock).toBe(false)
    }
  })
})
