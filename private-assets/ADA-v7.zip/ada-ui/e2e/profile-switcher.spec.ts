import { test, expect } from '@playwright/test'
import { setActiveProfile, clearStorage, getStoredProfile } from './helpers'

test.describe('ProfileSwitcher', () => {
  test.beforeEach(async ({ page }) => {
    await clearStorage(page)
  })

  test('charge la liste des profils depuis /api/profiles', async ({ page }) => {
    const profilesResponse = page.waitForResponse(
      (r) => r.url().includes('/api/profiles') && r.status() === 200,
    )

    await page.goto('/dashboard')
    const res = await profilesResponse

    const body = await res.json() as { profiles: string[] }
    expect(Array.isArray(body.profiles)).toBe(true)
    expect(body.profiles.length).toBeGreaterThan(0)
  })

  test('auto-sélectionne le premier profil disponible au chargement', async ({ page }) => {
    await page.goto('/dashboard')

    const switcher = page.locator('[data-testid="profile-select-trigger"]')
    await expect(switcher).toBeVisible({ timeout: 10000 })

    // ProfileCard affiche "—" tant que useProfiles() n'a pas résolu — attendre
    // que le vrai nom de profil (activeProfile renvoyé par /api/profiles) soit
    // rendu avant de vérifier le pattern.
    await expect(switcher).toContainText(/claude-\w+/, { timeout: 10000 })
  })

  // ProfileCard n'est pas un <select>/dropdown avec role="option" — c'est un
  // bouton qui ouvre un Drawer listant chaque profil en carte, avec un bouton
  // "Basculer" pour les profils non-actifs (voir components/layout/ProfileCard.tsx).
  test('le ProfileSwitcher affiche les profils disponibles dans le Drawer', async ({ page }) => {
    await setActiveProfile(page, 'pro')
    await page.goto('/dashboard')

    const trigger = page.locator('[data-testid="profile-select-trigger"]')
    await expect(trigger).toBeVisible({ timeout: 10000 })
    await trigger.click()

    await expect(page.getByRole('heading', { name: 'Profils' })).toBeVisible({ timeout: 10000 })
    // Chaque profil est affiché avec son chemin ~/.<id> en mono.
    const items = page.locator('.dim.mono', { hasText: /^~\/\.claude-\w+/ })
    await expect(items.first()).toBeVisible({ timeout: 5000 })
    expect(await items.count()).toBeGreaterThan(0)
  })

  test('switcher de profil met à jour le localStorage', async ({ page }) => {
    await setActiveProfile(page, 'pro')
    await page.goto('/dashboard')

    const trigger = page.locator('[data-testid="profile-select-trigger"]')
    await expect(trigger).toBeVisible({ timeout: 10000 })
    await trigger.click()

    await expect(page.getByRole('heading', { name: 'Profils' })).toBeVisible({ timeout: 10000 })
    const switchButtons = page.getByText('Basculer', { exact: true })
    await page.waitForTimeout(1000)
    if (await switchButtons.count() === 0) { test.skip(); return }

    await switchButtons.first().click()

    const stored = await getStoredProfile(page)
    expect(stored).not.toBeNull()
    expect(typeof stored).toBe('string')
  })

  test('switcher de profil déclenche un re-fetch des agents avec le bon profile param', async ({ page }) => {
    // /api/stats/overview est scopé par workspaceId, pas par profil CLI (décision
    // 2026-08-13 — voir profile-data-isolation.spec.ts) : il ne re-fetch PAS avec
    // un profile= différent après un switch, ce n'est pas une régression. /api/agents
    // en revanche EST réellement scopé par profil (<profileDir>/agents/ sur disque)
    // — c'est lui qu'on vérifie ici pour tester le re-fetch post-switch.
    const agentsParamsSeen: string[] = []
    await page.route('**/api/agents*', async (route) => {
      const url = new URL(route.request().url())
      const p = url.searchParams.get('profile')
      if (p) agentsParamsSeen.push(p)
      await route.continue()
    })

    await setActiveProfile(page, 'pro')
    await page.goto('/agents')
    await expect(page.getByRole('heading', { name: 'Agents' })).toBeVisible({ timeout: 15000 })

    const trigger = page.locator('[data-testid="profile-select-trigger"]')
    await expect(trigger).toBeVisible({ timeout: 10000 })
    await trigger.click()

    // ProfileCard ouvre un Drawer avec un bouton "Basculer" par profil non-actif —
    // attendre que la liste (dépend de useProfiles()) ait fini de se peupler.
    await expect(page.getByRole('heading', { name: 'Profils' })).toBeVisible({ timeout: 10000 })
    const switchButtons = page.getByText('Basculer', { exact: true })
    await page.waitForTimeout(1500)
    const count = await switchButtons.count()
    if (count === 0) { test.skip(); return }

    const fetchAfterSwitch = page.waitForResponse(
      (r) => r.url().includes('/api/agents') && !r.url().includes('profile=pro'),
      { timeout: 10000 },
    )
    await switchButtons.first().click()
    await fetchAfterSwitch

    expect(agentsParamsSeen.some((p) => p !== 'pro')).toBe(true)
  })

  test('le profil est persisté dans localStorage sous la clé ada-ui-store', async ({ page }) => {
    await setActiveProfile(page, 'pro')
    await page.goto('/dashboard')

    await page.waitForSelector('[data-testid="profile-select-trigger"]', { timeout: 10000 })

    const raw = await page.evaluate(() => localStorage.getItem('ada-ui-store'))
    expect(raw).not.toBeNull()

    const parsed = JSON.parse(raw!)
    expect(parsed).toHaveProperty('state')
    expect(parsed.state).toHaveProperty('activeProfile')
    expect(typeof parsed.state.activeProfile).toBe('string')
  })
})
