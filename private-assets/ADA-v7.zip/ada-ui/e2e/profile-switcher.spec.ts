import { test, expect } from '@playwright/test'
import { setActiveProfile, clearStorage, getStoredProfile } from './helpers'

test.describe('ProfileSwitcher', () => {
  test.beforeEach(async ({ page }) => {
    await clearStorage(page)
  })

  test('charge la liste des profils depuis /api/profiles', async ({ page }) => {
    const profilesResponse = page.waitForResponse(
      (r) => r.url().includes('/api/profiles') && r.status() === 200,
    )

    await page.goto('/dashboard')
    const res = await profilesResponse

    const body = await res.json() as { profiles: string[] }
    expect(Array.isArray(body.profiles)).toBe(true)
    expect(body.profiles.length).toBeGreaterThan(0)
  })

  test('auto-sélectionne le premier profil disponible au chargement', async ({ page }) => {
    await page.goto('/dashboard')

    const switcher = page.locator('[data-testid="profile-select-trigger"]')
    await expect(switcher).toBeVisible({ timeout: 10000 })

    // Wait for auto-select to complete: switcher should not say Détection or Sélectionner
    await expect(switcher).not.toContainText('Détection', { timeout: 10000 })
    await expect(switcher).not.toContainText('Sélectionner', { timeout: 5000 })

    const text = await switcher.textContent()
    expect(text).toMatch(/claude-\w+/)
  })

  test('le ProfileSwitcher affiche les profils disponibles dans le menu', async ({ page }) => {
    await setActiveProfile(page, 'pro')
    await page.goto('/dashboard')

    const trigger = page.locator('[data-testid="profile-select-trigger"]')
    await expect(trigger).toBeVisible({ timeout: 10000 })
    await trigger.dispatchEvent('click')

    const items = page.locator('[role="option"]')
    const count = await items.count()
    expect(count).toBeGreaterThan(0)

    const firstItemText = await items.first().textContent()
    expect(firstItemText).toMatch(/claude-\w+/)
  })

  test('switcher de profil met à jour le localStorage', async ({ page }) => {
    await setActiveProfile(page, 'pro')
    await page.goto('/dashboard')

    const trigger = page.locator('[data-testid="profile-select-trigger"]')
    await expect(trigger).toBeVisible({ timeout: 10000 })
    await trigger.dispatchEvent('click')

    const items = page.locator('[role="option"]')
    await items.first().click()

    const stored = await getStoredProfile(page)
    expect(stored).not.toBeNull()
    expect(typeof stored).toBe('string')
  })

  test('switcher de profil déclenche un re-fetch avec le bon profile param', async ({ page }) => {
    // ProfileBootstrap always sets the server profile ('pro') — we start there
    // and switch to a different profile to verify the re-fetch
    const profileParamsSeen: string[] = []
    await page.route('/api/stats/overview*', async (route) => {
      const url = new URL(route.request().url())
      const p = url.searchParams.get('profile')
      if (p) profileParamsSeen.push(p)
      await route.continue()
    })

    await page.goto('/dashboard')

    // Wait for initial data load with server profile
    await expect(page.getByText('Total Runs')).toBeVisible({ timeout: 15000 })

    const trigger = page.locator('[data-testid="profile-select-trigger"]')
    await expect(trigger).toBeVisible({ timeout: 10000 })
    await trigger.dispatchEvent('click')

    // Pick any option that differs from the current profile (server sets 'pro')
    const options = page.locator('[role="option"]')
    const count = await options.count()
    const currentText = await trigger.textContent() ?? ''

    let targetProfile: string | null = null
    for (let i = 0; i < count; i++) {
      const text = (await options.nth(i).textContent() ?? '').trim()
      if (text && !currentText.includes(text)) {
        targetProfile = text.replace('claude-', '').trim()
        break
      }
    }

    if (!targetProfile) { test.skip(); return }

    const fetchAfterSwitch = page.waitForResponse(
      (r) => r.url().includes('/api/stats/overview') && r.url().includes(`profile=${targetProfile}`),
      { timeout: 10000 },
    )
    await options.filter({ hasText: `claude-${targetProfile}` }).first().click()
    await fetchAfterSwitch
    expect(profileParamsSeen).toContain(targetProfile)
  })

  test('le profil est persisté dans localStorage sous la clé ada-ui-store', async ({ page }) => {
    await setActiveProfile(page, 'pro')
    await page.goto('/dashboard')

    await page.waitForSelector('[data-testid="profile-select-trigger"]', { timeout: 10000 })

    const raw = await page.evaluate(() => localStorage.getItem('ada-ui-store'))
    expect(raw).not.toBeNull()

    const parsed = JSON.parse(raw!)
    expect(parsed).toHaveProperty('state')
    expect(parsed.state).toHaveProperty('activeProfile')
    expect(typeof parsed.state.activeProfile).toBe('string')
  })
})
