import { test, expect } from '@playwright/test'
import { setActiveProfile } from './helpers'

test.describe('Teams page', () => {
  test('affiche le titre Teams', async ({ page }) => {
    await setActiveProfile(page, 'pro')
    await page.goto('/teams')

    await expect(page.getByRole('heading', { name: 'Teams' })).toBeVisible({ timeout: 10000 })
  })

  test('profil "pro" — affiche le bouton New team', async ({ page }) => {
    await setActiveProfile(page, 'pro')
    await page.goto('/teams')

    await expect(page.getByRole('button', { name: 'New team' })).toBeVisible({ timeout: 10000 })
  })

  test('profil "pro" (teams.json) — charge les équipes depuis /api/teams', async ({ page }) => {
    await setActiveProfile(page, 'pro')

    const teamsRequests: string[] = []
    await page.route('**/api/teams*', async (route) => {
      const url = new URL(route.request().url())
      teamsRequests.push(url.searchParams.get('profile') ?? 'none')
      await route.continue()
    })

    // Set up waiter BEFORE navigation to catch the request
    const responsePromise = page.waitForResponse(
      (r) => r.url().includes('/api/teams'),
      { timeout: 15000 },
    )

    await page.goto('/teams')
    await responsePromise

    expect(teamsRequests.some((p) => p === 'pro')).toBe(true)
  })

  test('profil "pro" (teams.json) — affiche 19 équipes', async ({ page }) => {
    await setActiveProfile(page, 'pro')

    const teamsResponsePromise = page.waitForResponse(
      (r) => r.url().includes('/api/teams') && r.url().includes('profile=pro'),
      { timeout: 15000 },
    )

    await page.goto('/teams')

    try {
      const res = await teamsResponsePromise
      const data = await res.json() as { teams?: unknown[] }

      if (data.teams) {
        expect(data.teams.length).toBe(19)
      } else {
        test.skip()
      }
    } catch {
      test.skip()
    }
  })

  test('profil "pro" — les TeamCards affichent nom et agents', async ({ page }) => {
    await setActiveProfile(page, 'pro')

    // Wait for data before checking DOM
    const responsePromise = page.waitForResponse(
      (r) => r.url().includes('/api/teams'),
      { timeout: 15000 },
    )

    await page.goto('/teams')
    await responsePromise

    // Wait for skeletons to disappear
    await page.waitForFunction(
      () => !document.querySelector('[data-slot="skeleton"]'),
      { timeout: 10000 },
    )

    const teamCards = page.locator('.bg-zinc-900.border.border-zinc-800.rounded-lg')
    const count = await teamCards.count()

    if (count > 0) {
      const firstCardName = teamCards.first().locator('p.text-sm.font-medium')
      await expect(firstCardName).toBeVisible()
      const nameText = await firstCardName.textContent()
      expect(nameText).toBeTruthy()
    } else {
      await expect(page.getByText('No teams yet')).toBeVisible()
    }
  })

  test('profil "pro" — les teams ne sont pas des MOCK_TEAMS', async ({ page }) => {
    await setActiveProfile(page, 'pro')

    const teamsResponsePromise = page.waitForResponse(
      (r) => r.url().includes('/api/teams') && r.url().includes('profile=pro'),
      { timeout: 15000 },
    )

    await page.goto('/teams')

    try {
      const res = await teamsResponsePromise
      const data = await res.json() as { teams?: Array<{ id: string; name: string }> }

      if (data.teams && data.teams.length > 0) {
        const allMock = data.teams.every((t) => /^mock-team-\d+$/.test(t.id))
        expect(allMock).toBe(false)
      }
    } catch {
      test.skip()
    }
  })

  test('profil "jarvis" (sans teams.json) — teams parsées depuis CLAUDE.md, pas vides', async ({ page }) => {
    await setActiveProfile(page, 'jarvis')

    const teamsResponsePromise = page.waitForResponse(
      (r) => r.url().includes('/api/teams') && r.url().includes('profile=jarvis'),
      { timeout: 15000 },
    )

    await page.goto('/teams')

    try {
      const res = await teamsResponsePromise
      const data = await res.json() as { teams?: Array<{ id: string; name: string }>; source?: string }

      if (data.teams && data.teams.length > 0) {
        const allMock = data.teams.every((t) => /^mock-team-\d+$/.test(t.id))
        expect(allMock).toBe(false)
      }
    } catch {
      test.skip()
    }
  })

  test('switcher de profil sur la page teams recharge les données', async ({ page }) => {
    await setActiveProfile(page, 'pro')

    const initialResponse = page.waitForResponse(
      (r) => r.url().includes('/api/teams') && r.url().includes('profile=pro'),
      { timeout: 15000 },
    )
    await page.goto('/teams')
    await initialResponse

    const requestsAfterSwitch: string[] = []
    await page.route('**/api/teams*', async (route) => {
      const url = new URL(route.request().url())
      requestsAfterSwitch.push(url.searchParams.get('profile') ?? 'none')
      await route.continue()
    })

    const trigger = page.locator('[data-testid="profile-select-trigger"]')
    await expect(trigger).toBeVisible()
    await trigger.dispatchEvent('click')

    const jarvisOption = page.locator('[role="option"]', { hasText: 'claude-jarvis' })
    if (await jarvisOption.count() > 0) {
      const reloadPromise = page.waitForResponse(
        (r) => r.url().includes('/api/teams') && !r.url().includes('profile=pro'),
        { timeout: 10000 },
      )
      await jarvisOption.click()
      await reloadPromise

      expect(requestsAfterSwitch.some((p) => p !== 'pro')).toBe(true)
    } else {
      test.skip()
    }
  })

  test('cliquer sur New team ouvre la modal', async ({ page }) => {
    await setActiveProfile(page, 'pro')
    await page.goto('/teams')

    const newTeamBtn = page.getByRole('button', { name: 'New team' })
    await expect(newTeamBtn).toBeVisible({ timeout: 10000 })
    await newTeamBtn.click()

    await expect(page.locator('[role="dialog"]:not([data-nextjs-dialog])')).toBeVisible({ timeout: 5000 })
  })
})
