import { test, expect } from '@playwright/test'
import { setActiveProfile, clearStorage } from './helpers'

test.describe('Workspaces — page list', () => {
  test.beforeEach(async ({ page }) => {
    await setActiveProfile(page, 'test-profile')
  })

  test('affiche le titre et le bouton Créer', async ({ page }) => {
    await page.goto('/workspaces')
    await expect(page.getByRole('heading', { name: /workspace/i })).toBeVisible({ timeout: 10000 })
    // La grille doit contenir au moins le card "Créer"
    await expect(page.getByText(/créer/i).first()).toBeVisible()
  })

  test('affiche un état de chargement si ada-api offline', async ({ page }) => {
    // Mock ada-api token absent → le loader s'affiche
    await clearStorage(page)
    await page.goto('/workspaces')
    // L'UI doit afficher quelque chose (pas crasher)
    await expect(page).not.toHaveURL('/error')
  })
})

test.describe('Workspaces — page detail [wid]', () => {
  test('redirige si wid inconnu ne retourne pas de conversations', async ({ page }) => {
    await setActiveProfile(page, 'test-profile')
    await page.goto('/workspaces/invalid-wid-00000')
    // Doit soit afficher la page vide sans crash, soit une erreur gracieuse
    await expect(page).not.toHaveURL('/error')
  })

  test('la sidebar contient le bouton Nouvelle conversation', async ({ page }) => {
    await setActiveProfile(page, 'test-profile')
    // On tente d'accéder à une URL plausible — si la page charge, le bouton doit exister
    await page.goto('/workspaces/test-workspace-id')
    // Attendre que la page charge (sans throw)
    await page.waitForLoadState('networkidle')
    // Page ne doit pas crasher
    await expect(page).not.toHaveURL('/error')
  })
})
