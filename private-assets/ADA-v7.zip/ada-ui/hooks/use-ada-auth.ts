'use client'

import { useEffect, useRef } from 'react'
import { useShallow } from 'zustand/react/shallow'
import { useAdaStore } from '@/store/ada-store'
import { ADA_API_BASE } from '@/lib/api'

interface TokenResponse {
  token: string
  expiresAt: string
  tokenType: 'Bearer'
}

/** exp (epoch s) lu depuis le payload JWT, sans dépendance de vérification. */
function parseExp(token: string): number | null {
  try {
    const seg = token.split('.')[1]
    const json = atob(seg.replace(/-/g, '+').replace(/_/g, '/'))
    const payload = JSON.parse(json) as { exp?: number }
    return typeof payload.exp === 'number' ? payload.exp : null
  } catch {
    return null
  }
}

/**
 * Bootstrap d'authentification de l'UI contre ada-api-nest.
 *  - POST /auth/token (public, mode local) au montage → JWT en mémoire (store).
 *  - Re-émission automatique via POST /auth/refresh avant expiration (90% du TTL).
 *  - Le JWT n'est jamais persisté (exclu du partialize du store).
 * ada-api offline → mode dégradé silencieux (les hooks Query afficheront l'erreur).
 */
export function useAdaAuth(): void {
  const { setAdaApiToken } = useAdaStore(
    useShallow((s) => ({ setAdaApiToken: s.setAdaApiToken })),
  )
  const started = useRef(false)
  const refreshTimer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const retryTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  useEffect(() => {
    if (started.current) return
    started.current = true

    let cancelled = false

    function scheduleRefresh(token: string): void {
      if (refreshTimer.current) clearTimeout(refreshTimer.current)
      const exp = parseExp(token)
      if (!exp) return
      const msUntilExpiry = exp * 1000 - Date.now()
      const delay = Math.max(msUntilExpiry * 0.9, 30_000) // min 30 s
      refreshTimer.current = setTimeout(() => {
        void refresh(token)
      }, delay)
    }

    async function refresh(currentToken: string): Promise<void> {
      try {
        const r = await fetch(`${ADA_API_BASE}/auth/refresh`, {
          method: 'POST',
          headers: { Authorization: `Bearer ${currentToken}` },
        })
        if (!r.ok) throw new Error(String(r.status))
        const { token } = (await r.json()) as TokenResponse
        if (token && !cancelled) {
          setAdaApiToken(token)
          scheduleRefresh(token)
        }
      } catch {
        // Refresh échoué (ada-api offline / token révoqué) — re-mint complet.
        if (!cancelled) void mint()
      }
    }

    async function mint(): Promise<void> {
      try {
        const r = await fetch(`${ADA_API_BASE}/auth/token`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: '{}',
        })
        if (!r.ok) throw new Error(String(r.status))
        const { token } = (await r.json()) as TokenResponse
        if (token && !cancelled) {
          setAdaApiToken(token)
          scheduleRefresh(token)
        }
      } catch {
        // ada-api offline — réessai dans 5 s.
        if (!cancelled) retryTimer.current = setTimeout(() => void mint(), 5_000)
      }
    }

    void mint()

    return () => {
      cancelled = true
      if (refreshTimer.current) clearTimeout(refreshTimer.current)
      if (retryTimer.current) clearTimeout(retryTimer.current)
    }
  }, [setAdaApiToken])
}
