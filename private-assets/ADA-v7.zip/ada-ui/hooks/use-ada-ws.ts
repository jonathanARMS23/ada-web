'use client'

import { useEffect, useRef } from 'react'
import { useQueryClient } from '@tanstack/react-query'
import { useShallow } from 'zustand/react/shallow'
import { useAdaStore } from '@/store/ada-store'
import { ADA_WS_ORIGIN } from '@/lib/api'

/**
 * Connexion WebSocket au StreamGateway de ada-api-nest (`/ws`).
 *
 * Bug corrigé (refonte P0) : l'ancienne implémentation faisait un aller-retour
 * `GET /api/ws/ticket` (route handler Canal A FS, supprimée) pour obtenir un
 * ticket one-time, puis se connectait à une origine `:3001` (ancien Fastify).
 * Le StreamGateway NestJS accepte directement le JWT via `?token=` (extractToken
 * — Authorization Bearer OU ?token=/?ticket=), donc on se connecte en une étape
 * à `${ADA_WS_ORIGIN}/ws?token=<jwt>` sans round-trip ni route FS.
 *
 * Reconnexion : backoff exponentiel 1s → 30s. Invalidations TanStack Query sur
 * les events run.x / cost.delta / budget.warning pour rafraîchir le dashboard live.
 */
export function useAdaWs(): void {
  const { adaApiToken, activeWorkspaceId, setAdaApiConnected, setWsLastEvent, setWsSend } = useAdaStore(
    useShallow((s) => ({
      adaApiToken: s.adaApiToken,
      activeWorkspaceId: s.activeWorkspaceId,
      setAdaApiConnected: s.setAdaApiConnected,
      setWsLastEvent: s.setWsLastEvent,
      setWsSend: s.setWsSend,
    })),
  )
  const queryClient = useQueryClient()
  const wsRef = useRef<WebSocket | null>(null)
  const retryRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const retryCount = useRef(0)
  const closedByEffect = useRef(false)
  const activeWorkspaceIdRef = useRef(activeWorkspaceId)

  useEffect(() => {
    activeWorkspaceIdRef.current = activeWorkspaceId
  }, [activeWorkspaceId])

  useEffect(() => {
    if (!adaApiToken) return
    const token = adaApiToken
    closedByEffect.current = false

    // Émetteur WS partagé via le store : lit toujours le socket courant (survit
    // aux reconnexions). Renvoie false si le socket n'est pas ouvert.
    setWsSend((msg) => {
      const ws = wsRef.current
      if (!ws || ws.readyState !== WebSocket.OPEN) return false
      ws.send(JSON.stringify(msg))
      return true
    })

    function connect(): void {
      // JWT directement en query (le gateway l'accepte via ?token=).
      const url = `${ADA_WS_ORIGIN}/ws?token=${encodeURIComponent(token)}`
      const ws = new WebSocket(url)
      wsRef.current = ws

      ws.onopen = () => {
        setAdaApiConnected(true)
        retryCount.current = 0
        const wid = activeWorkspaceIdRef.current
        if (wid) ws.send(JSON.stringify({ type: 'workspace.join', payload: { workspaceId: wid } }))
      }

      ws.onmessage = (e) => {
        let event: { type: string; [key: string]: unknown }
        try {
          event = JSON.parse(e.data as string)
        } catch {
          return
        }
        setWsLastEvent(event as Parameters<typeof setWsLastEvent>[0])
        const wid = activeWorkspaceIdRef.current

        const convId = (event.corr as { conversationId?: string } | undefined)?.conversationId

        switch (event.type) {
          case 'run.started':
          case 'run.completed':
          case 'run.phase.started':
          case 'run.phase.completed':
          case 'run.phase.failed':
          case 'run.cancelled':
            queryClient.invalidateQueries({ queryKey: ['stats'] })
            if (wid) {
              queryClient.invalidateQueries({ queryKey: ['runs', wid] })
              queryClient.invalidateQueries({ queryKey: ['workspace-stats', wid] })
              queryClient.invalidateQueries({ queryKey: ['conversations', wid] })
            }
            if (convId) queryClient.invalidateQueries({ queryKey: ['messages', convId] })
            break
          case 'cost.delta':
            queryClient.invalidateQueries({ queryKey: ['stats', 'overview'] })
            queryClient.invalidateQueries({ queryKey: ['stats', 'budget'] })
            if (wid) queryClient.invalidateQueries({ queryKey: ['workspace-stats', wid] })
            break
          case 'budget.warning':
            queryClient.invalidateQueries({ queryKey: ['stats', 'budget'] })
            break
          case 'session.turn_complete':
          case 'session.closed':
            // Le backend a persisté les nouveaux tours : rafraîchir l'historique.
            if (convId) queryClient.invalidateQueries({ queryKey: ['messages', convId] })
            if (wid) queryClient.invalidateQueries({ queryKey: ['conversations', wid] })
            break
        }
      }

      ws.onclose = () => {
        setAdaApiConnected(false)
        if (closedByEffect.current) return // démontage volontaire — pas de reconnexion
        const delay = Math.min(1000 * 2 ** retryCount.current, 30_000)
        retryCount.current++
        retryRef.current = setTimeout(connect, delay)
      }

      ws.onerror = () => ws.close()
    }

    connect()

    return () => {
      closedByEffect.current = true
      if (retryRef.current) clearTimeout(retryRef.current)
      wsRef.current?.close()
      setWsSend(null)
    }
  }, [adaApiToken, queryClient, setAdaApiConnected, setWsLastEvent, setWsSend])

  // Changement de room workspace sans reconnexion.
  useEffect(() => {
    const ws = wsRef.current
    if (!ws || ws.readyState !== WebSocket.OPEN) return
    if (activeWorkspaceId) {
      ws.send(JSON.stringify({ type: 'workspace.join', payload: { workspaceId: activeWorkspaceId } }))
    } else {
      ws.send(JSON.stringify({ type: 'workspace.leave' }))
    }
  }, [activeWorkspaceId])
}
