'use client'

import { useQuery, type UseQueryResult } from '@tanstack/react-query'
import { useShallow } from 'zustand/react/shallow'
import { apiJson } from '@/lib/api'
import { useAdaStore } from '@/store/ada-store'

export interface AgentInfo {
  slug: string
  name: string
  tier: 'haiku' | 'sonnet' | 'opus' | string
  role?: string
  runs?: number
  winRate?: number // 0..1
  avgCost?: number
}

export interface AgentDetail extends AgentInfo {
  title?: string
  description?: string
  active?: boolean
  prompt?: string
  /** Compétences déclarées de l'agent (peut être absent le temps que le backend redémarre). */
  skills: string[]
  /** Serveurs MCP susceptibles d'être utilisés (peut être absent). */
  mcps: string[]
  /** Win rate Thompson (0..1) issu de stats.pWin. */
  pWin?: number
  /** Taux de succès observé (0..1) issu de stats.successRate. */
  successRate?: number
  alpha?: number
  beta?: number
  mu?: number
  recentRuns?: Array<{ runId?: string; pipeline?: string; phase?: string; status: string; at?: string }>
}

/** stats Thompson renvoyées par GET /agents/:slug. */
interface RawAgentStats {
  totalRuns?: number
  successRate?: number
  alpha?: number
  beta?: number
  pWin?: number
}

/** agents.list est un relais RPC live ; on normalise plusieurs formes. */
interface RawAgent {
  slug?: string
  name?: string
  id?: string
  title?: string
  tier?: string
  model?: string
  role?: string
  description?: string
  desc?: string
  active?: boolean
  prompt?: string
  skills?: string[]
  mcps?: string[]
  stats?: RawAgentStats
  runs?: number
  winRate?: number
  mu?: number
  avgCost?: number
  cost?: number
}

function normTier(raw?: string): string {
  if (!raw) return 'sonnet'
  const v = raw.toLowerCase()
  if (v.includes('haiku')) return 'haiku'
  if (v.includes('opus')) return 'opus'
  if (v.includes('sonnet')) return 'sonnet'
  return v
}

function normalize(a: RawAgent): AgentInfo {
  const slug = a.slug ?? a.id ?? a.name ?? 'unknown'
  const stats = a.stats
  return {
    slug,
    name: a.name ?? slug,
    tier: normTier(a.tier ?? a.model),
    role: a.role || a.description || a.desc,
    runs: stats?.totalRuns ?? a.runs,
    winRate: typeof a.winRate === 'number' ? a.winRate : (stats?.pWin ?? a.mu),
    avgCost: a.avgCost ?? a.cost,
  }
}

/** Détail complet d'un agent — décapsule la forme réelle { agent: { …, stats } }. */
function normalizeDetail(a: RawAgent): AgentDetail {
  const stats = a.stats
  return {
    ...normalize(a),
    title: a.title,
    description: a.description ?? a.desc,
    active: a.active,
    prompt: a.prompt,
    skills: Array.isArray(a.skills) ? a.skills : [],
    mcps: Array.isArray(a.mcps) ? a.mcps : [],
    pWin: stats?.pWin,
    successRate: stats?.successRate,
    alpha: stats?.alpha,
    beta: stats?.beta,
    mu: a.mu,
  }
}

export function useAgents(): UseQueryResult<AgentInfo[]> {
  // Chaque profil a son propre <profileDir>/agents/ (agents custom par profil) —
  // le catalogue doit donc être re-fetché quand on change de profil actif.
  // useSwitchProfile invalide déjà la queryKey ['agents'] au succès.
  const activeProfile = useAdaStore(useShallow((s) => s.activeProfile))
  return useQuery({
    queryKey: ['agents', activeProfile],
    queryFn: async () => {
      const qs = activeProfile ? `?profile=${encodeURIComponent(activeProfile)}` : ''
      const raw = await apiJson<{ agents?: RawAgent[] } | RawAgent[]>(`/agents${qs}`)
      const list = Array.isArray(raw) ? raw : (raw.agents ?? [])
      return list.map(normalize)
    },
    staleTime: 60_000,
  })
}

export function useAgentDetail(slug: string | null): UseQueryResult<AgentDetail> {
  return useQuery({
    queryKey: ['agent', slug],
    enabled: !!slug,
    queryFn: async () => {
      // Forme réelle : { agent: { …, stats, skills, mcps } }. On gère aussi
      // une réponse à plat par défense (anciennes versions du backend).
      const raw = await apiJson<{ agent?: RawAgent } | RawAgent>(`/agents/${slug}`)
      const agent = 'agent' in raw && raw.agent ? raw.agent : (raw as RawAgent)
      return normalizeDetail(agent)
    },
    staleTime: 60_000,
  })
}
