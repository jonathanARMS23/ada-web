'use client'

import {
  useMutation,
  useQuery,
  useQueryClient,
  type UseQueryResult,
} from '@tanstack/react-query'
import { apiJson, apiFetch } from '@/lib/api'

export interface Conversation {
  id: string
  workspaceId: string
  title: string | null
  summary: string | null
  status?: string | null
  lastRunStatus?: string | null
  pinned: boolean
  archived: boolean
  messageCount?: number
  createdAt: string
  updatedAt: string
}

export interface Message {
  id: string
  conversationId: string
  role: 'user' | 'assistant' | 'system' | 'tool' | 'error' | string
  content: string
  contentType?: string | null
  metadata?: Record<string, unknown>
  createdAt: string
}

interface ConversationsPage {
  items: Conversation[]
  nextCursor?: string | null
}
interface MessagesPage {
  items: Message[]
  nextCursor?: string | null
}

export function useConversations(workspaceId: string | null): UseQueryResult<ConversationsPage> {
  return useQuery({
    queryKey: ['conversations', workspaceId],
    enabled: !!workspaceId,
    queryFn: () => apiJson<ConversationsPage>(`/workspaces/${workspaceId}/conversations?limit=50`),
    staleTime: 15_000,
  })
}

export function useMessages(conversationId: string | null): UseQueryResult<MessagesPage> {
  return useQuery({
    queryKey: ['messages', conversationId],
    enabled: !!conversationId,
    queryFn: () => apiJson<MessagesPage>(`/conversations/${conversationId}/messages?limit=100`),
    staleTime: 10_000,
  })
}

export function useCreateConversation() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ workspaceId, title }: { workspaceId: string; title?: string }) =>
      apiJson<Conversation>(`/workspaces/${workspaceId}/conversations`, {
        method: 'POST',
        body: JSON.stringify({ title }),
      }),
    onSuccess: (_data, vars) => qc.invalidateQueries({ queryKey: ['conversations', vars.workspaceId] }),
  })
}

export function useUpdateConversation(workspaceId: string | null) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ id, patch }: { id: string; patch: { title?: string; pinned?: boolean; archived?: boolean } }) =>
      apiJson<Conversation>(`/conversations/${id}`, { method: 'PATCH', body: JSON.stringify(patch) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['conversations', workspaceId] }),
  })
}

export function useDeleteConversation(workspaceId: string | null) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: async (id: string) => {
      const res = await apiFetch(`/conversations/${id}`, { method: 'DELETE' })
      if (!res.ok && res.status !== 204) throw new Error(`Suppression échouée (${res.status})`)
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ['conversations', workspaceId] }),
  })
}
