'use client'

import { useQuery, type UseQueryResult } from '@tanstack/react-query'
import { apiJson } from '@/lib/api'

/* ── Types miroir des DTO ada-api-nest (stats.service.ts / claude.service.ts) ── */

export interface OverviewStats {
  totalRuns: number
  byStatus: Record<string, number>
  successRate: number // 0..1
  topAgents: Array<{ agent: string; runs: number; cost: number }>
  totalCost: number
  totalTokens: number
  activeRuns: number
  source: 'postgres' | 'live' | 'empty'
  degraded: boolean
  router?: RouterStats
}

export interface ActivityBucket {
  day: string
  runs: number
  cost: number
}
export interface ActivityStats {
  days: number
  buckets: ActivityBucket[]
  source: 'postgres' | 'empty'
  degraded: boolean
}

export interface TimelinePhase {
  phaseId: string
  agent: string | null
  status: string
  cost: number
  durationMs: number | null
}
export interface TimelineItem {
  runId: string
  pipeline: string
  name: string | null
  status: string
  startedAt: string | null
  completedAt: string | null
  durationMs: number | null
  cost: number
  phases: TimelinePhase[]
}
export interface TimelineStats {
  items: TimelineItem[]
  source: 'postgres' | 'empty'
  degraded: boolean
}

export interface BudgetStats {
  config: Record<string, unknown> | null
  check: Record<string, unknown> | null
  source: 'live' | 'empty'
  degraded: boolean
}

/** router.stats est un relais RPC live (forme non garantie côté NestJS). */
export interface RouterAgentStat {
  agent: string
  tier?: 'haiku' | 'sonnet' | 'opus' | string
  runs?: number
  winRate?: number // 0..1
  alpha?: number
  beta?: number
}
export interface RouterStats {
  agents?: RouterAgentStat[]
  resamples?: number
  updatedAt?: string
  [k: string]: unknown
}

/** Santé du recall mémoire. `degraded` = recall fonctionnel mais en mode TF-IDF (Ollama down). */
export interface MemoryHealth {
  ollama: 'up' | 'down'
  degraded: boolean
}

export interface HealthReport {
  status: 'ok' | 'degraded'
  controlPlane: { reachable: boolean; [k: string]: unknown }
  db: 'up' | 'down' | 'disabled'
  dbError: string | null
  /** Optionnel : absent si l'API ne l'expose pas encore (rétrocompat). */
  memory?: MemoryHealth
}

/* ── Hooks ── */

const STALE = 30_000

export function useOverview(workspaceId?: string): UseQueryResult<OverviewStats> {
  const qs = workspaceId ? `?workspaceId=${encodeURIComponent(workspaceId)}` : ''
  return useQuery({
    queryKey: ['stats', 'overview', workspaceId ?? null],
    queryFn: () => apiJson<OverviewStats>(`/stats/overview${qs}`),
    staleTime: STALE,
  })
}

export function useActivity(days = 90, workspaceId?: string): UseQueryResult<ActivityStats> {
  const params = new URLSearchParams({ days: String(days) })
  if (workspaceId) params.set('workspaceId', workspaceId)
  return useQuery({
    queryKey: ['stats', 'activity', days, workspaceId ?? null],
    queryFn: () => apiJson<ActivityStats>(`/stats/activity?${params.toString()}`),
    staleTime: STALE,
  })
}

export function useTimeline(limit = 20, workspaceId?: string): UseQueryResult<TimelineStats> {
  const params = new URLSearchParams({ limit: String(limit) })
  if (workspaceId) params.set('workspaceId', workspaceId)
  return useQuery({
    queryKey: ['stats', 'timeline', limit, workspaceId ?? null],
    queryFn: () => apiJson<TimelineStats>(`/stats/runs/timeline?${params.toString()}`),
    staleTime: STALE,
  })
}

export function useBudget(): UseQueryResult<BudgetStats> {
  return useQuery({
    queryKey: ['stats', 'budget'],
    queryFn: () => apiJson<BudgetStats>('/stats/budget'),
    staleTime: STALE,
  })
}

export function useRouterStats(): UseQueryResult<RouterStats> {
  return useQuery({
    queryKey: ['stats', 'router'],
    queryFn: () => apiJson<RouterStats>('/router/stats'),
    staleTime: STALE,
  })
}

export function useHealth(): UseQueryResult<HealthReport> {
  return useQuery({
    queryKey: ['health'],
    queryFn: () => apiJson<HealthReport>('/health'),
    staleTime: 10_000,
    refetchInterval: 15_000,
  })
}
