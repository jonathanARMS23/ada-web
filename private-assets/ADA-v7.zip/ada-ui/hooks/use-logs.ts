'use client'

import { keepPreviousData, useQuery, type UseQueryResult } from '@tanstack/react-query'
import { apiJson } from '@/lib/api'

export type LogLevel = 'debug' | 'info' | 'warn' | 'error'

export interface LogEntry {
  id: string
  ts: string
  level: LogLevel | string
  source: string
  message: string
  runId?: string | null
}

export interface LogsPage {
  items: LogEntry[]
  nextCursor?: string | null
  degraded?: boolean
}

export interface LogsFilter {
  level?: LogLevel
  source?: string
  run?: string
  q?: string
  from?: string
  to?: string
  limit?: number
  follow?: boolean
}

interface RawLog {
  id?: string
  ts?: string
  time?: string
  createdAt?: string
  level?: string
  source?: string
  message?: string
  msg?: string
  runId?: string | null
  run?: string | null
}

function normalize(r: RawLog, idx: number): LogEntry {
  return {
    id: r.id ?? `${r.ts ?? idx}-${idx}`,
    ts: r.ts ?? r.time ?? r.createdAt ?? '',
    level: (r.level as LogLevel) ?? 'info',
    source: r.source ?? '—',
    message: r.message ?? r.msg ?? '',
    runId: r.runId ?? r.run ?? null,
  }
}

/**
 * Logs filtrables + paginés (GET /logs). Le mode « suivre » active un
 * rafraîchissement périodique (les logs ne sont pas poussés ligne-à-ligne via WS).
 */
export function useLogs(filter: LogsFilter): UseQueryResult<LogsPage> {
  const params = new URLSearchParams()
  if (filter.level) params.set('level', filter.level)
  if (filter.source) params.set('source', filter.source)
  if (filter.run) params.set('run', filter.run)
  if (filter.q) params.set('q', filter.q)
  if (filter.from) params.set('from', filter.from)
  if (filter.to) params.set('to', filter.to)
  params.set('limit', String(filter.limit ?? 100))

  return useQuery({
    queryKey: ['logs', filter],
    queryFn: async () => {
      const raw = await apiJson<{ items?: RawLog[]; nextCursor?: string | null; degraded?: boolean } | RawLog[]>(
        `/logs?${params.toString()}`,
      )
      const items = Array.isArray(raw) ? raw : (raw.items ?? [])
      return {
        items: items.map(normalize),
        nextCursor: Array.isArray(raw) ? null : raw.nextCursor,
        degraded: Array.isArray(raw) ? false : raw.degraded,
      }
    },
    placeholderData: keepPreviousData,
    refetchInterval: filter.follow ? 3000 : false,
    staleTime: filter.follow ? 0 : 15_000,
  })
}
