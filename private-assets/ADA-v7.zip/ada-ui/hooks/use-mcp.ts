'use client'

import {
  useMutation,
  useQuery,
  useQueryClient,
  type UseQueryResult,
} from '@tanstack/react-query'
import { apiJson, apiFetch } from '@/lib/api'

export interface McpConnector {
  id: string
  name: string
  transport: 'stdio' | 'http' | 'sse' | string
  status: 'running' | 'warning' | 'error' | 'idle' | string
  toolCount?: number
  description?: string
  enabled?: boolean
}

export interface McpCatalogEntry {
  id: string
  name: string
  description?: string
}

interface RawConnector {
  id?: string
  name?: string
  transport?: string
  command?: string
  url?: string
  status?: string
  health?: string
  toolCount?: number
  tools?: number
  description?: string
  enabled?: boolean
}

function normConnector(c: RawConnector): McpConnector {
  const id = c.id ?? c.name ?? 'mcp'
  return {
    id,
    name: c.name ?? id,
    transport: c.transport ?? (c.url ? 'http' : 'stdio'),
    status: c.status ?? c.health ?? (c.enabled === false ? 'idle' : 'running'),
    toolCount: c.toolCount ?? c.tools,
    description: c.description,
    enabled: c.enabled,
  }
}

export function useMcpConnectors(): UseQueryResult<McpConnector[]> {
  return useQuery({
    queryKey: ['mcp', 'connectors'],
    queryFn: async () => {
      const raw = await apiJson<{ connectors?: RawConnector[] } | RawConnector[]>('/mcp/connectors')
      const list = Array.isArray(raw) ? raw : (raw.connectors ?? [])
      return list.map(normConnector)
    },
    staleTime: 30_000,
  })
}

export function useMcpRegistry(): UseQueryResult<McpCatalogEntry[]> {
  return useQuery({
    queryKey: ['mcp', 'registry'],
    queryFn: async () => {
      const raw = await apiJson<{ servers?: RawConnector[]; registry?: RawConnector[] } | RawConnector[]>('/mcp/registry')
      const list = Array.isArray(raw) ? raw : (raw.servers ?? raw.registry ?? [])
      return list.map((c) => ({ id: c.id ?? c.name ?? 'srv', name: c.name ?? c.id ?? 'srv', description: c.description }))
    },
    staleTime: 300_000,
  })
}

export interface CreateConnectorInput {
  name: string
  command?: string
  url?: string
  args?: string[]
}

export function useCreateConnector() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (input: CreateConnectorInput) =>
      apiJson<McpConnector>('/mcp/connectors', { method: 'POST', body: JSON.stringify(input) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['mcp', 'connectors'] }),
  })
}

export function useUpdateConnector() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ id, patch }: { id: string; patch: { enabled?: boolean; url?: string; command?: string } }) =>
      apiJson<McpConnector>(`/mcp/connectors/${id}`, { method: 'PATCH', body: JSON.stringify(patch) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['mcp', 'connectors'] }),
  })
}

export function useDeleteConnector() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: async (id: string) => {
      const res = await apiFetch(`/mcp/connectors/${id}`, { method: 'DELETE' })
      if (!res.ok && res.status !== 204) throw new Error(`Suppression échouée (${res.status})`)
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ['mcp', 'connectors'] }),
  })
}
