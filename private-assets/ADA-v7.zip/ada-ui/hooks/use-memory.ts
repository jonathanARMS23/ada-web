'use client'

import { useQuery, type UseQueryResult } from '@tanstack/react-query'
import { apiJson } from '@/lib/api'

/**
 * Types de nœuds RÉELS du graphe mémoire (vérifié contre /api/memory/graph) :
 * uniquement `agent` | `phase` | `pipeline`. Les ids portent le préfixe
 * correspondant (`agent:db`, `phase:schema`, `pipeline:feature`).
 */
export type MemoryNodeType = 'agent' | 'phase' | 'pipeline' | string

export interface MemoryNode {
  id: string
  label: string
  type: MemoryNodeType
  /** poids/pagerank → taille du nœud */
  val?: number
}
export interface MemoryEdge {
  source: string
  target: string
  type?: string
  weight?: number
}
export interface MemoryGraph {
  nodes: MemoryNode[]
  links: MemoryEdge[]
  stats?: Record<string, unknown>
  empty: boolean
}

interface RawNode {
  id?: string
  label?: string
  name?: string
  type?: string
  group?: string
  category?: string
  pagerank?: number
  weight?: number
  val?: number
}
interface RawEdge {
  source?: string
  target?: string
  from?: string
  to?: string
  type?: string
  weight?: number
}
interface RawGraph {
  nodes?: RawNode[]
  edges?: RawEdge[]
  links?: RawEdge[]
  stats?: Record<string, unknown>
  pagerank?: Record<string, number>
  empty?: boolean
}

function normalizeGraph(raw: RawGraph): MemoryGraph {
  const pr = raw.pagerank ?? {}
  const nodes = (raw.nodes ?? []).map((n): MemoryNode => {
    const id = n.id ?? n.name ?? n.label ?? 'node'
    return {
      id,
      label: n.label ?? n.name ?? id,
      // type réel exposé directement ; fallback dérivé du préfixe de l'id.
      type: n.type ?? n.group ?? n.category ?? (id.split(':')[0] || 'node'),
      val: n.val ?? n.weight ?? pr[id],
    }
  })
  const rawLinks = raw.links ?? raw.edges ?? []
  const links = rawLinks
    .map((e): MemoryEdge => ({
      source: e.source ?? e.from ?? '',
      target: e.target ?? e.to ?? '',
      type: e.type,
      weight: e.weight,
    }))
    .filter((l) => l.source && l.target)
  return { nodes, links, stats: raw.stats, empty: raw.empty ?? nodes.length === 0 }
}

export function useMemoryGraph(top = 200): UseQueryResult<MemoryGraph> {
  return useQuery({
    queryKey: ['memory', 'graph', top],
    queryFn: async () => normalizeGraph(await apiJson<RawGraph>(`/memory/graph?top=${top}`)),
    staleTime: 60_000,
  })
}

/**
 * Topic du wiki mémoire. Le `content` (markdown) est inclus INLINE par
 * /api/memory/wiki — on NE fait PAS d'appel /memory/notes/:slug (renvoie 400).
 */
export interface WikiTopic {
  slug: string
  topic: string
  domain: string
  sessionCount: number
  lastUpdated: string | null
  projects: string[]
  content: string
}

interface RawWikiTopic {
  slug?: string
  topic?: string
  title?: string
  name?: string
  domain?: string
  sessionCount?: number
  sessions_count?: number
  lastUpdated?: string
  updated?: string
  projects?: string[]
  content?: string
  body?: string
  markdown?: string
}
interface RawWiki {
  topics?: RawWikiTopic[]
  totalSessions?: number
  generatedAt?: string
  empty?: boolean
}

function normalizeTopic(t: RawWikiTopic): WikiTopic {
  const slug = t.slug ?? t.title ?? t.name ?? 'topic'
  return {
    slug,
    topic: t.topic ?? t.title ?? t.name ?? slug,
    domain: t.domain ?? 'other',
    sessionCount: t.sessionCount ?? t.sessions_count ?? 0,
    lastUpdated: t.lastUpdated ?? t.updated ?? null,
    projects: Array.isArray(t.projects) ? t.projects : [],
    content: t.content ?? t.body ?? t.markdown ?? '',
  }
}

export function useMemoryWiki(): UseQueryResult<WikiTopic[]> {
  return useQuery({
    queryKey: ['memory', 'wiki'],
    queryFn: async () => {
      const raw = await apiJson<RawWiki>('/memory/wiki')
      return (raw.topics ?? []).map(normalizeTopic)
    },
    staleTime: 60_000,
  })
}

export function useMemorySearch(query: string): UseQueryResult<unknown> {
  return useQuery({
    queryKey: ['memory', 'search', query],
    enabled: query.trim().length > 0,
    queryFn: () => apiJson<unknown>(`/memory?q=${encodeURIComponent(query)}`),
    staleTime: 30_000,
  })
}

/**
 * Détail d'un pipeline pour le panneau topologie (nœud `pipeline:<name>`).
 * Fetch direct via apiJson (le hook use-pipelines a été retiré de l'UI).
 */
export interface PipelinePhaseLite {
  id: string
  label?: string
  agent?: string | null
  tier?: number | string | null
  depends?: string[]
}
export interface PipelineDetail {
  name: string
  description?: string
  phases: PipelinePhaseLite[]
}

interface RawPipelinePhase {
  id?: string
  phaseId?: string
  name?: string
  label?: string
  agent?: string | null
  tier?: number | string | null
  depends?: string[]
  deps?: string[]
}
interface RawPipelineEnvelope {
  pipeline?: {
    name?: string
    id?: string
    description?: string
    phases?: RawPipelinePhase[]
  }
}

export function usePipelineDetail(name: string | null): UseQueryResult<PipelineDetail> {
  return useQuery({
    queryKey: ['memory', 'pipeline', name],
    enabled: !!name,
    queryFn: async () => {
      const raw = await apiJson<RawPipelineEnvelope>(`/pipelines/${name}`)
      const p = raw.pipeline ?? {}
      return {
        name: p.name ?? p.id ?? name!,
        description: p.description,
        phases: (p.phases ?? []).map((ph) => ({
          id: ph.id ?? ph.phaseId ?? ph.name ?? 'phase',
          label: ph.label ?? ph.name,
          agent: ph.agent ?? null,
          tier: ph.tier ?? null,
          depends: ph.depends ?? ph.deps ?? [],
        })),
      }
    },
    staleTime: 60_000,
  })
}
