'use client'

import { useMutation, useQuery, useQueryClient, type UseQueryResult } from '@tanstack/react-query'
import { apiJson } from '@/lib/api'

export interface ObsidianStatus {
  enabled: boolean
  initialized: boolean
  vaultName: string
  vaultDir: string
  uri: string
  sessionCount: number
}

/**
 * Forme brute renvoyée par GET /obsidian/status (relais obsidian.status) :
 * { enabled, mode, vaultDir, initialized, sessions }. Champs vaultName/uri/
 * sessionCount tolérés aussi en entrée (déjà normalisés) — accepte les deux
 * formes pour rester robuste si le backend les expose directement un jour.
 */
interface RawObsidianStatus {
  enabled?: boolean
  initialized?: boolean
  vaultDir?: string
  vaultName?: string
  uri?: string
  sessions?: number
  sessionCount?: number
  mode?: string
}

function basename(p: string): string {
  return p.split('/').filter(Boolean).pop() ?? p
}

function normalize(raw: RawObsidianStatus): ObsidianStatus {
  const vaultDir = raw.vaultDir ?? ''
  const vaultName = raw.vaultName ?? (vaultDir ? basename(vaultDir) : '')
  return {
    enabled: !!raw.enabled,
    initialized: !!raw.initialized,
    vaultName,
    vaultDir,
    uri: raw.uri ?? (vaultName ? `obsidian://open?vault=${encodeURIComponent(vaultName)}` : ''),
    sessionCount: raw.sessionCount ?? raw.sessions ?? 0,
  }
}

export function useObsidianStatus(): UseQueryResult<ObsidianStatus> {
  return useQuery({
    queryKey: ['obsidian', 'status'],
    queryFn: async () => normalize(await apiJson<RawObsidianStatus>('/obsidian/status')),
    staleTime: 30_000,
  })
}

/** Bascule rapide enabled — POST /obsidian/status (mute ~/.ada.json). */
export function useToggleObsidian() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (enabled: boolean) =>
      apiJson<unknown>('/obsidian/status', { method: 'POST', body: JSON.stringify({ enabled }) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['obsidian'] }),
  })
}
