'use client'

import { useMutation, useQuery, useQueryClient, type UseQueryResult } from '@tanstack/react-query'
import { apiJson } from '@/lib/api'

export interface ProfileInfo {
  id: string
  name: string
  tier?: 'haiku' | 'sonnet' | 'opus' | string
  health?: 'idle' | 'running' | 'success' | 'warning' | 'error' | 'paused' | string
}

/** profiles.list est un relais RPC live ; on normalise plusieurs formes possibles. */
export interface ProfilesResponse {
  profiles: ProfileInfo[]
  activeProfile: string | null
}

interface RawProfiles {
  profiles?: Array<string | { id?: string; name?: string; tier?: string; health?: string }>
  activeProfile?: string | null
  active?: string | null
}

function normalize(raw: RawProfiles): ProfilesResponse {
  const list = (raw.profiles ?? []).map((p): ProfileInfo => {
    if (typeof p === 'string') return { id: p, name: p }
    return {
      id: p.id ?? p.name ?? 'unknown',
      name: p.name ?? p.id ?? 'unknown',
      tier: p.tier,
      health: p.health,
    }
  })
  return { profiles: list, activeProfile: raw.activeProfile ?? raw.active ?? null }
}

export function useProfiles(): UseQueryResult<ProfilesResponse> {
  return useQuery({
    queryKey: ['profiles'],
    queryFn: async () => normalize(await apiJson<RawProfiles>('/profiles')),
    staleTime: 60_000,
  })
}

/** Bascule le profil actif (PUT /profiles/active) — mute ~/.ada.json côté serveur. */
export function useSwitchProfile() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (profile: string) =>
      apiJson<unknown>('/profiles/active', { method: 'PUT', body: JSON.stringify({ profile }) }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['profiles'] })
      qc.invalidateQueries({ queryKey: ['agents'] })
      qc.invalidateQueries({ queryKey: ['stats'] })
    },
  })
}

/** Crée/enregistre un profil (POST /profiles). */
export function useCreateProfile() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (input: { name: string; tier?: string }) =>
      apiJson<unknown>('/profiles', { method: 'POST', body: JSON.stringify(input) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['profiles'] }),
  })
}
