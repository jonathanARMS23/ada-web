'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { useShallow } from 'zustand/react/shallow'
import { useAdaStore } from '@/store/ada-store'
import { apiJson } from '@/lib/api'

/**
 * Catégories de ligne console (mappées aux classes cl-* du design).
 * `user` = tour utilisateur (instruction), rendu comme une conversation.
 */
export type LineKind = 'sys' | 'user' | 'agent' | 'output' | 'tool' | 'warn' | 'err' | 'tok'

export interface ConsoleLine {
  id: number
  kind: LineKind
  time?: string
  agent?: string
  text: string
  /** Tour auquel appartient la ligne (pour agréger les chunks d'output). */
  turn?: number
}

export interface SessionMetrics {
  status: 'idle' | 'running' | 'success' | 'error'
  tokens: number
  cost: number
  /** Numéro du tour courant (0 tant qu'aucun tour n'a démarré). */
  turn: number
  startedAt: number | null
  durationMs: number
}

/** Demande de permission émise par le backend, en attente de décision UI. */
export interface PermissionRequest {
  requestId: string
  tool: string
  input?: unknown
}

export type PermissionDecision = 'allow' | 'deny' | 'allow_always'

interface SessionResponse {
  sessionId: string
  resumed: boolean
}

/** Forme défensive d'un event WS générique (corr + payload faiblement typés). */
interface WsEvent {
  type: string
  corr?: { runId?: string | null; workspaceId?: string | null; conversationId?: string | null } | null
  payload?: Record<string, unknown>
}

function hhmmss(ts?: number): string {
  const d = ts ? new Date(ts) : new Date()
  return d.toTimeString().slice(0, 8)
}

const INITIAL: SessionMetrics = {
  status: 'idle',
  tokens: 0,
  cost: 0,
  turn: 0,
  startedAt: null,
  durationMs: 0,
}

function str(v: unknown, fallback = ''): string {
  return typeof v === 'string' ? v : v == null ? fallback : String(v)
}
function num(v: unknown, fallback = 0): number {
  return typeof v === 'number' && Number.isFinite(v) ? v : fallback
}

/**
 * Pilote une session Claude Code CONVERSATIONNELLE persistante — réplique exacte
 * de `ada launch` : un message → flux streamé → message de suivi dans la MÊME
 * session (mémoire continue), au lieu du comportement pipeline figé.
 *
 * Cycle de vie :
 *  - `launch(message, workspaceId, conversationId)` → POST /sessions → mémorise
 *    `sessionId` (le backend reprend automatiquement la session existante de la
 *    conversation si elle existe) → consomme les events `session.*` du WS.
 *  - `sendFollowUp(content)` → émet `{type:'task.message', sessionId, content}` sur
 *    le WS pour continuer la même session.
 *  - permissions : `pendingPermission` + `respondPermission(decision)` répondent à
 *    `task.permission_request` via `{type:'task.permission_response', requestId, decision}`.
 *
 * Le flux WS est centralisé (un seul socket, use-ada-ws). On lit `wsLastEvent` du
 * store et on émet via `wsSend`. Filtrage STRICT par sessionId actif (avec repli
 * sur conversationId) pour éviter toute fuite d'events entre conversations.
 */
export function useSessionStream(profile: string | null) {
  const { wsLastEvent, wsSend } = useAdaStore(
    useShallow((s) => ({ wsLastEvent: s.wsLastEvent, wsSend: s.wsSend })),
  )
  const [sessionId, setSessionId] = useState<string | null>(null)
  const [lines, setLines] = useState<ConsoleLine[]>([])
  const [metrics, setMetrics] = useState<SessionMetrics>(INITIAL)
  const [launching, setLaunching] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [pendingPermission, setPendingPermission] = useState<PermissionRequest | null>(null)

  const lineId = useRef(0)
  const sessionIdRef = useRef<string | null>(null)
  const conversationIdRef = useRef<string | null>(null)
  // Id de la ligne d'output assistant en cours d'agrégation, par tour.
  const outputLineByTurn = useRef<Map<number, number>>(new Map())
  const currentTurn = useRef(0)

  const push = useCallback(
    (kind: LineKind, text: string, opts?: { agent?: string; time?: number; turn?: number }): number => {
      const id = lineId.current++
      setLines((prev) => [
        ...prev,
        { id, kind, text, agent: opts?.agent, time: hhmmss(opts?.time), turn: opts?.turn },
      ])
      return id
    },
    [],
  )

  /** Concatène un chunk d'output assistant sur la ligne du tour courant (ou la crée). */
  const appendOutput = useCallback((turn: number, chunk: string) => {
    const existingId = outputLineByTurn.current.get(turn)
    if (existingId == null) {
      const id = lineId.current++
      outputLineByTurn.current.set(turn, id)
      setLines((prev) => [...prev, { id, kind: 'output', text: chunk, time: hhmmss(), turn }])
    } else {
      setLines((prev) =>
        prev.map((l) => (l.id === existingId ? { ...l, text: l.text + chunk } : l)),
      )
    }
  }, [])

  const reset = useCallback(() => {
    sessionIdRef.current = null
    conversationIdRef.current = null
    outputLineByTurn.current = new Map()
    currentTurn.current = 0
    setSessionId(null)
    setLines([])
    setMetrics(INITIAL)
    setError(null)
    setPendingPermission(null)
  }, [])

  /**
   * Pré-remplit la console avec l'historique persistant d'une conversation
   * (tours user/assistant), AVANT de reprendre la session. À appeler quand la
   * conversation change. `cid` rattache le filtrage WS à cette conversation.
   */
  const seedHistory = useCallback(
    (cid: string | null, history: { role: string; content: string; createdAt?: string }[]) => {
      sessionIdRef.current = null
      conversationIdRef.current = cid
      outputLineByTurn.current = new Map()
      currentTurn.current = 0
      lineId.current = 0
      setSessionId(null)
      setMetrics(INITIAL)
      setError(null)
      setPendingPermission(null)
      const seeded: ConsoleLine[] = history.map((m, i) => {
        const kind: LineKind =
          m.role === 'user'
            ? 'user'
            : m.role === 'assistant'
              ? 'output'
              : m.role === 'tool'
                ? 'tool'
                : m.role === 'error'
                  ? 'err'
                  : 'sys'
        return {
          id: lineId.current++,
          kind,
          text: m.content,
          time: m.createdAt ? hhmmss(new Date(m.createdAt).getTime()) : undefined,
          turn: i,
        }
      })
      setLines(seeded)
    },
    [],
  )

  const launch = useCallback(
    async (message: string, workspaceId: string, conversationId?: string) => {
      if (!profile) {
        setError('Aucun profil actif.')
        return
      }
      setLaunching(true)
      setError(null)
      conversationIdRef.current = conversationId ?? conversationIdRef.current
      setMetrics((m) => ({ ...m, status: 'running', startedAt: m.startedAt ?? Date.now() }))
      // Écho optimiste du tour utilisateur (le backend renverra session.message).
      push('user', message)
      try {
        const res = await apiJson<SessionResponse>('/sessions', {
          method: 'POST',
          body: JSON.stringify({ profile, workspaceId, conversationId, message }),
        })
        sessionIdRef.current = res.sessionId
        setSessionId(res.sessionId)
        if (res.resumed) push('sys', `▸ session reprise · ${res.sessionId}`)
      } catch (e) {
        const msg = (e as Error).message
        setError(msg)
        push('err', `✕ échec du lancement : ${msg}`)
        setMetrics((m) => ({ ...m, status: 'error' }))
      } finally {
        setLaunching(false)
      }
    },
    [profile, push],
  )

  /** Continue la session active avec un nouveau message (WS task.message). */
  const sendFollowUp = useCallback(
    (content: string) => {
      const sid = sessionIdRef.current
      if (!sid) {
        setError('Aucune session active.')
        return false
      }
      if (!wsSend) {
        setError('Connexion temps réel indisponible.')
        return false
      }
      push('user', content)
      setMetrics((m) => ({ ...m, status: 'running', startedAt: m.startedAt ?? Date.now() }))
      const ok = wsSend({ type: 'task.message', sessionId: sid, content })
      if (!ok) {
        setError('Message non transmis (socket fermé).')
        push('err', '✕ message non transmis (socket fermé)')
      }
      return ok
    },
    [wsSend, push],
  )

  /** Répond à une demande de permission backend (parité terminal allow/deny). */
  const respondPermission = useCallback(
    (decision: PermissionDecision) => {
      const req = pendingPermission
      setPendingPermission(null)
      if (!req) return
      push(decision === 'deny' ? 'warn' : 'sys', `▸ permission ${req.tool} → ${decision}`)
      wsSend?.({ type: 'task.permission_response', requestId: req.requestId, decision })
    },
    [pendingPermission, wsSend, push],
  )

  // Consomme les events WS de la session active (filtrage strict).
  useEffect(() => {
    const evt = wsLastEvent as unknown as WsEvent | null
    if (!evt) return
    const p = evt.payload ?? {}
    const evtSession = typeof p.sessionId === 'string' ? p.sessionId : null
    const evtConv = evt.corr?.conversationId ?? null
    const activeSession = sessionIdRef.current
    const activeConv = conversationIdRef.current

    // Filtre : on accepte l'event s'il cible la session active OU (à défaut de
    // session connue/sur l'event) la conversation active. Évite toute fuite.
    const matchesSession = activeSession != null && evtSession === activeSession
    const matchesConv = activeConv != null && evtConv != null && evtConv === activeConv
    if (!matchesSession && !matchesConv) return

    switch (evt.type) {
      case 'session.started': {
        const sid = evtSession
        if (sid && !sessionIdRef.current) {
          sessionIdRef.current = sid
          setSessionId(sid)
        }
        const mode = p.permissionMode ? ` · ${str(p.permissionMode)}` : ''
        push('sys', `▸ session ${str(p.profile, profile ?? '')}${mode}`)
        setMetrics((m) => ({ ...m, status: 'running', startedAt: m.startedAt ?? Date.now() }))
        break
      }
      case 'session.message': {
        // Écho serveur du tour utilisateur. On l'ignore si on l'a déjà poussé
        // optimistiquement (role user déjà rendu) ; on n'ajoute que les rôles non-user.
        const turn = num(p.turn, currentTurn.current)
        currentTurn.current = turn
        if (str(p.role) !== 'user') push('user', str(p.content), { turn })
        break
      }
      case 'session.output': {
        const turn = num(p.turn, currentTurn.current)
        currentTurn.current = turn
        appendOutput(turn, str(p.chunk))
        break
      }
      case 'session.tool':
        push('tool', `→ ${str(p.tool, 'tool')}${p.input != null ? ` ${JSON.stringify(p.input)}` : ''}`)
        break
      case 'session.turn_complete': {
        const turn = num(p.turn, currentTurn.current)
        const tokens = num(p.tokens)
        const cost = num(p.cost)
        push('tok', `✓ tour ${turn} · ${tokens.toLocaleString('fr-FR')} tok · $${cost.toFixed(2)}`)
        if (p.summary) push('sys', str(p.summary))
        setMetrics((m) => ({
          ...m,
          status: 'success',
          turn,
          tokens: m.tokens + tokens,
          cost: m.cost + cost,
          durationMs: m.startedAt ? Date.now() - m.startedAt : m.durationMs,
        }))
        break
      }
      case 'session.error':
        push('err', `✕ ${str(p.error, 'erreur session')}`)
        setError(str(p.error, 'erreur session'))
        setMetrics((m) => ({ ...m, status: 'error' }))
        break
      case 'session.closed':
        push('sys', `▸ session terminée${p.code != null ? ` (code ${str(p.code)})` : ''}`)
        setMetrics((m) => ({ ...m, status: m.status === 'error' ? 'error' : 'success' }))
        break
      case 'task.permission_request': {
        const requestId = str(p.requestId)
        if (requestId) {
          setPendingPermission({ requestId, tool: str(p.tool, 'outil'), input: p.input })
          push('warn', `⚠ permission demandée · ${str(p.tool, 'outil')}`)
        }
        break
      }
    }
  }, [wsLastEvent, push, appendOutput, profile])

  return {
    sessionId,
    lines,
    metrics,
    launch,
    sendFollowUp,
    respondPermission,
    pendingPermission,
    seedHistory,
    reset,
    launching,
    error,
  }
}
