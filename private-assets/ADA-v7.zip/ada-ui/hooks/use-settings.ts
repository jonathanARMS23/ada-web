'use client'

import { useMutation, useQuery, useQueryClient, type UseQueryResult } from '@tanstack/react-query'
import { apiJson } from '@/lib/api'

export interface AdaSettings {
  provider?: 'claude-code' | 'api' | string
  budget?: {
    dailyLimit?: number
    monthlyLimit?: number
    hourlyLimit?: number
    blockAtCap?: boolean
    [k: string]: unknown
  } | null
  obsidian?: {
    enabled?: boolean
    vaultPath?: string
    [k: string]: unknown
  } | null
  webhook?: {
    url?: string
    events?: string[]
    [k: string]: unknown
  } | null
  [k: string]: unknown
}

export function useSettings(): UseQueryResult<AdaSettings> {
  return useQuery({
    queryKey: ['settings'],
    queryFn: () => apiJson<AdaSettings>('/settings'),
    staleTime: 60_000,
  })
}

export function useUpdateSettings() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (patch: Partial<AdaSettings>) =>
      apiJson<AdaSettings>('/settings', { method: 'PUT', body: JSON.stringify(patch) }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['settings'] })
      qc.invalidateQueries({ queryKey: ['stats', 'budget'] })
    },
  })
}
