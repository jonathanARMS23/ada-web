'use client'

import { useQuery, type UseQueryResult } from '@tanstack/react-query'
import { apiJson } from '@/lib/api'

export interface TeamInfo {
  id: string
  name: string
  agents: string[]
  tier?: 'haiku' | 'sonnet' | 'opus' | string
  runs?: number
}

interface RawTeam {
  id?: string
  name?: string
  slug?: string
  agents?: string[] | string
  tier?: string
  runs?: number
}

function normalize(t: RawTeam): TeamInfo {
  const id = t.id ?? t.slug ?? t.name ?? 'unknown'
  const agents = Array.isArray(t.agents)
    ? t.agents
    : typeof t.agents === 'string'
      ? t.agents.split(/[·,]/).map((s) => s.trim()).filter(Boolean)
      : []
  return { id, name: t.name ?? id, agents, tier: t.tier, runs: t.runs }
}

export function useTeams(): UseQueryResult<TeamInfo[]> {
  return useQuery({
    queryKey: ['teams'],
    queryFn: async () => {
      const raw = await apiJson<{ teams?: RawTeam[] } | RawTeam[]>('/teams')
      const list = Array.isArray(raw) ? raw : (raw.teams ?? [])
      return list.map(normalize)
    },
    staleTime: 60_000,
  })
}
