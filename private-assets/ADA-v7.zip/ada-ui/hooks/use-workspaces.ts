'use client'

import {
  useMutation,
  useQuery,
  useQueryClient,
  type UseQueryResult,
} from '@tanstack/react-query'
import { apiJson, apiFetch } from '@/lib/api'

export interface Workspace {
  id: string
  slug: string
  name: string
  profile: string | null
  color: string | null
  description: string | null
  projectDir: string | null
  pinned: boolean
  archived: boolean
  createdAt: string
  updatedAt: string
  config?: Record<string, unknown>
}

export interface WorkspaceStats {
  conversations: number
  messages: number
  runs: number
  totalCost: number
  totalTokens: number
  activeRuns?: number
}

interface ListResponse {
  items: Workspace[]
  total: number
}

export function useWorkspaces(archived = false): UseQueryResult<ListResponse> {
  const qs = archived ? '?archived=true' : ''
  return useQuery({
    queryKey: ['workspaces', { archived }],
    queryFn: () => apiJson<ListResponse>(`/workspaces${qs}`),
    staleTime: 30_000,
  })
}

export function useWorkspaceStats(id: string | null): UseQueryResult<WorkspaceStats> {
  return useQuery({
    queryKey: ['workspace-stats', id],
    enabled: !!id,
    queryFn: () => apiJson<WorkspaceStats>(`/workspaces/${id}/stats`),
    staleTime: 15_000,
  })
}

export interface CreateWorkspaceInput {
  name: string
  profile?: string
  color?: string
  description?: string
}

export function useCreateWorkspace() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (input: CreateWorkspaceInput) =>
      apiJson<Workspace>('/workspaces', { method: 'POST', body: JSON.stringify(input) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['workspaces'] }),
  })
}

export function useUpdateWorkspace() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ id, patch }: { id: string; patch: Partial<CreateWorkspaceInput> & { pinned?: boolean; archived?: boolean } }) =>
      apiJson<Workspace>(`/workspaces/${id}`, { method: 'PATCH', body: JSON.stringify(patch) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['workspaces'] }),
  })
}

export function useDeleteWorkspace() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: async (id: string) => {
      const res = await apiFetch(`/workspaces/${id}`, { method: 'DELETE' })
      if (!res.ok && res.status !== 204) throw new Error(`Suppression échouée (${res.status})`)
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ['workspaces'] }),
  })
}
