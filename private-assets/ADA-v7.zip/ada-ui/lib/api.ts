import { useAdaStore } from '@/store/ada-store'

/**
 * Base ada-api-nest. NEXT_PUBLIC_ADA_API_URL inclut déjà le préfixe `/api`
 * (ex: http://localhost:3010/api). Les chemins passés aux helpers sont donc
 * relatifs à ce préfixe : `/auth/token`, `/stats/overview`, `/health`…
 */
export const ADA_API_BASE =
  process.env.NEXT_PUBLIC_ADA_API_URL ?? 'http://localhost:3010/api'

/** Origine ws(s):// dérivée du base (sans le préfixe /api). Le gateway est sur /ws. */
export const ADA_WS_ORIGIN = (() => {
  try {
    const u = new URL(ADA_API_BASE)
    const proto = u.protocol === 'https:' ? 'wss:' : 'ws:'
    return `${proto}//${u.host}`
  } catch {
    return 'ws://localhost:3010'
  }
})()

export interface ApiError extends Error {
  status: number
  code?: string
}

/**
 * fetch vers ada-api-nest avec Authorization: Bearer <adaApiToken> (lu hors-hook
 * via getState — utilisable dans queryFn/mutationFn). `path` commence par '/'.
 */
export async function apiFetch(path: string, init: RequestInit = {}): Promise<Response> {
  const token = useAdaStore.getState().adaApiToken
  const headers = new Headers(init.headers)
  if (token) headers.set('Authorization', `Bearer ${token}`)
  if (!headers.has('Content-Type') && init.body) headers.set('Content-Type', 'application/json')
  return fetch(`${ADA_API_BASE}${path}`, { ...init, headers })
}

/** Raccourci JSON : lève une ApiError typée si la réponse n'est pas ok. */
export async function apiJson<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await apiFetch(path, init)
  if (!res.ok) {
    const body = (await res.json().catch(() => ({}))) as { error?: string; message?: string }
    const err = new Error(body.message ?? res.statusText) as ApiError
    err.status = res.status
    err.code = body.error
    throw err
  }
  return res.json() as Promise<T>
}
