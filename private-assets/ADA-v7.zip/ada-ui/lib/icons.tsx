import type { SVGProps } from 'react'

/**
 * Jeu d'icônes inline (stroke 1.9, viewBox 24) porté depuis docs/design/export/js/ada.js.
 * Rendues comme composants React pour rester fidèles au design sans dépendance.
 */
const PATHS: Record<string, string> = {
  dashboard: 'M3 3h7v9H3zM14 3h7v5h-7zM14 12h7v9h-7zM3 16h7v5H3z',
  workspaces: 'M3 3h18v18H3zM3 9h18M9 21V9',
  agents: 'M12 2 4 6v6c0 5 3.4 7.7 8 10 4.6-2.3 8-5 8-10V6zM12 10m-2.2 0a2.2 2.2 0 1 0 4.4 0a2.2 2.2 0 1 0 -4.4 0M8.5 16a3.5 3.5 0 0 1 7 0',
  memory: 'M12 12m-3 0a3 3 0 1 0 6 0a3 3 0 1 0 -6 0M5 6m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0M19 7m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0M18 18m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0M6 18m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0M7 7l3 3M17 8l-2.5 2M16.5 16.5 14 14M8 16.5 10 14',
  mcp: 'M3 4h18v6H3zM3 14h18v6H3zM7 7h.01M7 17h.01',
  logs: 'M4 5h16M4 10h16M4 15h10M4 20h7',
  settings:
    'M12 12m-3 0a3 3 0 1 0 6 0a3 3 0 1 0 -6 0M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-2.9 1.2V21a2 2 0 0 1-4 0v-.1A1.7 1.7 0 0 0 6.8 19l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0-1.2-2.9H2a2 2 0 0 1 0-4h.1A1.7 1.7 0 0 0 5 6.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 2.9-1.2V2a2 2 0 0 1 4 0v.1A1.7 1.7 0 0 0 19 5l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0 1.2 2.9H21a2 2 0 0 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1.3z',
  search: 'M11 11m-7 0a7 7 0 1 0 14 0a7 7 0 1 0 -14 0M21 21l-4.3-4.3',
  sidebar: 'M3 3h18v18H3zM9 3v18',
  sun: 'M12 12m-4 0a4 4 0 1 0 8 0a4 4 0 1 0 -8 0M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4',
  moon: 'M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z',
  x: 'M18 6 6 18M6 6l12 12',
  chevron: 'M9 18l6-6-6-6',
  plus: 'M12 5v14M5 12h14',
  play: 'M6 4l14 8-14 8z',
  bolt: 'M13 2 3 14h7l-1 8 10-12h-7z',
  cost: 'M12 12m-9 0a9 9 0 1 0 18 0a9 9 0 1 0 -18 0M12 7v10',
  activity: 'M22 12h-4l-3 9L9 3l-3 9H2',
  check: 'M20 6 9 17l-5-5',
  filter: 'M22 3H2l8 9.5V19l4 2v-8.5z',
  refresh: 'M3 12a9 9 0 0 1 15-6.7L21 8M21 3v5h-5M21 12a9 9 0 0 1-15 6.7L3 16M3 21v-5h5',
  clock: 'M12 12m-9 0a9 9 0 1 0 18 0a9 9 0 1 0 -18 0M12 7v5l3 2',
  layers: 'm12 2 9 5-9 5-9-5zM3 12l9 5 9-5M3 17l9 5 9-5',
  chart: 'M3 3v18h18M7 14l3-4 3 2 4-6',
  shield: 'M12 2 4 6v6c0 5 3.4 7.7 8 10 4.6-2.3 8-5 8-10V6z',
  alert: 'm12 3 9 16H3z',
  server: 'M3 4h18v6H3zM3 14h18v6H3zM7 7h.01M7 17h.01',
  book: 'M4 19.5A2.5 2.5 0 0 1 6.5 17H20M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z',
  tag: 'M20.6 13.4 12 22l-9-9V3h10l7.6 7.6a2 2 0 0 1 0 2.8zM7 7h.01',
  pause: 'M7 4h3v16H7zM14 4h3v16h-3z',
  download: 'M12 3v12m0 0 4-4m-4 4-4-4M5 21h14',
  inbox: 'M22 12h-6l-2 3h-4l-2-3H2M5.5 5h13l3.5 7v6a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1v-6z',
}

export type IconName = keyof typeof PATHS | string

export function Icon({ name, ...props }: { name: IconName } & SVGProps<SVGSVGElement>) {
  const d = PATHS[name] ?? ''
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.9}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      {...props}
    >
      <path d={d} />
    </svg>
  )
}
