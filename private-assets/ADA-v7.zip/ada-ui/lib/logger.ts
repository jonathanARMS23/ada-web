import { getActiveSpan } from './telemetry'

/** Catégories d'erreur (anciennement dans error-handler, supprimé en P0). */
type ErrorCategory = 'validation' | 'auth' | 'network' | 'upstream' | 'internal'

type Level = 'info' | 'warn' | 'error'

type LogEntry = {
  level:      Level
  msg:        string
  ts:         string
  category?:  ErrorCategory
  requestId?: string
  traceId?:   string
  spanId?:    string
  [k: string]: unknown
}

function log(level: Level, msg: string, meta?: Record<string, unknown>) {
  const entry: LogEntry = { level, msg, ts: new Date().toISOString(), ...meta }
  const span = getActiveSpan()
  if (span?.isRecording()) {
    const ctx = span.spanContext()
    entry.traceId = ctx.traceId
    entry.spanId  = ctx.spanId
  }
  process.stderr.write(JSON.stringify(entry) + '\n')
}

export const logger = {
  info:  (msg: string, meta?: Record<string, unknown>) => log('info',  msg, meta),
  warn:  (msg: string, meta?: Record<string, unknown>) => log('warn',  msg, meta),
  error: (msg: string, meta?: Record<string, unknown>) => log('error', msg, meta),
}

/**
 * Returns a contextual logger that merges a fixed `context` object into every
 * log entry. Useful for attaching `requestId`, `profile`, etc. at the call site.
 *
 * @example
 *   const log = createLogger({ requestId: req.headers.get('x-request-id') })
 *   log.info('processing run', { runId })
 */
export function createLogger(context: Record<string, unknown>) {
  return {
    info:  (msg: string, meta?: Record<string, unknown>) => logger.info(msg,  { ...context, ...meta }),
    warn:  (msg: string, meta?: Record<string, unknown>) => logger.warn(msg,  { ...context, ...meta }),
    error: (msg: string, meta?: Record<string, unknown>) => logger.error(msg, { ...context, ...meta }),
  }
}
