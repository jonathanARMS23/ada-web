import type { NextConfig } from 'next'

const securityHeaders = [
  { key: 'X-Content-Type-Options', value: 'nosniff' },
  { key: 'X-Frame-Options', value: 'DENY' },
  { key: 'Referrer-Policy', value: 'strict-origin' },
  { key: 'X-XSS-Protection', value: '1; mode=block' },
]

const config: NextConfig = {
  output: 'standalone',
  serverExternalPackages: ['node-pty', 'chokidar'],
  async headers() {
    return [{ source: '/(.*)', headers: securityHeaders }]
  },
}

export default config
