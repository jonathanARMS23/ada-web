import crypto from 'crypto'
import { NextRequest, NextResponse } from 'next/server'

/**
 * Proxy (ex-middleware Next 16) : pose un nonce CSP par requête + l'en-tête CSP.
 * La refonte P0 a retiré le Canal A (route handlers /api/* FS) : toutes les
 * données passent désormais par ada-api-nest (Bearer JWT côté client), donc plus
 * aucune authentification de route /api/* à gérer ici.
 *
 * connect-src autorise ada-api-nest en HTTP + WebSocket (localhost / 127.0.0.1).
 */
function buildCsp(nonce: string): string {
  const isDev = process.env.NODE_ENV !== 'production'
  return [
    "default-src 'self'",
    `script-src 'self' 'nonce-${nonce}'${isDev ? " 'unsafe-eval' 'unsafe-inline'" : ''}`,
    "style-src 'self' 'unsafe-inline'",
    "connect-src 'self' ws://127.0.0.1:* wss://127.0.0.1:* http://127.0.0.1:* ws://localhost:* wss://localhost:* http://localhost:*",
    "img-src 'self' data:",
    "font-src 'self' data:",
    "frame-ancestors 'none'",
  ].join('; ')
}

export function proxy(req: NextRequest) {
  const nonce = Buffer.from(crypto.randomUUID()).toString('base64')
  const csp = buildCsp(nonce)

  const reqHeaders = new Headers(req.headers)
  reqHeaders.set('x-nonce', nonce)
  const res = NextResponse.next({ request: { headers: reqHeaders } })
  res.headers.set('Content-Security-Policy', csp)
  return res
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'],
}
