'use client'

import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export interface AdaWsEvent {
  type: string
  runId?: string
  phaseId?: string
  log?: string
  conversationId?: string
  message?: Record<string, unknown>
  workspaceId?: string
  pipeline?: string
  cost?: number
  summary?: string
  status?: string
  ts?: string
  [key: string]: unknown
}

/** Message sortant émis sur le WebSocket (task.message, task.permission_response…). */
export interface AdaWsOutbound {
  type: string
  [key: string]: unknown
}

/** Émetteur WS exposé par use-ada-ws ; renvoie true si le message a été envoyé. */
export type AdaWsSend = (msg: AdaWsOutbound) => boolean

interface ADAStore {
  activeProfile: string | null
  authStatus: 'authenticated' | 'unauthenticated' | 'unknown'
  uiToken: string | null
  adaApiToken: string | null
  adaApiConnected: boolean
  activeWorkspaceId: string | null
  wsLastEvent: AdaWsEvent | null
  wsSend: AdaWsSend | null
  setActiveProfile: (id: string) => void
  setAuthStatus: (s: ADAStore['authStatus']) => void
  setUiToken: (t: string | null) => void
  setAdaApiToken: (t: string | null) => void
  setAdaApiConnected: (v: boolean) => void
  setActiveWorkspaceId: (id: string | null) => void
  setWsLastEvent: (e: AdaWsEvent | null) => void
  setWsSend: (fn: AdaWsSend | null) => void
}

export const useAdaStore = create<ADAStore>()(
  persist(
    (set) => ({
      activeProfile: null,
      authStatus: 'unknown',
      uiToken: null,
      adaApiToken: null,
      adaApiConnected: false,
      activeWorkspaceId: null,
      wsLastEvent: null,
      wsSend: null,
      setActiveProfile: (id) => set({ activeProfile: id }),
      setAuthStatus: (s) => set({ authStatus: s }),
      setUiToken: (t) => set({ uiToken: t }),
      setAdaApiToken: (t) => set({ adaApiToken: t }),
      setAdaApiConnected: (v) => set({ adaApiConnected: v }),
      setActiveWorkspaceId: (id) => set({ activeWorkspaceId: id }),
      setWsLastEvent: (e) => set({ wsLastEvent: e }),
      setWsSend: (fn) => set({ wsSend: fn }),
    }),
    {
      name: 'ada-ui-store',
      partialize: (s) => ({
        activeProfile: s.activeProfile,
        activeWorkspaceId: s.activeWorkspaceId,
        // adaApiToken intentionnellement exclu — JWT stocké en mémoire uniquement
      }),
      skipHydration: true,
    },
  ),
)
