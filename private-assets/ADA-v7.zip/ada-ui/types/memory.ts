export interface MemoryGraphNode {
  id: string
  type: 'agent' | 'phase' | 'lesson'
  label: string
  group: string  // category for agents, 'phase', 'episodic'/'semantic'/'procedural' for memories
  val: number    // node size (1–15)
  // agent-specific
  successes?: number
  failures?: number
  efficiency?: number
  meanTokens?: number
  // lesson/memory-specific
  excerpt?: string
}

export interface MemoryGraphLink {
  source: string
  target: string
  value: number  // 0–1 strength
}

export interface MemoryGraphData {
  nodes: MemoryGraphNode[]
  links: MemoryGraphLink[]
  stats: {
    totalAgents: number
    totalPhases: number
    totalLessons: number
    totalConnections: number
  }
}
