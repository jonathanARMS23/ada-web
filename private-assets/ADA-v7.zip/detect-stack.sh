#!/usr/bin/env bash
# =============================================================
# detect-stack.sh — Détection automatique de stack
#
# Lit les fichiers du projet courant et produit un bloc compact
# injecté dans context.md — lu une seule fois au démarrage.
#
# Coût : ~50 tokens (une seule injection, pas répétée).
# =============================================================

set -e

PROJECT_DIR="${1:-$(pwd)}"
CONFIG_DIR="${CLAUDE_CONFIG_DIR:-$HOME/.claude}"
PROJECT_ID="${AI_DEV_PROJECT:-$(basename "$PROJECT_DIR")}"
CONTEXT_FILE="$CONFIG_DIR/.claude/memory/projects/$PROJECT_ID/context.md"

# ── Détection ────────────────────────────────────────────────

BACKEND=""
FRONTEND=""
DATABASE=""
MOBILE=""
INFRA=""
TEST=""
PROFILE=""

# package.json (Node.js)
PKG="$PROJECT_DIR/package.json"
if [ -f "$PKG" ]; then
  deps=$(cat "$PKG" 2>/dev/null)

  echo "$deps" | grep -q '"@nestjs/core"'      && BACKEND="NestJS"
  echo "$deps" | grep -q '"next"'              && FRONTEND="Next.js"
  echo "$deps" | grep -q '"react-native"'      && MOBILE="React Native"
  echo "$deps" | grep -q '"expo"'              && MOBILE="React Native + Expo"
  echo "$deps" | grep -q '"@prisma/client"'    && DATABASE="${DATABASE} Prisma"
  echo "$deps" | grep -q '"typeorm"'           && DATABASE="${DATABASE} TypeORM"
  echo "$deps" | grep -q '"@supabase/supabase-js"' && DATABASE="${DATABASE} Supabase"
  echo "$deps" | grep -q '"jest"'              && TEST="Jest"
  echo "$deps" | grep -q '"vitest"'            && TEST="Vitest"
  echo "$deps" | grep -q '"playwright"'        && TEST="${TEST} Playwright"
  echo "$deps" | grep -q '"tailwindcss"'       && FRONTEND="${FRONTEND} + Tailwind"
  echo "$deps" | grep -q '"@shadcn/ui"\|shadcn' && FRONTEND="${FRONTEND} + shadcn/ui"
fi

# requirements.txt / pyproject.toml (Python)
if [ -f "$PROJECT_DIR/requirements.txt" ] || [ -f "$PROJECT_DIR/pyproject.toml" ]; then
  PY_DEPS=$(cat "$PROJECT_DIR/requirements.txt" "$PROJECT_DIR/pyproject.toml" 2>/dev/null || true)
  echo "$PY_DEPS" | grep -qi "djangorestframework\|djangorestf" && BACKEND="DRF"
  echo "$PY_DEPS" | grep -qi "django"   && [ -z "$BACKEND" ] && BACKEND="Django"
  echo "$PY_DEPS" | grep -qi "fastapi"  && BACKEND="FastAPI"
  echo "$PY_DEPS" | grep -qi "celery"   && BACKEND="${BACKEND} + Celery"
  echo "$PY_DEPS" | grep -qi "pytest"   && TEST="pytest"
fi

# Prisma schema
if [ -f "$PROJECT_DIR/prisma/schema.prisma" ]; then
  SCHEMA=$(cat "$PROJECT_DIR/prisma/schema.prisma" 2>/dev/null)
  echo "$SCHEMA" | grep -q 'provider.*postgresql' && DATABASE="${DATABASE} PostgreSQL"
  echo "$SCHEMA" | grep -q 'provider.*mysql'      && DATABASE="${DATABASE} MySQL"
  echo "$SCHEMA" | grep -q 'provider.*sqlite'     && DATABASE="${DATABASE} SQLite"
fi

# Django models / settings
if [ -f "$PROJECT_DIR/manage.py" ]; then
  DJANGO_SETTINGS=$(find "$PROJECT_DIR" -name "settings.py" 2>/dev/null | head -1)
  if [ -n "$DJANGO_SETTINGS" ]; then
    cat "$DJANGO_SETTINGS" | grep -q "postgresql\|psycopg" && DATABASE="${DATABASE} PostgreSQL"
  fi
fi

# Supabase
[ -d "$PROJECT_DIR/supabase" ] && DATABASE="${DATABASE} Supabase"

# Docker
[ -f "$PROJECT_DIR/Dockerfile" ] || [ -f "$PROJECT_DIR/docker-compose.yml" ] && INFRA="Docker"
[ -f "$PROJECT_DIR/.github/workflows" ] || ls "$PROJECT_DIR/.github/workflows/"*.yml 2>/dev/null | head -1 | grep -q "." && INFRA="${INFRA} GitHub Actions"

# iOS / Android natif
[ -d "$PROJECT_DIR/ios" ] || [ -f "$PROJECT_DIR/Podfile" ]     && MOBILE="${MOBILE} iOS/Swift"
[ -d "$PROJECT_DIR/android" ] && [ -f "$PROJECT_DIR/android/build.gradle" ] && MOBILE="${MOBILE} Android/Kotlin"

# ── Déduction du profil optimal ──────────────────────────────

if [ -n "$BACKEND" ] && [ -n "$FRONTEND" ]; then
  echo "$BACKEND" | grep -qi "nestjs" && PROFILE="fullstack"
  echo "$BACKEND" | grep -qi "drf\|django" && PROFILE="fullstack-drf"
elif [ -n "$MOBILE" ]; then
  echo "$MOBILE" | grep -qi "react native\|expo" && PROFILE="mobile-rn"
  echo "$MOBILE" | grep -qi "ios\|android" && PROFILE="mobile-native"
elif [ -n "$FRONTEND" ] && [ -z "$BACKEND" ]; then
  PROFILE="frontend"
elif [ -n "$BACKEND" ] && [ -z "$FRONTEND" ]; then
  echo "$BACKEND" | grep -qi "nestjs" && PROFILE="backend-nestjs"
  echo "$BACKEND" | grep -qi "drf\|django" && PROFILE="backend-drf"
fi

[ -z "$PROFILE" ] && PROFILE="fullstack"

# ── Nettoyer les espaces ──────────────────────────────────────
BACKEND=$(echo "$BACKEND" | xargs)
FRONTEND=$(echo "$FRONTEND" | xargs)
DATABASE=$(echo "$DATABASE" | xargs)
MOBILE=$(echo "$MOBILE" | xargs)
INFRA=$(echo "$INFRA" | xargs)
TEST=$(echo "$TEST" | xargs)

# ── Écrire dans context.md ───────────────────────────────────
mkdir -p "$(dirname "$CONTEXT_FILE")"

STACK_BLOCK="## Stack détectée (auto)
- Backend  : ${BACKEND:-Non détecté}
- Frontend : ${FRONTEND:-Non détecté}
- Database : ${DATABASE:-Non détecté}
- Mobile   : ${MOBILE:-Non détecté}
- Infra    : ${INFRA:-Non détecté}
- Tests    : ${TEST:-Non détecté}
- Profil   : $PROFILE"

# Remplacer le bloc Stack s'il existe, sinon l'ajouter
if [ -f "$CONTEXT_FILE" ]; then
  if grep -q "## Stack détectée" "$CONTEXT_FILE"; then
    # Remplacer le bloc existant
    python3 - << PYEOF
import re
with open('$CONTEXT_FILE', 'r') as f:
    content = f.read()
new_block = """$STACK_BLOCK"""
content = re.sub(r'## Stack détectée.*?(?=\n## |\Z)', new_block + '\n', content, flags=re.DOTALL)
with open('$CONTEXT_FILE', 'w') as f:
    f.write(content)
PYEOF
  else
    # Insérer après le titre
    echo "" >> "$CONTEXT_FILE"
    echo "$STACK_BLOCK" >> "$CONTEXT_FILE"
  fi
else
  # Créer le context.md
  cat > "$CONTEXT_FILE" << CTXEOF
# Context — $(echo "$PROJECT_ID" | tr '[:lower:]' '[:upper:]')

$STACK_BLOCK

## Dernières modifications

## Décisions récentes

## Blockers actifs
CTXEOF
fi

# Sauvegarder le profil actif
mkdir -p "$CONFIG_DIR/.claude/teams"
echo "$PROFILE" > "$CONFIG_DIR/.claude/teams/active-profile.txt"

# Output pour tmux-dev.sh
echo "✓ Stack détectée : ${BACKEND:-?} / ${FRONTEND:-?} / ${DATABASE:-?}"
echo "✓ Profil activé  : $PROFILE"
