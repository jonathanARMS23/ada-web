#!/bin/sh
# Entrypoint for ada-api container.
# Runs as root to fix volume directory permissions, then drops to 'ada' user.
# Named volumes are created by Docker with root:root ownership — this ensures
# the 'ada' process can write to /data (SQLite) and /ipc (Unix socket).
set -e

chown -R ada:ada /data /ipc 2>/dev/null || true

exec su-exec ada "$@"
