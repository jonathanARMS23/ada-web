# ADR-001 — Unified Coordinator (State Machine d'orchestration)

**Date :** 2026-05-10
**Status :** Accepted
**Auteur :** Jonathan Dune / AI Dev Assistant

---

## Contexte

Avant cette décision, l'orchestrateur gérait l'ordre d'exécution des agents de façon purement
textuelle dans `feature.md` : un prompt linéaire décrivant "étape 1 → étape 2 → ...".

**Problèmes identifiés :**
- Aucun suivi d'état entre les agents — si un agent échoue au milieu d'un `/feature`,
  l'orchestrateur ne sait pas où il en est
- Pas de retry logic — une erreur transitoire (timeout MCP, API down) interrompt tout
- Pas de gestion des dépendances — rien n'empêche de lancer `backend` avant que `schema` soit terminé
- Zéro observabilité — impossible de savoir quelle phase a duré combien de temps, quelles ont échoué
- Agents nommés dans un ordre fixe non déclaratif — changer l'ordre nécessite une réécriture du prompt

**Inspiration :** [ruflo](../ruflo/) — `unified-coordinator.ts` (ADR-003) qui consolide 4 systèmes
legacy en un seul coordinateur hiérarchique avec domains, topology manager, et consensus engines.

---

## Décision

Implémenter un **Unified Coordinator** composé de :

### 1. `coordinator/pipelines.json` — DAG déclaratif

Chaque commande (`feature`, `review`, `db-migrate`, `test`) est définie comme un DAG :
- `phases[]` : liste ordonnée avec `depends`, `agent`, `required`, `maxRetries`, `stopOnFailure`
- `onFailure` : comportement global (`stop` | `continue`)

Le DAG est la source de vérité — modifier l'ordre = modifier `pipelines.json`, pas les prompts.

### 2. `coordinator/run.js` — State machine Node.js

CLI qui gère le cycle de vie d'un run :
```
initialized → running → completed | failed | completed_with_errors
```

Par phase :
```
pending → running → completed | failed | skipped | retrying
```

État persisté en JSON dans `.claude/runs/<runId>/state.json` — survit aux restarts Claude Code.

### 3. Architecture Domain-Based (orchestrateur)

Inspiré du pattern Queen → Domain → Specialist de ruflo, les agents sont regroupés en domaines :

```
QUEEN (orchestrateur)
  ├── Domain DATA    → db
  ├── Domain BACKEND → nestjs · drf · tester
  ├── Domain FRONTEND → nextjs · react-native · android · swift
  └── Domain QUALITY  → reviewer · devops
```

Le routing n'est plus basé sur des mots-clés du prompt (table statique) mais sur le **domaine
fonctionnel** de la tâche.

---

## Conséquences

### Positives
- **Traçabilité** : chaque run a un ID, un état JSON, des timestamps par phase
- **Retry ciblé** : un timeout MCP sur `backend` ne relance que `backend`, pas tout le pipeline
- **Dépendances explicites** : `frontend` ne peut pas démarrer sans `backend` = `completed`
- **Visibilité** : `node run.js status <runId>` donne l'état complet en un coup
- **Extensible** : ajouter un agent = ajouter une phase dans `pipelines.json`

### Négatives / Trade-offs
- **Overhead initial** : `node run.js init/start/done` à appeler à chaque phase — 3 commandes supplémentaires par phase
- **Complexité accrue** : l'orchestrateur doit gérer les runIds entre les étapes
- **Pas de parallélisme** : le DAG est exécuté séquentiellement (pas de phases parallèles)
  → Acceptable pour un utilisateur solo ; à revisiter si multi-dev

### Futures améliorations (non dans cette ADR)
- Phases parallèles (frontend + tests) via `Promise.all` simulé dans l'orchestrateur
- Thompson Sampling pour choisir l'agent optimal par phase (ADR-002 — Phase 4)
- ReasoningBank : stocker les trajectoires des runs passés pour informer les prochains (Phase 5)

---

## Alternatives considérées

### A. Prompt linéaire amélioré (rejeté)
Garder la liste d'étapes dans le prompt mais ajouter des checkboxes markdown.
→ Rejeté : pas de persistance, pas de retry, pas d'observabilité.

### B. LangGraph StateGraph (rejeté pour l'instant)
Implémenter un vrai graphe avec LangGraph pour la state machine.
→ Rejeté : overhead de dépendances (Python, LangGraph, infra) injustifié pour un usage solo.
→ À reconsidérer si le projet évolue vers un système multi-utilisateurs.

### C. Coordination via fichiers Markdown (rejeté)
Stocker l'état dans des fichiers `.md` (comme la mémoire).
→ Rejeté : non structuré, difficile à parser programmatiquement, pas de validation de schéma.

---

## Fichiers impactés

```
.claude/coordinator/
  ├── pipelines.json      [NEW] DAG des pipelines
  └── run.js              [NEW] CLI state machine

.claude/agents/orchestrator/CLAUDE.md   [MODIFIED] Protocol domain-based + state machine
.claude/commands/feature.md             [MODIFIED] Utilise coordinator init/start/done/fail
```

---

## Exemple d'usage complet

```bash
# 1. Démarrer un run
node ~/.claude/coordinator/run.js init feature "user-auth" --backend nestjs
# → Retourne : feature-user-auth-20260510-1430

# 2. Exécuter chaque phase
node run.js start feature-user-auth-20260510-1430 schema
# [déléguer à db agent] ...
node run.js done feature-user-auth-20260510-1430 schema "table users + sessions créées"

node run.js start feature-user-auth-20260510-1430 specs
# [déléguer à tester agent] ...
node run.js done feature-user-auth-20260510-1430 specs "12 specs, 3 fichiers"

# 3. Si un agent échoue
node run.js fail feature-user-auth-20260510-1430 backend "TypeORM schema mismatch" --retry
node run.js start feature-user-auth-20260510-1430 backend   # retry

# 4. Consulter l'état
node run.js status feature-user-auth-20260510-1430
```

**Output de `status` :**
```
Run: feature-user-auth-20260510-1430
Feature: user-auth  [RUNNING]  245s
Pipeline: feature  Backend: nestjs

  ✓ Schéma DB + migration   [db]  42s
    ↳ table users + sessions créées
  ✓ Specs TDD (RED)          [tester]  31s
    ↳ 12 specs, 3 fichiers
  ● Implémentation backend   [nestjs]
  ○ Implémentation frontend  [nextjs]
  ○ Vérification coverage    [tester]
  ○ Code review final        [reviewer]
  – Déploiement staging      [devops]  (skipped: --no-deploy)
```
