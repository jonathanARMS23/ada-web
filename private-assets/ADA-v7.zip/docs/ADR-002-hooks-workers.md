# ADR-002 — Hooks System & Background Workers

**Date :** 2026-05-10
**Status :** Accepted
**Auteur :** Jonathan Dune / AI Dev Assistant

---

## Contexte

Après la Phase 1 (stabilisation) et la Phase 2 (state machine), le système avait un seul
hook PostToolUse (`memory-manager.js`) qui capturait les fichiers écrits. Il manquait :

- Aucune interception des commandes Bash (git, tests, migrations)
- Aucun garde de sécurité dynamique (au-delà de la deny list statique de settings.json)
- Zéro analyse automatique post-commit ou post-test
- Mémoire qui grossit indéfiniment sans consolidation
- Aucune extraction de learnings entre sessions

**Inspiration :** [ruflo](../ruflo/) implémente 27 hooks + 12 background workers.
Le principe clé est la séparation : **les hooks sont synchrones et légers** (décision/log uniquement),
**les workers sont asynchrones et lourds** (analyse, consolidation, apprentissage).

---

## Décision

### Architecture en deux couches

```
CLAUDE CODE EVENT
       │
   [HOOK — sync, <2s]
       │
   Décision + log léger
       │
   Dispatch worker (fire-and-forget)
       │
       └──→ [WORKER — async, background]
                 │
              Analyse lourde
              Écriture mémoire
              Pas de blocage
```

### Hooks implémentés (3 nouveaux + 1 existant)

| Hook | Event Claude Code | Timeout | Rôle |
|------|-------------------|---------|------|
| `memory-manager.js` | PostToolUse Write/Edit | 3s | Persistance mémoire (existant) |
| `pre-bash.js` | PreToolUse Bash | 2s | Garde sécurité + log commandes |
| `post-bash.js` | PostToolUse Bash | 3s | Détection événements + dispatch workers |
| `session-end.js` | Stop | 3s | Checkpoint session + dispatch consolidate |

### Workers implémentés (4)

| Worker | Déclenché par | Fréquence | Rôle |
|--------|---------------|-----------|------|
| `testgaps.js` | post-bash (test failures) | À chaque failure | Identifier fichiers sans tests |
| `audit.js` | post-bash (git commit) | À chaque commit | Scan sécurité OWASP rapide |
| `consolidate.js` | session-end (mémoire > seuil) | Toutes 10 réponses si besoin | Déduplication + archivage |
| `ultralearn.js` | session-end + post-bash push | Toutes 20 réponses | Extraction insights + do/don't |

### Règles de comportement des hooks

**Jamais bloquer Claude Code :**
- Tous les hooks ont un timeout de sécurité (2-3s max)
- En cas de crash : exit 0 + allow (jamais exit 1 qui bloque)
- Les erreurs sont loggées dans `logs/hook.log`, pas remontées

**PreToolUse — Protocole de décision :**
- Exit 0 + `{"decision": "allow"}` → autoriser
- Exit 0 + `{"decision": "block", "reason": "..."}` → bloquer avec raison
- Jamais de blocage si le hook plante

**Workers — Totalement async :**
- Spawn avec `detached: true, stdio: 'ignore'`
- `child.unref()` immédiat — le hook termine sans attendre le worker
- Workers écrivent uniquement dans `memory/` et `logs/`
- Workers sont idempotents (relancer = même résultat)

---

## Registre des logs

```
.claude/logs/
  commands.log      ← toutes les commandes Bash (pre-bash.js)
  workers.log       ← dispatches de workers
  sessions.log      ← checkpoints par réponse
  consolidate.log   ← historique consolidations
  ultralearn.log    ← historique extractions
  git-push.log      ← historique git push
  docker-builds.log ← historique builds Docker

.claude/memory/projects/<project>/
  git-log.md        ← commits avec SHA + message
  test-results.log  ← résultats de tests avec coverage
  migrations.log    ← migrations appliquées
  testgaps.md       ← rapport gaps de tests (mis à jour par worker)
  audit.md          ← rapport sécurité (mis à jour par worker)
  build-errors.log  ← erreurs TypeScript

.claude/memory/global/
  insights.md       ← learnings distillés (ultralearn)
  decisions.md      ← décisions d'architecture (memory-manager)
  patterns.md       ← patterns de code (memory-manager)
  errors.md         ← bugs et fixes (memory-manager)
```

---

## Règles de sécurité implémentées dans pre-bash.js

| Règle | Pattern | Sévérité |
|-------|---------|----------|
| rm -rf non ciblé | `rm -rf` sur chemin non temporaire | BLOCK |
| Force push | `git push --force` sauf staging | BLOCK |
| Redirection système | `>` vers `/etc/`, `/usr/`, `~/` | BLOCK |
| Pipe curl → exec | `curl | bash|sh|node|python` | BLOCK |
| chmod 777 non-script | `chmod 777` sur non-`.sh` | BLOCK |
| DROP en production | `DROP TABLE/DATABASE` hors test/dev | BLOCK |
| TRUNCATE en production | `TRUNCATE TABLE` hors test/dev | BLOCK |
| Export secret | `export SECRET_KEY=...` en shell | BLOCK |

---

## Règles de sécurité dans le worker audit.js

| Règle OWASP | ID | Sévérité |
|-------------|-----|----------|
| Injection SQL (concaténation) | SQL_INJECTION | CRITICAL |
| Secret hardcodé | HARDCODED_SECRET | CRITICAL |
| JWT sans vérification | JWT_NO_VERIFY | HIGH |
| eval() / exec() dynamique | UNSAFE_EVAL | HIGH |
| Math.random() pour secrets | WEAK_RANDOM | HIGH |
| innerHTML dynamique | XSS_INNERHTML | HIGH |
| Path traversal | PATH_TRAVERSAL | HIGH |
| CORS wildcard | CORS_WILDCARD | MEDIUM |
| Logs avec données sensibles | SENSITIVE_LOG | MEDIUM |
| RLS Supabase manquante | RLS_MISSING | MEDIUM |

---

## Conséquences

### Positives
- **Zéro friction** : les hooks sont invisibles, Claude Code continue normalement
- **Observabilité** : tout est loggé (`logs/commands.log`, `logs/workers.log`)
- **Sécurité proactive** : audit automatique après chaque commit
- **Tests automatiques** : testgaps identifie les fichiers sans tests sans action manuelle
- **Mémoire saine** : consolidate évite la croissance infinie des fichiers mémoire
- **Apprentissage continu** : ultralearn distille les patterns de la semaine

### Négatives / Trade-offs
- **Overhead I/O** : chaque Bash lance pre-bash.js et post-bash.js — ~5-20ms par commande
  → Acceptable sur machine dev, à monitorer si ça ralentit
- **Workers en background** : pas de feedback immédiat sur leur résultat
  → Lire `memory/projects/<project>/testgaps.md` ou `audit.md` après coup
- **Faux positifs possibles** dans audit.js (regex → pas d'AST parsing)
  → Toujours vérifier manuellement avant de corriger

### Futures améliorations (Phase 4+)
- Thompson Sampling routing : utiliser `logs/commands.log` pour détecter quels agents performent mieux
- Worker `predict.js` : précharger le contexte des fichiers susceptibles d'être édités prochainement
- Worker `document.js` : générer automatiquement les docstrings manquantes

---

## Mapping ruflo → AI Dev Assistant

| Concept ruflo | Notre équivalent | Différence |
|---------------|------------------|------------|
| 27 hooks | 4 hooks (pre-bash, post-edit, post-bash, session-end) | Adapté aux 3 events Claude Code |
| 12 background workers | 4 workers (testgaps, audit, consolidate, ultralearn) | Pragmatique, extensible |
| HNSW vector search | Jaccard similarity (consolidate.js) | Pas de dépendance externe |
| SONA adaptation loop | ultralearn.js (term frequency + patterns) | Distillation MD, pas ML |
| Thompson Sampling | À venir (Phase 4) | — |
| ReasoningBank trajectoires | À venir (Phase 5) | — |
