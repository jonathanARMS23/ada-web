# ADR-003 — Thompson Sampling Router (Routing adaptatif)

**Date :** 2026-05-10
**Status :** Accepted
**Auteur :** Jonathan Dune / AI Dev Assistant

---

## Contexte

Avant cette décision, le routing des agents était **statique** : une table de mots-clés dans
`CLAUDE.md` mappait chaque prompt vers un profil fixe (ex: "nestjs" → agent `nestjs`).

**Problèmes :**
- Pas d'apprentissage — si l'agent `drf` performe mieux sur un type de projet, rien ne s'adapte
- Routing binaire — aucune notion de confiance ou d'exploration
- Pas de trace — impossible de savoir pourquoi un agent a été choisi
- Choix `nestjs` vs `drf` toujours identique quelle que soit l'historique du projet

**Observation :** ruflo utilise Thompson Sampling (multi-armed bandit) pour le routing 3-tier
Haiku/Sonnet/Opus (`llm-hooks.ts`). Le même principe s'applique au choix d'agent.

---

## Décision

Implémenter un **Thompson Sampling Router** dans `coordinator/router.js`.

### Algorithme

Pour chaque `(phaseType, agent)`, maintenir un prior **Beta(α, β)** :
- α = nombre de succès + 1 (prior optimiste)
- β = nombre d'échecs + 1

**Pour router une tâche :**
1. Pour chaque agent candidat de la phase, sample `θ_i ~ Beta(α_i, β_i)`
2. Choisir l'agent avec le `θ` le plus élevé

**Sur résultat :**
- Succès → `α++` (via `run.js done`)
- Échec → `β++` (via `run.js fail`)

**Propriété clé :** avec peu de données → exploration (variance élevée de Beta) ; avec beaucoup de données → exploitation (variance faible, θ proche du vrai win rate).

### Implémentation Beta distribution

Méthode Marsaglia-Tsang (zero-dependency, précise pour toutes valeurs α, β) :

```
Beta(α, β) = Gamma(α) / (Gamma(α) + Gamma(β))
Gamma(shape) ← Marsaglia-Tsang rejection sampling
```

### Phases et candidats

| Phase | Candidats | Impact du routing |
|-------|-----------|-------------------|
| `schema` | `db` (seul) | Monitoring fiabilité |
| `specs` | `tester` (seul) | Monitoring fiabilité |
| `backend` | `nestjs`, `drf` | **Choix dynamique** |
| `frontend` | `nextjs` (seul) | Monitoring fiabilité |
| `coverage` | `tester` (seul) | Monitoring fiabilité |
| `review` | `reviewer` (seul) | Monitoring fiabilité |
| `deploy` | `devops` (seul) | Monitoring fiabilité |
| `task:backend` | `nestjs`, `drf` | Routing général |
| `task:mobile` | `react-native`, `android`, `swift` | Routing général |

### Intégration avec run.js

`run.js` appelle `router.js update` en background (fire-and-forget) automatiquement :
- `run.js done <runId> <phase>` → `router.js update <phase> <agent> success`
- `run.js fail <runId> <phase>` → `router.js update <phase> <agent> failure`

Zéro modification des slash commands — la mise à jour des priors est transparente.

### Niveaux de confiance

| Niveau | Condition | Comportement recommandé |
|--------|-----------|-------------------------|
| `none` | n = 0 | Utiliser le défaut pipeline |
| `low` | n ≤ 3 | Suivre sauf contexte fort |
| `medium` | n ≤ 10 | Suivre sauf contrainte technique |
| `high` | n > 10 | Suivre sans justification |

---

## Conséquences

### Positives
- **Apprentissage automatique** : chaque run améliore le routing suivant
- **Exploration intelligente** : en confiance `low`, explore les candidats moins testés
- **Transparence** : `node router.js stats` montre l'état complet avec win rates
- **Bootstrap** : `node router.js seed` importe l'historique des runs existants
- **Zero friction** : les priors sont mis à jour en background, invisible pour l'orchestrateur

### Négatives / Trade-offs
- **Cold start** : les premières sessions ont confiance `none` → routing par défaut
  → Résolu par `seed` qui importe l'historique existant
- **Session solo** : avec un seul développeur, n reste faible longtemps
  → Les niveaux de confiance adaptent le comportement automatiquement
- **Stationnarité implicite** : l'algorithme assume que la performance d'un agent
  est stable dans le temps. Si un agent s'améliore/dégrade, les anciens priors biaisent.
  → Mitigation : implémenter un decay (α, β *= 0.95 périodiquement) en Phase 5

### Futures améliorations
- **Contextual bandit** (Phase 5) : conditionner le prior sur le type de feature
  (ex: `backend:nestjs` pour projets GraphQL vs REST)
- **Prior decay** : réduire le poids des anciennes observations (0.95 decay mensuel)
- **ReasoningBank** : utiliser les trajectoires complètes pour le routing (pas juste succès/échec)

---

## Exemple d'évolution

```
Session 1 : n=0, confiance=none → défaut: nestjs
  /feature user-auth → nestjs ✓ → α_nestjs=2, β_nestjs=1

Session 2 : n=1, confiance=low → exploration possible
  /feature payment → Thompson sample → drf (exploration)
  drf échoue → α_drf=1, β_drf=2

Session 3 : n=2 nestjs / n=1 drf, confiance=low
  /feature invoices → sample → nestjs(θ=0.72) > drf(θ=0.31) → nestjs ✓
  → α_nestjs=3, β_nestjs=1

Session 10 : n=8 nestjs (6✓ 2✗), n=3 drf (1✓ 2✗), confiance=medium
  → nestjs recommandé avec win=75% vs drf win=33%
  → L'orchestrateur suit sans justification

Session 20 : n=15 nestjs, confiance=high
  → Exploitation pure, exploration rare
```

---

## Fichiers impactés

```
.claude/coordinator/
  ├── router.js            [NEW] Thompson Sampling router (CLI + module)
  └── router-state.json    [AUTO] Priors β(α,β) par (phase, agent)

.claude/coordinator/run.js          [MODIFIED] +routerUpdate() dans cmdDone/cmdFail
.claude/agents/orchestrator/CLAUDE.md [MODIFIED] +section routing adaptatif
```
