# ADR-004 — ReasoningBank (Mémoire par trajectoires structurées)

**Date :** 2026-05-10
**Status :** Accepted — partiellement superséédé (voir encart)
**Auteur :** Jonathan Dune / AI Dev Assistant

> **Mise à jour 2026-06-18.** Le pipeline RETRIEVE/JUDGE/DISTILL/CONSOLIDATE décrit ici
> reste valide, mais le **chemin store→recall** a été refondu (recall asservi au contenu,
> portée global/domaine, supersession, mode dégradé observable). Le scoring de retrieve
> et les seuils décrits plus bas ne sont plus à jour. Références à jour :
> `docs/adr/ADR-018-memoire-recall-asservi.md` (décision) et
> `docs/architecture-memoire.md` (architecture détaillée).

---

## Contexte

Avant cette décision, la mémoire de l'assistant était stockée sous forme de **fichiers Markdown plats** :
- `memory/global/decisions.md` — décisions d'architecture
- `memory/global/patterns.md` — patterns de code
- `memory/global/errors.md` — bugs et fixes
- `memory/projects/<project>/context.md` — contexte projet

**Problèmes :**
- Pas de structure exploitable — texte libre impossible à requêter
- Pas de lien entre action → résultat → apprentissage
- Compression = perte d'information (archivage aveugle)
- Pas de score de pertinence — tout est équivalent dans la mémoire
- Pas d'indication de succès/échec des approches passées

**Observation :** ruflo utilise un ReasoningBank inspiré des trajectoires de RL :
chaque action est stockée avec son contexte, son résultat et les learnings distillés.
Le pipeline RETRIEVE→JUDGE→DISTILL→CONSOLIDATE permet une mémoire qui s'améliore.

---

## Décision

Implémenter un **ReasoningBank** dans `coordinator/bank.js`.

### Structure de trajectoire

Chaque trajectoire représente un **résultat de phase de run** :

```json
{
  "id": "traj-20260510-ab12",
  "ts": "2026-05-10T14:30:00Z",
  "project": "my-saas",
  "runId": "feature-user-auth-20260510-1430",
  "phase": "backend",
  "agent": "nestjs",
  "verdict": "success",
  "summary": "JWT auth avec refresh tokens, asymmetric keys",
  "duration": 42,
  "tags": ["backend", "nestjs", "success", "jwt", "auth", "refresh"],
  "distilled": {
    "do": "Réutiliser le pattern : jwt",
    "dont": null
  }
}
```

### Pipeline STORE→RETRIEVE→JUDGE→DISTILL→CONSOLIDATE

#### STORE
Déclenché automatiquement par `run.js done/fail` (fire-and-forget) :
```bash
node bank.js store <phase> <agent> success|failure "<summary>" --run <runId> --duration <s>
```

#### RETRIEVE
Score composite pour chaque trajectoire :
- +4 si phase correspond
- +3 si agent correspond
- +1 par token en commun avec la requête
- +bonus recency (max +2, décroît sur 30j)
- +0.5 si verdict=success

```bash
node bank.js retrieve "jwt auth" --phase backend --limit 3
```

#### JUDGE
Évaluation interne pour la consolidation :
- `recencyScore` = max(0, 1 - age_jours / 60)
- `verdictScore` = 1.0 (success) / 0.5 (partial) / 0.0 (failure)
- `qualityScore` = min(1, summary.length / 50)
- `total` = 0.4×recency + 0.4×verdict + 0.2×quality
- `keep` = total > 0.2

#### DISTILL
Déclenché par `workers/ultralearn.js` (toutes les 20 réponses) :
```bash
node bank.js distill --since 30
```
- Groupe par phase → calcule `successRate`, `topAgent`
- Extrait tokens récurrents des summaries → `patterns` (DO) et `pitfalls` (DONT)
- Met à jour `distilled.do/dont` sur les trajectoires récentes
- Génère `insights.byPhase` et `insights.globalDo/globalDont`

#### CONSOLIDATE
Déclenché manuellement ou périodiquement :
```bash
node bank.js consolidate
```
- Archive les trajectoires > 90 jours avec score judge < 0.2
- Déduplique par Jaccard similarity > 0.85 sur les tags (même phase+agent)
- Conserve max 500 trajectoires récentes

### Stockage

```
coordinator/
  bank.js              [NEW] CLI + module ReasoningBank
  bank-state.json      [AUTO] {trajectories: [...], insights: {...}}
```

### Intégration dans l'orchestrateur

Avant chaque délégation, l'orchestrateur consulte le bank :
```bash
node bank.js retrieve "<tâche>" --phase <phase> --limit 3
```
Les trajectoires success → contexte additionnel pour l'agent
Les trajectoires failure → avertissements sur les pièges connus

---

## Conséquences

### Positives
- **Mémoire structurée** : trajectoire = contexte + action + résultat + learning
- **Requêtable** : retrieve par similarité de tokens + phase/agent + recency
- **Auto-améliorante** : distillation produit des DO/DONT qui guident les futures délégations
- **Faible friction** : STORE fire-and-forget, transparent pour l'orchestrateur
- **Scalable** : max 500 trajectoires, archivage + déduplication automatiques
- **Zero-dependency** : pure Node.js CJS, même contrainte que les autres workers

### Négatives / Trade-offs
- **Cold start** : les 10 premières sessions ont un bank vide → pas de guidage
  → Résolu par `seed` possible depuis l'historique des runs existants
- **Qualité des summaries** : la richesse des trajectoires dépend des summaries fournis à `run.js done`
  → Règle : summary obligatoire, > 20 chars
- **Latence distillation** : l'analyse NLP (token frequency) est naïve mais sufficient pour du texte court
  → Pour une distillation sémantique, phase 6 : embedding local (nomic-embed)

### Relation avec la mémoire plate existante

Le ReasoningBank **complète** (ne remplace pas) les fichiers Markdown :
- `decisions.md` → reste pour les ADR et décisions d'architecture libres
- `patterns.md` → reste pour les patterns de code non liés à un run
- `errors.md` → reste pour les bugs et fixes ad hoc
- `bank-state.json` → trajectoires structurées issues des pipelines

---

## Exemple d'évolution

```
Run 1 — feature user-auth :
  backend (nestjs) → success → store traj-001 tags:[backend,nestjs,success,jwt,auth]
  backend (nestjs) → distill → DO: jwt, auth, asymmetric

Run 2 — feature payment :
  retrieve "stripe webhook payment" → traj-001 (score 1.5) → inclus dans prompt nestjs
  backend (nestjs) → failure "N+1 queries on order fetch" → store traj-002 tags:[failure,nestjs,n+1]
  distill → DONT: n+1, queries

Run 3 — feature invoice :
  retrieve "invoice order query" → traj-002 (score 3.2, DONT: n+1)
  → Orchestrateur avertit nestjs : "attention N+1 identifié sur order fetch"
  backend (nestjs) → success (prévenu du piège) → store traj-003

Session 10 : 8 succès / 2 échecs
  stats → backend: 80% succès, agent: nestjs, patterns: jwt auth, pitfalls: n+1
  Orchestrateur utilise ces insights pour enrichir chaque prompt backend
```

---

## Fichiers impactés

```
.claude/coordinator/
  ├── bank.js             [NEW] ReasoningBank CLI + module
  └── bank-state.json     [AUTO] Trajectoires + insights

.claude/coordinator/run.js         [MODIFIED] +bankStore() dans cmdDone/cmdFail
.claude/workers/ultralearn.js      [MODIFIED] +bank.js distill à la fin
.claude/agents/orchestrator/CLAUDE.md [MODIFIED] +section ReasoningBank
docs/ADR-004-reasoningbank.md      [NEW] ce fichier
```

---

## Futures améliorations

- **Phase 6** : Embedding local (nomic-embed via ollama) pour retrieve sémantique au lieu de token overlap
- **Contextual bank** : trajectoires par `(phase, project-type)` — ex: backend:saas vs backend:api
- **Trajectory replay** : rejouer les étapes d'une trajectoire success pour un cas similaire
- **Inter-agent learning** : partager les trajectoires entre agents (reviewer → nestjs : patterns de sécurité)
