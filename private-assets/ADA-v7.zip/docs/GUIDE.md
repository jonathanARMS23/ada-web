# Guide Ada Platform

> Ada v6 — Orchestrateur multi-agents de développement IA sur Claude Code

---

## Table des matières

1. [Prérequis](#1-prérequis)
2. [Installation rapide (5 minutes)](#2-installation-rapide-5-minutes)
3. [Structure du projet](#3-structure-du-projet)
4. [Démarrage en développement](#4-démarrage-en-développement)
5. [Configuration](#5-configuration)
6. [Utilisation](#6-utilisation)
   - [Interface web](#61-interface-web)
   - [CLI ada](#62-cli-ada)
   - [API REST](#63-api-rest)
   - [WebSocket](#64-websocket)
7. [Déploiement en production](#7-déploiement-en-production)
   - [Mode local sécurisé](#71-mode-local-sécurisé)
   - [Mode Docker](#72-mode-docker)
   - [Nginx reverse proxy](#73-nginx-reverse-proxy)
   - [Variables d'environnement production](#74-variables-denvironnement-production)
8. [Sécurité](#8-sécurité)
9. [Troubleshooting](#9-troubleshooting)
10. [Référence rapide](#10-référence-rapide)

---

## 1. Prérequis

| Outil | Version minimale | Vérification | Installation |
|-------|-----------------|--------------|--------------|
| Node.js | >= 22 | `node --version` | [nodejs.org](https://nodejs.org) |
| npm | >= 10 | `npm --version` | inclus avec Node.js |
| Claude Code CLI | latest | `claude --version` | `npm i -g @anthropic-ai/claude-code` |
| git | >= 2.30 | `git --version` | [git-scm.com](https://git-scm.com) |
| tmux | >= 3.0 | `tmux -V` | `brew install tmux` / `apt install tmux` |
| curl | tout | `curl --version` | inclus sur macOS/Linux |
| openssl | tout | `openssl version` | inclus sur macOS/Linux |

**Mode fournisseur (choisir un des deux) :**

| Mode | Prérequis | Commande |
|------|-----------|---------|
| `claude-code` (défaut) | Compte Claude.ai + `claude auth login` | `ada provider set claude-code` |
| `api` | Clé `ANTHROPIC_API_KEY` | `ada provider set api` |

En mode `api` uniquement :

```bash
export ANTHROPIC_API_KEY=sk-ant-...
```

**Optionnel pour la production :**

- Docker >= 24 + Docker Compose v2 (`docker compose version`)
- Nginx (reverse proxy SSL)

---

## 2. Installation rapide (5 minutes)

```bash
# 1. Vérifier les prérequis
node --version    # doit afficher v22.x ou supérieur
npm --version     # doit afficher 10.x ou supérieur

# 2. Installer Claude Code CLI si absent
npm install -g @anthropic-ai/claude-code

# 3. Définir la clé Anthropic
export ANTHROPIC_API_KEY=sk-ant-...

# 4. Cloner et installer
git clone https://github.com/jonathanARMS23/AI-Dev-Assistant.git
cd AI-Dev-Assistant

# Installation avec ada-api + ada-ui
bash install.sh --with-server

# 5. Démarrer les services
ada server start

# 6. Vérifier
ada server status
curl http://localhost:3001/api/health/live

# 7. Ouvrir l'interface
open http://localhost:7777
```

**Multi-profils (un profil par contexte) :**

```bash
bash install.sh --profile claude-perso
bash install.sh --profile claude-pro
```

Le profil est créé s'il n'existe pas. `--all` réinstalle tous les profils
`~/.claude-*/` déjà présents.

> L'installeur sélectionne le profil via `--profile`, **pas** via la variable
> `CLAUDE_CONFIG_DIR` (elle n'est pas lue pour ce choix).

Pour l'installation côté client licencié, voir
[INSTALL-CLIENT.md](INSTALL-CLIENT.md).

---

## 3. Structure du projet

```
AI-Dev-Assistant/
├── .claude/                  # ada-core CLI — agents, skills, hooks, commandes
│   ├── agents/               # 131 agents spécialisés (full + stubs lazy)
│   ├── skills/               # 250 recettes par agent
│   ├── commands/             # 18 slash commands (/feature, /review, /saas-*, …)
│   ├── hooks/                # 7 hooks Claude Code (PreToolUse, PostToolUse, Stop)
│   ├── teams/                # 30 profils de routing (profiles.json)
│   ├── memory/               # Mémoire court/long terme (Markdown)
│   └── bin/
│       └── ada.js            # Point d'entrée CLI
├── ada-api/                  # API REST + WebSocket (Fastify 4, ESM, Node 22)
│   └── src/
│       ├── server.js         # Point d'entrée Fastify
│       ├── routes/           # Endpoints REST
│       ├── ws/               # Gestionnaire WebSocket + tickets
│       ├── ipc/              # Client IPC NDJSON ↔ ada-core
│       ├── db/               # SQLite (Drizzle ORM)
│       └── auth/             # JWT + bcrypt
├── ada-ui/                   # Interface web (Next.js 15, port 7777)
│   └── app/
│       ├── workspaces/       # Pages workspaces
│       ├── agents/           # Catalogue agents
│       ├── pipelines/        # Éditeur DAG
│       └── settings/         # Configuration
├── docs/                     # Documentation technique
│   ├── GUIDE.md              # Ce fichier
│   ├── platform/
│   │   └── DEPLOYMENT.md     # Guide déploiement détaillé
│   └── ada-api/
│       ├── API-REFERENCE.md  # Référence complète des endpoints REST
│       ├── WEBSOCKET.md      # Protocole WebSocket
│       └── DB-SCHEMA.md      # Schéma SQLite
├── scripts/
│   └── ada-api-server.sh     # Gestion locale ada-api (start/stop/status/logs)
├── docker-compose.yml        # Déploiement production (ada-api + ada-ui)
├── .env.server.example       # Template variables production
├── install.sh                # Script d'installation principal
└── CLAUDE.md                 # Configuration orchestrateur + routing
```

**Architecture des 3 composants :**

```
ada-core (CLI local, CommonJS)
    ↓ IPC NDJSON + HMAC (Unix socket /tmp/ada-api.sock)
ada-api (Fastify 4, ESM, Node 22, SQLite)
    ↓ WebSocket (ticket one-time-use, 30s) + REST API
ada-ui (Next.js 15, localhost:7777)
```

---

## 4. Démarrage en développement

### Commandes principales

```bash
# Démarrer tous les services (ada-core IPC + ada-api + ada-ui)
ada server start

# Démarrer en mode verbose (logs combinés dans le terminal)
ada server start --verbose

# Vérifier l'état des 3 services
ada server status
# → ada-core ✅  (socket .claude/ada-core.sock)
# → ada-api  ✅  (:3001, SQLite ada-api.db OK)
# → ada-ui   ✅  (:7777, connected to ada-api)

# Arrêt propre
ada server stop

# Redémarrer un service spécifique
ada server restart ada-api

# Voir les logs
ada server logs           # tous les services
ada server logs ada-api   # ada-api uniquement
ada server logs ada-api --last 50
```

### Vérification santé

```bash
# Health global
curl http://localhost:3001/api/health

# Liveness (conteneur Docker)
curl http://localhost:3001/api/health/live

# État de la connexion IPC ada-core
curl http://localhost:3001/api/health/core

# État de la base SQLite
curl http://localhost:3001/api/health/db
```

Réponse attendue sur `/api/health` :

```json
{ "status": "ok", "ts": "2026-06-01T10:00:00Z", "uptime": 3600 }
```

### Accéder à l'interface

```
http://localhost:7777
```

En mode développement (`ADA_AUTH_MODE=local`), l'authentification est automatique — aucun mot de passe requis.

---

## 5. Configuration

### Fichiers de configuration

| Fichier | Usage |
|---------|-------|
| `.env.local` | Variables ada-ui (généré par `install.sh`) |
| `.env.server` | Variables production (copier depuis `.env.server.example`) |
| `~/.claude-<profil>/ada-api.db` | Base SQLite ada-api |
| `.claude/ada-core.sock` | Socket IPC Unix (créé au démarrage) |

### Tableau des variables d'environnement

| Variable | Défaut | Obligatoire | Description |
|----------|--------|-------------|-------------|
| `ADA_PROVIDER_MODE` | `claude-code` | non | `claude-code` (OAuth Claude.ai) ou `api` (Anthropic API directe) |
| `ANTHROPIC_API_KEY` | — | si `api` | Clé API Anthropic — requise uniquement en mode `api` |
| `ADA_AUTH_MODE` | `local` | non | `local` (dev, sans password) ou `server` (prod) |
| `ADA_AUTH_PASSWORD` | — | si `server` | Mot de passe pour `POST /api/auth/token` |
| `ADA_JWT_SECRET` | auto-généré | oui en prod | Secret JWT min 64 chars — `openssl rand -hex 32` |
| `ADA_JWT_TTL` | `7d` | non | Durée de vie des tokens JWT (`7d`, `24h`, `30m`) |
| `ADA_API_PORT` | `3001` | non | Port d'écoute ada-api |
| `ADA_UI_PORT` | `7777` | non | Port d'écoute ada-ui |
| `ADA_IPC_MODE` | `unix` | non | `unix` (socket local) ou `tcp` (multi-machine) |
| `ADA_IPC_SOCKET` | `/tmp/ada-api.sock` | non | Chemin socket Unix IPC |
| `ADA_IPC_HMAC_SECRET` | — | recommandé en prod | Secret HMAC pour les événements IPC |
| `DB_PATH` | `~/.claude-<profil>/ada-api.db` | non | Chemin SQLite |
| `CORS_ORIGINS` | `http://localhost:7777` | oui en prod | Origins CORS autorisées (virgule-séparées) |
| `LOG_LEVEL` | `info` | non | Niveau de log Fastify : `trace\|debug\|info\|warn\|error` |
| `NEXT_PUBLIC_ADA_API_URL` | `http://localhost:3001` | oui en prod | URL ada-api vue depuis le navigateur |
| `NEXT_PUBLIC_WS_URL` | `ws://localhost:3001` | oui en prod | URL WebSocket vue depuis le navigateur |

---

## 6. Utilisation

### 6.1 Interface web

Accessible sur `http://localhost:7777`.

| Route | Description |
|-------|-------------|
| `/` | Dashboard — runs récents, état du système |
| `/workspaces` | Gestion des workspaces (isolation par projet) |
| `/agents` | Catalogue des 131 agents avec recherche |
| `/teams` | Compositions d'équipes et profils de routing |
| `/pipelines` | Éditeur DAG visuel + timeline des phases |
| `/schedules` | Planification cron des pipelines (CRUD + toggle) |
| `/audit` | Journal d'audit NDJSON, auto-refresh 30s |
| `/settings` | Configuration webhook, MCP connectors |

**Workflow typique dans l'UI :**

1. Créer un workspace pour votre projet
2. Lancer un pipeline depuis `/pipelines`
3. Observer les runs en temps réel (WebSocket auto-connecté)
4. Consulter le journal sur `/audit` si une phase échoue

### 6.2 Mode fournisseur (dual-provider)

ADA supporte deux modes d'authentification pour les appels Claude :

| Mode | Prérequis | Comportement |
|------|-----------|-------------|
| `claude-code` | Compte Claude.ai connecté (`claude auth login`) | Démarre une session Claude Code OAuth — aucune clé API requise |
| `api` | `ANTHROPIC_API_KEY` dans l'environnement | Injecte la clé dans le processus Claude Code — idéal pour les environnements CI/CD ou sans compte Claude.ai |

```bash
# Afficher le mode actif
ada provider

# Passer en mode API directe
ada provider set api
export ANTHROPIC_API_KEY=sk-ant-...
ada launch

# Revenir en mode Claude Code (OAuth)
ada provider set claude-code
ada launch
```

Le mode est persisté dans `~/.ada.json` (champ `providerMode`) et visible dans `ada status`.

> **Sécurité** : en mode `claude-code`, `ANTHROPIC_API_KEY` est **supprimée** de l'environnement du processus fils pour forcer l'auth OAuth et éviter toute fuite accidentelle.

### 6.3 CLI ada (commandes)

```bash
# Gestion du serveur
ada server start|stop|status|restart
ada server logs [service] [--last N]
ada server update          # git pull + rebuild + restart
ada server stats           # métriques : runs, tokens, durée moyenne

# Pipelines et runs
ada run <pipeline>         # lancer un pipeline
ada run <pipeline> --retry # relancer les phases échouées

# Agents
ada agents list                       # tous les 131 agents
ada agents list --category github     # filtrer par catégorie
ada agents search "coordinator"       # recherche multicritère

# Mémoire (SmartRetrieval)
ada memory search "stripe billing"    # BM25 → RRF → MMR
ada memory hnsw "auth jwt"            # recherche vectorielle HNSW directe
ada memory stats                      # compte trajectoires + état HNSW

# Planification
ada schedule list
ada schedule add <pipeline> "0 8 * * *"
ada schedule remove <id>
ada schedule toggle <id>

# Daemon workers (12 workers background)
ada daemon start|stop|status
ada daemon run <worker>

# Profils
ada profile push <url>   # push profil actif vers git
ada profile pull <url>   # pull profil depuis git
```

**Slash commands dans Claude Code :**

```bash
/feature user-auth          # scaffolde feature complète
/review                     # code review du diff courant
/saas-init mon-saas         # bootstrap SaaS complet
/saas-feature analytics     # feature métier avec context SaaS
/test                       # tests + rapport de couverture
/summarize                  # archive session en mémoire long terme
/compact                    # compression manuelle du contexte
/team backend-nestjs        # changer de profil d'agents
/db-migrate add-users-table # générer + appliquer migration SQL
```

### 6.4 API REST

Base URL : `http://localhost:3001`

Toutes les routes (sauf `/api/auth/token` et `/api/health`) requièrent :

```
Authorization: Bearer <jwt>
```

**Obtenir un token :**

```bash
# Mode local (sans password)
curl -X POST http://localhost:3001/api/auth/token \
  -H "Content-Type: application/json" \
  -d '{}'

# Mode server (avec password)
curl -X POST http://localhost:3001/api/auth/token \
  -H "Content-Type: application/json" \
  -d '{"password": "mon-mot-de-passe"}'
```

Réponse :

```json
{
  "token": "eyJhbGciOiJIUzI1NiJ9...",
  "expiresAt": "2026-06-08T10:00:00.000Z"
}
```

**Endpoints clés :**

```bash
# Health
GET /api/health
GET /api/health/live
GET /api/health/core
GET /api/health/db

# Workspaces
GET  /api/workspaces
POST /api/workspaces
GET  /api/workspaces/:id

# Conversations
GET  /api/workspaces/:wid/conversations
POST /api/workspaces/:wid/conversations
GET  /api/workspaces/:wid/conversations/:id

# Runs
GET  /api/workspaces/:wid/runs
POST /api/workspaces/:wid/runs
GET  /api/workspaces/:wid/runs/:id

# Ticket WebSocket
GET /api/ws/ticket
```

Format d'erreur uniforme :

```json
{
  "error": {
    "code":    "CONVERSATION_NOT_FOUND",
    "message": "Conversation abc123 introuvable",
    "status":  404
  }
}
```

Référence complète : [docs/ada-api/API-REFERENCE.md](ada-api/API-REFERENCE.md)

### 6.5 WebSocket

La connexion WebSocket se fait en **2 étapes** — le JWT n'est jamais exposé en query string.

**Étape 1 — Obtenir un ticket (valide 30s, one-time-use) :**

```bash
curl http://localhost:3001/api/ws/ticket \
  -H "Authorization: Bearer <jwt>"
# → { "ticket": "550e8400-...", "expiresAt": "2026-06-01T10:00:30Z" }
```

**Étape 2 — Ouvrir la connexion WebSocket :**

```
ws://localhost:3001/ws?ticket=<uuid>
```

Exemple JavaScript :

```javascript
const { ticket } = await fetch('/api/ws/ticket', {
  headers: { Authorization: `Bearer ${jwt}` }
}).then(r => r.json());

const socket = new WebSocket(`ws://localhost:3001/ws?ticket=${ticket}`);

socket.onmessage = ({ data }) => {
  const event = JSON.parse(data);
  console.log(event.type, event.payload);
};
```

Codes de fermeture :

| Code | Signification |
|------|--------------|
| `4001` | Ticket invalide ou déjà consommé |
| `4002` | JWT expiré ou révoqué |

Référence complète : [docs/ada-api/WEBSOCKET.md](ada-api/WEBSOCKET.md)

---

## 7. Déploiement en production

### 7.1 Mode local sécurisé

Adapté à : serveur unique avec accès SSH, usage personnel ou petite équipe.

```bash
# 1. Générer les secrets
export ADA_JWT_SECRET=$(openssl rand -hex 32)
export ADA_AUTH_PASSWORD=$(openssl rand -base64 24)
export ADA_IPC_HMAC_SECRET=$(openssl rand -hex 32)

# Afficher pour les copier dans .env.server
echo "ADA_JWT_SECRET=$ADA_JWT_SECRET"
echo "ADA_AUTH_PASSWORD=$ADA_AUTH_PASSWORD"
echo "ADA_IPC_HMAC_SECRET=$ADA_IPC_HMAC_SECRET"

# 2. Créer .env.server depuis le template
cp .env.server.example .env.server
# Éditer : nano .env.server

# 3. Créer les volumes (une seule fois)
sudo mkdir -p /opt/ada-data/db /opt/ada-data/ipc

# 4. Démarrer
docker compose up -d

# 5. Vérifier
docker compose ps
curl http://localhost:3001/api/health/live
```

Contenu minimal de `.env.server` en production :

```bash
ANTHROPIC_API_KEY=sk-ant-...
ADA_AUTH_MODE=server
ADA_AUTH_PASSWORD=<généré ci-dessus>
ADA_JWT_SECRET=<généré ci-dessus>
ADA_IPC_HMAC_SECRET=<généré ci-dessus>
CORS_ORIGINS=https://ada.ton-domaine.com
NEXT_PUBLIC_ADA_API_URL=https://ada.ton-domaine.com/api
NEXT_PUBLIC_WS_URL=wss://ada.ton-domaine.com/ws
DB_PATH=/opt/ada-data/db/ada-api.db
ADA_IPC_SOCKET=/opt/ada-data/ipc/ada-core.sock
```

### 7.2 Mode Docker

Le `docker-compose.yml` embarque **ada-api** et **ada-ui**.

> Note : ada-core tourne en local et communique avec ada-api via le socket Unix monté dans le volume `ada-ipc`.

**Services définis :**

| Service | Image | Port interne | Healthcheck |
|---------|-------|-------------|-------------|
| `ada-api` | `Dockerfile.api` | `127.0.0.1:3001` | `GET /api/health/live` |
| `ada-ui` | `Dockerfile.ui` | `127.0.0.1:7777` | `GET /` |

**Volumes :**

| Volume | Bind host | Contenu |
|--------|-----------|---------|
| `ada-db` | `/opt/ada-data/db` | SQLite + WAL |
| `ada-ipc` | `/opt/ada-data/ipc` | Socket Unix IPC |

**Commandes Docker utiles :**

```bash
# Démarrer
docker compose up -d

# Voir les logs
docker compose logs -f ada-api
docker compose logs ada-api --since 1h

# Logs filtrés (erreurs uniquement)
docker compose logs ada-api | jq 'select(.level >= 40)'

# Mise à jour sans downtime
docker compose up --build -d --no-deps ada-api
docker compose up --build -d --no-deps ada-ui

# Arrêt
docker compose down
```

**Migrations Drizzle (appliquées automatiquement au démarrage) :**

```bash
# En manuel si nécessaire
cd ada-api && npx drizzle-kit push --config drizzle.config.ts
```

### 7.3 Nginx reverse proxy

Configurer Nginx pour proxy ada-api (`/api`, `/ws`) et ada-ui (reste).

```nginx
upstream ada_api { server 127.0.0.1:3001; keepalive 64; }
upstream ada_ui  { server 127.0.0.1:7777; keepalive 32; }

server {
    listen 80;
    server_name ada.ton-domaine.com;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name ada.ton-domaine.com;

    ssl_certificate     /etc/letsencrypt/live/ada.ton-domaine.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/ada.ton-domaine.com/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    add_header Strict-Transport-Security "max-age=63072000" always;
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;

    # WebSocket — timeout 24h pour les connexions longues
    location /ws {
        proxy_pass http://ada_api;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_read_timeout 86400;
        proxy_send_timeout 86400;
    }

    # API REST
    location /api {
        proxy_pass http://ada_api;
        proxy_http_version 1.1;
        proxy_set_header Connection "";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 60;
        limit_req zone=api burst=20 nodelay;
        limit_req_status 429;
    }

    # Interface UI
    location / {
        proxy_pass http://ada_ui;
        proxy_http_version 1.1;
        proxy_set_header Connection "";
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    access_log /var/log/nginx/ada.access.log;
    error_log  /var/log/nginx/ada.error.log;
}

# Dans le bloc http de nginx.conf :
# limit_req_zone $binary_remote_addr zone=api:10m rate=30r/m;
```

**Obtenir un certificat SSL :**

```bash
apt install certbot python3-certbot-nginx
certbot --nginx -d ada.ton-domaine.com -m admin@ton-domaine.com
```

### 7.4 Variables d'environnement production

Référence complète avec descriptions — voir [section 5](#5-configuration).

Checklist avant mise en production :

- `ADA_AUTH_MODE=server`
- `ADA_JWT_SECRET` — 64 chars min, aléatoire
- `ADA_AUTH_PASSWORD` — fort, généré aléatoirement
- `ADA_IPC_HMAC_SECRET` — recommandé
- `CORS_ORIGINS` — domaine exact sans trailing slash
- `NEXT_PUBLIC_ADA_API_URL` — URL https complète
- `NEXT_PUBLIC_WS_URL` — URL wss complète
- `LOG_LEVEL=warn` en prod (réduire le bruit)

---

## 8. Sécurité

### Mode local vs server

| Paramètre | `local` (dev) | `server` (prod) |
|-----------|--------------|-----------------|
| Auth token | Token auto-généré, pas de password | Password bcrypt requis |
| JWT secret | Éphémère (recréé au redémarrage) | Persistant, min 64 chars |
| Cookie | HttpOnly, SameSite=Strict | HttpOnly, Secure, SameSite=Strict |
| CORS | `http://localhost:7777` | Domaine(s) explicite(s) |

### IPC HMAC

En production, activer `ADA_IPC_HMAC_SECRET` pour signer les événements NDJSON entre ada-core et ada-api. Sans ce secret, les événements sont acceptés sans vérification d'intégrité.

```bash
export ADA_IPC_HMAC_SECRET=$(openssl rand -hex 32)
```

### CSP nonce-based

Ada-ui génère automatiquement un nonce par requête dans le Content-Security-Policy. Aucune configuration requise.

### Rate limiting

| Endpoint | Limite | Comportement |
|----------|--------|--------------|
| `POST /api/auth/token` | configurable | retourne 429 |
| `GET /api/ws/ticket` | 60 req/min | retourne 429 |
| `*` via Nginx | 30 req/min (burst 20) | retourne 429 |

### JWT et rotation

- TTL par défaut : `7d` (configurable via `ADA_JWT_TTL`)
- Révocation stockée dans la table `sessions` (SQLite)
- Le déconnexion invalide le token côté serveur

### Secrets : règles absolues

- Jamais de secrets dans le code ou les commits
- `.env.server` dans `.gitignore` (déjà configuré)
- `ADA_JWT_SECRET` et `ADA_AUTH_PASSWORD` : toujours générés aléatoirement
- Rotation des secrets via `ada server rotate-secrets` (redémarre ada-api)

---

## 9. Troubleshooting

| Symptôme | Cause probable | Solution |
|----------|----------------|----------|
| `ada: command not found` | Symlink absent | `sudo ln -sf $(pwd)/.claude/bin/ada.js /usr/local/bin/ada` |
| `ANTHROPIC_API_KEY not set` | Variable absente | `export ANTHROPIC_API_KEY=sk-ant-...` dans `.bashrc`/`.zshrc` |
| 401 sur l'interface | Cookie HttpOnly absent ou token expiré | Recharger la page ; vérifier `ADA_JWT_TTL` |
| 403 `FORBIDDEN` | Mauvais workspace dans le JWT | Se déconnecter et reconnecter |
| WS ne se connecte pas (code 4001) | Ticket expiré (>30s) | Régénérer le ticket immédiatement avant connexion |
| WS ne se connecte pas (code 4002) | JWT expiré ou révoqué | Se reconnecter via `/api/auth/token` |
| ada-api ne démarre pas | `ADA_JWT_SECRET` absent en mode server | Vérifier `.env.server`, redémarrer |
| ada-api ne rejoint pas ada-core | Socket Unix absent | Vérifier `ADA_IPC_SOCKET` ; `ada server status` ; redémarrer ada-core |
| Migrations échouent au démarrage | Permissions sur `DB_PATH` | `chmod 755 /opt/ada-data/db` ; vérifier propriétaire |
| `SQLITE_BUSY` dans les logs | WAL verrouillé | Arrêter ada-api proprement ; supprimer `.db-wal` et `.db-shm` |
| Base de données corrompue | Crash pendant écriture | `sqlite3 <db> "PRAGMA integrity_check;"` ; restaurer depuis backup |
| `node: command not found` dans Docker | Image Node absente | Vérifier que `Dockerfile.api` est basé sur `node:22-alpine` |
| Logs vides en production | `LOG_LEVEL=error` trop restrictif | Passer à `warn` ou `info` temporairement |
| Interface vide (0 workspaces) | `NEXT_PUBLIC_ADA_API_URL` incorrect | Vérifier que l'URL pointe vers ada-api accessible depuis le navigateur |

**Diagnostics rapides :**

```bash
# État complet des services
ada server status

# Logs ada-api (50 dernières lignes)
ada server logs ada-api --last 50

# Vérifier la connexion IPC
curl http://localhost:3001/api/health/core

# Vérifier la base SQLite
sqlite3 ~/.claude-<profil>/ada-api.db "PRAGMA integrity_check;"

# Vérifier le socket IPC
ls -la /tmp/ada-api.sock   # ou le chemin dans ADA_IPC_SOCKET
```

---

## 10. Référence rapide

### Commandes fréquentes

| Commande | Description |
|----------|-------------|
| `ada server start` | Démarrer les 3 services |
| `ada server stop` | Arrêt propre |
| `ada server status` | État de chaque service |
| `ada server restart ada-api` | Redémarrer un service |
| `ada server logs ada-api` | Logs ada-api |
| `ada server update` | git pull + rebuild + restart |
| `ada server stats` | Métriques : runs, tokens, durée |
| `ada agents list` | Catalogue des 131 agents |
| `ada agents search <query>` | Recherche agents |
| `ada memory search <query>` | SmartRetrieval |
| `ada memory stats` | État HNSW + trajectoires |
| `ada daemon start` | Démarrer les 12 workers background |
| `ada run <pipeline>` | Lancer un pipeline |
| `ada schedule list` | Pipelines planifiés |

### Ports par défaut

| Service | Port | Protocole |
|---------|------|-----------|
| ada-api REST | `3001` | HTTP |
| ada-api WebSocket | `3001/ws` | WS |
| ada-ui | `7777` | HTTP |
| ada-core IPC (unix) | `.claude/ada-core.sock` | Unix socket |
| ada-core IPC (tcp) | `3099` | TCP |

### Fichiers importants

| Fichier | Usage |
|---------|-------|
| `.env.server.example` | Template variables production |
| `.env.server` | Variables production actives (ne pas commiter) |
| `.env.local` | Variables ada-ui dev (généré par install.sh) |
| `docker-compose.yml` | Services production |
| `~/.ada-api.pid` | PID ada-api (mode script direct) |
| `~/.ada-api.log` | Logs ada-api (mode script direct) |
| `~/.claude-<profil>/ada-api.db` | Base SQLite |
| `/opt/ada-data/db/ada-api.db` | Base SQLite (Docker) |
| `/opt/ada-data/ipc/ada-core.sock` | Socket IPC (Docker) |

### Documentation complémentaire

| Document | Contenu |
|----------|---------|
| [docs/ada-api/API-REFERENCE.md](ada-api/API-REFERENCE.md) | Référence complète des endpoints REST |
| [docs/ada-api/WEBSOCKET.md](ada-api/WEBSOCKET.md) | Protocole WebSocket détaillé |
| [docs/ada-api/DB-SCHEMA.md](ada-api/DB-SCHEMA.md) | Schéma SQLite complet |
| [docs/platform/DEPLOYMENT.md](platform/DEPLOYMENT.md) | Guide déploiement avancé (hybride, backup, monitoring) |
| [docs/adr/](adr/) | Architectural Decision Records |

---

*Guide généré le 2026-06-01 — Ada Platform v6*
