# Installation d'ADA — guide licencié

Ce document est destiné au **développeur qui reçoit une licence ADA** et l'installe
sur son poste. Il ne couvre pas le développement d'ADA lui-même (voir
[`GUIDE.md`](GUIDE.md) pour l'exploitation avancée et la contribution).

Durée : environ 5 minutes, hors compilation de l'interface.

---

## 1. Prérequis

| Outil | Version | Vérification | Obligatoire |
|-------|---------|--------------|-------------|
| Node.js | **>= 22** | `node --version` | Oui — l'installeur s'arrête en dessous |
| npm | >= 10 | `npm --version` | Oui (fourni avec Node) |
| Claude Code CLI | à jour | `claude --version` | Oui — exécute les agents |
| git | >= 2.30 | `git --version` | Oui — sert aux mises à jour |
| bash | 3.2 ou 5.x | `bash --version` | Oui (présent sur macOS/Linux) |
| tmux | >= 3.0 | `tmux -V` | Seulement pour les agents en équipe (`ada team`) |
| rsync | toute | `rsync --version` | Recommandé (sinon copie POSIX moins précise) |

Si Node est trop ancien :

```bash
nvm install 22 && nvm use 22
```

Claude Code CLI, si absent :

```bash
npm install -g @anthropic-ai/claude-code
```

**Systèmes supportés :** macOS et Linux. Windows n'est pas supporté nativement
(utiliser WSL2).

**PostgreSQL n'est pas requis** pour ADA lui-même : la mémoire des agents est
stockée en SQLite local (`node:sqlite`, inclus dans Node 22+). PostgreSQL ne
concerne que les projets *générés* par ADA quand leur stack en utilise un.

---

## 2. Choisir le mode fournisseur (BYOK)

ADA n'inclut aucun crédit LLM : **vous fournissez votre propre accès Anthropic**
(BYOK, "bring your own key"). Deux modes :

| Mode | Prérequis | Activation |
|------|-----------|-----------|
| `api` — **recommandé en entreprise** | Clé `ANTHROPIC_API_KEY` (console.anthropic.com) | `ada provider set api` |
| `claude-code` | Compte Claude.ai + `claude auth login` | `ada provider set claude-code` |

En mode `api`, exporter la clé dans votre shell :

```bash
export ANTHROPIC_API_KEY=sk-ant-...     # à ajouter à ~/.zshrc pour la persistance
```

> Le mode `api` (clé API facturée à l'usage) est celui à privilégier pour un
> usage professionnel : c'est le mode d'accès prévu par Anthropic pour les
> produits construits sur Claude. Vérifiez que votre usage respecte les
> conditions d'utilisation de votre abonnement ou de votre compte API.

La consommation de tokens est facturée par Anthropic, directement sur votre
compte — jamais par ADA. Suivi local : `ada cost`.

---

## 3. Installation

ADA est distribué par **dépôt git privé** ou **archive de release**. Vous avez
reçu un accès en lecture au dépôt, ou une archive `ADA-vX.Y.Z.zip`.

### Depuis le dépôt git (recommandé — permet les mises à jour)

```bash
git clone <url-du-depot-fournie-avec-votre-licence> ADA
cd ADA
bash install.sh
```

L'installeur :
1. vérifie les prérequis ;
2. crée un profil `~/.claude-ada` s'il n'en existe aucun (il demande le nom ;
   `Entrée` accepte la valeur par défaut) ;
3. installe les agents, hooks et le coordinateur dans ce profil ;
4. pose la commande `ada` (`/usr/local/bin/ada` via `sudo`, sinon un alias dans
   votre `~/.zshrc`) ;
5. compile l'interface web ;
6. lance une vérification automatique.

**Important — ne déplacez pas et ne supprimez pas le dossier cloné après
l'installation.** La commande `ada` est un lien symbolique vers ce dossier :
le déplacer casse la commande. Choisissez donc un emplacement durable
(par exemple `~/ADA`, pas `/tmp` ni `~/Downloads`).

### Options utiles

```bash
bash install.sh --help                      # liste toutes les options
bash install.sh --profile client-acme       # nomme le profil explicitement
bash install.sh --non-interactive           # aucune question (provisioning, CI)
bash install.sh --with-server               # installe aussi l'API ada-api
bash install.sh --dry-run                   # simule sans rien écrire (recommandé avant mise à jour)
bash install.sh --all                       # met à jour TOUS les profils connus de ~/.ada.json
bash install.sh --dry-run --all             # prévisualise toute mise à jour multi-profils
```

**Conseil** — avant toute mise à jour sur une machine avec plusieurs profils, lancez
`bash install.sh --dry-run [--all]` pour voir exactement ce qui serait copié/modifié/préservé,
profil par profil.

### Depuis une archive de release

```bash
unzip ADA-v7.3.0.zip -d ~/ADA && cd ~/ADA
bash install.sh
```

Vérifiez l'intégrité de l'archive avant de l'exécuter — voir
[§6 Intégrité](#6-vérifier-lintégrité-de-la-livraison).

---

## 4. Vérifier que l'installation fonctionne

```bash
ada --version     # version du dépôt + version installée dans le profil
ada doctor        # diagnostic complet
```

`ada doctor` doit se terminer par **« Tout est OK. Système opérationnel. »**.
Les lignes `ollama` et `plugins` sont optionnelles : un avertissement là n'est
pas bloquant.

Puis un essai de bout en bout :

```bash
ada status                    # état du système
ada start                     # démarre l'interface web
ada open                      # ouvre http://127.0.0.1:7777
ada launch ~/mon-projet       # lance Claude avec les agents ADA sur un projet
```

Si `ada` n'est pas reconnu juste après l'installation, rechargez votre shell
(`source ~/.zshrc`) — l'alias vient d'y être ajouté.

---

## 5. Mettre à jour

Les versions suivent le format `vX.Y.Z` et sont publiées en tags git / releases.

### Étape 1 — Prévisualiser avec `--dry-run`

Avant toute vraie mise à jour, lancez une **simulation** :

```bash
cd ~/ADA           # le dossier cloné à l'installation
git pull
bash install.sh --dry-run [--all]
```

Cela affiche, profil par profil :
- Statut : `[premier install]`, `[déjà à jour, vX.Y.Z]`, ou `[mise à jour vX.Y.Z → vA.B.C]`
- Plan exact : fichiers à copier/mettre à jour/préserver
- Fichiers personnalisés non écrasés
- Aucune écriture sur le disque

### Étape 2 — Exécuter la vraie mise à jour

#### Option A — Mettre à jour UN SEUL profil (l'actif)

```bash
ada update                    # alias court
# ou :
bash install.sh --profile <votre-profil>
```

#### Option B — Mettre à jour TOUS les profils connus

```bash
ada update --all              # via la commande ada
# ou directement :
bash install.sh --all
```

### Portée annoncée à chaque run

L'installeur affiche clairement sa portée avant d'agir :
- « Portée : 1 profil (<nom>) » (quand `--profile <nom>` est utilisé)
- « Portée : N profil(s) connu(s) de ~/.ada.json » (pour `--all` ou `bash install.sh` nu)

**Important** — `bash install.sh` nu (sans `--all` ni `--profile`) met à jour tous les
profils déjà CONNUS de `~/.ada.json` (jamais un profil détecté sur disque mais inconnu de
cette liste — celui-ci n'est jamais inclus silencieusement, il faut confirmer ou passer
`--all`). Pour limiter à un seul profil, utilisez `ada update` ou `bash install.sh --profile <nom>`.

### Vérifier la version

`ada --version` signale explicitement l'écart quand le dépôt a été mis à jour
sans réinstallation :

```
⚠ Profil claude-ada installé en v7.2.0 — dépôt en v7.3.0
  Réinstalle pour aligner : ada install
```

### Ce qui est préservé lors d'une mise à jour

L'installeur protège vos données et personnalisations par un **manifeste de livraison**
(voir §6) : seuls les fichiers trackés git et non modifiés par vous sont mis à jour.

| Catégorie | Détail | Protection |
|-----------|--------|-----------|
| **Mémoire et données runtime** | `bank.db` + fichiers `.db-*`, `bank-state.json`, `router-state.json`, `memory-episodic.json`, `memory-procedural.json`, `memory-semantic.json`, `lessons.json`, `audit.log`, `logs/` | Jamais écrasés, hors manifeste |
| **Sessions d'équipe** | `teams/session-*/` (données vivantes) | Jamais écrasés, hors manifeste |
| **Pipelines personnalisés** | `coordinator/pipelines.json` modifié par vous | Sauvegarde checksumée : si modifié, listé en fin d'exécution, jamais écrasé |
| **CLAUDE.md du profil** | Si vous l'avez personnalisé | Sauvegarde horodatée `CLAUDE.md.bak.<YYYYmmddHHMMSS>` créée AVANT la mise à jour, ancienne version jamais perdue |
| **Réglages (settings.json)** | `hooks` (ajout), `permissions.deny` (ajout), `permissions.allow` (intouché) | Union additive ; vos valeurs jamais supprimées |
| **Environnement et préférences** | `env` et `preferences` dans `settings.json` | Union de clés ; en cas de conflit (même clé, valeur différente), **votre valeur est toujours conservée**, la divergence est affichée pour réconciliation manuelle |
| **Données de référence et templates** | `benchmarks/`, `templates/`, `memory/`, `archives/` | Contenu de référence livré mis à jour, état runtime cohabitant préservé |

Il n'y a pas de notification automatique de mise à jour : consultez les
releases du dépôt, ou comparez `ada --version` au dernier tag
(`git fetch --tags && git tag --sort=-v:refname | head -1`).

---

## 6. Vérifier l'intégrité de la livraison

L'installeur ne télécharge aucun code depuis Internet : il ne fait que copier
les fichiers du dossier cloné vers votre profil. Ce qu'il fait tout de même et
que vous devez connaître avant de l'exécuter :

- `sudo ln -sf` pour poser `/usr/local/bin/ada` (demande votre mot de passe ;
  en cas de refus, il retombe sur un alias shell — aucun privilège requis) ;
- `npm install` / `npm run build` dans `ada-ui/` (télécharge les dépendances de
  l'interface depuis le registre npm public) ;
- écriture dans `~/.<profil>/` et `~/.ada.json` uniquement.

### Manifeste de livraison

ADA inclut un **manifeste de livraison** (`.claude/.ada-manifest.json`), committé
dans le dépôt. Il liste tous les fichiers qu'ADA « possède » (ceux trackés git sous
`.claude/`) avec leur empreinte SHA256.

**Fonctionnement** :
- Un fichier livré, **non modifié par vous** → mis à jour normalement
- Un fichier livré, **modifié par vous** (checksum différent) → **jamais écrasé**,
  listé en fin d'exécution avec le chemin exact, à reporter à la main si vous
  voulez la version livrée
- Tout fichier **hors manifeste** (mémoire, sessions d'équipe, logs, état runtime)
  → jamais touché dans aucun sens, c'est structurellement garanti

C'est votre protection automatique contre la perte de données lors d'une mise à jour.

### Autres vérifications

```bash
# Archive de release : comparer au SHA256SUMS publié avec la release
shasum -a 256 -c SHA256SUMS

# Dépôt git : le tag doit correspondre à la version attendue
git fetch --tags && git tag --points-at HEAD

# Relire l'installeur avant de l'exécuter — il est en bash, lisible
less install.sh
```

Le clone git s'effectue sur HTTPS authentifié : l'intégrité repose sur TLS et
sur les empreintes de commit git. Aucune signature GPG n'est apposée
actuellement.

Le manifeste de livraison, couplé aux vérifications git/SHA256SUMS ci-dessus,
offre une protection multi-niveaux : vérification du dépôt source, détection des
modifications côté client, et préservation garantie de vos données.

---

## 7. Désinstaller

```bash
ada uninstall            # retire les hooks du profil actif, liste ce qui subsiste
ada uninstall --purge    # désinstallation complète (demande confirmation)
```

`--purge` supprime les profils `~/.claude-*` gérés par ADA, `~/.ada.json`, la
commande `ada` et l'alias shell. **La mémoire accumulée est définitivement
perdue** — sauvegardez `~/.<profil>/coordinator/bank.db` si elle a de la valeur.
Le dossier cloné n'est pas supprimé : effacez-le manuellement.

Si la suppression de `/usr/local/bin/ada` échoue (permissions), terminez avec :

```bash
sudo rm /usr/local/bin/ada
```

---

## 8. Obtenir de l'aide

Avant de demander de l'aide, joignez la sortie de ces trois commandes :

```bash
ada --version
ada doctor
ada logs --tail 50
```

| Symptôme | Piste |
|----------|-------|
| `ada: command not found` | `source ~/.zshrc`, ou `sudo ln -sf <dossier>/.claude/bin/ada.js /usr/local/bin/ada` |
| `sourceDir introuvable` | Le dossier cloné a été déplacé — corrigez `sourceDir` dans `~/.ada.json` ou réinstallez |
| L'installeur s'arrête sur la version de Node | `nvm install 22 && nvm use 22` |
| L'interface ne démarre pas | `ada stop && ada start`, puis `ada logs` |
| Erreurs d'authentification Anthropic | `ada provider` pour voir le mode actif ; vérifiez `ANTHROPIC_API_KEY` ou `claude auth login` |

Support : contact fourni avec votre licence. Consultez également la portée et
les limites de garantie dans [`../LICENSE`](../LICENSE).
