# Rapport — rendre l'installeur ADA distribuable à un client externe

**Date :** 2026-08-03 · **Périmètre :** `install.sh`, `.claude/bin/ada.js`, doc d'installation,
versioning, intégrité de la livraison · **Statut :** correctifs appliqués, décisions produit ouvertes

---

## 1. Résumé exécutif

L'installeur n'était pas distribuable en l'état. **Cinq défauts bloquants ou
destructeurs ont été trouvés et vérifiés par exécution** (pas par lecture seule) ;
tous sont corrigés. Aucun chemin `/Users/jonathanarms/...` n'était hardcodé — le
correctif « agnostique au profil » déjà en mémoire projet a tenu.

| # | Défaut | Gravité | Statut |
|---|--------|---------|--------|
| 1 | Installation impossible sur un poste vierge (`exit 1` si aucun `~/.claude-*`) | Bloquant | Corrigé |
| 2 | `install.sh` s'arrête au milieu du 1er profil sur bash 3.2 (bash système macOS) | Bloquant | Corrigé |
| 3 | `install.sh` et `ada update` copiaient la **mémoire du créateur** (`bank.db`, 340 Ko) chez le client | Fuite + perte de données | Corrigé |
| 4 | Chemin d'installation nº1 du README (`curl \| bash`) produisait une commande `ada` cassée ; dépôt privé ⇒ 404 | Bloquant | Corrigé |
| 5 | `ada install` échouait systématiquement (mauvais chemin d'installeur) | Cassé | Corrigé |

Vérification finale : installation complète simulée sur un `HOME` vierge avec le
bash système macOS → profil créé, `ada doctor` vert, aucune donnée du créateur
transmise.

---

## 2. Audit des hypothèses « usage interne »

### Ce qui était sain

- **Aucun chemin absolu hardcodé** dans `install.sh` ni `bin/ada.js`
  (`grep '/Users/'` → 0 résultat).
- **Aucun nom de profil hardcodé** en logique : tout passe par
  `~/.ada.json` / `ADA_ACTIVE_PROFILE` / `--profile`. Les deux seules occurrences
  de `claude-pro` sont un exemple dans un message d'aide et un commentaire.
- La préservation de l'état client (`bank-state.json`, `router-state.json`,
  `pipelines.json`) était déjà pensée dans `_sync_dir`.

### Ce qui cassait chez un client externe

| Hypothèse interne | Conséquence côté client |
|---|---|
| « Un profil `~/.claude-*` existe déjà » | Poste vierge : `⚠ Aucun profil détecté` + `exit 1`. Le client devait devineret `mkdir ~/.claude-<nom>` à la main. **Vérifié par exécution.** |
| « Je lance l'installeur avec bash 5 (brew) » | Sur le bash 3.2 par défaut de macOS, `"${excludes[@]}"` sur tableau vide sous `set -u` → `unbound variable`, arrêt à mi-installation, profil à moitié synchronisé. **Reproduit.** |
| « Le dépôt source ne contient pas d'état runtime » | Faux dans une copie de travail : `bank.db`, `bank-hnsw.json`, `graph-state.json` (gitignorés mais présents) étaient copiés dans le profil client. Fuite des trajectoires du créateur + écrasement de l'apprentissage du client. |
| « Le dépôt est public » | Le dépôt est **PRIVATE** : le `curl -fsSL raw.githubusercontent.com...` du README renvoie 404. |
| « `sourceDir` = racine du dépôt » | `sourceDir` vaut `<repo>/.claude` ⇒ `ada install` cherchait `<repo>/.claude/install.sh`, inexistant. |
| « Le client sait quelles dépendances sont requises » | `check_prerequisites` ne validait que Node. Ni Claude Code CLI, ni git, ni tmux, ni rsync n'étaient signalés. |
| Profils de test jamais élagués | `installedProfiles` contenait 4 profils fantômes (`claude-test-install`, …) supprimés du disque. |

### Non corrigé volontairement — dépendance structurelle à documenter

`/usr/local/bin/ada` est un **lien symbolique vers le dépôt cloné**. Déplacer ou
supprimer le dossier casse la commande `ada`. C'est acceptable pour une
distribution par git clone, mais c'est une contrainte réelle : documentée en gras
dans `INSTALL-CLIENT.md` (§3) et dans le README. Voir décision **D2**.

---

## 3. Versioning et mises à jour

### État trouvé — dérive de version sur 4 sources

| Source | Valeur |
|--------|--------|
| `install.sh` (`ADA_VERSION`) | `1.0.0` |
| `.claude/bin/ada.js` (`VERSION`) | `5.0.0` |
| `README.md` (titre / sprint) | `v6` / `v7.0.1` |
| Dernier tag git | **`v7.3.0`** |

Pas de `package.json` à la racine. `ada --version` renvoyait
`Commande inconnue : --version` (seul `ada version` existait).

### Appliqué

- **`VERSION` à la racine = source unique de vérité** (`7.3.0`, aligné sur le
  dernier tag). Lu par `install.sh` et par `ada.js` ; plus aucun numéro dupliqué.
  Choix d'un fichier `VERSION` plutôt qu'un `package.json` : `ci.yml` note
  explicitement que la racine n'a pas de `package.json`/lockfile — ne pas
  introduire de sémantique npm par effet de bord. Voir décision **D1**.
- **`ada --version` / `-v` / `--help` / `-h`** fonctionnent (alias vers les
  sous-commandes).
- **Détection de dérive dépôt ↔ runtime** — piège récurrent en mémoire projet,
  désormais visible :
  ```
  ⚠ Profil claude-ada installé en v7.2.0 — dépôt en v7.3.0
    Réinstalle pour aligner : ada install
  ```
  L'installeur dépose `VERSION` dans le profil pour permettre cette comparaison.
- **Garde-fou CI** — `release.yml` échoue si `VERSION` ≠ tag git. Empêche de
  livrer une archive dont le numéro affiché ne correspond pas.
- **`ada install` réparé** — cherche `install.sh` à la racine du dépôt et le lance
  sur le profil actif (contrôle de périmètre realpath conservé).
- **`ada update` rendu non destructeur** — exclut désormais mémoire (`bank.db` et
  index), priors du routeur, `pipelines.json`, `settings.json`, logs et runs.
  Avant, un `ada update` détruisait tout l'apprentissage du client.
- **Désinstallation complète** — `ada uninstall` ne retirait que les hooks et
  laissait `ada` sur le `PATH`, `~/.ada.json` et les profils en place. Ajout de
  `ada uninstall --purge` : arrêt de l'UI, suppression des profils, de la config,
  du lien symbolique et des alias shell, sous confirmation explicite (taper
  « supprimer »), `--yes` pour l'automatisation. Le dépôt source n'est jamais
  supprimé.

### Détection de mise à jour — délibérément manuelle

Aucun serveur de mise à jour, conformément au périmètre MVP : le client compare
`ada --version` au dernier tag (`git fetch --tags`), procédure documentée en
`INSTALL-CLIENT.md` §5. Voir décision **D3** si un check automatique est voulu.

---

## 4. Documentation d'installation client

`docs/GUIDE.md` (26 Ko, « Guide Ada Platform ») mélange exploitation, déploiement
Docker, Nginx, API REST et contribution : inadapté à un licencié qui veut juste
installer. Ses prérequis étaient corrects (Node 22, BYOK) mais il portait les
mêmes commandes périmées que le README.

**Créé : `docs/INSTALL-CLIENT.md`** — document dédié au développeur licencié :
prérequis vérifiables, choix du mode fournisseur BYOK, installation, vérification
(`ada doctor`), mise à jour, intégrité, désinstallation, tableau de dépannage,
et les 3 commandes à joindre à toute demande de support.

Précisions utiles apportées : **PostgreSQL n'est pas requis** par ADA (mémoire en
SQLite via `node:sqlite`) — il ne concerne que les projets générés ; **aucun crédit
LLM n'est fourni** (facturation Anthropic directe, `ada cost` pour le suivi) ;
Windows non supporté hors WSL2.

**Corrigé dans `README.md` et `docs/GUIDE.md`** : suppression du one-liner
`curl | bash` mort, remplacement de `CLAUDE_CONFIG_DIR=... bash install.sh` (jamais
lu pour ce choix) par `--profile`, et **Node >= 18 → >= 22** (le README
contredisait le blocage réel de l'installeur : un client en Node 18 suivait le
README et l'installation échouait).

> Le mode `api` (clé Anthropic) est présenté comme recommandé en entreprise, en
> cohérence avec le risque légal déjà tracé (`ada_legal_cgu_anthropic_2026-08-03` :
> l'auth OAuth par abonnement est en tension avec la doc légale Claude Code). Le
> guide reste factuel et renvoie au client la vérification de ses propres CGU —
> l'arbitrage juridique n'est pas tranché ici.

---

## 5. Vérification d'intégrité

### État réel (documenté, pas sur-ingénieré)

`install.sh` **ne télécharge aucun code** : il copie les fichiers du dossier cloné
vers le profil. Les trois seules actions à divulguer au client :

1. `sudo ln -sf` pour poser `/usr/local/bin/ada` (repli sur un alias shell si refus — aucun privilège requis) ;
2. `npm install` / `npm run build` dans `ada-ui/` → télécharge depuis le registre npm public ;
3. écritures limitées à `~/.<profil>/` et `~/.ada.json`.

Le canal réel est un `git clone` HTTPS authentifié sur dépôt privé : intégrité
assurée par TLS et les empreintes de commit git. Le risque d'un `curl | bash`
anonyme a disparu avec la suppression de `install-remote.sh`.

### Appliqué — proportionné

- `release.yml` publie un **`SHA256SUMS`** à côté de l'archive ⇒ le client peut
  faire `shasum -a 256 -c SHA256SUMS` avant d'exécuter quoi que ce soit
  (l'archive de release existait déjà sans empreinte).
- `install-remote.sh` **supprimé** : il clonait dans un `mktemp -d` supprimé par son
  propre `trap ... EXIT`, alors que `install.sh` y faisait pointer `/usr/local/bin/ada`
  → **toute installation par ce chemin produisait une commande `ada` cassée**. Le
  dépôt étant privé et le modèle économique basé sur la vente ciblée (zéro essai public),
  ce fichier n'a plus de raison d'être. Voir décision **D4**.
- Section « Vérifier l'intégrité » dans `INSTALL-CLIENT.md` avec les commandes.

**Non fait volontairement :** pas de signature GPG des tags ni de notarisation.
Disproportionné pour une distribution en dépôt privé à des clients identifiés
sous contrat. À revoir si le canal devient public ou anonyme (**D4**).

---

## 6. Décisions ouvertes (à trancher — non tranchées seul)

| Réf | Décision | Options | Recommandation |
|-----|----------|---------|----------------|
| **D1** | Source de vérité de version | (a) `VERSION` — appliqué, zéro effet de bord ; (b) `package.json` racine — conventionnel, requis si distribution npm, mais contredit un choix explicite de `ci.yml` | **Tranché (2026-08-03) : (a) confirmé** tant que le canal reste git clone privé (D2) ; migrer vers (b) seulement si le canal passe un jour à npm. |
| **D2** | Canal de distribution | (a) git clone privé — actuel, mises à jour par `git pull`, impose de garder le dossier ; (b) paquet npm privé (`npm i -g @ada/cli`) — installation et mise à jour standard, supprime le lien symbolique fragile, mais gros refactor (le CLI suppose un dépôt à côté) ; (c) archive zip + `SHA256SUMS` — simple, pas de mise à jour incrémentale | **Tranché (2026-08-03) : (a) conservé** pour l'instant (pas de client externe réel à date) — à revisiter si le canal git clone devient un point de friction concret avec un client. |
| **D3** | Mécanisme de mise à jour | (a) manuel documenté + détection de dérive — appliqué ; (b) `ada update --check` interrogeant l'API GitHub des releases (nécessite un token côté client sur dépôt privé) ; ~~(c) serveur de mise à jour maison~~ | **Tranché (2026-08-03) : (a).** L'option (c) était couplée à ADR-020 (backend de licences par siège), **rejeté le même jour** — le modèle réel est une vente perpétuelle sans aucune logique d'entitlement dans le produit. (c) n'a donc plus lieu d'être. |
| **D4** | Sort de `install-remote.sh` | (a) désactivé — appliqué ; (b) supprimé du dépôt ; (c) réécrit pour un canal public (clone persistant + vérification d'empreinte) si un essai gratuit public est voulu | **Tranché (2026-08-03) : (b)** — aucun essai public n'est prévu (vente ciblée), le fichier est supprimé. |
| **D5** | Nom du profil par défaut | `claude-ada` retenu (neutre, respecte « jamais de nom de profil du créateur »). Alternatives : `claude-client`, ou nom d'organisation du licencié | **Tranché (2026-08-03) : `claude-ada` confirmé.** |
| **D6** | Consolidation `ada update` / `ada install` | Deux chemins de synchronisation coexistent avec des sémantiques différentes (`update` = rsync rapide, `install` = merge complet des hooks/permissions). Risque de divergence future des listes d'exclusion | **Tranché (2026-08-03) : appliqué.** `ada update` devient un alias de `ada install` (une seule logique, celle qui fusionne correctement) ; le changement de comportement observable (update fait désormais le merge complet) est assumé. |

Point d'hygiène non bloquant : `.claude/events.ndjson` est non suivi et non
ignoré — à ajouter au `.gitignore` ou à committer selon son statut.

---

## 7. Fichiers touchés

**Créés**
- `VERSION` — source unique de vérité (`7.3.0`)
- `docs/INSTALL-CLIENT.md` — guide d'installation licencié
- `docs/RAPPORT-packaging-installeur-2026-08-03.md` — ce rapport

**Modifiés** (`+490 / −175`)
- `install.sh` — version depuis `VERSION` ; création de profil sur poste vierge ;
  `--profile` crée le profil ; validation stricte du nom (refus des chemins) ;
  correctif bash 3.2 ; `--help` / `--version` ; échec sur option inconnue ;
  prérequis non bloquants (claude/git/rsync/tmux) ; exclusion de `bank.db` & index ;
  dépose `VERSION` dans le profil ; élagage des profils fantômes
- `.claude/bin/ada.js` — résolution de version par fichier + repli ; dérive
  dépôt↔profil dans `ada version` ; alias `--version`/`-v`/`--help`/`-h` ;
  `cmdInstall` réparé ; `ada update` non destructeur ; `ada uninstall --purge`
- `.github/workflows/release.yml` — garde `VERSION` = tag ; publication `SHA256SUMS`
- `README.md` — installation et prérequis corrigés (Node 22, plus de `curl | bash`)
- `docs/GUIDE.md` — commandes multi-profils corrigées, one-liner mort retiré

**Non committé** : les changements sont dans l'arbre de travail, sur `main`.

---

## 8. Validation exécutée

| Test | Résultat |
|------|----------|
| `bash -n install.sh`, `node --check ada.js` | OK |
| Installation sur `HOME` vierge, bash 3.2, sans `~/.ada.json` | Profil créé, installation complète, `ada doctor` vert |
| Absence de fuite d'état créateur après installation | `bank.db`, `bank-hnsw.json`, `graph-state.json` absents du profil client ; `bank-state`/`router-state` = seeds neutres (`trajectories: []`, `priors: {}`) |
| `ada --version`, `-v`, `version` | `v7.3.0` + version du profil installé |
| `install.sh --help` / `--version` sans prérequis | OK (répond sans exiger Node) |
| Rejet de `--profile '../evil'` et `--bogus` | Refusés avec message explicite |
| Aucune référence à `install-remote.sh` | ✓ supprimé, références nettoyées dans docs |
| Hooks de sécurité après réinstallation | Actifs (blocage `node -e` et `rm -rf` reproduit) |

**Régression connue, non liée à ce travail :** `flywheel.test.js` échoue
(2 tests, `score 0.9166 ≠ 1.0`). Vérifié par `git stash` : **l'échec est déjà
présent à HEAD** sans aucune de mes modifications, et le test ne référence aucun
fichier touché ici. À traiter séparément — c'est un test anti-régression de recall
qui n'est plus vert, donc un signal à ne pas laisser dormir.

**Incident de test, réparé :** l'exécution de `ada uninstall` pendant la
validation a retiré les hooks du profil actif `claude-pro` (comportement attendu
de la commande). Restauré immédiatement via `install.sh --profile claude-pro` ;
hooks et `permissions.deny` vérifiés en place, blocages de sécurité reproduits.
Les profils de test créés (`~/.evil`, `~/.claude-pkgtest`) ont été supprimés et
`installedProfiles` élagué.
