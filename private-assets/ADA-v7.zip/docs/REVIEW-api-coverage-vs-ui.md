# Review — Couverture API NestJS vs features ada-ui + plan d'implémentation

| Date | 2026-06-09 |
|------|-----------|
| Objet | Les 9 features produit d'ada-ui sont-elles couvertes par l'API NestJS (`ada-api-nest`) + le control-server ? |
| Méthode | Analyse read-only de `ada-api-nest/src`, `.claude/coordinator/control-server.js`, et de l'existant (`ada-api` Fastify, `ada-ui/app/api` Canal A) |

## Synthèse

| # | Feature | Couverture | En une ligne |
|---|---------|-----------|--------------|
| 1 | Dashboard | 🟡 partielle | Briques live OK (runs, router.stats, cost, metrics, health) ; agrégation/timeline/heatmap/budget non exposées |
| 2 | Workspaces | ❌ absente | Aucun endpoint workspaces/conversations en NestJS ; existaient en Fastify, **non portés** |
| 3 | Agents / Profiles / Teams | 🟡 partielle | agents/profiles/skills OK ; **teams absentes** ; détail agent partiel |
| 4 | Mémoire (graph 3D + obsidian) | 🟡 partielle | `bank.retrieve` + `obsidian.status` seulement ; **pas de graphe nœuds/arêtes ni wiki** |
| 5 | Pipelines | ❌ absente | Aucun endpoint/RPC `pipelines.*` ; DAG vit dans `pipelines.json` + ada-ui FS |
| 6 | MCP (CRUD config) | ❌ absente | `mcp/broker` = broker de permissions **déprécié**, pas du CRUD config |
| 7 | Logs (stockés, rétention) | 🟡 partielle | `logs.tail` lit en live ; **aucune table logs, aucune ingestion/rétention** |
| 8 | Settings (profil) | 🟡 partielle | providers/schedules/pr mutables ; pas de surface unifiée (webhook, budget, obsidian) |
| 9 | Gestion des profils | 🟡 partielle | `GET /profiles` OK ; **pas de switch ni create** en NestJS |

**Bilan : 4 absentes, 5 partielles.** Le moteur d'exécution (runs/tâches/sessions temps réel) est solide ; ce qui manque est surtout la **couche produit** (workspaces, persistance logs, config MCP/pipelines/profils, mémoire riche).

## Surface API existante (référence)

**REST NestJS** : `ClaudeController` (`/capabilities`, `/health`, `/runs`, `/runs/:id`, `/memory`, `/router/stats`, `/stats/cost`, `/stats/metrics`) · `AdaController` (`/profiles`, `/agents`(+search), `/skills`, `/teams/sync`, `/bridge`, `/federation`, `/daemon`, `/schedules`, `/providers`, `/obsidian`, `/pr`, `/logs` + mutations) · `TasksController` (`POST /tasks`, `GET /tasks/:runId`) · `SessionsController` (`POST /sessions`, `GET /sessions/policy/:profile`) · `McpBrokerController` (**déprécié**, broker de permissions).

**RPC control-server** : groupes `run, router, bank, provider, cost, metrics, budget, profiles, agents, skills, team, bridge, fed, daemon, schedules, providers, obsidian, pr, logs, capabilities, health`. **Absents : `pipelines`, `mcp`, `workspace`, `conversation`, `memory.graph`, `teams`.**

**WS** (`/ws`) : routage par room workspace, dédup par `id`, JWT. Events : `run.started/phase.started/phase.completed/phase.failed/completed`. Inbound : `task.message/interrupt/cancel/permission_response/plan_response/clarification_response`.

**Persistance** (`schema.ts`) : `events, runs, run_phases, messages, tool_calls, sessions, permission_policies, permission_requests, plans, plan_steps, clarifications`. **Absents : `workspaces`, `conversations`, `logs`, `cost_ledger`, `teams`, `pipelines`, `mcp_servers`, `agents`.**

## Manques transverses (critiques)

- **Workspaces/conversations** ❌ — Fastify avait le CRUD complet (workspaces→conversations→messages→search), **non porté** en NestJS. Les colonnes `workspaceId/conversationId` sont du TEXT nullable sans table ni FK. Bloque la feature 2 ET le routage WS réel (la room workspace reste théorique tant qu'aucun workspace n'existe).
- **Logs** ❌ pour le stockage — tout est FS éphémère (`events.ndjson`, `runs/*.jsonl`, `.claude/logs/`). `logs.tail` fait du tail live. Aucune table, ingestion, recherche, ni rétention. Plus gros manque de persistance.
- **Coûts temps réel** ❌ — aucun event `cost.delta`/`budget.warning` sur le WS ; la feature 2 (« coûts en temps réel ») n'a aucune source.
- **Mémoire riche** 🟡 — `graph-builder.js`/`graph-memory.js` existent mais **non exposés en RPC** ; le wiki Obsidian non exposé.

## Plan d'implémentation (suite de la roadmap : P5→P8)

**P5 — Fondations persistance & workspaces** _(débloque #2, #7, temps réel)_
1. Migration `0004` : tables `workspaces`, `conversations` + FK depuis `runs/sessions/events/messages`.
2. Migration `0005` : table `logs` + `LogIngestionService` (bus events + tail `events.ndjson`) + job de rétention mensuelle.
3. `WorkspacesController` + `ConversationsController` (CRUD, stats, messages) — porter la logique Fastify.

**P6 — Dashboard & coûts live** _(dépend de P5 pour le scope)_
4. Migration `cost_ledger` + alimentation via ingestion ; events WS `cost.delta`/`budget.warning`.
5. `StatsController` : `GET /stats/overview`, `/stats/activity` (heatmap), `/stats/budget`, timeline runs.

**P7 — Features de configuration (RPC + REST, parallélisables)**
6. RPC + `PipelinesController` (`GET /pipelines`, `/pipelines/:name`).
7. RPC `mcp.*` + `McpController` (CRUD connectors + registry/catalogue).
8. RPC `profiles.switch/create` + endpoints ; `SettingsController` unifié (providers/budget/obsidian/webhook).
9. RPC `teams.*` + `TeamsController` ; `GET /agents/:slug` (RPC `agents.info`).

**P8 — Mémoire riche**
10. RPC `memory.graph` (wrapper `graph-builder.js`) + `obsidian.wiki`/`obsidian.note` ; `GET /memory/graph`, `/memory/wiki`, `/memory/notes/:file`.

**Ordre** : la persistance workspaces/logs (P5) est prérequis du dashboard scopé et des coûts temps réel (P6) ; les groupes de config (P7) sont des relais RPC indépendants (parallélisables) ; la mémoire (P8) est la moins bloquante. Traiter les ❌ (workspaces, pipelines, MCP CRUD, logs) avant les 🟡 (qui ont déjà une brique exploitable).

## Détail par feature

### 1. Dashboard — 🟡
Existant : `/router/stats`, `/stats/cost` (recalcul depuis sessions), `/stats/metrics`, `/runs`, `/health`.
Manques : overview agrégé (totalRuns/successRate/topAgent), heatmap 90j, budget exposé en REST, timeline structurée, historique coûts persisté.
Plan : `GET /stats/overview` · `/stats/activity` · `/stats/budget` · table `cost_ledger`.

### 2. Workspaces — ❌
Existant : rien en NestJS (colonnes TEXT nullable seulement). Fastify avait tout, non porté.
Plan : tables `workspaces`/`conversations` + FK ; `WorkspacesController`/`ConversationsController` ; lier `POST /tasks`+`/sessions` à un workspace ; coûts live via event `cost.delta {workspaceId}`.

### 3. Agents / Profiles / Teams — 🟡
Existant : `/agents`(+search), `/profiles`, `/skills`.
Manques : **teams absentes** (≠ `team.status` = synchro git) ; pas de `GET /agents/:slug` détail.
Plan : RPC `agents.info` + `GET /agents/:slug` ; RPC `teams.*` + `TeamsController`.

### 4. Mémoire — 🟡
Existant : `/memory?q=` (`bank.retrieve`), `/obsidian` (status/compteurs).
Manques : graphe navigable (nœuds/arêtes), wiki (contenu des notes).
Plan : RPC `memory.graph` (wrapper `graph-builder.js`) ; RPC `obsidian.wiki`/`obsidian.note` ; endpoints `GET /memory/graph`, `/memory/wiki`, `/memory/notes/:file`.

### 5. Pipelines — ❌
Existant : rien exposé (DAG chargé en interne pour exécuter seulement).
Plan : RPC `pipelines.list/get` (parse `pipelines.json` + résolution agents/tiers) ; `PipelinesController`.

### 6. MCP — ❌
Existant : `mcp/broker` déprécié (permissions), pas de CRUD config.
Plan : RPC `mcp.list/add/remove/update` (mute `settings.json mcpServers`) + `McpController` + `GET /mcp/registry` (catalogue) ; mutations derrière JWT + rate-limit.

### 7. Logs — 🟡 (gros manque persistance)
Existant : `logs.tail` (tail live `events.ndjson`/`daemon.log`).
Manques : table `logs`, ingestion, recherche/filtres/pagination, rétention mensuelle.
Plan : table `logs`(ts, level, source, run_id, workspace_id, message, payload) + `LogIngestionService` + `GET /logs` filtrable + job rétention 30j.

### 8. Settings — 🟡
Existant : `PUT /providers`, `/schedules`, `GET /pr`.
Manques : surface unifiée ; webhook, budget config, obsidian config.
Plan : `SettingsController` `GET/PUT /settings` (vue agrégée `~/.ada.json`).

### 9. Profils — 🟡
Existant : `GET /profiles` (liste + actif).
Manques : switch, create.
Plan : RPC `profiles.switch/create` ; `PUT /profiles/active`, `POST /profiles`.
