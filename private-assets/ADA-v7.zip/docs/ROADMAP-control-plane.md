# Roadmap d'implémentation — Liaison ada-api ↔ ada-core

> Séquence d'exécution des ADR-016 (protocole Control Plane) et ADR-017 (schéma Postgres).
> Principe : chaque phase est **indépendamment livrable et testable**, le CLI `ada` reste fonctionnel tout du long, et aucune phase ne démarre sans que sa dépendance soit verte.

| Date | 2026-06-09 |
|------|-----------|
| Statut | Proposé (en revue) |
| Réfs | ADR-016, ADR-017 |

---

## Vue d'ensemble

```
P0 Control Server (ada-core)  ──┐
                                ├─► P2 OrchestrationLoop (Mode A) ──► P3 Sessions interactives + Permission Broker (Mode B)
P1 NestJS + Client + Postgres ──┘                                          │
                                                                           └─► P4 Surface CLI complète + ada-ui + cutover
```

Cross-cutting (à traiter dans P0/P1, dette identifiée à l'état des lieux) : réparer le test runner (29/43 suites câblées), migrer les tests `claude-opus-4-7`→`4-8`, supprimer le code mort (`run.js:1158 loadRouterState`, `context-advisor.js`).

---

## P0 — ada-core Control Server (fondation)

**But :** un contrat RPC stable et unique remplace les 15 invocations éparses.
**Livrables :**
- `coordinator/control-server.js` : daemon, socket Unix `<profileDir>/control.sock` (+ fallback TCP), framing JSON-RPC 2.0/NDJSON, HMAC par frame, handshake `hello`+semver.
- Wrappers in-process (`require()`) : `run.*`, `router.*`, `bank.*`, `provider.*`, `cost.*`, `metrics.*`, `budget.*`, `capabilities.list`, `health.probe` (cf. ADR-016 §2).
- Normalisation du vocabulaire d'events (corrige le désalignement `run.completed`/`run.done`) ; émission socket + append `events.ndjson` (G1/G4).
- CLI `ada control start|stop|status`.

**Dépend de :** rien. **Gate de décision :** aucune.
**Test d'acceptation :** un client de test fait `hello` → `run.init` → `run.next` → `run.status` en in-process ; les events streament ; HMAC vérifié de bout en bout (corrige le bug de reconstruction de ligne identifié à l'audit).

## P1 — NestJS + Control Plane Client + Postgres (lecture seule)

**But :** la nouvelle API parle au Control Server et expose tout le read-only.
**Livrables :**
- Bootstrap NestJS (coexiste avec Fastify le temps de la bascule), réutilise le JWT/Guards existants.
- `ControlPlaneClient` : connexion socket, reconnexion backoff, replay `events.ndjson` par cursor (G2/G3).
- `CapabilityDiscovery`, `HealthProbe`.
- Endpoints lecture : `GET /capabilities`, `/health`, `/runs`, `/memory`, `/router/stats`, `/stats/cost`, `/stats/metrics`.
- **Postgres (ADR-017)** : Drizzle pg, migrations des tables transactionnelles, schéma `pgboss.*`, ingestion des `events` (dédup `ON CONFLICT (id) DO NOTHING`).

**Dépend de :** P0. **Gate de décision :** aucune.
**Test d'acceptation :** `GET /capabilities` renvoie le manifeste live ; un `ada run` lancé en CLI fait apparaître ses events dans la table `events` Postgres.

## P2 — OrchestrationLoop (Mode A) — le moteur d'exécution

**But :** combler le gap #3 — une instruction exécute un pipeline sans humain dans un TTY.
**Livrables :**
- `POST /tasks` (mode pipeline), `JobQueue` pg-boss, `OrchestrationLoop` : `run.next` → `ProtocolAdapter.execute(claude -p --output-format stream-json --model <tier>)` → `run.done`/`run.fail`, boucle jusqu'à fin, phases `parallel_mesh` concurrentes.
- `StreamParser` NDJSON → events `run.phase.output`/`tool` ; `StreamGateway` WS streaming vers l'UI (routage par room workspace, fini `broadcastAll`).
- Persistance `runs` / `run_phases` / `messages` / `tool_calls` (ADR-017).
- `claude` résolu par **chemin absolu** ; rate-limit sur `POST /tasks`.

**Dépend de :** P1. **⛔ Gate de décision — Fork #1 (Planner mode:auto)** : on peut démarrer en exigeant `pipeline` explicite ; l'auto-routing instruction→pipeline est un sous-incrément (mots-clés / arbitrage LLM tier 1 / demander).
**Test d'acceptation :** `POST /tasks {pipeline:"feature", feature:"..."}` exécute le run de bout en bout en headless ; phases streament ; `run.completed` ; tokens/coût enregistrés en base.

## P3 — Sessions interactives + Permission Broker (Mode B) — cœur du remplacement du terminal

**But :** reproduire l'interactivité du TTY (la condition de complétude, ADR-016 §6bis).
**Livrables :**
- Session bidirectionnelle : `claude -p --input-format stream-json --output-format stream-json --resume`, process maintenu vivant ; messages entrants `task.message`/`interrupt`/`cancel`.
- **Permission Broker** : outil MCP `mcp__ada__approve` + events `task.permission_request`/`_response` + table `permission_requests` + `permission_policies` ; modes `default|acceptEdits|bypassPermissions|plan`.
- Plan mode + clarifications (`task.plan`/`clarification` ↔ réponses).
- `SessionManager` (`--resume`), persistance `sessions`/`messages`/`clarifications`/`plans`.

**Dépend de :** P2. **⛔ Gate de décision — Fork #2 (politique de permissions par défaut)** : niveau d'auto-approbation (`Read`=always, `Bash`/`Write`=prompt ?).
**Test d'acceptation :** une tâche interactive complète avec une approbation `Bash`, pilotée par un client de test, **sans ouvrir de terminal**.

## P4 — Surface CLI complète + ada-ui + cutover

**But :** valider la vision « zéro terminal » et basculer.
**Livrables :**
- Endpoints restants (matrice §6bis) : `profiles`, `skills`, `sync`, `bridge`, `federation`, `daemon`, `schedules`, `providers`, `pr`, `obsidian`, `logs`.
- Correctif UI : bug ticket WS (`useAdaWs` URL relative) ; ada-ui pointe sur NestJS ; dépréciation Fastify (ADR-015 SQLite retiré).
- Bascule Postgres big-bang à froid (script idempotent, ADR-017).

**Dépend de :** P3. **Gate de décision :** Fork #3 (pgvector ReasoningBank → ADR dédiée) ; Fork #4 (rétention/partitionnement `events`).
**Test d'acceptation de la vision :** « toute action faisable dans `ada launch` ou via une commande `ada` est faisable depuis ada-ui via ada-api, sans terminal » → matrice de complétude 100% verte.

---

## Risques de conception à valider avant P2 (revue adverse)

1. **Overhead `claude -p` par phase** : un spawn + chargement de config par phase peut être lent sur les pipelines longs. Mitigation prévue : sessions `--resume` + SDK natif en option. À benchmarker dès P2.
2. **Concurrence d'état `runs/<id>/state.json`** : si OrchestrationLoop (NestJS) et le Control Server écrivent l'état, qui détient le lock ? → règle : **seul le Control Server mute l'état** (NestJS passe par les méthodes RPC), pas d'écriture directe.
3. **Permission Broker = chemin critique de latence** : chaque outil gardé fait un aller-retour UI. Les politiques d'auto-approbation doivent court-circuiter localement (pas d'event) pour les outils `always`.
4. **Double source d'events** (NestJS driver vs Control Server hors-bande) : risque de doublons UI. → dédup stricte par `id` UUID côté StreamGateway, déjà prévue.

---

## Décision : par où démarrer

**P0 n'a aucun gate** et débloque tout le reste. Recommandation : lancer P0 immédiatement (création du Control Server), en parallèle de la mise en place du squelette NestJS + Postgres (P1, sans gate non plus).
