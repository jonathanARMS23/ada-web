# Changements Ada-Core pour Platform v2

## Principe

Ada-core reste le CLI inchangé dans sa logique métier. Trois additions non-breaking sont intégrées :

1. `emitIPC()` — envoi d'événements vers ada-api via socket
2. Append log `events.ndjson` — persistance locale des événements pour replay
3. Flag `--headless` — mode JSON structuré sans ANSI ni prompts interactifs

Les trois additions sont des **effets de bord optionnels et fire-and-forget**. Si ada-api est absent ou le socket indisponible, ada-core fonctionne exactement comme avant.

---

## Addition 1 : emitIPC() dans run.js

### Localisation

`coordinator/run.js` — à appeler après chaque `saveState()` / `writeRun()` qui modifie l'état d'un run ou d'une phase.

### Points d'appel

```javascript
// Après démarrage d'un run
await writeRun(runId, runData);
emitIPC('run:started', { runId, pipeline, prompt, conversationId, workspaceId });

// Après démarrage d'une phase
await saveState(runId, state);
emitIPC('run:phase:started', { runId, phaseId, agent, model });

// Après progression d'une phase (tokens)
emitIPC('run:phase:progress', { runId, phaseId, tokensSoFar, costSoFar, statusMessage });

// Après complétion d'une phase
await saveState(runId, state);
emitIPC('run:phase:completed', { runId, phaseId, agent, model, durationMs, tokens, cost, filesChanged });

// Après échec d'une phase
emitIPC('run:phase:failed', { runId, phaseId, agent, error, errorCode, retryable, durationMs });

// Après complétion du run
await writeRun(runId, finalRunData);
emitIPC('run:completed', { runId, pipeline, totalCost, totalTokens, durationMs, phasesCount });

// Après échec du run
emitIPC('run:failed', { runId, failedPhase, error, errorCode, totalCost, totalTokens, durationMs });

// Après annulation
emitIPC('run:cancelled', { runId, cancelledAt, totalCost, totalTokens });
```

### Implémentation complète de emitIPC()

```javascript
// coordinator/ipc-emit.js
// Fichier à créer séparément, importé dans run.js

import net from 'net';
import { randomUUID } from 'crypto';

const IPC_PATH    = process.env.ADA_API_IPC_PATH || '/tmp/ada-api.sock';
const IPC_HOST    = process.env.ADA_API_IPC_HOST;
const IPC_PORT    = parseInt(process.env.ADA_API_IPC_PORT || '3002', 10);
const IPC_TIMEOUT = parseInt(process.env.ADA_IPC_TIMEOUT  || '500',  10);  // ms

/**
 * Émet un événement vers ada-api via socket Unix ou TCP.
 * Fire-and-forget : ne bloque jamais run.js, n'entraîne aucune exception.
 *
 * @param {string} type    - Type d'événement (ex: 'run:phase:completed')
 * @param {object} payload - Données de l'événement
 */
export function emitIPC(type, payload) {
  const event = JSON.stringify({
    id:      randomUUID(),
    ts:      Date.now(),
    type,
    payload,
  }) + '\n';  // NDJSON framing

  const socket = IPC_HOST
    ? net.createConnection({ host: IPC_HOST, port: IPC_PORT })
    : net.createConnection({ path: IPC_PATH });

  // Timeout court : si ada-api ne répond pas en 500ms, on abandonne silencieusement
  socket.setTimeout(IPC_TIMEOUT);

  socket.on('connect', () => {
    socket.write(event, () => {
      socket.destroy();  // connexion courte : un message, on ferme
    });
  });

  // Toutes les erreurs sont silencieuses : ada-core ne doit pas crasher pour ada-api
  socket.on('timeout', () => socket.destroy());
  socket.on('error',   () => socket.destroy());
}
```

### Import dans run.js

```javascript
// Ajouter en haut de coordinator/run.js
import { emitIPC } from './ipc-emit.js';
```

---

## Addition 2 : events.ndjson append log

### Localisation

`coordinator/ipc-emit.js` — dans la même fonction `emitIPC()`, en plus de l'envoi socket.

### Rôle

Chaque événement émis vers ada-api est aussi appendé localement dans `.claude/events.ndjson`. Ce fichier sert de source de vérité pour :
- Le replay en cas de démarrage tardif d'ada-api
- L'audit offline des runs
- Le débogage des événements manqués

### Format d'une ligne

```json
{"id":"a1b2c3d4-e5f6-7890-abcd-ef1234567890","ts":1748686800000,"type":"run:phase:completed","payload":{"runId":"run_2026053102","phaseId":"backend_01","agent":"nestjs-expert","durationMs":12400}}
```

### Implémentation

```javascript
import fs   from 'fs';
import path from 'path';
import os   from 'os';

// Résolution du chemin : priorité ADA_EVENTS_LOG, sinon ~/.claude/events.ndjson
const EVENTS_LOG = process.env.ADA_EVENTS_LOG
  || path.join(os.homedir(), '.claude', 'events.ndjson');

/**
 * Appende un événement dans events.ndjson de manière synchrone.
 * Synchrone pour garantir l'ordre même si plusieurs phases terminent simultanément.
 * Silencieux en cas d'erreur FS (répertoire manquant, permissions, etc.).
 */
function appendEventLog(event) {
  try {
    fs.mkdirSync(path.dirname(EVENTS_LOG), { recursive: true });
    fs.appendFileSync(EVENTS_LOG, event, { encoding: 'utf8' });
  } catch {
    // Silencieux : le log local est un best-effort
  }
}

// Dans emitIPC(), avant ou après l'envoi socket :
export function emitIPC(type, payload) {
  const event = JSON.stringify({
    id:      randomUUID(),
    ts:      Date.now(),
    type,
    payload,
  }) + '\n';

  // 1. Append log local (synchrone, best-effort)
  appendEventLog(event);

  // 2. Envoi IPC vers ada-api (asynchrone, fire-and-forget)
  const socket = IPC_HOST
    ? net.createConnection({ host: IPC_HOST, port: IPC_PORT })
    : net.createConnection({ path: IPC_PATH });

  socket.setTimeout(IPC_TIMEOUT);
  socket.on('connect', () => { socket.write(event, () => socket.destroy()); });
  socket.on('timeout', () => socket.destroy());
  socket.on('error',   () => socket.destroy());
}
```

### Rotation du fichier

Ada-api peut lire events.ndjson et replayer les événements non encore traités au démarrage. Le fichier est tronqué par ada-api après replay réussi (ou après 7 jours selon la configuration `IPC_EVENTS_RETENTION_DAYS`).

---

## Addition 3 : --headless flag

### Localisation

`bin/ada.js` — dans `cmdStart()` et les fonctions CLI qui écrivent vers stdout.

### Activation

```bash
# Via flag CLI
ada start --headless

# Via variable d'environnement (prioritaire, pour systemd / docker)
ADA_HEADLESS=1 ada start
```

### Comportement en mode headless

| Comportement normal | Comportement headless |
|--------------------|-----------------------|
| Spinners ora avec ANSI | Désactivés |
| `process.stdout.write()` pour le progress | Supprimé |
| Logs colorisés chalk | JSON structuré sur stdout |
| Prompts inquirer interactifs | Désactivés (valeurs par défaut) |
| `console.log("✓ Phase terminée")` | `{"level":"info","msg":"phase_completed","phase":"backend_01","ts":1748686800000}` |

### Implémentation dans bin/ada.js

```javascript
// bin/ada.js

const HEADLESS = process.env.ADA_HEADLESS === '1'
  || process.argv.includes('--headless');

// Export pour les modules qui ont besoin de tester le mode
export { HEADLESS };

// Logger structuré (remplace console.log en mode headless)
export function log(level, msg, extra = {}) {
  if (HEADLESS) {
    process.stdout.write(JSON.stringify({
      level,
      msg,
      ts: Date.now(),
      ...extra,
    }) + '\n');
  } else {
    // Comportement normal selon level
    if (level === 'error') console.error(msg, extra);
    else                   console.log(msg);
  }
}

// Spinner wrapper
export function createSpinner(text) {
  if (HEADLESS) {
    log('info', text);
    return {
      start:   ()  => {},
      succeed: (t) => log('info', t || text),
      fail:    (t) => log('error', t || text),
      stop:    ()  => {},
    };
  }
  const ora = (await import('ora')).default;
  return ora(text);
}
```

### Utilisation dans run.js

```javascript
import { HEADLESS, log, createSpinner } from '../bin/ada.js';

// Avant
const spinner = ora('Démarrage du run...').start();

// Après
const spinner = createSpinner('Démarrage du run...');
spinner.start();
```

---

## Aucune modification de la logique métier

Les fichiers suivants ne sont **pas modifiés** :

| Fichier | Rôle | Statut |
|---------|------|--------|
| `coordinator/router.js` | Routing profil → agents | Inchangé |
| `coordinator/bank.js` | ReasoningBank, embeddings | Inchangé |
| `coordinator/embeddings.js` | Calcul embeddings | Inchangé |
| `coordinator/thompson.js` | Thompson Sampling | Inchangé |
| `coordinator/run.js` (logique) | Orchestration runs | Inchangé sauf appels emitIPC() |
| `agents/*.js` | Tous les agents | Inchangés |
| `hooks/*.js` | Hooks pré/post | Inchangés |
| `micro-lessons.js` | Micro-leçons | Inchangé |
| `ada-bridge.js` | Multi-profile bridge | Inchangé |

---

## Variables d'environnement ajoutées par ada-core

| Variable | Défaut | Description |
|----------|--------|-------------|
| `ADA_API_IPC_PATH` | `/tmp/ada-api.sock` | Socket Unix vers ada-api |
| `ADA_API_IPC_HOST` | — | Hôte TCP (si socket Unix non disponible) |
| `ADA_API_IPC_PORT` | `3002` | Port TCP IPC |
| `ADA_IPC_TIMEOUT` | `500` | Timeout socket en ms avant abandon |
| `ADA_EVENTS_LOG` | `~/.claude/events.ndjson` | Chemin du log NDJSON local |
| `ADA_HEADLESS` | `0` | `1` pour activer le mode headless |

---

## Tests recommandés

### Test unitaire emitIPC()

```javascript
// tests/unit/ipc-emit.test.js
import { describe, it, expect, vi, beforeEach } from 'vitest';
import net from 'net';

vi.mock('net');

describe('emitIPC', () => {
  it('fire-and-forget : ne jette pas si ada-api est absent', async () => {
    net.createConnection.mockReturnValue({
      setTimeout: vi.fn(),
      on: vi.fn().mockImplementation(function(event, cb) {
        if (event === 'error') cb(new Error('ENOENT'));
        return this;
      }),
      write: vi.fn(),
      destroy: vi.fn(),
    });

    const { emitIPC } = await import('../../coordinator/ipc-emit.js');
    expect(() => emitIPC('run:started', { runId: 'test' })).not.toThrow();
  });

  it('appende dans events.ndjson même si IPC échoue', async () => {
    const appendSpy = vi.spyOn(fs, 'appendFileSync').mockImplementation(() => {});
    emitIPC('run:started', { runId: 'test' });
    expect(appendSpy).toHaveBeenCalledOnce();
  });
});
```

### Test d'intégration ada-core ↔ ada-api

```bash
# 1. Démarrer ada-api
npm --prefix packages/ada-api start

# 2. Lancer un run en mode headless
ADA_HEADLESS=1 ada start --pipeline test-ping

# 3. Vérifier les événements reçus
curl -s http://localhost:3001/api/health/db | jq '.tables.ipc_events'
# Attendu : { "count": >0, "unprocessed": 0 }

# 4. Vérifier events.ndjson
wc -l ~/.claude/events.ndjson
```
