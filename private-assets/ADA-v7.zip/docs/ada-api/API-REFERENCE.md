# API Reference — Ada-API REST

## Conventions

### Base URL
```
http://localhost:3001
```

### Authentification

Toutes les routes sauf `/api/auth/token` et `/api/health` requièrent un token JWT dans le header :

```
Authorization: Bearer <token>
```

### Format des erreurs

Toutes les erreurs retournent le même format :

```json
{
  "error": {
    "code":    "CONVERSATION_NOT_FOUND",
    "message": "Conversation abc123 introuvable",
    "status":  404
  }
}
```

### Codes d'erreur courants

| Code | Status | Description |
|------|--------|-------------|
| `UNAUTHORIZED` | 401 | Token absent, invalide ou révoqué |
| `TOKEN_EXPIRED` | 401 | Token expiré |
| `FORBIDDEN` | 403 | Accès refusé à la ressource |
| `NOT_FOUND` | 404 | Ressource introuvable |
| `CONFLICT` | 409 | Conflit (ex. slug déjà pris) |
| `VALIDATION_ERROR` | 422 | Corps de requête invalide |
| `IPC_UNAVAILABLE` | 503 | Ada-core IPC non joignable |
| `INTERNAL_ERROR` | 500 | Erreur serveur interne |

### Pagination

Les listes supportent la pagination par cursor (time-based) :

```
GET /api/workspaces/:wid/conversations?cursor=<created_at_iso>&limit=20&direction=before
```

La réponse inclut :

```json
{
  "data":     [...],
  "meta": {
    "cursor_next": "2026-05-30T10:00:00.000Z",
    "cursor_prev": "2026-05-28T08:00:00.000Z",
    "has_more":    true,
    "total":       142
  }
}
```

---

## Auth

### POST /api/auth/token

Génère un token JWT. En mode `local` (développement), aucune credential n'est requise. En mode `password`, le mot de passe fourni est comparé avec `timingSafeEqual` — pas de hachage bcrypt, la vérification est en temps constant pour éviter les timing attacks.

Rate limit : **10 requêtes / 15 minutes** par IP.

**Request**

```
POST /api/auth/token
Content-Type: application/json
```

```json
{
  "password": "my-secure-password"
}
```

Le champ `password` est ignoré en `AUTH_MODE=local`.

**Response 200**

```json
{
  "token":      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "expires_at": "2026-06-01T10:00:00.000Z",
  "mode":       "local"
}
```

**Response 401**

```json
{
  "error": {
    "code":    "UNAUTHORIZED",
    "message": "Mot de passe incorrect",
    "status":  401
  }
}
```

**Exemple curl**

```bash
# Mode local — pas de body requis
curl -X POST http://localhost:3001/api/auth/token \
  -H "Content-Type: application/json" \
  -d '{}'

# Mode password
curl -X POST http://localhost:3001/api/auth/token \
  -H "Content-Type: application/json" \
  -d '{"password": "my-secure-password"}'
```

---

### POST /api/auth/refresh

Rafraîchit un token valide (non expiré). Révoque l'ancien token et en génère un nouveau.

**Request**

```
POST /api/auth/refresh
Authorization: Bearer <token>
```

**Response 200**

```json
{
  "token":      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "expires_at": "2026-06-02T10:00:00.000Z"
}
```

**Exemple curl**

```bash
curl -X POST http://localhost:3001/api/auth/refresh \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
```

---

### GET /api/ws/ticket

Génère un ticket WebSocket one-time-use. Le ticket est valide **30 secondes** et est consommé à la première connexion WS — toute réutilisation est rejetée.

Rate limit : **60 requêtes / minute** par IP.

**Request**

```
GET /api/ws/ticket
Authorization: Bearer <token>
```

**Response 200**

```json
{
  "ticket":    "550e8400-e29b-41d4-a716-446655440000",
  "expiresAt": "2026-06-01T10:00:30.000Z"
}
```

**Response 429** — rate limit dépassé

```json
{
  "error": {
    "code":    "RATE_LIMITED",
    "message": "Trop de requêtes. Réessayez dans 60s.",
    "status":  429
  }
}
```

**Exemple curl**

```bash
TICKET=$(curl -s http://localhost:3001/api/ws/ticket \
  -H "Authorization: Bearer $TOKEN" | jq -r .ticket)

# Puis connecter en WS
wscat -c "ws://localhost:3001/ws?ticket=$TICKET"
```

---

### DELETE /api/auth/session

Révoque le token courant (logout). Le token est supprimé de la table `sessions`.

**Request**

```
DELETE /api/auth/session
Authorization: Bearer <token>
```

**Response 204** — corps vide

**Exemple curl**

```bash
curl -X DELETE http://localhost:3001/api/auth/session \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
```

---

### GET /api/auth/me

Retourne les informations du token courant.

**Request**

```
GET /api/auth/me
Authorization: Bearer <token>
```

**Response 200**

```json
{
  "session_id": "sess_abc123",
  "issued_at":  "2026-05-31T10:00:00.000Z",
  "expires_at": "2026-06-01T10:00:00.000Z",
  "mode":       "local"
}
```

**Exemple curl**

```bash
curl http://localhost:3001/api/auth/me \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
```

---

## Health

Ces routes ne requièrent pas d'authentification.

### GET /api/health

Status global des trois composantes de la plateforme ADA.

**Request**

```
GET /api/health
```

**Response 200** — tout OK

```json
{
  "status": "healthy",
  "timestamp": "2026-05-31T10:00:00.000Z",
  "services": {
    "ada_api": {
      "status":   "healthy",
      "uptime_s": 3600
    },
    "ada_core_ipc": {
      "status":          "connected",
      "last_event_at":   "2026-05-31T09:58:00.000Z",
      "reconnect_count": 0
    },
    "database": {
      "status":        "healthy",
      "size_bytes":    1048576,
      "wal_size_bytes": 4096
    }
  }
}
```

**Response 200** — dégradé (ada-core absent)

```json
{
  "status": "degraded",
  "timestamp": "2026-05-31T10:00:00.000Z",
  "services": {
    "ada_api": { "status": "healthy", "uptime_s": 42 },
    "ada_core_ipc": {
      "status":          "disconnected",
      "last_event_at":   null,
      "reconnect_count": 7
    },
    "database": { "status": "healthy", "size_bytes": 524288, "wal_size_bytes": 0 }
  }
}
```

**Response 503** — DB inaccessible

```json
{
  "status": "unhealthy",
  "timestamp": "2026-05-31T10:00:00.000Z",
  "services": {
    "ada_api":      { "status": "healthy",      "uptime_s": 10 },
    "ada_core_ipc": { "status": "disconnected", "last_event_at": null, "reconnect_count": 0 },
    "database":     { "status": "error",        "error": "SQLITE_CANTOPEN" }
  }
}
```

---

### GET /api/health/core

Détail du canal IPC vers ada-core.

**Response 200**

```json
{
  "status":          "connected",
  "socket_path":     "/tmp/ada-core.sock",
  "last_event_at":   "2026-05-31T09:58:00.000Z",
  "last_event_type": "run:phase:completed",
  "reconnect_count": 0,
  "events_received": 1842
}
```

---

### GET /api/health/db

Statistiques SQLite.

**Response 200**

```json
{
  "status":     "healthy",
  "db_path":    "/Users/me/.ada/ada-api.db",
  "size_bytes": 1048576,
  "wal_size_bytes": 4096,
  "tables": {
    "workspaces":         { "count": 3 },
    "conversations":      { "count": 127 },
    "messages":           { "count": 4820 },
    "run_links":          { "count": 312 },
    "sessions":           { "count": 2 },
    "workspace_settings": { "count": 9 },
    "ipc_events":         { "count": 1842, "unprocessed": 0 }
  }
}
```

---

## Workspaces

### GET /api/workspaces

Liste tous les workspaces non supprimés.

**Request**

```
GET /api/workspaces?profile=claude-pro&limit=50
Authorization: Bearer <token>
```

**Query params**

| Param | Type | Description |
|-------|------|-------------|
| `profile` | string | Filtrer par profil ADA |
| `limit` | number | Nb résultats, défaut 50, max 200 |

**Response 200**

```json
{
  "data": [
    {
      "id":          "ws_01j1a2b3c4d5e6f7",
      "name":        "Projet Dental CRM",
      "slug":        "projet-dental-crm",
      "profile":     "claude-pro",
      "description": "Refonte complète du CRM dental",
      "color":       "#6366f1",
      "project_dir": "/Users/me/projects/dental-crm",
      "config":      {},
      "created_at":  "2026-05-01T09:00:00.000Z",
      "updated_at":  "2026-05-31T08:00:00.000Z",
      "stats": {
        "conversation_count": 24,
        "run_count":          87,
        "total_cost":         12.34,
        "total_tokens":       450000
      }
    }
  ],
  "meta": { "total": 3 }
}
```

**Exemple curl**

```bash
curl http://localhost:3001/api/workspaces \
  -H "Authorization: Bearer $TOKEN"
```

---

### POST /api/workspaces

Crée un nouveau workspace.

**Request**

```
POST /api/workspaces
Authorization: Bearer <token>
Content-Type: application/json
```

```json
{
  "name":        "Projet Dental CRM",
  "profile":     "claude-pro",
  "description": "Refonte complète du CRM dental",
  "color":       "#6366f1",
  "project_dir": "/Users/me/projects/dental-crm",
  "config": {
    "env": { "NODE_ENV": "development" },
    "default_pipeline": "fullstack"
  }
}
```

Le `slug` est auto-généré depuis `name` (slugify + déduplication si conflit).

**Response 201**

```json
{
  "id":          "ws_01j1a2b3c4d5e6f7",
  "name":        "Projet Dental CRM",
  "slug":        "projet-dental-crm",
  "profile":     "claude-pro",
  "description": "Refonte complète du CRM dental",
  "color":       "#6366f1",
  "project_dir": "/Users/me/projects/dental-crm",
  "config":      { "env": { "NODE_ENV": "development" }, "default_pipeline": "fullstack" },
  "created_at":  "2026-05-31T10:00:00.000Z",
  "updated_at":  "2026-05-31T10:00:00.000Z"
}
```

**Response 422 — validation**

```json
{
  "error": {
    "code":    "VALIDATION_ERROR",
    "message": "name est requis, profile est requis",
    "status":  422,
    "fields":  [
      { "field": "name",    "message": "Required" },
      { "field": "profile", "message": "Required" }
    ]
  }
}
```

**Exemple curl**

```bash
curl -X POST http://localhost:3001/api/workspaces \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name":    "Mon Projet",
    "profile": "claude-pro"
  }'
```

---

### GET /api/workspaces/:id

Détails d'un workspace avec ses statistiques.

**Request**

```
GET /api/workspaces/ws_01j1a2b3c4d5e6f7
Authorization: Bearer <token>
```

**Response 200**

```json
{
  "id":          "ws_01j1a2b3c4d5e6f7",
  "name":        "Projet Dental CRM",
  "slug":        "projet-dental-crm",
  "profile":     "claude-pro",
  "description": "Refonte complète du CRM dental",
  "color":       "#6366f1",
  "project_dir": "/Users/me/projects/dental-crm",
  "config":      {},
  "created_at":  "2026-05-01T09:00:00.000Z",
  "updated_at":  "2026-05-31T08:00:00.000Z",
  "stats": {
    "conversation_count": 24,
    "run_count":          87,
    "total_cost":         12.34,
    "total_tokens":       450000,
    "last_run_at":        "2026-05-31T09:55:00.000Z"
  },
  "settings": {
    "auto_summary":         true,
    "notification_level":   "all",
    "max_concurrent_runs":  1
  }
}
```

---

### PATCH /api/workspaces/:id

Modification partielle d'un workspace.

**Request**

```
PATCH /api/workspaces/ws_01j1a2b3c4d5e6f7
Authorization: Bearer <token>
Content-Type: application/json
```

```json
{
  "name":  "Dental CRM v2",
  "color": "#10b981"
}
```

Tous les champs sont optionnels. Seuls les champs fournis sont modifiés.

**Response 200** — workspace mis à jour (même format que GET)

---

### DELETE /api/workspaces/:id

Soft-delete d'un workspace. Les conversations et run_links sont préservés pour audit.

**Request**

```
DELETE /api/workspaces/ws_01j1a2b3c4d5e6f7
Authorization: Bearer <token>
```

**Response 204** — corps vide

**Response 409** — si un run est encore en statut `running`

```json
{
  "error": {
    "code":    "CONFLICT",
    "message": "Impossible de supprimer : 2 run(s) en cours dans ce workspace",
    "status":  409
  }
}
```

---

### GET /api/workspaces/:id/stats

Statistiques détaillées sur la période demandée.

**Request**

```
GET /api/workspaces/ws_01j1a2b3c4d5e6f7/stats?from=2026-05-01&to=2026-05-31
Authorization: Bearer <token>
```

**Response 200**

```json
{
  "workspace_id": "ws_01j1a2b3c4d5e6f7",
  "period": {
    "from": "2026-05-01T00:00:00.000Z",
    "to":   "2026-05-31T23:59:59.999Z"
  },
  "totals": {
    "runs":               87,
    "conversations":      24,
    "messages":           1240,
    "cost_usd":           12.34,
    "tokens_input":       320000,
    "tokens_output":      130000
  },
  "by_pipeline": [
    { "pipeline": "fullstack",      "runs": 42, "cost_usd": 6.10 },
    { "pipeline": "backend-nestjs", "runs": 31, "cost_usd": 4.80 },
    { "pipeline": "review",         "runs": 14, "cost_usd": 1.44 }
  ],
  "by_day": [
    { "date": "2026-05-31", "runs": 8, "cost_usd": 1.12, "tokens": 58000 }
  ]
}
```

---

## Conversations

### GET /api/workspaces/:wid/conversations

Liste les conversations d'un workspace, triées par `updated_at` DESC.

**Request**

```
GET /api/workspaces/ws_01j1a2b3c4d5e6f7/conversations?limit=20&pinned=true&archived=false
Authorization: Bearer <token>
```

**Query params**

| Param | Type | Description |
|-------|------|-------------|
| `cursor` | string | ISO 8601 — pagination cursor (valeur `updated_at`) |
| `limit` | number | Défaut 20, max 100 |
| `pinned` | boolean | Filtrer les épinglées uniquement |
| `archived` | boolean | Inclure les archivées (défaut false) |
| `search` | string | Recherche full-text dans title + summary |

**Response 200**

```json
{
  "data": [
    {
      "id":           "conv_01j2b3c4d5e6f7g8",
      "workspace_id": "ws_01j1a2b3c4d5e6f7",
      "title":        "Refactor module auth NestJS",
      "summary":      "Ajout JWT RS256, refresh tokens, tests Vitest.",
      "pinned":       false,
      "archived":     false,
      "run_count":    3,
      "last_run_id":  "run_2026053101",
      "created_at":   "2026-05-28T14:00:00.000Z",
      "updated_at":   "2026-05-31T09:55:00.000Z"
    }
  ],
  "meta": {
    "cursor_next": "2026-05-28T14:00:00.000Z",
    "has_more":    true,
    "total":       24
  }
}
```

---

### POST /api/workspaces/:wid/conversations

Crée une nouvelle conversation.

**Request**

```
POST /api/workspaces/ws_01j1a2b3c4d5e6f7/conversations
Authorization: Bearer <token>
Content-Type: application/json
```

```json
{
  "title": "Ajout feature paiements Stripe"
}
```

**Response 201**

```json
{
  "id":           "conv_01j2b3c4d5e6f7g8",
  "workspace_id": "ws_01j1a2b3c4d5e6f7",
  "title":        "Ajout feature paiements Stripe",
  "summary":      null,
  "pinned":       false,
  "archived":     false,
  "run_count":    0,
  "last_run_id":  null,
  "created_at":   "2026-05-31T10:00:00.000Z",
  "updated_at":   "2026-05-31T10:00:00.000Z"
}
```

---

### GET /api/conversations/:id

Détails d'une conversation.

**Request**

```
GET /api/conversations/conv_01j2b3c4d5e6f7g8
Authorization: Bearer <token>
```

**Response 200** — même format que dans la liste, avec le champ `workspace` inclus.

```json
{
  "id":           "conv_01j2b3c4d5e6f7g8",
  "workspace_id": "ws_01j1a2b3c4d5e6f7",
  "title":        "Refactor module auth NestJS",
  "summary":      "Ajout JWT RS256, refresh tokens, tests Vitest.",
  "pinned":       false,
  "archived":     false,
  "run_count":    3,
  "last_run_id":  "run_2026053101",
  "created_at":   "2026-05-28T14:00:00.000Z",
  "updated_at":   "2026-05-31T09:55:00.000Z",
  "workspace": {
    "id":      "ws_01j1a2b3c4d5e6f7",
    "name":    "Projet Dental CRM",
    "profile": "claude-pro",
    "color":   "#6366f1"
  }
}
```

---

### PATCH /api/conversations/:id

Modification partielle (titre, épinglage, archivage).

**Request**

```
PATCH /api/conversations/conv_01j2b3c4d5e6f7g8
Authorization: Bearer <token>
Content-Type: application/json
```

```json
{
  "pinned":  true,
  "title":   "Auth NestJS — JWT RS256 + refresh"
}
```

**Response 200** — conversation mise à jour.

---

### DELETE /api/conversations/:id

Suppression définitive de la conversation et de ses messages.

**Request**

```
DELETE /api/conversations/conv_01j2b3c4d5e6f7g8
Authorization: Bearer <token>
```

**Response 204** — corps vide.

---

### POST /api/conversations/:id/messages

Envoie un message utilisateur dans la conversation. Retourne le message créé. N'effectue pas de complétion LLM — c'est ada-core qui répond via IPC.

**Request**

```
POST /api/conversations/conv_01j2b3c4d5e6f7g8/messages
Authorization: Bearer <token>
Content-Type: application/json
```

```json
{
  "content":      "Ajoute un endpoint PATCH /users/:id/password",
  "content_type": "text"
}
```

**Response 201**

```json
{
  "id":              "msg_01j3c4d5e6f7g8h9",
  "conversation_id": "conv_01j2b3c4d5e6f7g8",
  "role":            "user",
  "content":         "Ajoute un endpoint PATCH /users/:id/password",
  "content_type":    "text",
  "metadata":        {},
  "created_at":      "2026-05-31T10:05:00.000Z"
}
```

---

### GET /api/conversations/:id/messages

Historique des messages avec pagination par cursor.

**Request**

```
GET /api/conversations/conv_01j2b3c4d5e6f7g8/messages?limit=50&cursor=2026-05-31T10:00:00.000Z&direction=before
Authorization: Bearer <token>
```

**Query params**

| Param | Type | Description |
|-------|------|-------------|
| `cursor` | string | ISO 8601 — valeur `created_at` du pivot |
| `limit` | number | Défaut 50, max 200 |
| `direction` | string | `before` (plus anciens) ou `after` (plus récents) |

**Response 200**

```json
{
  "data": [
    {
      "id":              "msg_01j3c4d5e6f7g8h9",
      "conversation_id": "conv_01j2b3c4d5e6f7g8",
      "role":            "user",
      "content":         "Ajoute un endpoint PATCH /users/:id/password",
      "content_type":    "text",
      "metadata":        {},
      "created_at":      "2026-05-31T10:05:00.000Z"
    },
    {
      "id":              "msg_01j3c4d5e6f7g8ha",
      "conversation_id": "conv_01j2b3c4d5e6f7g8",
      "role":            "assistant",
      "content":         "J'ai ajouté l'endpoint dans `src/users/users.controller.ts`...",
      "content_type":    "text",
      "metadata": {
        "runId":      "run_2026053101",
        "phaseId":    "phase_backend_01",
        "agent":      "nestjs-expert",
        "model":      "claude-opus-4-7",
        "tokens":     { "input": 4200, "output": 1850 },
        "cost":       0.0312,
        "duration_ms": 8450
      },
      "created_at": "2026-05-31T10:05:35.000Z"
    }
  ],
  "meta": {
    "cursor_next": "2026-05-31T10:05:35.000Z",
    "cursor_prev": "2026-05-31T10:05:00.000Z",
    "has_more":    false
  }
}
```

---

## Runs

### POST /api/runs

Spawne un nouveau run ada-core pour une conversation.

**Request**

```
POST /api/runs
Authorization: Bearer <token>
Content-Type: application/json
```

```json
{
  "conversation_id": "conv_01j2b3c4d5e6f7g8",
  "workspace_id":    "ws_01j1a2b3c4d5e6f7",
  "pipeline":        "fullstack",
  "prompt":          "Ajoute un endpoint PATCH /users/:id/password avec validation Zod",
  "options": {
    "model_tier": 2,
    "max_agents": 3
  }
}
```

**Response 201**

```json
{
  "run_id":          "run_2026053102",
  "conversation_id": "conv_01j2b3c4d5e6f7g8",
  "workspace_id":    "ws_01j1a2b3c4d5e6f7",
  "pipeline":        "fullstack",
  "status":          "running",
  "phases":          {},
  "total_cost":      0,
  "total_tokens":    0,
  "started_at":      "2026-05-31T10:05:00.000Z",
  "completed_at":    null
}
```

**Response 503** — ada-core IPC non joignable

```json
{
  "error": {
    "code":    "IPC_UNAVAILABLE",
    "message": "Ada-core IPC socket non joignable. Vérifiez que ada-core est démarré.",
    "status":  503
  }
}
```

**Exemple curl**

```bash
curl -X POST http://localhost:3001/api/runs \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "conversation_id": "conv_01j2b3c4d5e6f7g8",
    "workspace_id":    "ws_01j1a2b3c4d5e6f7",
    "pipeline":        "fullstack",
    "prompt":          "Ajoute un endpoint PATCH /users/:id/password"
  }'
```

---

### GET /api/runs/:id

État d'un run. Combine les données de `run_links` (DB) et du fichier `.claude/runs/<runId>/run.json` (FS ada-core).

**Request**

```
GET /api/runs/run_2026053102
Authorization: Bearer <token>
```

**Response 200**

```json
{
  "run_id":          "run_2026053102",
  "conversation_id": "conv_01j2b3c4d5e6f7g8",
  "workspace_id":    "ws_01j1a2b3c4d5e6f7",
  "pipeline":        "fullstack",
  "status":          "running",
  "phases": {
    "backend_01": {
      "status":    "completed",
      "agent":     "nestjs-expert",
      "model":     "claude-opus-4-7",
      "duration_ms": 12400,
      "tokens":    { "input": 5200, "output": 2100 },
      "cost":      0.0480
    },
    "frontend_01": {
      "status":     "running",
      "agent":      "nextjs-expert",
      "started_at": "2026-05-31T10:07:30.000Z"
    },
    "review_01": {
      "status": "pending",
      "agent":  "reviewer"
    }
  },
  "total_cost":   0.0480,
  "total_tokens": 7300,
  "started_at":   "2026-05-31T10:05:00.000Z",
  "completed_at": null,
  "core_data": {
    "prompt":   "Ajoute un endpoint PATCH /users/:id/password...",
    "topology": "sequential",
    "model_tier": 2
  }
}
```

---

### DELETE /api/runs/:id

Annule un run en envoyant SIGTERM au processus ada-core.

**Request**

```
DELETE /api/runs/run_2026053102
Authorization: Bearer <token>
```

**Response 202**

```json
{
  "run_id":  "run_2026053102",
  "status":  "cancelling",
  "message": "Signal SIGTERM envoyé au processus ada-core"
}
```

**Response 409** — le run est déjà terminé

```json
{
  "error": {
    "code":    "CONFLICT",
    "message": "Le run run_2026053102 est déjà terminé (status: completed)",
    "status":  409
  }
}
```

---

### POST /api/runs/:id/retry

Relance un run échoué depuis la première phase en erreur.

**Request**

```
POST /api/runs/run_2026053102/retry
Authorization: Bearer <token>
Content-Type: application/json
```

```json
{
  "from_phase": "frontend_01"
}
```

Si `from_phase` est omis, reprend depuis la première phase en échec.

**Response 201** — nouveau run_link créé

```json
{
  "run_id":          "run_2026053102_retry1",
  "original_run_id": "run_2026053102",
  "conversation_id": "conv_01j2b3c4d5e6f7g8",
  "pipeline":        "fullstack",
  "status":          "running",
  "started_at":      "2026-05-31T10:20:00.000Z"
}
```

---

### GET /api/runs

Liste tous les runs, optionnellement filtrés.

**Request**

```
GET /api/runs?workspace_id=ws_01j1a2b3c4d5e6f7&status=running&limit=20
Authorization: Bearer <token>
```

**Query params**

| Param | Type | Description |
|-------|------|-------------|
| `workspace_id` | string | Filtrer par workspace |
| `conversation_id` | string | Filtrer par conversation |
| `status` | string | `running` / `completed` / `failed` / `cancelled` |
| `cursor` | string | ISO 8601 de `started_at` |
| `limit` | number | Défaut 20, max 100 |

**Response 200**

```json
{
  "data": [
    {
      "run_id":          "run_2026053102",
      "conversation_id": "conv_01j2b3c4d5e6f7g8",
      "workspace_id":    "ws_01j1a2b3c4d5e6f7",
      "pipeline":        "fullstack",
      "status":          "running",
      "total_cost":      0.0480,
      "total_tokens":    7300,
      "started_at":      "2026-05-31T10:05:00.000Z",
      "completed_at":    null
    }
  ],
  "meta": {
    "cursor_next": "2026-05-31T10:05:00.000Z",
    "has_more":    false,
    "total":       1
  }
}
```

---

## Settings

### GET /api/settings

Settings globaux de l'instance ada-api.

**Request**

```
GET /api/settings
Authorization: Bearer <token>
```

**Response 200**

```json
{
  "auth_mode":             "local",
  "jwt_mode":              "hs256",
  "jwt_expires_in":        "24h",
  "ipc_path":              "/tmp/ada-core.sock",
  "ada_core_bin":          "ada",
  "ada_profiles_dir":      "/Users/me/.claude-pro",
  "cors_origins":          ["http://localhost:3000"],
  "ws_heartbeat_interval": 30000,
  "log_level":             "info",
  "db_path":               "/Users/me/.ada/ada-api.db"
}
```

---

### PATCH /api/settings

Modifie les settings modifiables à chaud (sans redémarrage).

**Request**

```
PATCH /api/settings
Authorization: Bearer <token>
Content-Type: application/json
```

```json
{
  "log_level":             "debug",
  "ws_heartbeat_interval": 15000
}
```

Seuls `log_level` et `ws_heartbeat_interval` sont modifiables à chaud. Les autres settings requièrent un redémarrage du service.

**Response 200**

```json
{
  "log_level":             "debug",
  "ws_heartbeat_interval": 15000,
  "message":               "Settings appliqués à chaud"
}
```

---

## Stats

### GET /api/stats/observe

Statistiques globales d'utilisation sur une fenêtre temporelle.

**Request**

```
GET /api/stats/observe?window=7d
Authorization: Bearer <token>
```

**Query params**

| Param | Type | Valeurs | Description |
|-------|------|---------|-------------|
| `window` | string | `7d` `30d` `session` | Fenêtre d'observation. `session` = depuis le dernier démarrage d'ada-api. Défaut : `7d` |

**Response 200**

```json
{
  "window": "7d",
  "from":   "2026-05-25T00:00:00.000Z",
  "to":     "2026-06-01T00:00:00.000Z",
  "totals": {
    "runs":            142,
    "completed":       128,
    "failed":           9,
    "cancelled":        5,
    "cost_usd":        48.21,
    "tokens_input":  820000,
    "tokens_output": 340000
  },
  "by_pipeline": [
    { "pipeline": "fullstack",      "runs": 68, "cost_usd": 23.40 },
    { "pipeline": "backend-nestjs", "runs": 47, "cost_usd": 16.10 },
    { "pipeline": "review",         "runs": 27, "cost_usd":  8.71 }
  ],
  "timeline": [
    { "date": "2026-05-31", "runs": 22, "cost_usd": 7.80, "tokens": 165000 },
    { "date": "2026-05-30", "runs": 18, "cost_usd": 6.20, "tokens": 131000 }
  ]
}
```

**Exemple curl**

```bash
curl "http://localhost:3001/api/stats/observe?window=30d" \
  -H "Authorization: Bearer $TOKEN"
```
