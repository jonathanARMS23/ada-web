# DB-SCHEMA — Schéma SQLite Ada-API

## Configuration SQLite

```sql
PRAGMA journal_mode = WAL;          -- Write-Ahead Logging : lectures non bloquées par écritures
PRAGMA synchronous = NORMAL;        -- Bon compromis perf / durabilité avec WAL
PRAGMA foreign_keys = ON;           -- Contraintes FK actives
PRAGMA temp_store = MEMORY;         -- Tables temporaires en RAM
PRAGMA mmap_size = 268435456;       -- 256 MB memory-mapped I/O
PRAGMA cache_size = -16000;         -- 16 MB cache pages (négatif = kibibytes)
```

Ces PRAGMA sont appliqués à chaque ouverture de connexion dans `src/db/client.js`.

---

## Tables

### workspaces

Espace de travail isolant un projet ou un contexte métier.

```sql
CREATE TABLE workspaces (
  id          TEXT PRIMARY KEY,
  name        TEXT NOT NULL,
  slug        TEXT NOT NULL UNIQUE,
  profile     TEXT NOT NULL,
  description TEXT,
  color       TEXT NOT NULL DEFAULT '#6366f1',
  project_dir TEXT,
  config      TEXT NOT NULL DEFAULT '{}',
  created_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  updated_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE INDEX idx_workspaces_slug    ON workspaces(slug);
CREATE INDEX idx_workspaces_profile ON workspaces(profile);

CREATE TRIGGER workspaces_updated_at
AFTER UPDATE ON workspaces
BEGIN
  UPDATE workspaces SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
  WHERE id = NEW.id;
END;
```

| Colonne | Type | Description |
|---------|------|-------------|
| `id` | TEXT | UUID v4 généré côté applicatif |
| `name` | TEXT | Nom lisible, ex. `"Projet Dental CRM"` |
| `slug` | TEXT | Identifiant URL-safe unique, ex. `"projet-dental-crm"` |
| `profile` | TEXT | Profil ADA utilisé, ex. `"claude-pro"`, `"claude-dev"` |
| `description` | TEXT | Texte libre, nullable |
| `color` | TEXT | Couleur hex pour l'UI, ex. `"#6366f1"` |
| `project_dir` | TEXT | Chemin absolu du répertoire projet lié, nullable |
| `config` | TEXT | JSON sérialisé : env vars overrides, conventions, hooks |

**Exemple config JSON :**
```json
{
  "env": { "NODE_ENV": "development", "DATABASE_URL": "postgres://..." },
  "conventions": { "lang": "fr", "commit_style": "conventional" },
  "default_pipeline": "fullstack"
}
```

---

### conversations

Fil de discussion liant messages utilisateur et événements d'un ou plusieurs runs ada-core.

```sql
CREATE TABLE conversations (
  id             TEXT PRIMARY KEY,
  workspace_id   TEXT NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  title          TEXT NOT NULL,
  summary        TEXT,
  pinned         INTEGER NOT NULL DEFAULT 0 CHECK(pinned IN (0, 1)),
  archived       INTEGER NOT NULL DEFAULT 0 CHECK(archived IN (0, 1)),
  run_count      INTEGER NOT NULL DEFAULT 0,
  last_run_id    TEXT,
  created_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  updated_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE INDEX idx_conversations_workspace_id  ON conversations(workspace_id);
CREATE INDEX idx_conversations_pinned        ON conversations(workspace_id, pinned) WHERE pinned = 1;
CREATE INDEX idx_conversations_archived      ON conversations(workspace_id, archived);
CREATE INDEX idx_conversations_updated_at    ON conversations(updated_at DESC);

CREATE TRIGGER conversations_updated_at
AFTER UPDATE ON conversations
BEGIN
  UPDATE conversations SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
  WHERE id = NEW.id;
END;
```

| Colonne | Type | Description |
|---------|------|-------------|
| `id` | TEXT | UUID v4 |
| `workspace_id` | TEXT | FK vers workspaces(id), cascade delete |
| `title` | TEXT | Titre généré ou saisi, ex. `"Refactor auth module"` |
| `summary` | TEXT | Résumé auto-généré après complétion du run, nullable |
| `pinned` | INTEGER | 0/1 booléen SQLite |
| `archived` | INTEGER | 0/1 — les conversations archivées n'apparaissent pas par défaut |
| `run_count` | INTEGER | Compteur incrémenté à chaque nouveau run lié |
| `last_run_id` | TEXT | runId du dernier run ada-core lié, nullable |

---

### messages

Messages individuels dans une conversation : saisie utilisateur, réponses assistant, logs de phases.

```sql
CREATE TABLE messages (
  id              TEXT PRIMARY KEY,
  conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  role            TEXT NOT NULL CHECK(role IN ('user', 'assistant', 'system', 'tool', 'error')),
  content         TEXT NOT NULL,
  content_type    TEXT NOT NULL DEFAULT 'text' CHECK(content_type IN ('text', 'code', 'run_status', 'phase_log')),
  metadata        TEXT NOT NULL DEFAULT '{}',
  created_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE INDEX idx_messages_conversation_id ON messages(conversation_id);
CREATE INDEX idx_messages_created_at      ON messages(conversation_id, created_at);
CREATE INDEX idx_messages_role            ON messages(conversation_id, role);
```

Pas de trigger `updated_at` : les messages sont immuables après insertion.

| Colonne | Type | Description |
|---------|------|-------------|
| `id` | TEXT | UUID v4 |
| `conversation_id` | TEXT | FK vers conversations(id), cascade delete |
| `role` | TEXT | `user` / `assistant` / `system` / `tool` / `error` |
| `content` | TEXT | Contenu Markdown |
| `content_type` | TEXT | Type de rendu attendu par l'UI |
| `metadata` | TEXT | JSON sérialisé avec contexte d'exécution |

**Valeurs de content_type :**

| Valeur | Usage |
|--------|-------|
| `text` | Message texte standard (user, assistant) |
| `code` | Bloc de code (diff, fichier généré) |
| `run_status` | Carte de statut run (démarrage, complétion) |
| `phase_log` | Log d'une phase individuelle ada-core |

**Exemple metadata JSON :**
```json
{
  "runId": "run_abc123",
  "phaseId": "phase_backend_01",
  "agent": "nestjs-expert",
  "model": "claude-opus-4-7",
  "tokens": { "input": 4200, "output": 1850 },
  "cost": 0.0312,
  "duration_ms": 8450
}
```

---

### run_links

Table pivot entre les run IDs d'ada-core (identifiants FS) et les conversations ada-api.

```sql
CREATE TABLE run_links (
  run_id          TEXT PRIMARY KEY,
  conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE RESTRICT,
  workspace_id    TEXT NOT NULL REFERENCES workspaces(id) ON DELETE RESTRICT,
  pipeline        TEXT NOT NULL,
  status          TEXT NOT NULL DEFAULT 'running'
                  CHECK(status IN ('running', 'completed', 'failed', 'cancelled', 'completed_with_errors')),
  phases          TEXT NOT NULL DEFAULT '{}',
  total_cost      REAL NOT NULL DEFAULT 0,
  total_tokens    INTEGER NOT NULL DEFAULT 0,
  started_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  completed_at    TEXT
);

CREATE INDEX idx_run_links_conversation_id ON run_links(conversation_id);
CREATE INDEX idx_run_links_workspace_id    ON run_links(workspace_id);
CREATE INDEX idx_run_links_status          ON run_links(status);
CREATE INDEX idx_run_links_started_at      ON run_links(started_at DESC);
```

ON DELETE RESTRICT sur les FK : on ne supprime pas un run_link en cascadant depuis workspace ou conversation — il faut d'abord annuler le run explicitement.

| Colonne | Type | Description |
|---------|------|-------------|
| `run_id` | TEXT | `runId` tel que retourné par ada-core (ex. `"run_2026053101"`) |
| `conversation_id` | TEXT | Conversation parente |
| `workspace_id` | TEXT | Dénormalisé pour queries rapides sans JOIN |
| `pipeline` | TEXT | Pipeline ada-core, ex. `"fullstack"`, `"backend-nestjs"` |
| `status` | TEXT | État synchronisé depuis les événements IPC |
| `phases` | TEXT | Snapshot JSON des phases ada-core (depuis `run.json`) |
| `total_cost` | REAL | Coût LLM cumulé en USD |
| `total_tokens` | INTEGER | Tokens cumulés (input + output) |
| `completed_at` | TEXT | ISO 8601, null tant que running |

**Exemple phases JSON :**
```json
{
  "backend_01": { "status": "completed", "agent": "nestjs-expert", "duration_ms": 12400 },
  "frontend_01": { "status": "running",   "agent": "nextjs-expert",  "started_at": "2026-05-31T10:22:00Z" },
  "review_01":   { "status": "pending",   "agent": "reviewer" }
}
```

---

### sessions

Tokens JWT actifs. Permet la révocation explicite (logout) avant expiration naturelle.

```sql
CREATE TABLE sessions (
  id          TEXT PRIMARY KEY,
  token_hash  TEXT NOT NULL UNIQUE,
  expires_at  TEXT NOT NULL,
  created_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE INDEX idx_sessions_token_hash  ON sessions(token_hash);
CREATE INDEX idx_sessions_expires_at  ON sessions(expires_at);
```

| Colonne | Type | Description |
|---------|------|-------------|
| `id` | TEXT | UUID v4 interne |
| `token_hash` | TEXT | SHA-256 hex du JWT raw (ne jamais stocker le token) |
| `expires_at` | TEXT | ISO 8601, copié du claim `exp` du JWT |

Job de nettoyage : une requête `DELETE FROM sessions WHERE expires_at < datetime('now')` est exécutée au démarrage et toutes les heures.

---

### workspace_settings

Paramètres clé/valeur par workspace. Extensible sans migration de schéma.

```sql
CREATE TABLE workspace_settings (
  workspace_id TEXT NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  key          TEXT NOT NULL,
  value        TEXT,
  PRIMARY KEY (workspace_id, key)
);

CREATE INDEX idx_workspace_settings_workspace_id ON workspace_settings(workspace_id);
```

| Colonne | Type | Description |
|---------|------|-------------|
| `workspace_id` | TEXT | FK vers workspaces(id) |
| `key` | TEXT | Nom du paramètre, ex. `"auto_summary"`, `"default_model"` |
| `value` | TEXT | JSON sérialisé, nullable (null = supprimé) |

**Clés réservées par ada-api :**

| Clé | Type valeur | Description |
|-----|-------------|-------------|
| `auto_summary` | boolean | Générer automatiquement un résumé après chaque run |
| `default_model` | string | Modèle LLM préféré pour ce workspace |
| `notification_level` | string | `"all"` / `"errors"` / `"none"` |
| `max_concurrent_runs` | number | 1-5, défaut 1 |

---

### ipc_events

Event store append-only pour audit et replay. Chaque événement reçu depuis ada-core via IPC est persisté avant traitement.

```sql
CREATE TABLE ipc_events (
  id         TEXT PRIMARY KEY,
  type       TEXT NOT NULL,
  payload    TEXT NOT NULL,
  processed  INTEGER NOT NULL DEFAULT 0 CHECK(processed IN (0, 1)),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE INDEX idx_ipc_events_processed    ON ipc_events(processed, created_at);
CREATE INDEX idx_ipc_events_type         ON ipc_events(type);
CREATE INDEX idx_ipc_events_created_at   ON ipc_events(created_at DESC);
```

| Colonne | Type | Description |
|---------|------|-------------|
| `id` | TEXT | UUID v4 |
| `type` | TEXT | Type d'événement IPC, ex. `"run:phase:completed"` |
| `payload` | TEXT | JSON complet de l'événement |
| `processed` | INTEGER | 0 = en attente, 1 = traité |

**Types d'événements IPC connus :**

| Type | Description |
|------|-------------|
| `run:started` | ada-core a démarré un nouveau run |
| `run:phase:started` | Une phase a commencé |
| `run:phase:completed` | Une phase s'est terminée avec succès |
| `run:phase:failed` | Une phase a échoué |
| `run:completed` | Run terminé, toutes phases OK |
| `run:failed` | Run échoué (au moins une phase bloquante) |
| `run:cancelled` | Run annulé par l'utilisateur |
| `run:progress` | Mise à jour de progression (tokens, cost) |
| `agent:message` | Message d'un agent (pour les messages de type `assistant`) |

Job de purge : les événements traités (`processed = 1`) de plus de 7 jours sont supprimés au démarrage.

---

## Migrations Drizzle

### Configuration drizzle.config.js

```javascript
import { defineConfig } from 'drizzle-kit';
import { env } from './src/config/env.js';

export default defineConfig({
  schema:    './src/db/schema.js',
  out:       './src/db/migrations',
  dialect:   'sqlite',
  dbCredentials: {
    url: env.DB_PATH,
  },
  verbose: true,
  strict:  true,
});
```

### Générer et appliquer une migration

```bash
# 1. Modifier src/db/schema.js

# 2. Générer le fichier SQL de migration
npm run db:generate
# → src/db/migrations/0001_add_run_links.sql

# 3. Appliquer en dev
npm run db:migrate

# 4. En production (migration au démarrage du service)
# src/server.js appelle migrate() avant listen()
```

### Stratégie de migration au démarrage

```javascript
// src/server.js
import { migrate } from 'drizzle-orm/better-sqlite3/migrator';
import { db } from './db/client.js';

// Applique toutes les migrations non encore appliquées
migrate(db, { migrationsFolder: './src/db/migrations' });
```

Les migrations sont idempotentes. Drizzle maintient une table interne `__drizzle_migrations` pour tracer les migrations appliquées.

---

## Schéma Drizzle (src/db/schema.js)

```javascript
import { sqliteTable, text, integer, real, primaryKey, index, uniqueIndex } from 'drizzle-orm/sqlite-core';
import { sql } from 'drizzle-orm';

const now = sql`(strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))`;

export const workspaces = sqliteTable('workspaces', {
  id:          text('id').primaryKey(),
  name:        text('name').notNull(),
  slug:        text('slug').notNull().unique(),
  profile:     text('profile').notNull(),
  description: text('description'),
  color:       text('color').notNull().default('#6366f1'),
  project_dir: text('project_dir'),
  config:      text('config').notNull().default('{}'),
  created_at:  text('created_at').notNull().default(now),
  updated_at:  text('updated_at').notNull().default(now),
}, (t) => ({
  slugIdx:    uniqueIndex('idx_workspaces_slug').on(t.slug),
  profileIdx: index('idx_workspaces_profile').on(t.profile),
}));

export const conversations = sqliteTable('conversations', {
  id:           text('id').primaryKey(),
  workspace_id: text('workspace_id').notNull().references(() => workspaces.id, { onDelete: 'cascade' }),
  title:        text('title').notNull(),
  summary:      text('summary'),
  pinned:       integer('pinned', { mode: 'boolean' }).notNull().default(false),
  archived:     integer('archived', { mode: 'boolean' }).notNull().default(false),
  run_count:    integer('run_count').notNull().default(0),
  last_run_id:  text('last_run_id'),
  created_at:   text('created_at').notNull().default(now),
  updated_at:   text('updated_at').notNull().default(now),
}, (t) => ({
  workspaceIdx: index('idx_conversations_workspace_id').on(t.workspace_id),
  updatedAtIdx: index('idx_conversations_updated_at').on(t.updated_at),
}));

export const messages = sqliteTable('messages', {
  id:              text('id').primaryKey(),
  conversation_id: text('conversation_id').notNull().references(() => conversations.id, { onDelete: 'cascade' }),
  role:            text('role', { enum: ['user', 'assistant', 'system', 'tool', 'error'] }).notNull(),
  content:         text('content').notNull(),
  content_type:    text('content_type', { enum: ['text', 'code', 'run_status', 'phase_log'] }).notNull().default('text'),
  metadata:        text('metadata').notNull().default('{}'),
  created_at:      text('created_at').notNull().default(now),
}, (t) => ({
  conversationIdx: index('idx_messages_conversation_id').on(t.conversation_id),
  createdAtIdx:    index('idx_messages_created_at').on(t.conversation_id, t.created_at),
}));

export const run_links = sqliteTable('run_links', {
  run_id:          text('run_id').primaryKey(),
  conversation_id: text('conversation_id').notNull().references(() => conversations.id, { onDelete: 'restrict' }),
  workspace_id:    text('workspace_id').notNull().references(() => workspaces.id, { onDelete: 'restrict' }),
  pipeline:        text('pipeline').notNull(),
  status:          text('status', { enum: ['running', 'completed', 'failed', 'cancelled', 'completed_with_errors'] }).notNull().default('running'),
  phases:          text('phases').notNull().default('{}'),
  total_cost:      real('total_cost').notNull().default(0),
  total_tokens:    integer('total_tokens').notNull().default(0),
  started_at:      text('started_at').notNull().default(now),
  completed_at:    text('completed_at'),
});

export const sessions = sqliteTable('sessions', {
  id:         text('id').primaryKey(),
  token_hash: text('token_hash').notNull().unique(),
  expires_at: text('expires_at').notNull(),
  created_at: text('created_at').notNull().default(now),
});

export const workspace_settings = sqliteTable('workspace_settings', {
  workspace_id: text('workspace_id').notNull().references(() => workspaces.id, { onDelete: 'cascade' }),
  key:          text('key').notNull(),
  value:        text('value'),
}, (t) => ({
  pk: primaryKey({ columns: [t.workspace_id, t.key] }),
}));

export const ipc_events = sqliteTable('ipc_events', {
  id:        text('id').primaryKey(),
  type:      text('type').notNull(),
  payload:   text('payload').notNull(),
  processed: integer('processed', { mode: 'boolean' }).notNull().default(false),
  created_at: text('created_at').notNull().default(now),
}, (t) => ({
  processedIdx: index('idx_ipc_events_processed').on(t.processed, t.created_at),
  typeIdx:      index('idx_ipc_events_type').on(t.type),
}));
```
