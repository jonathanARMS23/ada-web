# Ada-API — Serveur de plateforme ADA

## Rôle

Service intermédiaire entre **ada-core** (orchestrateur CLI Node.js) et **ada-ui** (interface web Next.js 15).

### Ce que possède ada-api
- Conversations et leurs messages
- Workspaces et leurs settings
- Sessions d'authentification
- `run_links` : pont entre les run IDs d'ada-core et les conversations

### Ce que ne possède PAS ada-api
- Runs, trajectoires, phases : propriété d'ada-core (fichiers `.claude/runs/`)
- Agents et leurs configurations : propriété d'ada-core
- Profils ADA : lus depuis le FS, non dupliqués en DB

---

## Stack

| Composant | Choix | Version |
|-----------|-------|---------|
| Runtime | Node.js | 22 LTS |
| Framework HTTP | Fastify | 4.x |
| WebSocket | @fastify/websocket | 8.x |
| CORS | @fastify/cors | 9.x |
| Auth middleware | @fastify/jwt | 8.x |
| ORM | Drizzle ORM | 0.30.x |
| Driver SQLite | better-sqlite3 | 9.x |
| JWT signing | jose | 5.x |
| IPC | net.Socket (Unix domain ou TCP) | stdlib |
| Tests unitaires | Vitest | 1.x |
| Tests HTTP | supertest | 7.x |

---

## Structure du projet

```
ada-api/
├── src/
│   ├── app.js                  # Factory Fastify : plugins, routes, hooks
│   ├── server.js               # Point d'entrée : listen + IPC connect
│   │
│   ├── config/
│   │   └── env.js              # Validation et export des variables d'environnement
│   │
│   ├── db/
│   │   ├── client.js           # Instance better-sqlite3 + WAL mode + PRAGMA
│   │   ├── schema.js           # Schéma Drizzle (tables, index, relations)
│   │   └── migrations/         # Fichiers SQL générés par drizzle-kit
│   │       ├── 0000_init.sql
│   │       └── meta/
│   │
│   ├── auth/
│   │   ├── jwt.js              # Sign / verify JWT (HS256 local, RS256 serveur)
│   │   └── middleware.js       # Fastify preHandler : extraction + vérification token
│   │
│   ├── ipc/
│   │   ├── client.js           # Connexion au socket ada-core + reconnect loop
│   │   ├── parser.js           # NDJSON framing : découpe flux TCP en événements
│   │   └── handler.js          # Dispatch des IpcEvent vers DB + WebSocket broadcast
│   │
│   ├── routes/
│   │   ├── auth.js             # POST /api/auth/token, refresh, DELETE, GET /me
│   │   ├── health.js           # GET /api/health, /health/core, /health/db
│   │   ├── workspaces.js       # CRUD /api/workspaces
│   │   ├── conversations.js    # CRUD /api/workspaces/:wid/conversations + messages
│   │   ├── runs.js             # POST/GET/DELETE /api/runs
│   │   └── settings.js         # GET/PATCH /api/settings
│   │
│   ├── ws/
│   │   ├── server.js           # Enregistrement du plugin WebSocket Fastify
│   │   ├── rooms.js            # Gestion rooms par workspace_id (Map<wid, Set<socket>>)
│   │   ├── handler.js          # Dispatch des UICommand reçues du client
│   │   └── heartbeat.js        # Émission périodique { type: "heartbeat" }
│   │
│   └── services/
│       ├── workspace.js        # Logique métier workspaces (slugify, stats)
│       ├── conversation.js     # Logique métier conversations (pagination, summary)
│       ├── run.js              # Spawn ada-core, lecture FS runs/, gestion SIGTERM
│       └── message.js          # Insertion messages, cursor pagination
│
├── tests/
│   ├── unit/
│   │   ├── ipc-parser.test.js
│   │   ├── auth-jwt.test.js
│   │   └── ws-rooms.test.js
│   └── integration/
│       ├── workspaces.test.js
│       ├── conversations.test.js
│       ├── runs.test.js
│       └── health.test.js
│
├── drizzle.config.js           # Configuration drizzle-kit (dialect: sqlite)
├── package.json
├── .env.example
└── README.md
```

---

## Démarrage

### Développement

```bash
# Installer les dépendances
npm install

# Générer les migrations depuis le schéma
npm run db:generate

# Appliquer les migrations
npm run db:migrate

# Démarrer en mode watch
npm run dev
```

### Production / systemd

```bash
npm run build   # transpile si TypeScript, sinon no-op
npm start       # node src/server.js
```

### Tests

```bash
# Tous les tests
npm test

# Watch mode
npm run test:watch

# Coverage
npm run test:coverage

# Tests d'intégration seulement
npm run test:integration
```

### Scripts package.json

```json
{
  "scripts": {
    "dev":              "node --watch src/server.js",
    "start":            "node src/server.js",
    "test":             "vitest run",
    "test:watch":       "vitest",
    "test:coverage":    "vitest run --coverage",
    "test:integration": "vitest run tests/integration",
    "db:generate":      "drizzle-kit generate",
    "db:migrate":       "drizzle-kit migrate",
    "db:studio":        "drizzle-kit studio"
  }
}
```

---

## Variables d'environnement

Toutes les variables sont validées au démarrage dans `src/config/env.js`. Le service refuse de démarrer si une variable requise est absente ou invalide.

| Variable | Requis | Défaut | Description |
|----------|--------|--------|-------------|
| `NODE_ENV` | non | `development` | `development` / `production` / `test` |
| `PORT` | non | `3001` | Port d'écoute HTTP + WebSocket |
| `HOST` | non | `127.0.0.1` | Interface d'écoute (mettre `0.0.0.0` pour Docker) |
| `DB_PATH` | non | `~/.ada/ada-api.db` | Chemin absolu du fichier SQLite |
| `JWT_SECRET` | oui* | — | Secret HS256 (min 32 chars). Requis si `JWT_MODE=hs256` |
| `JWT_PRIVATE_KEY_PATH` | oui* | — | Chemin clé privée RS256 PEM. Requis si `JWT_MODE=rs256` |
| `JWT_PUBLIC_KEY_PATH` | oui* | — | Chemin clé publique RS256 PEM. Requis si `JWT_MODE=rs256` |
| `JWT_MODE` | non | `hs256` | `hs256` (local) ou `rs256` (multi-instance) |
| `JWT_EXPIRES_IN` | non | `24h` | Durée de vie token (format ms/jose : `24h`, `7d`) |
| `ADA_CORE_IPC_PATH` | non | `/tmp/ada-core.sock` | Chemin socket Unix d'ada-core |
| `ADA_CORE_IPC_HOST` | non | — | Hôte TCP si pas de socket Unix |
| `ADA_CORE_IPC_PORT` | non | `3002` | Port TCP IPC (utilisé si `ADA_CORE_IPC_HOST` défini) |
| `ADA_CORE_BIN` | non | `ada` | Chemin ou nom du binaire ada-core (pour spawn runs) |
| `ADA_PROFILES_DIR` | non | `~/.claude-pro` | Répertoire des profils ADA |
| `CORS_ORIGINS` | non | `http://localhost:3000` | Origines CORS autorisées, séparées par virgule |
| `WS_HEARTBEAT_INTERVAL` | non | `30000` | Intervalle heartbeat WebSocket en ms |
| `LOG_LEVEL` | non | `info` | Niveau Fastify logger : `trace` / `debug` / `info` / `warn` / `error` |
| `AUTH_MODE` | non | `local` | `local` (auto-auth sans password) ou `password` |
| `AUTH_PASSWORD_HASH` | oui* | — | bcrypt hash du password admin. Requis si `AUTH_MODE=password` |

*Requis selon le mode configuré.

### Fichier .env.example

```bash
NODE_ENV=development
PORT=3001
HOST=127.0.0.1
DB_PATH=/Users/yourname/.ada/ada-api.db

# Auth — mode local (développement)
AUTH_MODE=local
JWT_MODE=hs256
JWT_SECRET=change-me-min-32-chars-long-secret
JWT_EXPIRES_IN=24h

# IPC vers ada-core (socket Unix)
ADA_CORE_IPC_PATH=/tmp/ada-core.sock
ADA_CORE_BIN=ada

# Profils
ADA_PROFILES_DIR=/Users/yourname/.claude-pro

# CORS
CORS_ORIGINS=http://localhost:3000

# Logs
LOG_LEVEL=info
```

---

## Architecture des flux

```
ada-core (CLI)
    │
    │  IPC socket (NDJSON over Unix/TCP)
    │  émis après chaque saveState() / writeRun()
    ▼
ada-api (Fastify)
    ├── Persiste dans SQLite (run_links, messages, ipc_events)
    ├── Broadcast aux clients WebSocket abonnés (room = workspace_id)
    └── Expose REST API consommée par ada-ui
         │
         │  HTTP REST + WebSocket
         ▼
      ada-ui (Next.js 15)
```

### Tolérance aux pannes

- **ada-core absent** : ada-api démarre normalement, le client IPC tente une reconnexion toutes les 5 secondes. Les routes REST fonctionnent, le status `/api/health/core` retourne `disconnected`.
- **ada-api absent** : ada-core fonctionne exactement comme avant (les appels `emitIPC()` sont fire-and-forget avec timeout 500ms).
- **ada-ui absente** : ada-api fonctionne normalement. Les WebSocket broadcasts n'ont simplement aucun abonné.
