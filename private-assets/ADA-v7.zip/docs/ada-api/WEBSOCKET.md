# WebSocket Protocol — Ada-API ↔ Ada-UI

## Obtenir un ticket

Avant d'ouvrir une connexion WebSocket, le client doit obtenir un ticket one-time-use auprès de l'API REST.

```bash
curl -X GET http://localhost:3001/api/ws/ticket \
  -H "Authorization: Bearer <jwt>"
```

Réponse :

```json
{
  "ticket":    "550e8400-e29b-41d4-a716-446655440000",
  "expiresAt": "2026-06-01T10:00:30.000Z"
}
```

Le ticket est valide **30 secondes**. Il est consommé à la première utilisation — toute tentative de réutilisation est rejetée avec code `4001`.

Rate limit : 60 requêtes/minute sur `GET /api/ws/ticket`.

---

## Connexion

La connexion se fait en **2 étapes** :

```
1. GET /api/ws/ticket
   Authorization: Bearer <jwt>
   → { ticket: "<uuid>", expiresAt: "..." }

2. ws://localhost:3001/ws?ticket=<uuid>
```

```javascript
// Exemple
const { ticket } = await fetch('/api/ws/ticket', {
  headers: { Authorization: `Bearer ${jwt}` }
}).then(r => r.json());

const socket = new WebSocket(`ws://localhost:3001/ws?ticket=${ticket}`);
```

Le token JWT n'est jamais passé en query string — seul le ticket éphémère est transmis dans l'URL.

---

## Authentification

1. Le client obtient un ticket via `GET /api/ws/ticket` (JWT requis dans le header).
2. Le client initie la connexion WebSocket avec `?ticket=<uuid>`.
3. Ada-api valide le ticket : vérifie son existence, son expiration (30s) et le marque comme consommé.
4. Le JWT associé au ticket est vérifié (signature, expiration, révocation dans `sessions`).
5. Si invalide ou expiré : fermeture immédiate avec code `4001` ou `4002`.
6. Si valide : le socket est enregistré dans la room de son workspace actif.

---

## Rooms

Chaque socket rejoint une room identifiée par `workspace_id`. Les événements ne sont broadcastés qu'aux clients de la même room.

```
Map<workspace_id: string, Set<WebSocket>>
```

Un client peut changer de room en envoyant la commande `join_room`.

Gestion des déconnexions : le socket est retiré de toutes ses rooms automatiquement sur `close` ou `error`.

---

## Heartbeat

Ada-api émet un message toutes les 30 secondes (configurable via `WS_HEARTBEAT_INTERVAL`) :

```json
{
  "type": "heartbeat",
  "ts":   1748686800000
}
```

Côté client : si aucun heartbeat reçu pendant `3 × WS_HEARTBEAT_INTERVAL` (défaut 90s), le client déclenche une reconnexion.

---

## Format des messages

### Enveloppe générique

Tous les messages (client → serveur et serveur → client) respectent la même enveloppe :

```json
{
  "type":    "<event_type>",
  "id":      "<uuid_message>",
  "ts":      1748686800000,
  "payload": { }
}
```

Le champ `id` permet de corréler une commande à son accusé de réception.

---

## Messages client → serveur (UICommands)

### join_room

Rejoint la room d'un workspace. Quitte automatiquement la room précédente.

```json
{
  "type": "join_room",
  "id":   "cmd_01j1a2b3",
  "ts":   1748686800000,
  "payload": {
    "workspace_id": "ws_01j1a2b3c4d5e6f7"
  }
}
```

Accusé de réception serveur :

```json
{
  "type": "room_joined",
  "id":   "cmd_01j1a2b3",
  "ts":   1748686800001,
  "payload": {
    "workspace_id": "ws_01j1a2b3c4d5e6f7",
    "members":      2
  }
}
```

---

### subscribe_run

S'abonne aux événements temps-réel d'un run spécifique.

```json
{
  "type": "subscribe_run",
  "id":   "cmd_01j1a2b4",
  "ts":   1748686800000,
  "payload": {
    "run_id": "run_2026053102"
  }
}
```

Accusé de réception :

```json
{
  "type": "run_subscribed",
  "id":   "cmd_01j1a2b4",
  "ts":   1748686800001,
  "payload": {
    "run_id": "run_2026053102",
    "status": "running"
  }
}
```

---

### unsubscribe_run

Se désabonne d'un run.

```json
{
  "type": "unsubscribe_run",
  "id":   "cmd_01j1a2b5",
  "ts":   1748686800000,
  "payload": {
    "run_id": "run_2026053102"
  }
}
```

---

### cancel_run

Demande l'annulation d'un run (équivalent à DELETE /api/runs/:id).

```json
{
  "type": "cancel_run",
  "id":   "cmd_01j1a2b6",
  "ts":   1748686800000,
  "payload": {
    "run_id": "run_2026053102"
  }
}
```

Accusé de réception :

```json
{
  "type": "run_cancelling",
  "id":   "cmd_01j1a2b6",
  "ts":   1748686800001,
  "payload": {
    "run_id":  "run_2026053102",
    "message": "SIGTERM envoyé"
  }
}
```

---

### ping

Ping applicatif (distinct du WebSocket ping/pong frame). Permet au client de mesurer la latence.

```json
{
  "type": "ping",
  "id":   "cmd_01j1a2b7",
  "ts":   1748686800000,
  "payload": {}
}
```

Réponse serveur :

```json
{
  "type": "pong",
  "id":   "cmd_01j1a2b7",
  "ts":   1748686800001,
  "payload": {
    "latency_ms": 1
  }
}
```

---

## Messages serveur → client (ApiEvents)

### run:started

Émis quand ada-core démarre un nouveau run. Envoyé à toute la room workspace.

```json
{
  "type": "run:started",
  "id":   "evt_01j2b3c4",
  "ts":   1748686800000,
  "payload": {
    "run_id":          "run_2026053102",
    "conversation_id": "conv_01j2b3c4d5e6f7g8",
    "workspace_id":    "ws_01j1a2b3c4d5e6f7",
    "pipeline":        "fullstack",
    "prompt_preview":  "Ajoute un endpoint PATCH /users/:id/password...",
    "started_at":      "2026-05-31T10:05:00.000Z"
  }
}
```

---

### run:phase:started

Émis quand une phase individuelle commence.

```json
{
  "type": "run:phase:started",
  "id":   "evt_01j2b3c5",
  "ts":   1748686810000,
  "payload": {
    "run_id":      "run_2026053102",
    "phase_id":    "backend_01",
    "agent":       "nestjs-expert",
    "model":       "claude-opus-4-7",
    "started_at":  "2026-05-31T10:05:10.000Z"
  }
}
```

---

### run:phase:progress

Mise à jour de progression d'une phase (tokens streamés, coût intermédiaire).

```json
{
  "type": "run:phase:progress",
  "id":   "evt_01j2b3c6",
  "ts":   1748686815000,
  "payload": {
    "run_id":         "run_2026053102",
    "phase_id":       "backend_01",
    "tokens_so_far":  2400,
    "cost_so_far":    0.0210,
    "status_message": "Génération du contrôleur..."
  }
}
```

---

### run:phase:completed

Émis quand une phase se termine avec succès.

```json
{
  "type": "run:phase:completed",
  "id":   "evt_01j2b3c7",
  "ts":   1748686825000,
  "payload": {
    "run_id":      "run_2026053102",
    "phase_id":    "backend_01",
    "agent":       "nestjs-expert",
    "model":       "claude-opus-4-7",
    "duration_ms": 12400,
    "tokens": {
      "input":  5200,
      "output": 2100
    },
    "cost":        0.0480,
    "files_changed": [
      "src/users/users.controller.ts",
      "src/users/users.service.ts",
      "src/users/dto/update-password.dto.ts"
    ]
  }
}
```

---

### run:phase:failed

Émis quand une phase échoue.

```json
{
  "type": "run:phase:failed",
  "id":   "evt_01j2b3c8",
  "ts":   1748686830000,
  "payload": {
    "run_id":      "run_2026053102",
    "phase_id":    "frontend_01",
    "agent":       "nextjs-expert",
    "error":       "Rate limit exceeded",
    "error_code":  "RATE_LIMIT",
    "retryable":   true,
    "duration_ms": 3200
  }
}
```

---

### run:completed

Émis quand toutes les phases du run sont terminées avec succès.

```json
{
  "type": "run:completed",
  "id":   "evt_01j2b3c9",
  "ts":   1748686900000,
  "payload": {
    "run_id":          "run_2026053102",
    "conversation_id": "conv_01j2b3c4d5e6f7g8",
    "pipeline":        "fullstack",
    "total_cost":      0.1240,
    "total_tokens":    18500,
    "duration_ms":     95000,
    "phases_count":    3,
    "completed_at":    "2026-05-31T10:06:35.000Z"
  }
}
```

---

### run:failed

Émis quand le run échoue (phase bloquante non retryable ou timeout global).

```json
{
  "type": "run:failed",
  "id":   "evt_01j2b3ca",
  "ts":   1748686900000,
  "payload": {
    "run_id":       "run_2026053102",
    "failed_phase": "frontend_01",
    "error":        "Rate limit exceeded après 3 tentatives",
    "error_code":   "MAX_RETRIES_EXCEEDED",
    "total_cost":   0.0480,
    "total_tokens": 7300,
    "duration_ms":  42000
  }
}
```

---

### run:cancelled

Émis quand un run est annulé (SIGTERM reçu par ada-core).

```json
{
  "type": "run:cancelled",
  "id":   "evt_01j2b3cb",
  "ts":   1748686900000,
  "payload": {
    "run_id":       "run_2026053102",
    "cancelled_at": "2026-05-31T10:06:00.000Z",
    "total_cost":   0.0480,
    "total_tokens": 7300
  }
}
```

---

### message:created

Émis quand un nouveau message est inséré dans une conversation (user ou assistant).

```json
{
  "type": "message:created",
  "id":   "evt_01j2b3cc",
  "ts":   1748686900000,
  "payload": {
    "message": {
      "id":              "msg_01j3c4d5e6f7g8ha",
      "conversation_id": "conv_01j2b3c4d5e6f7g8",
      "role":            "assistant",
      "content":         "J'ai ajouté l'endpoint dans `src/users/users.controller.ts`...",
      "content_type":    "text",
      "metadata": {
        "runId":       "run_2026053102",
        "phaseId":     "backend_01",
        "agent":       "nestjs-expert",
        "model":       "claude-opus-4-7",
        "tokens":      { "input": 5200, "output": 2100 },
        "cost":        0.0480,
        "duration_ms": 12400
      },
      "created_at": "2026-05-31T10:06:35.000Z"
    }
  }
}
```

---

### conversation:updated

Émis quand une conversation est modifiée (titre auto-généré, run_count incrémenté, etc.).

```json
{
  "type": "conversation:updated",
  "id":   "evt_01j2b3cd",
  "ts":   1748686900000,
  "payload": {
    "conversation_id": "conv_01j2b3c4d5e6f7g8",
    "changes": {
      "run_count":   4,
      "last_run_id": "run_2026053102",
      "updated_at":  "2026-05-31T10:06:35.000Z"
    }
  }
}
```

---

### core:status

Émis quand l'état du canal IPC vers ada-core change (connexion/déconnexion).

```json
{
  "type": "core:status",
  "id":   "evt_01j2b3ce",
  "ts":   1748686900000,
  "payload": {
    "status":          "connected",
    "reconnect_count": 0,
    "socket_path":     "/tmp/ada-core.sock"
  }
}
```

Valeurs de `status` : `"connected"` / `"disconnected"` / `"reconnecting"`.

---

### error

Émis en réponse à une UICommand invalide ou si une erreur serveur survient.

```json
{
  "type": "error",
  "id":   "cmd_01j1a2b6",
  "ts":   1748686900000,
  "payload": {
    "code":    "RUN_NOT_FOUND",
    "message": "Le run run_9999 est introuvable",
    "status":  404
  }
}
```

Le `id` reprend celui de la commande qui a déclenché l'erreur.

---

## Reconnexion côté client

Implémentation recommandée avec backoff exponentiel :

```javascript
class AdaWebSocket {
  #attempts = 0;
  #socket   = null;
  #maxDelay = 30_000;

  // Obtenir un ticket puis connecter
  async connect(jwt) {
    // 1. Récupérer un ticket one-time-use (30s)
    const res = await fetch('http://localhost:3001/api/ws/ticket', {
      headers: { Authorization: `Bearer ${jwt}` }
    });
    if (!res.ok) { this.onAuthError?.(); return; }
    const { ticket } = await res.json();

    // 2. Connecter avec le ticket
    const url = `ws://localhost:3001/ws?ticket=${ticket}`;
    this.#socket = new WebSocket(url);

    this.#socket.addEventListener('open', () => {
      this.#attempts = 0;   // reset après connexion stable > 10s
      this.onOpen?.();
    });

    this.#socket.addEventListener('close', (event) => {
      if (event.code === 1000) return;   // fermeture volontaire, ne pas reconnecter
      if (event.code === 4001 || event.code === 4002) {
        this.onTokenExpired?.();          // refresh JWT puis reconnecter
        return;
      }
      if (event.code === 4003) {
        setTimeout(() => this.connect(jwt), 60_000);  // rate limit
        return;
      }
      this.#scheduleReconnect(jwt);
    });

    this.#socket.addEventListener('message', (event) => {
      this.onMessage?.(JSON.parse(event.data));
    });
  }

  #scheduleReconnect(jwt) {
    const delay = Math.min(
      1000 * Math.pow(2, this.#attempts - 1),
      this.#maxDelay
    );
    // attempts 0 → immédiat, 1 → 1s, 2 → 2s, 3 → 4s, 4 → 8s, ...
    setTimeout(() => {
      this.#attempts++;
      this.connect(jwt);
    }, this.#attempts === 0 ? 0 : delay);
  }

  send(type, payload, id = crypto.randomUUID()) {
    this.#socket?.send(JSON.stringify({ type, id, ts: Date.now(), payload }));
    return id;
  }

  close() {
    this.#socket?.close(1000);
  }
}
```

---

## Codes de fermeture

| Code | Nom | Signification | Action client recommandée |
|------|-----|---------------|--------------------------|
| 1000 | Normal Closure | Fermeture propre initiée par le serveur ou le client | Ne pas reconnecter |
| 1001 | Going Away | Shutdown serveur en cours (restart, deploy) | Reconnecter après 5s |
| 1006 | Abnormal Closure | Perte réseau, processus tué | Reconnecter avec backoff |
| 1011 | Internal Error | Erreur non gérée côté serveur | Reconnecter avec backoff |
| 4001 | Ticket Invalid | Ticket absent, déjà utilisé, expiré (>30s) ou JWT associé invalide | Obtenir un nouveau ticket via GET /api/ws/ticket, reconnecter |
| 4002 | Token Expired | JWT associé au ticket expiré (claim `exp` dépassé) | Appeler POST /api/auth/refresh, obtenir un nouveau ticket, reconnecter |
| 4003 | Rate Limited | Trop de connexions depuis cette IP | Attendre 60s avant de reconnecter |
| 4004 | Session Revoked | JWT révoqué explicitement (logout) | Rediriger vers la page de login |

---

## Exemple complet : cycle de vie d'un run

```
Client                          Ada-API                         Ada-Core
  |                               |                               |
  |-- join_room (workspace) ----> |                               |
  |<- room_joined ---------------|                               |
  |                               |                               |
  |-- POST /api/runs ------------>|-- spawn ada-core -----------> |
  |<- 201 { run_id } ------------|                               |
  |                               |                               |
  |-- subscribe_run (run_id) ---> |                               |
  |<- run_subscribed ------------|                               |
  |                               |                               |
  |                               |<- IPC: run:started ----------|
  |<- run:started ---------------|                               |
  |                               |                               |
  |                               |<- IPC: run:phase:started ----|
  |<- run:phase:started ---------|                               |
  |                               |                               |
  |                               |<- IPC: run:phase:progress ---|
  |<- run:phase:progress --------|  (plusieurs fois)             |
  |                               |                               |
  |                               |<- IPC: run:phase:completed --|
  |<- run:phase:completed --------|                               |
  |<- message:created (assistant)|  (message inséré en DB)       |
  |                               |                               |
  |                               |<- IPC: run:completed --------|
  |<- run:completed --------------|                               |
  |<- conversation:updated -------|                               |
```
