# ADR-001 — Routage Thompson Sampling pour la sélection d'agents

**Date** : 2026-05-23
**Statut** : Accepté
**Décideur** : Équipe ADA

## Contexte

ADA orchestre des runs multi-phases. Chaque phase (schema, specs, backend, frontend, coverage, review, deploy) doit être assignée à un agent parmi les candidats définis dans `PHASE_CANDIDATES`. Au démarrage du projet, certains types de phases admettent plusieurs candidats réels.

> ⚠ **Amendé le 2026-08-04** — les exemples donnés à l'origine (`backend: ['nestjs','drf']`, `task:frontend: ['nextjs','react-native']`) étaient de MAUVAIS exemples : ce ne sont pas des candidats substituables mais des stacks mutuellement exclusives. Voir l'amendement en fin de document.

Une sélection déterministe (round-robin, priorité fixe) ignore les données de performance accumulées et ne s'adapte pas à la dérive de qualité d'un agent. Une sélection purement aléatoire maximise l'exploration mais converge lentement et gaspille des tokens sur des agents peu performants.

## Décision

Utiliser **Thompson Sampling** basé sur une distribution Beta pour sélectionner l'agent optimal à chaque phase.

### Principe

Chaque paire `(phaseType, agent)` maintient un prior `Beta(α, β)` :

- `α = succès + 1` (prior optimiste — évite d'exclure un agent sans données)
- `β = échecs + 1`

Au moment du routage, on tire un échantillon `θ ~ Beta(α, β)` pour chaque candidat et on sélectionne celui avec le sample le plus élevé. Après exécution :

- succès → `α++`
- échec → `β++`

Le mécanisme converge naturellement vers l'exploitation sans jamais fermer l'exploration.

### Decay périodique

Un facteur de decay `0.95` est appliqué aux priors (voir amendement §3/§4 pour la
formule en vigueur — les compteurs `successes`/`failures` sont décayés eux aussi, et
la protection EWC dépend de la récence) :

```
α = max(1, α × facteurEffectif)
β = max(1, β × facteurEffectif)
```

Cela permet à un agent dont les performances se sont dégradées de regagner des opportunités sans réinitialiser l'historique.

### Modèles par tier

Le router associe également un tier de modèle à chaque recommandation. La table
tier→modèle n'est pas dupliquée ici : source unique de vérité
`.claude/coordinator/models.js` (`TIER_MODELS`), consommée via
`router.recommendModel(tier)` — tier 1 = Haiku, 2 = Sonnet, 3 = Opus.

### Protection contre les accès concurrents

L'état `router-state.json` est protégé par un verrou fichier `O_EXCL` (atomic, sans TOCTOU). Un verrou zombie de plus de 8 secondes est supprimé automatiquement. L'attente entre tentatives utilise `Atomics.wait()` pour éviter de spawner un processus externe.

## Alternatives considérées

| Alternative | Avantage | Inconvénient |
|-------------|----------|--------------|
| Round-robin | Simple, équitable | Ignore les performances réelles |
| Priority-first (score fixe) | Prévisible | Ne s'adapte pas à la dérive de qualité |
| UCB1 (Upper Confidence Bound) | Convergence prouvée | Requiert un compteur de tirages global ; moins naturel pour des événements binaires succès/échec |
| Epsilon-greedy | Simple à implémenter | Epsilon fixe = exploration constante même après convergence |

## Conséquences

**Positives :**
- Sélection adaptive sans configuration manuelle des priorités
- Le decay à 0.95 permet la réadaptation sans effacer l'historique
- Les phases mono-candidat sont quand même tracées (détection de dégradation future)
- L'efficacité tokens (`meanTokens`, `efficiencySample`) est capturée pour orienter le tier de modèle

**Négatives / Compromis :**
- La convergence nécessite un volume de runs minimal ; sur un projet démarrant, le comportement est proche du random
- L'état est local à `~/.claude[-<profil>]/coordinator/router-state.json` — non partagé entre machines
- Le verrou fichier impose une latence de 50 ms par contention (acceptable, les runs durent plusieurs secondes)

## Statut de mise en œuvre

- Algorithme principal : `.claude/coordinator/router.js` — fonctions `recommend()`, `update()`, `decay()`
- Mise à jour post-run : `.claude/hooks/session-end.js`
- CLI d'inspection : `node router.js stats` / `node router.js recommend <phaseType>`

---

## Amendement 2026-08-04 — périmètre de l'arbitrage et sémantique du decay

Un audit du routeur a montré que la décision d'origine était appliquée à des choix
qui ne sont pas arbitrables, et que le decay ne faisait pas ce qu'il documentait.
Quatre corrections, sans remettre en cause Thompson Sampling lui-même.

### 1. Thompson n'arbitre QUE des choix réellement substituables

Une **stack** n'est pas une variante dont on peut apprendre « laquelle est
meilleure » : un projet est NestJS **ou** Django, iOS **ou** Android. Router
`backend: ['nestjs','drf']` par Thompson envoyait un agent incompatible avec le
projet ~50 % du temps — et jusqu'à ~46 % **même avec un contexte de stack explicite**,
parce que le garde-fou contextuel ne s'appliquait qu'en confiance `low`/`none` alors
que dès n≥4 la confiance passait à `medium`/`high` et écrasait le contexte.

Décision : les familles de stacks (`STACK_FAMILIES` dans `router.js`) sont retirées
de `PHASE_CANDIDATES` et résolues **déterministement**, dans cet ordre absolu :

1. stack déclarée (`--backend`, `state.args.backend`) — jamais écrasable par un prior ;
2. stack détectée sur le disque (`nest-cli.json`, `manage.py`, deps) ;
3. premier candidat déclaré (défaut documenté).

`PHASE_CANDIDATES` ne contient plus que des choix où ≥2 agents sont objectivement
qualifiés pour la même phase, indépendamment de la stack : `review` et `deps`
(reviewer ↔ security-auditor), `safety` (reviewer ↔ migration-strategist),
`data-model` (data-modeler ↔ db), plus les familles `task:*` de spécialistes.
Constat honnête de l'audit : sur ~50 phases de `pipelines.json`, la grande majorité
n'a qu'**un** agent qualifié — Thompson n'a légitimement rien à y arbitrer.

Corollaire : `PHASE_CANDIDATES` étant indexé par `phase.id` nu alors qu'un même id
existe dans plusieurs pipelines avec des agents de familles différentes (`review` =
reviewer, technical-architect ou performance-analyst selon le pipeline),
`run.js:selectAgentForPhase` ne consulte le routeur que si l'agent **déclaré** par le
pipeline fait partie des candidats.

### 2. Les priors mono-candidat restent écrits (ce n'est pas de l'écriture morte)

Ils ne servent pas à l'arbitrage mais alimentent `predictive-estimator`
(`meanTokens`, `meanDurationMs`, `successRate`), `router stats`, `ewc report`,
`workers/metrics` et never-worse. Ils sont conservés délibérément.

### 3. Le decay décaie aussi `successes`/`failures`

`confidence` et `winRate` sont calculés depuis ces compteurs, **pas** depuis α/β.
Ne décayer que α/β laissait la confiance figée en `high` à vie : ni l'exploration
Thompson ni le garde-fou contextuel ne se rouvraient jamais. Le decay est
proportionnel (même facteur) : le ratio `winRate` est préservé, seule la masse de
preuve diminue.

### 4. La protection EWC dépend de la RÉCENCE, pas du volume

L'importance Fisher `1 − var/(1/12)` croît de façon monotone avec `n` : utilisée
seule comme facteur de protection, elle protégeait **le plus** les priors les plus
anciens — exactement l'inverse de l'intention du decay, jusqu'au gel complet
(`effectiveFactor = 1.0` avec `ewcStrength = 1`). L'EWC réel protège ce qui importe
encore, pas ce qui a accumulé du volume. Nouvelle formule :

```
protection      = certitude Fisher × récence          (récence = 0.5^(âge/demi-vie), demi-vie 30 j)
effectiveFactor = min(factor + (1−factor)·protection·ewcStrength, 0.999)
```

`router.update()` horodate désormais chaque prior (`lastUpdatedAt`) ; `seed()`
utilise la date réelle du run importé. Un prior sans horodatage (état legacy) est
traité comme ancien — donc non protégé. Le plafond `0.999` garantit qu'aucun prior
n'est gelé indéfiniment.

### Notes de mise à jour

- `decay()` prend le même verrou `O_EXCL` que `update()` (il réécrit tous les priors).
- Il n'existe pas de decay automatique « toutes les 30 mises à jour » : le decay est
  déclenché explicitement (`node router.js decay`).
- L'attente sur verrou n'utilise pas `Atomics.wait()` (interdit sur le main thread
  Node.js 20+) : tentative unique + nettoyage de verrou zombie > 8 s.
- La table tier→modèle n'est plus dupliquée ici : source unique
  `.claude/coordinator/models.js` (`TIER_MODELS`). Le **tier 0** (codemod
  déterministe) n'a pas de modèle par conception ; les appelants doivent le traiter
  avant `recommendModel()` (repli explicite tier 2 quand le codemod est bypassé).
