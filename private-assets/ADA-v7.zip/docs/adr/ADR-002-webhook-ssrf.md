# ADR-002 — Sécurité des webhooks sortants : SSRF guard

**Date** : 2026-05-23
**Statut** : Accepté
**Décideur** : Équipe ADA

## Contexte

ADA supporte des webhooks sortants configurés dans `~/.ada.json` sous la clé `webhook.url`. Ces URLs sont définies par l'utilisateur final et envoyées via `dispatchWebhook()` lors des événements `run.complete`, `run.fail` et `session.end`.

Sans validation, un utilisateur (ou un script malveillant modifiant `~/.ada.json`) pourrait configurer une URL pointant vers :

- Des services locaux (`http://localhost:11434` — Ollama, `http://127.0.0.1:5432` — PostgreSQL)
- Des services LAN internes (`http://192.168.1.1` — routeur, `http://10.0.0.X` — AWS metadata)
- Des adresses encodées non canoniques (`http://2130706433/` = `127.0.0.1` en décimal, `http://[::1]/`)

Cette classe d'attaque est un SSRF (Server-Side Request Forgery) : ADA devient un proxy vers des ressources réseau internes.

## Décision

Implémenter un **SSRF guard** dans `coordinator/webhook.js` via la fonction `isWebhookUrlSafe()`, appelée avant chaque dispatch.

### Règles de blocage

La regex `BLOCKED_HOSTS` couvre :

```
/^(localhost|127\.|0\.0\.0\.0|::1$|::ffff:|fd[0-9a-f]{2}:|
   10\.|172\.(1[6-9]|2\d|3[01])\.|192\.168\.|169\.254\.|0177\.)/i
```

Plages bloquées :
- `localhost` (toute casse)
- `127.0.0.0/8` — loopback IPv4
- `0.0.0.0` — wildcard
- `::1` — loopback IPv6
- `::ffff:*` — IPv4-mapped IPv6
- `fd*` — Unique Local Address IPv6 (RFC 4193)
- `10.0.0.0/8`, `172.16.0.0/12`, `192.168.0.0/16` — RFC 1918
- `169.254.0.0/16` — link-local (AWS/GCP instance metadata)
- `0177.*` — loopback en notation octale

### Normalisation IPv6

`URL.hostname` retourne `[::1]` pour les adresses IPv6 littérales. Les brackets sont supprimés avant le test regex :

```javascript
const host = u.hostname.replace(/^\[|\]$/g, '')
if (BLOCKED_HOSTS.test(host)) return false
```

### Blocage des IP décimales

Les hostnames purement numériques (ex : `2130706433` = `127.0.0.1`) sont bloqués :

```javascript
if (/^\d+$/.test(host)) return false
```

### Autres contraintes

- Seuls `http:` et `https:` sont acceptés comme protocoles
- Pas de suivi de redirects (le handler utilise `http.request` avec `maxRedirects: 0` implicite)
- Timeout 5 secondes, fire-and-forget (échec silencieux pour ne pas bloquer le run)

## Alternatives considérées

| Alternative | Avantage | Inconvénient |
|-------------|----------|--------------|
| Allowlist de domaines | Surface d'attaque minimale | Trop restrictif pour un outil généraliste ; toute URL légitime nécessite une mise à jour du code |
| Validation DNS (résolution avant envoi) | Détecte les CNAMEs vers des IP privées | Vulnérable au DNS rebinding ; ajoute une dépendance réseau synchrone ; complexité accrue |
| Désactivation des webhooks HTTP | Élimine le risque complètement | Supprime un cas d'usage légitime (webhooks locaux dans les tests) |

## Conséquences

**Positives :**
- Protection contre les SSRF sans configuration supplémentaire
- Couvre les encodages non canoniques courants (décimal, IPv6, octal)
- Le guard est testé unitairement dans `.claude/tests/`
- Fire-and-forget : une URL bloquée ne fait pas échouer le run

**Négatives / Compromis :**
- Des cas limites existent (DNS rebinding après validation, CNAMEs vers RFC-1918) — non couverts par ce guard
- La validation est effectuée sur le nom d'hôte textuel, pas sur l'IP résolue : un CNAME `my-internal.example.com → 192.168.1.1` passerait le guard
- Le blocage est silencieux : un utilisateur ne voit pas d'erreur explicite si son webhook est bloqué (comportement volontaire — fire-and-forget)

## Statut de mise en œuvre

- Guard SSRF : `.claude/coordinator/webhook.js` — fonction `isWebhookUrlSafe()`
- Dispatch : `.claude/coordinator/webhook.js` — fonction `dispatchWebhook()`
- Appelé depuis : `.claude/coordinator/run.js`, `.claude/hooks/session-end.js`
