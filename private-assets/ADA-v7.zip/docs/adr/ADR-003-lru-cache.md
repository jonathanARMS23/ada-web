# ADR-003 — Mémoire hiérarchique : LRU cache avec TTL

**Date** : 2026-05-23
**Statut** : Accepté
**Décideur** : Équipe ADA

## Contexte

Plusieurs composants d'ADA lisent fréquemment les mêmes fichiers :

- Les routes API de statistiques (`/api/stats/*`) lisent `runs/`, `agents.json` et `router-state.json` à chaque requête de l'UI
- `stats-cache.ts` agrège ces trois sources en un `StatsBundle` par profil
- Les workers `ultralearn` et `consolidate` accèdent à `context.md` pour chaque traitement

Sans cache, chaque requête HTTP génère entre 3 et N+3 opérations I/O filesystem (N = nombre de runs). Sur un profil avec 200 runs, cela représente 203 lectures de fichiers par appel à `/api/stats/overview`.

La fréquence d'actualisation des données de stats tolère un délai de quelques secondes (l'UI affiche un tableau de bord, pas un flux temps réel).

## Décision

Implémenter un **LRU Cache** avec TTL dans `lib/cache.js` (Node.js, 0 dépendance externe) et `ada-ui/lib/cache.ts` (TypeScript). Utiliser ce cache dans `ada-ui/lib/stats-cache.ts` pour le `StatsBundle`.

### Structure de données

Doubly-linked list + Map pour des opérations O(1) :

```
head ↔ [most-recent] ↔ … ↔ [least-recent] ↔ tail
Map: key → LRUNode
```

- `get(key)` : déplace le noeud en tête, O(1)
- `set(key, value)` : insère en tête, évince la queue si `size > maxSize`, O(1)
- `getOrSet(key, fn)` : get-or-compute synchrone, O(1)
- `invalidate(key)` : suppression ciblée, O(1)

Chaque noeud porte un `expiry` (timestamp absolu en ms). Un noeud expiré est traité comme un miss et supprimé à la première consultation.

### Configuration dans stats-cache.ts

```typescript
// max 50 profils, TTL 5 s par entrée
const _cache = new LRUCache<string, StatsBundle>(50, 5_000)
```

Un mécanisme d'inflight deduplication (`_inflight: Map<string, Promise<StatsBundle>>`) évite les lectures parallèles redondantes pour la même clé avant que la première promesse soit résolue.

### Politique de TTL par type de donnée

| Donnée | TTL | Justification |
|--------|-----|---------------|
| `StatsBundle` (runs, agents, router state) | 5 000 ms | Tolérance UI — affichage dashboard |
| Fichiers de mémoire (`context.md`, memory/) | Pas de cache | Doivent refléter l'état courant immédiatement |
| Données de configuration critique | Pas de cache | Cohérence requise à chaque accès |

### Stats internes

`LRUCache.stats` expose `{ hits, misses, evictions }` pour le monitoring.

## Alternatives considérées

| Alternative | Avantage | Inconvénient |
|-------------|----------|--------------|
| Redis | Partageable entre processus, persistant | Dépendance externe non justifiée pour un outil CLI local ; requiert un serveur Redis démarré |
| `Map` simple sans TTL | Trivial à implémenter | Memory leak progressif — les entrées obsolètes ne sont jamais évincées |
| `Map` avec TTL mais sans LRU | Pas de fuite mémoire avec TTL court | Pas d'éviction sous pression mémoire si le TTL est long ; taille non bornée |
| node-lru-cache (npm) | Bibliothèque éprouvée | Ajoute une dépendance externe ; le cas d'usage ne justifie pas l'overhead |

## Conséquences

**Positives :**
- Réduction des I/O filesystem : une seule lecture de `StatsBundle` par profil par fenêtre de 5 s, quel que soit le nombre de requêtes HTTP simultanées
- Zéro dépendance externe — fonctionne dans les deux environnements (Node.js CLI et Next.js server-side)
- La taille est bornée (`maxSize = 50`) — pas de fuite mémoire en cas de prolifération de profils
- L'inflight deduplication élimine les "thundering herds" au démarrage de l'UI

**Négatives / Compromis :**
- TTL de 5 s = données potentiellement décalées de 5 s dans l'UI (acceptable pour un dashboard)
- Le cache est in-process : redémarrer le serveur Next.js vide le cache (cold start)
- Les fichiers de mémoire ne sont pas cachés — compromis délibéré pour préserver la cohérence des données de contexte agent

## Statut de mise en œuvre

- Implémentation Node.js : `.claude/lib/cache.js` — classe `LRUCache`
- Implémentation TypeScript : `ada-ui/lib/cache.ts` — classe `LRUCache<K, V>`
- Usage stats : `ada-ui/lib/stats-cache.ts` — `getCachedStatsBundle()` avec inflight dedup
