# ADR-004 — Validation des entrées : Zod centralisé avec regex nommées

**Date** : 2026-05-23
**Statut** : Accepté
**Décideur** : Équipe ADA

## Contexte

Les routes API Next.js d'ADA UI acceptent des corps JSON arbitraires. Ces données sont ensuite utilisées pour :

- Modifier des fichiers de configuration (`~/.claude[-<profil>]/agents.json`, `~/.ada.json`)
- Exécuter des commandes MCP (`uvx`, `npx`, `node`, etc.)
- Filtrer des données en base ou dans le filesystem

Sans validation centralisée, plusieurs problèmes émergent :

1. **Divergence silencieuse** : chaque route implémente ses propres contrôles partiels, avec des règles inconsistantes (ex : longueur max de `name` définie différemment selon la route)
2. **Path traversal** : un champ `name` contenant `../` pourrait permettre d'écrire hors du répertoire cible
3. **Injection de commandes** : des arguments MCP non filtrés pourraient inclure `--require`, `--eval`, `--inspect` ou d'autres flags dangereux de Node.js
4. **Champs inconnus** : des corps JSON avec des clés supplémentaires pourraient polluer les fichiers de config si l'objet est sérialisé tel quel

## Décision

Centraliser tous les schemas de validation dans `ada-ui/lib/schemas.ts` en utilisant **Zod 4.x**.

### Schemas définis

| Export | Protège | Contrainte principale |
|--------|---------|-----------------------|
| `AgentPatchSchema` | `PATCH /api/agents/[slug]` | `name` : `SAFE_NAME_RE`, `.strict()` |
| `TeamCreateSchema` | `POST /api/teams` | `agents` : max 20, `SAFE_AGENT_RE` |
| `TeamPatchSchema` | `PATCH /api/teams` | `pipeline` : `SAFE_PIPELINE_RE` |
| `ProfileTypeCreateSchema` | `POST /api/profile-types` | `keywords` : max 50, `teamId` : UUID |
| `ProfileTypePatchSchema` | `PATCH /api/profile-types` | Tous les champs optionnels, `.strict()` |
| `ProfileQuerySchema` | Query params `?profile=` | `SAFE_PROFILE_RE` |

### Regex de sécurité nommées

Définies une seule fois, réutilisées dans plusieurs schemas :

```typescript
const SAFE_NAME_RE    = /^[a-zA-Z0-9][a-zA-Z0-9 _-]{0,63}$/
const SAFE_PIPELINE_RE = /^[a-z0-9][a-z0-9-]{0,63}$/
const SAFE_AGENT_RE   = /^[a-z0-9-]{1,32}$/
const SAFE_PROFILE_RE = /^[a-z0-9][a-z0-9-]{0,30}$/
const SAFE_KEYWORD_RE = /^[a-zA-Z0-9][a-zA-Z0-9 _/-]{0,63}$/
```

Ces regex excluent les caractères de path traversal (`..`, `/` dans les noms) et les caractères de contrôle.

### Validation MCP

`validateMcpCommand()` est un helper exporté dédié aux routes MCP (`/api/mcp/connectors`, `/api/mcp/registry`). Il vérifie :

1. `command` est dans l'allowlist `MCP_ALLOWED_COMMANDS` : `uvx`, `npx`, `node`, `python`, `python3`, `deno`, `bun`
2. Chaque argument correspond à `MCP_SAFE_ARG_RE` : `^[a-zA-Z0-9_\-./: @=]+$`
3. Les flags Node.js dangereux sont bloqués par `MCP_BLOCKED_NODE_FLAGS` :
   ```typescript
   /^--(require|inspect|eval|exec|loader|experimental|import|env-file)/i
   ```
4. Les clés d'env suivent `MCP_SAFE_ENV_KEY_RE` : `^[A-Z_][A-Z0-9_]{0,63}$`

### Politique `.strict()`

Tous les schemas utilisent `.strict()` : tout champ inconnu dans le corps JSON provoque une erreur de validation immédiate (HTTP 400), empêchant la propagation de données non définies vers les fichiers de configuration.

### Usage dans les routes

```typescript
// Pattern standard dans chaque route
const body = await request.json()
const parsed = SomeSchema.safeParse(body)
if (!parsed.success) {
  return NextResponse.json({ error: parsed.error.format() }, { status: 400 })
}
// parsed.data est typé et validé
```

## Alternatives considérées

| Alternative | Avantage | Inconvénient |
|-------------|----------|--------------|
| Validation manuelle champ par champ | Pas de dépendance | Divergence entre routes garantie ; pas d'inférence TypeScript ; surface d'erreur élevée |
| JSON Schema + ajv | Standard, large écosystème | Pas d'inférence TypeScript native ; verbeux pour les unions et optionnels |
| class-validator + class-transformer | Intégration NestJS native | Non adapté au runtime Next.js Edge/Node ; decorators expérimentaux en TypeScript |
| io-ts | Typage fort, composable | API moins intuitive que Zod ; courbe d'apprentissage plus raide |

## Conséquences

**Positives :**
- Un seul fichier à auditer pour toutes les règles de validation d'entrée
- Les types TypeScript des corps validés sont inférés automatiquement (`z.infer<typeof Schema>`)
- `.strict()` garantit qu'aucun champ non déclaré n'atteint les couches de persistance
- `validateMcpCommand()` partage la même logique dans toutes les routes MCP
- Les regex nommées documentent leur intention (sécurité, pas seulement format)

**Négatives / Compromis :**
- Zod est une dépendance de production (environ 30 Ko minifié + gzippé)
- Les erreurs Zod 4.x (`parsed.error.format()`) ont une structure imbriquée qui peut être verbeuse en réponse HTTP
- `.strict()` peut causer des erreurs inattendues si un client légitime envoie des champs nouveaux lors d'une évolution d'API — nécessite une coordination entre front et back

## Statut de mise en œuvre

- Schemas centralisés : `ada-ui/lib/schemas.ts`
- Consommateurs : `ada-ui/app/api/agents/[slug]/route.ts`, `ada-ui/app/api/agents/route.ts`, `ada-ui/app/api/teams/route.ts`, `ada-ui/app/api/mcp/connectors/route.ts`, `ada-ui/app/api/mcp/registry/route.ts`, `ada-ui/app/api/profile-types/test/route.ts`
