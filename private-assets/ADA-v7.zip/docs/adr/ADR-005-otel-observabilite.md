# ADR-005 — Observabilité : OpenTelemetry natif et logs structurés corrélés

**Date** : 2026-05-23
**Statut** : Accepté
**Décideur** : Équipe ADA

## Contexte

ADA orchestre des runs multi-agents dont chaque phase est exécutée par un agent différent, potentiellement avec un modèle LLM différent. Un incident dans une phase `review` peut avoir pour cause une donnée corrompue produite en phase `schema` plusieurs minutes auparavant.

Les logs non structurés (chaînes de caractères en clair) ne permettent pas de :

- Relier une ligne de log à la requête HTTP qui l'a déclenchée
- Reconstruire la séquence causale d'un incident multi-phases
- Mesurer la latence par opération dans les route handlers
- Corréler les logs applicatifs avec les traces distribuées dans un outil de monitoring

`console.log()` en production produit des sorties qui mélangent les contextes de requêtes concurrentes dans les workers Next.js.

## Décision

Adopter **OpenTelemetry** comme standard d'observabilité, avec :

1. `instrumentation.ts` pour l'initialisation OTel au démarrage du serveur Next.js
2. `lib/telemetry.ts` pour les spans manuels dans les route handlers
3. `lib/logger.ts` pour les logs structurés JSON corrélés aux traces actives

### Initialisation OTel

`ada-ui/instrumentation.ts` utilise le hook `register()` de Next.js (exécuté une seule fois au démarrage du processus Node.js) :

```typescript
export async function register() {
  if (process.env.NEXT_RUNTIME === 'nodejs') {
    const { registerOTel } = await import('@vercel/otel')
    registerOTel({
      serviceName: process.env.OTEL_SERVICE_NAME ?? 'ada-ui',
    })
  }
}
```

La garde `NEXT_RUNTIME === 'nodejs'` empêche l'initialisation dans le runtime Edge (qui ne supporte pas les SDK OTel complets).

### Spans manuels

`lib/telemetry.ts` expose `withSpan()` pour instrumenter les opérations critiques :

```typescript
export function withSpan<T>(
  name: string,
  attributes: Record<string, string | number | boolean>,
  fn: () => Promise<T>
): Promise<T>
```

Le span est automatiquement marqué `OK` ou `ERROR` avec l'exception enregistrée (`span.recordException()`). Le span est terminé dans un `finally` pour garantir la fermeture même en cas d'erreur.

### Corrélation log ↔ trace

`lib/logger.ts` injecte `traceId` et `spanId` dans chaque entrée de log quand un span actif existe :

```typescript
const span = getActiveSpan()
if (span?.isRecording()) {
  const ctx = span.spanContext()
  entry.traceId = ctx.traceId
  entry.spanId  = ctx.spanId
}
```

Format de sortie : JSON sur `stderr`, une ligne par entrée. Champs fixes : `level`, `msg`, `ts`, `traceId?`, `spanId?`, plus les champs `meta` passés par l'appelant.

### Logger contextuel

`createLogger(context)` retourne un logger qui merge un contexte fixe (`requestId`, `profile`, `runId`) dans chaque entrée :

```typescript
const log = createLogger({ requestId: req.headers.get('x-request-id'), profile })
log.info('processing run', { runId })
// → { level: "info", msg: "processing run", ts: "...", requestId: "...", profile: "...", runId: "..." }
```

### Déploiement local

Un `otel-collector.yaml` de référence est prévu pour le routing des traces vers Jaeger (développement) ou Grafana Tempo (production). L'exporteur est configuré via les variables d'environnement standard OTel (`OTEL_EXPORTER_OTLP_ENDPOINT`).

## Alternatives considérées

| Alternative | Avantage | Inconvénient |
|-------------|----------|--------------|
| Logs structurés seuls (sans traces) | Suffisant pour les cas simples | Impossible de reconstruire la causalité entre phases dans un incident multi-agents |
| Datadog APM | Intégration Next.js mature, dashboards prêts | Payant ; dépendance externe incompatible avec le modèle d'outil local ; lock-in vendor |
| Sentry | Gestion des erreurs avec contexte | Centré sur les erreurs, pas sur la latence et la causalité ; données envoyées vers des serveurs tiers |
| `console.log` + grep | Zéro configuration | Non structuré ; pas de corrélation ; impossible à filtrer programmatiquement |
| Pino + pino-http | Logs structurés très performants | Logs seuls, pas de traces distribuées ; corrélation manuelle via `req.id` uniquement |

## Conséquences

**Positives :**
- `traceId` dans chaque log permet de retrouver tous les logs d'une requête en une query
- `withSpan()` mesure la latence réelle de chaque opération instrumentée
- Compatible avec Vercel (via `@vercel/otel`), Jaeger, Grafana Tempo et tout backend OTLP
- `createLogger()` évite la répétition du contexte de requête dans chaque appel `log.*`
- La sortie sur `stderr` est une convention Unix : facilement redirigeable sans interférer avec la réponse HTTP

**Négatives / Compromis :**
- `@vercel/otel` ajoute une dépendance de production ; un bootstrap OTel sans cette bibliothèque serait plus verbeux mais sans dépendance
- Sans backend OTel configuré (`OTEL_EXPORTER_OTLP_ENDPOINT`), les spans sont créés mais non exportés — la corrélation dans les logs reste fonctionnelle, les traces sont perdues
- `withSpan()` ne couvre pas les spans automatiques Next.js (routing, rendering) — ces derniers sont gérés par `@vercel/otel` automatiquement

## Statut de mise en œuvre

- Initialisation OTel : `ada-ui/instrumentation.ts`
- Spans manuels : `ada-ui/lib/telemetry.ts` — `withSpan()`, `getActiveSpan()`
- Logs structurés : `ada-ui/lib/logger.ts` — `logger`, `createLogger()`
- Configuration collector : `ada-ui/otel-collector.yaml` (référence locale Jaeger/Tempo)
