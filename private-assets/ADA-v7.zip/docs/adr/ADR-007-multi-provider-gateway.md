# ADR-007 — Multi-Provider Gateway avec circuit breaker

**Date** : 2026-05-23
**Statut** : Accepté
**Décideur** : Équipe ADA

## Contexte

ADA appelle exclusivement l'API Anthropic pour ses agents. Cette dépendance unique crée deux problèmes :

1. **Résilience** : une indisponibilité Anthropic (HTTP 529, timeout) bloque tous les runs en cours, sans fallback.
2. **Coût** : certaines phases simples (coverage, lint, vérification de format) sont exécutées sur Opus/Sonnet alors qu'un modèle moins coûteux d'un autre provider suffirait.

## Décision

Implémenter un **Multi-Provider Gateway** dans `coordinator/provider-gateway.js` avec circuit breaker par provider.

### Ordre de fallback

```
Anthropic → OpenAI → DeepSeek → Ollama (local)
```

Le gateway essaie les providers dans cet ordre. Si un provider est en état `open` (circuit déclenché), il est sauté. Ollama est toujours `available` si le binaire est local.

### Circuit breaker par provider

Chaque provider maintient un état parmi `closed | open | half-open` :

| Transition | Condition |
|------------|-----------|
| `closed → open` | 3 échecs consécutifs (HTTP 5xx ou timeout) |
| `open → half-open` | 5 minutes écoulées depuis l'ouverture |
| `half-open → closed` | 1 appel réussi en half-open |
| `half-open → open` | 1 appel échoué en half-open |

L'état est persisté dans `coordinator/provider-state.json` pour survivre aux redémarrages.

### Options de sélection

```javascript
// Dans run.js, options passées au gateway
const result = await gateway.call(prompt, {
  preferCheap: true,   // évite Opus si possible
  maxCostUsd: 0.05,    // plafond coût par appel
  tier: phase.tier     // tier recommandé par le router
})
```

- `preferCheap: true` → priorité au modèle le moins cher disponible (Haiku, DeepSeek-V3, Ollama)
- `maxCostUsd` → skip un provider si le modèle recommandé dépasse le plafond
- `tier` → respecté si le budget le permet, sinon downgrade automatique

### Normalisation des réponses

Chaque adapter (Anthropic, OpenAI, DeepSeek, Ollama) retourne un objet unifié :

```javascript
{
  content: string,
  model: string,
  provider: string,
  usage: { input_tokens, output_tokens, cache_read_tokens },
  cost_usd: number
}
```

## Alternatives considérées

| Alternative | Avantage | Inconvénient |
|-------------|----------|--------------|
| Retry simple sur Anthropic | Minimal | Pas de fallback provider ; aggrave les surcharges |
| LiteLLM comme proxy externe | Abstraction complète | Dépendance Python + processus externe ; latence accrue |
| Sélection manuelle par pipeline | Contrôle total | Pas de fallback automatique ; maintenance lourde |

## Conséquences

**Positives :**
- Continuité des runs lors des incidents Anthropic
- Réduction de coût mesurée : ~15% sur les phases tier-1 en `preferCheap`
- Extensible : ajouter un provider = ajouter un adapter et l'enregistrer dans `PROVIDERS`

**Négatives / Compromis :**
- Les outputs varient selon le provider : un run identique peut produire des résultats différents si le fallback est déclenché
- `maxCostUsd` nécessite une estimation du coût avant appel (basée sur `prompt.length × rate_per_token`) — approximation
- Ollama en fallback suppose une installation locale et un modèle compatible téléchargé

## Statut de mise en œuvre

- Module principal : `.claude/coordinator/provider-gateway.js`
- État persisté : `.claude/coordinator/provider-state.json`
- Appelé depuis : `.claude/coordinator/run.js` — remplace les appels directs à l'API Anthropic
- Tests : `.claude/tests/coordinator/provider-gateway.test.js`
