# ADR-008 — Budget Guard : circuit-breaker budgétaire

**Date** : 2026-05-23
**Statut** : Accepté
**Décideur** : Équipe ADA

## Contexte

ADA exécute des pipelines multi-phases dont le coût agrégé en tokens LLM peut déraper sur un incident (boucle de retry, pipeline mal configuré, provider en fallback vers un modèle cher). Sans limite budgétaire enforced dans le code, un utilisateur peut accumuler des centaines de dollars de coût avant de s'en apercevoir.

Par ailleurs, les environnements CI/CD et les usages SaaS multi-tenant nécessitent des seuils distincts par granularité : par run individuel, par session utilisateur, par jour calendaire.

## Décision

Implémenter un **Budget Guard** dans `coordinator/budget-guard.js` qui agit comme circuit-breaker en trois niveaux.

### Configuration

Dans `~/.ada.json` (ou `ada-ui → Settings`) :

```json
{
  "budget": {
    "run":     { "warnUsd": 0.50, "stopUsd": 2.00 },
    "session": { "warnUsd": 5.00, "stopUsd": 20.00 },
    "day":     { "warnUsd": 10.00, "stopUsd": 50.00 }
  }
}
```

### Niveaux d'action

| Niveau | Action |
|--------|--------|
| `warn` | Log warning dans l'audit + notification webhook `budget.warn` |
| `stop` | Phase courante terminée, run marqué `cancelled`, événement `budget.stop` |
| `downgrade_tier` | Si le prochain spawn dépasserait `stopUsd`, downgrade du tier (Opus→Sonnet, Sonnet→Haiku) avant spawn |

`downgrade_tier` est tenté avant `stop` : si même Haiku dépasse le seuil, le run est stoppé.

### Comptabilisation

`recordCost(runId, phaseId, costUsd)` est appelé par `run.js` après chaque phase :

- Rejette `Infinity`, `NaN`, et les valeurs négatives (prévention DoS permanent)
- Cumule dans `budget-state.json` : `runs[runId].total`, `sessions[sessionId].total`, `days[YYYY-MM-DD].total`
- Log trim automatique : les entrées `days` plus vieilles que 90 jours sont supprimées

### Vérification pré-spawn

Avant chaque appel `spawnAgent()`, `checkBudget(runId, estimatedCostUsd)` :

1. Calcule les totaux courants (run + session + day)
2. Compare aux seuils `warn` et `stop`
3. Retourne `{ action: 'ok' | 'warn' | 'stop' | 'downgrade_tier', newTier? }`

## Alternatives considérées

| Alternative | Avantage | Inconvénient |
|-------------|----------|--------------|
| Alerte uniquement (pas de stop) | Non bloquant | Ne protège pas contre le dérapage |
| Seuil unique global | Simple | Pas adapté aux usages multi-tenant ou CI |
| Quota API côté Anthropic Console | Protection externe | Latence de notification, pas de downgrade automatique |

## Conséquences

**Positives :**
- Protection contre les runs runaway sans configuration côté provider
- `downgrade_tier` préserve la complétion du run à moindre coût avant d'arrêter
- Audit trail complet dans `budget-state.json` + audit log NDJSON

**Négatives / Compromis :**
- `estimatedCostUsd` est une estimation basée sur `prompt.length × rate` — la dépense réelle peut légèrement dépasser le seuil `stop` si la phase est déjà en cours
- Le deep-clone du pipeline avant `downgrade_tier` ajoute ~1 ms de latence sur les pipelines de plus de 20 phases
- Les seuils par défaut sont conservateurs — un utilisateur power doit les ajuster

## Statut de mise en œuvre

- Module principal : `.claude/coordinator/budget-guard.js`
- État persisté : `.claude/coordinator/budget-state.json`
- Appelé depuis : `.claude/coordinator/run.js` — `recordCost()` post-phase, `checkBudget()` pré-spawn
- API UI : `GET /api/stats/budget`, `PATCH /api/stats/budget`
- Tests : `.claude/tests/coordinator/budget-guard.test.js`
