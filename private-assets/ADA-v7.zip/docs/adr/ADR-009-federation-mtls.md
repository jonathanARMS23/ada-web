# ADR-009 — Federation mTLS : échange P2P de trajectoires

**Date** : 2026-05-23
**Statut** : Accepté
**Décideur** : Équipe ADA

## Contexte

Le Thompson Sampling d'ADA (ADR-001) converge sur les données locales d'une machine. Dans un contexte d'équipe distribuée, chaque développeur accumule ses propres priors indépendamment. La fonctionnalité Team Sync (F6) permet la synchronisation via git, mais cette approche est asynchrone (push/pull manuel) et ne couvre pas les trajectoires du `ReasoningBank` — seulement les priors Thompson.

Pour des équipes travaillant en temps réel sur le même domaine métier, un mécanisme d'échange direct de trajectoires entre instances ADA accélère la convergence de l'apprentissage collectif.

## Décision

Implémenter un **serveur de fédération mTLS** dans `coordinator/federation.js` permettant l'échange P2P de trajectoires entre instances ADA autorisées.

### Architecture

Chaque instance ADA peut démarrer un serveur de fédération (désactivé par défaut) :

```bash
ada federation start --port 7822
ada federation peer add <ip>:<port> --cert ./peer.crt
ada federation sync
```

Le serveur écoute sur `127.0.0.1` par défaut (pas d'exposition réseau sans configuration explicite). Pour une utilisation LAN/VPN, l'opérateur doit spécifier `--bind 0.0.0.0` explicitement.

### TLS mutuel

- `requestCert: true` côté serveur — toute connexion sans certificat client valide est rejetée
- Les certificats sont générés via `generateCerts()` qui appelle `openssl req` en subprocess
- Le CA est local à l'installation (`~/.ada.json → federation.caPath`)
- Durée de vie des certificats : 365 jours par défaut, renouvelables via `ada federation renew-cert`

### Protocole d'échange

Chaque requête de synchronisation est une requête HTTPS `POST /federation/sync` avec un body JSON :

```json
{
  "phaseType": "backend",
  "since": "2026-05-01T00:00:00Z",
  "limit": 50
}
```

Contraintes appliquées côté serveur :
- Body limité à **1 KB** avant traitement (prévention DoS)
- `limit` plafonné à 100 trajectoires par appel
- Seuls les champs `issue`, `resolution`, `outcome`, `phaseType`, `ts` sont retournés — le `prompt` brut n'est jamais partagé

### Merge côté receveur

Après réception, les trajectoires distantes sont insérées dans `bank.json` local via `bank.importRemote()` :
- Déduplication par hash `sha256(phaseType + issue + resolution)`
- Les trajectoires importées sont marquées `source: "federation"` pour audit

## Alternatives considérées

| Alternative | Avantage | Inconvénient |
|-------------|----------|--------------|
| Sync via git (F6 seulement) | Aucune infra supplémentaire | Asynchrone, manuel, ne couvre pas le ReasoningBank |
| Service centralisé (API SaaS) | Simple côté client | Single point of failure ; confidentialité des trajectoires |
| Sync via fichier partagé (NFS/S3) | Simple | Pas de contrôle d'accès granulaire ; pas de chiffrement transit |

## Conséquences

**Positives :**
- Convergence du Thompson Sampling ~3× plus rapide dans les équipes de 3+ développeurs (estimation interne)
- mTLS garantit que seules les instances avec certificat signé par le CA partagé peuvent échanger
- Bind `127.0.0.1` par défaut = zéro exposition réseau sans action explicite

**Négatives / Compromis :**
- Requiert une PKI légère (CA local) — génération et distribution des certificats sont à la charge de l'équipe
- La limite 1 KB sur le body entrant est stricte : une requête avec beaucoup de métadonnées peut être rejetée légitimement
- Pas de chiffrement au repos des trajectoires fédérées dans `bank.json` — même niveau que les trajectoires locales

## Statut de mise en œuvre

- Module principal : `.claude/coordinator/federation.js`
- Génération des certificats : `generateCerts()` dans `federation.js` via `child_process.execSync`
- Appelé depuis : `ada federation start` (CLI), `ada federation sync`
- Tests : `.claude/tests/coordinator/federation.test.js`
