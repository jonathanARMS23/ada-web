# ADR-010 — Skill Marketplace : installation SHA256-verified

**Date** : 2026-05-23
**Statut** : Accepté
**Décideur** : Équipe ADA

## Contexte

ADA supporte les plugins locaux (`~/.claude/plugins/`) depuis v1.0. Cependant, la distribution de plugins entre utilisateurs est manuelle (copie de fichiers, git clone). L'absence de vérification d'intégrité crée un vecteur d'attaque : un plugin modifié en transit ou corrompu peut exécuter du code arbitraire dans le contexte des hooks ADA.

Deux risques spécifiques ont été identifiés lors de l'audit S14 :
1. **Path traversal** : un nom de fichier contenant `../` dans le manifest permet d'écrire hors du répertoire plugin
2. **Symlink jail** : sans vérification `realpathSync`, un plugin peut créer un symlink pointant vers `/etc/passwd` et le lire via les hooks

## Décision

Implémenter un **Skill Marketplace** dans `coordinator/skill-registry.js` avec vérification SHA256 systématique et jail de fichiers.

### Flux d'installation

```bash
ada skill install <slug>          # depuis le registre public
ada skill install --url <url>     # depuis une URL custom
ada skill verify <slug>           # vérifier l'intégrité sans installer
ada skill list                    # skills installés
ada skill remove <slug>
```

1. Téléchargement de `manifest.json` depuis le registre
2. Téléchargement de l'archive `.tar.gz`
3. **Vérification SHA256** : `sha256(archive) === manifest.sha256` — échec = installation annulée
4. Extraction dans `~/.claude/plugins/<slug>/`
5. Vérification `isSafeFilename()` sur chaque fichier extrait
6. `realpathSync` sur chaque chemin extrait — rejet si hors du répertoire plugin (symlink jail)

### `isSafeFilename(name)`

```javascript
function isSafeFilename(name) {
  return /^[a-zA-Z0-9_\-\.]+$/.test(name)
    && !name.includes('..')
    && !name.startsWith('.')
    && name.length <= 64
}
```

### Cache TTL

Le manifest et le SHA256 d'un skill sont mis en cache 1 heure dans `skill-cache.json`. Au-delà du TTL, une vérification d'intégrité est refaite avant utilisation.

### Registre public

Le registre public (`https://registry.ada.sh/v1/skills`) expose :
- `GET /skills` — liste paginée avec `name`, `slug`, `version`, `sha256`, `description`
- `GET /skills/:slug` — manifest complet + changelog
- `GET /skills/:slug/download` — archive `.tar.gz`

L'hébergement du registre est hors scope de ce document. Pour un usage privé, `ada skill install --url` accepte n'importe quelle URL HTTPS avec un manifest local (`--sha256 <hash>`).

## Alternatives considérées

| Alternative | Avantage | Inconvénient |
|-------------|----------|--------------|
| Signature GPG des archives | Standard de sécurité éprouvé | Requiert une gestion de keyring ; complexité pour l'utilisateur |
| Sandbox V8 Isolate | Isolation d'exécution complète | Incompatible avec les modules `node:*` natifs utilisés dans les plugins |
| Whitelist de registres autorisés | Surface d'attaque minimale | Frein à l'adoption communautaire |

## Conséquences

**Positives :**
- SHA256 élimine les attaques man-in-the-middle et les corruptions accidentelles
- La jail `realpathSync` bloque les path traversal, y compris via les symlinks
- Le cache TTL 1 h évite de re-vérifier à chaque hook invocation sans fenêtre d'exposition longue

**Négatives / Compromis :**
- SHA256 sans signature asymétrique ne protège pas si le registre lui-même est compromis (le hash peut être mis à jour avec le binaire malveillant)
- `isSafeFilename` rejette les plugins avec des noms de fichiers contenant des caractères Unicode valides — limitation acceptée pour la v6
- Le cache TTL 1 h signifie qu'un plugin retiré du registre reste utilisable pendant 1 h sur les machines qui l'ont mis en cache

## Statut de mise en œuvre

- Module principal : `.claude/coordinator/skill-registry.js`
- Cache : `.claude/coordinator/skill-cache.json`
- CLI : `.claude/bin/ada.js` — sous-commandes `skill install|verify|list|remove`
- Tests : `.claude/tests/coordinator/skill-registry.test.js`
