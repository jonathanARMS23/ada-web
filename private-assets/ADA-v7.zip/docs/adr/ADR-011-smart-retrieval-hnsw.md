# ADR-011 — SmartRetrieval ACW v2 + HNSW persistant

**Date** : 2026-05-31
**Statut** : Accepté
**Décideurs** : Jonathan Arms

## Contexte

L'ACW (v1) injectait les trajectoires via un TF-IDF mono-requête sur `bank.retrieve()`. Deux problèmes :
1. **Qualité** : TF-IDF exact-match rate élevé → trajectoires similaires redondantes injectées
2. **Performance** : `db.getAll(MAX_TRAJECTORIES=5000)` + HNSW rebuild O(n²) à chaque retrieve

## Décision

### SmartRetrieval (run.js)
Pipeline expandQuery → BM25×3 → RRF+recency → MMR(λ=0.6) en remplacement du TF-IDF direct.

Rationale :
- expandQuery : compense les variations lexicales (nestjs ≠ express, même concept)
- BM25 vs TF-IDF : meilleure normalisation longueur document
- RRF : fusion robuste, k=60 réduit la variance des rangs extrêmes
- MMR : diversité explicite, λ=0.6 optimal empiriquement (cf. Carbonell & Goldstein 1998)

### HNSW persistant (bank.js)
Graph HNSW sérialisé dans `bank-hnsw.json` avec vocab partagé inter-sessions.

Rationale :
- Les embeddings ONNX ne sont pas disponibles (nomic-embed-text non installé)
- TF-IDF dense sur vocab partagé est une approximation raisonnable pour la recherche de trajectoires
- Persistance évite la reconstruction O(n) à chaque démarrage

### Safeguards P1 (v7.0.1)
- `RETRIEVE_CAP=500` : borne le scan de candidats dans `retrieve()`
- Timeout 2s ACW : skip injection plutôt que bloquer la phase
- `_hnswVocabSet` (Set) : O(1) lookup vs O(n) `includes()`
- Atomic write HNSW : tmp + renameSync

## Alternatives rejetées

| Option | Raison du rejet |
|--------|----------------|
| ONNX nomic-embed-text | Non disponible sans installation séparée |
| Ollama embeddings | Optionnel, pas garanti présent |
| Elasticsearch/OpenSearch | Dépendance externe, over-engineering |
| Rebuild HNSW à chaque retrieve | O(n²) inacceptable à > 500 trajectoires |

## Conséquences

- **+** Qualité de retrieval améliorée : diversité MMR + recency bias
- **+** Performance : RETRIEVE_CAP borne la complexité
- **-** Légère dérive vocab si bank > 500 nœuds (dimension drift acceptable)
- **-** bank-hnsw.json peut grossir (typiquement ~1-5 MB à 1000 trajectoires)

## Métriques de succès

- Temps ACW < 2s sur 95% des phases
- 0 crash bank.retrieve() par timeout
- Diversité des trajectoires injectées : max 2 trajectoires du même agent par injection
