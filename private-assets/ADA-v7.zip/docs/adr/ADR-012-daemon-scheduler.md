# ADR-012 — Daemon Worker Scheduler

**Date** : 2026-05-31
**Statut** : Accepté
**Décideurs** : Jonathan Arms

## Contexte

Les 12 workers de maintenance (ultralearn, consolidate, audit, cve-scan, etc.) étaient déclenchés manuellement ou via des hooks Claude Code avec des fréquences codées en dur. Aucun mécanisme de scheduling automatique, aucune reprise après redémarrage.

## Décision

Process Node.js léger en arrière-plan (PID file) avec `setTimeout` + `setInterval` par worker.

Rationale :
- Node.js natif : zéro dépendance (pas cron, pas systemd, pas pm2)
- PID file : protection double-start, arrêt propre via SIGTERM
- `delayUntilNext()` : reprise correcte après redémarrage en lisant `daemon-state.json`
- Détachement complet : `spawn(detached: true)` + `child.unref()` → daemon survit à la fermeture du terminal

## Alternatives rejetées

| Option | Raison du rejet |
|--------|----------------|
| crontab système | Dépend de l'environnement user, difficile à configurer programmatiquement |
| pm2 / forever | Dépendance npm externe, over-engineering pour 4 workers |
| systemd service | Unix-only, nécessite droits admin |
| setInterval seul (sans PID) | Pas de protection double-start, pas de log rotation |

## Sécurité (validation loadSchedule)

Un `~/.ada.json` malveillant pourrait injecter un worker arbitraire avec un intervalle de 1ms. Mitigation :
- Whitelist : worker doit exister dans `workers/` ou `DEFAULT_SCHEDULE`
- Plage : [1min, 7j] — rejette les intervalles extrêmes
- Intervalle malformé : ignoré avec warning log

## Graceful Shutdown (P1)

SIGTERM appelait `process.exit(0)` immédiatement → possible corruption des logs en cours d'écriture.
Fix : `_gracefulShutdown()` = clear timers + unlink PID + `setTimeout(exit, 2000).unref()`.

## Conséquences

- **+** Workers tournent automatiquement sans intervention manuelle
- **+** Reprise propre après redémarrage (délais respectés)
- **+** Config user dans `~/.ada.json` sans modifier le code
- **-** Dépend du process utilisateur (s'arrête si la machine s'éteint)
- **-** Pas de retry si un worker crash (fire-and-forget)
