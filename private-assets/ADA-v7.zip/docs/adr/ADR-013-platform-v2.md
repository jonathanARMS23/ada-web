# ADR-013 — ADA Platform v2 : Architecture 3 services

| Champ | Valeur |
|-------|--------|
| Date | 2026-05-31 |
| Statut | Accepté |
| Décideurs | Jonathan Arms |
| Catégorie | Architecture système |
| Remplace | — |

---

## Contexte

ADA v1 est un outil CLI (ada-core) qui orchestre des runs multi-agents via
Claude. L'interface ada-ui (Next.js 15) a été ajoutée mais reste en **lecture
seule** : elle affiche l'état en lisant directement les fichiers JSON de
ada-core via des API routes Next.js.

Cette architecture présente 4 problèmes bloquants pour la suite :

**1. Mutations CLI uniquement**
Lancer un run, annuler une phase, relancer depuis un point de reprise — tout
passe par le terminal. L'interface ne peut pas déclencher d'actions. Les
utilisateurs doivent jongler entre le terminal et l'UI.

**2. Absence de persistance des conversations**
Les échanges avec les agents n'ont pas d'historique structuré. Chaque run est
isolé. Il est impossible de retrouver un run passé ou de continuer une session.

**3. Pas de déploiement serveur**
Ada-ui lit `.claude/` directement sur le filesystem local. Il est impossible de
déployer l'UI sur un VPS et d'accéder à ada-core sur une autre machine. Le
multi-utilisateur et le multi-device sont impossibles.

**4. Couplage fort UI ↔ filesystem**
Ada-ui connaît la structure interne des fichiers ada-core (paths, formats JSON).
Toute évolution du format interne de ada-core casse l'UI. Pas de contrat formel.

---

## Décision

Transformer ADA en **plateforme 3 services** avec séparation stricte des
responsabilités :

```
ada-core  →  ada-api  →  ada-ui
(CLI inchangé)  (nouveau serveur)  (UI étendue)
```

**Ada-core** reste inchangé dans son comportement fondamental. Seuls 3 ajouts
mineurs : `emitIPC()` post-write atomique, `events.ndjson` append-only,
et le flag `--headless` pour supprimer les sorties ANSI.

**Ada-api** est un nouveau service Fastify + SQLite qui :
- Reçoit les événements IPC d'ada-core (push socket)
- Persiste les conversations, workspaces et messages
- Expose une API REST + WebSocket pour ada-ui
- Spawne des processus ada-core CLI pour les mutations

**Ada-ui** est étendu pour :
- Se connecter uniquement à ada-api (plus de lecture directe de fichiers)
- Permettre les mutations (spawn run, cancel, send message)
- Afficher les conversations et workspaces
- Recevoir les mises à jour en temps réel via WebSocket

---

## Alternatives rejetées

### Alternative A — Transformer ada-core en monolithe API

Ada-core deviendrait un serveur HTTP qui expose lui-même une API REST et
WebSocket, en plus de son rôle d'orchestrateur CLI.

**Rejeté pour** :
- Couplage fort entre le moteur d'exécution et la couche réseau
- Risque de régression sur le CLI existant (tests, dépendances)
- Ada-core est CommonJS, non typé, difficile à faire évoluer vers un serveur
  HTTP robuste sans réécriture majeure
- Impossible de redémarrer l'API sans tuer les runs en cours
- Un crash HTTP entraînerait un crash des runs actifs

### Alternative B — FSWatcher polling dans ada-api

Ada-api surveillerait les fichiers de ada-core avec `chokidar` et lirait les
changements par polling.

**Rejeté pour** :
- Race condition : ada-api peut lire un fichier partiellement écrit
- Latence de détection : 100ms à 500ms selon l'OS et le filesystem
- Sur macOS, `kqueue` est notorieusement peu fiable pour les fichiers atomiques
- Consommation CPU non nulle même quand ada-core est idle
- Impossible sur un déploiement multi-machine (volumes distants)

Ce mode reste disponible comme **fallback de niveau 3** uniquement.

### Alternative C — Redis pub/sub comme bus d'événements

Un serveur Redis servirait de bus entre ada-core et ada-api.

**Rejeté pour** :
- Dépendance externe lourde pour un usage single-user initial
- Redis doit être installé, configuré et maintenu séparément
- Single point of failure supplémentaire
- Latence légèrement supérieure à un socket local
- La complexité est justifiée pour du multi-node ; pas pour v2

Redis reste une option de migration future si ada-core devient distribué.

### Alternative D — gRPC entre ada-core et ada-api

Protocole binaire structuré avec code généré depuis des `.proto`.

**Rejeté pour** :
- Ada-core est CommonJS sans TypeScript ; la génération gRPC est complexe
- NDJSON sur socket Unix offre des performances suffisantes (< 1ms local)
- Debuggabilité : les messages NDJSON sont lisibles avec `tail -f events.ndjson`
- Pas de dépendance à `@grpc/grpc-js` et la complexité de setup associée

---

## Conséquences positives

**Séparation des cycles de déploiement** : ada-api peut être mis à jour sans
redémarrer ada-core (et donc sans couper les runs en cours).

**Déploiement serveur possible** : ada-ui + ada-api peuvent être sur un VPS,
ada-core sur la machine locale ou dans un container séparé.

**Persistance des conversations** : les messages, workspaces et sessions sont
stockés dans ada-api.db et survivent aux redémarrages.

**Contrat formel** : le catalogue d'événements (EVENT-CATALOG.md) définit un
contrat immuable. L'évolution interne d'ada-core n'impacte plus ada-ui.

**Mutations depuis l'UI** : spawn, cancel, retry de runs depuis l'interface.

**Multi-device** : accès depuis n'importe quel navigateur via le domaine serveur.

## Conséquences négatives

**Complexité opérationnelle accrue** : 3 services à démarrer, surveiller et
mettre à jour. Géré par `ada server start/stop/status/update`.

**Nouveau service à maintenir** : ada-api en TypeScript + Fastify est un
nouveau codebase. Nécessite des tests et une maintenance active.

**Démarrage ordonné** : ada-core doit être opérationnel avant ada-api, qui
doit l'être avant ada-ui. Géré par les health checks et `depends_on`.

**SQLite WAL** : le mode WAL doit être activé explicitement pour éviter les
locks lors des lectures simultanées (ada-api lit + écrit pendant qu'un run
tourne). C'est le cas par défaut dans la configuration fournie.
