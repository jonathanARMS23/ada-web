# ADR-014 — IPC Push via socket vs FSWatcher polling

| Champ | Valeur |
|-------|--------|
| Date | 2026-05-31 |
| Statut | Accepté |
| Décideurs | Jonathan Arms |
| Catégorie | Communication inter-process |
| Dépend de | ADR-013 |

---

## Contexte

Dans l'architecture ADA Platform v2 (ADR-013), ada-api doit être notifié des
changements d'état produits par ada-core en temps quasi-réel (< 200ms). Ada-core
écrit ses états via des `renameSync` atomiques POSIX sur des fichiers JSON.

Deux approches ont été sérieusement évaluées pour ce canal de notification.

### Le problème du polling / FSWatcher

Si ada-api utilise `chokidar` ou `fs.watch` pour détecter les changements :

```
ada-core                          ada-api (FSWatcher)
   │                                   │
   │  1. write(tmp_state.json)         │
   │  2. renameSync(tmp, state.json)   │
   │                 ← atomique ─────► │ (événement 'rename')
   │                                   │
   │  [entre 1 et 2, état inconsistant]│
   │  [ada-api pourrait lire tmp]      │
   │                                   │
   │  [délai de détection: 50-500ms]   │
   │  [sur macOS kqueue: non fiable]   │
```

La race condition est réelle : sur macOS, `fs.watch` utilise `kqueue` qui ne
garantit pas l'ordre ni la fraîcheur des événements. Des benchmarks internes
ont montré des délais de 200ms à 800ms sur des runs intensifs (> 20 events/s).

---

## Décision

**IPC push via socket NDJSON**, avec fallback en 3 couches :

### Couche 1 (primaire) — Unix Domain Socket

Ada-core émet les événements **après** le `renameSync`. La garantie d'ordre est
donc : fichier écrit → événement émis. Ada-api ne peut jamais voir un événement
avant que le fichier correspondant soit lisible.

```javascript
// run.js — ajout dans ada-core
async function emitIPC(type, payload) {
  const msg = JSON.stringify({
    id: crypto.randomUUID(),
    ts: new Date().toISOString(),
    type,
    catalog: "1.0",
    payload
  });
  ipcSocket.write(msg + "\n");
  appendEventLog(msg); // couche 3
}

// Séquence atomique garantie
fs.renameSync(tmpPath, destPath);   // 1. write atomique
await emitIPC("run.phase.done", { runId, phase }); // 2. notify après
```

### Couche 2 (secondaire) — TCP loopback

Identique au mode socket, mais sur `127.0.0.1:3099`. Activé en mode Docker
ou quand le Unix socket est indisponible. Le port 3099 est limité au loopback
(`127.0.0.1`, jamais `0.0.0.0`).

### Couche 3 (tertiaire) — events.ndjson + FSWatcher / polling

Chaque événement est aussi écrit dans `.claude/events.ndjson` (append-only)
simultanément à l'envoi IPC. Si les couches 1 et 2 sont indisponibles,
ada-api lit ce fichier en polling (toutes les 500ms) ou via FSWatcher
en mode dégradé. Le cursor dans `.claude/events.cursor` garantit qu'aucun
événement n'est rejoué deux fois.

---

## Pourquoi pas Redis / RabbitMQ / NATS

| Solution | Raison du rejet |
|----------|----------------|
| Redis pub/sub | Dépendance externe, single-user v2, overkill |
| RabbitMQ | Complexité opérationnelle très élevée, JVM ou Erlang |
| NATS | Dépendance externe, binaire à installer sur le serveur |
| Kafka | Overkill absolu pour < 100 events/minute |

Ces solutions sont pertinentes si ada-core devient distribué (plusieurs
instances sur plusieurs machines). En v2, ada-core est toujours mono-instance
sur la même machine (ou dans le même réseau Docker). Un socket local est plus
rapide et sans dépendance externe.

---

## Garanties du protocole choisi

### G1 — Pas de perte d'événement

L'écriture dans `events.ndjson` est effectuée dans le même tick synchrone que
le `renameSync`. Si le processus ada-core est tué entre l'écriture NDJSON et
l'envoi IPC, l'événement est dans le fichier et sera rejoué au redémarrage
d'ada-api.

Le `fsync` est appelé sur `events.ndjson` pour les événements critiques
(`run.started`, `run.done`, `run.cancelled`) pour garantir la persistence sur
disque même en cas de crash OS.

### G2 — Reconnexion automatique

Ada-api maintient la connexion socket. En cas de déconnexion :

```
Backoff exponentiel : 1s → 2s → 4s → 8s → 16s → 30s (plafonné)
Fallback actif      : events.ndjson polling pendant la reconnexion
Notification UI     : WSEvent notification "warn" envoyé aux clients
```

### G3 — Idempotence du replay

Chaque événement a un `id` UUID v4 unique. La DB ada-api utilise
`INSERT OR IGNORE` sur l'index unique `(id)`. Un même événement peut arriver
deux fois (socket + replay NDJSON) sans créer de doublon.

### G4 — Ordre préservé

Les événements dans `events.ndjson` sont en ordre chronologique strict
(append-only). Le socket IPC livre les événements dans l'ordre d'émission
(TCP garantit l'ordre dans une même connexion, Unix socket idem). L'ordre
est donc cohérent entre les deux canaux.

---

## Conséquences

**Positif** :
- Latence < 5ms en mode local (Unix socket)
- Aucune dépendance externe
- Debuggable : `tail -f .claude/events.ndjson | jq`
- Résistance aux pannes par le triple fallback

**Négatif** :
- Ada-core doit implémenter `emitIPC()` (3 ajouts mineurs, non bloquants)
- Le socket Unix n'est pas disponible nativement sur Windows
  (workaround : TCP mode par défaut sur Windows, ou WSL2)
- La gestion du cursor NDJSON ajoute de la complexité à ada-api
  (mitigé : ~80 lignes de code, bien isolées dans `ipc/replay.ts`)
