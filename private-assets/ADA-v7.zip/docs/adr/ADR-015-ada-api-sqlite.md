# ADR-015 — SQLite pour ada-api vs PostgreSQL

| Champ | Valeur |
|-------|--------|
| Date | 2026-05-31 |
| Statut | Accepté |
| Décideurs | Jonathan Arms |
| Catégorie | Persistance des données |
| Dépend de | ADR-013 |

---

## Contexte

Ada-api (ADR-013) a besoin d'une base de données pour persister les
conversations, workspaces, messages et run_links. Le choix du moteur impacte
l'installation, les performances, la maintenabilité et la capacité à migrer
vers un SaaS multi-tenant futur.

Ada-api cible deux modes de déploiement en v2 :
- **Mode local** : usage personnel, développeur solo, même machine
- **Mode serveur** : VPS personnel ou petite équipe (< 10 utilisateurs)

Le mode multi-tenant SaaS (> 100 utilisateurs simultanés) n'est **pas** un
objectif de v2.

---

## Décision

**SQLite** (via `better-sqlite3` + Drizzle ORM) pour ada-api v2.

### Moteur

`better-sqlite3` est choisi plutôt que `node:sqlite` (Node 22 built-in) ou
`sql.js` (WASM) pour :
- API synchrone qui simplifie le code Fastify (pas de `await` sur les queries)
- Performances supérieures pour des workloads mono-thread élevés
- Maturité et stabilité éprouvées (utilisé en production par Litestream, Turso)
- Bindings natifs optimisés

### ORM

Drizzle ORM est choisi pour :
- Type-safety totale sans code généré lourd (contrairement à Prisma)
- Support natif SQLite ET PostgreSQL sans changement de code applicatif
- Migrations légères (`drizzle-kit push` en développement, `drizzle-kit migrate` en prod)
- Bundle size minimal (< 50kb)

```typescript
// ada-api/src/db/schema.ts — exemple de table
import { sqliteTable, text, integer, real } from "drizzle-orm/sqlite-core";
import { sql } from "drizzle-orm";

export const conversations = sqliteTable("conversations", {
  id:          text("id").primaryKey(),                 // UUID v4
  workspaceId: text("workspace_id").notNull(),
  title:       text("title").notNull(),
  profile:     text("profile").notNull(),
  createdAt:   text("created_at")
               .default(sql`(datetime('now'))`).notNull(),
  updatedAt:   text("updated_at")
               .default(sql`(datetime('now'))`).notNull(),
});

// Migration future PostgreSQL : seul le dialect change
// import { pgTable, text, timestamp } from "drizzle-orm/pg-core";
```

---

## WAL mode (Write-Ahead Logging)

Le mode WAL est **activé obligatoirement** au démarrage d'ada-api :

```typescript
// ada-api/src/db/client.ts
import Database from "better-sqlite3";

export function createDb(path: string): Database.Database {
  const db = new Database(path);

  // WAL obligatoire : permet lectures simultanées pendant une écriture
  db.pragma("journal_mode = WAL");

  // Performances + sécurité
  db.pragma("synchronous = NORMAL");  // plus rapide que FULL, suffisant avec WAL
  db.pragma("foreign_keys = ON");
  db.pragma("temp_store = MEMORY");
  db.pragma("mmap_size = 268435456"); // 256MB mmap

  return db;
}
```

**Pourquoi WAL est obligatoire** : Ada-api reçoit des événements IPC d'ada-core
(writes fréquents) pendant que des requêtes REST lisent la DB. Sans WAL, une
write transaction bloque toutes les reads. Avec WAL, les reads et writes sont
concurrents (readers ne bloquent pas les writers et vice versa).

---

## Path de la base de données

```
Variable    : $ADA_DB_PATH
Défaut local: ~/.claude-<profile>/ada-api.db
              ex: ~/.claude-pro/ada-api.db
Défaut Docker: /data/ada-api.db (volume monté)
```

La résolution du chemin dans ada-api :

```typescript
// ada-api/src/config.ts
export function resolveDbPath(): string {
  if (process.env.ADA_DB_PATH) {
    return process.env.ADA_DB_PATH;
  }

  const profile = process.env.ADA_ACTIVE_PROFILE ?? "default";
  const homeDir = os.homedir();
  const claudeDir = profile === "default"
    ? path.join(homeDir, ".claude")
    : path.join(homeDir, `.claude-${profile}`);

  fs.mkdirSync(claudeDir, { recursive: true });
  return path.join(claudeDir, "ada-api.db");
}
```

---

## Schéma des tables

```sql
-- Workspaces (regroupement de conversations)
CREATE TABLE workspaces (
  id          TEXT PRIMARY KEY,              -- UUID v4
  name        TEXT NOT NULL,
  profile     TEXT NOT NULL,
  description TEXT,
  created_at  TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Conversations (sessions de chat)
CREATE TABLE conversations (
  id           TEXT PRIMARY KEY,            -- UUID v4
  workspace_id TEXT NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  title        TEXT NOT NULL,
  profile      TEXT NOT NULL,
  created_at   TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at   TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Messages (historique)
CREATE TABLE messages (
  id              TEXT PRIMARY KEY,         -- UUID v4
  conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  role            TEXT NOT NULL CHECK (role IN ('user', 'assistant', 'system')),
  content         TEXT NOT NULL,
  run_id          TEXT,                     -- lien vers un run ada-core (nullable)
  seq             INTEGER NOT NULL,         -- ordre dans la conversation
  created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_messages_conversation ON messages(conversation_id, seq);

-- Run links (association conversation ↔ runId ada-core)
CREATE TABLE run_links (
  id              TEXT PRIMARY KEY,         -- UUID v4
  run_id          TEXT NOT NULL UNIQUE,     -- runId ada-core
  conversation_id TEXT NOT NULL REFERENCES conversations(id),
  profile         TEXT NOT NULL,
  status          TEXT NOT NULL DEFAULT 'starting'
                  CHECK (status IN ('starting','running','done','cancelled','error')),
  phases_total    INTEGER,
  phases_done     INTEGER NOT NULL DEFAULT 0,
  tokens_used     INTEGER NOT NULL DEFAULT 0,
  started_at      TEXT NOT NULL DEFAULT (datetime('now')),
  completed_at    TEXT
);
CREATE INDEX idx_run_links_conversation ON run_links(conversation_id);

-- Sessions WebSocket actives
CREATE TABLE sessions (
  id         TEXT PRIMARY KEY,              -- UUID v4 (= token WS)
  user_id    TEXT NOT NULL DEFAULT 'local', -- pour le multi-user futur
  rooms      TEXT NOT NULL DEFAULT '[]',   -- JSON array des rooms abonnées
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  last_seen  TEXT NOT NULL DEFAULT (datetime('now'))
);
```

---

## Migration future vers PostgreSQL

La migration est possible sans changement du code applicatif grâce à Drizzle :

```typescript
// Aujourd'hui (SQLite)
import { drizzle } from "drizzle-orm/better-sqlite3";
import Database from "better-sqlite3";
const db = drizzle(new Database(resolveDbPath()));

// Futur (PostgreSQL) — uniquement ces lignes changent
import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
const db = drizzle(new Pool({ connectionString: process.env.DATABASE_URL }));
```

Les types Drizzle (`text`, `integer`, etc.) ont des équivalents directs en
PostgreSQL. La seule adaptation nécessaire : remplacer `datetime('now')` par
`now()` dans les defaults SQL — géré par Drizzle automatiquement selon le dialect.

**Trigger de migration** : SQLite devient un goulot quand :
- > 50 utilisateurs simultanés
- > 10 GB de données
- Besoin de réplication ou de sharding

En v2, aucun de ces seuils n'est atteint.

---

## Alternatives rejetées

### PostgreSQL dès v2

**Rejeté pour** :
- Nécessite une installation serveur (PostgreSQL daemon, auth, pg_hba.conf)
- Impossible en mode local sans Docker
- Overhead opérationnel disproportionné pour 1 utilisateur
- Ajoute une dépendance de démarrage critique

### PlanetScale / Turso (SQLite distribué)

**Rejeté pour** :
- Dépendance externe (cloud) — contraire au principe d'autonomie d'ADA
- Latence réseau sur chaque query
- Coût non nul pour un usage personnel

### MongoDB

**Rejeté pour** :
- Schema-less inadapté à des données fortement relationnelles (messages ↔ conversations ↔ workspaces)
- Pas de transactions ACID simples
- Overkill en ressources pour le cas d'usage

---

## Conséquences

**Positif** :
- Installation zero-config : la DB est créée automatiquement à `ada server start`
- Performances excellentes en single-user (> 50k queries/s en lecture)
- Fichier unique facilement sauvegardable et transportable
- Mode WAL résout le problème de concurrence lecture/écriture
- Migration PostgreSQL possible sans refactoring applicatif

**Négatif** :
- SQLite ne supporte pas la réplication native (lecture sur plusieurs nodes)
- Pas de connexions réseau (DB doit être sur la même machine qu'ada-api)
- Le fichier `.db-wal` doit être inclus dans les backups
- `better-sqlite3` est un binding natif Node.js : nécessite une recompilation
  si l'ABI Node change (géré par `node-pre-gyp` automatiquement)
