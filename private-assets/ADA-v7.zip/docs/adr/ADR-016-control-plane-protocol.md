# ADR-016 — Control Plane Protocol (liaison ada-api ↔ ada-core)

| Champ | Valeur |
|-------|--------|
| Date | 2026-06-09 |
| Statut | Proposé (en revue) |
| Décideurs | Jonathan Arms |
| Catégorie | Communication inter-process / Architecture |
| Remplace | ADR-014 (IPC unidirectionnel) |
| Impacte | ADR-013 (Platform v2), ADR-015 (persistance → migration Postgres séparée) |

---

## Contexte

L'état des lieux a établi que **chaque sous-système (ada-core, ada-api, ada-ui) est mature en interne, mais la liaison entre eux est cassée**. Trois causes racines, pas un bug isolé :

1. **Aucun contrat stable.** La surface de ada-core est éclatée en ~15 styles d'invocation : CLI texte (`bin/ada.js`, ~30 sous-commandes), un seul JSON (`run.js next --json`), modules `require()` in-process (router/bank/provider-gateway), fichiers d'état, et un IPC fire-and-forget.
2. **IPC fantôme.** ADR-014 spécifiait un push socket, mais l'implémentation a deux *clients* et zéro *serveur* (`coordinator/ipc-emit.js:51` et `ada-api/src/ipc/client.js` sont tous deux des `net.createConnection`). Les noms d'events sont désalignés (core émet `run.completed`, l'API écoute `run.done` — `run.js:794` vs `ada-api/src/ipc/handler.js:59`), les ports/sockets divergent (`/tmp/ada-api.sock:3002` côté core vs `.claude/ada-core.sock:3099` côté API), et la corrélation `workspaceId`/`conversationId` n'est jamais émise.
3. **Pas de moteur d'exécution.** Un run ne peut pas avancer sans un humain qui lance `ada launch` (Claude Code en TTY interactif). L'unique spawn de Claude est `spawnSync('claude', [], {stdio:'inherit'})` (`bin/ada.js:1344`) — aucun `-p`, `--resume`, ni `--output-format stream-json`. **Le pilotage programmatique de Claude Code est totalement absent.**

ADR-014 ne résolvait que la cause #2 (et seulement le sens core→api). Cette ADR traite les trois ensemble, car réparer la plomberie sans combler le gap d'exécution ne débloque pas le produit.

### Décisions de cadrage (verrouillées avec le décideur)

| Question | Choix |
|----------|-------|
| Framework API | Migration **Fastify → NestJS** |
| Cible du bridge | **Hybride** : pilote l'orchestration ada-core ET Claude Code headless |
| Transport ada-api ↔ ada-core | **Daemon JSON-RPC sur Unix socket** |
| Exécution d'une phase | **CLI subprocess (`claude -p`) par défaut**, SDK natif en option |
| File d'exécution asynchrone | **pg-boss** (adossé à PostgreSQL) |
| Persistance | **PostgreSQL/Supabase** (schéma détaillé : ADR-017, à venir) |

---

## Décision

Architecture en **5 couches**. Les 4 premières reprennent le diagramme de référence ; la 5ᵉ (Control Server) est l'ajout qui rend le contrat stable et unique.

```
┌──────────────────────────────────────────────────────────────────────┐
│ L1  NestJS API Gateway                                                 │
│      ClaudeController(REST+Guards) · StreamGateway(WS/SSE) ·           │
│      SessionManager(contexte/history, Postgres) · JobQueue(pg-boss)   │
├──────────────────────────────────────────────────────────────────────┤
│ L2  ClaudeCodeBridgeService                                           │
│      ★ TaskRouter/Planner (instruction → plan) ·                      │
│      CapabilityDiscovery · ProtocolAdapter · StreamParser ·           │
│      HealthProbe · ★ OrchestrationLoop (moteur d'exécution manquant)  │
├───────────────────────────────┬──────────────────────────────────────┤
│ L3a Transport — exécution      │ L3b Transport — orchestration         │
│      CLI Subprocess (claude -p)│      Control Plane Client             │
│      SDK Native (option)       │      (JSON-RPC / Unix socket)         │
│      MCP Passthrough           │                                       │
├───────────────────────────────┼──────────────────────────────────────┤
│ L4  Claude Code instance       │ L5  ★ ada-core Control Server         │
│      CLAUDE.md · MCP · hooks · │      daemon long-running, require()   │
│      sessions --resume         │      in-process run/router/bank/...   │
└───────────────────────────────┴──────────────────────────────────────┘
```

**Clarification d'architecture clé** (conséquence du mode hybride) : en mode pipeline, c'est **NestJS (OrchestrationLoop) qui pilote la boucle** — il appelle `run.start`/`run.done` et exécute lui-même Claude Code. NestJS est donc **la source de vérité du cycle de vie** et émet les events vers l'UI directement. Le canal d'events du Control Server (core→api) devient **secondaire** : il sert uniquement à observer les changements **hors-bande** (un `ada run` lancé en CLI, un worker du daemon, une autre instance API). Cela élimine la confusion `broadcastAll` et la question « qui émet ».

---

## 0. But principal & flux nominal

**Objectif, en une phrase** : depuis ada-api, j'envoie une **instruction** ; ada-core l'**orchestre et l'exécute** de façon autonome, et je peux **interagir avec tous ses aspects** (mémoire, routeur, coûts, agents, skills…).

**Vision cible** : ada-api est branché à une interface (notamment **ada-ui**) qui doit permettre de **tout piloter** — au point de **remplacer intégralement le terminal `ada launch`**. Conséquence directe : l'API doit exposer non seulement l'exécution, mais aussi l'**interactivité d'une session** (réponses en cours, follow-ups, interruption), le **brokering des permissions** (les approbations d'outils que le terminal affiche), et **l'intégralité de la surface CLI `ada`**. Voir §6bis (la condition de complétude de cette vision).

### Point d'entrée unique par instruction

```
POST /tasks { instruction, profile, mode?: "auto"|"pipeline"|"freeform" }
```

Le **TaskRouter/Planner** (L2) transforme l'instruction libre en plan exécutable — c'est la logique de la table de routing du CLAUDE.md transformée en service. Deux stratégies, choisies par `mode` (défaut `auto`) :

| Stratégie | Quand | Comment |
|-----------|-------|---------|
| **Pipeline structuré** (Mode A, §5) | instruction qui matche un pipeline connu (feature, review, db-migrate…) | Planner détecte le profil/pipeline (routing par mots-clés + arbitrage LLM via `provider.complete` tier 1 si ambigu), produit `{pipeline, feature, opts}`, lance l'**OrchestrationLoop** : run.js DAG + Thompson Sampling + retries + parallel_mesh, observable et reprenable. |
| **Free-form orchestré** (Mode B, §6) | instruction exploratoire / hors pipeline | lance une session **Claude Code headless** amorcée avec le CLAUDE.md du profil (comportement orchestrateur) ; Claude détecte le profil et délègue lui-même aux agents via le Task tool. Flexible, non structuré. |

Dans les deux cas, le résultat **stream** vers le client (StreamGateway). Le Planner peut, en `mode:auto`, demander une **clarification** avant de lancer (règle « étape 0 » du CLAUDE.md) — renvoyée comme event `task.clarification` à l'UI.

### Accès à « tous les aspects » de ada-core

Au-delà de l'exécution, chaque sous-système est piloté par sa méthode RPC (§2) et exposé en REST par le `ClaudeController` :

| Aspect | Endpoint REST (L1) | Méthode RPC (L5) |
|--------|--------------------|--------------------|
| Lancer/suivre une tâche | `POST /tasks`, `GET /runs/:id`, `GET /runs` | `run.*` |
| Mémoire (ReasoningBank) | `GET /memory?q=`, `POST /memory` | `bank.retrieve/store/stream` |
| Routeur (Thompson) | `GET /router/stats` | `router.recommend/stats` |
| Coûts & métriques | `GET /stats/cost`, `GET /stats/metrics` | `cost.report`, `metrics.get`, `budget.check` |
| Catalogue (agents/skills/pipelines/teams/MCP) | `GET /capabilities` | `capabilities.list` |
| Providers LLM | `POST /providers/complete` | `provider.complete/embed` |
| Santé | `GET /health` | `health.probe` |

---

## 1. Protocole Control Plane (L5 ↔ L3b)

### 1.1 Transport

- **Primaire** : Unix Domain Socket, un **par profil** : `<profileDir>/control.sock` (ex. `~/.claude-pro/control.sock`). Un serveur par profil = isolation native de l'état (les modules ada-core lisent `CLAUDE_CONFIG_DIR`), pas de multiplexing fragile.
- **Fallback** : TCP loopback `127.0.0.1:<port>` (jamais `0.0.0.0`) pour Docker/Windows, port dérivé du profil.
- Latence cible < 5 ms en local.

### 1.2 Framing — JSON-RPC 2.0 sur NDJSON

Chaque message est une ligne JSON terminée par `\n`. On généralise l'enveloppe ADR-014 en JSON-RPC 2.0 :

```jsonc
// Requête (api → core)
{"jsonrpc":"2.0","id":"u-7f3a","method":"run.next","params":{"runId":"feature-auth-..."}}
// Réponse (core → api)
{"jsonrpc":"2.0","id":"u-7f3a","result":{"topology":"parallel_mesh","ready":[...]}}
// Erreur
{"jsonrpc":"2.0","id":"u-7f3a","error":{"code":1001,"message":"RUN_NOT_FOUND"}}
// Notification / event (core → api, sans id)
{"jsonrpc":"2.0","method":"event","params":{"type":"run.completed","ts":"...","payload":{...}}}
```

### 1.3 Authentification

- HMAC-SHA256 par frame, secret `~/.ada/ipc.secret` (mécanisme existant, `0600`) — champ `_sig` ajouté en fin de ligne avant `\n` (compat ADR-014).
- Perms socket `0600`. Handshake initial obligatoire avant toute méthode.

### 1.4 Handshake & versioning

Première frame après connexion :

```jsonc
{"jsonrpc":"2.0","id":"hs","method":"hello",
 "params":{"protocolVersion":"1.0.0","client":"ada-api/2.0.0","profile":"pro"}}
// → result: {"protocolVersion":"1.0.0","capabilities":["run.*","router.*","bank.*",...],"adaCore":"1.0.0"}
```

Versioning **semver**. Incompatibilité majeure → erreur `1005 PROTOCOL_VERSION_UNSUPPORTED`. `capabilities.list` (cf. §4) expose le détail des méthodes/agents/pipelines disponibles.

---

## 2. Catalogue des méthodes RPC

Tous les appels sont **in-process** (`require()` des modules existants) — zéro parsing texte. Mapping vers la surface réelle de ada-core :

| Méthode | Module ada-core | Params | Result |
|---------|-----------------|--------|--------|
| `run.init` | `run.js init` (`:383`) | `{pipeline, feature, opts:{backend,apiOnly,noDeploy}, correlation:{workspaceId,conversationId}}` | `{runId, phases}` |
| `run.next` | `run.js` (`:1118`) | `{runId, estimate?}` | `{topology, ready:[{phaseId,agent,tier,model,required,acwContext,retryContext}], parallelizable}` |
| `run.start` | `run.js start` (`:677`) | `{runId, phaseId}` | `{ok, lockId}` |
| `run.done` | `run.js done` (`:794`) | `{runId, phaseId, summary, tokens, cost}` | `{ok, runStatus}` |
| `run.fail` | `run.js fail` (`:926`) | `{runId, phaseId, error, retryable, tokens, cost}` | `{ok}` |
| `run.skip` | `run.js skip` | `{runId, phaseId, reason}` | `{ok}` |
| `run.status` | `runs/<id>/state.json` | `{runId}` | `{state.json complet}` |
| `run.retry` / `run.rollback` / `run.checkRetry` | `run.js` | `{runId, phaseId?}` | `{ok, readyPhases?}` |
| `run.list` | `run.js list` | `{limit}` | `[{runId, pipeline, status, ...}]` |
| `router.recommend` | `router.recommendWithContext` (`:264`) | `{phaseType, context}` | `{agent, tier, model}` |
| `router.update` | `router.update` (`:386`) | `{phaseType, agent, outcome}` | `{ok}` |
| `router.stats` | `router.js stats` | `{}` | `{priors[], ...}` |
| `bank.retrieve` | `bank.smartRetrieve` (`:1556`) | `{query, phase?, agent?, topK?}` | `[{trajectory}]` |
| `bank.store` | `bank.store` | `{phase, agent, verdict, summary}` | `{id}` |
| `bank.stream` | `bank.retrieveStream` (`:1482`) | `{query, opts}` | notifications `bank.chunk` puis `bank.end` |
| `provider.complete` | `gateway.complete` (`:567`) | `{messages, tier}` | `{content, model, cost}` |
| `provider.embed` | `gateway.embed` | `{text}` | `{vector}` |
| `cost.report` | `workers/cost-report.js --json` | `{sessions?}` | `{rapport agrégé}` |
| `metrics.get` | `workers/metrics.js --json` | `{}` | `{runs, router, bank, tokens}` |
| `budget.check` / `budget.record` | `budget-guard.js` (`:229`) | `{estCost}` / `{cost}` | `{allowed, dailyRemaining}` |
| `capabilities.list` | introspection (cf. §4) | `{}` | manifeste de capacités |
| `health.probe` | (cf. §5) | `{}` | `{status, uptime, activeRuns, circuitStates}` |

---

## 3. Taxonomie des événements

Vocabulaire **normalisé unique**, avec corrélation `{runId, workspaceId, conversationId, sessionId}` injectée dès `run.init`. Deux origines distinctes :

**A. Émis par NestJS (StreamGateway) — source de vérité du flux UI** (mode pipeline piloté) :

| Event | Origine | Payload |
|-------|---------|---------|
| `run.started` | OrchestrationLoop | `{runId, pipeline, name, workspaceId, conversationId}` |
| `run.phase.started` | OrchestrationLoop | `{runId, phaseId, agent, model}` |
| `run.phase.output` | StreamParser (NDJSON `claude -p`) | `{runId, phaseId, chunk}` (token streaming) |
| `run.phase.tool` | StreamParser | `{runId, phaseId, tool, input}` |
| `run.phase.completed` | OrchestrationLoop | `{runId, phaseId, agent, tokens, cost, durationMs}` |
| `run.phase.failed` | OrchestrationLoop | `{runId, phaseId, agent, error, retryable, tokens, cost}` |
| `run.completed` | OrchestrationLoop | `{runId, pipeline, status, totalTokens, totalCost}` |

**B. Émis par le Control Server (core→api) — observabilité hors-bande** (CLI, daemon, autre instance) : mêmes noms que ci-dessus, normalisés au niveau du serveur (on supprime l'ancien désalignement `run.completed` vs `run.done`). NestJS s'y abonne et **déduplique par `id` UUID** (idempotence ADR-014 G3 préservée). Routage **par room workspace**, jamais `broadcastAll`.

> `events.ndjson` reste le journal append-only durable (G1/G4 d'ADR-014). NestJS le rejoue au reconnect via le cursor pour rattraper les events manqués.

**C. Messages entrants (client → serveur, via WS)** — l'interactivité qui remplace le terminal :

| Message | Sens | Payload |
|---------|------|---------|
| `task.message` | follow-up / réponse en cours de session | `{sessionId, content}` |
| `task.interrupt` | interrompre la génération (équivalent ESC) | `{sessionId}` |
| `task.cancel` | annuler le run/la session | `{runId\|sessionId}` |
| `task.permission_response` | réponse à une demande d'approbation d'outil | `{requestId, decision:"allow"\|"deny"\|"allow_always", updatedInput?}` |
| `task.plan_response` | approbation/rejet d'un plan (plan mode) | `{sessionId, decision:"approve"\|"edit", feedback?}` |
| `task.clarification_response` | réponse à une question de clarification | `{sessionId, answers}` |

Et les events **sortants** correspondants (serveur → client) : `task.permission_request {requestId, tool, input}`, `task.plan {steps}`, `task.clarification {questions}`.

---

## 4. CapabilityDiscovery — manifeste

`capabilities.list` retourne l'introspection de l'installation pour que l'UI/clients découvrent dynamiquement ce qui est disponible :

```jsonc
{
  "protocolVersion": "1.0.0",
  "profile": "pro",
  "models": {"tier1":"claude-haiku-4-5-20251001","tier2":"claude-sonnet-4-6","tier3":"claude-opus-4-8"},
  "pipelines": [{"name":"feature","phases":[...]}, ...],   // coordinator/pipelines.json
  "agents":   [{"slug":"nestjs","category":"backend"}, ...], // agents/*.md
  "skills":   [...],                                          // skill-registry
  "teams":    [...],                                          // teams/profiles.json
  "mcpServers": [...],                                        // config Claude Code (.mcp.json)
  "methods":  ["run.*","router.*","bank.*","provider.*","cost.*","metrics.*","budget.*"]
}
```

---

## 5. OrchestrationLoop — le moteur d'exécution (Mode A)

Comble le gap #3. Séquence d'un run piloté :

```
POST /runs {pipeline, feature, workspaceId, conversationId}
  └─ Bridge → control.run.init → {runId}
  └─ JobQueue(pg-boss) enqueue job "orchestrate:<runId>"

[worker pg-boss]
  loop:
    control.run.next(runId) → {topology, ready[], parallelizable}
    si ready vide → fin
    pour chaque phase de ready (en parallèle si topology=parallel_mesh, borné par concurrence) :
      control.run.start(runId, phaseId)
      ProtocolAdapter.execute(phase):                       ← L3a
        spawn `claude -p --output-format stream-json \
               --model <phase.model> --append-system-prompt <agent.md> \
               --resume <sessionId?>`  avec CLAUDE_CONFIG_DIR=<profileDir>
        StreamParser(stdout NDJSON) → emit run.phase.output / run.phase.tool
      à la complétion :
        control.run.done(runId, phaseId, summary, {tokens, cost})  (ou run.fail)
        emit run.phase.completed
    répéter
  emit run.completed
```

- **Parallélisme** : `topology=parallel_mesh` (`run.js:1314`) → exécution concurrente des phases de `parallelizable[]`, plafonnée par la concurrence pg-boss.
- **Modèle par tier** : `phase.model` vient de `run.next` (résolu via `TIER_MODELS`), passé à `--model`.
- **Reprise** : un job pg-boss interrompu reprend via `control.run.next` (idempotent sur l'état `state.json`).

## 6. Mode B — Claude Code direct (headless ad-hoc)

```
POST /claude/query {prompt, sessionId?, profile, allowedTools?}
  └─ Bridge → ProtocolAdapter → spawn `claude -p --resume <sessionId> \
       --output-format stream-json` (ou SDK natif si configuré)
  └─ StreamParser → stream tokens/tool-uses (WS/SSE)
  └─ SessionManager persiste {sessionId, profile, lastMessageId} en Postgres pour --resume
```

Le `ProtocolAdapter` choisit CLI (défaut, isolation par `CLAUDE_CONFIG_DIR`) ou SDK `@anthropic-ai/claude-agent-sdk` (option basse latence), selon config et capacité détectée par `HealthProbe`.

---

## 6bis. Sessions interactives & remplacement du terminal (vision cible)

C'est la **condition de complétude** : pour se passer de `ada launch`, l'API doit reproduire tout ce qu'offre la session TTY interactive. Quatre piliers.

### A. Session bidirectionnelle (pas one-shot)

`claude` est lancé en **flux bidirectionnel** : `claude -p --input-format stream-json --output-format stream-json --resume <sessionId?>`. Le bridge garde le process **vivant** ; les `task.message` entrants (§3.C) sont écrits sur le **stdin** du process comme messages user stream-json. Multi-tours dans une session, `--resume` à travers les reconnexions. `task.interrupt` envoie le signal d'interruption ; `task.cancel` tue proprement le process.

### B. Permission Broker (le pilier critique du terminal)

En terminal, Claude demande « Autoriser Bash à exécuter X ? ». En headless, on intercepte via un **outil MCP hébergé par le bridge** : `claude … --permission-prompt-tool mcp__ada__approve`. Flux :

```
Claude veut utiliser un outil gardé (Bash/Write/…)
  → appelle mcp__ada__approve(tool, input)
  → bridge émet event task.permission_request {requestId, tool, input, runId}
  → UI affiche, l'utilisateur répond → task.permission_response {requestId, decision}
  → bridge retourne la décision à Claude (allow/deny + input éventuellement modifié)
```

- **Politiques d'auto-approbation** par profil/outil (ex. `Read`=always, `Bash`/`Write`=prompt), stockées en config profil/DB — miroir du `settings.json` de Claude Code (`permissions.allow/deny/ask`).
- **Modes de permission** exposés à l'UI : `default | acceptEdits | bypassPermissions | plan` (réglables par session/run).
- `allow_always` persiste la règle dans la politique du profil.

### C. Plan mode & clarifications (règle « étape 0 » du CLAUDE.md)

- **Clarification** : avant de router, le Planner peut émettre `task.clarification {questions}` → l'UI rend des choix → `task.clarification_response`. (Reproduit le comportement d'AskUserQuestion en interface.)
- **Plan mode** : `task.plan {steps}` → `task.plan_response {approve|edit}` avant exécution. L'UI devient le lieu d'approbation des plans.

### D. Exposition exhaustive de la surface CLI (matrice de complétude)

Chaque commande `ada` (cf. cartographie ada-core) doit avoir un endpoint, sinon le terminal reste requis :

| Domaine CLI | Commande `ada` | Exposition API | Statut contrat |
|-------------|----------------|----------------|----------------|
| Exécution | `run`, `resume`, `launch` | `POST /tasks` (interactif), `GET /runs`, `task.*` WS | ★ remplace `launch` |
| Profils | `profile list/use/create` | `GET/POST /profiles`, `POST /profiles/switch` | à exposer |
| Mémoire | `memory search/hnsw/stats`, `bank …` | `GET /memory`, `bank.*` RPC | à exposer |
| Skills | `skill list/search/install/info/uninstall` | `GET/POST /skills`, `skill-registry` | à exposer |
| Teams/sync | `sync init/push/pull/status` | `GET/POST /teams/sync` | à exposer |
| Multi-profil | `ada-bridge send/receive/share-lessons` | `POST /bridge/*` | à exposer |
| Fédération | `fed init/start/sync/peers/status` | `GET/POST /federation/*` | à exposer |
| Daemon | `daemon start/stop/status/run` | `GET/POST /daemon`, `POST /daemon/jobs/:worker` | à exposer |
| Schedules | `schedule list/add/remove/toggle` | `GET/POST/DELETE /schedules` | à exposer |
| Providers | `provider status/set` | `GET/PUT /providers`, `provider.*` RPC | à exposer |
| Coûts | `cost` | `GET /stats/cost` | partiel (existe) |
| Agents | `agents list/search` | `GET /agents` | partiel (existe) |
| Obsidian | `obsidian` | `GET/POST /obsidian/*` | partiel (existe) |
| PR | `pr` | `POST /pr` | à exposer |
| Diagnostic | `doctor`, `logs`, `status` | `GET /health`, `GET /logs`, `health.probe` | à exposer |

> Un **test d'acceptation de la vision** : « toute action faisable dans `ada launch` ou via une commande `ada` est faisable depuis ada-ui via ada-api, sans ouvrir de terminal. » Cette matrice est la checklist de ce critère.

---

## 7. Cycle de vie & supervision

- **Démarrage** : `ada control start [--profile]` (PID file `<profileDir>/control.pid`), ou auto-spawn par NestJS au premier `hello` (spawn + attente du socket avec timeout).
- **Arrêt gracieux** : SIGTERM → draine les requêtes en cours → ferme le socket.
- **Reconnexion API** : backoff exponentiel 1→30 s (ADR-014 G2), fallback `events.ndjson` pendant la coupure, notification `warn` aux clients WS.
- **HealthProbe** : `health.probe` + endpoint `/health/ready` NestJS (503 si Control Server injoignable).
- **Backpressure** : `run.phase.output` et `bank.chunk` sont **lossy** si le client est lent (on drop des chunks de sortie) ; les events de cycle de vie sont **lossless** (jamais droppés).

## 8. Modèle d'erreurs (codes JSON-RPC applicatifs)

| Code | Nom | Sens |
|------|-----|------|
| 1001 | `RUN_NOT_FOUND` | runId inconnu |
| 1002 | `PHASE_LOCKED` | lock `runs/<id>.lock` détenu |
| 1003 | `BUDGET_EXCEEDED` | budget-guard refuse |
| 1004 | `PROFILE_MISMATCH` | profil de la connexion ≠ profil demandé |
| 1005 | `PROTOCOL_VERSION_UNSUPPORTED` | handshake incompatible |
| 1006 | `CLAUDE_EXEC_FAILED` | spawn `claude` échoué / non trouvé |
| -32600/-32601/-32602 | (standard) | requête/méthode/params invalides |

---

## 9. Sécurité

- Socket `0600` + HMAC par frame ; jamais d'écoute sur `0.0.0.0`.
- Isolation profil forte (serveur + socket par profil ; `CLAUDE_CONFIG_DIR` fixé).
- `claude` résolu par **chemin absolu** (corrige le risque PATH de `services/run.js:56`), `shell:false`, args en tableau.
- Rate-limit dédié sur `POST /runs` et `POST /claude/query` (Guards NestJS).
- Pas de secret côté client ; JWT hors persistance/URL (déjà OK côté UI).

## 10. Plan de migration (par phases, non bloquant)

| Phase | Livrable | Déprécie |
|-------|----------|----------|
| P0 | `coordinator/control-server.js` (daemon) wrappant les modules existants ; `ada control` CLI | — |
| P1 | NestJS : `ControlPlaneClient`, `CapabilityDiscovery`, `HealthProbe` ; remplace l'IPC cassé | `ipc-emit.js` fire-and-forget → canal events du serveur |
| P2 | `OrchestrationLoop` + `ProtocolAdapter`(CLI) + `StreamParser` (Mode A) | `ada launch` interactif comme seul moyen d'exécuter |
| P3 | `SessionManager` + Mode B direct + SDK natif optionnel | — |
| P4 | Bascule ada-api Fastify → NestJS ; migration Postgres (ADR-017) | ada-api Fastify, ADR-015 SQLite |

Le CLI `ada` continue de fonctionner pendant toute la migration (il peut soit appeler le Control Server, soit garder ses appels directs).

---

## Garanties préservées d'ADR-014

- **G1 pas de perte** : `events.ndjson` écrit dans le même tick que le `renameSync` d'état ; `fsync` sur events critiques.
- **G2 reconnexion** : backoff + fallback fichier.
- **G3 idempotence** : dédup par `id` UUID (`INSERT … ON CONFLICT DO NOTHING` côté Postgres).
- **G4 ordre** : append-only NDJSON + ordre TCP/socket dans une connexion.

## Conséquences

**Positif** : contrat unique versionné (remplace 15 invocations) · gap d'exécution comblé (runs autonomes) · streaming propre token/tool · isolation profil nette · events normalisés et routés par workspace · réutilise HMAC/events.ndjson existants.

**Négatif** : nouveau daemon à construire et superviser (Control Server) · couplage NestJS → catalogue de méthodes (mitigé par `capabilities.list` + semver) · le mode CLI `claude -p` ajoute un overhead de spawn par phase (mitigé : SDK natif en option, sessions `--resume`) · migration en 5 phases à séquencer.

## Points ouverts (prochaine session)

- ADR-017 — **schéma PostgreSQL** : stockage des échanges Claude Code (sessions, messages, tool-calls) + tables analytiques (tokens, coûts, latence, taux de succès par agent/phase/pipeline) pour mesurer perf & efficience.
- Choix SDK natif : valider la disponibilité/maturité de `@anthropic-ai/claude-agent-sdk` pour le mode option.
