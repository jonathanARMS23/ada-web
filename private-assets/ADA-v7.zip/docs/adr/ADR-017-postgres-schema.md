# ADR-017 — Schéma PostgreSQL/Supabase (échanges Claude Code + analytique)

| Champ | Valeur |
|-------|--------|
| Date | 2026-06-09 |
| Statut | Proposé (en revue) |
| Décideurs | Jonathan Arms |
| Catégorie | Persistance des données |
| Remplace | ADR-015 (SQLite ada-api) |
| Dépend de | ADR-016 (Control Plane Protocol), ADR-013, ADR-014 |

---

## Contexte

ADR-015 a retenu SQLite pour la v2 « locale ». ADR-016 a fait basculer trois
décisions structurantes qui invalident ce choix :

1. **pg-boss** comme file d'exécution → impose PostgreSQL de toute façon (pg-boss
   crée son propre schéma `pgboss.*` dans la même base). Maintenir SQLite *en
   plus* de Postgres serait deux moteurs pour rien.
2. **Vision « remplacer le terminal `ada launch` »** (§0, §6bis) → on ne persiste
   plus seulement des `messages` plats, mais des **sessions interactives
   complètes** : tool calls, résultats, demandes de permission, plans,
   clarifications, journal d'events rejouable.
3. **Mesure perf & efficience** (point ouvert ADR-016) → on a besoin d'un socle
   **analytique** (tokens/coût/latence/taux de succès par agent·phase·pipeline·
   modèle, historique des priors Thompson, coûts par provider/jour) qui dépasse
   ce que SQLite permet de calculer efficacement (vues matérialisées, agrégats).

Ce schéma **remplace** intégralement celui d'ADR-015. La migration des données
existantes est traitée au §Plan de migration.

### Décisions verrouillées (non rediscutées)

| Point | Choix |
|-------|-------|
| Moteur | **PostgreSQL 15+ / Supabase** |
| ORM | **Drizzle `pg-core`** |
| File d'exécution | **pg-boss** (schéma `pgboss.*`, non modélisé ici, coexiste) |
| PK | **`uuid` partout** (`gen_random_uuid()` via `pgcrypto`) |
| Timestamps | `created_at` / `updated_at` en `timestamptz` sur toute table métier |
| Isolation | **`workspace_id` sur toute table métier** + **RLS Supabase** |
| Secrets | jamais en base (HMAC/JWT/tokens hashés uniquement) |

### Principe directeur : transactionnel vs analytique

- **Transactionnel** (OLTP, écrit en temps réel par NestJS/Control Server) :
  workspaces, conversations, sessions, messages, tool_calls, tool_results,
  permission_requests, clarifications, plans + plan_steps, runs, run_phases,
  events, router_priors, cost_ledger, permission_policies, profiles.
- **Analytique** (OLAP, dérivé, lecture seule) : **vues matérialisées**
  rafraîchies hors-ligne. Aucune écriture applicative directe.

---

## Décision

### Conventions communes

```sql
CREATE EXTENSION IF NOT EXISTS pgcrypto;   -- gen_random_uuid()

-- Trigger générique de maj de updated_at (appliqué sur les tables mutables)
CREATE OR REPLACE FUNCTION set_updated_at() RETURNS trigger AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$ LANGUAGE plpgsql;
```

Helper Drizzle réutilisé par toutes les tables :

```ts
// ada-api/src/db/_common.ts
import { pgTable, uuid, timestamp } from 'drizzle-orm/pg-core';
import { sql } from 'drizzle-orm';

export const pk        = () => uuid('id').primaryKey().default(sql`gen_random_uuid()`);
export const createdAt = () => timestamp('created_at', { withTimezone: true }).notNull().defaultNow();
export const updatedAt = () => timestamp('updated_at', { withTimezone: true }).notNull().defaultNow();
```

---

### 1. Tables transactionnelles

#### 1.1 `profiles` — profils ADA (pro, default, …)

Source de l'isolation `CLAUDE_CONFIG_DIR` (ADR-016 §1.1). Référencé par tout le reste.

```sql
CREATE TABLE profiles (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug        text NOT NULL UNIQUE,          -- "pro", "default", "perso"
  display_name text NOT NULL,
  config_dir  text NOT NULL,                 -- ex ~/.claude-pro
  models      jsonb NOT NULL DEFAULT '{}',   -- {tier1,tier2,tier3} cf capabilities.list
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now()
);
```
```ts
export const profiles = pgTable('profiles', {
  id: pk(),
  slug: text('slug').notNull().unique(),
  displayName: text('display_name').notNull(),
  configDir: text('config_dir').notNull(),
  models: jsonb('models').notNull().default({}),
  createdAt: createdAt(), updatedAt: updatedAt(),
});
```

#### 1.2 `workspaces`

```sql
CREATE TABLE workspaces (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id  uuid NOT NULL REFERENCES profiles(id) ON DELETE RESTRICT,
  name        text NOT NULL,
  slug        text NOT NULL,
  description text,
  color       text NOT NULL DEFAULT '#6366f1',
  project_dir text,
  pinned      boolean NOT NULL DEFAULT false,
  archived    boolean NOT NULL DEFAULT false,
  config      jsonb   NOT NULL DEFAULT '{}',
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (profile_id, slug)
);
CREATE INDEX idx_workspaces_profile ON workspaces(profile_id);
```
> `ON DELETE RESTRICT` sur profile : on ne supprime pas un profil qui a des
> workspaces (action lourde, manuelle).

#### 1.3 `conversations`

```sql
CREATE TABLE conversations (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  title        text NOT NULL,
  summary      text,
  pinned       boolean NOT NULL DEFAULT false,
  archived     boolean NOT NULL DEFAULT false,
  last_run_id  uuid,                          -- FK ajoutée après création runs
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_conversations_workspace ON conversations(workspace_id);
CREATE INDEX idx_conversations_updated  ON conversations(workspace_id, updated_at DESC);
```

#### 1.4 `sessions` — session Claude Code interactive (cœur de la vision 6bis)

Lie le `sessionId` Claude Code (pour `--resume`) au triplet de corrélation.
Une session = un process `claude` long-running piloté par le bridge.

```sql
CREATE TABLE sessions (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id    uuid NOT NULL REFERENCES workspaces(id)    ON DELETE CASCADE,
  conversation_id uuid     REFERENCES conversations(id)      ON DELETE SET NULL,
  profile_id      uuid NOT NULL REFERENCES profiles(id)      ON DELETE RESTRICT,
  claude_session_id text,                     -- sessionId Claude Code (--resume)
  mode            text NOT NULL DEFAULT 'auto'
                  CHECK (mode IN ('auto','pipeline','freeform')),       -- POST /tasks
  permission_mode text NOT NULL DEFAULT 'default'
                  CHECK (permission_mode IN ('default','acceptEdits','bypassPermissions','plan')),
  status          text NOT NULL DEFAULT 'active'
                  CHECK (status IN ('active','idle','closed','error')),
  last_message_id uuid,                        -- pour reprise
  started_at      timestamptz NOT NULL DEFAULT now(),
  closed_at       timestamptz,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_sessions_workspace    ON sessions(workspace_id);
CREATE INDEX idx_sessions_conversation ON sessions(conversation_id);
CREATE UNIQUE INDEX idx_sessions_claude ON sessions(claude_session_id)
  WHERE claude_session_id IS NOT NULL;        -- 1 sessionId Claude ↔ 1 ligne
```
```ts
export const sessions = pgTable('sessions', {
  id: pk(),
  workspaceId: uuid('workspace_id').notNull().references(() => workspaces.id, { onDelete: 'cascade' }),
  conversationId: uuid('conversation_id').references(() => conversations.id, { onDelete: 'set null' }),
  profileId: uuid('profile_id').notNull().references(() => profiles.id, { onDelete: 'restrict' }),
  claudeSessionId: text('claude_session_id'),
  mode: text('mode', { enum: ['auto','pipeline','freeform'] }).notNull().default('auto'),
  permissionMode: text('permission_mode', { enum: ['default','acceptEdits','bypassPermissions','plan'] }).notNull().default('default'),
  status: text('status', { enum: ['active','idle','closed','error'] }).notNull().default('active'),
  lastMessageId: uuid('last_message_id'),
  startedAt: timestamp('started_at', { withTimezone: true }).notNull().defaultNow(),
  closedAt: timestamp('closed_at', { withTimezone: true }),
  createdAt: createdAt(), updatedAt: updatedAt(),
});
```

#### 1.5 `runs` — état machine d'un run piloté (remplace `run_links`)

Projection durable de `runs/<id>/state.json` (ADR-016 §2 `run.status`).

```sql
CREATE TABLE runs (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id    uuid NOT NULL REFERENCES workspaces(id)    ON DELETE CASCADE,
  conversation_id uuid     REFERENCES conversations(id)      ON DELETE SET NULL,
  session_id      uuid     REFERENCES sessions(id)           ON DELETE SET NULL,
  profile_id      uuid NOT NULL REFERENCES profiles(id)      ON DELETE RESTRICT,
  core_run_id     text NOT NULL,              -- runId ada-core ("feature-auth-...")
  pipeline        text NOT NULL,              -- feature, review, db-migrate...
  feature         text,
  topology        text,                        -- "sequential" | "parallel_mesh"
  status          text NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','running','completed','failed','cancelled','completed_with_errors')),
  phases_total    integer,
  phases_done     integer NOT NULL DEFAULT 0,
  total_tokens    bigint  NOT NULL DEFAULT 0,
  total_cost      numeric(12,6) NOT NULL DEFAULT 0,
  opts            jsonb   NOT NULL DEFAULT '{}',  -- {backend,apiOnly,noDeploy}
  state           jsonb   NOT NULL DEFAULT '{}',  -- snapshot state.json (audit/reprise)
  started_at      timestamptz,
  completed_at    timestamptz,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (profile_id, core_run_id)            -- runId unique par profil
);
CREATE INDEX idx_runs_workspace    ON runs(workspace_id);
CREATE INDEX idx_runs_conversation ON runs(conversation_id);
CREATE INDEX idx_runs_status       ON runs(status) WHERE status IN ('pending','running');
CREATE INDEX idx_runs_pipeline     ON runs(pipeline, created_at DESC);

-- FK différée conversations.last_run_id → runs.id (cycle résolu après coup)
ALTER TABLE conversations
  ADD CONSTRAINT fk_conv_last_run
  FOREIGN KEY (last_run_id) REFERENCES runs(id) ON DELETE SET NULL;
```
> `total_cost` en `numeric(12,6)` (≠ `real`) : le coût LLM est financier, on
> bannit le flottant binaire pour éviter l'accumulation d'erreurs d'arrondi.
> `total_tokens` en `bigint` (un run long dépasse aisément 2³¹).

#### 1.6 `run_phases` — une ligne par phase exécutée

Granularité analytique principale. Issue de `run.next` (agent/tier/model) +
events `run.phase.completed {tokens, cost, durationMs}` (ADR-016 §3.A).

```sql
CREATE TABLE run_phases (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  run_id        uuid NOT NULL REFERENCES runs(id) ON DELETE CASCADE,
  workspace_id  uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  phase_id      text NOT NULL,                -- id de phase dans le pipeline
  phase_type    text,                          -- type normalisé (clé du routeur)
  agent         text NOT NULL,                 -- slug agent (nestjs, reviewer...)
  tier          integer,                       -- 1|2|3
  model         text,                          -- claude-opus-4-8 ...
  required      boolean NOT NULL DEFAULT true,
  status        text NOT NULL DEFAULT 'pending'
                CHECK (status IN ('pending','running','completed','failed','skipped')),
  retry_count   integer NOT NULL DEFAULT 0,
  tokens        bigint  NOT NULL DEFAULT 0,
  cost          numeric(12,6) NOT NULL DEFAULT 0,
  duration_ms   integer,
  summary       text,
  error         text,
  retryable     boolean,
  started_at    timestamptz,
  completed_at  timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (run_id, phase_id, retry_count)       -- chaque tentative tracée
);
CREATE INDEX idx_phases_run     ON run_phases(run_id);
CREATE INDEX idx_phases_agent   ON run_phases(agent, status);
CREATE INDEX idx_phases_type    ON run_phases(phase_type, agent);
CREATE INDEX idx_phases_model   ON run_phases(model);
```

#### 1.7 `messages` — historique conversationnel

```sql
CREATE TABLE messages (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  workspace_id    uuid NOT NULL REFERENCES workspaces(id)    ON DELETE CASCADE,
  session_id      uuid     REFERENCES sessions(id)           ON DELETE SET NULL,
  run_id          uuid     REFERENCES runs(id)               ON DELETE SET NULL,
  role            text NOT NULL CHECK (role IN ('user','assistant','system','tool','error')),
  content         text NOT NULL,
  content_type    text NOT NULL DEFAULT 'text'
                  CHECK (content_type IN ('text','code','run_status','phase_log','thinking')),
  seq             integer NOT NULL,            -- ordre dans la conversation
  metadata        jsonb   NOT NULL DEFAULT '{}',
  created_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (conversation_id, seq)
);
CREATE INDEX idx_messages_conversation ON messages(conversation_id, seq);
CREATE INDEX idx_messages_session      ON messages(session_id);
```
> `seq` + `UNIQUE(conversation_id, seq)` garantit l'ordre stable (≠ tri par
> timestamp, fragile en cas d'égalité). Attribué par l'app (compteur par conv).

#### 1.8 `tool_calls` + `tool_results`

Un appel d'outil émis par Claude (event `run.phase.tool` / message stream-json),
et son résultat. Séparés car le résultat arrive plus tard (asynchrone) et peut
manquer (interruption).

```sql
CREATE TABLE tool_calls (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id   uuid     REFERENCES sessions(id)   ON DELETE CASCADE,
  message_id   uuid     REFERENCES messages(id)   ON DELETE SET NULL,
  run_id       uuid     REFERENCES runs(id)       ON DELETE SET NULL,
  phase_id     uuid     REFERENCES run_phases(id) ON DELETE SET NULL,
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  tool_use_id  text NOT NULL,                   -- id outil Claude (toolu_...)
  tool         text NOT NULL,                   -- Bash, Write, Read, Task...
  input        jsonb NOT NULL DEFAULT '{}',
  status       text NOT NULL DEFAULT 'pending'
               CHECK (status IN ('pending','running','completed','error','denied')),
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (session_id, tool_use_id)
);
CREATE INDEX idx_tool_calls_session ON tool_calls(session_id);
CREATE INDEX idx_tool_calls_tool    ON tool_calls(tool, status);

CREATE TABLE tool_results (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tool_call_id uuid NOT NULL REFERENCES tool_calls(id) ON DELETE CASCADE,
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  output       text,
  is_error     boolean NOT NULL DEFAULT false,
  duration_ms  integer,
  created_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tool_call_id)                          -- 1 résultat par appel
);
CREATE INDEX idx_tool_results_call ON tool_results(tool_call_id);
```

#### 1.9 `permission_requests` + `permission_policies` (Permission Broker, §6bis.B)

```sql
CREATE TABLE permission_requests (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id   uuid NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  run_id       uuid     REFERENCES runs(id)          ON DELETE SET NULL,
  tool_call_id uuid     REFERENCES tool_calls(id)    ON DELETE SET NULL,
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  request_id   text NOT NULL,                   -- requestId du protocole (§3.C)
  tool         text NOT NULL,
  input        jsonb NOT NULL DEFAULT '{}',
  decision     text CHECK (decision IN ('allow','deny','allow_always')),
  updated_input jsonb,                          -- input modifié par l'utilisateur
  policy_applied text,                          -- "auto:Read=always" | "user" ...
  decided_at   timestamptz,
  created_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (session_id, request_id)
);
CREATE INDEX idx_perm_req_session ON permission_requests(session_id);
CREATE INDEX idx_perm_req_pending ON permission_requests(session_id) WHERE decision IS NULL;

-- Politiques d'auto-approbation par profil/outil (miroir settings.json Claude Code)
CREATE TABLE permission_policies (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id  uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  workspace_id uuid REFERENCES workspaces(id) ON DELETE CASCADE,  -- NULL = global profil
  tool        text NOT NULL,                    -- "Read", "Bash", "Bash(npm:*)"
  effect      text NOT NULL CHECK (effect IN ('allow','deny','ask')),
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (profile_id, COALESCE(workspace_id, '00000000-0000-0000-0000-000000000000'::uuid), tool)
);
CREATE INDEX idx_perm_pol_profile ON permission_policies(profile_id, tool);
```
> `allow_always` (§6bis.B) = INSERT dans `permission_policies` avec `effect='allow'`.

#### 1.10 `clarifications`, `plans`, `plan_steps` (Plan mode & étape 0, §6bis.C)

```sql
CREATE TABLE clarifications (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id   uuid NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  questions    jsonb NOT NULL,                  -- [{aspect, question, default}]
  answers      jsonb,                           -- réponses de l'utilisateur
  answered_at  timestamptz,
  created_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_clarif_session ON clarifications(session_id);

CREATE TABLE plans (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id   uuid NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  run_id       uuid     REFERENCES runs(id)          ON DELETE SET NULL,
  workspace_id uuid NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  status       text NOT NULL DEFAULT 'proposed'
               CHECK (status IN ('proposed','approved','edited','rejected')),
  feedback     text,
  decided_at   timestamptz,
  created_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_plans_session ON plans(session_id);

CREATE TABLE plan_steps (
  id        uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_id   uuid NOT NULL REFERENCES plans(id) ON DELETE CASCADE,
  seq       integer NOT NULL,
  content   text NOT NULL,
  UNIQUE (plan_id, seq)
);
```

#### 1.11 `events` — journal rejouable (ADR-014 G1/G3/G4, ADR-016 §3)

Miroir Postgres durable de `events.ndjson`. Dédup par `id` UUID (G3).

```sql
CREATE TABLE events (
  id              uuid PRIMARY KEY,            -- fourni par l'émetteur (PAS de default)
  type            text NOT NULL,               -- run.phase.completed, task.permission_request...
  workspace_id    uuid     REFERENCES workspaces(id)    ON DELETE CASCADE,
  conversation_id uuid     REFERENCES conversations(id) ON DELETE SET NULL,
  run_id          uuid     REFERENCES runs(id)          ON DELETE SET NULL,
  session_id      uuid     REFERENCES sessions(id)      ON DELETE SET NULL,
  origin          text NOT NULL DEFAULT 'orchestration_loop'
                  CHECK (origin IN ('orchestration_loop','control_server','client')),
  payload         jsonb NOT NULL DEFAULT '{}',
  seq             bigserial,                   -- ordre global d'ingestion (cursor reconnect)
  ts              timestamptz NOT NULL DEFAULT now()
);
-- Dédup idempotente : INSERT ... ON CONFLICT (id) DO NOTHING
CREATE INDEX idx_events_run        ON events(run_id, seq);
CREATE INDEX idx_events_workspace  ON events(workspace_id, seq);
CREATE INDEX idx_events_type       ON events(type, ts DESC);
CREATE INDEX idx_events_seq        ON events(seq);   -- cursor de rejeu
```
> `id` **sans** default : l'émetteur (Control Server / OrchestrationLoop) fournit
> l'UUID, c'est ce qui rend `ON CONFLICT (id) DO NOTHING` idempotent à la reprise.
> `seq bigserial` = cursor monotone pour le rejeu au reconnect (ADR-016 §3.B).
> **Partitionnement** par range mensuel sur `ts` recommandé dès que la table
> dépasse ~50 M lignes (`PARTITION BY RANGE (ts)`), purge par `DROP PARTITION`.

#### 1.12 `router_priors` — historique d'apprentissage Thompson Sampling

Snapshots périodiques des priors (agent × phaseType → α/β) pour suivre
l'apprentissage **dans le temps** (≠ état courant côté ada-core).

```sql
CREATE TABLE router_priors (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id  uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  phase_type  text NOT NULL,
  agent       text NOT NULL,
  alpha       numeric(12,4) NOT NULL,          -- succès + 1
  beta        numeric(12,4) NOT NULL,          -- échecs + 1
  win_rate    numeric(6,5),                    -- alpha/(alpha+beta) dénormalisé
  trials      integer NOT NULL DEFAULT 0,
  snapshot_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_priors_lookup ON router_priors(profile_id, phase_type, agent, snapshot_at DESC);
```

#### 1.13 `cost_ledger` — coûts par provider/modèle/jour (budget-guard, cost-report)

Grain : une ligne par (jour, profil, provider, modèle, agent). Alimenté à la
complétion de chaque phase / appel `provider.complete`. Source de `GET /stats/cost`.

```sql
CREATE TABLE cost_ledger (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id  uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  workspace_id uuid REFERENCES workspaces(id) ON DELETE SET NULL,
  day         date NOT NULL,
  provider    text NOT NULL,                   -- anthropic, deepseek...
  model       text NOT NULL,
  agent       text,
  tier        integer,
  input_tokens  bigint NOT NULL DEFAULT 0,
  output_tokens bigint NOT NULL DEFAULT 0,
  cost        numeric(12,6) NOT NULL DEFAULT 0,
  calls       integer NOT NULL DEFAULT 0,
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (profile_id, day, provider, model, COALESCE(agent,''), COALESCE(tier,0))
);
CREATE INDEX idx_cost_day      ON cost_ledger(profile_id, day DESC);
CREATE INDEX idx_cost_provider ON cost_ledger(provider, model, day DESC);
```
> Agrégat incrémental via `INSERT ... ON CONFLICT (...) DO UPDATE SET
> cost = cost_ledger.cost + EXCLUDED.cost, ...` (upsert atomique). Le
> budget-guard lit `SUM(cost) WHERE day = CURRENT_DATE`.

---

### 2. Tables analytiques — vues matérialisées

Aucune écriture applicative. Dérivées des tables transactionnelles ci-dessus.

#### 2.1 `mv_agent_perf` — perf par agent (taux de succès, tokens, coût, latence)

```sql
CREATE MATERIALIZED VIEW mv_agent_perf AS
SELECT
  rp.agent,
  rp.phase_type,
  rp.model,
  count(*)                                            AS executions,
  count(*) FILTER (WHERE rp.status = 'completed')     AS successes,
  count(*) FILTER (WHERE rp.status = 'failed')        AS failures,
  round(
    count(*) FILTER (WHERE rp.status = 'completed')::numeric
    / NULLIF(count(*) FILTER (WHERE rp.status IN ('completed','failed')), 0), 4
  )                                                   AS success_rate,
  sum(rp.tokens)                                      AS total_tokens,
  sum(rp.cost)                                        AS total_cost,
  round(avg(rp.duration_ms))                          AS avg_duration_ms,
  percentile_cont(0.95) WITHIN GROUP (ORDER BY rp.duration_ms) AS p95_duration_ms,
  sum(rp.retry_count)                                 AS total_retries
FROM run_phases rp
GROUP BY rp.agent, rp.phase_type, rp.model;
CREATE UNIQUE INDEX ON mv_agent_perf (agent, phase_type, model);  -- requis pour REFRESH CONCURRENTLY
```

#### 2.2 `mv_pipeline_perf` — perf par pipeline

```sql
CREATE MATERIALIZED VIEW mv_pipeline_perf AS
SELECT
  r.pipeline,
  r.profile_id,
  count(*)                                          AS runs,
  count(*) FILTER (WHERE r.status = 'completed')    AS completed,
  count(*) FILTER (WHERE r.status LIKE 'failed%' OR r.status = 'completed_with_errors') AS degraded,
  round(
    count(*) FILTER (WHERE r.status = 'completed')::numeric / NULLIF(count(*),0), 4
  )                                                 AS completion_rate,
  sum(r.total_tokens)                               AS total_tokens,
  sum(r.total_cost)                                 AS total_cost,
  round(avg(EXTRACT(EPOCH FROM (r.completed_at - r.started_at)) * 1000)) AS avg_duration_ms
FROM runs r
WHERE r.completed_at IS NOT NULL
GROUP BY r.pipeline, r.profile_id;
CREATE UNIQUE INDEX ON mv_pipeline_perf (pipeline, profile_id);
```

#### 2.3 `mv_cost_daily` — coûts agrégés par jour/provider/modèle

```sql
CREATE MATERIALIZED VIEW mv_cost_daily AS
SELECT
  profile_id, day, provider, model,
  sum(input_tokens)  AS input_tokens,
  sum(output_tokens) AS output_tokens,
  sum(cost)          AS cost,
  sum(calls)         AS calls
FROM cost_ledger
GROUP BY profile_id, day, provider, model;
CREATE UNIQUE INDEX ON mv_cost_daily (profile_id, day, provider, model);
```

#### 2.4 `mv_router_learning` — évolution du winRate dans le temps

```sql
CREATE MATERIALIZED VIEW mv_router_learning AS
SELECT
  profile_id, phase_type, agent,
  date_trunc('day', snapshot_at)::date AS day,
  last(win_rate ORDER BY snapshot_at)  AS win_rate_eod,   -- nécessite ext. ou agg custom
  max(trials)                          AS trials
FROM router_priors
GROUP BY profile_id, phase_type, agent, date_trunc('day', snapshot_at);
CREATE UNIQUE INDEX ON mv_router_learning (profile_id, phase_type, agent, day);
```
> `last(... ORDER BY)` : si l'extension n'est pas dispo, remplacer par une
> sous-requête `DISTINCT ON (… ) … ORDER BY snapshot_at DESC`.

#### 2.5 Stratégie de rafraîchissement

- **Méthode** : `REFRESH MATERIALIZED VIEW CONCURRENTLY mv_*` (d'où l'index
  unique obligatoire sur chaque MV) → pas de lock en lecture.
- **Déclencheur** : worker pg-boss périodique `refresh-analytics`
  (cron 5 min pour `mv_cost_daily`, 15 min pour les perf). Aligné sur le worker
  `metrics.js`/`cost-report.js` d'ADR-016. **Jamais** de refresh synchrone dans
  le chemin de requête.
- **Fraîcheur acceptée** : 5–15 min (données d'observabilité, pas transactionnelles).

---

### 3. Politiques RLS Supabase

Activation sur **toutes** les tables métier. Modèle : isolation par
`workspace_id` (via JWT claim) pour le futur multi-tenant ; en mode local
single-user, un rôle `ada_service` (service_role) bypasse RLS.

```sql
ALTER TABLE workspaces            ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversations         ENABLE ROW LEVEL SECURITY;
ALTER TABLE sessions              ENABLE ROW LEVEL SECURITY;
ALTER TABLE runs                  ENABLE ROW LEVEL SECURITY;
ALTER TABLE run_phases            ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages              ENABLE ROW LEVEL SECURITY;
ALTER TABLE tool_calls            ENABLE ROW LEVEL SECURITY;
ALTER TABLE tool_results          ENABLE ROW LEVEL SECURITY;
ALTER TABLE permission_requests   ENABLE ROW LEVEL SECURITY;
ALTER TABLE clarifications        ENABLE ROW LEVEL SECURITY;
ALTER TABLE plans                 ENABLE ROW LEVEL SECURITY;
ALTER TABLE events                ENABLE ROW LEVEL SECURITY;
ALTER TABLE cost_ledger           ENABLE ROW LEVEL SECURITY;

-- 1) Mode local : le backend NestJS utilise la connexion service_role
--    (clé SERVICE_ROLE Supabase) qui bypasse RLS par conception.
--    => aucune policy nécessaire pour le backend de confiance.

-- 2) Multi-tenant futur : accès direct (client Supabase) filtré par workspace.
--    On suppose un claim JWT `workspace_ids` (array) ou une table membership.

-- Helper : workspaces accessibles par l'utilisateur courant
CREATE OR REPLACE FUNCTION current_workspace_ids() RETURNS uuid[] AS $$
  SELECT coalesce(
    (current_setting('request.jwt.claims', true)::jsonb -> 'workspace_ids'),
    '[]'::jsonb
  )::uuid[];  -- adapter selon le claim réel
$$ LANGUAGE sql STABLE;

-- Policy type sur une table directement porteuse de workspace_id
CREATE POLICY ws_isolation ON conversations
  FOR ALL TO authenticated
  USING      (workspace_id = ANY (current_workspace_ids()))
  WITH CHECK (workspace_id = ANY (current_workspace_ids()));

-- Idem pour runs, sessions, messages, run_phases, tool_calls, tool_results,
-- permission_requests, clarifications, plans, events, cost_ledger
-- (toutes portent workspace_id → policy identique, dupliquée par table).

-- workspaces lui-même : filtrage par id
CREATE POLICY ws_self ON workspaces
  FOR ALL TO authenticated
  USING      (id = ANY (current_workspace_ids()))
  WITH CHECK (id = ANY (current_workspace_ids()));
```

> **Raison du `workspace_id` dénormalisé sur les tables filles** (messages,
> tool_calls, run_phases…) : permet une policy RLS **directe** sans jointure
> récursive coûteuse vers `workspaces`. C'est la pratique Supabase recommandée
> (le coût de stockage est négligeable vs le coût d'une policy avec sous-requête).

---

### 4. Plan de migration SQLite (ADR-015) → PostgreSQL

#### 4.1 Mapping de types

| SQLite (ADR-015) | PostgreSQL | Note |
|------------------|-----------|------|
| `TEXT` PK (UUID) | `uuid` | conversion via `::uuid`, valider format v4 |
| `TEXT` (datetime) `datetime('now')` / `strftime(...)` | `timestamptz` `now()` | parse ISO-8601 → `to_timestamp` / cast direct |
| `TEXT` JSON (`config`, `metadata`, `phases`, `rooms`) | `jsonb` | `value::jsonb` |
| `INTEGER` (`pinned`, `archived`, mode boolean) | `boolean` | `value <> 0` |
| `INTEGER` (`tokens`) | `bigint` | élargi |
| `REAL` (`total_cost`) | `numeric(12,6)` | **change** : fin du flottant pour l'argent |
| `TEXT` enum (CHECK) | `text` + `CHECK` | enums conservés en CHECK (pas de type ENUM PG, plus souple) |

#### 4.2 Mapping table par table

| ADR-015 | ADR-017 | Transformation |
|---------|---------|----------------|
| `workspaces` | `workspaces` | + `profile_id` (résolu depuis `profile` text → FK), `slug` devient `UNIQUE(profile_id, slug)`, `run_count` supprimé (dérivé) |
| `conversations` | `conversations` | `last_run_id` text → uuid FK ; `run_count` supprimé (dérivé) |
| `messages` | `messages` | + `workspace_id`, `session_id`, `run_id` ; ajout `seq` (recalculé `ROW_NUMBER() OVER (PARTITION BY conversation_id ORDER BY created_at)`) |
| `run_links` | `runs` | `run_id` text → `core_run_id` + nouvel `id` uuid ; `phases` jsonb conservé dans `state` ; éclatement des phases vers `run_phases` (best effort, sinon vide) |
| `sessions` (WS token) | `sessions` (interactive) | **sémantique différente** : l'ancienne table = tokens WS éphémères → migrée vers une table technique `ws_tokens` *hors schéma métier* (ou Redis). La nouvelle `sessions` est créée vide. |
| `workspace_settings` | `workspaces.config` (jsonb) | fusion clé/valeur → objet jsonb |
| `ipc_events` | `events` | `payload` text→jsonb ; `processed` supprimé (remplacé par cursor `seq`) |

#### 4.3 Stratégie de bascule

ADR-016 §10 place la migration en **P4** (dernière phase, après NestJS). Bascule
**big-bang à froid** (acceptable : single-user, pas de HA en v2) :

1. **Pré-req** : Postgres/Supabase up, schéma ADR-017 appliqué (`drizzle-kit migrate`), schéma `pgboss` initialisé.
2. **Export** : script `migrate-sqlite-to-pg.ts` lit la `.db` (better-sqlite3, lecture seule), transforme selon §4.1/§4.2, écrit en Postgres par batch transactionnel (ordre FK : profiles → workspaces → conversations → runs → run_phases → messages → events → cost_ledger).
3. **Backfill analytique** : `cost_ledger` reconstruit depuis `run_phases` agrégés ; premier `REFRESH MATERIALIZED VIEW` de toutes les MV.
4. **Validation** : comptages ligne-à-ligne (`COUNT(*)` par table source/cible), checksum sur sommes de coûts/tokens.
5. **Cutover** : `DATABASE_URL` pointe Postgres ; ancien `.db` archivé (`.db.bak`) ; rollback = repointer la variable (le code Drizzle reste dialect-agnostique côté requêtes simples).
6. **Idempotence** : le script utilise `ON CONFLICT (id) DO NOTHING` → réexécutable sans doublon.

---

### 5. Diagramme relationnel (ASCII)

```
                         ┌────────────┐
                         │  profiles  │
                         └─────┬──────┘
                 ┌─────────────┼───────────────┬───────────────┐
                 │             │               │               │
          ┌──────▼─────┐  ┌────▼──────────┐ ┌──▼───────────┐ ┌─▼────────────┐
          │ workspaces │  │permission_    │ │router_priors │ │ cost_ledger  │
          └──────┬─────┘  │  policies     │ └──────────────┘ └──────────────┘
       ┌─────────┼──────────┴──┬──────────┬───────────┐
       │         │             │          │           │
 ┌─────▼──────┐  │      ┌───────▼────┐  ┌──▼────────┐  │
 │conversation│  │      │  sessions  │  │   runs    │◄─┘ (last_run_id ↺)
 └─────┬──────┘  │      └─────┬──────┘  └────┬──────┘
       │         │            │              │
       │    ┌────┴────────────┼──────────────┼─────────────┐
       │    │                 │              │             │
 ┌─────▼────▼─┐  ┌────────────▼──┐    ┌──────▼──────┐ ┌────▼────────────┐
 │  messages  │  │ clarifications│    │ run_phases  │ │     events      │
 └─────┬──────┘  │ plans         │    └──────┬──────┘ │ (dédup id UUID, │
       │         │  └─plan_steps  │           │        │  cursor seq)    │
 ┌─────▼──────┐  │ permission_   │    ┌───────▼──────┐ └─────────────────┘
 │ tool_calls │◄─┘  requests     │    │              │
 └─────┬──────┘                  │    (FK run/phase vers tool_calls,
       │                         │     permission_requests, messages)
 ┌─────▼───────┐                 │
 │ tool_results│                 │   ═══ ANALYTIQUE (MV, lecture seule) ═══
 └─────────────┘                 │   mv_agent_perf · mv_pipeline_perf
                                 │   mv_cost_daily · mv_router_learning
   pgboss.*  (coexiste, géré par pg-boss — non modélisé)
```

---

## Conséquences

**Positif**
- Un seul moteur (Postgres) : pg-boss, OLTP et OLAP cohabitent ; fin du double moteur.
- Sessions interactives **complètes** persistées → condition de complétude §6bis remplie (rejeu, `--resume`, audit des permissions/plans).
- Socle analytique natif (MV + `numeric` pour l'argent) → métriques perf/coût fiables sans ETL externe.
- `events` durable + dédup `id` + cursor `seq` → garanties ADR-014 G1/G3/G4 portées en base.
- RLS prête pour le multi-tenant sans refactoring (workspace_id dénormalisé).

**Négatif**
- Perte du zero-config SQLite : Postgres/Supabase devient dépendance de démarrage (mitigé : Supabase local via Docker, ou instance managée).
- `workspace_id` dénormalisé partout = redondance (assumée pour RLS/perf).
- MV à rafraîchir (worker dédié) → fraîcheur analytique 5–15 min, pas temps réel.
- `events` peut grossir vite → partitionnement par mois à prévoir (>50 M lignes).
- Binding natif `better-sqlite3` retiré ; migration big-bang à exécuter en P4.

## Alternatives rejetées

- **Timeseries DB dédiée (TimescaleDB / InfluxDB) pour events & métriques** —
  rejeté : ajoute un second moteur ; le volume v2 (single-user / petite équipe)
  ne le justifie pas. Le partitionnement natif Postgres + MV suffit. (TimescaleDB
  reste une extension activable plus tard si le volume d'`events` explose.)
- **Tout-JSONB pour les events (une table fourre-tout sans normalisation)** —
  rejeté pour les entités à forte cardinalité de requêtes (run_phases, tool_calls,
  cost_ledger) : on perd index typés, contraintes, agrégats efficaces. JSONB
  conservé **uniquement** pour le contenu réellement schemaless (`payload`,
  `input`, `state`, `config`, `metadata`, `models`).
- **Type `ENUM` Postgres pour status/role/decision** — rejeté au profit de
  `text + CHECK` : ajouter une valeur d'enum PG nécessite `ALTER TYPE` (verrou,
  migration lourde) ; un CHECK se modifie plus souplement et reste portable.
- **Conserver SQLite + sidecar Postgres pour pg-boss seulement** — rejeté :
  deux sources de vérité, corrélation cross-DB impossible, complexité de backup.
- **`real`/`float` pour les coûts** — rejeté : erreurs d'arrondi cumulatives sur
  une donnée financière (budget-guard). `numeric(12,6)` obligatoire.

## Points ouverts

- **`ws_tokens`** (tokens WebSocket éphémères, ex-`sessions` ADR-015) : Postgres
  ou Redis ? Recommandation : Redis/JWT stateless, pas en base métier.
- **Embeddings / vector search** (ReasoningBank, `bank.*`) : `pgvector` dans ce
  schéma ou store séparé ? Hors périmètre ADR-017, à trancher en ADR dédiée.
- **Rétention `events`** : durée avant purge/archivage des partitions (90 j ?).
- **`mv_router_learning`** : valider la dispo de l'agrégat `last()` ou basculer
  sur `DISTINCT ON`.
- **Multi-tenant réel** : claim JWT `workspace_ids` vs table `memberships`
  (rôles/permissions par workspace) — à concevoir quand le SaaS sera activé.
