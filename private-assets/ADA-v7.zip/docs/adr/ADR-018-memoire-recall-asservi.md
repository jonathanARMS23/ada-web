# ADR-018 — Recall asservi au contenu + portée/supersession des conventions

**Date** : 2026-06-18
**Statut** : Accepté
**Décideurs** : Jonathan Arms

## Contexte

L'ablation 4 bras (cf. ADR-019) a établi que **la mémoire est le seul driver de valeur
prouvé d'ADA** (B−A = +8.3). Or la couche mémoire elle-même injectait du bruit ou
masquait des règles pertinentes. Quatre défauts audités sur le chemin store→recall :

1. Fallback TF-IDF **silencieux** quand Ollama est absent : l'orchestrateur croit avoir
   de la recherche sémantique alors qu'il n'a que du lexical dégradé.
2. Acronymes/formes équivalentes non unifiés à l'indexation (`ts` ≠ `typescript`,
   `auth` ≠ `authentication`, `TS` jeté car longueur 2) → conventions invisibles selon
   la forme du prompt.
3. Score d'injection mélangeant pertinence-contenu et récence/verdict → une entrée
   récente mais hors-sujet franchissait le seuil.
4. Conventions quasi-doublons ou contradictoires stockées et injectées côte à côte.

Un cinquième bug a été introduit puis corrigé en cours de refonte (`18fcfa9`) : gater
les conventions **globales** sur le lexique du prompt produit une liste amputée, et le
modèle ancré dessus **abandonne** la règle manquante (RLS perdu sur un prompt de schéma).

## Décision

Refondre la chaîne mémoire en cinq incréments. Détail technique : `docs/architecture-memoire.md`.

| Incrément | Décision |
|-----------|----------|
| **P1-2** | Recall sémantique via Ollama (`buildRecallBlockAsync`). Sonde Ollama avant le retrieve ; mode dégradé **observable** (stderr + `lastRecallDegraded`), jamais silencieux. `bankHealth()` expose ollama/coverage/lastRecall*. |
| **P1-1** | `tokenize()` préserve les acronymes techniques (`ACRONYMS_KEEP`) et normalise les formes équivalentes (`NORMALIZE_MAP`) **à l'indexation ET en requête**. |
| **P0-2** | `contentRelevance()` isole la pertinence-CONTENU (similarité requête↔contenu seule). C'est le **seul** signal de seuillage d'injection ; récence/verdict ne peuvent plus maquiller un hors-sujet. |
| **P0-1** | Portée des conventions : `scope:global` (injectée inconditionnellement on-topic) vs `scope:domain` (gatée sur le contenu). Défaut global (rétro-compat). |
| **P0-3** | Dédup/supersession sémantique au store : Jaccard-sujet ≥ 0.5 → last-write-wins (`archived = true`) ; polarités opposées → WARNING (arbitrage humain), sans archiver ni bloquer. |

## Alternatives rejetées

| Option | Raison du rejet |
|--------|----------------|
| Garder le fallback TF-IDF silencieux | Cache une perte de qualité sémantique invisible à l'orchestrateur |
| Gater les conventions globales sur le lexique | Anchoring négatif mesuré : règle amputée → modèle abandonne la règle (bug `18fcfa9`) |
| Classer portée/polarité via LLM au store | `storeConvention` est synchrone (seed/promote) ; un appel LLM y serait bloquant |
| Supprimer (au lieu d'archiver) les conventions superseédées | Perte d'audit/réversibilité ; `archived` exclut du recall mais conserve en base |
| Archiver automatiquement sur contradiction | Risque d'écraser une règle valide sur une saisie mal polarisée |

## Conséquences

- **+** Recall asservi au contenu : moins de bruit injecté, mode dégradé visible.
- **+** Conventions cohérentes : une seule règle active par sujet, contradictions signalées.
- **+** Robustesse lexicale : unification acronymes/formes à l'indexation.
- **−** Deux proxies lexicaux subsistent au store (classification de portée + polarité),
  assumés car `storeConvention` est synchrone. Les voies de **recall** utilisent bien la
  sémantique dense quand Ollama est up. Override `opts.scope` disponible au seed.
- **−** Dépendance Ollama pour le régime sémantique nominal (sinon dégradé observable).

## Réserve honnête

Les heuristiques de portée (`classifyConventionScope`) et de polarité (`_polarity`)
sont des regex déterministes, pas de la sémantique. Stables sur de courtes phrases-règles,
mais faillibles sur des formulations atypiques → corrigeables via `opts.scope` ou via le
WARNING de contradiction (arbitrage humain).

## Fichiers impactés

```
coordinator/bank.js          storeConvention (P0-1/P0-3), buildRecallBlockAsync (P1-2),
                             bankHealth, _assembleRecallBlock, _recallConventions
coordinator/bank-ranking.js  contentRelevance (P0-2), scoreTrajectory
coordinator/embeddings.js    tokenize + NORMALIZE_MAP / ACRONYMS_KEEP (P1-1)
docs/architecture-memoire.md doc technique détaillée
```
