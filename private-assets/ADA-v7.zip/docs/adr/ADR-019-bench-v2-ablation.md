# ADR-019 — Benchmark v2 : ablation 4 bras à scoring exécutable

**Date** : 2026-06-18
**Statut** : Accepté
**Décideurs** : Jonathan Arms

## Contexte

Le benchmark v1 (`coordinator/benchmark.js`) compare ADA à Claude Code nu, mais son
scoring reste partiellement déclaratif (grep, LLM-judge). Surtout, il n'**isolait** pas
la contribution de chaque feature d'ADA : impossible de dire si la valeur vient de la
mémoire, du routing par tier, ou de la décomposition multi-agents. La mémoire MEMORY.md
note même un résultat antérieur où ADA était PIRE en qualité/$ que le baseline nu — sans
pouvoir attribuer la cause.

Il fallait un instrument qui **attribue le ROI à chaque feature** et dont le score ne
puisse pas être contesté.

## Décision

Créer `coordinator/bench-v2.js`, isolé du v1, avec trois propriétés.

### 1. Ablation à 4 bras

Chaque bras ajoute une feature au précédent ; les deltas attribuent la valeur :

| Bras | Description | Mémoire | Routing/spécialisation | Décompo |
|------|-------------|:-------:|:----------------------:|:-------:|
| **A** naked | agent générique, sonnet, 0 mémoire | — | — | — |
| **B** ada-mémoire | A + injection conventions (recall) | ✓ | — | — |
| **C** ada-solo-route | B + agent spécialisé + tier routing | ✓ | ✓ | — |
| **D** ada-full-pipeline | C + décomposition multi-agents | ✓ | ✓ | ✓ |

**Deltas** : `B−A` = valeur mémoire · `C−B` = valeur routing/spécialisation ·
`D−C` = ROI décomposition.

Les bras A/B restent sur `sonnet` (baseline constante) pour isoler la valeur mémoire.
Les bras C/D dérivent le modèle du tier rendu par `task-classifier` via
`router.recommendModel` (tier 1→haiku, 2→sonnet, 3→opus).

`bench-v2.js` **ne spawn pas d'agents** : il fournit le HARNAIS (`plan`, `menu`) + les
SCORERS (`score`, `report`). L'orchestrateur (Claude) exécute les bras puis appelle `score`.

### 2. Scoring exécutable (probant, pas du grep)

8 catégories enregistrées ; 4 sont **câblées** (`wired`), 4 **planifiées** (`planned`,
visibles au menu mais `score()` renvoie un skip explicite).

| Catégorie | Statut | Scorer |
|-----------|--------|--------|
| `correction-reelle` | wired | **SQL** exécuté sur Postgres jetable |
| `conventions-tacites` | wired | **SQL** (savoir projet non prompté) |
| `above-threshold` | wired | **SQL** + assertions comportementales |
| `precision-recuperation` | wired | **F1 recall** réel (precision/recall/F1) |
| `qualite`, `exec-time`, `token-efficiency`, `valeur-multi-tours`, `roi-decomposition-routing` | planned | — |

- Le scorer **SQL** applique le livrable sur une base Postgres jetable, puis exécute des
  assertions live (`SELECT ... expect`). Un **scaffold Supabase** (`anon`/`authenticated`/
  `service_role`, `auth.uid()`, `moddatetime`, `workspace_members`) est appliqué d'abord :
  un SQL fidèle au stack échouerait sur un Postgres vanilla — c'est un défaut du scorer,
  pas du livrable.
- Le scorer **recall** appelle `ada bank recall`, parse les conventions retournées, et
  calcule `precision = tp/(tp+fp)`, `recall = tp/(tp+fn)`, `f1` vs un ground-truth.
- Fix `parsePsqlScalar` (`9af9b2c`) : renvoyait le tag de complétion `DO` au lieu du
  scalaire pour les assertions `DO $$..$$; SELECT` — aurait faussé toutes les assertions
  comportementales.

### 3. Instrument du seuil « above-threshold »

Les bras routing (C) et teams (D) sont censés payer **au-dessus d'un seuil** de
complexité (gros refactors, contexte XXL, vérification croisée). Ce régime n'était pas
mesuré. Définition **mesurable** retenue :

> `classifierMode = pipeline` ET `tier = 3` ET ≥ 3 sous-tâches liées ET
> ≥ 1 exigence transverse à fort cross-check.

4 tâches above-threshold scorables en dur, avec assertions comportementales **live**
(UPDATE/DELETE rejetés, fuite RLS via FK, idempotence) :
`at-orders-fulfillment-schema`, `at-ledger-immutable-double-entry`,
`at-rls-cross-tenant-isolation`, `at-audit-soft-delete-trigger`. Pilote : le scorer
discrimine (single-pass 60-67 vs complet 100).

## Conclusion stratégique (état des mesures)

- **Mémoire = seul driver de valeur prouvé** : `B−A = +8.3` _(mesure antérieure du
  2026-06-18, commit `3b085af` — agrégat sur catégories mixtes ; conservée pour la
  traçabilité, remplacée par le run ciblé ci-dessous)_.
- **Routing n'apporte rien sous le seuil** : `C−B = 0`.
- **Teams/décomposition n'apportent rien sous le seuil** : `D−C = 0`.
- **Régime above-threshold = non encore mesuré** : l'instrument est prêt (4 tâches
  câblées, seuil défini), mais le run sur agents réels reste à faire.

**Implication produit** : la **décomposition par défaut = solo** (1 agent au tier
recommandé). Le fan-out multi-agents reste réservé aux cas réellement above-threshold,
dont le ROI est à confirmer par le run agents.

### Run conventions-tacites — 2026-08-03

Run ciblé sur la seule catégorie `conventions-tacites` (3 tâches :
`sql-invoices-implicit`, `sql-projects-implicit`, `sql-orders-outbox-divergent`),
bras A vs B, modèle `sonnet` constant.

| Bras | Score | Delta |
|------|:-----:|:-----:|
| **A** naked | 87.7 | — |
| **B** ada-mémoire | 100 | **+12.3** |

Le delta agrégé est le résultat le moins intéressant. **Le constat qualitatif est le
vrai résultat** : `sonnet` connaît déjà nativement les conventions SaaS standard. Le
bras A, sans aucune aide, a produit correctement `uuid` PK, `workspace_id` et
`timestamps` sur les 3 tâches, sans exception — ainsi que la table `projects` complète.
Sur ces assertions, `A = B = 100 %`.

L'écart se concentre **exclusivement** sur les assertions non-standard :

| Assertion non-standard | A (naked) | B (mémoire) |
|------------------------|:---------:|:-----------:|
| RLS activé + policies sur `invoices` | 0 % (RLS oublié) | 100 % |
| Convention **divergente** outbox transactionnel sur `orders` | 0 % (clé d'idempotence — solution valide en soi, mais pas la convention du projet) | 100 % (table outbox + triggers conformes) |
| Conventions standard (`uuid` / `workspace_id` / `timestamps` / `projects`) | 100 % | 100 % |

**Implication pitch commercial** : ne **pas** vendre « la mémoire améliore tout de X % » —
c'est trompeur, un modèle moderne connaît déjà le SaaS générique et un client technique
qui teste lui-même le constatera immédiatement. Vendre : **« la mémoire élimine les
erreurs sur les conventions non-standard ou contre-défaut spécifiques au projet (RLS,
patterns divergents type outbox), là où un modèle nu échoue systématiquement. »** Plus
précis, plus vrai, défendable en démo.

**Fiabilité de la mesure** : 2 bugs de scoring ont été corrigés dans
`coordinator/bench-v2.js` en cours de run (`extractReferencedTables` / `reCreate` et la
génération de stubs ne géraient pas le préfixe de schéma SQL — `public.table`,
`auth.users`). Un livrable correct mais schema-qualifié scorait 0 par accident du
harnais, pas par défaut du livrable : sans correction, le run affichait un faux `B = 0`,
soit une régression apparente de la mémoire. Bugs corrigés et couverts (+17 tests, tous
verts) — la mesure ci-dessus est fiable.

### Run above-threshold — natif vs pipeline ADA — 2026-08-04/06

Avant ce run, un audit du tier-routing (`task-classifier.js`/`router.js`) a trouvé et
corrigé 11 bugs réels : sur-déclenchement du classifieur (ponctuation seule = signal
pipeline, mots-clés trop larges type `\block\b` matchant un nom de fichier, `production`
capturant `hotfix` avant `db-migrate`…), et côté routeur, Thompson Sampling arbitrait
`nestjs`/`drf` comme des variantes substituables au lieu d'un choix de stack déterministe
(jusqu'à 46 % de dérive vers le mauvais framework à priors égaux), l'apprentissage
adaptatif n'était réellement consulté que sur 1 phase pipeline sur ~50, le decay EWC
protégeait davantage les priors anciens au lieu de moins (effet inversé), et un
estimateur prédictif était mort par une faute de frappe (`loadRouterState` inexistant).
Corrigés avant de mesurer, pour ne pas polluer la comparaison ci-dessous avec du bruit
de classification (voir commits `2e5250f`, `1163f09`).

Run sur les 4 tâches `above-threshold` (jamais exécutées sur agents réels avant
aujourd'hui), deux bras :
- **natif** : `ada classify` (pour le tier) → **1 seul agent**, libre d'utiliser l'outil
  Agent pour déléguer à sa discrétion (aucune décomposition imposée).
- **ADA-pipeline** : `ada classify` → pipeline `migration` existant (**3 agents** :
  design → safety → apply, séquentiels).

| Tâche | Natif (1 agent) | ADA-pipeline (3 agents) |
|-------|:---------------:|:-----------------------:|
| at-orders-fulfillment-schema | 100 | 100 |
| at-ledger-immutable-double-entry | 100 | 100 |
| at-rls-cross-tenant-isolation | 100 | 100 |
| at-audit-soft-delete-trigger | 100 | 100 |

**⚠️ CORRECTION (2026-08-06, ADR-021)** : ce tableau reflète le scorer d'origine, qui
exécutait toutes ses assertions en superuser Postgres — un angle mort qui rendait
invisibles précisément les bugs que la phase safety du pipeline corrigeait. Une revue
adversariale du protocole de mesure (ADR-021) a conduit à durcir les assertions pour
tester sous le rôle `authenticated` réel. Sous ce test plus strict, **`at-audit-soft-
delete-trigger` bras NATIF chute à 92/100** (vue `active_contacts` sans
`security_invoker=true`, fuite cross-tenant réelle) — le bras PIPELINE reste 100/100. Les
3 autres tâches confirment 100/100 des deux côtés sous le nouveau régime. **L'égalité
parfaite ci-dessous ne tient donc plus telle quelle** — voir ADR-021 pour le détail et la
réserve méthodologique (N=1, asymétrie de scrutin entre bras) qui empêche encore de
généraliser ce résultat en conclusion produit.

**Égalité parfaite sur le score automatisé d'origine (100/100 des deux côtés, 4/4 tâches)
— mais pas une égalité de fond, comme la correction ci-dessus le confirme.** Trois
observations qualitatives que le score ne capture pas :

1. **Coût** : le bras ADA-pipeline consomme ~3× plus d'appels agent pour le même score
   automatisé.
2. **Le bras pipeline a pris plus de risques, puis les a corrigés lui-même** : sur les 4
   tâches, l'agent "design" a systématiquement choisi l'architecture Supabase la plus
   ambitieuse (`auth.jwt()`, `service_role`), qui a introduit à chaque fois de vrais bugs
   de sécurité (trigger d'outbox cassé par défaut `SECURITY INVOKER` + RLS, vue
   `active_contacts` contournant la RLS de sa table de base, claim JWT falsifiable via
   `user_metadata` au lieu d'`app_metadata`, `GRANT` manquants rendant une policy jamais
   évaluée). La phase "safety" (`reviewer`, tier 3) les a trouvés et corrigés à chaque
   fois, avec des reviews d'une rigueur élevée (une même testée en exécution réelle contre
   Postgres, 14/14 assertions). Le bras natif a choisi des architectures plus simples
   (`current_setting` de session) qui évitaient nativement une bonne part de ces pièges,
   sans jamais se tromper sur les points testés — et sans phase de review dédiée.
3. **Angle mort du scorer** : les assertions ne testent que le SQL de schéma exécuté en
   tant que propriétaire/`service_role`, jamais le comportement sous le rôle
   `authenticated` réel — c'est précisément le régime où la plupart des bugs trouvés par
   la phase safety se manifestent (RLS bypass, policy jamais atteinte). La valeur ajoutée
   de la phase safety est donc réelle mais invisible dans les deux scores ci-dessus ; ce
   n'est pas une preuve d'absence de différence, c'est un trou de couverture du scorer.

**Implication produit** : sur ce lot de tâches, le pipeline rigide n'apporte pas de gain
de score mesurable (cohérent avec la conclusion stratégique ci-dessus) — mais son coût 3×
achète une profondeur de revue sécurité réelle qu'un scorer plus strict (testant sous
`authenticated`, pas `service_role`) pourrait révéler. Décision produit non tranchée ici :
la question n'est pas technique (le pipeline « marche »), c'est un choix de positionnement
commercial — vendre le pipeline comme option de durcissement sécurité payante, pas comme
gain de qualité générique.

## Alternatives rejetées

| Option | Raison du rejet |
|--------|----------------|
| Étendre le benchmark v1 | Couplage avec le scoring déclaratif ; v2 isolé évite la régression |
| Scoring par grep / LLM-judge seul | Contestable ; on veut un score exécuté (SQL réel, F1 réel) |
| Scorer sur Postgres vanilla | Pénalise injustement le SQL fidèle au stack Supabase |
| Conclure le ROI teams sans run above-threshold | Le régime n'est pas mesuré ; conclusion non fondée |

## Conséquences

- **+** Attribution feature-par-feature du ROI, scorée par exécution.
- **+** Seuil above-threshold devenu mesurable (plus un angle mort).
- **−** Le verdict teams/routing est borné au **régime sous le seuil** ; au-dessus,
  l'instrument existe mais le run agents réels n'a pas encore tourné.
- **−** Dépendance Postgres + scaffold Supabase pour les scorers SQL.

## Fichiers impactés

```
coordinator/bench-v2.js          harnais (plan/menu) + scorers (score/report) 4 bras
benchmarks/v2/tasks-v2.json      12 tâches (4 catégories wired)
benchmarks/v2/results-v2.json    résultats persistés
coordinator/benchmark.js         baseline équipe naïve + scoring conventions tacites (v1)
```
