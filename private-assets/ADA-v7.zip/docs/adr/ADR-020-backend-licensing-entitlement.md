# ADR-020 — Backend de licensing par siège (entitlement-only)

**Date** : 2026-08-03
**Statut** : **Rejeté** (2026-08-03, même jour — voir addendum ci-dessous)
**Décideurs** : Jonathan Arms
**Contexte amont** : audit commercial-readiness 2026-07-31 · ADR-015 (ada-api SQLite) ·
ADR-016 (control-plane protocol) · ADR-017 (schéma PostgreSQL)

---

## Addendum — rejet du modèle économique (2026-08-03)

Cet ADR proposait un backend d'entitlement par siège avec abonnement Stripe, tokens
JWT à durée de vie, comptage d'appareils et logique de grâce/dunning. **Ce modèle est
rejeté** : il correspondait à une hypothèse SaaS par abonnement qui ne reflète pas le
modèle économique réel.

**Modèle économique réel (posé explicitement par le décideur)** :
- Vente **ciblée** à des clients choisis (pas un canal self-service, pas de volume).
- Licence **perpétuelle** : le client paie une fois, possède le produit **à vie**.
- **Aucune restriction d'usage après vente** : le client peut l'installer sur autant
  d'appareils qu'il veut, le partager dans son équipe, etc. — hors de portée du produit.
- Conséquence directe et non négociable : **le produit ne doit contenir AUCUNE
  logique de gestion du modèle économique** — pas de vérification d'entitlement, pas
  de token, pas de comptage de sièges/appareils, pas d'appel réseau de licensing, pas
  de notion de compte/abonnement/statut de paiement dans le code.

Toutes les décisions O1/O3/O4/O5/O9 (§7) sont donc **sans objet** — elles supposaient
une logique d'enforcement qui n'existe plus. Le modèle de données (§1), le token
d'entitlement (§2), la facturation Stripe récurrente (§3-4) sont **obsolètes dans leur
ensemble**.

**Ce qui reste effectivement nécessaire pour vendre** (hors du produit lui-même) :
- Un moyen de livrer le produit au client (accès au dépôt privé / paquet — déjà couvert
  par le chantier packaging installeur, livré séparément, cf.
  `docs/RAPPORT-packaging-installeur-2026-08-03.md`).
- Un encaissement ponctuel (facture/paiement one-shot — mécanisme de vente classique,
  hors scope technique d'ADA, pas un système à construire dans le produit).

**Aucun développement de backend n'est donc justifié pour l'instant.** Si un besoin de
suivi commercial (qui a acheté, quand) émerge, ce serait un outil interne de suivi
(tableur/CRM léger), jamais un composant embarqué dans ADA qui vérifie ou restreint quoi
que ce soit côté client.

---

## Contexte (obsolète — conservé pour traçabilité de la décision initiale)

ADA est un **installeur** : il configure Claude Code (agents, skills, hooks, mémoire,
orchestration) sur la machine de chaque développeur. Il n'y a pas de plan de données
hébergé, pas de multi-tenant applicatif, pas d'exécution serveur. Le modèle commercial
retenu est une **licence propriétaire par siège**, vendue à des entreprises pour équiper
leurs équipes.

Il manque une seule brique pour vendre : savoir **qui a le droit de faire tourner `ada`**,
et facturer le nombre de sièges. Rien d'autre.

### Contrainte fondamentale, non négociable

**ADA reste 100 % BYOK et client-side.** Le backend de licensing NE DOIT PAS devenir un
tenant de données. Aucune trajectoire ReasoningBank, aucun code, aucun prompt, aucun
fichier, aucune donnée métier client ne transite par ce service. Il gère uniquement
l'**entitlement** : droit d'usage, comptage de sièges, statut d'abonnement, expiration.

Cette contrainte est ce qui a manqué au pitch SaaS initial (« orchestrateur multi-agents
hébergé »), dont l'audit a montré qu'il ne tenait pas économiquement : proxifier les
appels LLM aurait fait porter au vendeur un coût variable indexé sur l'usage client, sans
marge. Le présent ADR **verrouille le périmètre** pour empêcher ce glissement de revenir
par la porte de service.

### État du code existant (vérifié, pas de mémoire)

| Croyance | Réalité vérifiée |
|---|---|
| « Le repo a déjà une intégration Stripe réutilisable » | **Faux.** `grep -rli stripe --include=*.ts --include=*.js` hors `node_modules`/tests : **0 fichier d'implémentation**. Le seul artefact Stripe est un **générateur de code**, `.claude/skills/nestjs/create-stripe-module.md:1-109` (template `StripeService` + `StripeWebhookController`), consommé par `.claude/commands/saas-billing.md:27`. C'est une skill que l'installeur distribue aux clients, **pas** du code ADA. Rien à réutiliser, tout à écrire. |
| « `ada-api-nest/` peut héberger le module licensing » | **Faux, et dangereux.** `ada-api-nest/src/config/env.schema.ts:10` fixe `HOST` à `127.0.0.1` : ce service tourne **sur la machine du développeur** et sert l'UI locale. Y ajouter le licensing embarquerait les credentials de la base de licences chez chaque client. |

Ce qui **est** réutilisable de `ada-api-nest/`, comme *patron* et non comme dépendance :
`src/auth/jwt.service.ts:29-70` (sign/verify), `src/persistence/migrate-cli.ts` +
`src/persistence/migrations/*.sql` (migrations SQL numérotées), `src/config/env.schema.ts`
(validation d'env par Zod), `src/persistence/database.service.ts:53` (`pg.Pool`).

---

## Options considérées

### Option A — Vérification en ligne à chaque lancement (call-home)

Le CLI appelle `POST /v1/check` à chaque invocation de `ada`.

**Avantages** : révocation immédiate ; comptage de sièges exact ; anti-partage simple.
**Inconvénients** : latence réseau sur **chaque** commande (ADA est invoqué des dizaines de
fois par jour) ; ADA inutilisable hors ligne (avion, VPN d'entreprise, air-gap) ; une panne
du service de licensing bloque tous les clients simultanément — risque de réputation
disproportionné pour un outil de productivité ; le backend voit la fréquence d'usage réelle,
ce qui commence à ressembler à de la télémétrie intrusive.
**Coût** : service à haute disponibilité (SLA implicite 99,9 %), donc coûteux à opérer.

### Option B — Token d'entitlement signé, vérifié hors ligne, rafraîchi en arrière-plan

Le backend émet un **jeton signé Ed25519** (TTL court) à l'activation. Le CLI vérifie la
signature **localement** à chaque lancement (aucun réseau) et ne contacte le backend qu'en
tâche de fond, au plus une fois par 24 h.

**Avantages** : zéro latence sur le chemin chaud ; fonctionne hors ligne ; une panne backend
n'a aucun effet visible pendant plusieurs jours ; empreinte de télémétrie minimale (un appel
par jour et par siège) ; le backend n'a besoin que d'une disponibilité ordinaire.
**Inconvénients** : la révocation n'est pas immédiate (latence = TTL du jeton) ; il faut gérer
la rotation de clé de signature pour des clients déjà installés ; horloge locale manipulable.
**Coût** : un service à faible trafic (N sièges × 1 requête/jour), hébergeable sur une instance
unique + Postgres managé.

### Option C — Licence offline pure (fichier de clé perpétuel, aucun backend)

**Avantages** : coût opérationnel nul.
**Inconvénients** : impossible de révoquer, impossible de compter les sièges réellement
utilisés, impossible d'arrêter le service à l'expiration d'un abonnement — donc incompatible
avec un modèle par abonnement récurrent ; incompatible avec Stripe Billing.
**Coût** : nul en infra, élevé en revenu perdu.

---

## Décision

**Option B retenue.** Un service hébergé **nouveau et séparé**, `ada-licensing`, distinct de
`ada-api-nest/` (qui reste local à la machine du développeur). Périmètre : entitlement +
facturation par siège. Rien d'autre.

### Justification

Le critère décisif est **le coût d'une panne**. Un développeur bloqué en plein travail par un
service de licensing indisponible est un incident qui coûte, en support et en confiance, bien
plus que les quelques jours d'usage non licencié que l'Option A aurait empêchés. L'Option B
transforme une panne de licensing en non-événement.

Le critère secondaire est **la cohérence avec la promesse produit**. ADA se vend sur
« BYOK, votre code ne sort jamais de votre machine ». Un call-home synchrone à chaque commande
contredit visiblement cette promesse, même s'il ne transporte aucune donnée. L'Option B est
défendable en audit sécurité client : un appel par jour, un identifiant de siège, une empreinte
de machine hachée, rien d'autre.

---

## 1. Modèle de données

### Note explicite : ce n'est PAS un tenant applicatif

La convention projet « `workspace_id` sur toutes les tables métier SaaS » (CLAUDE.md)
**ne s'applique pas ici**, et cette dérogation est délibérée.

- Dans un SaaS multi-tenant, `workspace_id` isole les **données métier** d'un client des
  données d'un autre. C'est une frontière de confidentialité.
- Ici, `account_id` désigne une **contrepartie de facturation** — une entreprise qui a acheté
  N sièges. Il n'y a aucune donnée métier client dans cette base : ni code, ni prompt, ni
  mémoire, ni nom de projet. `account_id` est une clé de regroupement commercial, pas une
  frontière de confidentialité applicative.
- Conséquence pratique : **pas de RLS Supabase ici**, pas de `workspace_members`, pas de
  `auth.uid()`. L'autorisation se fait au niveau applicatif (le JWT admin porte un
  `account_id`, tout accès est scopé par le repository). Ajouter du RLS donnerait la fausse
  impression que ce service héberge des données clientes.

Les autres conventions s'appliquent **intégralement** : `uuid` PK, `created_at`/`updated_at`
timestamptz, montants en **entiers de minor units** suffixés `_cents`, **soft-delete** via
`deleted_at` (jamais de `DELETE` physique), **outbox transactionnel** sur toute mutation,
pagination **keyset** sur toutes les listes.

### Schéma

```sql
CREATE EXTENSION IF NOT EXISTS pgcrypto;   -- gen_random_uuid()
CREATE EXTENSION IF NOT EXISTS citext;     -- emails insensibles à la casse

-- Réutilisé d'ADR-017 § Conventions communes
CREATE OR REPLACE FUNCTION set_updated_at() RETURNS trigger AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$ LANGUAGE plpgsql;
```

#### `accounts` — l'entreprise cliente

```sql
CREATE TYPE account_status AS ENUM ('trial', 'active', 'past_due', 'suspended', 'canceled');

CREATE TABLE accounts (
  id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_name    text        NOT NULL,
  billing_email        citext      NOT NULL,
  status               account_status NOT NULL DEFAULT 'trial',

  seats_purchased      integer     NOT NULL DEFAULT 0 CHECK (seats_purchased >= 0),
  -- seats_assigned n'est PAS stocké : dérivé par COUNT sur seats (voir § Comptage)
  max_devices_per_seat smallint    NOT NULL DEFAULT 3 CHECK (max_devices_per_seat BETWEEN 1 AND 10),

  -- Clé de licence : JAMAIS stockée en clair. Le client la voit une seule fois à l'émission.
  license_key_hash     bytea       NOT NULL,             -- SHA-256(pepper || key)
  license_key_prefix   text        NOT NULL,             -- 8 car. affichables : "ADA-7F3A…"
  license_key_rotated_at timestamptz,

  -- Miroir Stripe (Stripe reste la source de vérité — voir § Facturation)
  stripe_customer_id     text UNIQUE,
  stripe_subscription_id text UNIQUE,
  trial_ends_at          timestamptz,
  current_period_start   timestamptz,
  current_period_end     timestamptz,
  canceled_at            timestamptz,

  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now(),
  deleted_at  timestamptz                              -- soft-delete obligatoire
);
CREATE UNIQUE INDEX accounts_license_key_hash_uq ON accounts (license_key_hash) WHERE deleted_at IS NULL;
CREATE INDEX accounts_keyset_idx ON accounts (created_at DESC, id DESC) WHERE deleted_at IS NULL;
CREATE TRIGGER accounts_set_updated_at BEFORE UPDATE ON accounts
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
```

#### `seats` — un siège = une personne

```sql
CREATE TYPE seat_status AS ENUM ('allocated', 'active', 'revoked');

CREATE TABLE seats (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id   uuid NOT NULL REFERENCES accounts(id),
  assignee_email citext NOT NULL,                       -- seule PII stockée, nécessaire à l'attribution
  status       seat_status NOT NULL DEFAULT 'allocated',
  activated_at timestamptz,
  last_seen_at timestamptz,                             -- date seule (granularité jour), pas d'historique
  revoked_at   timestamptz,
  revoked_reason text,

  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  deleted_at timestamptz
);
-- Un email = au plus un siège vivant par compte
CREATE UNIQUE INDEX seats_account_email_uq
  ON seats (account_id, assignee_email) WHERE deleted_at IS NULL;
CREATE INDEX seats_keyset_idx
  ON seats (account_id, created_at DESC, id DESC) WHERE deleted_at IS NULL;
CREATE TRIGGER seats_set_updated_at BEFORE UPDATE ON seats
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
```

#### `seat_devices` — machines liées à un siège

```sql
CREATE TABLE seat_devices (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  seat_id      uuid NOT NULL REFERENCES seats(id),
  -- Empreinte calculée CLIENT-SIDE puis hachée avec un sel par compte.
  -- Le backend ne reçoit ni hostname brut, ni numéro de série, ni adresse MAC.
  device_fingerprint_hash bytea NOT NULL,
  device_label text,                                    -- libellé libre saisi par le dev, optionnel
  os_family    text,                                    -- 'darwin' | 'linux' | 'win32' — support uniquement
  first_seen_at timestamptz NOT NULL DEFAULT now(),
  last_seen_at  timestamptz NOT NULL DEFAULT now(),
  revoked_at    timestamptz,

  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  deleted_at timestamptz
);
CREATE UNIQUE INDEX seat_devices_uq
  ON seat_devices (seat_id, device_fingerprint_hash) WHERE deleted_at IS NULL;
```

#### `entitlement_tokens` — jetons émis (pour la révocation, pas pour la vérification)

```sql
CREATE TABLE entitlement_tokens (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  seat_id    uuid NOT NULL REFERENCES seats(id),
  device_id  uuid NOT NULL REFERENCES seat_devices(id),
  jti        uuid NOT NULL UNIQUE,                      -- claim jti du JWT émis
  key_id     text NOT NULL,                             -- kid de la clé de signature (rotation)
  issued_at  timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL,
  revoked_at timestamptz,

  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  deleted_at timestamptz
);
CREATE INDEX entitlement_tokens_seat_idx ON entitlement_tokens (seat_id, issued_at DESC);
```

> Le jeton n'est **jamais** vérifié en base au moment de l'usage — la vérification est purement
> cryptographique et locale. Cette table sert au **refus de renouvellement** et à l'audit.

#### `invoices` — miroir Stripe, montants en entiers

```sql
CREATE TABLE invoices (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id        uuid NOT NULL REFERENCES accounts(id),
  stripe_invoice_id text NOT NULL UNIQUE,
  status            text NOT NULL,                      -- draft|open|paid|uncollectible|void
  currency          char(3) NOT NULL,                   -- ISO 4217
  amount_due_cents  bigint  NOT NULL,                   -- entiers, JAMAIS de NUMERIC/float
  amount_paid_cents bigint  NOT NULL DEFAULT 0,
  seats_billed      integer NOT NULL,
  period_start      timestamptz NOT NULL,
  period_end        timestamptz NOT NULL,
  issued_at         timestamptz NOT NULL,

  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  deleted_at timestamptz
);
CREATE INDEX invoices_keyset_idx
  ON invoices (account_id, created_at DESC, id DESC) WHERE deleted_at IS NULL;
```

#### `outbox` — convention projet, obligatoire

```sql
CREATE TABLE outbox (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  aggregate_type text NOT NULL,                         -- 'account' | 'seat' | 'invoice'
  aggregate_id   uuid NOT NULL,
  event_type     text NOT NULL,                         -- 'seat.activated', 'account.suspended', …
  payload        jsonb NOT NULL,
  occurred_at    timestamptz NOT NULL DEFAULT now(),
  published_at   timestamptz,
  attempts       smallint NOT NULL DEFAULT 0,

  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  deleted_at timestamptz
);
CREATE INDEX outbox_unpublished_idx ON outbox (occurred_at) WHERE published_at IS NULL;
```

Toute mutation (activation de siège, révocation, changement de statut d'abonnement) écrit sa
ligne d'outbox **dans la même transaction**. Aucun appel direct au bus, à l'emailing ou à
Stripe depuis un service : c'est un relais qui dépublie l'outbox.

> **YAGNI assumé** : dans un service de cette taille, l'outbox pourrait sembler surdimensionné.
> Il est conservé pour deux raisons non-cosmétiques : (a) c'est une convention projet, (b) c'est
> exactement le cas où le dual-write fait mal — « révoquer le siège **et** envoyer l'email
> **et** décrémenter la quantité Stripe » sans outbox produit des états incohérents lors d'une
> panne partielle.

#### `stripe_events` — idempotence des webhooks

```sql
CREATE TABLE stripe_events (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  stripe_event_id text NOT NULL UNIQUE,                 -- 'evt_…' — clé d'idempotence
  event_type      text NOT NULL,
  processed_at    timestamptz,
  payload         jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  deleted_at timestamptz
);
```

### Comptage des sièges

`seats_assigned` n'est **pas** une colonne dénormalisée. Il est dérivé :

```sql
SELECT count(*) FROM seats
 WHERE account_id = $1 AND deleted_at IS NULL AND status <> 'revoked';
```

L'allocation d'un siège s'exécute dans une transaction avec
`SELECT … FROM accounts WHERE id = $1 FOR UPDATE`, puis contrôle
`count < seats_purchased`. Sans ce verrou, deux activations concurrentes dépassent le quota.
Un compteur dénormalisé aurait le même besoin de verrou **plus** un risque de dérive : rien
à gagner à ce volume.

---

## 2. Vérification d'entitlement côté client

### Le jeton

JWT signé **EdDSA / Ed25519** (`alg: EdDSA`), TTL **7 jours**, claims :

```jsonc
{
  "iss": "https://licensing.<domaine>",
  "sub": "<seat_id>",              // siège
  "aud": "ada-cli",
  "jti": "<uuid>",                 // corrélé à entitlement_tokens.jti
  "kid": "2026-08-a",              // dans l'en-tête — rotation de clé
  "acc": "<account_id>",
  "dev": "<device_id>",
  "plan": "team",
  "feat": ["orchestration", "bank", "agents"],   // capacités activables
  "iat": 1754179200,
  "nbf": 1754179200,
  "exp": 1754784000
}
```

Aucun nom de projet, aucun chemin, aucune métrique d'usage. Le jeton est stocké dans
`~/.ada/entitlement.json`, permissions `0600`.

**La clé publique de vérification est embarquée dans le paquet ADA** ; la clé privée ne quitte
jamais le backend (KMS ou secret manager). Un endpoint JWKS public permet au CLI de découvrir
une nouvelle clé lors d'une rotation — c'est pourquoi `kid` est obligatoire **dès la v1** (voir
§ Décisions irréversibles).

### Les trois états, et le chemin chaud

À **chaque** invocation de `ada`, le CLI fait uniquement de la crypto locale (< 1 ms, zéro I/O
réseau) :

| État | Condition | Comportement |
|---|---|---|
| **VALID** | signature OK, `now < exp` | ADA démarre normalement, silencieux |
| **GRACE** | signature OK, `exp < now ≤ exp + 14 j` | ADA démarre **+ un avertissement sur stderr** (« licence à renouveler, N jours restants ») |
| **EXPIRED** | `now > exp + 14 j`, ou signature invalide, ou aucun jeton | ADA **refuse** de démarrer et affiche la commande `ada activate` |

Le rafraîchissement est **hors du chemin chaud** : au plus **une fois par 24 h**, en processus
détaché, timeout 3 s, échec silencieux. Un `ada` ne bloque jamais sur le réseau.

### Fail-open — décision et limites

**Décision : fail-open sur l'échec de *renouvellement*, fail-closed sur l'absence de jeton
valide initial.**

Justification :

- Un développeur en plein travail ne doit jamais être arrêté par une panne d'un service qui ne
  lui rend, à cet instant, aucun service. Le rapport bénéfice/risque est asymétrique : bloquer
  100 développeurs payants pour empêcher 1 usage frauduleux est un mauvais échange.
- Le fail-open est **borné** : 7 j de TTL + 14 j de grâce = 21 jours maximum d'inertie. Ce n'est
  pas un fail-open illimité, c'est un différé de révocation.
- Un jeton jamais obtenu, ou de signature invalide, n'est **pas** couvert : on ne « fail-open »
  que sur ce qui a déjà été légitimement accordé. Un client qui n'a jamais payé ne démarre pas.

Limites acceptées et documentées :

- **Révocation différée jusqu'à 21 jours.** Un employé licencié le jour de l'émission d'un jeton
  garde ADA fonctionnel 21 jours. Acceptable : ADA n'ouvre l'accès à aucune donnée d'entreprise —
  c'est un outil local, avec la clé API du dev.
- **Manipulation d'horloge.** Reculer l'horloge système prolongerait la grâce. Mitigation
  partielle : le CLI persiste dans `entitlement.json` le plus haut horodatage jamais observé et
  refuse de démarrer si l'horloge courante est antérieure de plus de 24 h. C'est un ralentisseur,
  pas une barrière — toute protection client-side est contournable par un adversaire déterminé,
  et prétendre l'inverse serait de la sécurité de théâtre. Le vrai moyen de recours contre la
  fraude délibérée en B2B est **contractuel**, pas technique.

---

## 3. Stack

| Couche | Choix | Justification |
|---|---|---|
| Runtime | **NestJS 10 + Fastify** | Aligné sur `ada-api-nest/package.json:19-24` — même version, mêmes patterns, une seule compétence à maintenir |
| Base | **PostgreSQL 16** (managé : Neon / RDS / Supabase Postgres) | Convention projet ; volume trivial, un plan de base suffit |
| Accès données | `pg.Pool` + SQL explicite + migrations numérotées | Copie du patron `ada-api-nest/src/persistence/migrate-cli.ts` + `migrations/*.sql` ; pas d'ORM lourd pour 7 tables |
| Config | **Zod** sur l'env | Patron `ada-api-nest/src/config/env.schema.ts` |
| JWT admin | patron `ada-api-nest/src/auth/jwt.service.ts:29-70` | Sessions du portail admin (HS256, court) — **distinct** du jeton d'entitlement (EdDSA, à vérification hors ligne) |
| Signature entitlement | **Ed25519**, clé privée en secret manager | Vérifiable hors ligne, clé publique de 32 octets embarquable dans le CLI |
| Facturation | **Stripe Billing — Subscriptions à quantité licenciée** | Aucune donnée de carte ne touche notre infra |
| Déploiement | conteneur unique + Postgres managé | Trafic = N sièges × 1 req/j ; une instance suffit largement, ne pas sur-architecturer |
| TypeScript | `strict: true`, **aucun `any`** | Convention projet |

**Ce service est un nouveau déployable**, pas un module d'`ada-api-nest/`. Voir § Contexte :
`ada-api-nest` écoute sur `127.0.0.1` chez le client.

### Facturation Stripe — modèle

- **Un `Customer` Stripe par `account`**, une `Subscription` avec un `SubscriptionItem` dont la
  `quantity` = `seats_purchased`. Tarification **par siège licencié**, pas d'usage metering :
  le revenu est prévisible et ne dépend pas de la consommation LLM du client (qui, en BYOK, ne
  nous coûte rien et ne doit rien nous rapporter).
- **Augmenter les sièges** → mise à jour de la `quantity`, proratisation gérée par Stripe.
  **Diminuer** → prise d'effet en fin de période (`proration_behavior: 'none'`), pour éviter
  l'aller-retour d'abus mensuel.
- **Stripe est la source de vérité** de l'état d'abonnement ; Postgres en est une **projection**
  alimentée par webhooks. En cas de divergence, une tâche de réconciliation quotidienne
  re-synchronise depuis Stripe. Ne jamais laisser une écriture locale contredire Stripe.
- Webhooks consommés : `checkout.session.completed`, `customer.subscription.updated`,
  `customer.subscription.deleted`, `invoice.paid`, `invoice.payment_failed`.
- Règles impératives, reprises de `.claude/skills/nestjs/create-stripe-module.md:105-108` :
  signature vérifiée systématiquement, **raw body** sur la route webhook (pas de parser JSON),
  idempotence via `stripe_events.stripe_event_id`.
- Aucun secret dans le code : `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`,
  `LICENSE_KEY_PEPPER`, clé privée Ed25519 — tous en variables d'environnement validées par Zod,
  jamais commités.

---

## 4. Contrat d'API minimal

Toutes les listes utilisent la **pagination keyset** (curseur sur `created_at, id`), réponse
`{ data, nextCursor }`. Tout `DELETE` est un `UPDATE SET deleted_at = now()`.

### Public — CLI (pas de session, authentifié par clé de licence ou jeton)

| Méthode | Route | Rôle |
|---|---|---|
| `POST` | `/v1/activate` | `{ license_key, assignee_email, device_fingerprint_hash, os_family, device_label? }` → `{ entitlement_token, expires_at }`. Vérifie le hash de clé, que l'email est un siège alloué, que le quota d'appareils n'est pas dépassé. Rate-limité agressivement. |
| `POST` | `/v1/entitlement/refresh` | `Authorization: Bearer <jeton actuel, éventuellement expiré>` → nouveau jeton. Refuse si le siège est révoqué, le compte suspendu/annulé, ou le `jti` révoqué. |
| `POST` | `/v1/entitlement/release` | Libère l'appareil courant (changement de machine). Soft-delete de `seat_devices`. |
| `GET` | `/.well-known/ada-licensing-jwks.json` | Clés publiques de vérification (`kid` → clé). Permet la rotation sans réinstaller. |
| `GET` | `/v1/health` | Sonde de disponibilité. |

### Admin — portail de l'entreprise cliente (JWT de session, scopé `account_id`)

| Méthode | Route | Rôle |
|---|---|---|
| `GET` | `/v1/accounts/me` | Compte, statut, `seats_purchased`, `seats_assigned`, période courante. |
| `GET` | `/v1/accounts/me/seats?cursor=&limit=` | Liste keyset des sièges. |
| `POST` | `/v1/accounts/me/seats` | `{ assignee_email }` → alloue un siège. `409` si quota atteint. |
| `DELETE` | `/v1/accounts/me/seats/:id` | Révoque (soft-delete + `status=revoked`), révoque les jetons associés, écrit l'outbox. |
| `GET` | `/v1/accounts/me/seats/:id/devices` | Appareils du siège (empreintes hachées + libellés). |
| `DELETE` | `/v1/accounts/me/seats/:id/devices/:deviceId` | Délie une machine (dev qui change de laptop). |
| `GET` | `/v1/accounts/me/invoices?cursor=&limit=` | Miroir des factures, montants en `_cents`. |
| `POST` | `/v1/accounts/me/billing-portal` | → URL de session du portail Stripe (changement de quantité, moyen de paiement, factures). Aucune UI de paiement maison. |
| `POST` | `/v1/accounts/me/license-key/rotate` | Régénère la clé (fuite suspectée). Invalide les activations futures, pas les jetons en cours. |

### Système

| Méthode | Route | Rôle |
|---|---|---|
| `POST` | `/v1/webhooks/stripe` | Raw body, signature vérifiée, idempotent. |

---

## 5. Périmètre EXCLU — ce que ce backend ne fera jamais

Cette section est normative. Toute proposition d'ajout doit passer par un nouvel ADR qui
**supersede** celui-ci.

- ❌ **Aucun proxy d'appel LLM.** Jamais de relais Anthropic/OpenAI/autre. ADA reste BYOK ; le
  coût variable du modèle reste chez le client. C'est le point qui a coulé le pitch SaaS initial.
- ❌ **Aucun stockage de clé API client.** La clé Anthropic du développeur ne quitte pas sa
  machine et n'a aucun champ dans ce schéma.
- ❌ **Aucune synchronisation de mémoire d'équipe.** ReasoningBank, trajectoires, embeddings,
  leçons restent locaux. Une « mémoire d'équipe partagée » est un produit distinct, avec ses
  propres obligations de confidentialité — et ferait de ce backend un tenant de données.
- ❌ **Aucune orchestration d'agents côté serveur.** Pas de spawn, pas de file de tâches, pas de
  runner. L'exécution est intégralement client-side.
- ❌ **Aucun code, prompt, chemin de fichier, nom de projet ou dépôt.** Aucun champ du schéma ne
  peut en accueillir ; toute PR en introduisant un est à rejeter.
- ❌ **Aucune télémétrie d'usage.** Pas de comptage de commandes, de tokens, de durées, de noms
  d'agents. Les seuls signaux collectés sont : date de dernière activité (granularité jour),
  nombre d'empreintes d'appareils distinctes, nombre d'activations. Ils existent pour la
  facturation et l'anti-abus, pas pour l'analytique produit.
- ❌ **Aucune place de marché ni distribution de skills.** L'installeur distribue le paquet ; ce
  service ne sert pas de contenu.
- ❌ **Aucun SSO/SCIM en v1.** YAGNI jusqu'au premier client entreprise qui l'exige au contrat.

---

## 6. Conséquences

**Positives**

- La panne du service de licensing est un non-événement pour les clients (jusqu'à 21 jours).
- Le coût d'infrastructure est quasi constant et découplé de l'usage : N sièges × 1 requête/jour.
- La promesse « votre code ne sort jamais » reste **techniquement vraie**, et vérifiable en audit
  client par simple inspection du schéma.
- Le revenu est prévisible (par siège) et sans coût variable adossé.
- Périmètre suffisamment petit pour être livré et audité rapidement.

**Négatives / compromis**

- Révocation non immédiate (jusqu'à 21 jours) — accepté, documenté commercialement.
- Un client de mauvaise foi peut faire tourner ADA hors ligne pendant la fenêtre de grâce.
  Recours contractuel, pas technique.
- Un second déployable à opérer, avec astreinte de fait sur les webhooks Stripe (une perte de
  webhook fausse le statut jusqu'à la réconciliation quotidienne).
- La rotation de la clé Ed25519 dépend de clients qui rafraîchissent : un poste éteint plusieurs
  semaines devra se réactiver après une rotation.
- Le portail admin est une surface web à sécuriser (authentification, énumération de comptes,
  IDOR sur `account_id`) alors que le reste d'ADA n'a aucune surface exposée.

### Décisions irréversibles (ou coûteuses à défaire) — à signaler

1. **Le format et l'algorithme du jeton d'entitlement.** La clé publique est embarquée dans les
   paquets installés chez les clients. Un changement d'algorithme casse tous les postes déjà
   déployés. → Mitigation obligatoire **dès la v1** : en-tête `kid` + endpoint JWKS, même s'il
   n'y a qu'une clé. Ne pas l'ajouter maintenant coûterait une réinstallation générale plus tard.
2. **La politique de fail-open.** Une fois annoncée, la resserrer se lit comme une régression
   hostile envers des clients payants. Le durcissement doit se faire par des paramètres de plan
   (TTL, grâce), pas par un changement de politique.
3. **« Le backend n'est pas un tenant de données ».** C'est l'argument de vente et la ligne
   d'audit. Le franchir déclencherait DPA, résidence des données, sous-traitance RGPD, et
   invaliderait le pitch. Coût de retour arrière : élevé et essentiellement juridique.
4. **Le format de la clé de licence** (`ADA-XXXX-…`), imprimé dans les contrats et la
   documentation client.
5. **Par siège licencié vs par usage.** Rebasculer vers le metering demanderait une collecte
   d'usage — c'est-à-dire de la télémétrie, c'est-à-dire la violation du point 3.

---

## 7. Risques et décisions ouvertes

Aucun de ces points ne bloque la rédaction du schéma ; **tous doivent être tranchés (décision
produit) avant l'implémentation**.

| # | Question ouverte | Options | Recommandation provisoire |
|---|---|---|---|
| **O1** | **Un siège partagé par plusieurs devs** (compte d'équipe `dev@corp.com`) | (a) autoriser N appareils sans contrôle ; (b) plafond d'appareils + alerte au-delà ; (c) identité forte par SSO | (b) : plafond à 3 appareils, alerte admin à la 4ᵉ empreinte en 30 j. Refuser silencieusement irriterait le cas légitime laptop+desktop+VM. |
| **O2** | **Détecter l'abus sans télémétrie intrusive** | (a) rien ; (b) trois compteurs seulement (appareils distincts, activations, dernière activité) ; (c) heuristiques d'usage | (b). (c) exigerait de collecter ce que le § 5 interdit. |
| **O3** | **Que faire d'un compte `past_due`** (échec de paiement) | (a) couper immédiatement ; (b) laisser tourner pendant la relance Stripe (~21 j) puis grâce | (b), mais **noter le cumul** : 21 j de dunning + 7 j TTL + 14 j de grâce ≈ 42 jours d'usage impayé au pire. Trancher si c'est acceptable ; sinon réduire le TTL à 3 j pour les comptes `past_due`. |
| **O4** | **Onboarding d'un siège : allowlist d'emails ou invitation par email** | (a) l'admin liste les emails, la clé circule en interne ; (b) email d'invitation avec code à usage unique | (a) en v1 (pas d'infra emailing à construire) ; (b) dès qu'un client dépasse ~20 sièges. Risque de (a) : la clé fuite → limité par l'allowlist + le quota. |
| **O5** | **Empreinte machine : quelle source ?** | UUID matériel, `machine-id`, UUID aléatoire persisté | UUID **aléatoire généré au premier lancement et persisté** dans `~/.ada/`, puis haché. Ne lit aucun identifiant matériel — bien plus défendable en audit ; contrepartie : réinstallation du poste = nouvel appareil, d'où l'endpoint `release`. |
| **O6** | **Air-gap / clients sans aucun réseau sortant** | (a) non supporté ; (b) licence longue durée émise hors bande | Différer. À traiter au premier prospect qui l'exige — ne pas construire par anticipation. |
| **O7** | **Portail admin : app web ou CLI seule ?** | (a) `ada admin …` en CLI en v1 ; (b) app Next.js | (a) : zéro surface web à sécuriser au départ ; ajouter (b) quand le nombre de comptes le justifie. |
| **O8** | **Résidence des données (UE)** | héberger UE d'emblée ou plus tard | Héberger en UE dès le départ : le seul contenu personnel est un email de siège, mais un client UE posera la question en due diligence et « déjà en UE » clôt le sujet. |
| **O9** | **Essai gratuit** | avec ou sans carte | Trial 14 j **sans carte**, plafonné à 5 sièges. Statut `trial` déjà prévu au schéma. |
| **O10** | **Réconciliation Stripe** | cron quotidien vs à la demande | Cron quotidien + endpoint admin manuel de re-synchronisation. Un webhook perdu ne doit pas rester invisible. |

---

## Prochaines étapes

1. Trancher **O1, O3, O4, O5, O9** (décisions produit) — bloquantes pour l'implémentation.
2. Passer cet ADR de `Proposé` à `Accepté`, ou ouvrir un ADR-021 si une option majeure change.
3. Écrire les migrations SQL (`0001_licensing_init.sql`) sur le patron
   `ada-api-nest/src/persistence/migrations/`.
4. Écrire les specs **avant** le code (convention TDD projet) : vérification de jeton, quota de
   sièges sous concurrence, idempotence des webhooks, transitions d'états d'entitlement.
5. Implémenter le module Stripe **from scratch** — le repo n'en contient aucun ;
   `.claude/skills/nestjs/create-stripe-module.md` est un générateur pour les clients, pas une
   dépendance interne.
6. Spécifier côté CLI le chemin de vérification hors ligne et la commande `ada activate`
   (ADR séparé si le protocole client dépasse le trivial).
