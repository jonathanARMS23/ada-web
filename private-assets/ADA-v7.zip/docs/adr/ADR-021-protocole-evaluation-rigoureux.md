# ADR-021 — Protocole d'évaluation rigoureux (efficacité + efficience)

**Date** : 2026-08-06
**Statut** : Proposé (en attente de revue adversariale + validation utilisateur avant tout run)
**Décideurs** : Jonathan Arms

---

## Contexte

Session du 2026-08-04/06 : deux expériences (natif vs pipeline ADA sur 4 tâches
above-threshold ; Engineering Loop sur 2 tâches) ont produit des résultats — mais un
audit honnête de leur fiabilité (demandé explicitement par le décideur) a révélé des
failles méthodologiques réelles, pas cosmétiques :

1. **N=1 sans mesure de variance.** Chaque condition n'a été mesurée qu'une seule fois.
   Les LLM sont stochastiques — impossible de distinguer "aucun effet réel" de "coup de
   dé qui tombe pareil" sur un seul tirage.
2. **Asymétrie de scrutin entre bras.** Dans l'expérience A, le bras pipeline a bénéficié
   d'une phase "safety" dédiée qui a trouvé et documenté ses propres bugs. Le bras natif
   n'a reçu aucune vérification équivalente — ses bugs éventuels sont invisibles, pas
   absents. Le score identique (100/100) peut donc refléter une différence de rigueur de
   *mesure*, pas de qualité *réelle*.
3. **Confusion prompt × architecture.** Les deux bras n'ont pas reçu un prompt strictement
   contrôlé — le natif avait une consigne de liberté, le pipeline des rôles scriptés par
   phase. La comparaison mesure un mélange non isolé de plusieurs variables.
4. **Bugs de l'instrument de mesure non détectés a priori.** Cinq bugs réels de scoring/
   classification ont été trouvés et corrigés dans les 48h précédentes (3 dans les
   assertions bench-v2, 2 dans le stub de schéma SQL, 11 dans le classifieur/routeur).
   Motif récurrent, pas incident isolé — l'instrument lui-même n'est jamais validé avant
   d'être utilisé pour juger.
5. **Échantillon de tâches non représentatif.** 4 tâches SQL (expérience A), 2 bugs JS
   du même registre "pattern connu" (expérience B) — trop étroit pour généraliser.
6. **Mécanisme partiellement testé.** L'Engineering Loop permet jusqu'à 3 itérations ;
   un seul retry a été testé. Un seul modèle (sonnet-5) a été utilisé partout.

Ce protocole existe pour que la PROCHAINE comparaison natif-vs-ADA produise un résultat
qu'on peut réellement défendre — pas un résultat qu'on découvre fragile après coup.

## Décision

### Principe directeur

**On ne mesure jamais avec un instrument qu'on n'a pas d'abord validé, et on ne conclut
jamais sur un échantillon qu'on n'a pas répété.** Tout run qui viole l'un des principes
ci-dessous est un pilote, pas un résultat.

### 1. Validation du scorer AVANT toute mesure (« tester le testeur »)

Avant d'utiliser un scorer sur de vrais livrables d'agents, il doit passer un jeu de
**fixtures de calibration** :
- **≥2 solutions volontairement correctes mais stylistiquement différentes** par tâche
  (ex: schéma avec colonnes additionnelles légitimes, noms de contraintes différents,
  qualification de schéma différente) → le scorer doit toutes les noter au maximum.
- **≥2 solutions volontairement incorrectes** par tâche, chacune violant UNE exigence
  précise et UNE SEULE → le scorer doit détecter exactement celle-là, pas plus, pas moins.
- Un scorer qui échoue sur ces fixtures est corrigé AVANT le run, jamais après (le motif
  de cette session — corriger le scorer en découvrant l'échec sur un vrai livrable — doit
  devenir l'exception, pas la procédure standard).

### 2. Répétition et variance — N minimum par condition

- **N ≥ 5 tirages indépendants par (tâche × condition)** pour tout résultat qu'on veut
  citer comme conclusion (pas juste comme observation exploratoire). N≥3 accepté pour un
  T1 (cf. cadre T0/T1/T2, addendum).
- Rapporter systématiquement : score médian, min/max, et taux de réussite si le score est
  binaire.
- **Rigueur statistique réelle, pas un vernis** (correction F1/I1 de la revue adversariale
  du 2026-08-06) : à N=5, seule une séparation **complète** (5/5 dans la direction
  attendue) est statistiquement concluante (test exact, p=0,031 unilatéral). Un score de
  4/5 est **suggestif, à répliquer** — jamais présenté comme une conclusion. La règle
  précédente ("≥4/5") avait un α≈19% (intervalle de Wilson sur 4/5 = [0,376 ; 0,964],
  contient 0,5) : elle ne pouvait pas exclure l'absence d'effet. Corrigé.
- **Type de test à choisir AVANT le run, pas après (F1)** : distinguer explicitement deux
  types de décision, qui n'ont pas la même charge de preuve :
  - **Test de supériorité** ("le mécanisme X est meilleur") → exige la séparation complète
    ci-dessus, ou un vrai test de puissance (à N=5 sur une échelle 0-100 avec écart-type
    plausible de 10, il faudrait en réalité N≈50/condition pour détecter un écart de 5 pts
    — le dire explicitement plutôt que de prétendre trancher à N=5).
  - **Règle de dominance de coût** ("le mécanisme X est retiré par défaut sauf preuve
    contraire") → NE cherche PAS à prouver une équivalence (absence de preuve ≠ preuve
    d'absence — piège de fond identifié en F1). Renverse la charge de la preuve : si le
    coût du mécanisme est déjà établi comme significativement plus élevé (ex: 2,5-3× en
    appels agent, mesuré avec une faible variance), la décision par défaut est le retrait,
    **sauf si** le mécanisme démontre un gain de qualité ≥ seuil pré-enregistré avec 5/5
    tirages. C'est la règle utilisée pour les décisions produit de ce protocole — décidable
    à N=5, honnête, et elle n'exige pas de prouver un null.

### 3. Contrôle strict des variables — isoler UNE différence à la fois

Pour comparer deux conditions (ex: natif vs pipeline), **tout le reste doit être
identique** : même modèle/tier, même mémoire injectée (ou son absence, mais alors des
deux côtés), même formulation de la tâche source. Seule la variable étudiée (ici :
décomposition oui/non) doit varier. Si une deuxième variable doit varier par nécessité
(ex: le pipeline a besoin d'un prompt structuré par phase), le documenter explicitement
comme confondu et ne pas prétendre isoler la variable principale.

### 4. Scrutin symétrique entre conditions

**Toute vérification appliquée à une condition doit être appliquée à l'autre**, avec la
même rigueur. Si un protocole prévoit une revue de sécurité adversariale pour le bras
pipeline, le bras natif reçoit la MÊME revue, par un agent différent qui ne sait pas quel
bras il évalue (voir point 5). Sans ça, le bras le moins examiné gagne artificiellement.

### 5. Notation à l'insu (blinding) quand un jugement qualitatif est nécessaire

Quand la notation n'est pas 100% objective/exécutable (ex: une revue de sécurité, un
jugement de lisibilité), l'agent qui note ne doit **jamais** savoir quelle condition
(natif/pipeline, avec/sans mémoire) a produit le livrable qu'il examine. Anonymiser
les livrables (retirer tout indice de style/structure qui trahirait la méthode de
génération) avant de les soumettre à notation.

### 5bis. Gate de pouvoir discriminant (F2) — ne pas répéter une mesure qui vaut 100 partout

Avant tout run coûteux (N≥5) sur une tâche : **pilote N=2** sur le bras a priori le plus
faible. Si sa médiane est **≥ 95**, la tâche est marquée `non-discriminante` — conservée
dans le corpus pour la régression (jamais retirée, cf. principe du point 6), mais
**exclue du corpus décisionnel** tant qu'elle ne discrimine rien. Répéter 5× une mesure
plafonnée ne produit aucune information, seulement 5× le coût.

**Application immédiate (2026-08-06)** : sur les 4 tâches `above-threshold`, même sous
assertions durcies (rôle `authenticated` réel, ADR-021 addendum F3/F6), 3 tâches sur 4
(`at-orders-fulfillment-schema`, `at-ledger-immutable-double-entry`,
`at-rls-cross-tenant-isolation`) restent 100/100 sur les deux bras — marquées
`non-discriminantes` pour le corpus décisionnel actuel. Seule
`at-audit-soft-delete-trigger` discrimine (100 vs 92) et devient la cible du prochain T1.

### 6. Corpus de tâches stratifié et représentatif

Ne plus mesurer sur un seul registre de tâches. Le corpus minimal couvre :
- **≥3 domaines distincts** (ex: schéma SQL, logique métier TypeScript, configuration
  d'infrastructure) — pas seulement du SQL.
- **≥2 niveaux de complexité** par domaine (standard vs above-threshold).
- **Pour les bugs testés par l'Engineering Loop** : au moins un bug "pattern connu"
  (type ceux testés le 2026-08-06) ET au moins un bug **spécifique au projet / non
  générique** (une convention ou un piège qui ne peut PAS être résolu par une
  connaissance générale de bonnes pratiques — sinon on ne teste que la capacité du modèle
  nu, pas la valeur du mécanisme).
- Chaque tâche déclare sa catégorie et son niveau, et le corpus est versionné (comme
  `tasks-v2.json` aujourd'hui) pour rester stable entre les runs successifs — on ajoute
  des tâches, on n'en retire jamais une existante (même principe que les ancres flywheel,
  cf. [[feedback_flywheel_anchors_immutable]]).

### 7. Couverture multi-modèle

Toute conclusion generalisée ("le mécanisme X n'apporte rien") doit être vérifiée sur
**au moins 2 tiers de modèle** (ex: sonnet ET haiku, ou sonnet ET opus) avant d'être
retenue comme robuste — un résultat spécifique à un seul modèle est étiqueté comme tel,
pas généralisé silencieusement.

### 8. Test du mécanisme réel, pas d'une version simplifiée

Pour l'Engineering Loop spécifiquement : tester le cycle complet jusqu'à `maxLoops`
itérations (pas un seul retry), avec le VRAI `error-context.js` (corrigé au préalable
si un bug de fidélité est connu — cf. le bug `parseErrors`/TAP découvert le 2026-08-06,
à corriger avant de remesurer). Ne jamais approximer le mécanisme testé par une version
allégée sans le signaler explicitement comme limite.

### 9. Métriques d'efficience — mesurées systématiquement, pas en option

Chaque run capture, pour CHAQUE tirage (pas juste en moyenne finale) :
- **Tokens** (input/output/cache-read/cache-write séparés — le cache hit rate est lui-même
  une métrique d'efficience à suivre, cf. point 10).
- **Coût réel** ($ selon la grille tarifaire du modèle utilisé, pas une estimation).
- **Temps mur (wall-clock)** de bout en bout — la décomposition en phases séquentielles a
  un coût temps, pas seulement un coût token, et c'est une dimension d'efficience que les
  runs précédents n'ont pas mesurée du tout.
- **Nombre d'appels agent** (proxy direct de la complexité orchestrée).

### 10. Hygiène de cache prompt — mesurée, pas supposée

Vérifier et rapporter le taux de cache-hit réel sur le bloc mémoire injecté à travers les
appels d'un même run. Un mécanisme qui réinjecte un bloc mémoire à un endroit instable du
prompt (cassant le cache) coûte plus cher que ce que les tokens bruts affichés suggèrent.

### 11. Rapport — format standard obligatoire

Chaque run produit un rapport qui déclare, AVANT les résultats :
- Le seuil de décision pré-enregistré (point 2).
- Les variables contrôlées et les confondus documentés (point 3).
- Le résultat de la validation du scorer sur les fixtures de calibration (point 1).
Puis les résultats avec N, médiane, min/max, et le calcul explicite de la règle de
décision — pas une conclusion qualitative non chiffrée.

## Conséquences

- **+** Un résultat produit sous ce protocole peut être cité dans un pitch commercial ou
  une décision produit sans réserve méthodologique majeure.
- **+** Les fixtures de calibration du scorer deviennent un actif réutilisable (comme les
  ancres flywheel) — chaque nouvelle catégorie de tâche les enrichit.
- **−** Coût nettement plus élevé par comparaison (N≥5 au lieu de N=1, scrutin symétrique
  qui double le nombre d'agents de revue, ≥2 modèles). Une comparaison complète devient un
  chantier de plusieurs heures/jours, pas une session.
- **−** Ne résout pas le biais d'échantillonnage inhérent à des tâches conçues par nous
  (même stratifiées, elles restent des proxys de la réalité, pas la réalité).

## Alternatives rejetées

| Option | Raison du rejet |
|--------|-----------------|
| Garder N=1 mais documenter la limite | Insuffisant pour fonder une décision produit coûteuse (retirer un mécanisme) — une limite documentée reste une limite, pas une preuve |
| Notation par LLM-judge non aveugle | Reproduit exactement l'asymétrie de scrutin qui a faussé l'expérience A |
| Un seul modèle testé, généralisé par défaut | Un résultat spécifique à sonnet-5 étiqueté comme général tromperait sur la portée réelle |

## Prochaines étapes

1. ~~Revue adversariale de ce protocole~~ **FAIT (2026-08-06)** — 7 findings fondamentaux
   (F1-F7) + 8 importants (I1-I8). Verdict : diagnostic juste, remède initial mal ciblé
   (corrigeait la faille la plus visible — N=1 — en ratant les 3 qui ont réellement
   produit le résultat non concluant). Findings intégrés ci-dessous.
2. ~~F6 (mutation testing du scorer)~~ **FAIT** — voir addendum.
3. ~~F3 (assertions sous rôle authenticated réel)~~ **FAIT** — voir addendum.
4. ~~I3 (provenance runId/sha dans les résultats)~~ **FAIT** — chaque `bench-v2 score`
   enregistre `runId` (unique par invocation), `scorerSha` et `tasksSha`
   (`git:<commit>` si le fichier est propre, `sha256:<contenu>` sinon) et `model`.
   Le vocabulaire des bras n'est plus figé à A-D : un bras `NATIVE`/`PIPELINE` est
   enregistré ET agrégé (il disparaissait silencieusement du rapport), et `report`
   **refuse** (erreur, exit 1) tout delta calculé sur un plan déséquilibré, une
   cellule ambiguë (deux scores pour un même couple tâche/bras) ou des `scorerSha`
   mélangés. Les 10 entrées obsolètes de `results-v2.json` (scores pré-fix empilés)
   ont été retirées : une seule mesure par couple (tâche, bras), la plus récente.
5. ~~F1 (règle de dominance de coût), F2 (gate de pouvoir discriminant)~~ **FAIT** — voir
   addendum T1. F7 (runner headless) reste non traité, nécessaire avant un run à l'échelle
   T2 (voir cadre T0/T1/T2 ci-dessous) mais hors périmètre pour une validation T1 (N=3,
   orchestration manuelle suffisante).
6. ~~T1 (natif vs natif+revue vs pipeline, N=3, `at-audit-soft-delete-trigger`)~~ **FAIT** —
   voir addendum. **Verdict retiré** après revue adversariale (G1/G3, voir CORRECTION
   ci-dessous) : non concluant, pas réfuté.
7. ~~Revue adversariale du protocole lui-même (fiabilité + couverture)~~ **FAIT** — 12
   findings (G1-G12), 6 vérifiés personnellement (6/6 confirmés). Voir CORRECTION et
   Action 2 ci-dessous.
8. ~~Action 2 (fixtures de calibration positives+négatives, principe #1)~~ **FAIT** — voir
   addendum. 59/59 conforme, 2 limites structurelles documentées (non corrigées).
9. Action 3 (2 tâches hors SQL scorées par exécution réelle) — en cours.

## Addendum — F3 et F6 exécutés (2026-08-06)

**F6 — mutation testing du scorer** (commit `0518551`) : 125 mutations sémantiquement
neutres appliquées aux 8 livrables réels de l'expérience A. 104 stables, 0 régression de
scorer trouvée, 21 n/a tracées (dépendances réelles qui interdisent légitimement la
mutation). Le scorer above-threshold est validé par mutation testing pour les classes de
variation testées — pas une preuve d'absence totale de bug, mais un vrai gain de confiance
sur exactement la classe d'erreur qui a mordu 5 fois cette session.

**F3 — assertions sous rôle `authenticated` réel** (commit `4d2562b`) : `auth.jwt()` n'est
plus un stub statique, `bench.act_as()` pose simultanément tous les canaux d'autz légitimes
(GUC session et claims JWT) pour ne favoriser aucun mécanisme. Validation croisée avec F6 :
8/8 mutants négatifs artificiels détectés dont **3 invisibles sous l'ancien régime
superuser** ; 4/4 contrôles positifs corrects (dont un mécanisme JWT légitime que l'ancienne
assertion pénalisait à tort — corrigé, pas juste découvert).

**Résultat sur les 8 livrables réels** : `at-rls-cross-tenant-isolation` confirme 100/100
des deux côtés — l'isolation est réellement vérifiée sous rôle réel, pas un artefact.
`at-audit-soft-delete-trigger` bras **NATIF chute à 92/100** : sa vue `active_contacts` n'a
pas `security_invoker=true`, fuite cross-tenant réelle et mesurée (0 ligne en lecture
directe sur la table, 1 ligne étrangère via la vue). Le bras PIPELINE reste 100/100 — sa
phase safety avait explicitement traité ce point. **L'égalité 100/100 de l'expérience A
(ADR-019, commit `1b0b3a8`) ne tient donc plus pour cette tâche précise.**

**Réserve méthodologique qui reste entière** (F1/F4 non résolus) : ceci est **N=1**. L'écart
observé peut refléter un vrai avantage du pipeline, OU l'asymétrie de scrutin documentée en
F4 (le pipeline a eu une phase safety dédiée, le natif non) plutôt que l'architecture en
elle-même. Ne pas généraliser « le pipeline est meilleur en sécurité » sur cette seule
observation — c'est exactement le type de conclusion prématurée que ce protocole existe
pour empêcher. Statut correct : **hypothèse renforcée, pas confirmée** — nécessite un T1
(N≥3, cf. cadre ci-dessous) avant toute décision produit.

## Cadre de niveaux de preuve — T0/T1/T2 (issu de la revue adversariale)

Trois niveaux de preuve, choisis **avant** le run et indexés sur la réversibilité de la
décision, pas sur l'envie de conclure :

- **T0 — pilote** (N=1, 1 modèle) : légitime pour une décision réversible et bon marché,
  explicitement étiqueté « exploratoire ». C'est le niveau de ce qui a été fait aujourd'hui.
- **T1 — interne** (N≥3, 1 modèle, 1 domaine, scorer validé par mutation testing) : niveau
  minimal pour retirer/garder un mécanisme en interne.
- **T2 — externe** (protocole complet : N≥5, scrutin symétrique, ≥2 modèles, corpus
  stratifié) : requis uniquement pour une affirmation commerciale ou un retrait
  irréversible.

Le niveau visé est engagé par commit git **avant** le run — un pré-enregistrement dans un
document qu'on édite soi-même après coup ne vaut rien, l'horodatage git oui.

## Addendum — T1 exécuté (2026-08-06) : natif vs natif+revue vs pipeline

Niveau engagé **avant** le run : T1 (N≥3, 1 modèle sonnet, 1 tâche discriminante
`at-audit-soft-delete-trigger`, scorer validé F6). Objectif : isoler si la valeur mesurée du
pipeline (100 vs 92, addendum F3/F6) vient de la **décomposition en elle-même** ou
spécifiquement d'une **étape de revue indépendante** — troisième condition ajoutée pour
neutraliser F4 (asymétrie de scrutin) au lieu de la documenter comme réserve non résolue.

**Bug d'instrument trouvé et corrigé pendant le run** (avant tout score définitif) : les
tables-souches créées pour une FK externe (`workspaces`, convention multi-tenant courante)
n'étaient jamais peuplées — toute assertion `role:'authenticated'` insérant sous une identité
simulée cassait sur violation de contrainte FK, indépendamment de la qualité du livrable.
Avait fait chuter à tort 2 trials PIPELINE à 50/100. Fix commité (`55ee0d5`, `buildStubSql`
seed désormais les identités `BENCH_IDS`), 116/116 tests bench-v2 + 1440/1440 suite globale
verts, tout re-scoré sous provenance propre. `results-v2.json` nettoyé (`4022e27`) : 11
entrées pré-fix/pré-provenance retirées, 9 conservées (3 par condition, `scorerSha` unique).

**Résultat (N=3 par condition, sonnet, scorerSha=`git:55ee0d5…`)** :

| Condition | Agents | Scores | Moyenne | σ |
|---|---|---|---|---|
| Natif | 1 | 92, 92, 92 | 92 | 0 |
| Natif + revue indépendante | 2 | 100, 75, 0 | 58,3 | ~41 |
| Pipeline | 3 | 100, 100, 100 | 100 | 0 |

**Ce que ça infirme** : l'hypothèse de travail après le premier trial (`NR1=100`, message
précédent) était que la revue seule reproduirait la valeur du pipeline à moindre coût.
Elle ne survit PAS à N=3 — au contraire, elle s'effondre : trial 2 = 75 (le générateur a
dévié du spec explicite, colonne `op` → `operation` ; hors périmètre demandé au reviewer,
sécurité/sûreté migratoire, pas conformité de nommage) ; trial 3 = **0** (le reviewer a
ajouté `ALTER FUNCTION ... OWNER TO postgres` pour fixer un risque perçu — bypass RLS du
trigger `SECURITY DEFINER` dépendant implicitement de l'ownership — mais `postgres` n'existe
pas comme rôle sur ce cluster de test, la transaction entière a rollback). Vérifié
reproductible en dehors du scorer (`psql -f` direct, erreur `role "postgres" does not
exist`) — **pas** un artefact d'instrument : aucun des 7 autres trials (natif, pipeline, NR1)
n'a eu besoin de cette instruction, l'ownership par défaut (rôle qui exécute la migration)
suffit partout ailleurs. Contrairement au bug stub-FK ci-dessus, celui-ci n'a donc **pas**
été neutralisé côté harnais — scrutin symétrique : on ne corrige l'instrument que quand le
gap est démontrablement indépendant du contenu jugé, pas quand corriger flatterait la
condition en cours d'évaluation.

**Application de la règle de dominance de coût (F1)** : Natif+revue (2 agents) devait
dominer Pipeline (3 agents) — qualité ≥, coût <. Résultat : qualité **strictement
inférieure** (58,3 vs 100), la moyenne est même sous Natif seul (92). **Rejetée par les
données, pas juste non confirmée.** Le pipeline n'est pas seulement meilleur en moyenne ici
— il est plus **fiable** (σ=0 sur les deux conditions à 3 agents/étapes vs σ≈41 pour la
revue seule à 2 étapes). Lecture qualitative (N=3, à ne pas sur-généraliser) : ajouter une
étape de revue sans les étapes de decomposition/spécification qui l'entourent dans le
pipeline complet (design isolé du reste) semble augmenter la variance plutôt que
simplement ajouter de la valeur — la revue seule peut proposer un correctif qui introduit un
nouveau défaut (trial 3) sans qu'aucune étape suivante ne le rattrape, alors que dans le
pipeline complet la phase `apply` suit directement la phase `safety` sur le même artefact
validé bout en bout.

**Limites qui restent (T1, pas T2)** : N=3, 1 modèle, 1 tâche. Ne PAS généraliser
« l'architecture pipeline complète bat systématiquement natif+revue » au-delà de cette
tâche — seulement : sur cet échantillon, la revue indépendante isolée n'a pas reproduit la
fiabilité du pipeline complet, et son échec le plus coûteux (trial 3) était évitable
(instruction non-idiomatique, non nécessaire dans 7/8 autres trials).

**Statut** : hypothèse initiale (revue seule = valeur du pipeline à moindre coût)
**réfutée à T1** sur cette tâche. Décision produit : ne pas retirer les étapes de pipeline
au profit d'une simple revue-bolt-on tant qu'un T2 (≥2 modèles, corpus stratifié) ne le
confirme pas — le coût d'un pipeline complet reste justifié sur cette classe de tâche
(SQL/RLS multi-tenant) par la réduction de variance observée, pas seulement par la moyenne.

## CORRECTION — revue adversariale du protocole lui-même (2026-08-06)

Le paragraphe « Statut » ci-dessus a été écrit avec trop de confiance. Une revue
adversariale dédiée (agent `devils-advocate`, mandat : évaluer la fiabilité et la
couverture de ce protocole) a trouvé 12 findings (G1-G12). Deux touchent directement le
verdict T1 ci-dessus et ont été **vérifiés personnellement** (pas pris pour argent
comptant) avant correction :

**G1 — vérifié et corrigé.** `SUPABASE_SCAFFOLD_SQL` (`bench-v2.js`) crée `anon`,
`authenticated`, `service_role` mais **jamais `postgres`** — vérifié par `psql \du` sur le
cluster réel (rôles présents : `admin, anon, authenticated, intuity_superuser,
jonathanarms, service_role`, aucun `postgres`). Le trial NR3 avait été scoré 0/100 pour
`ALTER FUNCTION ... OWNER TO postgres`, traité plus haut comme « défaut réel, pas artefact
d'instrument, aucun des 7 autres trials n'en avait besoin ». C'était une erreur : `postgres`
est le rôle superuser réel de toute instance Supabase (idiome standard, pas une excentricité
du livrable), et ADR-019 avait déjà tranché ce principe général (« scorer sur Postgres
vanilla pénalise injustement le SQL fidèle au stack Supabase ») — je n'ai simplement pas
appliqué mon propre principe, quelques messages après l'avoir appliqué au bug stub-FK.
Scaffold corrigé (commit `dcf7450`, 116/116 tests bench-v2 verts), NR3 re-scoré :
**0 → 75/100** (échoue maintenant sur la même déviation de spec que NR2 — colonne `op` vs
`operation` — cause légitime, confirmée indépendamment du bug de scaffold).

**G3 — vérifié, plus grave que rapporté.** Le pipeline `migration` (`pipelines.json`) a
**4 phases** (`design → safety → apply → verify`), pas 3 comme documenté plus haut. Mais le
vrai problème est ailleurs : sur les 9 trials T1, je n'ai **jamais** dispatché d'agent pour
les phases `apply`/`verify` — j'ai directement scoré le livrable issu de `safety` comme
livrable final, pour PIPELINE **et** pour NATIF+REVUE. Le bras « pipeline » réellement
exécuté = 2 appels d'agent (design + safety), **identique** en coût à natif+revue (gen +
review). La comparaison « pipeline 3 agents vs revue 2 agents » qui fonde toute la section
« règle de dominance de coût » ci-dessus n'a jamais correspondu à ce qui a été exécuté.
Second confound non isolé (principe #3, jamais respecté ici) : le générateur de PIPELINE
(phase `design`, agent `db`) et celui de NATIF+REVUE (`general-purpose`) sont deux agents
**différents** — la déviation `op`→`operation`, observée sur 2/3 trials NATIF+REVUE et
0/3 trials PIPELINE, peut donc venir du choix d'agent spécialisé plutôt que de la présence
d'une revue.

**Chiffres corrigés (N=3, scorerSha post-G1)** :

| Condition | Agents réellement exécutés | Scores | Moyenne | σ |
|---|---|---|---|---|
| Natif (1 agent, `general-purpose`) | 1 | 92, 92, 92 | 92 | 0 |
| Natif + revue (`general-purpose` puis `reviewer`) | 2 | 100, 75, 75 | 83,3 | ~11,8 |
| Pipeline (`db` puis `reviewer`) | 2 | 100, 100, 100 | 100 | 0 |

**Verdict révisé** : PIPELINE reste supérieur en moyenne et en variance à NATIF+REVUE sur
cet échantillon — mais le mot « pipeline » ici ne désigne PAS l'architecture de décomposition
(qui n'a jamais tourné au-delà de 2 phases), et l'écart peut venir du choix de l'agent
générateur (`db` vs `general-purpose`) plutôt que de la revue en soi. **La conclusion
« réfutée par les données » du paragraphe précédent est retirée.** Statut correct :
**non concluant** — deux variables non contrôlées (nombre réel de phases, agent générateur)
rendent l'attribution causale impossible avec ces données. Un re-run propre nécessiterait :
même agent générateur pour les 3 conditions, et soit dispatcher réellement `apply`+`verify`
pour PIPELINE, soit documenter explicitement qu'on compare seulement `design+safety` vs
`gen+review` (ce qui est une question différente et plus modeste : « une revue de sécurité
aide-t-elle, peu importe qui génère ? » — pas « le pipeline complet vaut-il le coût ? »).

**10 autres findings (G2, G4-G12)** portent sur le protocole en général (pas seulement ce
run) : hypothèse formulée après le 1er trial et comptée dans l'échantillon qui la teste
(G2) ; agrégat par défaut de `report` non protégé alors que le chemin delta l'est (G4) ;
aucun hash du livrable dans les entrées de `results-v2.json`, prompts des 9 trials jamais
versionnés (G5, partiellement traité — livrables rapatriés, voir Action 1a) ; principes #9
(tokens/coût/temps) et #10 (cache) déclarés mais 0 ligne de capture dans `bench-v2.js` (G6) ;
le mutation testing (F6) ne valide que la neutralité du scorer, aucun mutateur n'injecte de
défaut réel pour vérifier qu'il le détecte (G7) ; corpus 100 % SQL (12/12 tâches), 0 tâche
hors ce domaine malgré le principe #6 qui en exige ≥3 (G8) ; détection de bugs 100 %
réactive, 2 catégories `wired` du registre jamais exécutées une seule fois (G9) ; le
tier-routing/classifier (11 bugs fixés plus tôt cette session) n'a que des tests unitaires
anti-régression, jamais mesuré en effet réel — les bras A/B/C/D historiques (C/D à 0 entrée,
purgés) qui auraient pu le faire n'ont jamais eu de données (G10) ; aucun scrutin
multi-modèle (principe #7), 100 % des mesures en `sonnet` (G11) ; l'ADR affirmait
« `results-v2.json` : 9 entrées » alors que le fichier en contient 25 dont 12 sans
provenance — vrai seulement pour la tâche `at-audit-soft-delete-trigger`, faux pour le
fichier (G12, confirmé — 25 entrées comptées directement).

**Vérifié personnellement, pas pris sur la foi de l'agent** : G1 (rôles psql), G3 (JSON
`pipelines.json`), G6 (grep), G8 (JSON `tasks-v2.json`), G9 (comptage `results-v2.json`),
G12 (comptage `results-v2.json`). G2/G4/G5/G7/G10/G11 non re-vérifiés indépendamment mais
crédibles au vu du taux de confirmation (6/6) des findings vérifiés.

**Actions prises immédiatement** (coût nul à faible, aucune ne nécessite de nouveau run
d'agents) :
- G1 corrigé (commit `dcf7450`) et NR3 re-scoré.
- Action 1a de la revue : les 26 livrables `/tmp/benchv2-*.txt` (expériences A, F3, T1)
  rapatriés dans `.claude/benchmarks/v2/deliverables/<taskId>/` avant purge disque —
  seule trace des artefacts réels sous-jacents aux scores.

**Reste à décider (pas fait unilatéralement)** : Action 2 (fixtures négatives versionnées
par tâche, pour que le mutation testing détecte aussi les vrais défauts, pas seulement les
faux positifs) et Action 3 (2 tâches hors SQL scorées par exécution réelle) — voir rapport
complet de la revue pour le détail coût/impact. Ni l'une ni l'autre n'a été engagée sans
confirmation.

## Addendum — Action 2 exécutée : fixtures de calibration (2026-08-06)

Principe #1 implémenté : `.claude/benchmarks/v2/calibration/<taskId>/` pour les 10 tâches
SQL wired (correction-reelle ×3, conventions-tacites ×3, above-threshold ×4) — 20 fixtures
positives (2/tâche, stylistiquement différentes), 39 négatives (chacune violant une
exigence précise, identifiée à partir des `name` d'assertions), `expected.json` par tâche.
Harnais `.claude/coordinator/calibration-test.js` (`list`/`run`/`run-all`), comparaison
**assertion par assertion** (pas juste le score global — conforme à « détecter exactement
celle-là, pas plus, pas moins »). Vérifié personnellement : `run-all` → **59/59 conforme**,
`calibration-test.test.js` → 43/43, suite globale → **1483/1483** (0 régression).

**2 limites structurelles du scorer trouvées pendant la construction des fixtures — vérifiées,
non corrigées (décision produit, pas des bugs)** :

1. **`at-rls-cross-tenant-isolation`** — l'assertion « WITH CHECK refuse une écriture dans un
   autre workspace » ne peut pas être testée en isolation du SELECT policy : `bench.seed()`
   (`bench-v2.js:425,429`) utilise systématiquement `INSERT ... RETURNING id`, et Postgres
   exige que la ligne retournée satisfasse la policy SELECT — un WITH CHECK réellement cassé
   (ex. `WITH CHECK (true)`) est donc masqué dès que la policy SELECT filtre correctement,
   l'erreur observée (`insufficient_privilege`) étant identique dans les deux cas. Aucune
   fuite réelle de données (la ligne ne persiste jamais), mais l'assertion ne détecte pas la
   défaillance qu'elle nomme — seule `negative-permissive-policy-no-filter` (SELECT cassé
   aussi) déclenche un échec, indirectement.
2. **Toutes les tâches `above-threshold`** — l'assertion `[privilèges]` ne peut jamais
   détecter un GRANT manquant dans le livrable : `SUPABASE_SCAFFOLD_SQL` pose
   `ALTER DEFAULT PRIVILEGES ... GRANT ALL ON TABLES TO anon, authenticated, service_role`
   avant l'apply — intentionnel (fidélité Supabase, cf. addendum F3 plus haut), donc une
   table créée sans le moindre GRANT explicite reçoit quand même tous les privilèges.
   Vérifié : retirer `DELETE` du GRANT explicite d'un livrable ne change pas son score.

Pas de fixture négative livrée pour ces deux exigences précises plutôt que d'en forcer une
fausse — les 59 autres cas couvrent le reste. Ces deux limites sont documentées ici, pas
silencieusement contournées ; à corriger seulement si un vrai livrable produit un jour un
faux 100 qui en dépend (aucun cas connu à ce jour).

## Addendum — Action 3 exécutée : sortie du mono-domaine SQL (2026-08-06)

Finding G8 (revue adversariale) traité : corpus 12/12 SQL → **14 tâches, 3 domaines**.
2 agents en parallèle (`ts-scorer-task`, `infra-scorer-task`) — pipeline `feature` du
classifieur écarté (conçu pour une feature SaaS complète front+back+deploy, inadapté à de
l'outillage de benchmark ; décomposition manuelle en 2 workstreams indépendants à la place).

**TypeScript** (`ts-invoice-total-banker-rounding`, catégorie `correction-reelle-ts`,
`.claude/coordinator/bench-v2-ts.js`) : livrable TS isolé (fonction + DTO class-validator),
compilé via `tsc -p` (`noEmitOnError`), exécuté via un vrai harnais `node:test` généré à la
volée — résultats structurés par un marqueur JSON en sortie, pas de parsing TAP (leçon tirée
du bug documenté dans `ai-engineering-loop.md`). Dépendance assumée : réutilise
`ada-api-nest/node_modules` (class-validator/reflect-metadata) plutôt que dupliquer des
devDependencies — absence de ce node_modules → `typescriptAvailable()` renvoie false, skip
explicite, jamais un score silencieux. Bug réel trouvé et corrigé en cours de route (pas
dans le plan initial) : appelé depuis un test lui-même sous `node --test`, `NODE_TEST_CONTEXT`
se propage à l'enfant qui ignore l'appel imbriqué → faux score 0 systématique ; fix = retrait
explicite de la variable de l'environnement enfant.

**Docker** (`docker-node-multistage-nonroot`, catégorie `correction-reelle-docker`,
`.claude/coordinator/bench-v2-infra.js`) : Dockerfile multi-stage Node 20, `docker build`
réel, 6 checks par inspection réelle (`docker inspect`/`docker run id -u`/`docker
create`+`export` pour la fuite de secret — détecte un fichier renommé, pas juste un grep
textuel). Seuil de taille (≤150 Mo) calibré par mesure réelle (alpine≈49 Mo,
distroless≈44 Mo, node:20 complet≈389 Mo). Nettoyage `docker rmi -f` + dossiers temp en
`finally`, y compris sur build échoué — vérifié : `docker images -a`/`docker ps -a` ne
montrent aucune trace `benchv2-*` après un run complet.

Les deux teammates ont généralisé `calibration-test.js` pour dispatcher par catégorie
(`bench.runScorer`) au lieu d'un appel figé à `scoreSqlDeliverable` — le harnais de
calibration couvre maintenant les 3 domaines sans script ad hoc par domaine.

**Vérifié personnellement, pas pris sur la foi des agents** : `run-all` calibration → **72/72
conforme** (59 SQL + 7 TS + 6 Docker), suite globale → **1534/1534** (57 suites, 0
régression), 0 image/conteneur Docker orphelin avant et après un run complet (2 images
avaient été repérées à un instant donné, disparues au recheck — résidu transitoire d'un
run de mise au point de l'agent, pas un défaut du code final).

**Ce qui reste hors périmètre d'Action 3** (non demandé, non fait) : un 3ᵉ domaine
supplémentaire au-delà de SQL/TS/Docker (le principe #6 exige ≥3, désormais satisfait) ;
F7 (runner headless) et le passage à l'échelle T2.

## Addendum — G3 fermé : plan 2×2 générateur × revue (2026-08-07)

Case manquante complétée : 3 trials `db` seul, sans revue, même prompt canonique (versionné
dans `.claude/benchmarks/v2/deliverables/at-audit-soft-delete-trigger/PROMPT.txt` — ferme
une partie de G5). Bug d'instrument trouvé et corrigé en route (3ᵉ occurrence de la même
catégorie que G1/le fix stub-FK) : `bench.act_as()` ne peuplait jamais `workspace_members`,
cassant tout livrable utilisant le pattern RLS `workspace_id IN (SELECT ... FROM
workspace_members WHERE user_id = auth.uid())` — aussi idiomatique Supabase qu'un claim JWT.
Corrigé (`3e2b99b`), re-scoré : le score n'a pas changé pour les fixtures concernées mais la
CAUSE d'échec est passée d'un faux `contacts` RLS à la vraie cause (SECURITY DEFINER manquant
sur le trigger d'audit) — la mesure est maintenant fiable pour la bonne raison.

**Plan 2×2 complet (N=3/case, `at-audit-soft-delete-trigger`, scorerSha post-fix)** :

| | Sans revue | Avec revue |
|---|---|---|
| Générateur `general-purpose` | NATIF : 92,92,92 (μ=92, σ=0) | NATIF+REVUE : 100,75,75 (μ=83,3, σ≈11,8) |
| Générateur `db` (spécialiste) | NATIVE-DB : 50,50,92 (μ=64, σ≈19,8) | PIPELINE : 100,100,100 (μ=100, σ=0) |

**Ce que ça révèle, pas ce qu'on voulait démontrer** : l'effet de la revue **interagit** avec
le générateur, il n'est pas un incrément fixe. Chez `general-purpose`, la revue fait
**baisser** la moyenne (92→83,3) — 2/3 trials natif+revue ont régressé sur la colonne
`op`/`operation` (déviation de spec, hors du périmètre "safety" donné au reviewer). Chez
`db`, la revue **répare** un échec sévère et répété (64→100) — le générateur `db` a raté 2
fois sur 3 le `SECURITY DEFINER` du trigger d'audit (défaut plus grave qu'un simple
`security_invoker` manquant : la transaction entière échoue pour tout rôle `authenticated`),
exactement le type de défaut qu'une revue "safety/RLS" est censée attraper — et l'a
effectivement attrapé 3/3.

**Conclusion (T1, N=3/case, 1 tâche — pas T2)** : la revue indépendante n'a de valeur
mesurable ici que lorsqu'elle recoupe la classe de défaut du générateur qu'elle relit. Le
pipeline (`db`+revue) gagne parce que `db` produit des défauts "safety" que le reviewer
détecte systématiquement — pas parce que "pipeline > natif" en général. Un générateur qui ne
fait pas ce type d'erreur (`general-purpose` ici) ne gagne rien d'une revue scopée
sécurité/sûreté, et peut même en pâtir si le reviewer réécrit une partie du SQL en
introduisant une régression hors de son mandat. **Ne pas généraliser** au-delà de cette
tâche/ce couple d'agents — mais G3 est fermé : le confound est désormais mesuré, pas
seulement documenté comme limite.

## Addendum — Point 2 : la décomposition apporte-t-elle une vraie valeur ? (2026-08-07)

Question d'origine de toute cette session (« ADA ne sert à rien ? ») jamais mesurée avec un
instrument fiable — les bras C/D d'ADR-019 (valeur du routing, ROI de la décomposition)
avaient 0 donnée exploitable (classifier à 11 bugs, scorer non calibré, données purgées).
Premier test propre maintenant possible : classifier corrigé (11 bugs + C8 ci-dessous),
scorer calibré (Action 2), générateur tenu constant (leçon G3).

**Bug classifieur trouvé en préparant l'expérience (C8, 12ᵉ bug de la session)** : en
classifiant les 4 tâches `above-threshold` réelles pour choisir un cas d'étude, `at-orders-
fulfillment-schema` (3 tables, RLS, zéro frontend/déploiement) routait vers
`pipeline/saas-bootstrap` sur le seul mot « SaaS » utilisé comme contexte (« pour mon SaaS
multi-tenant »). Remplacer « SaaS » par « produit » dans le même prompt donnait `solo`.
Corrigé (`dd635b1`) : « saas » ne compte comme signal multi-couches que couplé à un verbe de
construction (crée/lance/construis/bootstrap/démarre/monte) — 4 tests de régression
ajoutés, 1539/1539 suite globale verte. Après fix, la tâche classifie `solo` — exactement le
cas où la règle par défaut d'ADA (CLAUDE.md : « défaut = 1 agent ») doit se justifier.

**Protocole** : `at-orders-fulfillment-schema` (classifiée `solo` post-fix), générateur `db`
identique dans les deux conditions (prompt canonique versionné dans
`deliverables/at-orders-fulfillment-schema/PROMPT.txt`). SOLO = `db` seul, N=3. PIPELINE =
`db`(design)+`reviewer`(safety), N=3 — même structure 2-agents que G3.

**Résultat (scorerSha unique, git:3e2b99ba23)** :

| Condition | Agents | Scores | Moyenne |
|---|---|---|---|
| SOLO | 1 | 100, 91, 100 | 97 |
| PIPELINE | 2 | 100, 91, 100 | 97 |

**Distribution identique.** Pas de différence à isoler ici — c'est le résultat le plus
propre et le plus interprétable de toute cette série de mesures : sur une tâche que le
classifieur (corrigé) juge suffisamment bornée pour 1 agent, ajouter une étape de revue
indépendante n'a produit **aucun** gain, pour le double du coût en appels d'agent. Les deux
échecs à 91 ont des causes DIFFÉRENTES et informatives : SOLO2 échoue sur l'assertion
d'isolation (choix défendable de correction silencieuse plutôt que rejet) ; PIPELINE2 échoue
sur `ON DELETE CASCADE` — le reviewer l'a remplacé par `RESTRICT` en argumentant une
cohérence avec le soft-delete, **contredisant une exigence explicite du prompt**. Troisième
occurrence cette session (après NR3/ADR-021-G3, PIPE2-orders) d'une revue qui introduit une
régression hors de son mandat en résolvant un problème qu'elle a elle-même identifié.

**Conclusion (T1, N=3, 1 tâche)** : sur une tâche correctement classifiée `solo`, décomposer
quand même ne coûte pas seulement plus cher — dans cet échantillon, ça n'apporte
**strictement rien**, et le doublement des points de défaillance (le reviewer peut introduire
sa propre régression) est un vrai risque, pas juste un coût. C'est la première preuve directe,
sur un instrument fiable, à l'appui de la règle « défaut = 1 agent » de CLAUDE.md — jusqu'ici
affirmée mais jamais mesurée. Ne pas généraliser au-delà de cette tâche/ce domaine (SQL) sans
réplication — mais c'est un résultat concordant avec G3 : la valeur de la décomposition,
quand elle existe, vient de la revue qui recoupe une classe de défaut précise du générateur
(G3), pas de la décomposition en soi ; et sur une tâche déjà bien exécutée en solo, il n'y a
simplement rien à recouper.

**Prochaine étape naturelle** (non engagée) : répliquer sur une tâche que le classifieur
juge `pipeline` à raison (ex. `at-ledger-immutable-double-entry`, complexité réelle :
double-entrée comptable, immutabilité) pour vérifier que la décomposition apporte alors une
vraie valeur — symétrique au test ci-dessus, qui montre l'absence de valeur côté `solo`.

## Addendum — Point 2 symétrique : SOLO vs PIPELINE sur une tâche classifiée pipeline (2026-08-07)

**Contexte** : suite directe de l'addendum Point 2 ci-dessus, qui montrait l'absence de
valeur de la décomposition sur une tâche classifiée `solo`. Réplique symétrique proposée en
clôture de cet addendum : tester la même paire SOLO/PIPELINE sur une tâche que le
classifieur (post-fix C8) juge au contraire digne d'une décomposition —
`at-ledger-immutable-double-entry` (grand-livre comptable double-entrée, immutabilité
append-only, idempotence), classifiée `pipeline` tier 3 via le signal `scope-long` (vérifié
directement dans `tasks-v2.json` : `thresholdAxes.classifierMode: "pipeline"`,
`classifierTier: 3`) — signal légitime, pas un artefact lexical comme
`at-orders-fulfillment-schema` avant le fix C8.

**Protocole** : générateur `db` identique dans les deux conditions, prompt canonique
versionné (`deliverables/at-ledger-immutable-double-entry/PROMPT.txt`). SOLO = `db` seul,
N=3. PIPELINE = `db`(design)+`reviewer`(safety), N=3 — même structure 2-agents que Point 2
et G3.

**Résultat (N=3/condition, sonnet, scorerSha=`git:3e2b99ba23a4ff09b2db6d84425bbc6ef85507af`,
tasksSha=`git:74d155640f33b0bd47888067a8d701ef413d7602`, vérifié directement dans
`results-v2.json`)** :

| Condition | Agents | Scores | Moyenne |
|---|---|---|---|
| SOLO | 1 | 100, 100, 100 | 100 |
| PIPELINE | 2 | 100, 100, 100 | 100 |

**Distribution identique, plafond des deux côtés** — mais ce plafond masque une différence
réelle de robustesse, pas une absence de différence. Les 3 livrables PIPELINE (revue
`reviewer`) signalent indépendamment, sans coordination entre eux, la **même**
vulnérabilité : `ledger_entries` référence `ledger_transactions` par une FK simple sur
`transaction_id`, sans garantir que `ledger_entries.workspace_id` corresponde au
`workspace_id` de la transaction parente référencée — un attaquant authentifié peut
rattacher une écriture comptable à la transaction d'un autre tenant. 0/3 générateurs SOLO
n'a évité ce défaut non plus (le schéma sous-jacent produit par `db` est identique dans les
deux conditions) : la différence n'est donc pas que PIPELINE corrige et SOLO échoue — c'est
que **seul PIPELINE le documente**. La revue le voit, le score ne le voit pas.

**Vérifié directement** : les 10 assertions de `at-ledger-immutable-double-entry`
(`tasks-v2.json`) sont **toutes** en rôle `owner` (aucun champ `role` explicite ≠ défaut
owner) — aucune assertion `role: 'authenticated'` d'isolation parent-enfant, le scorer ne
teste tout simplement pas ce scénario, sur aucun des deux bras. Même classe de trou
d'instrument que celle déjà documentée dans l'addendum Action 2 (calibration) pour
`at-rls-cross-tenant-isolation` (WITH CHECK non isolable du SELECT policy) et pour le GRANT
implicite des tâches `above-threshold` : une exigence de sécurité réelle, non couverte par
une assertion, produit un faux 100/100 identique sur les deux bras.

**Conclusion (T1, N=3, 1 tâche)** : contraste net avec Point 2 (orders). Sur une tâche
correctement classifiée `pipeline`, le score ne sépare **pas** SOLO de PIPELINE (les deux
plafonnent), mais la revue produit une information de sécurité réelle que le scorer actuel
ne peut pas capter — pas parce que PIPELINE serait supérieur « en soi », mais parce qu'une
paire d'yeux supplémentaire recoupe une classe de défaut (isolation multi-tenant
parent-enfant) que le générateur seul ne voit structurellement pas mieux à N=3. Corollaire
direct pour la décision produit : le résultat « distribution identique » ne peut être lu
comme « la décomposition n'apporte rien » **que si le scorer est complet** — ici, il ne l'est
pas, ce qui interdit de généraliser la conclusion du Point 2 (orders) au Point 2 symétrique
(ledger) sans réserve. Ne pas généraliser au-delà de cette tâche/ce domaine (SQL) sans
réplication, et pas avant que l'assertion cross-tenant manquante soit ajoutée (cf. ADR-022
§3, promue priorité n°1 par ADR-023 étape 2).

## Addendum — Test ADAPTIVE (2026-08-07/10) — non-infériorité, pas supériorité

**Contexte** : extension du protocole SOLO/PIPELINE (Point 2 / Point 2 symétrique) à une
troisième condition — un orchestrateur unique, sans template `pipelines.json`, libre de
déléguer à un ou plusieurs sous-agents et de choisir lui-même le modèle de chaque
délégation. Testé sur les 2 mêmes tâches (`at-orders-fulfillment-schema`,
`at-ledger-immutable-double-entry`), N=3/tâche, sous le même instrument que Point 2
(`scorerSha=git:3e2b99ba23a4ff09b2db6d84425bbc6ef85507af`,
`tasksSha=git:74d155640f33b0bd47888067a8d701ef413d7602` — provenance identique aux 12 trials
SOLO/PIPELINE, comparaison légitime au sens de I3).

**Design exact** : 1 orchestrateur par trial, aucune structure de phases imposée, liberté
complète de délégation (0, 1 ou plusieurs sous-agents) et de choix de modèle.

**Résultat brut (vérifié directement dans `results-v2.json`, 6 entrées `arm: ADAPTIVE`)** :

| Tâche | Scores | Modèle enregistré (par trial) |
|---|---|---|
| orders | 100, 100, 100 | sonnet, **opus**, sonnet |
| ledger | 100, 100, 100 | sonnet, sonnet, sonnet |

**6/6 = 100.**

### Section critique — obligatoire, non édulcorée

1. **Violation du gate de pouvoir discriminant (principe #5bis)**. Les deux tâches utilisées
   sont explicitement nommées dans le présent document, §5bis (« Application immédiate,
   2026-08-06 »), comme faisant partie des 3 tâches `above-threshold` sur 4 restées 100/100
   sur les deux bras testés à l'époque et marquées **`non-discriminantes`** — « conservées
   pour la régression, exclues du corpus décisionnel tant qu'elles ne discriminent rien ». Le
   test ADAPTIVE a ajouté un troisième bras précisément sur ces deux tâches interdites de
   corpus décisionnel. Le principe #5bis dit explicitement pourquoi c'est un problème :
   « répéter 5× une mesure plafonnée ne produit aucune information, seulement 5× le coût » —
   ici N=3, même logique. Ce n'est pas une erreur d'exécution isolée, c'est un run qui
   contourne un garde-fou que ce protocole avait lui-même posé quatre jours plus tôt.
2. **Modèle non tenu constant (violation du principe #3)**. Sur les 3 trials ADAPTIVE de
   `at-orders-fulfillment-schema`, le champ `model` enregistré est `sonnet`, `opus`, `sonnet`
   (runId `20260807T053809-3utmiu` pour le trial `opus`) — vérifié directement dans
   `results-v2.json`. Un bras censé être comparé à SOLO/PIPELINE (tous deux mesurés en
   `sonnet` constant) contient donc un tirage sur un modèle différent, non contrôlé.
   Explication avancée mais **non vérifiée indépendamment depuis les données disponibles
   ici** : le champ `model` serait un artefact de traçabilité (mauvais flag passé au CLI de
   scoring) plutôt qu'un changement réel du modèle de l'orchestrateur — plausible, mais
   invérifiable à partir de `results-v2.json` seul, puisque ce champ est un scalaire unique
   par trial et qu'un bras multi-modèle par construction (l'orchestrateur peut déléguer à
   plusieurs modèles dans un même trial) n'est de toute façon pas descriptible par un seul
   scalaire. Statut correct : **provenance lossy**, pas une confirmation de constance de
   modèle.
3. **Coût non mesuré (G6 absent)**. Vérifié directement : aucune des 46 entrées de
   `results-v2.json`, ADAPTIVE compris, ne porte de champ token/coût/temps/nombre d'appels
   agent — les seules clés présentes sont `taskId, category, arm, score, detail, ts, runId,
   scorerSha, tasksSha, model`. Sur les 6 trials ADAPTIVE, une partie a délégué (dont un
   trial en `opus`, mécaniquement plus coûteux) — sans mesure, impossible de savoir si
   ADAPTIVE coûte comme SOLO, comme PIPELINE, ou davantage. Un bras dont le coût est inconnu
   ne peut pas être déclaré gagnant d'un arbitrage coût/qualité : au mieux, il est à égalité
   de qualité et de coût inconnu.
4. **Saturation du design**. Sur `ledger`, les 3 bras (SOLO, PIPELINE, ADAPTIVE) sont à
   100/100 avant même ADAPTIVE — information nulle (confirmé ci-dessus, addendum Point 2
   symétrique). Sur `orders`, l'écart entre ADAPTIVE (100,100,100) et SOLO (100,91,100) tient
   à un **seul trial** de référence (SOLO2=91). À N=3 sur une échelle plafonnée, le principe
   #2 de ce protocole exige une séparation **complète** à N≥5 pour conclure une supériorité —
   un score parfait sur un design qui ne pouvait structurellement pas produire d'échec
   (tâches non-discriminantes) n'est pas une preuve de supériorité, c'est le résultat attendu
   même si ADAPTIVE n'apportait rigoureusement rien.
5. **Conclusion correcte** : **non-infériorité observée**, pas une supériorité prouvée.
   ADAPTIVE n'a pas fait pire que SOLO ou PIPELINE sur ces 2 tâches — c'est tout ce que ce
   design pouvait établir, et c'est déjà moins que ce qu'un 6/6 à 100 suggère intuitivement.
   Toute lecture « ADAPTIVE bat le template » à partir de ces seules données répète l'erreur
   méthodologique que ce protocole existe pour empêcher.

**Ce que le test suggère malgré tout, avec réserve** : 0/6 régression hors mandat côté
ADAPTIVE, contre 3 occurrences mesurées côté template (NR3, PIPE2-orders, `op`→`operation`).
Signal réel, mais confondu : la variable qui change n'est pas « adaptatif vs template »,
c'est la formulation du mandat de revue (large et cohérent avec la permission d'édition,
contre mandat étroit + permission large dans le template actuel) — reproductible par un
simple changement de prompt dans `pipelines.json` (amélioration n°1, ADR-022), sans changer
d'architecture.

**Décision d'architecture qui en découle** : voir ADR-023 (option D, hybride asymétrique par
nature de phase) — non dupliqué ici. Le présent addendum se limite au résultat brut et à ses
limites ; ADR-023 porte la lecture critique complète et la recommandation d'architecture,
cohérente avec la section critique ci-dessus.

## CORRECTION — l'addendum « Point 2 symétrique » ci-dessus contient une erreur factuelle (2026-08-10)

En exécutant l'étape 2 du plan ADR-023 (assertions discriminantes sous rôle `authenticated`),
les 6 vrais livrables du Point 2 symétrique (`P2BSOLO1-3`, `P2BPIPE1-3-final`) ont été
retrouvés (ils ne dormaient qu'en `/tmp`, jamais rapatriés dans le dépôt — gap corrigé) et
réexaminés directement, ligne par ligne, plutôt que résumés de mémoire.

**L'affirmation « les 3 livrables PIPELINE signalent indépendamment... la même
vulnérabilité » est fausse.** Vérifié sur le SQL réel : `P2BPIPE1-final` et `P2BPIPE3-final`
ont bien une FK composite `(transaction_id, workspace_id) → ledger_transactions(id,
workspace_id)` — la revue a trouvé et corrigé la faille. **`P2BPIPE2-final` a gardé la FK
simple `transaction_id → ledger_transactions(id)`**, vulnérable : son reviewer (`p2b-pipe2-
safety`) a bien produit une revue de qualité (idempotence, rollback, invariant
Σdebit=Σcredit, immutabilité des colonnes d'en-tête) mais **n'a jamais mentionné ni corrigé
l'isolation cross-tenant**. Le taux réel est **2/3, pas 3/3**.

**Confirmé empiriquement, pas seulement relu** : après ajout de l'assertion `role:
authenticated` correspondante (`tasks-v2.json`), score de chaque livrable sous l'instrument
corrigé (`scorerSha=git:e600307…`) :

| Condition | Scores individuels | Moyenne |
|---|---|---|
| SOLO (P2BSOLO1/2/3) | 91, 91, 91 | 91 |
| PIPELINE (P2BPIPE1/2/3-final) | 100, **91**, 100 | 97 |

**Ce que ça change** : la conclusion « le score ne sépare pas SOLO de PIPELINE » de
l'addendum original ne tient plus sous l'instrument corrigé — il y a maintenant un écart
réel (91 vs 97), quoique non séparé au sens du principe #2 (2/3 PIPELINE à 100, pas 3/3).
Ceci correspond exactement à la 1ʳᵉ issue pré-enregistrée de l'étape 2 d'ADR-023
(« PIPELINE > SOLO ») — mais l'écart tient sur un design N=3 avec un reviewer sur trois qui
a raté la faille : la revue **réduit** le risque sans le supprimer, ce qui est cohérent avec
G3 (la valeur d'une revue dépend de si elle recoupe la classe de défaut, pas d'une garantie
systématique). Le résultat officiel de l'étape 2 (SOLO/PIPELINE/ADAPTIVE, modèle tenu
constant, sur les 2 tâches) reste à documenter séparément une fois complet — ceci n'est
qu'une correction du tableau du Point 2 symétrique original, pas encore l'étape 2b.

**Leçon de processus** : cette erreur venait d'une synthèse (« 3 reviewers, même signal »)
non vérifiée contre le SQL réel au moment de l'écrire — exactement le type d'erreur que ce
protocole existe pour intercepter avant qu'elle ne devienne une décision. Elle a été
détectée en retrouvant et rescanant les livrables originaux, pas en faisant confiance au
rapport d'un agent.

## Addendum — Étape 2b (ADR-023) : résultat officiel SOLO/PIPELINE/ADAPTIVE sous instrument corrigé (2026-08-10)

Exécution de l'étape 2 du plan ADR-023 : assertions discriminantes ajoutées (isolation
cross-tenant `authenticated` sur `orders` et `ledger`, cf. correction ci-dessus), puis
re-score des **18 trials réels déjà générés** (aucune nouvelle génération — les mêmes
livrables du Point 2 et Point 2 symétrique, générateur et modèle inchangés, c'est
exactement ce que permet de faire une amélioration d'instrument sans reproduire l'
expérience). Provenance unique (`scorerSha=git:e600307…`), modèle `sonnet` tenu constant
sur les 18 trials (corrige au passage le mistag `opus` d'un trial ADAPTIVE-orders,
confirmé être un artefact de flag CLI, pas un changement réel de modèle).

| Tâche | SOLO | PIPELINE | ADAPTIVE |
|---|---|---|---|
| `at-orders-fulfillment-schema` | 100,91,100 (μ=97) | 100,91,100 (μ=97) | 100,100,100 (μ=100) |
| `at-ledger-immutable-double-entry` | 91,91,91 (μ=91) | 100,91,100 (μ=97) | 100,100,91 (μ=97) |

**`orders` : inchangé.** L'assertion d'isolation existait déjà sous `owner` et discriminait
déjà (91 sur SOLO2/PIPELINE2) ; la faire passer sous `authenticated` ne change aucun score
— confirmation de non-régression, pas d'information nouvelle. Toujours pas de séparation
SOLO/PIPELINE sur cette tâche.

**`ledger` : discrimine pour la première fois.** Sous l'ancien instrument (aveugle à
l'isolation cross-tenant), SOLO=PIPELINE=100/100/100 (tâche `non-discriminante`, §5bis).
Sous l'instrument corrigé : **SOLO (91,91,91, σ=0) < PIPELINE (100,91,100, μ=97) ≈ ADAPTIVE
(100,100,91, μ=97)**. Par la lettre de la règle pré-enregistrée d'ADR-023 (étape 2, issue 1 :
« PIPELINE > SOLO et ADAPTIVE ≥ PIPELINE → D confirmé »), cette issue est atteinte sur
`ledger`.

**Réserve statistique honnête, à ne pas dépasser** : ce n'est **pas** une séparation
complète au sens du principe #2 (N≥5, 5/5 dans la direction attendue) — c'est un résultat
T1 (N=3), légitime pour ce niveau de preuve mais pas plus. SOLO échoue 3/3 (σ=0, mécanisme
systématique : FK simple partout, jamais de garde compensatoire) ; PIPELINE et ADAPTIVE
échouent chacun 1/3 — un test exact sur 2/3 succès vs 0/3 n'est pas significatif au sens
classique à cet effectif. Le signal directionnel est cohérent et explicable (voir
mécanisme ci-dessous), mais N=3 ne permet pas d'exclure que le point d'écart (1 trial sur 3)
soit du bruit. **Statut correct : hypothèse renforcée pour la 2ᵉ fois consécutive (après
G3), pas une séparation prouvée.**

**Mécanisme observé, cohérent avec G3** : les 2 échecs de PIPELINE/ADAPTIVE ont chacun une
cause identifiable et différente de « la décomposition en soi » :
- `P2BPIPE2-final` (échec PIPELINE) : le reviewer a produit une revue de qualité sur
  d'autres points (idempotence, rollback, invariant Σdebit=Σcredit) mais n'a jamais examiné
  l'isolation cross-tenant — un défaut de **couverture du mandat**, pas de l'architecture.
- `ADAPT3` (échec ADAPTIVE) : ce trial a explicitement choisi de **ne pas déléguer**
  (« tâche unique, précise et complète, un seul passage suffit » — décision de l'agent,
  documentée dans son propre rapport) et a produit seul le même défaut qu'un SOLO. Sans
  second regard, même mécanisme de risque qu'un SOLO, peu importe que l'architecture soit
  « pipeline figé » ou « adaptatif » : **c'est l'absence de second regard qui coûte, pas
  l'absence de template.**

**Conséquence pour ADR-023** : le §risque n°1 d'ADR-023 (« si l'assertion manquante est
ajoutée et que PIPELINE se met à battre SOLO sur `ledger`… cette moitié de D doit être
réexaminée ») est en partie confirmé — PIPELINE bat désormais SOLO sur `ledger`. Mais le
mécanisme identifié ci-dessus (mandat de couverture, pas architecture) est cohérent avec la
recommandation D elle-même (décomposition-qualité → adaptatif à mandat **cohérent**, pas
retour au template figé) : ADAPTIVE échoue exactement de la même façon que PIPELINE quand
il choisit de ne pas déléguer — ce n'est pas un argument pour le template, c'est un
argument pour garantir qu'une revue a bien lieu et couvre le bon périmètre, quelle que soit
l'architecture. Voir mise à jour du statut dans ADR-023.
