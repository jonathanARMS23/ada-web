# ADR-022 — Décision : que retirer/améliorer sur le routing et la décomposition d'ADA

## Statut

Accepté (2026-08-07). Fondé sur les mesures de `docs/adr/ADR-021-protocole-evaluation-rigoureux.md`
(T1, G3, points 2 et 2-symétrique) — instrument calibré (Action 2), corpus 3 domaines
(Action 3), classifier corrigé (11 bugs router/classifier + C8).

## Contexte

Question ouverte depuis le début de cette série de sessions : « ADA ne sert à rien ? ».
Les bras C/D d'ADR-019 (valeur du routing, ROI de la décomposition) n'ont jamais eu de
données exploitables — classifier à 11 bugs, scorer non calibré, données purgées. Ce
document synthétise les 4 expériences qui répondent enfin à la question avec un instrument
fiable, et tranche ce qu'on retire, ce qu'on garde, ce qu'on améliore.

## Preuves (résumé — détail complet dans ADR-021)

| Expérience | Tâche | Classification | Générateur | SOLO/NATIF | +REVUE/PIPELINE | Lecture |
|---|---|---|---|---|---|---|
| T1/G3 | audit-trigger (SQL) | pipeline (avant fix C8) | `general-purpose` | 92,92,92 | 100,75,75 | revue régresse (spec `op`→`operation` hors mandat) |
| T1/G3 | audit-trigger (SQL) | — | `db` | 50,50,92 | 100,100,100 | revue répare un défaut sévère répété (SECURITY DEFINER manquant 2/3) |
| Point 2 | orders (SQL) | **solo** (après fix C8) | `db` | 100,91,100 | 100,91,100 | **distribution identique** ; revue introduit une régression de spec (CASCADE→RESTRICT) dans 1/3 |
| Point 2 symétrique | ledger (SQL) | **pipeline** (signal légitime) | `db` | 100,100,100 | 100,100,100 | **distribution identique au score**, MAIS 3/3 revues trouvent indépendamment une vraie faille d'isolation cross-tenant (FK simple sur `transaction_id`) que 0/3 générateurs solo n'évitent — invisible au scorer actuel |

## Décision

### 1. Retiré / confirmé à ne PAS faire par défaut

**Le fan-out automatique sur une tâche classifiée `solo` n'a plus besoin d'être une simple
affirmation de CLAUDE.md — c'est maintenant mesuré.** Sur `at-orders-fulfillment-schema`
(3 tables, RLS, correctement classifiée solo après fix C8), décomposer double le coût en
appels d'agent pour un gain de qualité mesuré de **zéro**, avec un risque net supplémentaire
(la revue a introduit une régression de spec dans 1/3 trials). **Rien à retirer ici — la
règle « défaut = 1 agent » de CLAUDE.md est confirmée, pas remise en cause.** Ce qui change :
elle passe du statut « principe de bon sens non vérifié » à « mesuré, T1, N=3, 1 domaine ».

### 2. Amélioration n°1 — border le mandat de la phase `safety`/reviewer

**Constat** : sur 3 expériences distinctes cette session, une revue « safety check » a
introduit une régression en résolvant un problème **hors de son mandat déclaré**
(idempotence/rollback/RLS) :
- NR3 (ADR-021 G1/G3) : `ALTER FUNCTION ... OWNER TO postgres` pour un souci d'ownership —
  non nécessaire, a cassé la migration sur l'environnement de test.
- PIPE2-orders (point 2) : `ON DELETE CASCADE` → `RESTRICT` pour une cohérence perçue avec
  le soft-delete — **contredit une exigence explicite du prompt**.
- Sur `at-audit-soft-delete-trigger`, la revue scopée « safety » n'a jamais rattrapé la
  déviation de spec `op`→`operation` (hors de son mandat, mais cette fois à raison — elle
  n'aurait pas dû corriger un point business).

**Le problème n'est pas que la revue trouve des choses hors mandat — c'est qu'elle les
CORRIGE au lieu de les SIGNALER.** Une revue qui modifie une décision qui n'est ni un trou
de sécurité ni un bug d'idempotence/réversibilité crée un nouveau risque sans qu'on l'ait
demandé.

**Action** : reformuler le prompt de la phase `safety` (pipelines.json, agent `reviewer`)
pour distinguer explicitement :
- **Corrige directement** : RLS manquante/cassée, isolation multi-tenant, injection,
  secrets en dur, idempotence de la migration, réversibilité.
- **Signale sans corriger** : tout écart avec le spec explicite du prompt (contraintes
  ON DELETE, noms de colonnes, comportements métier) — même si l'écart semble une
  amélioration. Charge à l'orchestrateur ou à l'humain de trancher.

Coût : modification de prompt uniquement, pas de nouveau mécanisme. Impact attendu : élimine
la classe de régression observée 3 fois cette session sans perdre la valeur de détection.

### 3. Amélioration n°2 — étendre le scorer : cohérence workspace_id parent-enfant

**Constat** : sur `at-ledger-immutable-double-entry`, **3 reviewers indépendants** (agents
différents, aucune coordination) ont trouvé la **même** vulnérabilité — une FK simple entre
une table enfant et sa table parente ne garantit pas que `workspace_id` de l'enfant
corresponde à celui du parent référencé, permettant à un attaquant authentifié de rattacher
une ligne à une ressource d'un autre tenant. **0 des 3 générateurs solo n'a évité ce défaut.**
C'est exactement le type de bug de sécurité multi-tenant le plus coûteux à découvrir en
production (silencieux, pas d'erreur applicative, juste une donnée mal rattachée).

Le scorer actuel ne teste PAS ce scénario (aucune assertion `[authenticated][isolation]` ne
vérifie qu'une FK enfant→parent est bien composite sur `workspace_id`) — c'est pour ça que
SOLO et PIPELINE affichent tous les deux 100/100 malgré la différence réelle de robustesse.

**Action** : ajouter à `at-orders-fulfillment-schema`, `at-ledger-immutable-double-entry` (et
tout futur tâche `above-threshold` avec relation parent-enfant multi-tenant) une assertion
`role:'authenticated'` qui tente d'insérer une ligne enfant avec `workspace_id = $WS1` mais
`parent_id` pointant vers une ligne parente de `$WS2`, et vérifie le rejet. Pattern
généralisable, à ajouter au harnais de calibration (Action 2) comme nouvelle catégorie de
fixture négative.

### 4. Ce qui reste correct et n'est PAS remis en cause

- Le principe de classification solo/pipeline lui-même (l'architecture du classifier) — les
  bugs trouvés (11 + C8) étaient des erreurs d'implémentation, pas un défaut de conception.
  Aucune preuve que l'approche « classifier une tâche puis router » soit la mauvaise
  architecture.
- Le tier-routing (choix du modèle par tier) n'a pas été retesté ici — reste une question
  ouverte, hors périmètre de cette décision (voir Prochaines étapes).
- Le scorer SQL et son harnais de calibration (Action 2) — solides, aucun défaut trouvé sur
  cette série d'expériences (contrairement aux séries précédentes).

## Conséquences

- CLAUDE.md n'a pas besoin d'être modifié sur la règle « défaut = 1 agent » — confirmée.
- `pipelines.json` / prompt de la phase `safety` à reformuler (amélioration n°1) — travail
  de prompt-engineering, pas de nouveau code.
- `tasks-v2.json` + `calibration/` à étendre avec le pattern d'assertion cross-tenant
  parent-enfant (amélioration n°2) — travail de test, pas de changement produit.
- Aucun retrait de mécanisme ADA n'est justifié par les données actuelles. La conclusion
  n'est pas « ADA ne sert à rien » ni « ADA marche toujours » — c'est : **la valeur de la
  décomposition est conditionnelle et mesurable**, pas un acquis universel. Le produit doit
  arrêter de vendre le fan-out comme une garantie de qualité et le présenter comme ce qu'il
  est : un filet de sécurité pour une classe précise de défauts (RLS/isolation/sécurité),
  qui ne coûte rien à avoir quand il ne sert pas (voir amélioration n°1) et qui rate des
  bugs sérieux de multi-tenance quand on ne teste pas pour (amélioration n°2).

## Prochaines étapes (non engagées)

1. Implémenter amélioration n°1 (reformulation prompt `safety`) et n°2 (assertion
   cross-tenant parent-enfant), puis re-mesurer point 2 et point 2-symétrique pour vérifier
   que n°2 fait apparaître une vraie différence SOLO vs PIPELINE sur `ledger`.
2. Tester le tier-routing (bras C historique, jamais mesuré avec cet instrument) :
   est-ce que le choix automatique de tier/modèle bat un tier fixe à qualité égale ou
   moindre coût ?
3. Répliquer sur les domaines TS/Docker (Action 3) pour vérifier que la conclusion « solo
   suffit sur une tâche bien classifiée » se généralise hors SQL.
4. T2 (multi-modèle) si une affirmation commerciale ou un retrait irréversible est envisagé
   — non nécessaire pour les décisions ci-dessus, qui sont des améliorations internes.
