# ADR-023 — Architecture cible d'orchestration : que devient le mécanisme routing/décomposition d'ADA

**Date** : 2026-08-10
**Statut** : Proposé — option **D** (hybride asymétrique par nature de phase) **confirmée par l'étape 2**
(voir « Mise à jour post-étape 2 » en fin de document), engagement toujours **partiel** (étapes 0-5 faites —
voir « Mise à jour étapes 4-5 » —, étape 6/T2 reste conditionnée). Aucun pipeline retiré par ce document.
**Niveau de preuve disponible** : **T1** (N=3, 1 modèle, corpus décisionnel SQL). Pas T2. Aucune
affirmation commerciale n'est autorisée par ce document.
**Décideurs** : Jonathan Arms
**Remplace partiellement** : ADR-022 (§4 dépassé, §2 reformulé, §3 corrigé factuellement — voir « Statut d'ADR-022 »)

---

## Contexte

Question ouverte depuis le début de cette série de sessions : **le mécanisme d'orchestration d'ADA
(classifieur solo/pipeline + 13 templates figés dans `pipelines.json`) produit-il de la valeur ?**

Cinq expériences y répondent maintenant avec un instrument calibré (ADR-019 → ADR-021 → ADR-022 → test
ADAPTIVE non encore documenté). Ce document synthétise l'ensemble, tranche entre 4 options d'architecture
cible, et séquence la mise en œuvre.

### Synthèse des preuves (détail : ADR-019 / ADR-021)

| # | Expérience | Tâche / domaine | Conditions | Résultat | Ce que ça établit |
|---|---|---|---|---|---|
| 1 | ADR-019 ablation A→D | corpus mixte SQL | A / B / C / D | `B−A` = +8,3 puis +12,3 (run ciblé : A=87,7 → B=100) · **`C−B` = 0** · **`D−C` = 0** | mémoire = seul driver de valeur prouvé ; routing et décomposition n'apportent rien **sous le seuil** |
| 2 | ADR-021 T1/G3 (plan 2×2) | `at-audit-soft-delete-trigger` | générateur × revue | `general-purpose` : 92,92,92 (μ=92, σ=0) → +revue 100,75,75 (μ=83,3, σ≈11,8) · `db` : 50,50,92 (μ=64, σ≈19,8) → +revue 100,100,100 (μ=100, σ=0) | **la valeur de la revue interagit avec le générateur** : elle répare quand elle recoupe la classe de défaut du générateur, elle **dégrade** sinon |
| 3 | ADR-021 Point 2 | `at-orders-fulfillment-schema` (classifiée `solo` après fix C8) | SOLO vs PIPELINE, générateur `db` constant | 100,91,100 (μ=97) **vs** 100,91,100 (μ=97) | sur une tâche bien classifiée solo, décomposer coûte 2× et apporte **zéro** ; le reviewer a introduit sa propre régression (CASCADE→RESTRICT, contre le prompt) |
| 4 | Point 2 symétrique | `at-ledger-immutable-double-entry` (classifiée `pipeline` à raison) | idem | 100,100,100 **vs** 100,100,100 | plafond total ; mais 3/3 reviewers trouvent indépendamment une faille d'isolation cross-tenant (FK simple) que 0/3 générateurs solo n'évitent — **invisible au scorer** |
| 5 | **ADAPTIVE** (ce document) | orders + ledger | 1 orchestrateur libre de déléguer et de choisir son modèle | **6/6 = 100** | voir lecture critique ci-dessous — **non-infériorité sur des tâches non-discriminantes**, pas une supériorité |

### Ce que les données établissent

1. **La décomposition n'est pas une source de qualité en soi.** `D−C = 0` (exp. 1), distribution identique
   en Point 2 (exp. 3) et Point 2 symétrique (exp. 4). Trois mesures indépendantes, même conclusion.
2. **Quand la décomposition paie, c'est par la revue, et conditionnellement** (exp. 2) : `db`+revue
   64 → 100 parce que `db` produit exactement la classe de défaut (`SECURITY DEFINER` manquant) que le
   reviewer « safety » détecte. Le même reviewer fait **baisser** `general-purpose` de 92 à 83,3.
3. **Une classe de régression est identifiée et reproduite 3 fois** (NR3, PIPE2-orders, `op`→`operation`) :
   un reviewer à **mandat déclaré étroit** mais **permission d'édition large** corrige hors mandat et
   contredit le spec explicite.
4. **La mémoire reste le seul driver de valeur prouvé**, et de façon localisée : conventions non-standard
   ou contre-défaut (RLS, outbox divergent), pas les conventions SaaS génériques que `sonnet` connaît déjà.

### Ce que les données n'établissent pas (et qui pèse sur toute décision ici)

- **Le tier-routing n'a jamais été mesuré** (G10, ADR-021). Le choix automatique de modèle est un
  mécanisme actif, non prouvé.
- **Aucune métrique d'efficience n'est capturée** (G6). Vérifié directement : `results-v2.json` n'a
  **aucun** champ token / coût / temps / nombre d'appels agent sur ses 46 entrées. Les principes #9 et #10
  d'ADR-021 sont déclarés et non implémentés. **Toute conclusion coût/latence de cette session est une
  estimation en appels d'agent, pas une mesure.**
- **Mono-modèle** (`sonnet`) sur la quasi-totalité des mesures (G11), et **corpus décisionnel 100 % SQL** —
  les domaines TS et Docker sont outillés (Action 3) mais n'ont **jamais servi à une décision**.
- **Dette de traçabilité** : l'addendum « Point 2 symétrique » n'existe pas dans ADR-021 ; il n'apparaît
  que résumé dans le tableau d'ADR-022. Le test ADAPTIVE n'est documenté nulle part avant ce document.
- **Hygiène de l'instrument** : `results-v2.json` contient 5 entrées `PIPELINE` pour
  `at-orders-fulfillment-schema` réparties sur 2 `scorerSha` (`git:6b9629cd…` et `git:3e2b99ba…`) — soit
  exactement la « cellule ambiguë » que I3 avait câblé `report` pour **refuser**. Le garde-fou existe ; les
  données le déclenchent.

---

## Lecture critique du test ADAPTIVE (vérifiée sur `results-v2.json`, pas prise sur parole)

**Ce qui est propre.** Les 6 trials ADAPTIVE partagent `tasksSha = git:74d155640f…` et
`scorerSha = git:3e2b99ba23…` avec les 6 SOLO et les 6 PIPELINE du Point 2 / Point 2 symétrique. La
comparaison est légitime au sens de I3 : même instrument, même corpus, provenance enregistrée.

**Ce qui interdit d'y lire une supériorité :**

1. **Les deux tâches sont déclarées `non-discriminantes` par le protocole lui-même.** ADR-021 §5bis
   (gate F2) les nomme explicitement — avec `at-rls-cross-tenant-isolation` — comme 100/100 sur les deux
   bras, « conservées pour la régression, **exclues du corpus décisionnel** ». Le test ADAPTIVE a donc
   **violé le gate 5bis** : il a ajouté un troisième bras sur des tâches que le protocole avait interdites
   au corpus décisionnel, précisément parce que « répéter une mesure plafonnée ne produit aucune
   information, seulement le coût ». À reconnaître, pas à contourner.
2. **Le résultat est saturé par construction.** Sur `ledger`, les 3 bras font 100/100 : information nulle.
   Sur `orders`, ADAPTIVE 100,100,100 vs SOLO 100,91,100 — l'écart tient à **un seul trial** du bras de
   référence. À N=3 sur une échelle plafonnée, aucun test ne sépare ; le principe #2 d'ADR-021 exige une
   séparation **complète à N=5** pour conclure une supériorité. Statut correct : **non-infériorité
   observée**, ce qui est le maximum que ce design pouvait produire — y compris si ADAPTIVE n'apportait
   rien du tout.
3. **Le modèle n'est pas tenu constant** (violation du principe #3). L'un des 3 trials ADAPTIVE sur
   `orders` est enregistré `model: "opus"`, les cinq autres `"sonnet"`. Un bras multi-modèle par
   construction n'est de toute façon pas décrit par un champ scalaire `model` : la provenance est ici
   **lossy**, et la constance du modèle face à des bras `sonnet` n'est pas vérifiable depuis les données.
4. **Le coût n'est pas mesuré.** 4/6 trials ont délégué (dont une revue `opus`). Faute de G6, on ne sait
   pas si ADAPTIVE coûte comme SOLO, comme PIPELINE, ou plus. **Un bras dont on ne connaît pas le coût ne
   peut pas gagner un arbitrage coût/qualité** — c'est la moitié manquante de l'équation.
5. **Biais de confirmation à signaler explicitement.** Ce test a été conçu pour éprouver une intuition, et
   il l'a confirmée 6/6, sans un seul échec. Sur des tâches déjà plafonnées, l'absence totale d'échec n'est
   pas une force du design : c'est le symptôme que **le design ne pouvait pas échouer**. Un résultat
   parfaitement flatteur mérite une suspicion proportionnelle.

**Le seul signal réellement neuf** : 0/6 régression hors mandat côté ADAPTIVE, contre 3 occurrences
mesurées côté template. Mais la variable qui change n'est pas « adaptatif vs template » — c'est la
**formulation du mandat de revue** (large « trouve et corrige » vs étroit « safety check » avec permission
d'édition large). Confond non isolé. Et il est **reproductible par un simple changement de prompt dans le
template existant** : c'est mot pour mot l'amélioration n°1 d'ADR-022.

**Insight de synthèse** : le défaut n'est pas la largeur du mandat, c'est son **incohérence avec la
permission d'édition**. Deux résolutions symétriques ferment la même classe de régression — (i) réduire la
permission au mandat (ADR-022 n°1 : signaler sans corriger), (ii) élargir le mandat à la permission
(ADAPTIVE). Le template actuel était simplement incohérent : mandat étroit, permission large.

---

## L'argument de fond contre le mécanisme actuel — et il ne vient pas d'ADAPTIVE

Le résultat le plus structurant de la session est **G3** (exp. 2), pas ADAPTIVE :

> la valeur d'une étape de revue dépend de la **classe de défaut effectivement produite par le générateur**.

Or le classifieur décide du nombre d'agents **avant** la génération, à partir du **texte de la description**.
L'information qui détermine la valeur de la décomposition (quel défaut le livrable contient-il ?) n'existe
pas encore au moment où la décision est prise. Ce n'est pas un bug à corriger — c'est une **inadéquation
informationnelle structurelle** : aucune amélioration du classifieur lexical ne peut y remédier. Seule une
entité qui a le livrable sous les yeux peut trancher utilement.

C'est cet argument — T1, indépendant du test ADAPTIVE, indépendant de tout résultat flatteur — qui fonde la
décision ci-dessous. ADAPTIVE ne le prouve pas ; il est simplement **compatible** avec lui.

---

## Options évaluées

### (A) Statu quo — garder les 13 pipelines figés

**Bénéfices** : coût de changement nul. Préserve ce qui, dans `pipelines.json`, n'est **pas** de la
décomposition-qualité et n'a jamais été remis en cause par aucune mesure : `onFailure: "stop"`,
`stopOnFailure`, `maxRetries`, `depends` (DAG réel), `skipIf: ["--dry-run"]`, `rollbackPhase`,
`rollbackOnFailure`, `outputKey`. Préserve le point d'ancrage de `budget-guard` (appelé depuis
`run.js:811/813` à chaque frontière de phase) et le tier-0 codemod ($0, ~1 ms, aucun agent).

**Coûts** : 2 à 3× les appels d'agent sur des tâches où le gain mesuré est **nul** (exp. 1, 3, 4) ;
conserve la classe de régression hors mandat (mesurée 3×) ; **11 des 13 templates n'ont jamais été mesurés
du tout** — seuls `migration` (partiellement, et jamais au-delà de 2 phases sur 4, cf. G3) et une
structure 2-agents ad hoc l'ont été.

**Risque principal** : continuer à présenter le fan-out comme une garantie de qualité est une affirmation
que **nos propres mesures contredisent**. Un client technique qui teste lui-même le constatera — motif déjà
rencontré sur la mémoire (ADR-019, « ne pas vendre : la mémoire améliore tout de X % »).

**Verdict** : rejeté comme cible. **Retenu comme socle transitoire** (aucun retrait immédiat).

### (B) Remplacer le routing/décomposition par un orchestrateur ADAPTIVE

**Bénéfices** : 6/6 à 100 sans template ; comportement de délégation observé raisonnable (4/6 délèguent,
2/6 jugent un passage suffisant, 100 dans les deux cas) ; supprime l'entretien de 13 templates ; ferme la
classe de régression par cohérence du mandat ; résout l'inadéquation informationnelle ci-dessus (décision
prise après avoir vu le livrable).

**Coûts et pertes — ce qui disparaîtrait avec les templates, et qui n'est pas de la qualité :**

1. **Le plan de contrôle du coût.** `budget-guard` est **phase-keyed** : `checkBudget(runId, phaseCost,
   cumulCost, …)` et `recordCost` sont appelés aux frontières de phase depuis `run.js`. Un orchestrateur
   qui délègue via l'outil Agent en session ne franchit **aucune** frontière de phase → plus de plafond,
   plus de `recordCost`. On remplacerait le seul mécanisme de gouvernance de coût par un agent qui décide
   lui-même de dépenser, y compris en `opus`. Et la télémétrie qui permettrait de le constater est
   justement celle qui manque (G6).
2. **Les contrats d'exécution.** Un prompt ne garantit pas un `rollbackPhase`, un `stopOnFailure`, ni un
   `skipIf --dry-run`. Un DAG déclaré, oui. Ces garanties ne portent pas sur la qualité du livrable mais
   sur la **réversibilité d'un effet de bord** — dimension entièrement absente de tout ce qui a été mesuré.
3. **Le tier-0 codemod** ($0, aucun agent) court-circuite aujourd'hui tout le reste dans
   `classifyTask`. Si l'orchestrateur devient le point d'entrée, ce chemin gratuit est perdu.
4. **La prévisibilité et la reproductibilité.** La structure d'exécution devient un tirage stochastique
   (2/6 vs 4/6 sur la même tâche). Conséquence sous-estimée : **le protocole ADR-021 lui-même suppose des
   conditions comparables entre trials.** Un défaut de production ne serait plus rejouable à structure
   identique, et la comparabilité longitudinale — base de tout ce travail — s'effondre.
5. **Risque de sur-délégation : non mesuré.** Décider ce point sans la mesure serait exactement la faute
   que ADR-021 existe pour empêcher.

**Niveau de preuve** : T1, N=3, 2 tâches, 1 domaine, **tâches déclarées non-discriminantes**, modèle non
tenu constant. Un remplacement du chemin de routing est un changement à réversibilité moyenne (code +
docs + habitudes). Insuffisant.

**Verdict** : **rejeté maintenant — pas réfuté, sous-mesuré.** Devient la cible de la partie
« qualité » sous l'option D, sous conditions.

### (C) Hybride par domaine (pipelines pour CI/CD et migrations, adaptatif pour la génération de code/schéma)

L'intuition est juste, **le critère de découpage est le mauvais axe**. `migration`, `db-migrate` et
`data-migration` sont du **SQL** — le domaine précis où l'on a mesuré que la décomposition n'apporte rien
en qualité. Ce qui les distingue n'est pas le domaine mais l'**effet de bord irréversible** (`apply`,
`deploy`, `migrate-data`). Un découpage par domaine classerait `api-design` (zéro effet de bord) côté
pipeline, et laisserait côté adaptatif des tâches à effet de bord réel.

**Verdict** : rejeté au profit de D — même esprit, critère corrigé.

### (D) Hybride asymétrique par **nature de phase** — RECOMMANDÉ

`pipelines.json` confond aujourd'hui deux fonctions qu'il faut séparer :

| Fonction | Statut mesuré | Cible |
|---|---|---|
| **Décomposition-qualité** — enchaîner design → revue pour améliorer un livrable | valeur **nulle** (exp. 1, 3, 4) ou **conditionnelle et non prédictible avant génération** (exp. 2 / G3) | **adaptatif** : l'orchestrateur décide s'il délègue une revue, avec **mandat cohérent** (large, « trouve et corrige », interdiction explicite de toucher à ce que le prompt spécifie nommément) |
| **Décomposition-contrat** — phases à effet de bord externe irréversible, ou porteuses d'une garantie de réversibilité (`apply`, `deploy`, `migrate-data`, `rollbackPhase`, `skipIf --dry-run`) | **jamais mesuré, jamais contesté** — ce n'est pas de la qualité, c'est du contrôle d'exécution | **reste un DAG déclaré**, non négociable par un agent |

Et le classifieur **reste**, réduit à ses trois rôles défendables : (a) tier-0 codemod ($0) ; (b) `tier` de
modèle — conservé mais désormais **explicitement étiqueté « non prouvé »** (G10) ; (c) détection de la
présence d'une phase à effet de bord, qui active le contrat d'exécution. Il **cesse** d'être ce qui décide
combien d'agents travaillent sur la qualité.

**Critère de tri, opérationnel et déclaré (pas inféré)** : une phase porte-t-elle un effet de bord non
réversible sans procédure, ou une clause `rollbackPhase` / `skipIf --dry-run` ? → **contrat**. Sinon →
**adaptatif**. Application au catalogue actuel (à revoir phase par phase, pas à décréter) :

- **Enveloppe contrat à conserver** (6) : `migration` (`apply`), `db-migrate` (`apply`), `data-migration`
  (les 4 phases mutantes + `rollback-expand`), `feature` / `hotfix` / `saas-bootstrap` (phase `deploy`
  uniquement — le reste de leurs phases est de la décomposition-qualité).
- **Candidats à l'adaptatif** (7, aucune phase à effet de bord) : `review`, `test`, `mobile`, `bug-fix`,
  `perf-audit`, `security-audit`, `api-design`.

---

## Décision

**Retenir l'option D**, et **n'engager que les étapes 0 à 2** du plan ci-dessous — réversibles, sans agent
supplémentaire, et qui ne nécessitent **aucune preuve additionnelle** parce qu'elles sont précisément ce qui
produira la preuve. Les étapes 3 à 6 (bascule effective du défaut vers l'adaptatif) sont **conditionnées à
des gates mesurables**.

**Ce document ne retire aucun pipeline, ne modifie aucun code, et n'autorise aucune affirmation
commerciale.**

---

## Risques de la recommandation (contre-pouvoir sur ma propre conclusion)

1. **Risque n°1 — D repose sur le même corpus aveugle que B.** Le fondement « la revue n'apporte rien » est
   établi sur un scorer dont on **sait** qu'il rate la faille trouvée 3/3 par les reviewers (exp. 4). Si
   l'assertion manquante est ajoutée et que PIPELINE se met à battre SOLO sur `ledger` — ce que ADR-022 §3
   prédit explicitement — alors « décomposition-qualité → adaptatif » vient de l'**aveuglement de
   l'instrument, pas de la réalité**, et cette moitié de D doit être réexaminée. C'est pourquoi le plan
   durcit le scorer **avant** toute bascule, et non l'inverse.
2. **Sur-délégation : D ne la résout pas, il la déplace.** Un agent libre de déléguer et de choisir `opus`
   sans plafond est un risque de coût réel et actuellement **non observable** (G6 + `budget-guard`
   phase-keyed). Gate bloquant.
3. **Perte d'auditabilité.** Même sous D, la partie adaptative est stochastique dans sa structure. Les
   phases déclarées offraient gratuitement une trace exploitable ; il faudra la **produire
   explicitement** (qui a été appelé, avec quel modèle, sous quel mandat) sinon on perd la capacité de
   rejouer un incident.
4. **Biais de nouveauté et biais d'auteur.** ADAPTIVE confirme parfaitement l'intuition de celui qui a
   commandé la mesure, sur des tâches plafonnées, à N=3. Je recommande D **malgré** ce résultat et non
   grâce à lui : l'argument porteur est G3 (inadéquation informationnelle), pas le 6/6.
5. **Complexité de maintenance supérieure à A et à B.** Deux régimes coexistent, avec une frontière à
   trancher pour chaque phase. Une frontière mal placée est un **bug silencieux d'architecture** (un
   `deploy` basculé côté adaptatif = perte de garde). Mitigation obligatoire : la frontière doit être une
   propriété **déclarée dans le fichier** (`sideEffect: true`), jamais une inférence lexicale.
6. **Coût de positionnement.** « 13 pipelines prêts à l'emploi » est un actif de démo. En désactiver 7
   réduit la surface produit visible même à qualité constante. À assumer explicitement — cohérent avec la
   ligne d'ADR-019 (arrêter de vendre le fan-out comme une garantie).
7. **Le corpus décisionnel reste 100 % SQL et mono-modèle.** Rien dans ce document ne se généralise à TS,
   Docker, ou à un autre tier de modèle. D est une décision **interne**.

---

## Statut d'ADR-022 — révision explicite

| Section ADR-022 | Statut | Motif |
|---|---|---|
| **§1** — « défaut = 1 agent », rien à retirer | **Maintenu, renforcé** | ADAPTIVE ne le contredit pas : 2/6 trials ont choisi de ne pas déléguer et ont fait 100. La règle CLAUDE.md reste correcte. |
| **§2** — améliorer le mandat de la phase `safety` | **Objectif maintenu, moyen reformulé** | ADR-022 proposait de **réduire la permission** (« signaler sans corriger »). ADAPTIVE montre qu'**élargir le mandat** ferme la même classe de régression (0/6). La cause est l'**incohérence** mandat/permission, pas la largeur. Or « signaler sans corriger » comme unique remède est **contre-productif sur la sécurité** : un mandat trop étroit est exactement ce qui a laissé passer le `security_invoker` manquant du bras natif (92/100, addendum F3). **Formulation révisée** : mandat de revue **large** (« trouve et corrige tout défaut réel »), assorti d'une **interdiction explicite de modifier ce que le prompt spécifie nommément** (noms de colonnes, clauses `ON DELETE`, comportements métier) — à signaler, jamais à réécrire. |
| **§3** — assertion cross-tenant parent-enfant | **Maintenu, promu priorité n°1, périmètre corrigé** | **Correction factuelle** : l'assertion existe **déjà** sur `at-orders-fulfillment-schema` (`[comportement-isolation] item avec workspace divergent du parent est rejeté`, présente dans les 3 bras — c'est elle qui fait tomber SOLO2 à 91). ADR-022 affirmait qu'aucune assertion de ce type n'existait : faux pour `orders`. Elle est en revanche **bien absente de `at-ledger-immutable-double-entry`** (10 assertions, **toutes** `role: "owner"`, aucune isolation parent-enfant) — la faille FK trouvée 3/3 y reste invisible. Et sur `orders` elle tourne en `owner`, donc teste une contrainte/trigger, **pas** l'isolation sous identité réelle. L'action reste à faire, avec un périmètre différent de celui décrit. |
| **§4** — « le principe classifier-puis-router n'est pas remis en cause » | **Partiellement dépassé** | Le principe n'est pas invalidé **en bloc**, il doit être **scindé**. Classifier pour le coût (tier-0, tier) et pour le contrat d'exécution : **conservé**. Classifier pour décider du nombre d'agents affectés à la qualité : **à remplacer** — c'est la fonction dont la valeur mesurée est nulle (exp. 1, 3, 4) ou conditionnelle et **structurellement non prédictible avant génération** (G3). ADR-022 écrivait « aucune preuve que l'approche classifier-puis-router soit la mauvaise architecture » ; G3 en fournit une, pour ce sous-rôle précis. |
| **§Prochaines étapes** | **Réordonnées** | Voir plan ci-dessous : l'ordre d'ADR-022 (implémenter n°1 et n°2 puis re-mesurer) est conservé mais **précédé** de G6 (efficience), sans quoi aucun arbitrage coût/qualité n'est possible. |

---

## Plan de mise en œuvre séquencé

**Étape 0 — dette de traçabilité** (aucun agent, aucun coût) : rédiger dans ADR-021 l'addendum manquant
« Point 2 symétrique », et l'addendum « ADAPTIVE » avec ses limites **y compris la violation du gate 5bis
et le confond de modèle (1 trial `opus`)**. Un résultat non documenté n'existe pas.

**Étape 1 — gate de mesurabilité (BLOQUANT)** : implémenter G6 — tokens (in/out/cache-read/cache-write),
coût réel, wall-clock, nombre d'appels agent, **par trial**, persistés dans `results-v2.json`. Sans ça, la
recommandation D repose sur une moitié d'équation et ADAPTIVE ne peut pas être arbitré face à SOLO.
**Aucune bascule avant.**

**Étape 2 — gate de discrimination (BLOQUANT)** : ajouter à `at-ledger-immutable-double-entry` les
assertions `role: "authenticated"` d'isolation parent-enfant (la faille FK trouvée 3/3) ; **passer sous
`authenticated`** l'assertion d'isolation d'`orders`. Puis re-mesurer SOLO / PIPELINE / ADAPTIVE (N=3, même
générateur, **modèle tenu constant**) sur les 2 tâches. Trois issues, pré-enregistrées :

- **PIPELINE > SOLO et ADAPTIVE ≥ PIPELINE** → D confirmé, passer à l'étape 3.
- **PIPELINE > SOLO et ADAPTIVE < PIPELINE** → la revue à mandat large ne suffit pas pour cette classe de
  défaut : la partie « décomposition-qualité → adaptatif » de D **ne bascule pas**, le template est
  conservé sur cette classe. D est révisé, pas appliqué.
- **Tout reste à 100** → les tâches sont définitivement non-discriminantes : **construire une tâche
  discriminante** (§5bis) avant toute décision, plutôt que conclure sur une saturation.

**Étape 3 — déclarer la frontière** (réversible, aucun changement de comportement) : ajouter
`sideEffect: true` aux phases concernées de `pipelines.json` et produire le tableau de tri des 13
pipelines, revu à la main. Livrable purement déclaratif.

**Étape 4 — ré-ancrer la gouvernance de coût (BLOQUANT avant l'étape 5)** : étendre `budget-guard` aux
délégations d'un orchestrateur adaptatif (plafond de délégations par tâche + plafond $ , refus au-delà, pas
un simple avertissement). Sans ça, D hérite intégralement du trou de gouvernance de l'option B.

**Étape 5 — bascule progressive, réversible par flag** : basculer en adaptatif les pipelines sans
`sideEffect`, **un par un**, en commençant par `review` (2 phases, le plus simple, le seul dont la
structure a déjà été partiellement mesurée). Le pipeline figé reste en place derrière un flag. Ne basculer
le suivant qu'après mesure du précédent (étapes 1 et 2 rendent cette mesure possible).

**Étape 6 — T2, avant toute affirmation commerciale** : ≥2 tiers de modèle (G11), ≥2 domaines hors SQL
(TS/Docker déjà outillés, jamais utilisés en décision), N≥5, scrutin symétrique. Tant que l'étape 6 n'est
pas faite, D est une décision **interne** et rien de ce document ne peut être cité en vente.

### Ce qui reste en l'état pendant la transition

- **Les 13 pipelines** : aucun retrait. Désactivation par flag uniquement.
- **CLAUDE.md, règle « défaut = 1 agent »** : confirmée par exp. 3, inchangée.
- **Tier-0 codemod** : intouché, prioritaire sur tout le reste du chemin.
- **Injection mémoire par défaut** (`ada bank recall`) : seul driver de valeur prouvé — **ne pas y
  toucher** dans ce chantier.
- **Corpus de tâches** : immuable, on ajoute, on ne retire jamais.

---

## Décisions irréversibles — signalées explicitement

1. **Retirer un pipeline de `pipelines.json`** est en pratique quasi irréversible : les tiers, `depends`,
   `maxRetries` et clauses de rollback ont été calibrés à la main et ne se reconstituent pas. → **N'en
   retirer aucun** ; désactiver par flag.
2. **Purger `results-v2.json`** détruit la seule base de comparaison longitudinale. Cette session l'a déjà
   fait 3 fois (10, 11, puis d'autres entrées retirées). → **Interdire toute purge future** : marquer une
   entrée obsolète (`superseded: true`) plutôt que la supprimer — même principe que les ancres flywheel.
   Corollaire immédiat : les 2 entrées `PIPELINE` à `scorerSha` ancien sur `orders`/`ledger` doivent être
   **marquées**, pas effacées, pour que `report` cesse de voir une cellule ambiguë.
3. **Basculer une phase à effet de bord côté adaptatif** est irréversible par nature (un `deploy` ou un
   `apply` exécuté sans garde ne se rejoue pas). → C'est exactement ce que la déclaration explicite
   `sideEffect` (étape 3) existe pour rendre impossible par accident.

---

## Conséquences

- **+** L'architecture cible distingue enfin **décomposition-qualité** (mesurée sans valeur intrinsèque) de
  **décomposition-contrat** (jamais mesurée, jamais contestée, indispensable) — une confusion qui rendait
  la question « ADA sert-il à quelque chose ? » indécidable.
- **+** L'argument porteur (G3 : inadéquation informationnelle d'une décision de décomposition prise avant
  génération) est structurel et T1, indépendant du résultat le plus flatteur de la session.
- **+** Les deux gates bloquants (G6 efficience, assertions discriminantes) sont des dettes déjà
  identifiées par ADR-021 : le plan les paie au lieu de les contourner.
- **−** Aucune décision d'architecture n'est appliquée aujourd'hui : ce document ferme une question
  d'orientation, pas un chantier. Le statu quo reste actif entre-temps.
- **−** Deux régimes coexisteront, avec une frontière à maintenir et un risque de mauvais classement de
  phase.
- **−** Le corpus reste SQL et mono-modèle : la portée de tout ceci est bornée jusqu'à l'étape 6.

## Alternatives rejetées

| Option | Raison du rejet |
|---|---|
| (A) statu quo comme cible | 11/13 templates jamais mesurés ; conserve un coût 2-3× à gain nul mesuré et une classe de régression reproduite 3× ; positionnement commercial non soutenable par nos propres données |
| (B) remplacement complet par ADAPTIVE | Preuve T1 sur 2 tâches **déclarées non-discriminantes**, modèle non constant, coût non mesuré ; perdrait `budget-guard` (phase-keyed), les contrats de rollback/dry-run, le tier-0 codemod, et la reproductibilité dont dépend tout le protocole d'évaluation |
| (C) hybride par domaine | Bon esprit, mauvais axe : `migration`/`db-migrate` sont du SQL, le domaine même où la décomposition ne vaut rien en qualité. Le discriminant est l'effet de bord, pas le domaine |
| Attendre un T2 avant toute décision | Les étapes 0-2 sont des améliorations d'instrument : elles ne requièrent aucune preuve supplémentaire et sont **précisément ce qui produira** la preuve. Les différer garantirait de ne jamais l'obtenir |
| Conclure de ADAPTIVE 6/6 que l'adaptatif est supérieur | Non-infériorité sur des tâches plafonnées ≠ supériorité. Le principe #2 d'ADR-021 exige une séparation complète à N=5 ; le gate §5bis interdisait même ce run |

## Fichiers concernés (aucun modifié par ce document)

```
.claude/coordinator/pipelines.json        13 templates ; ajout futur de `sideEffect` (étape 3)
.claude/coordinator/task-classifier.js    rôle réduit : codemod + tier + détection sideEffect
.claude/coordinator/router.js             tier-routing conservé, étiqueté non prouvé (G10)
.claude/coordinator/budget-guard.js       à étendre aux délégations adaptatives (étape 4)
.claude/coordinator/bench-v2.js           G6 : tokens/coût/temps/appels par trial (étape 1)
.claude/benchmarks/v2/tasks-v2.json       assertions `authenticated` d'isolation (étape 2)
.claude/benchmarks/v2/results-v2.json     `superseded` au lieu de purge (décision irréversible n°2)
docs/adr/ADR-021-…                        addenda manquants (étape 0)
docs/adr/ADR-022-…                        §2 reformulé, §3 corrigé, §4 partiellement dépassé
```

---

## Mise à jour post-étape 2 (2026-08-10)

Étapes 0-2 exécutées (voir addenda ADR-021 correspondants — « Point 2 symétrique », « Test
ADAPTIVE », correction du 3/3→2/3, « Étape 2b »). Résultat officiel, 18 trials réels,
provenance unique (`git:e600307…`), modèle `sonnet` constant :

| Tâche | SOLO | PIPELINE | ADAPTIVE |
|---|---|---|---|
| `orders` | μ=97 | μ=97 | μ=100 |
| `ledger` | μ=91 | μ=97 | μ=97 |

**`ledger` atteint la lettre de l'issue 1 pré-enregistrée** (« PIPELINE > SOLO et ADAPTIVE
≥ PIPELINE → D confirmé ») — SOLO échoue systématiquement (3/3, σ=0), PIPELINE et ADAPTIVE
chacun 2/3. **Ce n'est pas une séparation statistique complète** (principe #2, N≥5) — un
résultat T1 cohérent pour la 2ᵉ fois consécutive avec G3, pas une preuve au-delà de ce
niveau. `orders` reste inchangé (l'assertion discriminait déjà sous `owner`, aucune
information nouvelle).

**Ce que ça confirme, précisément** : le risque n°1 listé plus haut (« si l'assertion
manquante est ajoutée et que PIPELINE se met à battre SOLO, cette moitié de D doit être
réexaminée ») s'est produit — mais **pas de la façon qui invaliderait D**. Mécanisme
identifié sur les 2 seuls échecs (PIPELINE et ADAPTIVE) : dans les deux cas, la cause est
une **absence de second regard sur ce périmètre précis** — un reviewer qui n'a pas examiné
l'isolation (PIPELINE), un orchestrateur adaptatif qui a jugé qu'un seul passage suffisait
et s'est trompé (ADAPTIVE). Le template figé n'a **pas** de garantie de couverture
supérieure à l'adaptatif : il a simplement eu de la chance sur 2/3 trials, exactement comme
ADAPTIVE. Ceci renforce plutôt que contredit la décision D : la variable qui compte est la
**garantie qu'une revue a bien lieu et couvre le bon périmètre**, pas l'architecture
(figée vs adaptative) qui la porte.

**Statut des 3 options** : (A) statu quo toujours rejeté (coût 2-3× sans garantie de
couverture supérieure, maintenant démontré sur ce point précis). (B) adaptatif intégral
toujours rejeté en l'état (mêmes gates G6/gouvernance de coût non levés). **(D) confirmée**,
mais avec un correctif obligatoire ajouté au plan étape 3 : la déclaration `sideEffect`
doit s'accompagner d'une **checklist de mandat de revue par domaine** (ex. isolation
multi-tenant systématiquement dans le périmètre d'une revue SQL/RLS), pas seulement d'un
mandat générique « trouve et corrige » — sans quoi l'un ou l'autre régime peut reproduire
l'échec de couverture observé ici.

**Ce qui ne change pas** : étapes 3-6 restent conditionnées comme prévu, aucune bascule de
pipeline n'est faite, le corpus reste SQL/mono-modèle (portée toujours T1, pas
d'affirmation commerciale).

---

## Mise à jour étapes 4-5 (2026-08-11)

Étape 3 (déclaration `sideEffect`) et la checklist de mandat par domaine
(`review-mandates.json`) étaient déjà faites avant ce chantier. Ce qui suit couvre
les étapes 4 et 5 du plan de mise en œuvre.

### Étape 4 — gouvernance de coût des délégations adaptatives

`coordinator/budget-guard.js` expose trois nouvelles fonctions publiques, symétriques
à `checkBudget`/`recordCost`/`getSessionCost` :

- `checkDelegationBudget(runId, delegationCount, cumulCost, config, aggregates?)` — fonction
  pure. Refuse (`action: 'stop'`) dès que `delegationCount >= maxDelegationsPerRun` OU que
  l'un des plafonds $ (`perRun`, `perSession`, `perDay`) est dépassé.
- `recordDelegation(runId, { agent, model, mandateId, cost })` — persistance atomique dans
  `~/.ada/logs/delegation-log.json` (même dossier que `budget-log.json`). Trace explicitement
  *qui* a été appelé, *avec quel modèle*, *sous quel mandat* — pas un compteur nu, pour
  répondre au risque n°3 de l'ADR (« perte d'auditabilité »).
- `getDelegationCount(runId)` — lecture agrégée, tolérante aux entrées sans `mandateId`
  (rétrocompatibilité).

Deux nouveaux champs de config, persistés dans `~/.ada.json` sous la clé `budget` existante
(même mécanisme que `perRun`/`perSession`/`perDay`) :

- `maxDelegationsPerRun` — défaut **3**, choisi pour rester cohérent avec la règle CLAUDE.md
  « Max 3 agents actifs par session » plutôt que d'introduire un second chiffre à maintenir.
- `adaptiveOnExceed` — défaut **`'stop'`**. C'est un champ *distinct* de `onExceed` (qui régit
  les pipelines figés et peut légitimement valoir `'warn'`) : l'ADR exige un refus dur pour ce
  chemin précis, indépendamment de la configuration `onExceed` de l'utilisateur.
  **Écart mineur par rapport au brief** : `checkDelegationBudget` *respecte* `adaptiveOnExceed`
  plutôt que de retourner `'stop'` en dur inconditionnellement — c'est-à-dire que la garantie
  « refus dur, pas un avertissement » tient sur le *défaut* (`'stop'`) et sur l'indépendance
  vis-à-vis de `onExceed`, pas sur l'impossibilité absolue de configurer `adaptiveOnExceed`
  à `'warn'`. Un utilisateur qui change explicitement ce champ fait un choix conscient et
  découplé du réglage des pipelines figés — ce n'est pas un héritage silencieux du trou de
  gouvernance de l'option B. Si cette marge de configuration s'avère indésirable en pratique,
  la retirer est un changement d'une ligne (`action = 'stop'` en dur) sans impact sur le reste.

Auditabilité additionnelle : les handlers IPC `budget.checkDelegation` /
`budget.recordDelegation` ont été ajoutés à `coordinator/control-handlers.js`, symétriques à
`budget.check`/`budget.record` déjà existants — pour que le même contrat de gouvernance soit
disponible aux appelants passant par le control-plane (UI/`ada-api-nest`), pas seulement par
`run.js` en CLI. Ajout non demandé explicitement par le brief mais à risque nul (pattern
strictement identique aux deux handlers existants) et cohérent avec l'objectif d'auditabilité.

Isolation des tests : `budget-guard.js` lit `HOME` directement (pas `CLAUDE_CONFIG_DIR`,
contrairement à la majorité du dossier `coordinator/`). Deux nouvelles variables d'env
surchargent ce chemin pour des tests hermétiques — `ADA_CONFIG_PATH` (reprend un précédent
déjà présent dans `control-handlers.js`) et `ADA_LOG_DIR` (nouveau, même principe). Sans ça,
toute suite de tests aurait lu/écrit le vrai `~/.ada.json` et `~/.ada/logs` de la machine qui
exécute les tests — risque non hypothétique, vérifié en pratique pendant l'implémentation.

### Étape 5 — bascule adaptative du pipeline `review`, réversible par flag

Nouvelle clé `adaptivePipelines` dans `~/.ada.json`, même style que `webhook`/`federation`/
`budget` :

```json
"adaptivePipelines": { "review": true }
```

**Défaut : absent ou `false` → comportement 100% inchangé.** Aucune clé n'est écrite
automatiquement par ce chantier ; l'activation est un geste explicite de l'utilisateur.

Dans `coordinator/run.js`, `next --json` reste le point d'entrée. Trois fonctions ajoutées,
pures pour la décision (`resolveEffectiveTopology`), I/O séparées (`loadAdaptivePipelinesConfig`,
`loadApplicableReviewMandates`) :

- Flag désactivé (ou pipeline non éligible) → `topology` inchangée (`'sequential'` ou
  `'parallel_mesh'` selon `analyzeTopology`, comme avant ce chantier), pas de champ `adaptive`.
- Flag `review` activé → `topology: "adaptive"`, avec un champ `adaptive` contenant :
  - `mandates` — les entrées de `review-mandates.json` dont `appliesToPhaseIds` intersecte les
    phases du pipeline (résolu génériquement, pas hardcodé à `sql-rls` — se généralise sans
    changement de code le jour où un autre domaine est peuplé) ;
  - `governance` — `maxDelegationsPerRun`, `perRunBudgetUsd`, `onExceed`, lus depuis
    `budget-guard.loadBudgetConfig()` (étape 4), pour que l'appelant (l'orchestrateur Claude
    côté session) les respecte lors de ses délégations libres.
- Restriction dure : `ADAPTIVE_ELIGIBLE_PIPELINES = ['review']` — même si l'utilisateur active
  `adaptivePipelines.<autre-pipeline>` par erreur ou anticipation, seul `review` bascule
  effectivement. Les 6 autres candidats (`test`, `mobile`, `bug-fix`, `perf-audit`,
  `security-audit`, `api-design`) restent figés jusqu'à mesure de `review`.
- Le template `review` dans `pipelines.json` n'est ni retiré ni modifié structurellement — le
  flag est un aiguillage à l'exécution (« Décisions irréversibles » de l'ADR-023, point 1).
- Vérifié bout-en-bout avec le vrai `review-mandates.json` et un run réel (`node run.js init
  review ...` puis `next --json`, flag off puis on) avant nettoyage — comportement conforme aux
  deux points ci-dessus.

Le mode d'affichage humain de `cmdNext` (hors `--json`) n'a pas été modifié — le signal
adaptatif est destiné à l'appelant programmatique, conformément à la formulation du brief
(« probablement dans la logique de `next --json` »). Sujet à révision si l'usage interactif du
flag le justifie.

### Tests

`coordinator/tests/coordinator.test.js` — deux nouvelles suites (`node:test`), 11 tests :
refus dur au-delà de `maxDelegationsPerRun` et du plafond $ malgré `onExceed: 'warn'` global ;
autorisation sous les deux plafonds ; respect explicite de `adaptiveOnExceed: 'warn'` en
opt-out ; traçabilité `recordDelegation`/`getDelegationCount` (agent/modèle/mandat) ; topologie
inchangée par défaut (flag absent ou `false`) ; topologie `adaptive` avec mandat + gouvernance
quand le flag `review` est actif ; non-bascule d'un pipeline non éligible même flag actif.
**97/97 tests passent** (`tests/run-tests.sh`), aucune régression sur les 10 suites
préexistantes.

### Ce qui reste avant l'étape 6

- ~~**Mesurer `review` en conditions réelles**~~ — fait, voir section suivante.
- **Étape 6 (T2)** reste entièrement non franchie : ≥2 tiers de modèle, ≥2 domaines hors SQL,
  N≥5, scrutin symétrique. Ce document reste une décision interne — aucune affirmation
  commerciale n'est autorisée par ce chantier.
- Le corpus de mandats (`review-mandates.json`) reste volontairement limité à `sql-rls` —
  aucun défaut de couverture n'a été mesuré sur un autre domaine cette session, conformément
  au principe déjà posé dans ce fichier (`_domainsConsideredNotAdded`).

---

## Mesure du point 2 — pipeline `review` en conditions réelles (2026-08-11)

**Design.** Le pipeline `review` est littéralement diff→review (pas génération) — le diff est
donc tenu **constant** et seul le mécanisme de revue varie. Pour chaque tâche du corpus
décisionnel (`orders`, `ledger`), 1 génération de référence (sonnet, sans revue), puis N=3
essais **REVIEW-FIXED** (mandat générique, sans injection de `review-mandates.json` — c'est le
comportement actuel du pipeline figé) vs N=3 essais **REVIEW-ADAPTIVE-MECH** (flag
`adaptivePipelines.review=true`, mandat générique + checklist `sql-rls` complète injectée,
gouvernance étape 4 réellement exercée via `ADA_CONFIG_PATH`/`ADA_LOG_DIR` isolés — jamais le
`~/.ada.json` réel de la machine). Modèle tenu constant (`claude-sonnet-5`). Scoring Postgres
réel (`bench-v2.js scoreSqlDeliverable`) contre les assertions de `tasks-v2.json`, arms
enregistrés sous `REVIEW-FIXED`/`REVIEW-ADAPTIVE-MECH` (vocabulaire non figé, I3).

**Résultat** (12 essais scorés, `tasksSha`/`scorerSha` uniques, `results-v2.json`) :

| Tâche | REVIEW-FIXED | REVIEW-ADAPTIVE-MECH |
|---|---|---|
| `orders` (non-discriminante — cf. gate 5bis) | 100, 100, 100 (μ=100) | 100, 100, 100 (μ=100) |
| `ledger` (discriminante — défaut FK isolation connu) | 100, 100, **91** (μ=97) | 100, 100, 100 (μ=100) |

Le seul écart vient d'un unique trial FIXED qui traite `ledger_entries.transaction_id` (FK
simple sur le parent) comme un sujet de performance (ajout d'un index composite) sans voir
l'implication sécurité — exactement la classe d'échec de couverture déjà mesurée en Étape 2b.
Les 3 trials ADAPTIVE-MECH corrigent la FK en composite (ou trigger de cohérence) les 3 fois,
guidés par l'item `cross-tenant-parent-child-fk` de la checklist.

**Gouvernance étape 4 validée en conditions réelles** (pas seulement en test unitaire) :
`checkDelegationBudget`/`recordDelegation` exercés pour de vrai sur 2 runs isolés (3
délégations chacun) — les 3 délégations autorisées, une 4ᵉ délégation simulée sur le même
`runId` **refusée dur** (`action: "stop"`, `maxDelegationsPerRun=3/3`), conforme à la spec.

**Décision (issue pré-enregistrée n°1 : « ADAPTIVE ≥ FIXED → mécanisme confirmé, passer à la
bascule du pipeline suivant »)** : confirmée sur `ledger` (100 ≥ 97) ; `orders` reste
non-informative (plafonnée, comme prévu par le gate 5bis). Le mécanisme étape 5 est validé sur
sa première cible. **Passage au point 3 (bascule du candidat suivant parmi `test`, `mobile`,
`bug-fix`, `perf-audit`, `security-audit`, `api-design`) proposé à validation humaine — pas
exécuté automatiquement, conformément au séquençage strict demandé.**

**Limites de preuve (honnêtes, pas à esquiver)** : N=3 par condition, pas N=5 (principe #2
d'ADR-021 — non-infériorité observée, pas séparation statistique complète) ; 1 seule tâche
réellement discriminante sur 2 ; corpus toujours 100 % SQL, modèle unique (`sonnet`) — mêmes
bornes que le reste de ce document, étape 6 (T2) toujours non franchie.

**Deux défauts d'instrument trouvés et corrigés pendant cette mesure, hors scope étapes 4-5 :**

1. **Bug de harnais (corrigé)** : `buildReport` (`bench-v2.js`) ignorait le champ
   `superseded` — une entrée marquée obsolète (convention « Décisions irréversibles » #2 de ce
   document) continuait de polluer les moyennes au lieu d'être filtrée à la lecture. Découvert
   en pratique : 2 essais ratés de harnais pendant cette mesure elle-même (fichier livrable
   sans fence ```sql, puis fichier avec fence mais section "-- Rollback" du livrable encore
   concaténée après le `COMMIT` forward et auto-exécutée — `DROP TABLE` immédiat, score 0
   artefactuel) ont été marqués `superseded: true` plutôt que supprimés, ce qui a révélé que
   `buildReport` les comptait quand même. Fix : `rows = results.filter(r => !r.superseded)`
   avant tout calcul. 132/132 tests `bench-v2.test.js` + 97/97 `coordinator.test.js` passent
   après le fix, aucune régression. Ce bug touchait potentiellement aussi les 2 entrées
   `PIPELINE`/`scorerSha` ancien mentionnées dans « Décisions irréversibles » #2 — à vérifier
   si un rapport historique en dépendait.
2. **ID de modèle tier-3 périmé (trouvé, PAS corrigé ici — hors scope de cette mesure)** :
   `coordinator/models.js` mappe le tier 3 vers `claude-opus-4-8`, un ID qui n'existe pas dans
   la gamme de modèles active — `claude-opus-5` est l'ID correct. Confirmé en pratique
   (`bench-v2.js menu` sort littéralement `model=claude-opus-4-8` pour les arms tier-3 du
   corpus `ledger`). Sans conséquence sur cette mesure (modèle tenu constant à `sonnet`), mais
   un risque réel pour tout run tier-3/opus réel via le chemin d'exécution d'ADA (fallback
   silencieux vers le modèle de session documenté dans CLAUDE.md, « Vérification des IDs de
   modèles »). À corriger séparément (1 ligne).

---

## Bascule des 6 pipelines restants — écart assumé au plan (2026-08-11)

**Ce que dit le plan.** L'étape 5 de ce document prescrit explicitement une bascule
« progressive, réversible par flag », « **un par un**, en commençant par `review` »,
et « ne basculer le suivant qu'après mesure du précédent ». La section « Mesure du
point 2 » ci-dessus mesure `review` (résultat favorable sur `ledger`, la seule tâche
discriminante du corpus) et conclut en proposant explicitement « le passage au point 3
(bascule du candidat suivant) à validation humaine — pas exécuté automatiquement,
conformément au séquençage strict demandé ».

**Ce qui a été fait ici.** L'utilisateur a demandé explicitement de basculer les 6
candidats restants (`test`, `mobile`, `bug-fix`, `perf-audit`, `security-audit`,
`api-design`) **d'un coup**, sans mesure individuelle de chacun. C'est fait :
`ADAPTIVE_ELIGIBLE_PIPELINES` dans `coordinator/run.js` couvre désormais les 7
pipelines sans phase `sideEffect` (vérifié par grep sur `pipelines.json` avant
l'ajout — aucun des 6 ne porte de phase à effet de bord ; aucun pipeline à
`sideEffect` — `feature`, `hotfix`, `migration`, `db-migrate`, `saas-bootstrap`,
`data-migration` — n'a été ni ne sera ajouté par ce geste). Tests étendus dans
`coordinator.test.js` (mécanisme de bascule vérifié pour les 7 noms + garde-fou
explicite : un pipeline à `sideEffect` type `migration` ne bascule jamais même flag
forcé). 106/106 tests passent (`tests/run-tests.sh`), aucune régression.

**À dire sans ambiguïté :**

(a) Le plan prévoyait une mesure en conditions réelles avant chaque bascule
individuelle — c'est ce qui a été fait pour `review` (section « Mesure du point 2 »),
et ce qui n'a **pas** été fait pour les 6 autres.

(b) L'utilisateur a demandé explicitement de basculer les 6 restants d'un coup, sans
cette mesure — décision de sa part, pas une application du protocole de cet ADR. Cette
section documente l'écart, elle ne le maquille pas en respect du séquençage.

(c) **Ceci n'est pas une confirmation que le mécanisme fonctionne aussi bien sur ces 6
pipelines.** Aucune donnée de qualité, de coût ou de couverture n'existe sur `test`,
`mobile`, `bug-fix`, `perf-audit`, `security-audit` ou `api-design` en mode adaptatif.
Le seul résultat mesuré à ce jour reste celui de `review` sur le corpus SQL
(`orders`/`ledger`, N=3, modèle `sonnet` constant). Ce qui a été livré ici est le
**mécanisme** (le flag bascule bien la topologie, la gouvernance étape 4 s'applique
de façon identique quel que soit le nom du pipeline), pas une preuve de valeur sur ces
6 pipelines. L'étape 5 n'est **pas terminée** au sens du plan — elle est **étendue en
périmètre, non mesurée**, sur demande explicite.

(d) **Risque principal** : `review-mandates.json` ne couvre à ce jour qu'un seul
domaine, `sql-rls`, dont le `appliesToPhaseIds` (`safety`, `review`, `verify`, `fixes`,
`deps`, `scan`, `diagnose`) intersecte de façon inégale les 6 nouveaux pipelines —
`security-audit` (phases `scan`/`deps`/`fixes`/`verify`) matche sur ses 4 phases,
`bug-fix` et `perf-audit` matchent partiellement (`review`/`fixes`), tandis que `test`
(`unit`/`integration`/`coverage`) et `api-design` (`requirements`/`contract`/`docs`,
seule `review` matche) n'ont **aucune** couverture de checklist en dehors de leur
phase `review` générique. Autrement dit : si ces pipelines ont des défauts de
couverture propres à leur domaine (perf, mobile, tests, contrats API) analogues à la
faille d'isolation cross-tenant trouvée sur SQL, **aucune checklist déclarative ne les
protège** — contrairement à `review` sur `sql-rls`, dont la mesure a montré exactement
ce mécanisme de protection à l'œuvre (`cross-tenant-parent-child-fk`). Ce risque n'est
pas hypothétique par construction : c'est la classe de risque que ce document a
identifiée et mesurée sur SQL, simplement non vérifiée ici sur les 6 autres domaines.

**Ce qui ne change pas** : les pipelines figés eux-mêmes ne sont ni retirés ni modifiés
(cf. « Décisions irréversibles » #1) ; le flag reste désactivé par défaut dans
`~/.ada.json` (aucune régression pour un utilisateur qui n'active rien) ; l'étape 6
(T2) reste entièrement non franchie ; aucune affirmation commerciale n'est autorisée
par ce geste.
