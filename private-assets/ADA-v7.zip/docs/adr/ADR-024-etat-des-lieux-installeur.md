# ADR-024 — État des lieux de l'installeur ADA (install.sh)

## Statut

**Accepté — 4 bloquants + axe 1 (couverture) + axe 2 (CLAUDE.md, env/preferences) + axe 3
(E1-B/E1-E/E3-6, portée et distinction install/update) implémentés et vérifiés, ET première
validation réelle effectuée contre un vrai profil (`~/.claude-jarvis`, 2026-08-11) — zéro
perte de données confirmée, 2 défauts réels trouvés et corrigés** (voir addenda en fin de
document). Les 3 axes de la reprise ADR-024 sont clos, plus la passe de correction issue de
la validation réelle. Reste explicitement ouvert : E1-C/D (sémantique
`--all`/`--non-interactive` conflatée, mineur, jamais traité), `docs/INSTALL-CLIENT.md`
(jamais mis à jour).

**Date** : 2026-08-10
**Décideurs** : Jonathan Arms
**Méthode** : lecture intégrale d'`install.sh` (796 lignes), `.claude/bin/ada.js`
(`cmdInstall`/`cmdUpdate`/`cmdVersion`/`runNode`/`getProfileDir`), `.claude/bin/doctor.js`,
`docs/INSTALL-CLIENT.md`, `.gitignore` ; comparaison réelle (`md5`/`find`/`comm`/
`git ls-files`) entre le repo et les 4 profils existants sur la machine
(`claude-pro`, `claude-ov` [actif], `claude-jarvis`, `claude-perso`). Chaque finding
ci-dessous a été vérifié directement — au minimum 9 des affirmations les plus
consé­quentes ont été recroisées personnellement (ligne exacte du script + état réel du
disque), pas relayées sur la seule foi de l'agent qui a produit l'audit.

## Contexte

Trois exigences produit explicites ont motivé cet audit :

1. **Détection interactive + création** — détecter les profils Claude Code existants et y
   installer/mettre à jour ADA ; créer un profil si aucun n'existe.
2. **Zéro perte de données tolérée** — une installation/mise à jour ne doit jamais altérer
   les données d'un profil existant, seulement ajouter/mettre à jour la config ADA.
3. **Gestion correcte des mises à jour futures** — le code d'ADA évolue dans le repo
   (nouveaux fichiers, fichiers modifiés, données de référence comme les tâches de
   benchmark) ; une mise à jour doit propager ces changements de façon fiable.

Point de départ concret : un run `bash install.sh` avait déjà été jugé risqué au préalable
(session en cours) pour un cas précis (perte de `memory-semantic.json`). L'utilisateur a
demandé un état des lieux complet, pas seulement un correctif ponctuel.

## Correction à noter avant tout : le runtime, c'est le profil

**`ada` n'exécute PAS le code du repo pour la plupart de ses sous-commandes.**
`runNode()` (`ada.js:172-181`) lance `node <chemin relatif>` avec `cwd: <dossier du
profil>` ; les appelants passent des chemins relatifs (`'coordinator/bank.js'`,
`'coordinator/benchmark.js'`, `'workers/cost-report.js'`, `'tests/run-all.js'`,
`'bin/doctor.js'`…). Vérifié directement dans `ada.js`. Seul le dispatcher `ada` lui-même
(le fichier pointé par le symlink/alias `ada`) est du code repo — tout ce qu'il délègue à
`runNode()` tourne depuis le profil. **Conséquence directe** : le code périmé dans un
profil n'est pas cosmétique, c'est ce qui s'exécute réellement en pratique. Toute
divergence repo↔profil (ex. `pipelines.json`, `tasks-v2.json`) est un bug fonctionnel actif,
pas une question d'hygiène.

## Findings — Exigence 1 (détection/création interactive)

| # | Constat vérifié | Sévérité |
|---|---|---|
| E1-A | `~/.claude` (profil Claude Code **par défaut**) est invisible : `detect_profiles()` (l.114) glob `~/.claude-*/`, qui ne matche pas `~/.claude`. Vérifié sur disque : `~/.claude/` existe, contient un ADA périmé (`CLAUDE.md` md5 différent du repo) + des `.bak.*` prouvant qu'un **ancien** installeur sauvegardait, celui d'aujourd'hui non. | **Bloquant** |
| E1-B | L'interactivité (cas 4, l.177-219) n'est atteinte que sur le tout premier install multi-profils. Dès que `~/.ada.json` a des `installedProfiles` connus (cas courant), c'est muet : tous les profils détectés sur disque sont réinstallés sans confirmation (l.159-175 : `SELECTED=("${PROFILES[@]}")` — **tous les profils du disque**, pas `cfg.installedProfiles`, malgré un commentaire l.171 qui dit le contraire). | Majeur |
| E1-E | Aucune distinction premier-install / mise-à-jour dans le code : `VERSION` est écrit (l.370-373) mais jamais lu, aucun `installedVersion` par profil, aucune étape de migration. Tout run est traité comme un install. | Majeur |
| E1-F | Ce qu'un profil neuf reçoit ≠ ce qu'un profil existant contient : manquent `benchmarks/`, `templates/`, `memory/context.md`, `memory/projects/_template`, `archives/summaries` (contenu réel) — `install.sh` ne fait que `mkdir -p` des dossiers vides (l.409-412). `doctor.js` ne vérifie rien de tout ça — un doctor vert ne prouve pas un profil complet. | Majeur |
| E1-G | `ada update` ne met à jour qu'**un** profil (l'actif, `ada.js:2141`) ; `bash install.sh` nu en met à jour **quatre** (cas 3). Deux portées différentes, aucune annoncée. | Majeur |
| E1-C/D | `--all`/`--non-interactive` = même code (sémantique brouillée) ; `--profile <nom>` sans préfixe crée un profil hors-glob, invisible à un futur `install.sh` nu. | Mineur |

## Findings — Exigence 2 (zéro perte de données)

| # | Constat vérifié | Sévérité |
|---|---|---|
| E2-1 | 5 familles de fichiers d'état réel non protégées par la liste d'exclusion (l.333-335 : `bank-state.json router-state.json pipelines.json bank.db bank.db-* bank-hnsw.json bank-index.json graph-state.json`) : `memory-episodic.json`, `memory-procedural.json`, `memory-semantic.json` (écrits par `typed-memory.js`, **3 fichiers** — vérifié ; `.gitignore` n'en liste que **2**, `memory-semantic.json` n'est ni tracké ni gitignoré — vérifié), `lessons.json`, `audit.log`, `coordinator/logs/`. Dégât **bidirectionnel** : `~/.claude-ov/coordinator/memory-semantic.json` (3383 o, réel) serait supprimé par `rsync --delete` ; `audit.log`/`lessons.json`/`memory-episodic/procedural.json` sont déjà byte-identiques sur les 4 profils et le repo — preuve qu'ils ont déjà été poussés depuis une source vers les clients, pas accumulés localement. | **Bloquant** |
| E2-3 | Le fallback sans `rsync` (`cp -r`, l.304-306) n'honore **aucune** exclusion — écraserait `bank.db`/`bank-state.json`/`pipelines.json` dans un contexte sans rsync (images Docker minimales, CI). | **Bloquant** (contexte conteneur/CI) |
| E2-4 | `CLAUDE.md` écrasé sans merge ni sauvegarde (l.375-380) — aucune personnalisation client protégée. Régression confirmée : un ancien installeur sauvegardait (`.bak.*` trouvés sur disque), l'actuel non. | Majeur |
| E2-6 | `merge_settings` ne fusionne que `hooks` et `permissions.deny` — `env`/`preferences` jamais propagés (une future variable d'environnement requise n'atteindra jamais un profil déjà installé), dédoublonnage de hook fragile (clé = commande seule, pas `matcher`). | Majeur |
| E2-7 | Mode `merge` = `rsync --update`, basé sur le mtime — sûr après `git pull`, potentiellement destructeur après un `git clone`/tarball (tous les fichiers source paraissent alors plus récents). Non tranchable depuis le seul code source : dépend de comment le tarball de release est fabriqué (aucun script de packaging trouvé). | Majeur (à vérifier) |
| E2-8 | Aucun `--dry-run`, aucune sauvegarde, aucun rollback pour une opération qui fait `rsync --delete` sur 10 dossiers × N profils. | Mineur |
| E2-9 | Effets de bord non documentés : `docs/INSTALL-CLIENT.md` promet une écriture limitée à `~/.<profil>/` + `~/.ada.json` ; en réalité le script tue tout process sur le port 7777 (pas seulement l'UI ADA), écrit dans `~/.zshrc`, lance `npm install`/`npm run build` inconditionnellement, et `ada obsidian init --all` touche tous les profils même non sélectionnés. | Mineur |

## Findings — Exigence 3 (mises à jour futures)

| # | Constat vérifié | Sévérité |
|---|---|---|
| E3-1 | Aucun mécanisme de version/diff : ni lecture de `VERSION`, ni consommation de `CHANGELOG.md`, ni checksum. `~/.ada.json` n'a qu'une version **globale**, pas par profil. Chaque run est un rsync aveugle. | Majeur |
| E3-2 | **`pipelines.json` gelé** : copié seulement si absent (l.417-420). Vérifié : repo = 9 occurrences de `sideEffect` (ajouté cette session), les 4 profils = 0. Vérifié aussi : les **clés de premier niveau sont identiques** entre repo et profils — la divergence est *à l'intérieur* des pipelines existants, pas dans l'ajout de nouveaux. Un simple "merge = ajouter les nouveaux pipelines" ne corrigerait donc PAS ce cas. Conséquence combinée avec la correction ci-dessus (le profil = le runtime) : **le `sideEffect` commité cette session (`60e4a67`) ne s'exécute sur aucun profil installé.** | **Bloquant (fonctionnel)** |
| E3-3 | `benchmarks/` mélange données de référence trackées (`tasks-v2.json`, `calibration/`, `deliverables/`) et état runtime gitignoré (`results.json`, `.pending.json`) dans le même dossier, synchronisé par **aucune** des deux listes (`system_dirs`/`content_dirs`). Vérifié : `tasks-v2.json` repo = 63 904 o vs profils = 31 651 o (figé au 18 juin). Ni `replace` (écraserait les résultats client + poussersait les livrables du créateur) ni `merge` (mtime-based, ne retire jamais une tâche obsolète) ne convient tel quel — une 3ᵉ catégorie est nécessaire. Même trou pour `templates/*.json` et `memory/global/*.md`. | Majeur |
| E3-4 | Mode `merge` sans chemin de retrait : un fichier supprimé/renommé côté source reste indéfiniment côté profil. Preuve concrète : 8 agents au format plat (`agents/ai-engineer.md`…) coexistent avec le nouveau format répertoire (`agents/ai-engineer/CLAUDE.md`) sur les 4 profils. Lequel Claude Code retient n'est pas tranchable depuis le seul code source. | Majeur |
| E3-5 | `teams/` classé "contenu" (merge) alors qu'il porte de l'état runtime réel (`claude-pro` : 68 fichiers de sessions d'équipe vivantes) — préservé aujourd'hui par accident (absence de retrait en mode merge), pas par conception. Un futur passage en `replace` (pour propager `routing.md`) détruirait ces sessions. | Majeur |
| E3-6 | Deux portées de mise à jour concurrentes (`ada update` = 1 profil, `install.sh` nu = 4), ni annoncée. | Majeur |
| E3-7 | `docs/INSTALL-CLIENT.md` §5 décrit le bon geste de mise à jour mais promet explicitement la préservation de données qui ne l'est pas (`lessons.json`, les 3 `memory-*.json`, `env`/`preferences` de `settings.json`) — écart doc/comportement à corriger une fois la conception tranchée. | Mineur (sur la forme, majeur sur la promesse) |

## Non tranchable depuis le code source seul

- Quel format Claude Code retient réellement quand un agent existe en flat-file ET en
  répertoire simultanément (E3-4) — à vérifier empiriquement.
- Comment le tarball/paquet de release est fabriqué (aucun script de packaging trouvé sous
  `scripts/`) — détermine si E2-7 (mode merge destructeur après clone/tarball) est un risque
  actif ou théorique.
- Si `~/.claude` doit devenir une cible d'installation ou être explicitement exclu et
  signalé — question produit, pas technique.

## Pistes de conception — non tranchées, aucun code écrit

**Détection/sélection (E1)**
- Étendre le glob à `~/.claude` ou en faire un cas nommé explicite (jamais silencieux).
- Distinguer 3 états par profil (jamais installé / à jour / installé-et-périmé), afficher
  un plan avant d'agir dans tous les cas (y compris `n==1`).
- `cfg.installedProfiles` comme source de vérité du cas 3, confirmation explicite pour
  élargir le périmètre. Découpler `--all` (portée) de `--yes` (interactivité).

**Protection des données (E2)**
- Passer d'une denylist énumérée à la main (qui a déjà raté 5 familles de fichiers) à une
  allowlist dérivée de `git ls-files` : "si ce n'est pas tracké, ADA n'y touche jamais,
  dans aucun sens".
- Test automatisé qui échoue si `.gitignore` et la liste d'exclusion de l'installeur
  divergent.
- Fallback `cp -r` : soit un vrai copieur respectant les exclusions, soit une erreur
  bloquante plutôt qu'une dégradation silencieuse.
- `CLAUDE.md` : sauvegarde horodatée systématique, ou fusion 3-way par checksum de la
  version livrée d'origine, ou fichier séparé importé (`ADA.md`).
- `merge_settings` : traiter `env`/`preferences`, clé de dédoublonnage hook incluant le
  `matcher` + un identifiant stable côté source pour permettre modification/retrait.
- `--dry-run` + sauvegarde horodatée avant toute opération destructive.

**Mises à jour (E3) — la 3ᵉ catégorie**
- Catégorie "données de référence" distincte de `system`/`content` : mise à jour fiable du
  contenu livré + préservation absolue de l'état runtime cohabitant — suppose de séparer
  physiquement référence et runtime, ou de synchroniser fichier par fichier depuis un
  manifeste plutôt que dossier par dossier.
- `pipelines.json` (et tout JSON à double nature) : checksum de la version livrée d'origine
  pour distinguer "non modifié → remplacer" de "modifié par le client → fusionner/alerter" ;
  la granularité doit descendre au niveau du pipeline/phase, pas du fichier. Alternative :
  `pipelines.default.json` (livré) + `pipelines.local.json` (client), fusionnés au
  chargement — déplace le problème dans le coordinateur plutôt que dans l'installeur.
- Manifeste de livraison versionné (fichiers appartenant à ADA + checksum) : résout d'un
  coup l'allowlist (E2-1), le retrait des fichiers dépréciés (E3-4), la détection des
  personnalisations (E3-2), et permet un vrai diff avant install (E2-8).
- Étapes de migration versionnées pour les changements de format (ex. retrait propre des 8
  agents au format plat).
- Trancher et documenter la portée de `ada update` (un profil ou tous), dans les deux
  commandes.
- Réaligner `docs/INSTALL-CLIENT.md` une fois la conception tranchée.

## Conséquences

- Aucun changement de comportement immédiat — cet ADR documente un diagnostic, pas une
  décision.
- Le travail de cette session sur `pipelines.json` (`sideEffect`, commit `60e4a67`) est
  fonctionnellement inerte tant que E3-2 n'est pas résolu — à garder en tête avant toute
  communication sur l'état d'avancement du plan ADR-023.
- Reprise prévue dans une session dédiée, distincte du plan ADR-023.

## Prochaines étapes (non engagées)

1. Trancher les points "non tranchables depuis le source seul" (format d'agent réellement
   chargé par Claude Code ; mécanisme de packaging de release).
2. Choisir une conception parmi les pistes ci-dessus pour chaque exigence (pas
   nécessairement la première listée).
3. Implémenter, en traitant les 4 bloquants en priorité (E1-A, E2-1, E2-3, E3-2).
4. Mettre à jour `docs/INSTALL-CLIENT.md` en dernier, une fois le comportement réel figé.

---

## Addendum — Implémentation des 4 bloquants (2026-08-11)

Direction retenue, validée avant implémentation : remplacer la denylist à la main + le mode
`merge` basé sur mtime par un **manifeste de livraison** (fichiers trackés git + sha256).

**Décision produit tranchée avant implémentation** : `~/.claude` (profil Claude Code par
défaut) est traité comme un profil normal — pas exclu, pas juste nettoyé une fois.

### Ce qui a été livré (commit `eaa2dc3`)

- **`.claude/scripts/generate-ada-manifest.js`** — génère `.claude/.ada-manifest.json`
  (fichiers trackés sous `.claude/` + sha256 de chacun, 909 fichiers, v7.4.0), commité (pour
  qu'un client sans `.git` — cas du zip de release — en dispose quand même). `--check`
  échoue si le manifeste committé est périmé.
- **`.claude/scripts/manifest-files-for.js`** — filtre le manifeste par préfixe de dossier,
  produit la liste `--files-from` pour rsync.
- **`.claude/scripts/sync-content-dir.js`** — logique de décision par checksum (pas mtime)
  pour les dirs de contenu et les fichiers à double nature : fichier neuf → copié ; non
  modifié depuis la dernière sync → mis à jour ; modifié par le client → **jamais écrasé**,
  signalé ; déprécié côté source et intact chez le client → supprimé ; déprécié et modifié →
  conservé, signalé. Mode `--dry-run` déjà implémenté dans le script (pas encore câblé dans
  `install.sh`).
- **`install.sh`** réécrit : `detect_profiles()` étend le glob à `~/.claude` (en plus de
  `~/.claude-*`, pas à leur place) ; dirs système synchronisés via manifeste +
  `rsync -a --checksum --delete --files-from=<liste>` (protection généralisée à **tous** les
  dirs système, plus seulement `coordinator`) ; dirs de contenu et fichiers mutables
  synchronisés via `sync-content-dir.js` ; fallback sans `rsync` en bash pur, respectant le
  même manifeste (merge-safe, ne supprime rien).
- **`.github/workflows/release.yml`** : étape CI qui échoue la release si le manifeste
  committé est périmé — sinon deux bugs silencieux (fichiers neufs jamais installés,
  fichiers mis à jour gelés à tort comme "personnalisation client").

### Un bug trouvé et corrigé pendant l'implémentation, pas anticipé par le brief

**`rsync -a --files-from=… --delete` ne détecte pas un contenu différent quand la taille et
le mtime coïncident** (quick-check par défaut de rsync) — reproduit puis corrigé par
`--checksum`, **vérifié personnellement** dans un bac à sable isolé (fichier source/dest de
même taille/mtime, contenu différent : sans `--checksum` → 0 octet transféré, contenu jamais
mis à jour ; avec `--checksum` → détecté et transféré). Sans ce flag, toute la conception de
cet ADR aurait été inopérante — un mtime issu d'un `zip -r` sur un checkout CI frais
(`.github/workflows/release.yml`) ne prouve jamais rien sur le contenu réel.

### 4 fichiers à double nature trouvés en plus de `pipelines.json`

Trackés par git **et** réécrits au runtime (même classe de bug que l'incident flywheel
anchors déjà vécu cette session) : `coordinator/witness-history.jsonl`,
`coordinator/witness-fixes.json`, `coordinator/agent-audit-baseline.json`,
`coordinator/flywheel-baseline.json` — **vérifiés personnellement** (grep direct dans
`witness.js`/`agent-audit.js`/`flywheel.js` + `git ls-files`). Protégés dans
`MANIFEST_MUTABLE`, même traitement par checksum que `pipelines.json`.

### Vérification personnelle (pas prise sur la foi du rapport d'implémentation)

- Bug `--checksum` reproduit et corrigé moi-même dans un scratch dir isolé (pas relayé sans
  test).
- Les 4 fichiers mutables confirmés trackés + réécrits au runtime, et présents dans
  `MANIFEST_MUTABLE` dans le code livré.
- Structure du manifeste vérifiée : 909 fichiers, aucune fuite de `teams/session-*/`
  (confirmé : seuls `teams/profiles.json` et `teams/routing.md` trackés).
- 4 runs complets de la suite globale : **1618 tests, 0 échec** sur chacun (1 échec signalé
  par l'agent pendant son propre développement, non reproduit sur 4 runs propres — flake
  préexistant probable parmi les suites chronométrées, pas une régression de ce travail).
- Suite dédiée `ada-manifest.test.js` : 65/65, incluant un test d'intégration qui source le
  vrai `install.sh` et appelle la vraie fonction `install_profile()` sur un profil fictif
  sous `os.tmpdir()`, avec de fausses données client (`memory-semantic.json`, `audit.log`,
  `bank.db`, une session `teams/session-vivante/`) — vérifie sur disque qu'elles survivent
  intactes.
- Aucun profil réel de la machine n'a été touché à aucun moment (contrainte du brief,
  respectée).

### Ce qui reste ouvert, explicitement hors périmètre de cette passe

- **E3-3/E1-F** (`benchmarks/`, `templates/`, `memory/`, `archives/`, fichiers racine de
  `.claude/`) : toujours non synchronisés — pas une régression, et devenu trivial à ajouter
  (même mécanique, juste étendre `content_dirs`), mais pas fait ici.
- **E2-4** (`CLAUDE.md` écrasé sans sauvegarde), **E2-6** (`env`/`preferences` de
  `settings.json` jamais mergés), **E2-8** (`--dry-run` pas câblé dans `install.sh` bien
  qu'implémenté dans `sync-content-dir.js`), **E1-B/E1-E/E3-6** (portée et distinction
  premier-install/mise-à-jour) : intouchés.
- Cas limite assumé, non rencontré : un fichier de `MANIFEST_MUTABLE` un jour retiré de la
  source serait supprimé (`prune`) même s'il a été modifié par le client.
- `docs/INSTALL-CLIENT.md` non mis à jour — prévu en dernier, une fois le comportement figé.

---

## Addendum — Axe 1 : couverture étendue + `--dry-run` câblé (2026-08-11)

`content_dirs` passe de `(agents skills teams)` à `(agents skills teams benchmarks
templates memory archives)` — même mécanisme manifeste+checksum, aucun code spécifique
nécessaire (141/4/8/3 fichiers trackés respectivement, vérifié). Ferme E3-3/E1-F pour ces 4
dossiers.

**Écart trouvé avec l'audit E3-3, vérifié** : `benchmarks/v2/results-v2.json` n'est **pas**
gitignoré comme l'audit le supposait — il est **tracké par git** (résultats de référence
committés) **et** réécrit au runtime par `bench-v2.js`. Même classe que `pipelines.json`,
mais n'a pas eu besoin d'entrer dans `MANIFEST_MUTABLE` : le mode `content` (checksum),
maintenant actif sur `benchmarks/`, suffit — un fichier modifié depuis la dernière sync
(donc les résultats du client) n'est jamais écrasé, juste signalé.

`--dry-run` câblé dans `install.sh` : tous les effets de bord (`rsync`, `sync-content-dir`,
`mkdir`, symlink CLI, `npm`, `~/.zshrc`, Obsidian, `doctor`) gardés — **confirmé
personnellement** par un smoke-test de bout en bout (`install.sh --dry-run
--non-interactive` sur un `HOME` factice) : 0 fichier écrit, tous les dossiers correctement
comptés (192/330/2/141/4/8/3), l'étape CLI correctement simulée sans `sudo` réel. Ferme E2-8.

**2ᵉ bug rsync trouvé** (openrsync, même famille que le bug `--checksum` de l'addendum
précédent) : `--dry-run --itemize-changes` rapporte `>f.......` au lieu de `>f+++++++++`
pour un fichier neuf **quand le dossier de destination entier est absent** (cas d'un profil
neuf) — reproduit personnellement (mon premier test avec un dossier de destination déjà
existant ne le reproduisait PAS ; il a fallu tester spécifiquement le cas "dossier absent"
pour confirmer). Contourné en comptant par simple test d'existence de fichier en bash,
indépendant de l'implémentation rsync.

Vérifié personnellement : 1626/1626 tests globaux, 73/73 suite dédiée, syntaxe de tous les
fichiers touchés, aucun profil réel touché. Commit `327cfc7`.

### Ce qui reste, inchangé

E1-B/E1-E/E3-6 (portée et distinction premier-install/mise-à-jour), E2-4 (`CLAUDE.md` sans
sauvegarde), E2-6 (`env`/`preferences` de `settings.json` jamais mergés),
`docs/INSTALL-CLIENT.md` non mis à jour. Aucune validation réelle contre un profil existant
n'a encore été faite (tout est testé en bac à sable) — reste l'étape naturelle suivante,
avec confirmation explicite avant de toucher de vraies données.

---

## Addendum — Axe 2 (2026-08-11)

Ferme E2-4 (`CLAUDE.md` écrasé sans sauvegarde) et E2-6 (`env`/`preferences` de
`settings.json` jamais mergés) — les 2 derniers trous connus de la garantie « zéro perte de
données » (Exigence 2). Portée strictement limitée à ces deux points ; `select_profiles`/
`detect_profiles` (axe 3, E1-B/E1-E/E3-6) non touchés.

### E2-4 — `CLAUDE.md` : fonction dédiée `sync_claude_md()`

Le `cp` inconditionnel (l.625-634) est remplacé par une fonction dédiée `sync_claude_md(src,
dst)`, appelée depuis `install_profile`, avec 3 cas tranchés par **comparaison de contenu**
(`cmp -s`, jamais de mtime — cohérent avec le principe déjà posé par le manifeste de
livraison) :

1. `dst` absent (premier install) → copie simple, aucune sauvegarde.
2. `dst` identique au contenu qui serait écrit → no-op idempotent (pas de `.bak` à chaque
   `ada update` répété si le client n'a rien changé).
3. `dst` différent → sauvegarde D'ABORD vers `CLAUDE.md.bak.<timestamp>`
   (`date +%Y%m%d%H%M%S`, déjà portable macOS/Linux dans le reste du fichier), PUIS
   écrasement par la nouvelle version.

**Décision de conception — format de sauvegarde** : `NOM.bak.<YYYYmmddHHMMSS>`. Vérifié
avant d'inventer quoi que ce soit : aucune convention `.bak.*` n'existait déjà dans le code
du repo (seules des mentions en documentation/exemples, `GUIDE.md`/`ADR-006`/
`ADR-017`) ; en revanche `.gitignore` (l.11 et 38) contient déjà le motif générique
`*.bak.*` — le format choisi tombe directement dans ce motif existant, aucune règle
`.gitignore` à ajouter.

**Décision explicitement laissée de côté, hors scope de cette passe** : aucune politique de
rétention/purge des `.bak.*` — ils s'accumulent à chaque personnalisation détectée sur
chaque `ada update`. Documenté en commentaire dans `sync_claude_md()`.

Extraire la logique dans sa propre fonction (plutôt que de l'inliner dans `install_profile`
comme le code d'origine) suit le style déjà en place pour `merge_settings`/
`_sync_checksum`/`_sync_system_dir` — et rend la fonction testable directement par
sourcing, sans reconstruire un faux dépôt complet pour chacun des 6 scénarios (3 cas ×
avec/sans `--dry-run`).

### E2-6 — `merge_settings()` : `env` et `preferences`

Ajout à la fonction existante (pas de nouvelle fonction — le merge de `settings.json` est
un tout cohérent) : union de clés pour `env` et `preferences`, chacun traité
indépendamment, même logique pour les deux :

- clé source absente côté client → ajoutée (nouveau défaut ADA atteint enfin un profil déjà
  installé — c'était tout le problème signalé par E2-6 : une variable d'environnement
  requise n'atteignait jamais un profil existant) ;
- clé commune, même valeur → rien à faire ;
- clé commune, valeur différente → **la valeur CLIENT gagne toujours**, jamais écrasée
  (symétrique avec `permissions.deny` qui reste additif et avec `permissions.allow` qui
  reste intouché) ;
- clé propre au client, absente de la source → intouchée (évident, mais vérifié par test).

**Décision de conception — format du signal de conflit** : le sous-script `node -e` émet
sur stdout des lignes `CONFLICT<TAB>env|preferences<TAB>clé<TAB>valeur-client<TAB>
valeur-ada` (seule sortie de ce script node — pas de bruit mêlé aux autres messages) ;
`merge_settings` (bash) les relit et affiche un bloc dédié, séparé du message de succès :

```
✓ settings.json mergé (hooks + permissions.deny + env + preferences)
⚠ Conflits env/preferences — valeur CLIENT conservée, ADA ignorée (à réconcilier à la main) :
  • env.DIFF_KEY : client="valeur-client" (conservé) vs ada="valeur-ada" (ignoré)
```

Volontairement PAS silencieux (contrairement à ce qu'un merge additif pur aurait pu
laisser passer sans le dire) : le client doit pouvoir repérer et réconcilier une
divergence, même si ADA ne la résout jamais à sa place.

`permissions.allow` non touché — comportement existant, confirmé inchangé par régression.

### Tests — `.claude/tests/scripts/ada-manifest.test.js`

3 nouveaux blocs, même style que l'existant (sourcing réel de `install.sh` avec `main`
désactivé, profils fictifs sous `os.tmpdir()`) :

- `sync_claude_md` (6 tests) : les 3 cas (absent/identique/différent) × présence/absence de
  `--dry-run` — dry-run vérifié par empreinte de répertoire avant/après (`snapshotTree`),
  pas seulement par lecture ponctuelle.
- `merge_settings` (12 tests) : 4 tests de régression explicites (hooks union, hooks
  dédoublonnage, `permissions.deny` additif, `permissions.allow` intouché) + 8 tests
  `env`/`preferences` (nouvelle clé / même valeur / conflit signalé / clé propre au client,
  ×2 pour les deux objets) + 1 test premier-merge sans conflit.
- Extension du test d'intégration bout-en-bout existant
  (`install.sh :: install_profile`) : un profil déjà installé où le client personnalise
  `CLAUDE.md` ET `env`/`preferences` de `settings.json`, ré-exécution complète
  d'`install_profile`, vérifie en une seule fois : sauvegarde `CLAUDE.md.bak.*` créée avec
  le bon contenu (celui du client, pas le nouveau), nouvelle version en place, clés
  client/`env`/`preferences` préservées y compris en conflit, nouvelles clés ADA arrivées,
  conflit signalé sur stdout, et qu'aucun autre état runtime (bank.db,
  `memory-semantic.json`) n'a été perturbé au passage.

### Vérification personnelle (pas prise sur la foi de l'implémentation seule)

- Les 2 fonctions (`sync_claude_md`, le node -e étendu de `merge_settings`) testées à la
  main dans un scratch dir isolé sous `os.tmpdir()` AVANT d'écrire les tests `node:test` —
  3 cas CLAUDE.md + 1 cas merge avec conflits croisés `env`/`preferences`, sortie inspectée
  ligne à ligne.
- `node --test .claude/tests/scripts/ada-manifest.test.js` : **92/92**, 0 échec (73 avant
  cette passe + 19 nouveaux : 6 `sync_claude_md` + 12 `merge_settings` + 1 intégration).
- `node .claude/tests/run-all.js` (suite globale complète) : **1645/1645, 0 échec, 58/58
  suites** (1626 avant cette passe, cohérent avec les 19 tests ajoutés).
- `bash -n install.sh` : syntaxe valide.
- Aucun profil réel de la machine touché à aucun moment (contrainte du brief respectée —
  toutes les fixtures vivent sous `os.tmpdir()` avec des données inventées).

### Ce qui reste, explicitement hors périmètre de cette passe

- **E1-B/E1-E/E3-6** (portée et distinction premier-install/mise-à-jour) — axe 3, pas
  commencé.
- Politique de rétention/purge des `CLAUDE.md.bak.*` — décision explicitement différée (voir
  plus haut), les fichiers s'accumulent indéfiniment en l'état.
- `docs/INSTALL-CLIENT.md` toujours non mis à jour — prévu en dernier, une fois l'axe 3
  également tranché.
- Aucune validation réelle contre un profil existant n'a encore été faite (tout est testé
  en bac à sable, comme pour les passes précédentes).

---

## Addendum — Axe 3 (2026-08-11)

Ferme E1-B (Cas 3 de `select_profiles` sélectionnait tous les profils du disque, pas
`cfg.installedProfiles`), E1-E (aucune distinction premier-install/mise-à-jour, aucun plan
affiché avant d'agir) et E3-6/E1-G (`ada update`/`ada install` et `bash install.sh` nu
avaient deux portées différentes, ni annoncées ni alignables sans sortir de `ada`). Les 3
axes de la reprise ADR-024 sont maintenant clos.

### E1-B — `select_profiles()` : KNOWN/NEW_ON_DISK

Nouvelle fonction `compute_known_new()` (appelée en tête de `select_profiles`) construit
deux tableaux :
- `KNOWN` = profils de `cfg.installedProfiles` mappés en `$HOME/.<item>` (même convention
  que `getProfileDir` côté `ada.js`) **ET** encore présents sur disque — un profil supprimé
  depuis le dernier install n'y figure jamais.
- `NEW_ON_DISK` = `PROFILES \ KNOWN` — les profils détectés sur disque mais absents de
  `cfg.installedProfiles`.

**Décision de conception non explicitement tranchée par le brief : où loger la logique
d'expansion en mode non-interactif.** Le brief décrit l'annonce connus/nouveaux comme un
comportement du « Cas 3 », mais dans le code existant le Cas 1 (`NONINTERACTIVE == true` —
donc `--all`/`--non-interactive`) retourne **avant** que le Cas 3 ne soit jamais atteint :
un `bash install.sh --all` ne passe jamais par le Cas 3. Plutôt que réordonner les cas (ce
que le brief interdit explicitement — « Garder Cas 1 … inchangé dans leur déclenchement »),
`compute_known_new()` est calculée une fois en tête de fonction et **consommée par les deux
Cas** : le Cas 1 annonce désormais connus/nouveaux quand `~/.ada.json` révèle une expansion
(exactement le comportement demandé, juste logé au bon endroit compte tenu du
court-circuit existant) ; le Cas 3 gère la variante interactive (bascule sur Cas 4).

Comportement final :
- Cas 1 (`--all`/`--non-interactive`) : sélectionne toujours tout (déclenchement inchangé).
  Si `~/.ada.json` a des `installedProfiles` et qu'il existe des `NEW_ON_DISK`, le message
  distingue nommément « déjà connu(s) » et « nouveau(x) ajouté(s) à ce run » — jamais un
  message générique unique. Sinon, message inchangé.
- Cas 2 (n==1) : inchangé, comme demandé.
- Cas 3 (`~/.ada.json` connu, n>1, interactif) : `SELECTED = KNOWN` exactement (plus «
  ${PROFILES[@]}» comme avant — c'est le cœur du bug E1-B) si aucune expansion ; sinon
  bascule sur le Cas 4 sans retour anticipé, avec un avertissement explicite listant
  connus/nouveaux.
- Cas 4 (interactif) : les profils déjà connus sont pré-cochés (`selected_flags` à 1),
  les nouveaux à 0 — l'utilisateur voit et confirme l'expansion au lieu de la deviner.

### Bug trouvé et corrigé pendant l'implémentation, pas anticipé par le brief

`compute_known_new()` se terminait sur `[[ "$is_known" == "false" ]] && NEW_ON_DISK+=(...)`
— si la dernière itération de la boucle rencontre un profil déjà connu, ce test évalue à
faux et devient le statut de sortie de la fonction. Appelée en instruction nue dans
`select_profiles()` (pas dans un `if`/`while`/`&&`), sous `set -e` (actif dès la ligne 3
d'`install.sh`), un statut de sortie non nul de la fonction fait avorter **tout le script**
en silence — reproduit empiriquement (le smoke-test manuel s'arrêtait sans aucun message
d'erreur juste après le calcul de `KNOWN`/`NEW_ON_DISK`). Corrigé par un `return 0` explicite
en fin de fonction. Même classe de piège que le bug `--checksum` et le bug `--itemize-changes`
des deux addenda précédents : une hypothèse implicite sur le comportement de bash/rsync qui
ne tient que dans certains cas, ici le cas « le dernier profil itéré est déjà connu ».

### E1-E — `print_install_plan()`

Lit `$profile_dir/VERSION` (déjà écrit par `install_profile` depuis le début de cet ADR,
jamais lu jusqu'ici avant d'agir) pour chaque profil de `SELECTED`, y compris pour `n==1`
(Cas 2, comme demandé) :
- absent → `[premier install]`
- présent == `$ADA_VERSION` → `[déjà à jour, vX.Y.Z]`
- présent != `$ADA_VERSION` → `[mise à jour vX.Y.Z → vA.B.C]`

Confirmation `y/N` (défaut N) demandée **uniquement** si le plan contient au moins un
`[premier install]` **ou** si `SCOPE_EXPANDED=true` (positionné par `select_profiles` quand
une expansion a été détectée, qu'elle ait été confirmée via Cas 1 non-interactif ou via
Cas 4 interactif) — sinon aucune friction ajoutée au cas courant (mise à jour de profils
déjà connus). En mode non-interactif, le plan s'affiche mais ne lit jamais `stdin` (jamais
bloquant en CI).

**Décision de conception — `SCOPE_EXPANDED` est un drapeau global, pas un retour de
fonction** : `select_profiles` n'a qu'un canal de sortie naturel en bash (les variables
globales `SELECTED`, déjà le pattern existant) — `SCOPE_EXPANDED` suit la même convention
plutôt que d'inventer un mécanisme de retour différent pour cette seule information.

### E3-6/E1-G — Portées alignées et annoncées

- **`install.sh`** : nouvelle fonction `print_scope_banner()`, appelée juste après
  `parse_args` (donc avant `detect_profiles`/`select_profiles`/`print_install_plan`) :
  `--profile <nom>` → « Portée : 1 profil (nom) » ; sinon lecture directe du compte
  `cfg.installedProfiles` dans `~/.ada.json` → « Portée : N profil(s) connu(s) de
  ~/.ada.json » ou « Portée : aucun profil connu — première installation » si absent/vide.
- **`ada.js`** : `cmdInstall`/`cmdUpdate` acceptent désormais `args` (même style que
  `cmdObsidian(args)` déjà en place — dispatcher ligne ~3189-3190 mis à jour pour leur
  passer `args`). `--all` et `--profile <nom>` sont un **passthrough brut** vers
  `install.sh` (pas de logique dupliquée côté `ada.js`) : `ada update --all` /
  `ada install --all` atteignent donc exactement la portée `bash install.sh --all` sans
  sortir de `ada`. Sans `--all`, comportement historique inchangé (1 profil, l'actif, via
  `--profile <profil-actif>`). Un message annonce la portée choisie avant d'invoquer
  l'installeur, dans les deux commandes (elles partagent la même implémentation depuis la
  décision D6 déjà actée).

**Limite assumée, non corrigée ici (hors scope, cf. E1-C/D déjà marqué mineur/non traité)** :
`--all` sélectionne (Cas 1 d'`install.sh`) tous les profils **détectés sur disque**, pas
strictement `cfg.installedProfiles` — comportement historique de `--all`, pas modifié par
cette passe. `ada update --all` atteint donc la portée réelle de `bash install.sh --all`,
qui reste la portée « large » existante, pas une nouvelle portée plus stricte.

### Tests — `.claude/tests/scripts/ada-manifest.test.js`

Deux nouveaux `describe` (+14 tests, même style que l'existant — sourcing réel
d'`install.sh` avec `main` désactivé, `os.tmpdir()`, aucune donnée ni profil réel) :

- **`select_profiles` (5 tests)** : Cas 3 avec `cfg.installedProfiles` exactement égal au
  disque (aucune lecture stdin — preuve qu'aucun prompt n'est déclenché à tort, un `read`
  sur stdin vide sous `set -e` ferait échouer le test) ; sous-ensemble strict (l'extra sur
  disque n'est jamais inclus, confirmé en pilotant le Cas 4 via `stdin`) ; expansion
  non-interactive (message distinguant nommément connus/nouveaux, assertion sur le texte) ;
  expansion interactive (preuve d'atteinte du Cas 4 via la présence du menu numéroté sur
  stdout, pas seulement sur `SELECTED`) ; présélection Cas 4 (Entrée directe ne coche que
  les connus).
- **`print_install_plan` (9 tests)** : les 3 états VERSION (absent/identique/différent,
  avec assertion explicite sur le texte « A → B » de la mise à jour) ; aucune confirmation
  demandée quand rien ne le justifie (stdin vide, preuve par absence de blocage) ; réponse
  n/y sur premier install (annulation avec `exit 0` avant la suite du script vs poursuite) ;
  `SCOPE_EXPANDED` seul déclenche aussi la confirmation ; mode non-interactif jamais
  bloquant ; plusieurs profils dans `SELECTED` reçoivent chacun leur propre ligne.

**Établi pour la première fois dans ce fichier de tests** : piloter `read`/`read -rp` via
l'option `input` d'`execFileSync` (aucun test précédent du fichier n'avait besoin de driver
une boucle interactive avec plusieurs tours de `read` — les tests Cas 4 n'existaient pas
avant cette passe). Vérifié manuellement d'abord (`node` scratch script isolé) que `input`
alimente bien `stdin` d'un process bash avant de l'utiliser dans les tests `node:test`.

**`ada update --all`/`ada install --all` (ada.js) : aucune suite de tests dédiée ajoutée.**
`ada.js` n'a, à date, qu'un seul point d'entrée testé — `require('../../bin/ada.js')` pour
les fonctions explicitement exportées (`module.exports` en fin de fichier :
`resolveRunMode`, `slugifyName`, `planReap`, `cmdTeamReap`, etc., voir
`tests/coordinator/team-reap.test.js`). `cmdInstall`/`cmdUpdate` n'y sont pas exportées, et
les tester nécessiterait soit de les exporter (changement de surface non demandé par le
brief) soit de mocker `loadConfig()`/`spawnSync` — aucun pattern de mock n'existe ailleurs
dans ce fichier CLI. Les exécuter réellement est exclu (règle absolue : jamais contre un
vrai profil, et `cmdInstall` lit `~/.ada.json` réel et lance `bash install.sh` réel). La
logique de construction des arguments (`--all` vs `--profile` vs défaut) a été vérifiée par
lecture directe du code + par le comportement déjà couvert côté `install.sh` (qui reçoit
exactement ces arguments) — pas par un test automatisé dédié à `ada.js`. Documenté ici
plutôt que forcé, comme demandé par le brief.

### Vérification personnelle (pas prise sur la foi de l'implémentation seule)

- Smoke-test manuel des 3 scénarios de portée avec le **vrai** `install.sh` en `--dry-run`
  contre un `$HOME` factice sous `/tmp` (jamais un vrai profil) :
  1. **1 profil connu** (`~/.ada.json` avec `installedProfiles: ["claude-pro"]`,
     `~/.claude-pro` sur disque, `--non-interactive`) → `Portée : 1 profil(s) connu(s) de
     ~/.ada.json`, plan `[premier install]`, aucune confirmation (non-interactif).
  2. **Plusieurs profils connus** (`claude-pro`+`claude-perso`, tous deux sur disque,
     interactif) → `Portée : 2 profil(s) connu(s)…`, réinstallation directe des deux (Cas 3,
     pas de Cas 4), plan affiché, réponse `n` → `Installation annulée.` proprement.
  3. **Expansion de périmètre** (`installedProfiles: ["claude-pro"]`, disque a aussi
     `claude-perso`, `--all`) → message distinguant `1 profil(s) déjà connu(s)… + 1
     nouveau(x) profil(s) ajouté(s) à ce run`, tous deux traités en dry-run.
  Sorties collées ci-dessus dans les commandes exécutées pendant cette passe (voir
  historique de session) ; aucun fichier réel écrit dans les trois cas (`--dry-run`).
- Reproduit et corrigé moi-même le bug `set -e`/`compute_known_new` dans un bac à sable
  isolé (sourcing manuel de `install.sh` avec `bash -x`) avant d'écrire les tests
  `node:test` — pas relayé sans preuve.
- `node --test .claude/tests/scripts/ada-manifest.test.js` : **106/106**, 0 échec, exécuté
  2 fois de suite pour écarter une flakiness liée aux tests pilotant `stdin` (nouveaux dans
  ce fichier) — stable les deux fois.
- `node .claude/tests/run-all.js` (suite globale) : **1659/1659, 0 échec, 58/58 suites**
  (1645 avant cette passe, cohérent avec les 14 tests ajoutés).
- `bash -n install.sh` et `node -c .claude/bin/ada.js` : syntaxe valide.
- Aucun profil réel de la machine (`~/.claude*`) touché à aucun moment — toutes les
  fixtures et tous les smoke-tests vivent sous `os.tmpdir()`/`/tmp` avec des données
  inventées, conformément à la règle absolue du brief.

### Ce qui reste ouvert après cet axe (les 3 axes de la reprise ADR-024 sont clos)

- **E1-C/D** (sémantique `--all`/`--non-interactive` conflatée) — mineur, jamais traité,
  explicitement hors scope de cette passe comme des deux précédentes.
- **`docs/INSTALL-CLIENT.md`** — toujours non mis à jour. Vérifié pendant cette passe : le
  document ne décrit pas encore `ada update --all`/`ada install --all` (normal, la
  fonctionnalité vient d'être ajoutée) mais ne contient rien d'explicitement faux non plus
  sur la portée existante — pas de correction urgente identifiée, mise à jour toujours
  prévue en dernier, une fois tout le comportement de l'installeur figé.
- Politique de rétention/purge des `CLAUDE.md.bak.*` — décision différée depuis l'axe 2,
  toujours non tranchée.
- **Aucune validation réelle contre un profil existant n'a encore été faite** — les 4
  passes de cet ADR (bloquants, axe 1, axe 2, axe 3) ont toutes été vérifiées en bac à
  sable uniquement. C'est l'étape naturelle suivante, avec confirmation explicite de
  l'utilisateur avant de toucher un vrai profil.

---

## Addendum — Corrections issues de la validation réelle (2026-08-11)

**Première validation réelle de cet ADR** contre un vrai profil (`~/.claude-jarvis`, avec
sauvegarde préalable et vérification checksum complète avant/après) : succès, **zéro perte
de données confirmée**. Mais cette validation — pas le bac à sable, qui ne l'avait capturé
dans aucune des 4 passes précédentes — a révélé 2 défauts réels sur `write_env_local()` et
`write_ada_config()`, tous deux dans la même famille : une fonction qui déduit une valeur de
ses propres arguments (la sélection en cours) au lieu de lire l'état réel de `~/.ada.json`.
**Donnée importante pour la suite** : le bac à sable a un angle mort spécifique sur les
configs pré-existantes multi-profils — tous les tests précédents de `write_env_local`/
`write_ada_config` (aucun n'existait avant cette passe, cf. plus bas) partaient d'un
`~/.ada.json` soit absent, soit cohérent avec la sélection en cours ; le scénario qui casse
— *plusieurs profils déjà connus, maintenance d'UN SEUL d'entre eux* — n'avait jamais été
exercé.

### Défaut 1 — `write_env_local()` écrasait `ADA_ACTIVE_PROFILE` sans condition

**Bug confirmé en conditions réelles** : `active_name` était dérivé de
`installed_profiles[0]` — le PREMIER profil de la sélection EN COURS, pas le profil
réellement actif de la machine (`cfg.activeProfile` dans `~/.ada.json`). Reproduit :
`~/.ada.json` avait `activeProfile: "claude-ov"` et `ada-ui/.env.local` contenait
`ADA_ACTIVE_PROFILE=ov` ; un `bash install.sh --profile claude-jarvis` (maintenance d'un
seul profil parmi 4) faisait passer `.env.local` à `ADA_ACTIVE_PROFILE=jarvis` —
silencieusement, sans rapport avec ce qui était demandé, redirigeant l'UI ADA vers un autre
profil que celui réellement actif.

**Correction** : nouvelle fonction `compute_effective_active_profile()` (`install.sh`,
avant `write_env_local()`), lecture seule de `$ADA_CONFIG` — retourne `cfg.activeProfile`
s'il existe, sinon retombe sur le même calcul de bootstrap que `write_ada_config()`
(premier profil de la sélection, comportement de bootstrap inchangé). `write_env_local()`
appelle ce helper au lieu de dériver `active_name` de `installed_profiles[0]` directement.
Le format affiché dans `.env.local` (basename, sans point, sans préfixe `claude-`) et la
validation regex existante (`^[a-z0-9][a-z0-9-]{0,30}$`) sont inchangés.

### Défaut 2 — message dry-run de `write_ada_config()` trompeur

**Bug confirmé en conditions réelles** : `~/.ada.json` avait `installedProfiles:
["claude-perso","claude-pro","claude-ov","claude-jarvis"]` et `activeProfile: "claude-ov"`.
Un `bash install.sh --profile claude-jarvis --dry-run` affichait `~/.ada.json serait mis à
jour (activeProfile=claude-jarvis, installedProfiles=["claude-jarvis"])` — laissant croire
que les 3 autres profils seraient retirés et l'actif changé. **Ce n'était pas ce qui se
passe réellement** (vérifié en relançant sans `--dry-run` puis en relisant `~/.ada.json`) :
le vrai code fait une union filtrée par existence sur disque (aucun profil existant n'est
retiré), et `activeProfile` n'est réécrit que s'il est absent. Le message dry-run décrivait
un comportement qui ne correspondait pas au code qu'il est censé prévisualiser.

**Correction** : nouvelle fonction `compute_ada_config_preview()` (`install.sh`, juste après
`compute_effective_active_profile()`), lecture seule de `$ADA_CONFIG` — duplique exactement
la même logique d'union + filtre `fs.existsSync` que le vrai `node -e` de
`write_ada_config()`, sans jamais écrire. Le bloc dry-run de `write_ada_config()` appelle ce
helper plus `compute_effective_active_profile()` (le même helper que le défaut 1) et
distingue nommément, même esprit que les messages de `select_profiles()` (axe 3) :
- profils déjà connus et toujours sur disque, marqués « inchangé(s) » ;
- nouveaux profils de la sélection en cours, marqués « ajouté(s) à ce run » ;
- l'`activeProfile` effectif, avec la mention « inchangé » ou « défini pour la première
  fois » selon que `cfg.activeProfile` existait déjà ou non.

Exemple exact du nouveau message sur le scénario du bug (4 profils connus, maintenance de
`claude-jarvis` seul) :
```
[dry-run] ~/.ada.json serait mis à jour :
    activeProfile=claude-ov (inchangé)
    installedProfiles inchangé(s) : 4 profil(s) déjà connu(s) (claude-perso, claude-pro, claude-ov, claude-jarvis)
```
Et sur une expansion réelle (nouveau profil détecté) :
```
    installedProfiles : 1 profil(s) déjà connu(s) (claude-pro, inchangé(s)) + 1 nouveau(x) profil(s) ajouté(s) à ce run (claude-extra)
```

**Comportement réel (non-dry-run) non modifié** — seul le message change, conformément à la
contrainte du brief ; vérifié par 2 tests de non-régression dédiés (union complète
appliquée + élagage d'un profil disparu du disque).

### Décision de conception — un helper partagé, un helper dédié

`compute_effective_active_profile()` est partagé entre les deux fonctions (c'est lui qui
corrige le défaut 1 dans `write_env_local()` ET qui fournit l'`activeProfile` affiché dans
le message dry-run corrigé de `write_ada_config()`) — évite que les deux fonctions dérivent
indépendamment une même valeur avec le risque de diverger à nouveau plus tard.
`compute_ada_config_preview()` reste propre à `write_ada_config()` (calcule l'union
`installedProfiles`, pas nécessaire ailleurs). Les deux sont des fonctions bash pures en
lecture seule (aucune écriture sur `$ADA_CONFIG`), suivant le pattern déjà en place pour
`compute_known_new()`/`print_scope_banner()` (lecture de `~/.ada.json` via un `node -e`
inline capturé en variable bash, jamais d'écriture).

### Tests — `.claude/tests/scripts/ada-manifest.test.js`

Deux nouveaux `describe`, même style que l'existant (sourcing réel d'`install.sh` avec
`main` désactivé, `os.tmpdir()`, aucune donnée ni profil réel) :

- **`write_env_local` (4 tests)** : régression exacte du bug réel (`activeProfile` connu
  différent du profil en cours d'installation → `.env.local` reflète `activeProfile`, pas
  la sélection) ; bootstrap sans `~/.ada.json` (comportement préservé) ; cas limite
  `~/.ada.json` présent mais sans `activeProfile` (retombe sur le premier profil de la
  sélection) ; `--dry-run` annonce la bonne valeur, disque strictement inchangé.
- **`write_ada_config` (6 tests)** : régression exacte du bug réel en dry-run (union
  complète annoncée, pas la seule sélection) ; `activeProfile` affiché = celui déjà présent,
  jamais celui de la sélection en cours ; distinction nommée connus/nouveaux sur une
  expansion ; premier install (`~/.ada.json` absent) ; 2 tests de non-régression sur le
  comportement réel non-dry-run (union appliquée sans retrait + élagage d'un profil
  supprimé du disque — cette suite n'avait aucun test dédié à `write_ada_config` avant
  cette passe, ni dry-run ni réel).

### Vérification personnelle (pas prise sur la foi de l'implémentation seule)

- Smoke-test manuel reproduisant EXACTEMENT le scénario réel qui a révélé les 2 bugs, contre
  un `$HOME` fictif sous `/tmp` (jamais un vrai profil), 4 profils connus dans `~/.ada.json`
  dont un seul sélectionné :
  - **Avant le fix** (code d'origine, testé manuellement pendant le diagnostic) :
    `.env.local` passait à `ADA_ACTIVE_PROFILE=jarvis`, message dry-run annonçait
    `installedProfiles=["claude-jarvis"]`.
  - **Après le fix, dry-run** :
    ```
    === write_ada_config (dry-run) ===
      [dry-run] ~/.ada.json serait mis à jour :
        activeProfile=claude-ov (inchangé)
        installedProfiles inchangé(s) : 4 profil(s) déjà connu(s) (claude-perso, claude-pro, claude-ov, claude-jarvis)
    === write_env_local (dry-run) ===
      [dry-run] .env.local serait mis à jour (ADA_ACTIVE_PROFILE=ov)
    ```
    `~/.ada.json` relu après coup : strictement inchangé (`--dry-run` respecté).
  - **Après le fix, réel** : `~/.ada.json` mis à jour avec `activeProfile: "claude-ov"`
    inchangé et `installedProfiles` = union des 4 profils ; `.env.local` contient
    `ADA_ACTIVE_PROFILE=ov`.
  - **Cas bootstrap** (`~/.ada.json` absent, premier install) vérifié séparément, dry-run et
    réel : `activeProfile=claude-ada` (« défini pour la première fois »), `.env.local`
    contient `ADA_ACTIVE_PROFILE=ada` — comportement de premier install inchangé.
- `bash -n install.sh` : syntaxe valide.
- `node --test .claude/tests/scripts/ada-manifest.test.js` : **116/116**, 0 échec (106 avant
  cette passe + 10 nouveaux : 4 `write_env_local` + 6 `write_ada_config`).
- `node .claude/tests/run-all.js` (suite globale) : **1669/1669, 0 échec, 58/58 suites**
  (1659 avant cette passe, cohérent avec les 10 tests ajoutés).
- Aucun profil réel de la machine (`~/.claude*`) touché à aucun moment pendant cette passe
  de correction — toutes les fixtures et tous les smoke-tests vivent sous `os.tmpdir()`/
  `/tmp` avec des données inventées, conformément à la règle absolue du brief. Seule la
  validation réelle qui a précédé cette passe (et qui a révélé les 2 bugs) a touché
  `~/.claude-jarvis`, avec sauvegarde préalable et vérification checksum complète — hors
  périmètre de cette tâche de correction.

### Ce qui reste ouvert

- **E1-C/D** (sémantique `--all`/`--non-interactive` conflatée) — mineur, toujours non
  traité.
- **`docs/INSTALL-CLIENT.md`** — toujours non mis à jour, prévu en dernier une fois le
  comportement de l'installeur figé.
- Politique de rétention/purge des `CLAUDE.md.bak.*` — décision différée depuis l'axe 2,
  toujours non tranchée.
- Angle mort de méthode noté ci-dessus (bac à sable insuffisant sur les configs
  pré-existantes multi-profils) : aucune action corrective générale prise au-delà de la
  correction ponctuelle des 2 défauts trouvés — à garder en tête pour une éventuelle
  prochaine validation réelle (autre machine, autre topologie de profils).
