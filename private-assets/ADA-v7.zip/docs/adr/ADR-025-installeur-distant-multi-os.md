# ADR-025 — Installeur distant multi-OS pour repo privé (bootstrap token-gated)

**Statut** : Proposé — stratégie validée par l'utilisateur, implémentation différée (V1
partielle en cours : installeurs locaux par OS, cf. « Note de transition » en fin de
document).
**Date** : 2026-08-28
**Décideurs** : Jonathan Arms
**Méthode** : vérification technique du mécanisme de téléchargement authentifié sur un
repo GitHub privé (comportement `raw.githubusercontent.com` + token écarté comme non
fiable/non documenté officiellement ; API GitHub Releases confirmée comme chemin correct,
y compris le comportement de `curl -L` sur la redirection 302 vers le stockage blob
signé) ; lecture de l'infrastructure existante (`.github/workflows/release.yml`,
`install.sh`, `.claude/package.json`) ; confrontation aux contraintes produit déjà actées
(repo privé permanent, ADR-020).

---

## Contexte

ADA est un produit commercial à **vente perpétuelle**. Le repo GitHub est **privé de
façon permanente** — contrainte business ferme, jamais public. Le modèle économique ne
comporte **aucune logique de licensing/entitlement dans le produit lui-même** : ADR-020
proposait un backend d'entitlement par siège et a été **rejeté explicitement le jour même
de sa rédaction**, précisément parce qu'il supposait un modèle SaaS par abonnement qui ne
correspond pas au modèle réel (vente ciblée, licence perpétuelle, zéro restriction
d'usage après vente, zéro vérification réseau au runtime). Cette ADR-025 s'inscrit dans
la continuité directe de ce rejet : tout mécanisme de distribution proposé ici doit
respecter la même contrainte — ne rien ajouter au produit qui ressemble, de près ou de
loin, à une vérification de licence.

Le canal de vente actuel est **manuel** : vente directe (virement, facture), faible
volume, géré à la main par l'utilisateur. Il n'existe aujourd'hui aucune automatisation
de facturation ni d'émission d'accès.

**Objectif** : un installeur one-liner façon Homebrew/rustup — `curl | bash` sur
macOS/Linux, `irm | iex` PowerShell sur Windows — qui fonctionne malgré le repo privé.

**Infrastructure existante, à réutiliser telle quelle** :
- `.github/workflows/release.yml` — déjà fonctionnel : build d'un zip propre sur tag
  `vX.Y.Z`, génère `SHA256SUMS`, publie une GitHub Release.
- `install.sh` — 1669 lignes bash, logique de setup local (détection de profils,
  manifeste, synchronisation système/contenu, UI, backend). Suppose aujourd'hui qu'il
  tourne **depuis le repo déjà cloné** — ce n'est **pas** un installeur distant, c'est la
  logique locale que cette ADR doit préserver et déléguer, pas réécrire.

`ADR-024-etat-des-lieux-installeur.md` documente déjà l'état et les défauts connus
d'`install.sh` côté logique locale (détection de profils, zéro perte de données). Cette
ADR-025 ne re-traite **pas** ces points : elle porte sur la couche
distribution/téléchargement distante, orthogonale à la logique locale d'ADR-024.

---

## Mécanisme de distribution retenu

**Écarté** : `raw.githubusercontent.com` + header `Authorization` sur un repo privé —
comportement non fiable, non documenté officiellement par GitHub pour ce cas d'usage.

**Retenu : API GitHub Releases + fine-grained Personal Access Token (PAT).**

- **Métadonnées** : `GET /repos/{owner}/{repo}/releases/latest` (ou
  `/releases/tags/vX.Y.Z`) avec `Authorization: Bearer <token>`.
- **Téléchargement du binaire** : `GET /repos/{owner}/{repo}/releases/assets/{asset_id}`
  avec `Accept: application/octet-stream` + `Authorization: Bearer <token>` — **pas**
  `browser_download_url`, qui nécessite une session cookie et ne fonctionne pas en
  curl+token pour un repo privé.
- `curl -L` gère la redirection 302 vers le stockage blob signé et **retire
  automatiquement l'en-tête `Authorization` sur une redirection cross-domaine** —
  comportement sûr par construction, vérifié.
- **Permission PAT requise** : fine-grained, "Contents" (lecture seule), scope limité à
  ce seul repo, avec date d'expiration (proposé 30 jours par défaut — à confirmer par
  l'utilisateur au moment de l'implémentation, cf. « Risques et décisions ouvertes »).
- **Émission de token forcément manuelle** : aucune API GitHub ne permet de créer un
  fine-grained PAT programmatiquement. Cohérent avec la vente manuelle actuelle — aucune
  automatisation à construire en V1.

### Architecture à deux niveaux

1. **Bootstrap public** — un petit repo GitHub public dédié (pas un gist : versionnable,
   historique attribuable, limite le typosquat), contenant **seulement**
   `install.sh`/`install.ps1` minimalistes, **zéro propriété intellectuelle ADA dedans**.
   Rôle : lire le token (env `ADA_TOKEN` ou prompt masqué) → résoudre la release visée via
   l'API metadata → télécharger le zip + `SHA256SUMS` via l'API asset authentifiée →
   vérifier le checksum → extraire → `exec` vers le vrai `install.sh` du zip extrait
   (celui du repo privé, logique de setup local **inchangée**) en transmettant les flags
   utilisateur.
2. **Contenu réel** — reste sur le repo privé, jamais dupliqué ailleurs. `VERSION` (racine
   du repo) reste la source unique de vérité : le tag résolu par l'API pilote quelle
   release est fetchée ; `install.sh` interne relit `VERSION` du zip extrait exactement
   comme aujourd'hui.

---

## Frontière de sécurité — le point le plus important de cette ADR

**Le token ne sert QU'À authentifier le téléchargement** (2 appels API : metadata +
asset). Le CLI `ada` installé **ne lit, ne valide et ne dépend jamais** de ce token pour
exécuter une commande — aucune vérification de licence au runtime, aucun phone-home.

Ceci est directement conforme au rejet d'ADR-020 : le produit ne doit contenir aucune
logique de gestion du modèle économique. Le token de cette ADR n'en est pas une — c'est
un credential de *fetch*, pas un credential d'*usage*.

**Seul usage légitime de conserver le token localement après install** : `ada update`
refait le même fetch authentifié plus tard. À traiter comme un credential de fetch
(analogie directe : un token `.npmrc` de registre npm privé), **jamais** comme une
licence contrôlée par le produit. Si le token expire ou est révoqué, `ada update` cesse
de fonctionner — le CLI `ada` déjà installé, lui, continue de fonctionner sans aucune
restriction, indéfiniment.

---

## Sécurité — autres points

- **Blast radius d'une fuite de token limité par construction** : lecture seule, un seul
  repo, expiration courte. Au pire, un tiers télécharge gratuitement une version ; aucun
  accès en écriture, aucune compromission de compte, aucun accès à d'autres repos. C'est
  un risque commercial (équivalent à un zip revendu ou partagé), pas un risque
  infrastructure.
- **Révocation manuelle disponible** (GitHub Settings → Developer settings →
  Fine-grained tokens) en cas de remboursement ou de fuite constatée.
- **Vérification du `SHA256SUMS`** (déjà produit par `release.yml`) obligatoire avant
  extraction côté bootstrap.
- **Chemin d'audit alternatif à documenter** dans le README/instructions client :
  `curl -fsSL <url> -o install.sh && less install.sh && bash install.sh` — coût nul,
  offre un chemin de vérification à l'utilisateur averti qui ne veut pas piper directement
  vers `bash`.
- **Jamais de `sudo`** requis dans le bootstrap — installation dans `$HOME` uniquement.
- **Note à documenter, ton neutre** : `pre-tool-validator.js` (hook ADA) bloque le pattern
  `curl|bash` comme dangereux pour le code **généré par les agents ADA eux-mêmes**. À
  anticiper explicitement dans le README/marketing de l'installeur, en distinguant
  clairement les deux cas : ce blocage vise du code produit par une IA et non vérifié,
  pas une distribution propre, vérifiable par checksum, dont le mécanisme est documenté
  publiquement.
- **Pas de signature cryptographique (Sigstore/GPG) en V1** : complexité de gestion de
  clés disproportionnée pour un mono-développeur vendant en direct. Checksum + review
  humaine suffisent au niveau de risque réel décrit ci-dessus.

---

## Faisabilité par plateforme

- **macOS/Linux** : ne pas réécrire `install.sh` (1669 lignes, déjà testé, gère profils/
  manifeste/UI/backend). Le bootstrap distant s'ajoute comme une couche séparée qui
  délègue ensuite à ce script inchangé.
- **Windows** : PowerShell natif (`.ps1`), pas de WSL imposé (friction que ni rustup ni
  Homebrew n'imposent), pas de dépendance implicite à Git Bash (non garanti présent, non
  testé en CI). **Blocage réel identifié** : `install_ui()` installe `ada-ui`
  inconditionnellement aujourd'hui, qui dépend de `node-pty` (module natif, nécessite
  node-gyp + Visual Studio Build Tools sur Windows). Recommandation : découpler l'UI en
  opt-in explicite (`--with-ui` / `ADA_INSTALL_UI=1`), **CLI-only par défaut sur TOUTES
  les plateformes** (pas seulement Windows, pour cohérence), avec un message clair
  post-install pointant vers la commande d'installation de l'UI en opt-in.
- **Node.js** : V1 se contente de vérifier la version (`>=22.0.0`, déclarée dans
  `.claude/package.json`), sans installation automatique.

---

## Décision

Adopter l'architecture bootstrap public + API GitHub Releases + fine-grained PAT décrite
ci-dessus comme mécanisme cible de distribution distante. L'implémentation est
**séquencée** ci-dessous mais **différée** : seule la V1 partielle des installeurs locaux
par OS est engagée à la date de cette ADR (cf. « Note de transition »).

### Stratégie d'implémentation (séquencée, V1)

1. Repo public dédié au bootstrap (vide de toute propriété intellectuelle).
2. Bootstrap `install.sh` distant (fetch authentifié + checksum + extraction +
   délégation).
3. Découpler `install_ui()` en opt-in dans `install.sh` existant (patch ciblé).
4. Stockage local du token (`~/.ada-credentials.json` chmod 600, ou Keychain OS —
   arbitrage différé, non bloquant) + adaptation de `ada update` pour le réutiliser.
5. `install.ps1` Windows — bootstrap distant équivalent, CLI-only par défaut, réutilisant
   `bin/ada.js`/`bin/create.js` (Node pur) pour la logique fine plutôt que de dupliquer en
   PowerShell.
6. Runbook manuel côté vendeur (hors code) : émission d'un fine-grained PAT par vente
   (repo unique, permission Contents:Read seule, expiration 14-30 jours), transmission au
   client avec les instructions curl/irm.

**Parallélisable** : (1) et (3) sont indépendants entre eux. (5) peut démarrer dès que le
design d'auth de (2) est validé — même logique, deux implémentations séparées.

### Hors scope V1 — explicitement écarté

Auto-installation de Node.js, publication npm, signature cryptographique du zip, WSL
comme chemin officiel Windows, auto-update silencieux via le bootstrap, portage complet
de la logique bash en PowerShell (le `.ps1` doit rester un bootstrap mince), tout serveur
de distribution/proxy custom, minting automatique de tokens, intégration paiement,
rotation/auto-renouvellement de token.

---

## Alternatives rejetées

| Option | Raison du rejet |
|---|---|
| `raw.githubusercontent.com` + header Authorization | Comportement non fiable, non documenté officiellement par GitHub sur un repo privé |
| `npm install -g` (package `.claude/package.json`, déjà `bin.ada`/`bin.create-ada`) | Licence `UNLICENSED` ; un registre npm public est incompatible avec le gating par repo privé ; un registre npm privé pose le même problème d'authentification sans bénéfice sur l'approche API Releases |
| Installation automatique de Node.js via l'installeur (nvm/fnm/binaire) | Projet à part entière, risque disproportionné pour une V1 ; se contenter de vérifier la version et pointer vers nodejs.org, comme aujourd'hui |
| Serveur de distribution/proxy custom | Sur-ingénierie vu le volume de vente manuel annoncé ; à ne réévaluer que si le volume dépasse la capacité d'émission manuelle de tokens |

---

## Risques et décisions ouvertes (à trancher avant ou pendant l'implémentation, pas par cette ADR)

- Durée d'expiration du token par défaut (proposé 30 jours).
- UX de `ada update` si le token a expiré (message d'erreur guidant vers contact manuel,
  vs silence).
- Mode de stockage local du token (JSON chmod 600 en V1, Keychain OS en amélioration
  future).
- Besoin réel d'un accès `git clone` en plus du simple zip (le token fonctionne aussi en
  HTTPS git clone) — à confirmer si un cas d'usage client l'exige, sinon ne pas le
  designer pour rien.
- CI : `ci.yml` actuel n'a aucun runner Windows (matrix ubuntu/macos seulement côté core,
  ubuntu seul côté ui/api) — à ajouter avant de livrer `install.ps1` en production, pour
  éviter une régression Windows non détectée.
- Nom de domaine/URL canonique du one-liner à documenter dans les instructions client une
  fois le repo bootstrap public créé.

---

## Conséquences

**Positives :**
- Un installeur one-liner devient possible malgré le repo privé permanent, sans jamais
  publier de code ADA.
- Zéro logique de licensing/entitlement ajoutée au produit — le token reste un credential
  de fetch, pas un mécanisme d'usage. Conforme au rejet d'ADR-020.
- `install.sh` local (1669 lignes, déjà testé par ADR-024) reste inchangé et réutilisé tel
  quel — aucune réécriture de la logique de setup.
- Le blast radius d'une fuite de token est borné et documenté (lecture seule, un repo,
  expiration courte).

**Négatives / compromis acceptés :**
- L'émission de token reste manuelle — aucune automatisation de vente construite en V1,
  cohérent avec le volume actuel mais un goulot si le volume augmente.
- Deux surfaces à maintenir en parallèle (bootstrap public minimal + repo privé) — un
  écart entre elles (ex. bootstrap qui pointe vers une mauvaise release) est un risque
  d'exploitation à surveiller.
- Windows nécessite un script distinct (`install.ps1`) et un renoncement à l'UI par
  défaut — expérience non strictement identique à macOS/Linux tant que l'UI opt-in n'est
  pas documentée clairement.
- Pas de signature cryptographique : la garantie d'intégrité repose sur checksum + review
  humaine, pas sur une preuve cryptographique de provenance.
- Aucune implémentation n'est engagée par cette ADR au-delà de la V1 locale déjà en
  cours — la distribution distante reste un chantier futur, non planifié dans le temps.

---

## Note de transition vers l'implémentation immédiate en cours

En parallèle de cette ADR, un premier lot d'implémentation a été engagé le 2026-08-28,
portant **uniquement sur l'installeur LOCAL par OS** — pas encore le bootstrap distant
token-gated décrit ci-dessus : garantir qu'`install.sh` (macOS/Linux) et un nouvel
`install.ps1` (Windows, setup local équivalent, sans mécanisme de fetch distant)
fonctionnent chacun correctement sur leur plateforme. Le mécanisme de distribution
distante (bootstrap public + token) décrit dans cette ADR reste, lui, **différé à une
session ultérieure**.

---

## Fichiers concernés (aucun modifié par ce document)

```
install.sh                          logique locale existante, à réutiliser inchangée, à découpler (install_ui() opt-in)
install.ps1                         n'existe pas encore ; V1 locale en cours (cf. note de transition)
.github/workflows/release.yml       déjà fonctionnel (zip + SHA256SUMS + Release), réutilisé tel quel
.claude/package.json                bin.ada/bin.create-ada existants, licence UNLICENSED, non concerné par npm en V1
docs/adr/ADR-020-...                rejet du licensing/entitlement — contrainte structurante de cette ADR
docs/adr/ADR-024-...                état des lieux de la logique locale d'install.sh — orthogonal, non re-traité ici
(nouveau) repo bootstrap public     à créer — étape 1 du plan, vide de propriété intellectuelle ADA
```
