# ADA SaaS API — Exemples curl

> Variables : `BASE=https://api.ada.ai/v1` / `TOKEN=<access_token>` / `WS=<workspace_id>`

---

## 1. AUTH

### Créer un compte
```bash
curl -X POST $BASE/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "alice@acme.com",
    "password": "S3cur3P@ss!",
    "display_name": "Alice Martin"
  }'
# 201 → { access_token, refresh_token, expires_in: 900, token_type: "Bearer" }
```

### Erreur — email déjà utilisé
```bash
# 409 → { "error": "CONFLICT", "detail": "Email déjà enregistré" }
```

### Login
```bash
curl -X POST $BASE/auth/login \
  -H "Content-Type: application/json" \
  -d '{ "email": "alice@acme.com", "password": "S3cur3P@ss!" }'
# 200 → { access_token, refresh_token, expires_in: 900 }
```

### Erreur — mauvais mot de passe
```bash
# 401 → { "error": "UNAUTHORIZED", "detail": "Identifiants invalides" }
```

### Refresh token
```bash
curl -X POST $BASE/auth/refresh \
  -H "Content-Type: application/json" \
  -d '{ "refresh_token": "<refresh_token>" }'
# 200 → { access_token, refresh_token, expires_in: 900 }
```

### Logout
```bash
curl -X POST $BASE/auth/logout \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{ "refresh_token": "<refresh_token>" }'
# 204 No Content
```

---

## 2. WORKSPACES

### Créer un workspace
```bash
curl -X POST $BASE/workspaces \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{ "name": "Acme Corp", "logo_url": "https://cdn.acme.com/logo.png" }'
# 201 → { id, name, slug: "acme-corp", plan: "free", created_at }
```

### Erreur — slug déjà pris
```bash
# 409 → { "error": "CONFLICT", "detail": "Le slug 'acme-corp' est déjà utilisé" }
```

### Lister mes workspaces
```bash
curl $BASE/workspaces \
  -H "Authorization: Bearer $TOKEN"
# 200 → { data: [...], meta: { total, page, limit, pages } }
```

### Inviter un membre
```bash
curl -X POST $BASE/workspaces/$WS/invitations \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{ "email": "bob@acme.com", "role": "member" }'
# 201 → { id, email, role, status: "pending", expires_at }
```

### Erreur — rôle insuffisant (viewer tente d'inviter)
```bash
# 403 → { "error": "FORBIDDEN", "detail": "Rôle admin ou supérieur requis" }
```

### Modifier le rôle d'un membre
```bash
curl -X PATCH $BASE/workspaces/$WS/members/<memberId> \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{ "role": "admin" }'
# 200 → { id, user_id, role: "admin", ... }
```

### Accepter une invitation
```bash
curl -X POST $BASE/invitations/<token>/accept
# 200 → { id, user_id, workspace_id, role, joined_at }
```

---

## 3. AGENT STORE

### Parcourir le catalogue
```bash
curl "$BASE/store/agents?category=engineering&sort=popular&page=1&limit=24"
# 200 → { data: [{ id, name, category, pricing, avg_rating, ... }], meta }
```

### Recherche full-text
```bash
curl "$BASE/store/agents?q=legal+review&is_verified=true"
# 200 → { data: [...], meta }
```

### Erreur — catégorie invalide
```bash
curl "$BASE/store/agents?category=unknown"
# 400 → { "error": "VALIDATION_ERROR", "fields": { "category": "enum" } }
```

### Détail d'un agent
```bash
curl $BASE/store/agents/<agentId>
# 200 → { id, name, version, capabilities, pricing, reviews: [...], changelog: [...] }
```

### Soumettre un avis
```bash
curl -X POST $BASE/store/agents/<agentId>/reviews \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{ "rating": 5, "body": "Excellent agent, très précis sur les contrats SaaS." }'
# 201 → { id, rating, body, author_name, created_at }
```

### Erreur — avis déjà soumis
```bash
# 409 → { "error": "CONFLICT", "detail": "Vous avez déjà soumis un avis pour cet agent" }
```

---

## 4. INSTALLATIONS

### Installer un agent (gratuit)
```bash
curl -X POST $BASE/workspaces/$WS/installations \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "agent_id": "550e8400-e29b-41d4-a716-446655440000",
    "config": { "default_language": "fr", "max_retries": 2 }
  }'
# 201 → { id, agent_id, workspace_id, status: "active", installed_at }
```

### Erreur — paiement requis
```bash
# 402 → { "error": "PAYMENT_REQUIRED", "detail": "Cet agent nécessite un abonnement Pro" }
```

### Lister les agents installés
```bash
curl "$BASE/workspaces/$WS/installations?status=active" \
  -H "Authorization: Bearer $TOKEN"
# 200 → { data: [{ id, agent: { name, version, ... }, status, config }], meta }
```

### Désinstaller un agent
```bash
curl -X DELETE $BASE/workspaces/$WS/installations/<installationId> \
  -H "Authorization: Bearer $TOKEN"
# 204 No Content
```

---

## 5. TEAMS

### Créer une équipe
```bash
curl -X POST $BASE/workspaces/$WS/teams \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Full Stack Feature Team",
    "pipeline_id": "feature",
    "members": [
      { "agent_installation_id": "uuid-db-agent", "role_in_team": "contributor", "order": 0 },
      { "agent_installation_id": "uuid-nestjs-agent", "role_in_team": "contributor", "order": 1 },
      { "agent_installation_id": "uuid-nextjs-agent", "role_in_team": "contributor", "order": 2 },
      { "agent_installation_id": "uuid-reviewer-agent", "role_in_team": "reviewer", "order": 3 }
    ]
  }'
# 201 → { id, name, pipeline_id, members: [...], created_at }
```

### Lister les équipes
```bash
curl "$BASE/workspaces/$WS/teams?pipeline_id=feature&is_active=true" \
  -H "Authorization: Bearer $TOKEN"
# 200 → { data: [...], meta }
```

### Modifier la composition
```bash
curl -X PATCH $BASE/workspaces/$WS/teams/<teamId> \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "members": [
      { "agent_installation_id": "uuid-nestjs-agent", "role_in_team": "lead", "order": 0 },
      { "agent_installation_id": "uuid-reviewer-agent", "role_in_team": "reviewer", "order": 1 }
    ]
  }'
# 200 → { id, members: [...], updated_at }
```

---

## 6. RUNS

### Lancer un run
```bash
curl -X POST $BASE/workspaces/$WS/runs \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "pipeline_id": "feature",
    "team_id": "uuid-full-stack-team",
    "input": {
      "feature_description": "Ajouter la gestion des tags sur les factures",
      "target_model": "Invoice"
    },
    "flags": []
  }'
# 201 → { id, status: "queued", pipeline_id, phases: [], created_at }
```

### Erreur — pipeline invalide
```bash
# 422 → { "error": "UNPROCESSABLE_ENTITY", "detail": "Pipeline 'feature' requiert un agent 'db' absent de l'équipe" }
```

### Historique des runs
```bash
curl "$BASE/workspaces/$WS/runs?status=completed&sort=created_at:desc&limit=10" \
  -H "Authorization: Bearer $TOKEN"
# 200 → { data: [{ id, pipeline_id, status, duration_ms, phases }], meta }
```

### Détail d'un run (résultats)
```bash
curl $BASE/workspaces/$WS/runs/<runId> \
  -H "Authorization: Bearer $TOKEN"
# 200 → { id, status, phases: [{ phase_id, status, output, duration_ms }] }
```

### Annuler un run
```bash
curl -X POST $BASE/workspaces/$WS/runs/<runId>/cancel \
  -H "Authorization: Bearer $TOKEN"
# 200 → { id, status: "cancelled" }
```

### Erreur — run déjà terminé
```bash
# 400 → { "error": "BAD_REQUEST", "detail": "Impossible d'annuler un run avec le statut 'completed'" }
```

### Stream SSE (temps réel)
```bash
curl -N "$BASE/workspaces/$WS/runs/<runId>/events?token=$TOKEN" \
  -H "Accept: text/event-stream"
# Stream SSE — voir structure des événements ci-dessous
```

---

## 7. MCP CONNECTORS

### Catalogue public
```bash
curl "$BASE/connectors?q=notion&auth_type=api_key"
# 200 → { data: [{ id, name, slug, auth_type, required_scopes }], meta }
```

### Installer un connecteur (API key)
```bash
curl -X POST $BASE/workspaces/$WS/connectors \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "connector_id": "uuid-notion-connector",
    "display_name": "Notion Acme",
    "credentials": { "api_key": "secret_xxxxx" }
  }'
# 201 → { id, status: "active", connector: { name, slug }, created_at }
```

### Installer un connecteur OAuth2
```bash
curl -X POST $BASE/workspaces/$WS/connectors \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "connector_id": "uuid-hubspot-connector",
    "display_name": "HubSpot CRM",
    "credentials": {
      "code": "<oauth_code>",
      "redirect_uri": "https://app.ada.ai/oauth/callback"
    }
  }'
# 201 → { id, status: "active", scopes_granted: ["contacts:read", "deals:write"] }
```

### Statut d'un connecteur
```bash
curl $BASE/workspaces/$WS/connectors/<connectorInstanceId> \
  -H "Authorization: Bearer $TOKEN"
# 200 → { id, status: "active", last_used_at, connector: { name } }
```

### Définir les permissions par agent
```bash
curl -X PUT $BASE/workspaces/$WS/connectors/<connectorInstanceId>/permissions \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "permissions": [
      {
        "agent_installation_id": "uuid-nestjs-agent",
        "allowed": true,
        "allowed_operations": ["read", "write"]
      },
      {
        "agent_installation_id": "uuid-reviewer-agent",
        "allowed": true,
        "allowed_operations": ["read"]
      },
      {
        "agent_installation_id": "uuid-nextjs-agent",
        "allowed": false
      }
    ]
  }'
# 200 → { data: [{ id, agent_installation_id, allowed, allowed_operations }] }
```

### Erreur — agent non membre du workspace
```bash
# 400 → { "error": "VALIDATION_ERROR", "detail": "L'agent 'uuid-xxx' n'est pas installé dans ce workspace" }
```

---

## 8. ADA LOCAL API (ada-ui)

> Variables : `LOCAL=http://localhost:3000` (port par défaut ada-ui)
> Pas d'auth — API locale uniquement accessible sur localhost.

### MCP Registry — lire registre + catalogue
```bash
curl $LOCAL/api/mcp/registry
# 200 → { registry: { version: 1, connectors: { ... } }, catalog: [ 15 entrées ] }
```

### MCP Registry — ajouter un connecteur
```bash
curl -X POST $LOCAL/api/mcp/registry \
  -H "Content-Type: application/json" \
  -d '{
    "id": "my-custom-mcp",
    "enabled": true,
    "command": "npx",
    "args": ["-y", "@my-org/my-mcp"],
    "env": { "MY_API_KEY": "value" },
    "description": "My custom MCP server",
    "tags": ["custom"]
  }'
# 201 → { id, enabled, command, args, env, addedAt, ... }
```

### MCP Registry — activer/désactiver un connecteur
```bash
curl -X PATCH $LOCAL/api/mcp/registry/my-custom-mcp \
  -H "Content-Type: application/json" \
  -d '{ "enabled": false }'
# 200 → { id, enabled: false, ... }
```

### MCP Registry — supprimer un connecteur
```bash
curl -X DELETE $LOCAL/api/mcp/registry/my-custom-mcp
# 204 No Content
```

### Audit Log
```bash
curl "$LOCAL/api/stats/audit?limit=100"
# 200 → [{ ts, op, subject, detail }, ...]
# ops: run.init, run.start, phase.start, phase.done, phase.fail, run.complete, run.fail
```

### Stats coût
```bash
curl "$LOCAL/api/stats/cost"
# 200 → {
#   total: { tokens: 45230, cost: 0.87 },
#   byAgent: { nestjs: { tokens: 12000, cost: 0.23 }, ... },
#   byPipeline: { feature: { tokens: 28000, cost: 0.54 }, ... },
#   recentRuns: [{ id, cost, tokens, pipeline, startedAt }]
# }
```

### Pipelines — liste
```bash
curl $LOCAL/api/pipelines
# 200 → [{ name, description, phases: [{ id, label, agent, depends, required, ... }] }]
```

### Pipelines — créer
```bash
curl -X POST $LOCAL/api/pipelines \
  -H "Content-Type: application/json" \
  -d '{
    "name": "my-pipeline",
    "description": "Mon pipeline custom",
    "phases": [
      { "id": "design", "label": "Design", "agent": "feature-architect", "depends": [], "required": true }
    ]
  }'
# 201 → pipeline créé
```

### Schedules — liste
```bash
curl $LOCAL/api/schedules
# 200 → [{ id, name, pipeline, cron, enabled, createdAt, lastRun }]
```

### Schedules — créer
```bash
curl -X POST $LOCAL/api/schedules \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Nightly Review",
    "pipeline": "review",
    "cron": "0 2 * * *",
    "enabled": true
  }'
# 201 → { id, name, pipeline, cron, enabled, createdAt, lastRun: null }
```

### Schedules — toggle
```bash
curl -X PATCH $LOCAL/api/schedules/<id> \
  -H "Content-Type: application/json" \
  -d '{ "enabled": false }'
# 200 → schedule mis à jour
```

### Webhook — lire config
```bash
curl $LOCAL/api/settings/webhook
# 200 → { url, events, secret } | 404 si non configuré
```

### Webhook — configurer
```bash
curl -X POST $LOCAL/api/settings/webhook \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://hooks.slack.com/services/xxx",
    "events": ["run.complete", "run.fail"],
    "secret": "my-hmac-secret"
  }'
# 200 → webhook enregistré
```

### Webhook — supprimer
```bash
curl -X DELETE $LOCAL/api/settings/webhook
# 204 No Content
```

### Run — réessayer les phases échouées
```bash
curl -X POST $LOCAL/api/runs/<runId>/retry
# 200 → state mis à jour (phases failed → pending, run relancé)
# 400 → run non failed
# 500 → erreur CLI (stderr retourné)
```

### SSE — stream fichiers
```bash
curl -N "$LOCAL/api/events" -H "Accept: text/event-stream"
# Stream d'événements :
# data: { type: "state", profile: "claude-pro", runId: "xxx" }
# data: { type: "agents", profile: "claude-pro" }    <- hot-reload agents
# data: { type: "run", profile: "claude-pro", runId: "yyy" }
# data: { type: "ping" }    <- keepalive 30s
```
