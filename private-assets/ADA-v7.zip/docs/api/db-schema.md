# ADA SaaS — Schéma de base de données

Stack : PostgreSQL (via TypeORM / NestJS)
Conventions : uuid PK, timestamps (created_at, updated_at), workspace_id sur toutes les tables métier.

---

## Tables

### `users`
```sql
CREATE TABLE users (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email         TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  display_name  TEXT NOT NULL,
  avatar_url    TEXT,
  is_active     BOOLEAN DEFAULT true,
  created_at    TIMESTAMPTZ DEFAULT now(),
  updated_at    TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_users_email ON users(email);
```

### `refresh_tokens`
```sql
CREATE TABLE refresh_tokens (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash  TEXT NOT NULL UNIQUE,   -- bcrypt du token opaque
  expires_at  TIMESTAMPTZ NOT NULL,
  revoked_at  TIMESTAMPTZ,
  created_at  TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_refresh_tokens_user_id ON refresh_tokens(user_id);
CREATE INDEX idx_refresh_tokens_hash ON refresh_tokens(token_hash);
```

### `workspaces`
```sql
CREATE TABLE workspaces (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name       TEXT NOT NULL,
  slug       TEXT NOT NULL UNIQUE,
  plan       TEXT NOT NULL DEFAULT 'free'
               CHECK (plan IN ('free','starter','pro','enterprise')),
  logo_url   TEXT,
  deleted_at TIMESTAMPTZ,   -- soft delete
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_workspaces_slug ON workspaces(slug);
CREATE INDEX idx_workspaces_deleted_at ON workspaces(deleted_at) WHERE deleted_at IS NULL;
```

### `workspace_members`
```sql
CREATE TABLE workspace_members (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  user_id      UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role         TEXT NOT NULL CHECK (role IN ('owner','admin','member','viewer')),
  joined_at    TIMESTAMPTZ DEFAULT now(),
  created_at   TIMESTAMPTZ DEFAULT now(),
  updated_at   TIMESTAMPTZ DEFAULT now(),

  UNIQUE (workspace_id, user_id)
);

CREATE INDEX idx_wm_workspace_id ON workspace_members(workspace_id);
CREATE INDEX idx_wm_user_id ON workspace_members(user_id);
```

### `invitations`
```sql
CREATE TABLE invitations (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  email        TEXT NOT NULL,
  role         TEXT NOT NULL CHECK (role IN ('owner','admin','member','viewer')),
  token_hash   TEXT NOT NULL UNIQUE,
  invited_by   UUID NOT NULL REFERENCES users(id),
  status       TEXT NOT NULL DEFAULT 'pending'
                 CHECK (status IN ('pending','accepted','expired','revoked')),
  expires_at   TIMESTAMPTZ NOT NULL,
  created_at   TIMESTAMPTZ DEFAULT now(),

  UNIQUE (workspace_id, email, status) -- une seule invitation pending par email+workspace
);

CREATE INDEX idx_invitations_token ON invitations(token_hash);
CREATE INDEX idx_invitations_workspace ON invitations(workspace_id);
```

### `agent_manifests`
```sql
-- Catalogue global géré par les créateurs d'agents
CREATE TABLE agent_manifests (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug             TEXT NOT NULL UNIQUE,
  name             TEXT NOT NULL,
  version          TEXT NOT NULL,
  description      TEXT NOT NULL,
  long_description TEXT,
  category         TEXT NOT NULL,
  capabilities     JSONB NOT NULL DEFAULT '[]',
  pricing          JSONB NOT NULL,          -- { model, price_cents, ... }
  author_id        UUID NOT NULL REFERENCES users(id),
  icon_url         TEXT,
  tags             TEXT[] DEFAULT '{}',
  is_verified      BOOLEAN DEFAULT false,
  install_count    INTEGER DEFAULT 0,
  avg_rating       NUMERIC(3,2) DEFAULT 0,
  review_count     INTEGER DEFAULT 0,
  deleted_at       TIMESTAMPTZ,
  created_at       TIMESTAMPTZ DEFAULT now(),
  updated_at       TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_agent_category ON agent_manifests(category);
CREATE INDEX idx_agent_tags ON agent_manifests USING gin(tags);
CREATE INDEX idx_agent_search ON agent_manifests USING gin(
  to_tsvector('french', name || ' ' || description)
);
```

### `agent_installations`
```sql
-- Agent installé dans un workspace spécifique
CREATE TABLE agent_installations (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  agent_id     UUID NOT NULL REFERENCES agent_manifests(id),
  status       TEXT NOT NULL DEFAULT 'active'
                 CHECK (status IN ('active','suspended','uninstalled')),
  config       JSONB DEFAULT '{}',
  installed_at TIMESTAMPTZ DEFAULT now(),
  created_at   TIMESTAMPTZ DEFAULT now(),
  updated_at   TIMESTAMPTZ DEFAULT now(),

  UNIQUE (workspace_id, agent_id)
);

CREATE INDEX idx_ai_workspace ON agent_installations(workspace_id);
CREATE INDEX idx_ai_status ON agent_installations(workspace_id, status);
```

### `agent_reviews`
```sql
CREATE TABLE agent_reviews (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  agent_id   UUID NOT NULL REFERENCES agent_manifests(id) ON DELETE CASCADE,
  author_id  UUID NOT NULL REFERENCES users(id),
  rating     SMALLINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  body       TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),

  UNIQUE (agent_id, author_id)
);

CREATE INDEX idx_reviews_agent ON agent_reviews(agent_id);
```

### `teams`
```sql
CREATE TABLE teams (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  name         TEXT NOT NULL,
  description  TEXT,
  pipeline_id  TEXT,    -- ex. "feature", "review", "hotfix"
  is_active    BOOLEAN DEFAULT true,
  created_at   TIMESTAMPTZ DEFAULT now(),
  updated_at   TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_teams_workspace ON teams(workspace_id);
CREATE INDEX idx_teams_pipeline ON teams(workspace_id, pipeline_id);
```

### `team_members`
```sql
CREATE TABLE team_members (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  team_id               UUID NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
  agent_installation_id UUID NOT NULL REFERENCES agent_installations(id),
  role_in_team          TEXT NOT NULL
                          CHECK (role_in_team IN ('lead','contributor','reviewer','observer')),
  "order"               SMALLINT DEFAULT 0,
  created_at            TIMESTAMPTZ DEFAULT now(),

  UNIQUE (team_id, agent_installation_id)
);

CREATE INDEX idx_tm_team ON team_members(team_id);
```

### `runs`
```sql
CREATE TABLE runs (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id   UUID NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  team_id        UUID REFERENCES teams(id),
  pipeline_id    TEXT NOT NULL,
  status         TEXT NOT NULL DEFAULT 'queued'
                   CHECK (status IN ('queued','running','completed','failed','cancelled')),
  input          JSONB DEFAULT '{}',
  triggered_by   UUID NOT NULL REFERENCES users(id),
  error_message  TEXT,
  started_at     TIMESTAMPTZ,
  completed_at   TIMESTAMPTZ,
  duration_ms    INTEGER,
  created_at     TIMESTAMPTZ DEFAULT now(),
  updated_at     TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_runs_workspace ON runs(workspace_id);
CREATE INDEX idx_runs_status ON runs(workspace_id, status);
CREATE INDEX idx_runs_created ON runs(workspace_id, created_at DESC);
CREATE INDEX idx_runs_team ON runs(team_id) WHERE team_id IS NOT NULL;
```

### `run_phases`
```sql
CREATE TABLE run_phases (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  run_id       UUID NOT NULL REFERENCES runs(id) ON DELETE CASCADE,
  phase_id     TEXT NOT NULL,
  label        TEXT NOT NULL,
  agent        TEXT NOT NULL,
  status       TEXT NOT NULL DEFAULT 'pending'
                 CHECK (status IN ('pending','running','completed','failed','skipped')),
  output_key   TEXT,
  output       JSONB,
  error        TEXT,
  started_at   TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  duration_ms  INTEGER,
  created_at   TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_rp_run_id ON run_phases(run_id);
```

### `connector_catalog`
```sql
-- Catalogue global des connecteurs MCP (géré en interne par ADA)
CREATE TABLE connector_catalog (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name             TEXT NOT NULL,
  slug             TEXT NOT NULL UNIQUE,
  provider         TEXT NOT NULL,
  description      TEXT,
  auth_type        TEXT NOT NULL
                     CHECK (auth_type IN ('oauth2','api_key','basic','none')),
  required_scopes  TEXT[] DEFAULT '{}',
  icon_url         TEXT,
  is_verified      BOOLEAN DEFAULT false,
  version          TEXT DEFAULT '1.0',
  created_at       TIMESTAMPTZ DEFAULT now(),
  updated_at       TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_connector_slug ON connector_catalog(slug);
```

### `workspace_connectors`
```sql
CREATE TABLE workspace_connectors (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id      UUID NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  connector_id      UUID NOT NULL REFERENCES connector_catalog(id),
  display_name      TEXT,
  status            TEXT NOT NULL DEFAULT 'pending_auth'
                      CHECK (status IN ('active','inactive','error','pending_auth')),
  -- credentials chiffrées AES-256-GCM, jamais exposées en clair via API
  credentials_enc   BYTEA,
  scopes_granted    TEXT[] DEFAULT '{}',
  last_used_at      TIMESTAMPTZ,
  error_message     TEXT,
  created_at        TIMESTAMPTZ DEFAULT now(),
  updated_at        TIMESTAMPTZ DEFAULT now(),

  UNIQUE (workspace_id, connector_id)
);

CREATE INDEX idx_wc_workspace ON workspace_connectors(workspace_id);
CREATE INDEX idx_wc_status ON workspace_connectors(workspace_id, status);
```

### `connector_permissions`
```sql
CREATE TABLE connector_permissions (
  id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_connector_id  UUID NOT NULL REFERENCES workspace_connectors(id) ON DELETE CASCADE,
  agent_installation_id   UUID NOT NULL REFERENCES agent_installations(id) ON DELETE CASCADE,
  allowed                 BOOLEAN NOT NULL DEFAULT false,
  allowed_operations      TEXT[] DEFAULT '{}',
  created_at              TIMESTAMPTZ DEFAULT now(),
  updated_at              TIMESTAMPTZ DEFAULT now(),

  UNIQUE (workspace_connector_id, agent_installation_id)
);

CREATE INDEX idx_cp_connector ON connector_permissions(workspace_connector_id);
CREATE INDEX idx_cp_agent ON connector_permissions(agent_installation_id);
```

---

## Diagramme de relations (simplifié)

```
users ──────────────── workspace_members ──── workspaces
  │                                                │
  │                         ┌──────────────────────┤
  │                    agent_installations     teams
  │                         │                  │
  │                    connector_permissions  team_members
  │                         │
  │                    workspace_connectors ── connector_catalog
  │
  └── runs ─────────── run_phases
        │
        └── team_id → teams
```

---

## Notes importantes

1. **Soft delete** : `workspaces.deleted_at` et `agent_manifests.deleted_at` — jamais de DELETE physique.
2. **credentials_enc** : Les credentials des connecteurs sont chiffrées avec AES-256-GCM avant stockage. La clé de chiffrement est gérée via AWS KMS / Vault, jamais dans le code.
3. **JSONB** : `capabilities`, `pricing`, `config`, `input`, `output` sont en JSONB pour flexibilité — les champs clés sont indexés si filtrés fréquemment.
4. **RLS Supabase** : Chaque table métier filtre par `workspace_id` via Row Level Security pour l'isolation multi-tenant.
