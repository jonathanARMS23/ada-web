# ADA SaaS — Événements SSE des Runs

Endpoint : `GET /v1/workspaces/:workspaceId/runs/:runId/events?token=<jwt>`

Protocol : `text/event-stream` (Server-Sent Events)

Le flux est fermé automatiquement quand le run atteint `completed`, `failed` ou `cancelled`.

---

## Structure générale

Chaque événement SSE suit le format :

```
event: <event_type>
data: <JSON string>
id: <event_id>

```

---

## Événements

### `run.started`
Émis quand le run passe de `queued` à `running`.

```
event: run.started
data: {
  "run_id": "uuid",
  "pipeline_id": "feature",
  "team_id": "uuid",
  "status": "running",
  "started_at": "2026-05-12T10:00:00Z",
  "phases_total": 7
}
id: evt_001
```

### `phase.started`
Émis au démarrage de chaque phase du pipeline.

```
event: phase.started
data: {
  "run_id": "uuid",
  "phase_id": "schema",
  "label": "Schéma DB + migration",
  "agent": "db",
  "order": 0,
  "phases_total": 7,
  "started_at": "2026-05-12T10:00:01Z"
}
id: evt_002
```

### `phase.log`
Logs en temps réel d'une phase (streaming de la sortie agent).

```
event: phase.log
data: {
  "run_id": "uuid",
  "phase_id": "schema",
  "level": "info",
  "message": "Generating migration for table 'invoice_tags'...",
  "timestamp": "2026-05-12T10:00:03Z"
}
id: evt_003
```

Niveaux de log : `info | warn | error | debug`

### `phase.completed`
Émis quand une phase se termine avec succès.

```
event: phase.completed
data: {
  "run_id": "uuid",
  "phase_id": "schema",
  "label": "Schéma DB + migration",
  "status": "completed",
  "output_key": "migration_summary",
  "output": {
    "migration_summary": "CREATE TABLE invoice_tags (...); CREATE INDEX ...",
    "tables_created": ["invoice_tags"],
    "indexes_created": ["idx_invoice_tags_invoice_id"]
  },
  "duration_ms": 4320,
  "completed_at": "2026-05-12T10:00:05Z"
}
id: evt_004
```

### `phase.failed`
Émis quand une phase échoue.

```
event: phase.failed
data: {
  "run_id": "uuid",
  "phase_id": "backend",
  "label": "Implémentation backend",
  "status": "failed",
  "error": "Agent 'nestjs' a retourné une erreur : TypeScript compilation failed",
  "retry_attempt": 1,
  "max_retries": 2,
  "duration_ms": 12000,
  "failed_at": "2026-05-12T10:01:00Z"
}
id: evt_010
```

### `phase.retrying`
Émis quand une phase est relancée après échec.

```
event: phase.retrying
data: {
  "run_id": "uuid",
  "phase_id": "backend",
  "retry_attempt": 2,
  "max_retries": 2,
  "delay_ms": 2000,
  "retrying_at": "2026-05-12T10:01:02Z"
}
id: evt_011
```

### `phase.skipped`
Émis quand une phase est sautée (flag `--no-deploy`, `--api-only`, etc.).

```
event: phase.skipped
data: {
  "run_id": "uuid",
  "phase_id": "frontend",
  "label": "Implémentation frontend",
  "reason": "flag --api-only actif",
  "skipped_at": "2026-05-12T10:00:06Z"
}
id: evt_005
```

### `run.completed`
Émis quand le run se termine avec succès. Ferme le flux SSE.

```
event: run.completed
data: {
  "run_id": "uuid",
  "pipeline_id": "feature",
  "status": "completed",
  "phases_completed": 6,
  "phases_skipped": 1,
  "phases_failed": 0,
  "duration_ms": 142000,
  "summary": {
    "migration_summary": "...",
    "test_specs": "...",
    "api_endpoints": ["POST /invoices/:id/tags", "DELETE /invoices/:id/tags/:tagId"],
    "review_verdict": "approved"
  },
  "completed_at": "2026-05-12T10:02:22Z"
}
id: evt_050
```

### `run.failed`
Émis quand le run échoue sur une phase critique (`stopOnFailure: true`). Ferme le flux SSE.

```
event: run.failed
data: {
  "run_id": "uuid",
  "pipeline_id": "feature",
  "status": "failed",
  "failed_phase_id": "specs",
  "error_message": "Agent 'tester' : impossible de générer les specs — migration non appliquée",
  "phases_completed": 1,
  "rollback_triggered": false,
  "duration_ms": 35000,
  "failed_at": "2026-05-12T10:00:35Z"
}
id: evt_020
```

### `run.cancelled`
Émis quand le run est annulé via `POST /runs/:id/cancel`. Ferme le flux SSE.

```
event: run.cancelled
data: {
  "run_id": "uuid",
  "status": "cancelled",
  "cancelled_by": "user_uuid",
  "last_completed_phase": "schema",
  "cancelled_at": "2026-05-12T10:00:45Z"
}
id: evt_015
```

### `run.heartbeat`
Ping toutes les 15s pour maintenir la connexion SSE ouverte.

```
event: run.heartbeat
data: {
  "run_id": "uuid",
  "status": "running",
  "current_phase": "backend",
  "elapsed_ms": 30000,
  "timestamp": "2026-05-12T10:00:30Z"
}
id: evt_030
```

---

## Reconnexion

Le client doit stocker le dernier `id` reçu et l'envoyer via le header `Last-Event-ID`
(gestion native de l'API EventSource browser) pour reprendre le flux après déconnexion.

```javascript
const es = new EventSource(
  `https://api.ada.ai/v1/workspaces/${wsId}/runs/${runId}/events?token=${jwt}`
);

es.addEventListener('phase.completed', (e) => {
  const data = JSON.parse(e.data);
  console.log('Phase done:', data.phase_id, data.output);
});

es.addEventListener('run.completed', (e) => {
  const data = JSON.parse(e.data);
  console.log('Run done in', data.duration_ms, 'ms');
  es.close();
});

es.addEventListener('run.failed', (e) => {
  const data = JSON.parse(e.data);
  console.error('Run failed at phase:', data.failed_phase_id);
  es.close();
});
```

---

## Tableau récapitulatif des événements

| Événement | Déclenché quand | Ferme le flux |
|---|---|---|
| `run.started` | Run passe queued → running | Non |
| `phase.started` | Début d'une phase | Non |
| `phase.log` | Log streaming d'une phase | Non |
| `phase.completed` | Phase terminée avec succès | Non |
| `phase.failed` | Phase en erreur | Non |
| `phase.retrying` | Retry d'une phase | Non |
| `phase.skipped` | Phase sautée (flag) | Non |
| `run.completed` | Toutes les phases terminées | Oui |
| `run.failed` | Phase critique en erreur | Oui |
| `run.cancelled` | Annulation manuelle | Oui |
| `run.heartbeat` | Toutes les 15s | Non |

---

## ADA UI — SSE Local (ada-ui)

Endpoint : `GET /api/events` (ada-ui, port 3000 par défaut)

Différent du SSE SaaS ci-dessus — ce flux surveille les fichiers du profil actif en temps réel via chokidar.

### Structure générale

Les événements sont émis en tant que `data:` SSE standard (pas d'`event:` type custom) :

```
data: {"type":"state","profile":"claude-pro","runId":"my-run-123"}

data: {"type":"ping"}
```

### Types d'événements

| `type` | Déclenché quand | Payload supplémentaire |
|--------|----------------|------------------------|
| `state` | `state.json` ou `runs/*/state.json` modifié | `profile`, `runId` (si run spécifique) |
| `run` | Fichier dans `runs/` modifié | `profile`, `runId` |
| `agents` | Sentinel `.last-modified` modifié (hot-reload) | `profile` |
| `ping` | Toutes les 30s (keepalive) | — |

### Utilisation côté client

```javascript
const es = new EventSource('/api/events')

es.onmessage = (e) => {
  const { type, profile, runId } = JSON.parse(e.data)
  if (type === 'state') queryClient.invalidateQueries(['runs'])
  if (type === 'agents') queryClient.invalidateQueries(['agents', profile])
}
```

Le flux est maintenu ouvert. Pas de fermeture automatique (contrairement au SSE SaaS).
