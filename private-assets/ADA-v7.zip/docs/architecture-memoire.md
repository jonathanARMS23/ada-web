# Architecture de la couche mémoire (ReasoningBank — refonte P0/P1)

> Documentation technique de la chaîne mémoire d'ADA-core après la refonte
> recall-asservi-au-contenu (commits `18fcfa9`, `ea33916`, juin 2026).
> Source de vérité unique : `bank.db` (cf. `coordinator/ARCHITECTURE-knowledge.md`).
> Pour la décision et les alternatives rejetées : `docs/adr/ADR-018-memoire-recall-asservi.md`.

## Problème résolu

Avant la refonte, le recall souffrait de quatre défauts qui injectaient du bruit ou
masquaient des règles pertinentes :

1. **Fallback TF-IDF silencieux** — si Ollama était absent, le recall retombait sur
   TF-IDF sans aucun signal ; l'orchestrateur croyait obtenir de la recherche
   sémantique alors qu'il n'avait que du lexical dégradé.
2. **Acronymes perdus à l'indexation** — `TS` (longueur 2) était jeté par le filtre,
   et `ts` / `typescript`, `auth` / `authentication` n'étaient jamais unifiés. Une
   convention restait invisible selon la forme employée dans le prompt.
3. **Récence/verdict maquillaient le hors-sujet** — le score d'injection mélangeait
   pertinence-contenu et bonus de récence ; une entrée récente mais hors-sujet
   franchissait le seuil.
4. **Conventions doublonnées ou contradictoires** — deux règles quasi-identiques
   (« Jamais de `any` en TS » vs « Pas de `any` en TypeScript ») étaient stockées et
   injectées côte à côte.

## Vue d'ensemble du recall

```
query (description de tâche)
    │
    ├─ buildRecallBlockAsync()  ← voie par défaut (ada bank recall)
    │     │
    │     1. sonde Ollama (embedWithOllama, timeout 2s) → up | down
    │     2. retrieveAsync()    → candidats (sémantique si up, sinon TF-IDF)
    │     3. degraded = !ollamaUp → stderr + setMeta('lastRecallDegraded')
    │     4. _recallConventions() → TOUTES les conventions, non tronquées
    │     5. _assembleRecallBlock() → seuillage par portée + contenu
    │
    └─→ bloc [CONNAISSANCE PROJET — ReasoningBank]  (ou '' si hors-sujet)
```

L'orchestrateur injecte ce bloc EN TÊTE du prompt agent. Bloc vide → rien n'est injecté.

## P1-2 — Recall sémantique observable (fin du fallback silencieux)

`buildRecallBlockAsync(query, { limit })` sonde Ollama **avant** le retrieve pour
distinguer le régime sémantique du régime dégradé :

- **Ollama up** → `retrieveAsync` utilise les embeddings denses ; `setMeta('lastRecallSemantic')`.
- **Ollama down** → repli TF-IDF, MAIS le mode dégradé est **observable** :
  - `stderr` : `[bank] recall DÉGRADÉ (TF-IDF, Ollama indisponible) — qualité sémantique réduite`
  - `setMeta('lastRecallDegraded', <ISO ts>)` consultable via `bankHealth()`.

`bankHealth()` (`ada bank health`) expose l'état réel de la couche :

| Champ | Sens |
|-------|------|
| `ollama` | sonde réelle up/down (timeout 2s) |
| `embedModel` | modèle d'embedding configuré |
| `trajectories` | total stocké |
| `withEmbedding` | nb de trajectoires portant un embedding dense |
| `coverage` | ratio `withEmbedding / trajectories` ∈ [0,1] |
| `lastRecallDegraded` / `lastRecallSemantic` | derniers timestamps observés |

La voie synchrone `buildRecallBlock()` (TF-IDF pur) est conservée pour les appelants
sync et la rétro-compatibilité ; elle ne tente jamais Ollama.

## P1-1 — Tokenizer : acronymes + formes canoniques (à l'indexation ET en requête)

`embeddings.tokenize()` applique deux normalisations DANS le tokenizer — donc elles
valent à l'indexation comme à la requête, pas seulement à l'expansion :

- **`ACRONYMS_KEEP`** : acronymes techniques courts préservés malgré le filtre
  `length > 2` (`ts`, `db`, `ci`, `cd`, `ui`, `ux`, `js`, `go`, `qa`, `ai`, `ml`).
- **`NORMALIZE_MAP`** : table canonique appliquée à chaque token stemmé
  (`ts`→`typescript`, `auth`→`authentication`, `db`→`database`, `migra`→`migration`,
  `k8s`→`kubernetes`, …). Deux conventions exprimant la même règle sous des formes
  différentes deviennent comparables.

## P0-2 — Pertinence-contenu séparée du bruit récence/verdict

`contentRelevance(traj, queryTokens, queryEmbedding, tfidfScore)` (dans
`bank-ranking.js`) calcule la similarité **requête↔contenu UNIQUEMENT** — aucune
contribution de récence, verdict, phase ou agent :

- embedding présent → `cosineSimilarity × 6`
- sinon TF-IDF → `tfidfScore × 0.7`
- sinon overlap de tokens → `+1` par token commun.

`scoreTrajectory` stampe ce score sur la trajectoire (champ non-énumérable `_content`).
C'est **le seul signal sur lequel on seuille l'injection** dans `_assembleRecallBlock` :
le bonus de récence/verdict universel ne peut plus faire franchir le seuil à une entrée
hors-sujet.

## P0-1 — Portée des conventions : `scope:global` vs `scope:domain`

À l'écriture (`storeConvention`), chaque convention reçoit un tag de portée :

- **`scope:global`** (règle transverse au projet, ex. RLS Supabase, `uuid` PK,
  pas de `any` TS) — injectée **inconditionnellement** dès que le bloc est on-topic,
  SANS gate de contenu. Gater une règle globale sur le lexique du prompt produit une
  liste amputée → le modèle, ancré dessus, abandonne la règle (anchoring négatif
  mesuré : RLS perdu sur un prompt de schéma — bug `18fcfa9`).
- **`scope:domain`** (règle spécifique à un domaine) — gatée sur la pertinence-contenu
  réelle (`_content > 0`). Une règle de domaine hors-sujet n'est pas injectée.

L'absence de tag de portée vaut **global par défaut** (rétro-compat). La portée est
classée par `classifyConventionScope()` (heuristique lexicale déterministe sur le
TEXTE de la convention, jamais sur la requête), ou forcée via `opts.scope`.

## P0-3 — Dédup / supersession / contradiction au store

`storeConvention()` compare la nouvelle convention aux conventions **actives** (non
archivées), sur les **tokens-SUJET** (tokens P1-1 normalisés, marqueurs de polarité
retirés) :

- **Doublon exact** (texte normalisé identique) → idempotent, aucun side-effect
  (re-seeder les mêmes conventions est un no-op).
- **Quasi-doublon** (Jaccard-sujet ≥ `DEDUP_TAU = 0.5`, polarités compatibles) →
  règle reformulée : **last-write-wins**. On stocke la nouvelle PUIS on marque
  l'ancienne `archived = true` (jamais de fenêtre sans règle active ; l'archivée
  reste en base pour l'audit/la réversibilité).
- **Contradiction** (overlap-sujet ≥ `CONTRA_OVL_TAU = 0.5` + polarités OPPOSÉES,
  ex. « jamais any » vs « utilise any si le build bloque ») → **WARNING** (stderr +
  champ `warnings` retourné). On **n'archive pas et on ne bloque pas** : arbitrage
  humain requis (risque d'écraser une règle valide sur une saisie mal polarisée).

Deux mesures complémentaires sur les tokens-SUJET :
`Jaccard = |A∩B|/|A∪B|` (dédup, pénalise les écarts de longueur) et
`overlap = |A∩B|/min(|A|,|B|)` (contradiction, robuste à la longueur).

Le champ **`archived`** est respecté à tous les points de sortie du recall :
`_recallConventions`, `_assembleRecallBlock` (garde-fou défensif) et le retrieve
général filtrent `!t.archived` — une convention superseédée n'est jamais injectée.

## Règle d'injection (assemblage final)

`_assembleRecallBlock(results, query)` :

1. **Garde-fou hors-sujet** : si AUCUN résultat ne partage de vocabulaire avec la
   tâche → bloc vide (pas de bruit).
2. **On-topic** (≥1 match lexical) → conventions globales injectées en bloc,
   conventions domaine gatées sur le contenu.
3. **Leçons** (non-conventions) : seuillées STRICTEMENT sur le contenu (`_content > 0`),
   triées par contenu décroissant, cappées par `LESSON_LIMIT = 4`. Ce cap est SÉPARÉ
   des conventions : une convention n'est jamais évincée par le volume de leçons.

## Réserve honnête — deux proxies lexicaux assumés

`storeConvention` est **synchrone** (appelé au seed/promote, fire-and-forget) :
appeler Ollama y serait bloquant. Deux décisions y reposent donc sur des heuristiques
lexicales déterministes, et non sur la sémantique dense :

1. **Classification de portée** (`classifyConventionScope`) — regex de marqueurs
   globaux (`rls`, `supabase`, `uuid`, `typescript`, `jamais`, `toujours`, …).
2. **Détection de polarité** (`_polarity`) — regex NEG/POS (FR + EN) pour décider
   doublon vs contradiction.

Ces proxies sont assumés : ils sont déterministes, sans dépendance, et stables sur de
courtes phrases-règles (le TF-IDF cosine a un IDF instable sur un corpus de quelques
conventions). L'override explicite `opts.scope` permet de corriger une classification
au seed. Les voies de **recall** (lecture), elles, utilisent bien la sémantique dense
quand Ollama est disponible.

## Fichiers concernés

| Fichier | Rôle |
|---------|------|
| `coordinator/bank.js` | `storeConvention` (P0-1/P0-3), `buildRecallBlockAsync` (P1-2), `bankHealth`, `_assembleRecallBlock` |
| `coordinator/bank-ranking.js` | `contentRelevance` (P0-2), `scoreTrajectory` |
| `coordinator/embeddings.js` | `tokenize` + `NORMALIZE_MAP` / `ACRONYMS_KEEP` (P1-1) |
| `coordinator/bank-hnsw.js` | index ANN extrait du god-object (axe C3) |

## CLI

```bash
ada bank recall "<tâche>"      # bloc injectable (voie async, signale le mode dégradé)
ada bank health                # JSON santé : ollama, coverage, lastRecall*
ada bank seed-conventions      # peuple le bank depuis CLAUDE.md (Règles stack)
```
