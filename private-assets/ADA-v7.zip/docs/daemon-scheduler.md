# Daemon Worker Scheduler

> Documentation du scheduler background ADA — `workers/daemon.js`

## Vue d'ensemble

Le daemon est un scheduler Node.js léger qui exécute les workers de maintenance automatiquement en arrière-plan selon des intervalles configurables.

```
ada daemon start
    │
    └── spawn detached (workers/daemon.js --daemon-worker)
              │
              ├── PID file → logs/daemon.pid
              ├── Log file → logs/daemon.log (rotation quotidienne)
              └── Timers via setTimeout + setInterval
                        │
                        ├── ultralearn  → toutes les 6h
                        ├── consolidate → toutes les 2h
                        ├── audit       → aligné minuit
                        └── cve-scan    → toutes les 72h
```

## Commandes

```bash
ada daemon start              # démarre le scheduler en arrière-plan
ada daemon stop               # arrête le daemon (SIGTERM + drain)
ada daemon status             # état, PID, prochains runs
ada daemon run <worker>       # exécuter un worker immédiatement
```

Ou via node directement :
```bash
node .claude/workers/daemon.js start
node .claude/workers/daemon.js stop
node .claude/workers/daemon.js status
node .claude/workers/daemon.js run ultralearn
```

## Workers disponibles

| Worker | Fréquence | Description |
|--------|-----------|-------------|
| `ultralearn` | 6h | Apprentissage profond — distille les trajectoires en patterns |
| `consolidate` | 2h | Consolidation bank — merge insights + archive vieux |
| `audit` | 24h (minuit) | Audit sécurité OWASP des fichiers modifiés |
| `cve-scan` | 72h | Scan CVE npm/pip — alerte sur vulnérabilités |
| `dashboard` | manuel | Génère le dashboard SVG |
| `metrics` | manuel | Exporte les métriques |
| `cost-report` | manuel | Rapport de coût détaillé |
| `pr-create` | manuel | Création PR automatique |
| `team-sync-push` | auto (≥5 réponses) | Sync priors Thompson vers remote |
| `federation-sync` | manuel | Sync trajectoires fédération |
| `testgaps` | manuel | Détecte les gaps de tests |
| `topic-wiki` | manuel | Génère wiki depuis les trajectoires |

## Configuration

Dans `~/.ada.json` :

```json
{
  "daemon": {
    "schedule": {
      "ultralearn": "4h",
      "consolidate": "1h",
      "audit": "24h",
      "cve-scan": "3d"
    }
  }
}
```

Formats d'intervalle acceptés :
- Chaîne : `"6h"`, `"30m"`, `"90s"`, `"2d"`
- Nombre : millisecondes (ex: `3600000`)

Contraintes :
- Minimum : 1 minute (`60000ms`)
- Maximum : 7 jours (`604800000ms`)
- Worker inconnu : ignoré avec warning dans `daemon.log`

## Fichiers

| Fichier | Description |
|---------|-------------|
| `logs/daemon.pid` | PID du process daemon |
| `logs/daemon.log` | Journal avec rotation quotidienne |
| `logs/daemon-state.json` | lastRun + nextRun par worker |
| `logs/daemon.YYYY-MM-DD.log` | Archives (7 jours max) |

## Arrêt gracieux

Le daemon implémente un shutdown en 3 étapes :
1. Reçoit SIGTERM ou SIGINT
2. `_gracefulShutdown()` : clear tous les timers (`clearTimeout` + `clearInterval`)
3. Unlink `daemon.pid`
4. `setTimeout(process.exit, 2000)` : 2 secondes de grâce pour les I/O en cours

## Reprise après redémarrage

`delayUntilNext(worker, intervalMs)` lit `daemon-state.json` pour calculer le temps déjà écoulé depuis le dernier run. Si le daemon redémarre 1h après un run ultralearn (interval 6h), il attendra encore 5h avant le prochain run.

## Variables d'environnement

| Variable | Valeur | Description |
|----------|--------|-------------|
| `ADA_DAEMON_AUTO` | `"1"` | Active le démarrage auto du daemon si absent |
| `CLAUDE_CONFIG_DIR` | `~/.claude` | Répertoire config (transmis aux workers) |
