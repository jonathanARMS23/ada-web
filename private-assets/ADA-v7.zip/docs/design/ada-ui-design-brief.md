# ADA — Brief de design `ada-ui`

> Destinataire : **Claude Design**. Objectif : générer le design complet de l'interface `ada-ui`.
> Stack cible : **Next.js (App Router) + Tailwind + shadcn/ui**. Dark mode par défaut. Outil « mission control » développeur, dense et temps réel.
> Convention de statut dans ce doc : **[LIVE]** = donnée déjà disponible via l'API ; **[PLANIFIÉ]** = gap à concevoir mais pas encore alimentable.

---

## 1. Résumé produit, principes de design, persona

### 1.1 Ce qu'est ADA
ADA (AI Dev Assistant) est un **orchestrateur d'agents IA pour le développement logiciel**. L'utilisateur envoie une **instruction** ; ADA la route vers un **pipeline** (DAG de phases) ou une **session interactive**, délègue à des **agents** spécialisés (chacun lié à un tier de modèle : haiku / sonnet / opus), exécute via Claude Code en headless, et **trace tout** : tokens, coûts, mémoire, événements temps réel.

Backend : API **NestJS** (`ada-api-nest`) + un **control-server** (daemon JSON-RPC) qui pilote le moteur `ada-core`. Temps réel via WebSocket (rooms par workspace).

Métaphore directrice : **mission control / cockpit**. Dense en information, technique, temps réel, orienté observabilité et contrôle.

### 1.2 Principes de design
1. **Densité maîtrisée** — afficher beaucoup sans saturer : hiérarchie par taille/espacement/contraste, pas par couleur seule. Tables compactes, KPIs scannables, zones repliables.
2. **Temps réel lisible** — le streaming (tokens, phases, coûts) doit être perçu instantanément sans faire « sauter » la mise en page (réserver l'espace, `tabular-nums`, pas de CLS).
3. **Statut toujours visible** — un système d'états sémantiques cohérent (idle / running / success / failed / paused) réutilisé partout (badges, points, barres, bordures).
4. **Le terminal est un citoyen de première classe** — streaming type xterm, monospace, copiable, pausable.
5. **Profil = contexte global** — tout ce qui est affiché dépend du profil actif (`~/.claude-<nom>`). Le sélecteur de profil est omniprésent et le changement recharge le contexte.
6. **Progressive disclosure** — vue d'ensemble → détail → trace brute. L'utilisateur plonge à la demande.
7. **Clavier-first** — palette de commandes (⌘K), navigation au clavier, raccourcis sur les actions fréquentes.
8. **Accessibilité même en dark dense** — contraste AA minimum sur texte, jamais d'info par couleur seule (icône + texte), focus visible, `prefers-reduced-motion` respecté (data lisible immédiatement, animations gelables).

### 1.3 Persona
- **Dev / lead technique « power user »** qui orchestre des agents IA toute la journée. Confortable avec terminal, DAG, JSON, métriques.
- **Attentes** : tout voir d'un coup d'œil (santé, runs, coûts), plonger dans la trace d'un run en cours, comprendre quel agent/modèle a coûté quoi, naviguer la mémoire, configurer providers/budget sans toucher au shell.
- **Contexte d'usage** : desktop large (≥1440px) en usage principal, dark room / OLED, souvent plusieurs heures, multi-écran. Le responsive < 1024px est une commodité (consultation), pas le cas nominal.

---

## 2. Architecture de l'information & navigation globale

### 2.1 Carte du produit (9 features)
```
ADA
├── Dashboard            (overview système, santé, runs, coûts, Thompson, heatmap)
├── Workspaces           (projets → conversations → tâches temps réel)
├── Agents / Profiles / Teams
│   ├── Agents (liste + détail)
│   ├── Profiles (liste)
│   └── Teams (liste + détail)
├── Pipelines            (liste + détail DAG)
├── Memory               (graphe 3D navigable + wiki Obsidian)
├── MCP                  (gestion serveurs + catalogue, CRUD)
├── Logs                 (consultation, filtres, recherche, rétention)
└── Settings             (providers, budget, obsidian, webhook)
+ Gestion des profils    (lister / créer / basculer — accessible depuis le sélecteur global)
```

### 2.2 Layout global (desktop ≥1024px)
- **Sidebar gauche fixe** (collapsible, ~240px → 64px en mode icônes) : logo ADA + navigation primaire. Item actif surligné (barre d'accent gauche + fond muted + poids fort). Icônes Lucide, label texte (jamais icône seule).
- **Top bar** (~52px) : breadcrumb contextuel à gauche · **sélecteur de profil** + **bouton ⌘K (command palette)** + **indicateur santé daemon** (pastille) + **toggle thème** à droite.
- **Zone de contenu** : max-width fluide (pas de container étroit — c'est un outil dense, on exploite la largeur), padding 24px, grilles bento pour le dashboard.
- **Drawer / panneau de détail droit** (slide-in, 40–50% largeur) : pour les détails contextuels (détail run, détail agent) sans quitter la liste. Fermeture Esc + clic scrim.

Ordre sidebar (par fréquence d'usage) :
`Dashboard · Workspaces · Pipelines · Agents · Memory · MCP · Logs · Settings`
Pied de sidebar : **carte profil actif** (nom + tier + santé) cliquable → ouvre le sélecteur/gestion profils.

```
┌──────────┬───────────────────────────────────────────────────────────┐
│  ADA ▮   │  Workspaces › dune-dental › #refacto-auth      [⌘K] (●) ☾  │  ← top bar
│          ├───────────────────────────────────────────────────────────┤
│ ◧ Dash   │                                                           │
│ ▸ Works  │                                                           │
│ ◫ Pipes  │                ZONE DE CONTENU (dense, bento)             │
│ ✦ Agents │                                                           │
│ ⬡ Memory │                                                           │
│ ⟐ MCP    │                                                           │
│ ≡ Logs   │                                                           │
│ ⚙ Set    │                                                           │
│──────────│                                                           │
│ ◐ pro    │                                                           │  ← carte profil
│  opus ●  │                                                           │
└──────────┴───────────────────────────────────────────────────────────┘
```

### 2.3 Navigation transverse
- **⌘K Command Palette** : aller à n'importe quelle page, lancer une instruction, basculer de profil, ouvrir un run récent, rechercher un agent. Pattern central pour le power user.
- **Breadcrumb** : pour toute hiérarchie ≥ 3 niveaux (Workspaces › projet › conversation).
- **État préservé** au retour arrière (scroll, filtres, onglet actif).
- **Deep-linking** : chaque run, agent, conversation, nœud mémoire a une URL partageable.

### 2.4 Responsive
- **≥1024px** : sidebar + détail en drawer/split. Cas nominal.
- **768–1024px** : sidebar collapse en rail d'icônes ; drawer plein écran.
- **<768px** : sidebar → bottom-sheet de navigation (≤ items principaux) ; tables → cartes empilées ou scroll horizontal `overflow-x-auto` ; graphe 3D → fallback liste/2D + message « mieux sur grand écran ».

---

## 3. Design system (via ui-ux-pro-max)

### 3.1 Style
**Dark Mode (OLED)** — thème sombre, deep black/midnight, haut contraste, faible émission lumineuse, lisibilité maximale. Pattern de page : **Real-Time / Operations** (densité scannable, status colors green/amber/red, KPIs après le hero d'état). Light mode fourni en option mais le dark est le défaut et le mode de référence pour le contraste.

Effets : minimal glow sur éléments « live » (text-shadow doux ~`0 0 10px` sur la valeur courante d'un stream / pulse), transitions 150–300ms, focus toujours visible. **Pas** d'ombres lourdes ni de gradients décoratifs qui masquent la donnée. Élévation discrète et cohérente (échelle de surfaces, pas d'ombres aléatoires).

### 3.2 Palette (tokens sémantiques)
Base recommandée par ui-ux-pro-max, affinée pour un cockpit (slate + accent vert « run »). Définir en variables CSS / tokens shadcn, **jamais de hex en dur dans les composants**.

| Rôle | Hex (dark) | Token | Usage |
|------|-----------|-------|-------|
| Background | `#0B1120` | `--background` | fond app (un cran plus noir que slate-900 pour OLED) |
| Surface 1 | `#0F172A` | `--card` | cartes, panneaux |
| Surface 2 | `#161E2E` | `--popover` / `--muted` | tables zébrées, headers de section |
| Surface 3 | `#1E293B` | `--secondary` | hover de ligne, chips |
| Border | `#283449` | `--border` | séparateurs, contours (visible en dark) |
| Foreground | `#F8FAFC` | `--foreground` | texte principal (≥ 4.5:1) |
| Muted fg | `#94A3B8` | `--muted-foreground` | labels secondaires (≥ 3:1) |
| Primary | `#3B82F6` | `--primary` | actions principales, liens, sélection |
| Accent / Run | `#22C55E` | `--accent` | état running / live / succès « actif » |
| Ring (focus) | `#3B82F6` | `--ring` | anneau de focus 2px |

**États sémantiques** (réutilisés partout — badge, point, barre, bordure) :
| État | Couleur | Token | Forme/icône associée (jamais couleur seule) |
|------|---------|-------|----------------------------------------------|
| idle / queued | `#64748B` slate | `--status-idle` | ○ cercle vide |
| running / live | `#22C55E` green (+ pulse) | `--status-running` | ◉ point animé |
| success | `#10B981` emerald | `--status-success` | ✓ check |
| warning / budget | `#F59E0B` amber | `--status-warning` | △ triangle |
| failed / error | `#EF4444` red | `--status-error` | ✕ croix |
| paused | `#A855F7` violet | `--status-paused` | ‖ pause |

**Tiers de modèle** (code couleur dédié, cohérent dans tout le produit) :
| Tier | Couleur | Sémantique |
|------|---------|-----------|
| haiku (T1) | `#38BDF8` sky | rapide / léger |
| sonnet (T2) | `#A78BFA` violet | standard |
| opus (T3) | `#FB923C` orange | raisonnement lourd / coûteux |

Heatmap d'activité : gradient froid→chaud `#1E293B → #155E75 → #0E7490 → #F59E0B → #EF4444`, **avec légende numérique** + valeur au survol (pas de couleur seule).

### 3.3 Typographie
- **Headings / UI structurelle** : `Fira Code` (ou `Geist Mono`) — caractère technique, mono pour titres de section courts et chiffres.
- **Body / labels** : `Fira Sans` (ou `Inter` / `Geist Sans`) — lisible, neutre.
- **Données / terminal / IDs / coûts** : **monospace tabulaire** obligatoire (`tabular-nums`) — empêche le saut de layout sur valeurs streamées.
- Échelle : `12 · 13 · 14 · 16 · 20 · 24 · 32`. Body 14px (UI dense desktop) / 16px mobile. Line-height 1.5 corps, 1.2 titres. Poids : 600–700 titres, 500 labels, 400 corps.

### 3.4 Système de composants (shadcn/ui + extensions ADA)
Briques shadcn : `Button`, `Badge`, `Card`, `Tabs`, `Table` (DataTable triable/filtrable), `Dialog`, `Sheet` (drawer détail), `Command` (⌘K), `Tooltip`, `Popover`, `Select`, `Switch`, `Skeleton`, `Toast` (Sonner), `Resizable` (split panes), `ScrollArea`, `Separator`, `Progress`, `HoverCard`.

Composants ADA spécifiques à concevoir :
- **`StatusBadge`** — pastille + icône + label, mappée sur les états sémantiques.
- **`TierChip`** — chip coloré haiku/sonnet/opus.
- **`CostMeter`** — montant `tabular-nums` + barre de budget + delta animé (vert/rouge).
- **`AgentAvatar`** — initiale/glyph monogramme + couleur de tier, taille token (sm/md/lg).
- **`StreamConsole`** — terminal xterm : monospace, auto-scroll (avec « stick to bottom » + bouton « reprendre le défilement »), pause/resume, copier, recherche, indicateur de tokens live.
- **`PhaseNode` / `DagCanvas`** — nœud de phase (nom, agent, tier, statut, durée, tokens) + graphe DAG (dépendances, surbrillance du chemin actif).
- **`Timeline`** — runs/phases sur axe temps (barres horizontales type gantt, couleur = statut).
- **`Heatmap`** — grille jour × heure d'activité.
- **`MetricStat`** — KPI card (label, valeur, delta, sparkline).
- **`MemoryGraph3D`** — canvas force-graph 3D (WebGL).
- **`EmptyState`** / **`ErrorState`** / **`LoadingSkeleton`** — patterns transverses (§5).

Densité : variante « compact » (lignes 32–36px) pour les tables ; spacing 4/8px ; icônes 16px en table, 20px en nav. Une seule famille d'icônes (Lucide), stroke 1.5–2px constant.

---

## 4. Spécification par feature

> Chaque feature : objectif · écrans · wireframe ASCII · composants · données · états · temps réel · interactions · micro-copy.

---

### Feature 1 — Dashboard `[overview agrégé : PLANIFIÉ ; briques sous-jacentes : LIVE]`

**Objectif utilisateur** : voir d'un coup d'œil la santé du système, ce qui tourne, ce que ça coûte, et où va l'activité — puis plonger.

**Écrans** : une page unique en grille bento, sections repliables.

**Wireframe**
```
┌───────────────────────────────────────────────────────────────────────────┐
│ Dashboard — profil: pro                                   période: [7j ▾]   │
├───────────────┬───────────────┬───────────────┬───────────────────────────┤
│ DAEMON  ● up  │ RUNS 24h      │ COÛT 24h      │ BUDGET MENSUEL            │  ← MetricStat ×4
│ 4 agents act. │ 18 ✓ · 2 ✕    │ $3.42 ▲12%    │ ▓▓▓▓▓▓░░░ 62% $124/$200   │
├───────────────┴───────────────┴───────────────┴───────────────────────────┤
│ TIMELINE DES RUNS (live)                                  [⟳ auto] [filtre] │
│  ──■■■■──────■■──────────◉◉◉◉ (running)──────────────────────  axe temps →  │  ← Timeline/Gantt
├───────────────────────────────────┬───────────────────────────────────────┤
│ ROUTER — Thompson priors          │ HEATMAP ACTIVITÉ (jour × heure)         │
│ agent      α/β   p(win)  runs     │      0 4 8 12 16 20                      │
│ nestjs    34/4   0.89 ▓▓▓▓▓ 38    │ Lun  ░░▒▓██▓▒░                           │  ← Heatmap
│ nextjs    21/6   0.78 ▓▓▓▓  29    │ Mar  ░▒▓███▓▒░  légende: ▢▢▢ → ███      │
│ reviewer  12/9   0.57 ▓▓    14    │ ...                                     │
├───────────────────────────────────┴───────────────────────────────────────┤
│ MÉTRIQUES AGENTS (table triable)        │ RUNS RÉCENTS                       │
│ agent   runs  succ%  tokens  $  p50    │ #a91 ✓ refacto-auth   nextjs  $0.21│
│ ...                                     │ #a90 ◉ build-api      nestjs ...   │
└─────────────────────────────────────────┴────────────────────────────────────┘
```

**Composants** : `MetricStat` ×4 (sparkline), `Timeline`, table Router (Thompson α/β + p(win) + barre), `Heatmap`, `DataTable` métriques agents, liste runs récents (lien → détail run en drawer).

**Données** : `health` `[LIVE]`, `runs` liste/détail `[LIVE]`, `router.stats` priors Thompson `[LIVE]`, `cost-report` `[LIVE]`, `metrics` `[LIVE]`, budget `[LIVE via cost-report]`. Agrégat « overview/activity/budget » consolidé `[PLANIFIÉ]`.

**États** :
- Vide (nouveau profil, aucun run) : hero « Aucun run pour l'instant » + CTA « Lancer une instruction » → Workspaces.
- Chargement : skeleton par carte (pas d'axe vide pour les charts, shimmer).
- Erreur daemon down : bandeau rouge persistant en haut « Daemon ADA injoignable — [Relancer] » + KPIs en état stale grisé.
- Temps réel : timeline et runs récents se mettent à jour live (WS) ; toggle « auto-refresh » ; nouveaux runs apparaissent en stagger (30–50ms), valeur de coût avec delta animé.

**Interactions** : sélecteur de période (24h/7j/30j) ; clic run → drawer détail ; clic agent dans Router/métriques → page agent ; tri colonnes ; hover heatmap = valeur exacte ; pause de l'auto-refresh.

**Micro-copy** :
- Vide : « Aucun run sur cette période. Lancez votre première instruction depuis un workspace. »
- Budget proche : « 62 % du budget mensuel consommé. » / alerte amber à 80 % « Attention : 80 % du budget atteint. » / rouge 100 % « Budget mensuel dépassé — les runs peuvent être bloqués. »
- Daemon down : « Daemon ADA injoignable. Vérifiez qu'il tourne. [Relancer] »

---

### Feature 2 — Workspaces `[PLANIFIÉ — WS events LIVE]`

**Objectif** : organiser le travail par **projet**, y tenir des **conversations**, y lancer des **instructions** et suivre l'exécution **en temps réel** (agents sollicités + coûts live).

**Écrans** : (a) Liste des workspaces · (b) Workspace = liste des conversations · (c) Conversation = vue temps réel (le cœur de l'app).

**Wireframe (c) — Conversation (vue maîtresse)**
```
┌─────────────┬──────────────────────────────────────────┬────────────────────┐
│ CONVERSATIONS│  #refacto-auth                  ◉ running │ AGENTS SOLLICITÉS  │
│ ● #refacto.. │  ──────────────────────────────────────  │ ✦ nestjs  T3 ◉ live│
│   #build-api │  ▸ vous: « refacto le module auth en ... »│   $0.18 · 12.4k tok│
│   #fix-tests │                                            │ ✦ reviewer T2 ⏸    │
│ + nouvelle   │  ┌─ run #a91 ─ pipeline: backend-feature ─┐│   $0.04 · 3.1k tok │
│              │  │ phase 1 spec      ✓ 4s   tester  T1    ││                    │
│ [+ instruction]│ │ phase 2 implement ◉ ... nestjs   T3    ││ COÛT CONVERSATION  │
│              │  │ phase 3 review    ○ pend reviewer T2   ││ $0.22  ▲ live      │
│              │  └────────────────────────────────────────┘│ budget run: 38%    │
│              │  ╭ STREAM (xterm) ─────────── [⏸][⧉][🔍]──╮│                    │
│              │  │ > applying changes to auth.service.ts  ││ TÉLÉMÉTRIE         │
│              │  │ > running tests... ▮                    ││ tokens/s: 142      │
│              │  ╰────────────────────────────────────────╯│ phase: 2/3         │
└─────────────┴──────────────────────────────────────────┴────────────────────┘
```

**Composants** : liste conversations (rail), header conversation (`StatusBadge`), composer d'instruction (textarea + bouton lancer + sélecteur pipeline/mode optionnel), carte run avec **phases** (`PhaseNode` empilés ou mini-DAG), `StreamConsole`, panneau droit agents sollicités (`AgentAvatar` + `TierChip` + `CostMeter` par agent), `CostMeter` conversation, télémétrie live.

**Données** : workspaces/conversations CRUD `[PLANIFIÉ]` ; events run `run.started/phase.started/phase.completed/phase.failed/completed` par room workspace `[LIVE]` ; `logs.tail` pour le stream `[LIVE]` ; coût live event `cost.delta` `[PLANIFIÉ]` (fallback : recalcul via cost-report au polling).

**États** :
- Vide (aucun workspace) : EmptyState « Créez votre premier workspace » + CTA.
- Vide (workspace sans conversation) : « Aucune conversation. Lancez une instruction pour démarrer. »
- Chargement : skeleton liste + composer désactivé tant que daemon non prêt.
- Erreur lancement : toast rouge « Échec du lancement : <raison> [Réessayer] », instruction conservée dans le composer.
- Temps réel : phases changent de statut live (○→◉→✓/✕), stream auto-scroll, coûts incrémentés avec delta animé, badge agent passe en `live` (pulse) puis `idle`.

**Interactions** : envoyer instruction (⌘↵), choisir pipeline ou mode interactif, pause/stop du run, pause du stream, copier le stream, clic phase → détail phase (drawer : prompt, tokens, modèle, durée, sortie), clic agent → page agent.

**Micro-copy** :
- Composer placeholder : « Décrivez la tâche à orchestrer… (⌘↵ pour lancer) »
- Lancement : « Instruction envoyée — routage en cours… »
- Succès : « Run #a91 terminé · 3 phases · $0.22 · 1m12s »
- Échec phase : « Phase “review” échouée. [Voir la trace] [Relancer la phase] »
- Stop : « Run interrompu par l'utilisateur. »

---

### Feature 3 — Agents / Profiles / Teams `[Agents & Profiles : LIVE · Teams : PLANIFIÉ]`

**Objectif** : explorer les agents (specs, tier, perf), les profils, et composer/inspecter des teams.

#### 3a. Agents — liste + détail
**Wireframe liste**
```
┌───────────────────────────────────────────────────────────────────────┐
│ Agents (32)         [🔍 rechercher]   tier:[tous▾] profil:[pro▾]  ▦ ▤   │
├──────────────┬──────┬────────┬────────┬──────────┬──────────┬──────────┤
│ agent        │ tier │ runs   │ succ%  │ tokens   │ coût      │ p(win)  │
│ ✦ nestjs     │ T3 ● │ 38     │ 89%    │ 1.2M     │ $4.10     │ 0.89 ▓▓▓│
│ ✦ nextjs     │ T2 ● │ 29     │ 78%    │ 880k     │ $2.30     │ 0.78 ▓▓ │
│ ✦ reviewer   │ T2 ● │ 14     │ 57%    │ 410k     │ $1.05     │ 0.57 ▓  │
└──────────────┴──────┴────────┴────────┴──────────┴──────────┴──────────┘
```
**Détail agent (drawer ou page)**
```
┌ ✦ nestjs  ─ T3 opus ─────────────────────────────────── [éditer] [×] ┐
│ Rôle : Backend NestJS — API, modules, DTO, tests                       │
│ Spécifications / system prompt  ▸ (repliable, monospace)               │
│ ┌ STATS ──────────────┐ ┌ THOMPSON ─────────┐ ┌ COÛT ───────────────┐ │
│ │ runs 38 · succ 89%  │ │ α 34 / β 4        │ │ $4.10 · 1.2M tokens │ │
│ │ p50 8s · p95 41s    │ │ p(win) 0.89       │ │ moy $0.11/run       │ │
│ └─────────────────────┘ └───────────────────┘ └─────────────────────┘ │
│ SKILLS associées : feature · db-migrate · test                         │
│ RUNS RÉCENTS de cet agent (table → lien run)                           │
└────────────────────────────────────────────────────────────────────────┘
```
**Composants** : `DataTable` (tri/filtre/recherche), `TierChip`, `StatusBadge`, vue grille/table toggle, drawer détail, `MetricStat`, bloc system-prompt repliable (`ScrollArea` + copier).
**Données** : `agents` liste+search `[LIVE]`, `router.stats` `[LIVE]`, `skills` `[LIVE]`, métriques par agent `[LIVE]`.
**États** : recherche sans résultat « Aucun agent ne correspond à “…”. » ; skeleton table ; agent jamais exécuté → stats « — / pas encore de données ».
**Interactions** : recherche fuzzy, filtre tier/profil, tri colonnes, clic ligne → détail, lien skills → page skill.

#### 3b. Profiles — liste
Table : nom · chemin (`~/.claude-<nom>`) · actif ? · #agents · #runs · coût total · santé. Action « Activer » (voir Feature 9). `[LIVE : liste + actif]`

#### 3c. Teams — liste + détail `[PLANIFIÉ]`
**Détail team**
```
┌ Team: fullstack ──────────────────────────────────────────────────┐
│ Description : NestJS + Next.js + DB                                 │
│ Membres :  ✦ nestjs T3   ✦ nextjs T2   ✦ db T2                      │
│ Pipeline par défaut : backend-feature → frontend → migration        │
│ Stats agrégées : runs 52 · succ 84% · coût $9.10                    │
└─────────────────────────────────────────────────────────────────────┘
```
EmptyState « Aucune team. Composez-en une à partir de vos agents. » + CTA.

---

### Feature 4 — Mémoire (Graph 3D + Wiki) `[PLANIFIÉ — obsidian.status LIVE]`

**Objectif** : explorer la mémoire d'ADA visuellement (graphe 3D navigable) et lire/éditer les notes (wiki Obsidian).

**Écrans** : split view — graphe 3D (gauche, dominant) + panneau wiki/note (droite). Toggle plein-écran graphe.

**Wireframe**
```
┌──────────────────────────────────────────────────┬─────────────────────────┐
│ MÉMOIRE — graphe 3D            [graph|wiki] [⤢]   │ NOTE                     │
│                                                    │ # project_ada_interface  │
│            ●───────●                               │ Stack UI retenue...      │
│           /│\     /                                │ - Next.js 15            │
│      ●───● │ ●───●     ◉ (nœud sélectionné)        │ - TanStack Query v5     │
│       \  \│/ /        type: decision               │ ...                     │
│        ●──●──●        liens: 4                      │ [éditer dans Obsidian↗] │
│                                                    │                         │
│ filtres: type[tous▾] profil[pro] [🔍 noeud]        │ rétroliens (3)          │
│ rendu: force ◉ · labels ☑ · profondeur [2▾]        │ ◦ ada_saas_vision       │
└──────────────────────────────────────────────────┴─────────────────────────┘
```

**Composants** : `MemoryGraph3D` (force-graph WebGL : nœuds typés, arêtes, zoom/pan/rotate, clic = sélection + recentrage), panneau note (markdown rendu + rétroliens), barre de contrôle (filtres type, recherche nœud, profondeur d'exploration, toggle labels), toggle graph/wiki.

**Données** : memory graph nœuds/arêtes `[PLANIFIÉ]`, wiki notes Obsidian `[PLANIFIÉ]`, `obsidian.status` (vault connecté, chemin, nb notes) `[LIVE]`.

**États** :
- Obsidian non configuré : EmptyState « Aucun vault Obsidian connecté. [Configurer dans Settings] ».
- Vide (vault sans note) : « Mémoire vide — les notes apparaîtront ici au fil des sessions. »
- Chargement graphe : skeleton + spinner centré « Construction du graphe… ».
- Erreur WebGL/petit écran : fallback liste 2D des nœuds + « Le graphe 3D nécessite un écran plus large / WebGL. »
- `prefers-reduced-motion` : graphe statique (pas de simulation animée), layout figé.

**Interactions** : rotation/zoom/pan, clic nœud → focus + ouvre la note, double-clic → expand voisins, recherche nœud → highlight + recentrage, filtre par type de nœud, slider profondeur, lien « éditer dans Obsidian ».

**Micro-copy** : nœud survol = tooltip « <titre> · <type> · <N liens> » ; « Cliquez un nœud pour ouvrir sa note. »

---

### Feature 5 — Pipelines `[PLANIFIÉ]`

**Objectif** : comprendre les pipelines disponibles (DAG de phases, agents/tiers par phase, dépendances) et inspecter une exécution.

**Écrans** : liste + détail DAG.

**Wireframe détail**
```
┌ Pipeline: backend-feature ──────────────────────────── [lancer] [×] ┐
│ Description : feature backend complète (TDD)                          │
│ ┌────────────── DAG ──────────────────────────────────────────────┐  │
│ │  [spec]──────▶[implement]──────▶[review]──────▶[migration]       │  │
│ │  tester T1     nestjs T3         reviewer T2     db T2            │  │
│ │     ✓             ◉ running         ○ pending       ○ pending     │  │
│ │                      └──parallel──▶[tests] tester T1  ○          │  │
│ └──────────────────────────────────────────────────────────────────┘  │
│ Phases (table) : nom · agent · tier · dépend de · durée moy · coût moy │
└────────────────────────────────────────────────────────────────────────┘
```

**Composants** : `DagCanvas` + `PhaseNode` (statut, agent, tier, durée, dépendances ; surbrillance du chemin actif et des phases parallèles), table des phases, bouton lancer (→ ouvre composer Workspace pré-rempli).

**Données** : pipelines list/detail `[PLANIFIÉ]`. Statut d'exécution live réutilise les WS events `[LIVE]`.

**États** : vide « Aucun pipeline défini. » ; topology `parallel_mesh` → phases parallèles dessinées côte à côte ; phase failed → nœud rouge + chemin aval en `blocked` grisé.

**Interactions** : zoom/pan DAG, clic phase → détail (prompt, agent, modèle, tier), lancer pipeline, voir exécutions passées.

**Micro-copy** : nœud « ◉ en cours · 12s » / « ✕ échec — bloque 2 phases en aval ».

---

### Feature 6 — MCP `[PLANIFIÉ]`

**Objectif** : gérer les serveurs MCP du profil (CRUD) et en ajouter depuis un **catalogue/registry**, sans toucher au JSON manuellement.

**Écrans** : liste serveurs connectés + onglet catalogue + modal d'ajout/édition.

**Wireframe**
```
┌ MCP Servers                         [serveurs connectés | catalogue]  ┐
│ ┌──────────────────────────────────────────────────────────────────┐ │
│ │ ⟐ filesystem   ● connecté   transport: stdio   3 tools   [⚙][⏻]   │ │
│ │ ⟐ github       ● connecté   transport: http    12 tools  [⚙][⏻]   │ │
│ │ ⟐ postgres     ○ déconnect. transport: stdio   —         [⚙][⏻]   │ │
│ └──────────────────────────────────────────────────────────────────┘ │
│ [+ Ajouter un serveur]                                                 │
└────────────────────────────────────────────────────────────────────────┘
  Modal ajout : nom · transport(stdio/http/sse) · commande/URL · env vars
                · headers · [tester la connexion] · [enregistrer]
```

**Composants** : `DataTable` serveurs (`StatusBadge` connexion, nb tools, transport), catalogue en cartes (nom, description, popularité, bouton « installer »), `Dialog` formulaire CRUD avec **test de connexion** inline, gestion env vars (clé/valeur, masquage secrets).

**Données** : MCP CRUD config `[PLANIFIÉ]`, catalogue/registry `[PLANIFIÉ]`.

**États** :
- Vide : « Aucun serveur MCP configuré. Ajoutez-en un ou parcourez le catalogue. »
- Test connexion en cours : bouton spinner « Test en cours… ».
- Test OK : badge vert « Connexion réussie · N tools détectés ».
- Test échec : « Échec de connexion : <message>. Vérifiez la commande/URL et les variables d'env. »
- Suppression : `confirmation-dialog` « Supprimer le serveur “github” ? Cette action retire sa configuration du profil. [Annuler] [Supprimer] » + undo toast.

**Interactions** : ajouter/éditer/supprimer, activer/désactiver, tester connexion, voir les tools exposés, installer depuis catalogue (pré-remplit le formulaire).

**Micro-copy** : champ secret « Stocké chiffré dans le profil — jamais affiché en clair. »

---

### Feature 7 — Logs `[tail LIVE · persistance/recherche PLANIFIÉ]`

**Objectif** : consulter les logs (filtres source/niveau/run/date, recherche, pagination), stockés avec rétention (nettoyage mensuel).

**Wireframe**
```
┌ Logs                                                                    ┐
│ source:[tous▾] niveau:[info+▾] run:[#a91▾] date:[7j▾]  [🔍 recherche] ⏸ │
├─────────┬───────┬──────────┬────────────────────────────────────────────┤
│ time    │ level │ source   │ message                                    │
│ 14:02:11│ INFO  │ core     │ run #a91 started · pipeline backend-feature │
│ 14:02:15│ DEBUG │ router   │ thompson pick → nestjs (p=0.89)             │
│ 14:02:41│ WARN  │ gateway  │ retry phase implement (1/3)                 │
│ 14:03:02│ ERROR │ core     │ phase review failed: assertion ...          │  ← ligne rouge
├─────────┴───────┴──────────┴────────────────────────────────────────────┤
│ rétention: 30j · nettoyage auto mensuel       ‹ 1 2 3 … ›   1–50 / 1240 │
└──────────────────────────────────────────────────────────────────────────┘
```

**Composants** : barre de filtres (multi-select source/niveau, sélecteur run, plage de dates, recherche full-text), table logs virtualisée (couleur de bordure gauche par niveau, monospace, expand ligne → contexte/stacktrace), toggle live tail/historique, pagination, info rétention.

**Données** : `logs.tail` live `[LIVE]` ; logs persistés + recherche + filtres + pagination `[PLANIFIÉ]`.

**États** :
- Live tail : flux en bas, auto-scroll + pause ; nouvelles lignes en fondu.
- Vide / aucun résultat : « Aucun log pour ces filtres. [Réinitialiser les filtres] ».
- Chargement page : skeleton lignes.
- Erreur : « Impossible de charger les logs. [Réessayer] ».

**Interactions** : combiner filtres (état dans l'URL), recherche, basculer live/historique, expand ligne, copier ligne, lien run → détail run, export `[PLANIFIÉ]`.

**Micro-copy** : « Logs conservés 30 jours · purge automatique le 1er du mois. »

---

### Feature 8 — Settings `[providers/obsidian/budget : LIVE partiel · settings unifié : PLANIFIÉ]`

**Objectif** : configurer le profil — providers LLM, budget, Obsidian, webhook.

**Écrans** : page à onglets (Providers · Budget · Obsidian · Webhook · Avancé).

**Wireframe (Providers + Budget)**
```
┌ Settings — profil: pro     [Providers][Budget][Obsidian][Webhook][Avancé]┐
│ PROVIDERS LLM                                                             │
│  ◉ Anthropic   clé: ••••••••  modèles: opus·sonnet·haiku   [tester] ●ok  │
│  ○ OpenAI      [+ configurer]                                            │
│  ○ DeepSeek    [+ configurer]                                           │
│ ─────────────────────────────────────────────────────────────────────── │
│ BUDGET                                                                    │
│  Plafond mensuel:  [$200]   alerte à [80]%   ☑ bloquer au dépassement    │
│  Consommé ce mois: $124  ▓▓▓▓▓▓░░░ 62%                                    │
└────────────────────────────────────────────────────────────────────────────┘
```

**Composants** : `Tabs`, lignes provider (statut + clé masquée + test), `CostMeter` budget, inputs avec helper text + validation inline, `Switch`, champ webhook URL + test, mapping tier→modèle (par défaut : opus T3 / sonnet T2 / haiku T1).

**Données** : `providers` `[LIVE]`, `obsidian.status` `[LIVE]`, budget via cost-report `[LIVE]` ; persistance unifiée des settings `[PLANIFIÉ]`.

**États** : clé invalide « Clé API invalide ou révoquée. » ; test provider en cours/ok/échec ; sauvegarde « Modifications enregistrées. » (toast) ; champ requis manquant → erreur sous le champ + focus premier invalide ; modifications non sauvegardées → confirm avant de quitter l'onglet.

**Interactions** : éditer/tester chaque provider, définir budget + seuil + blocage, connecter vault Obsidian (chemin), tester webhook, mapping tier↔modèle.

**Micro-copy** : « Les clés API sont chiffrées et propres à ce profil. » · webhook test « Ping envoyé — en attente de réponse… » · budget « À 100 %, les nouveaux runs seront refusés si le blocage est activé. »

---

### Feature 9 — Gestion des profils `[liste+actif LIVE · switch/create PLANIFIÉ]`

**Objectif** : lister, créer et **basculer** entre profils ; chaque profil = espace isolé `~/.claude-<nom>`.

**Écrans** : popover depuis le sélecteur (top bar / pied sidebar) + page de gestion + modal création.

**Wireframe (popover sélecteur)**
```
┌ Profils ───────────────────────┐
│ 🔍 filtrer                       │
│ ◉ pro       opus  ● up  $124    │  ← actif
│ ○ perso     sonnet ● up  $12    │
│ ○ client-x  haiku  ○ down  $0   │
│ ────────────────────────────────│
│ + Créer un profil                │
│ ⚙ Gérer les profils              │
└──────────────────────────────────┘
  Création (modal) : nom · template d'agents · tier par défaut · [créer]
```

**Composants** : `Command`/popover sélecteur (recherche, item actif marqué, santé + tier + coût), page gestion (table profils : nom, chemin, actif, #agents, #runs, coût, santé, dernière activité), `Dialog` création.

**Données** : profiles liste + actif `[LIVE]` ; switch + create `[PLANIFIÉ]`.

**États** :
- Bascule en cours : overlay léger « Bascule vers “perso”… » → **rechargement du contexte global** (toutes les vues reflètent le nouveau profil).
- Création : validation nom (`[a-z0-9-]`, unique) ; succès « Profil “client-x” créé. » ; échec « Un profil nommé “…” existe déjà. ».
- Profil down : badge « hors-ligne » + action « Démarrer le daemon ».

**Interactions** : basculer (clic), créer, ouvrir gestion, rechercher, supprimer (confirm + warning « supprime l'espace isolé »).

**Micro-copy** : « Changer de profil recharge l'ensemble du contexte (agents, runs, mémoire, settings). » · sélecteur « Profil actif : pro ».

---

## 5. Patterns transverses

### 5.1 Temps réel / streaming
- **Transport** : WebSocket par room workspace (events `run.*`, `phase.*`, `cost.delta` planifié) + `logs.tail`.
- **Anti-CLS** : réserver l'espace, `tabular-nums` sur tout chiffre qui bouge (coûts, tokens, durées, compteurs).
- **Stream console** : auto-scroll « stick to bottom » désactivable, bouton « ↓ reprendre », pause/resume, copier, recherche, indicateur tokens/s. Respecte `prefers-reduced-motion` (pas de clignotement ; valeur courante lisible en KPI texte).
- **Transitions de statut** : ○→◉→✓/✕ animées (crossfade 150–200ms, pas de snap), pulse doux sur `running`. Nouvelles lignes/items en stagger 30–50ms.
- **Indicateur de connexion WS** : pastille dans la top bar (connecté / reconnexion… / hors-ligne) + bannière si perte prolongée « Connexion temps réel perdue — reconnexion… ».

### 5.2 Sélecteur de profil (global)
Présent en top bar + pied de sidebar. Toujours visible. Changement = rechargement du contexte (invalidation des queries). Profil actif clairement marqué partout (header, breadcrumb).

### 5.3 États vides / chargement / erreur (canon)
- **Vide** : icône + titre + 1 phrase d'explication + 1 CTA primaire. Jamais d'écran blanc.
- **Chargement** : skeletons qui épousent la forme finale (cartes, lignes de table, axes de chart shimmer — pas d'axe vide). Spinner uniquement < blocs ponctuels.
- **Erreur** : message = cause + chemin de récupération (`[Réessayer]` / `[Voir la trace]`). `role="alert"` / `aria-live`. Erreurs serveur globales en bannière non-bloquante.
- **Destructif** : `confirmation-dialog` + couleur danger + séparation visuelle + **undo** quand possible.

### 5.4 Responsive
Voir §2.4. Tables → cartes ou scroll horizontal < 768px ; graphe 3D → fallback ; sidebar → bottom-sheet. Cas nominal = desktop large.

### 5.5 Accessibilité (WCAG AA, dark)
- Contraste : texte ≥ 4.5:1, secondaire ≥ 3:1, data lines/bars ≥ 3:1 — vérifié **en dark indépendamment**.
- **Jamais d'info par couleur seule** : statut = couleur + icône + label ; tiers = couleur + libellé ; heatmap = couleur + valeur au survol + légende ; charts = ligne style/forme + légende interactive.
- Focus visible 2px (ring `--primary`) sur tous les interactifs ; ordre de tab = ordre visuel ; focus déplacé vers le contenu au changement de route.
- Icônes seules → `aria-label`. Tables triables → `aria-sort`. Toasts `aria-live="polite"`, ne volent pas le focus.
- `prefers-reduced-motion` : animations gelées/réduites, graphe 3D statique, streams sans clignotement, data lisible immédiatement.
- Charts : résumé texte / `aria-label` décrivant l'insight ; alternative tableau pour les data-viz clés.
- Modales/drawers : Esc + scrim ; focus trap ; retour focus au déclencheur.

---

## 6. Annexe — Dictionnaire de données

> Champs indicatifs pour cadrer ce que chaque vue affiche. Statut LIVE/PLANIFIÉ par entité.

| Entité | Statut | Champs clés |
|--------|--------|-------------|
| **Workspace** | PLANIFIÉ | `id` (uuid), `name`, `path/repo`, `createdAt`, `conversationsCount`, `totalCost`, `lastActivityAt` |
| **Conversation** | PLANIFIÉ | `id`, `workspaceId`, `title`, `status` (idle/running/done/failed), `runs[]`, `agentsInvolved[]`, `cost`, `createdAt`, `updatedAt` |
| **Run** | LIVE | `id`, `workspaceId`, `conversationId`, `pipelineId?`, `mode` (pipeline/interactive), `status`, `phases[]`, `topology` (sequential/parallel_mesh), `tokens`, `cost`, `startedAt`, `endedAt`, `durationMs` |
| **Phase** | LIVE (events) | `id`, `runId`, `name`, `agentId`, `tier` (T1/T2/T3), `model`, `status` (queued/running/success/failed), `dependsOn[]`, `tokens`, `cost`, `durationMs`, `output/logRef` |
| **Agent** | LIVE | `id`, `name`, `role/description`, `tier`, `model`, `systemPrompt`, `skills[]`, `runs`, `successRate`, `tokens`, `cost`, `p50/p95`, `thompson` `{alpha,beta,pWin}` |
| **Profile** | LIVE (liste+actif) | `name`, `path` (`~/.claude-<nom>`), `active`, `defaultTier`, `agentsCount`, `runsCount`, `totalCost`, `health`, `lastActivityAt` |
| **Team** | PLANIFIÉ | `id`, `name`, `description`, `members[]` (agentId+tier), `defaultPipeline`, aggregated `{runs, successRate, cost}` |
| **Pipeline** | PLANIFIÉ | `id`, `name`, `description`, `phases[]` `{name, agentId, tier, dependsOn[], avgDuration, avgCost}`, `topology` |
| **MemoryNode** | PLANIFIÉ | `id`, `title`, `type` (decision/fact/note/entity…), `edges[]` `{targetId, relation}`, `noteRef` (chemin Obsidian), `createdAt` |
| **MCPServer** | PLANIFIÉ | `id`, `name`, `transport` (stdio/http/sse), `command/url`, `env{}` (secrets masqués), `headers{}`, `status` (connected/disconnected), `tools[]`, `enabled` |
| **LogEntry** | tail LIVE / persist PLANIFIÉ | `id`, `timestamp`, `level` (debug/info/warn/error), `source` (core/router/gateway/daemon…), `message`, `runId?`, `context/meta{}`, `retentionUntil` |
| **Provider** | LIVE | `name` (anthropic/openai/deepseek), `apiKey` (masqué), `models[]`, `status`, `enabled` |
| **Budget** | LIVE (cost-report) | `monthlyCap`, `consumed`, `pct`, `alertThreshold`, `blockOnExceed`, `period` |
| **Health/Daemon** | LIVE | `daemonStatus` (up/down), `activeAgents`, `wsConnected`, `uptime`, `version` |

---

*Fin du brief. Tout élément marqué [PLANIFIÉ] doit être conçu visuellement (vision cible) mais peut afficher un badge discret « bientôt » / utiliser des données de démonstration en attendant l'API.*
