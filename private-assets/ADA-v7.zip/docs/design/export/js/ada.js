/* ADA shared chrome: sidebar, topbar, theme, command palette, drawer. */
(function () {
  "use strict";

  // ---- Lucide-style inline icons (stroke 1.9, 24x24) ----
  var I = {
    dashboard: '<path d="M3 3h7v9H3zM14 3h7v5h-7zM14 12h7v9h-7zM3 16h7v5H3z"/>',
    workspaces:'<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/>',
    pipelines: '<circle cx="6" cy="6" r="2.4"/><circle cx="18" cy="18" r="2.4"/><circle cx="18" cy="6" r="2.4"/><path d="M8.4 6H18M6 8.4V14a4 4 0 0 0 4 4h5.6"/>',
    agents:    '<path d="M12 2 4 6v6c0 5 3.4 7.7 8 10 4.6-2.3 8-5 8-10V6z"/><circle cx="12" cy="10" r="2.2"/><path d="M8.5 16a3.5 3.5 0 0 1 7 0"/>',
    memory:    '<circle cx="12" cy="12" r="3"/><circle cx="5" cy="6" r="2"/><circle cx="19" cy="7" r="2"/><circle cx="18" cy="18" r="2"/><circle cx="6" cy="18" r="2"/><path d="M7 7l3 3M17 8l-2.5 2M16.5 16.5 14 14M8 16.5 10 14"/>',
    mcp:       '<rect x="3" y="4" width="18" height="6" rx="1.5"/><rect x="3" y="14" width="18" height="6" rx="1.5"/><path d="M7 7h.01M7 17h.01"/>',
    logs:      '<path d="M4 5h16M4 10h16M4 15h10M4 20h7"/>',
    settings:  '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-2.9 1.2V21a2 2 0 0 1-4 0v-.1A1.7 1.7 0 0 0 6.8 19l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0-1.2-2.9H2a2 2 0 0 1 0-4h.1A1.7 1.7 0 0 0 5 6.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 2.9-1.2V2a2 2 0 0 1 4 0v.1A1.7 1.7 0 0 0 19 5l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0 1.2 2.9H21a2 2 0 0 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1.3z"/>',
    search:    '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
    sidebar:   '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 3v18"/>',
    sun:       '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    moon:      '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',
    x:         '<path d="M18 6 6 18M6 6l12 12"/>',
    chevron:   '<path d="m9 18 6-6-6-6"/>',
    plus:      '<path d="M12 5v14M5 12h14"/>',
    play:      '<path d="m6 4 14 8-14 8z"/>',
    bolt:      '<path d="M13 2 3 14h7l-1 8 10-12h-7z"/>',
    cost:      '<circle cx="12" cy="12" r="9"/><path d="M12 7v10M9.5 9.2A2.5 2.5 0 0 1 12 8c1.4 0 2.5.8 2.5 2s-1.1 1.8-2.5 1.8-2.5.8-2.5 2 1.1 2 2.5 2a2.5 2.5 0 0 0 2.5-1.2"/>',
    activity:  '<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>',
    check:     '<path d="M20 6 9 17l-5-5"/>',
    filter:    '<path d="M22 3H2l8 9.5V19l4 2v-8.5z"/>',
    copy:      '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/>',
    pause:     '<path d="M7 4h3v16H7zM14 4h3v16h-3z"/>',
    refresh:   '<path d="M3 12a9 9 0 0 1 15-6.7L21 8M21 3v5h-5M21 12a9 9 0 0 1-15 6.7L3 16M3 21v-5h5"/>',
    download:  '<path d="M12 3v12m0 0 4-4m-4 4-4-4M5 21h14"/>',
    clock:     '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    layers:    '<path d="m12 2 9 5-9 5-9-5z"/><path d="m3 12 9 5 9-5M3 17l9 5 9-5"/>'
  };
  function svg(name, cls) {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"'
      + (cls ? ' class="' + cls + '"' : '') + '>' + (I[name] || '') + '</svg>';
  }

  var NAV = [
    { id: 'dashboard', label: 'Dashboard',  href: 'dashboard.html', icon: 'dashboard' },
    { id: 'workspaces',label: 'Workspaces', href: 'workspaces.html', icon: 'workspaces', badge: '3' },
    { id: 'pipelines', label: 'Pipelines',  href: 'pipelines.html', icon: 'pipelines' },
    { id: 'agents',    label: 'Agents',     href: 'agents.html', icon: 'agents' },
    { id: 'memory',    label: 'Memory',     href: 'memory.html', icon: 'memory' },
    { id: 'mcp',       label: 'MCP',        href: 'mcp.html', icon: 'mcp' },
    { id: 'logs',      label: 'Logs',       href: 'logs.html', icon: 'logs' },
    { id: 'settings',  label: 'Settings',   href: 'settings.html', icon: 'settings' }
  ];

  var PROFILES = [
    { id: 'claude-pro', name: 'claude-pro', tier: 'opus',   health: 'running' },
    { id: 'dune',       name: 'dune-dental',tier: 'sonnet', health: 'running' },
    { id: 'scratch',    name: 'scratch',    tier: 'haiku',  health: 'idle' }
  ];

  // ---- theme ----
  function applyTheme(t) {
    document.documentElement.setAttribute('data-theme', t);
    try { localStorage.setItem('ada-theme', t); } catch (e) {}
    var btn = document.getElementById('theme-btn');
    if (btn) btn.innerHTML = svg(t === 'light' ? 'moon' : 'sun');
  }
  function initTheme() {
    var t = 'dark';
    try { t = localStorage.getItem('ada-theme') || 'dark'; } catch (e) {}
    applyTheme(t);
  }

  // ---- render sidebar + topbar ----
  function renderSidebar(active) {
    var collapsed = false;
    try { collapsed = localStorage.getItem('ada-collapsed') === '1'; } catch (e) {}
    var items = NAV.map(function (n) {
      return '<a class="nav-item' + (n.id === active ? ' active' : '') + '" href="' + n.href + '" title="' + n.label + '">'
        + svg(n.icon) + '<span class="nav-label">' + n.label + '</span>'
        + (n.badge ? '<span class="nav-badge">' + n.badge + '</span>' : '') + '</a>';
    }).join('');
    var p = PROFILES[0];
    return '<aside class="sidebar' + (collapsed ? ' collapsed' : '') + '" id="sidebar">'
      + '<div class="brand"><div class="brand-mark">A</div>'
      + '<div class="brand-text"><b>ADA</b><span>Orchestrator</span></div></div>'
      + '<nav class="nav">' + items + '</nav>'
      + '<div class="sidebar-foot"><button class="profile-card" id="profile-btn">'
      + '<div class="profile-dot">◐</div>'
      + '<div class="profile-meta"><b>' + p.name + '</b>'
      + '<div class="row"><span class="tier ' + p.tier + '">' + p.tier + '</span>'
      + '<span style="color:var(--st-running)">●</span></div></div></button></div></aside>';
  }

  function renderTopbar(crumb) {
    var parts = (crumb || ['Dashboard']).map(function (c, i, arr) {
      var last = i === arr.length - 1;
      return (i > 0 ? '<span class="sep">' + svg('chevron') + '</span>' : '')
        + '<span class="crumb-item' + (i === 0 && arr.length > 1 ? ' hide-sm' : '') + '">'
        + (last ? '<b>' + c + '</b>' : c) + '</span>';
    }).join('');
    return '<header class="topbar">'
      + '<button class="icon-btn" id="collapse-btn" title="Replier la barre latérale" aria-label="Replier">' + svg('sidebar') + '</button>'
      + '<div class="crumb">' + parts + '</div>'
      + '<div class="topbar-spacer"></div>'
      + '<button class="cmdk-trigger" id="cmdk-btn"><span style="display:flex;align-items:center;gap:8px">'
      + svg('search') + '<span class="label">Rechercher ou exécuter…</span></span><kbd>⌘K</kbd></button>'
      + '<div class="health-pill"><span class="pulse"></span>daemon</div>'
      + '<button class="icon-btn" id="theme-btn" title="Thème" aria-label="Basculer le thème">' + svg('sun') + '</button>'
      + '</header>';
  }

  // ---- command palette ----
  var cmdkSel = 0, cmdkItems = [];
  function buildCmdk() {
    var actions = [
      { g: 'Actions', label: 'Lancer une instruction…', icon: 'play', href: 'workspaces.html' },
      { g: 'Actions', label: 'Nouveau pipeline', icon: 'pipelines', href: 'pipelines.html' },
      { g: 'Actions', label: 'Basculer de profil', icon: 'agents', href: 'agents.html' }
    ];
    var nav = NAV.map(function (n) { return { g: 'Aller à', label: n.label, icon: n.icon, href: n.href }; });
    return actions.concat(nav);
  }
  function renderCmdkList(q) {
    var all = buildCmdk();
    var f = all.filter(function (x) { return x.label.toLowerCase().indexOf((q || '').toLowerCase()) > -1; });
    cmdkItems = f; cmdkSel = 0;
    var groups = {}; f.forEach(function (x) { (groups[x.g] = groups[x.g] || []).push(x); });
    var html = '', idx = 0;
    Object.keys(groups).forEach(function (g) {
      html += '<div class="cmdk-group">' + g + '</div>';
      groups[g].forEach(function (x) {
        html += '<div class="cmdk-item" data-i="' + idx + '" data-href="' + x.href + '">'
          + svg(x.icon) + '<span>' + x.label + '</span><span class="hint">↵</span></div>';
        idx++;
      });
    });
    if (!f.length) html = '<div class="empty" style="padding:30px">' + svg('search') + '<span>Aucun résultat</span></div>';
    var list = document.getElementById('cmdk-list');
    list.innerHTML = html; highlightCmdk();
    Array.prototype.forEach.call(list.querySelectorAll('.cmdk-item'), function (el) {
      el.addEventListener('click', function () { go(el.getAttribute('data-href')); });
    });
  }
  function highlightCmdk() {
    var els = document.querySelectorAll('.cmdk-item');
    Array.prototype.forEach.call(els, function (el, i) { el.classList.toggle('sel', i === cmdkSel); });
  }
  function go(href) { if (href) window.location.href = href; }
  function openCmdk() {
    document.getElementById('cmdk-scrim').classList.add('open');
    document.getElementById('cmdk').classList.add('open');
    var inp = document.getElementById('cmdk-input'); inp.value = ''; renderCmdkList(''); setTimeout(function () { inp.focus(); }, 30);
  }
  function closeCmdk() {
    document.getElementById('cmdk-scrim').classList.remove('open');
    document.getElementById('cmdk').classList.remove('open');
  }

  function mountOverlays() {
    var wrap = document.createElement('div');
    wrap.innerHTML =
      '<div class="cmdk-scrim" id="cmdk-scrim"></div>'
      + '<div class="cmdk" id="cmdk" role="dialog" aria-label="Palette de commandes">'
      + '<div class="cmdk-input">' + svg('search')
      + '<input id="cmdk-input" placeholder="Rechercher une page, un run, un agent — ou exécuter…" autocomplete="off"></div>'
      + '<div class="cmdk-list" id="cmdk-list"></div></div>'
      + '<div class="drawer-scrim" id="drawer-scrim"></div>'
      + '<aside class="drawer" id="drawer"><div class="drawer-head"><h3 id="drawer-title"></h3>'
      + '<button class="icon-btn" id="drawer-close">' + svg('x') + '</button></div>'
      + '<div class="drawer-body" id="drawer-body"></div></aside>';
    document.body.appendChild(wrap);

    document.getElementById('cmdk-scrim').addEventListener('click', closeCmdk);
    document.getElementById('cmdk-input').addEventListener('input', function (e) { renderCmdkList(e.target.value); });
    document.getElementById('drawer-scrim').addEventListener('click', closeDrawer);
    document.getElementById('drawer-close').addEventListener('click', closeDrawer);
  }

  // ---- drawer API ----
  function openDrawer(title, html) {
    document.getElementById('drawer-title').innerHTML = title;
    document.getElementById('drawer-body').innerHTML = html;
    document.getElementById('drawer-scrim').classList.add('open');
    document.getElementById('drawer').classList.add('open');
  }
  function closeDrawer() {
    document.getElementById('drawer-scrim').classList.remove('open');
    document.getElementById('drawer').classList.remove('open');
  }

  function toggleCollapse() {
    var sb = document.getElementById('sidebar');
    sb.classList.toggle('collapsed');
    try { localStorage.setItem('ada-collapsed', sb.classList.contains('collapsed') ? '1' : '0'); } catch (e) {}
  }

  // ---- public mount ----
  function mount(opts) {
    opts = opts || {};
    var shell = document.querySelector('.app-shell');
    var sbHost = document.getElementById('sb-host');
    var tbHost = document.getElementById('tb-host');
    if (sbHost) sbHost.outerHTML = renderSidebar(opts.active);
    if (tbHost) tbHost.outerHTML = renderTopbar(opts.crumb);

    initTheme();
    mountOverlays();

    document.getElementById('theme-btn').addEventListener('click', function () {
      applyTheme(document.documentElement.getAttribute('data-theme') === 'light' ? 'dark' : 'light');
    });
    document.getElementById('collapse-btn').addEventListener('click', toggleCollapse);
    document.getElementById('cmdk-btn').addEventListener('click', openCmdk);
    var pb = document.getElementById('profile-btn');
    if (pb) pb.addEventListener('click', function () {
      openDrawer('Profils', PROFILES.map(function (p) {
        return '<button class="profile-card" style="margin-bottom:8px">'
          + '<div class="profile-dot">◐</div><div class="profile-meta"><b>' + p.name + '</b>'
          + '<div class="row"><span class="tier ' + p.tier + '">' + p.tier + '</span>'
          + '<span style="color:var(--st-' + p.health + ')">●</span> <span>~/.claude-' + p.id + '</span></div></div></button>';
      }).join('') + '<button class="btn btn-ghost" style="width:100%;margin-top:6px;justify-content:center">'
      + svg('plus') + 'Créer un profil</button>');
    });

    document.addEventListener('keydown', function (e) {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); openCmdk(); return; }
      var open = document.getElementById('cmdk').classList.contains('open');
      if (e.key === 'Escape') { closeCmdk(); closeDrawer(); }
      if (open && cmdkItems.length) {
        if (e.key === 'ArrowDown') { e.preventDefault(); cmdkSel = (cmdkSel + 1) % cmdkItems.length; highlightCmdk(); }
        if (e.key === 'ArrowUp') { e.preventDefault(); cmdkSel = (cmdkSel - 1 + cmdkItems.length) % cmdkItems.length; highlightCmdk(); }
        if (e.key === 'Enter') { e.preventDefault(); go(cmdkItems[cmdkSel].href); }
      }
    });
  }

  window.ADA = { mount: mount, svg: svg, openDrawer: openDrawer, closeDrawer: closeDrawer, icons: I };
})();
