# ADA Platform v2 — Architecture

> Version 2.0 | Statut: Spécification | Date: 2026-05-31

---

## Principes fondateurs

### P1 — Autorité par domaine

Chaque service est propriétaire exclusif de ses données. Aucun service ne lit
directement la base de données d'un autre. Les échanges se font uniquement par
contrats définis (IPC socket, WebSocket, REST). Ce principe garantit qu'un
service peut évoluer ou être remplacé sans casser les autres.

- **ada-core** possède : runs, trajectoires, agents, routing priors, bank
- **ada-api** possède : conversations, workspaces, messages, sessions, run_links
- **ada-ui** possède : état UI transitoire uniquement (jamais persisté)

### P2 — Contrat immuable

Les événements IPC et WebSocket ne sont jamais modifiés rétroactivement une
fois publiés. Un type d'événement défini dans le catalogue (`EVENT-CATALOG.md`)
garde sa structure pour toujours. L'évolution se fait uniquement par ajout de
champs optionnels ou de nouveaux types. Ce principe permet à des versions
différentes des services de coexister pendant une mise à jour progressive.

### P3 — Résilience par couches

La communication entre services dispose de 3 niveaux de dégradation gracieuse :

| Couche | Mécanisme | Activation |
|--------|-----------|-----------|
| 1 (primaire) | IPC Unix socket push | toujours en mode local |
| 2 (secondaire) | IPC TCP loopback push | mode serveur / socket absent |
| 3 (tertiaire) | FSWatch + events.ndjson replay | socket IPC indisponible |

La couche 3 garantit qu'aucun événement n'est perdu, même si ada-api était
arrêté pendant qu'ada-core tournait.

---

## Vue d'ensemble

```
┌─────────────────────────────────────────────────────────────────────┐
│                         ADA Platform v2                             │
│                                                                     │
│  ┌─────────────────┐          ┌──────────────────┐                 │
│  │   ada-core      │          │    ada-api        │                 │
│  │   (Node.js CLI) │          │  (Fastify server) │                 │
│  │                 │  IPC     │                   │  WebSocket      │
│  │  runs/          │ ──────►  │  ada-api.db       │ ──────────────► │
│  │  bank.db        │  socket  │  (SQLite/Drizzle) │                 │
│  │  router-state   │  :3099   │                   │  REST           │
│  │  events.ndjson  │          │  :3001            │ ◄────────────── │
│  │                 │          │                   │                 │
│  │  (no HTTP port) │          │                   │  ┌─────────────┐│
│  └─────────────────┘          └──────────────────┘  │   ada-ui    ││
│           ▲                            │             │  (Next.js)  ││
│           │                            │             │             ││
│           │ spawn process              │ REST + WS   │  :7777      ││
│           └────────────────────────────┘             │             ││
│                                                      └─────────────┘│
└─────────────────────────────────────────────────────────────────────┘

Protocoles :
  ada-core  → ada-api : IPC NDJSON (Unix socket .claude/ada-core.sock
                                    ou TCP 127.0.0.1:3099)
  ada-api   → ada-ui  : WebSocket ws://localhost:3001/ws
  ada-ui    → ada-api : REST HTTP + WebSocket commands
  ada-ui    → ada-core: JAMAIS DIRECT (passe toujours par ada-api)
  ada-api   → ada-core: spawn CLI process (ex: node run.js next <id>)
```

---

## Services

### Ada-Core (Node.js CLI)

**Rôle** : Moteur d'orchestration des runs. Exécute les phases, gère le
routing Thompson Sampling, persiste les trajectoires dans le ReasoningBank.
Service fondateur — son comportement ne change pas en v2.

**Responsabilités** :
- Lancer et orchestrer les phases d'un run (`node run.js next <runId>`)
- Sélectionner les agents via routing probabiliste (bank.db)
- Persister les résultats de chaque phase (`.claude/runs/<id>/state.json`)
- Émettre des événements IPC après chaque write atomique (v2 uniquement)
- Maintenir le journal d'événements append-only (`events.ndjson`)

**Ce qu'il possède (autorité exclusive)** :
```
.claude/
├── runs/
│   └── <runId>/
│       ├── state.json          # état courant du run
│       ├── phases/             # résultats par phase
│       └── meta.json           # métadonnées run
├── bank.db                     # ReasoningBank SQLite
├── router-state.json           # priors Thompson Sampling
└── events.ndjson               # journal IPC append-only
```

**Changements v2 (3 ajouts mineurs, aucune régression)** :

| Ajout | Fichier | Description |
|-------|---------|-------------|
| `emitIPC(event)` | `run.js` | Émet après chaque `renameSync` atomic write |
| `events.ndjson` append | `run.js` | Log append-only parallèle à l'IPC |
| `--headless` flag | `run.js` | Désactive les outputs ANSI (pour ada-api spawn) |

**Port** : Aucun (pas de serveur HTTP)

**IPC sortant** :
- Unix socket : `.claude/ada-core.sock` (mode local)
- TCP : `127.0.0.1:3099` (mode serveur, loopback uniquement)

---

### Ada-API (Fastify + SQLite)

**Rôle** : Passerelle entre ada-core et ada-ui. Traduction des événements IPC
en WebSocket. Persistance des conversations et workspaces. Exposition d'une API
REST pour les mutations (spawn run, send message, etc.).

**Responsabilités** :
- Recevoir les événements IPC d'ada-core et mettre à jour sa DB
- Broadcaster les mises à jour vers ada-ui via WebSocket
- Exposer l'API REST pour les actions de ada-ui
- Spawner des processus ada-core CLI en réponse aux commandes ada-ui
- Gérer l'authentification JWT pour les connexions multi-clients
- Maintenir le cursor `events.cursor` pour le replay NDJSON

**Ce qu'il possède (autorité exclusive)** :
```
ada-api.db  (SQLite, chemin: $ADA_DB_PATH ou ~/.claude-<profile>/ada-api.db)
├── conversations    -- historique des sessions de chat
├── messages         -- messages individuels (user/assistant/system)
├── workspaces       -- workspaces par profil
├── run_links        -- association conversation ↔ runId ada-core
└── sessions         -- tokens WebSocket actifs
```

**Stack technique** :
- Runtime : Node.js 22, TypeScript strict
- Framework HTTP : Fastify 4 (plugins: `@fastify/websocket`, `@fastify/cors`, `@fastify/jwt`)
- ORM : Drizzle ORM (dialect SQLite via `better-sqlite3`)
- WebSocket : `ws` via `@fastify/websocket`
- Auth : JWT via `jose`

**Port** : `3001` (REST + WebSocket sur le même port)

**Entrées** :
- IPC socket (push depuis ada-core)
- REST HTTP (depuis ada-ui)
- WebSocket commands (depuis ada-ui)

**Sorties** :
- WebSocket events (vers ada-ui, broadcast par room)
- Spawn process ada-core CLI

---

### Ada-UI (Next.js 15)

**Rôle** : Interface utilisateur. Affiche l'état des runs en temps réel,
expose le chat conversationnel, gère les workspaces. Ne connaît pas ada-core.

**Responsabilités** :
- Afficher les runs et leur progression (streaming WebSocket)
- Permettre la création et la gestion des conversations
- Gérer les workspaces utilisateur
- Authentifier les connexions vers ada-api

**Ce qu'il possède** :
- État UI transitoire uniquement : Zustand stores (jamais persistés côté client)
- Cache TanStack Query (invalidé sur events WebSocket)

**Ce qu'il ne fait jamais** :
- Lire directement `.claude/` ou `bank.db`
- Connaître l'existence de ada-core
- Persister des données métier dans `localStorage`

**Stack technique** :
- Framework : Next.js 15 (App Router, React 19)
- État serveur : TanStack Query v5
- État client : Zustand v5
- Composants : shadcn/ui + Tailwind CSS v4
- WebSocket client : native `WebSocket` API avec reconnexion auto

**Port** : `7777`

**Connexion** : REST + WebSocket vers `ada-api:3001` uniquement

---

## Flux de données

### Flux 1 — Lancement d'un run depuis ada-ui

```
ada-ui                    ada-api                    ada-core
  │                          │                           │
  │  POST /api/runs          │                           │
  │  { prompt, profile }     │                           │
  │ ───────────────────────► │                           │
  │                          │  spawn process            │
  │                          │  node run.js init         │
  │                          │  --headless --profile X   │
  │                          │ ─────────────────────────►│
  │                          │                           │ writes
  │                          │                           │ .claude/runs/<id>/
  │  202 { runId }           │                           │ meta.json
  │ ◄─────────────────────── │                           │
  │                          │                           │
  │  WS: run.started         │  IPC: run.started         │
  │  { runId, profile }      │ ◄──────────────────────── │
  │ ◄─────────────────────── │  upsert run_links         │
  │                          │                           │
  │  [affiche run UI]        │  IPC: run.phase.started   │
  │                          │ ◄──────────────────────── │
  │  WS: phase.started       │  upsert DB                │
  │ ◄─────────────────────── │                           │
  │                          │                           │
  │  WS: phase.progress      │  IPC: run.phase.log       │
  │ ◄─────────────────────── │ ◄──────────────────────── │
  │  [streaming logs]        │  insert message           │
  │                          │                           │
  │  WS: run.done            │  IPC: run.done            │
  │ ◄─────────────────────── │ ◄──────────────────────── │
  │  [marque run terminé]    │  update run_links status  │
  │                          │                           │
```

### Flux 2 — Mise à jour d'état en temps réel

```
ada-core (run.js)
  │
  │  1. Phase terminée : renameSync(tmp, state.json)  ← write atomique
  │
  │  2. emitIPC({
  │       type: "run.phase.done",
  │       payload: { runId, phase, result, durationMs }
  │     })
  │
  │  3. append events.ndjson ← même événement, log de secours
  │
  ▼
ada-api (ipc-listener.ts)
  │
  │  4. parse NDJSON line
  │
  │  5. db.upsert(run_links, { phase, status: "done", completedAt })
  │
  │  6. ws.broadcast(room=`run:${runId}`, {
  │       type: "phase.done",
  │       payload: { ... }
  │     })
  │
  ▼
ada-ui (useRunStore)
  │
  │  7. onmessage handler reçoit phase.done
  │
  │  8. Zustand store update : phases[phase].status = "done"
  │
  │  9. TanStack Query invalidation : queryClient.invalidateQueries(["run", runId])
  │
  ▼
  [Re-render React : phase affichée comme terminée]
```

### Flux 3 — Reprise après crash d'ada-api

```
ada-core                       ada-api (redémarre)
  │                                │
  │  [pendant downtime ada-api]    │
  │  continue d'écrire             │
  │  events.ndjson (append-only)   │
  │                                │
  │                                │  startup : lit events.cursor
  │                                │  cursor = { offset: 4821 }
  │                                │
  │                                │  ouvre events.ndjson
  │                                │  seek(4821)
  │                                │
  │                                │  replay ligne par ligne :
  │                                │    parse IPCMessage
  │                                │    upsert DB (idempotent via id)
  │                                │    avance cursor
  │                                │
  │                                │  cursor = { offset: 9134 }
  │                                │  sauvegarde events.cursor
  │                                │
  │  [socket IPC rétabli]          │  connecte socket IPC
  │  IPC: HELLO                    │ ◄──────────────────────
  │  ACK + cursor_offset           │ ─────────────────────►
  │                                │
  │  [reprend push temps réel]     │  [DB cohérente, WS actifs]
```

---

## Modes de déploiement

### Mode local (développement / usage personnel)

```
ada server start
│
├── ada-core daemon
│   └── écoute Unix socket : .claude/ada-core.sock
│
├── ada-api :3001
│   ├── connecte à .claude/ada-core.sock
│   └── expose REST + WebSocket
│
└── ada-ui :7777
    └── connecte à ws://localhost:3001/ws

Tous les processus sur la même machine, même utilisateur.
Pas d'authentification réseau (loopback uniquement).
```

### Mode serveur (VPS / cloud)

```
docker-compose up
│
├── ada-core container
│   └── TCP socket : 127.0.0.1:3099 (loopback inter-containers)
│
├── ada-api container :3001
│   ├── connecte à ada-core:3099
│   ├── volume : /data/ada-api.db
│   └── expose REST + WebSocket
│
├── ada-ui container :7777
│   └── connecte à ada-api:3001
│
└── Nginx reverse proxy :443
    ├── / → ada-ui:7777
    ├── /api → ada-api:3001
    └── /ws  → ada-api:3001 (WebSocket upgrade)

SSL : Let's Encrypt via certbot ou Traefik.
Authentification JWT obligatoire (CORS + Origin check).
```

---

## Garanties système

### G1 — Pas de perte d'événement

Chaque événement émis par ada-core est d'abord écrit dans `events.ndjson`
(append fsync), puis envoyé sur le socket IPC. Si le socket est fermé,
l'écriture NDJSON a déjà eu lieu. Au redémarrage d'ada-api, le replay depuis
le cursor récupère tous les événements manquants. Idempotence garantie par le
champ `id` (uuid v4) : un événement dupliqué est ignoré en DB (`INSERT OR IGNORE`).

### G2 — Reconnexion automatique

**ada-core → ada-api** : En cas de perte du socket, ada-api tente une
reconnexion avec backoff exponentiel : 1s, 2s, 4s, 8s, 16s, plafonné à 30s.
Pendant la reconnexion, le fallback events.ndjson est actif.

**ada-ui → ada-api** : Le client WebSocket tente une reconnexion avec la même
stratégie de backoff. TanStack Query refetch automatiquement après reconnexion
(`refetchOnReconnect: true`).

### G3 — Démarrage ordonné

`ada server start` démarre les services dans cet ordre et vérifie chaque étape :

```
1. ada-core daemon → attend .claude/ada-core.sock créé (timeout 10s)
2. ada-api        → attend GET /api/health 200 (timeout 15s)
3. ada-ui         → attend GET http://localhost:7777 200 (timeout 20s)
```

Si une étape échoue, les suivantes ne démarrent pas et un message d'erreur
clair est affiché avec les logs du service en faute.

### G4 — Isolation des pannes

| Service en panne | Impact | Comportement |
|-----------------|--------|-------------|
| ada-ui down | UI inaccessible | ada-core et ada-api continuent, aucun run perdu |
| ada-api down | UI déconnectée, pas de nouvelles commandes | ada-core continue ses runs en cours, NDJSON bufferise |
| ada-core down | Plus de nouveaux runs | ada-api et ada-ui restent up, historique consultable |
| DB ada-api corrompue | Perte conversations/workspaces | Runs ada-core intacts, replay NDJSON possible |

---

## Stack technique

| Service | Technologie | Version | Raison |
|---------|-------------|---------|--------|
| ada-core | Node.js | 22 LTS | Runtime existant, CommonJS |
| ada-core | CommonJS modules | — | Compatibilité codebase existante |
| ada-core | better-sqlite3 | 9.x | DB synchrone, performant pour CLI |
| ada-api | Node.js | 22 LTS | Même runtime que ada-core |
| ada-api | TypeScript | 5.x strict | Typage contrats IPC/WS |
| ada-api | Fastify | 4.x | Performances, ecosystem plugins |
| ada-api | @fastify/websocket | 8.x | WebSocket natif Fastify |
| ada-api | better-sqlite3 | 9.x | Synchrone, embedded, simple |
| ada-api | Drizzle ORM | 0.30.x | Type-safe, dialecte SQLite→PG futur |
| ada-api | jose | 5.x | JWT RS256 léger, sans dépendance |
| ada-ui | Next.js | 15.x | App Router, React Server Components |
| ada-ui | React | 19.x | Concurrent features, use() hook |
| ada-ui | TanStack Query | 5.x | Cache serveur, invalidation WS |
| ada-ui | Zustand | 5.x | État UI léger, devtools |
| ada-ui | shadcn/ui | latest | Composants accessibles, Tailwind |
| ada-ui | Tailwind CSS | 4.x | Styling performant |
| Infra | Docker Compose | v2 | Déploiement serveur optionnel |
| Infra | Nginx | 1.25+ | Reverse proxy, SSL termination |
