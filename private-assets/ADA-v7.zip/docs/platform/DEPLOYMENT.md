# Guide de déploiement — ADA Platform v2

> Version 2.0 | Date: 2026-05-31

---

## Mode local (développement / usage personnel)

### Prérequis

```
Node.js >= 22.0.0        (vérifier : node --version)
npm >= 10.0.0            (vérifier : npm --version)
ANTHROPIC_API_KEY        (variable d'environnement obligatoire)
```

Installation de Claude Code si absente :
```bash
npm install -g @anthropic-ai/claude-code
```

### Installation complète

```bash
# Cloner le dépôt
git clone https://github.com/jonathanARMS23/AI-Dev-Assistant.git
cd AI-Dev-Assistant

# Installer ada-core + ada-api + ada-ui en une seule commande
bash install.sh --with-server

# Le script effectue dans l'ordre :
#   1. npm install (ada-core)
#   2. npm install + tsc build (ada-api)
#   3. npm install + next build (ada-ui)
#   4. Génère ~/.claude-<profile>/ada-api.db (SQLite init + migrations)
#   5. Génère .env.local pour ada-ui
#   6. Crée le symlink /usr/local/bin/ada → .claude/bin/ada.js
```

### Démarrage

```bash
# Démarrer les 3 services
ada server start

# Ou en mode verbose (logs combinés en stdout)
ada server start --verbose

# Vérifier l'état
ada server status
# → ada-core ✅  (socket .claude/ada-core.sock)
# → ada-api  ✅  (:3001, SQLite ada-api.db OK)
# → ada-ui   ✅  (:7777, connected to ada-api)

# Arrêt propre
ada server stop

# Redémarrer un service spécifique
ada server restart ada-api
```

### Ports par défaut

| Service | Endpoint | Variable d'environnement |
|---------|----------|--------------------------|
| ada-core IPC (local) | `.claude/ada-core.sock` | `$ADA_IPC_SOCKET` |
| ada-core IPC (serveur) | `127.0.0.1:3099` | `$ADA_IPC_PORT` |
| ada-api REST | `http://localhost:3001` | `$ADA_API_PORT` |
| ada-api WebSocket | `ws://localhost:3001/ws` | `$ADA_API_PORT` |
| ada-ui | `http://localhost:7777` | `$ADA_UI_PORT` |

### Fichiers générés lors de l'installation

```
~/.claude-<profile>/
├── ada-api.db          # Base SQLite ada-api (conversations, workspaces)
└── ada-api.db-wal      # WAL SQLite (mode WAL activé automatiquement)

.env.local              # Variables Next.js (NEXT_PUBLIC_API_URL, etc.)
.claude/
├── ada-core.sock       # Unix socket IPC (créé au démarrage)
└── events.ndjson       # Journal IPC append-only
```

---

## Mode serveur (VPS / cloud)

### Prérequis serveur

```
OS         : Ubuntu 22.04+ ou Debian 12+
RAM        : 2 Go minimum, 4 Go recommandé
CPU        : 2 vCPU minimum
Stockage   : 20 Go SSD
Ports      : 80, 443 ouverts en entrant

Node.js 22+ via nvm :
  curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
  nvm install 22 && nvm use 22

Docker + Docker Compose (optionnel mais recommandé) :
  curl -fsSL https://get.docker.com | sh
  apt install docker-compose-plugin

Nginx :
  apt install nginx certbot python3-certbot-nginx

Domaine avec DNS A → IP du serveur
```

### Installation serveur

```bash
# Sur le VPS, en tant qu'utilisateur non-root avec sudo
git clone https://github.com/jonathanARMS23/AI-Dev-Assistant.git /opt/ada
cd /opt/ada

# Initialisation automatique
ada server init --remote \
  --domain ada.ton-domaine.com \
  --email admin@ton-domaine.com

# Cette commande génère :
#   docker-compose.yml      (3 services + volumes)
#   nginx.conf              (reverse proxy + SSL + WS upgrade)
#   .env.server             (toutes les variables requises)
#   ssl/                    (placeholder, certbot le remplira)

# Éditer .env.server avant de déployer (voir Variables ci-dessous)
nano .env.server

# Déploiement
ada server deploy
# → docker compose up --build -d
# → certbot --nginx -d ada.ton-domaine.com -m admin@ton-domaine.com
# → nginx -s reload
# → Vérification health checks
```

### Variables d'environnement requises

| Variable | Obligatoire | Description | Exemple |
|----------|-------------|-------------|---------|
| `ANTHROPIC_API_KEY` | oui | Clé API Anthropic | `sk-ant-...` |
| `ADA_JWT_SECRET` | oui | Secret JWT HS256 (min 64 chars) | généré par `openssl rand -hex 32` |
| `ADA_DB_PATH` | non | Chemin sqlite ada-api | `/data/ada-api.db` |
| `ADA_API_PORT` | non | Port ada-api | `3001` |
| `ADA_UI_PORT` | non | Port ada-ui | `7777` |
| `ADA_IPC_PORT` | non | Port IPC TCP | `3099` |
| `ADA_IPC_HMAC_SECRET` | non (recommandé prod) | Secret HMAC-SHA256 pour authentifier les événements IPC entre ada-core et ada-api. Si absent, les événements IPC ne sont pas signés. Activer en production. | généré par `openssl rand -hex 32` |
| `ADA_CORS_ORIGINS` | oui (serveur) | Origins autorisées | `https://ada.ton-domaine.com` |
| `ADA_LOG_LEVEL` | non | Niveau de log Fastify | `info` |
| `NEXT_PUBLIC_API_URL` | oui (ui) | URL ada-api côté client | `https://ada.ton-domaine.com/api` |
| `NEXT_PUBLIC_WS_URL` | oui (ui) | URL WebSocket | `wss://ada.ton-domaine.com/ws` |
| `NODE_ENV` | non | Environnement Node | `production` |

#### Note sécurité — mode server (AUTH_MODE=password)

Le mot de passe est comparé avec `timingSafeEqual` (Node.js `crypto`) — pas de hachage bcrypt. La comparaison est en temps constant pour éviter les timing attacks. Le secret est lu depuis la variable d'environnement `ADA_SERVER_PASSWORD` ; ne jamais le stocker dans le code source.

#### Note sécurité — WebSocket

Les clients ne transmettent **jamais** le JWT dans l'URL WebSocket. Le flux correct est :
1. `GET /api/ws/ticket` (avec `Authorization: Bearer <jwt>`) → ticket one-time-use valide 30s
2. `ws://…/ws?ticket=<uuid>` — le ticket est consommé à la connexion

Configurer Nginx pour proxy le path `/ws` avec les headers `Upgrade` + `Connection` (voir config générée ci-dessus).

### Docker Compose généré

```yaml
# docker-compose.yml — généré par ada server init --remote
version: "3.9"

services:
  ada-core:
    build:
      context: .
      dockerfile: Dockerfile.core
    container_name: ada-core
    restart: unless-stopped
    environment:
      - ANTHROPIC_API_KEY=${ANTHROPIC_API_KEY}
      - ADA_IPC_PORT=${ADA_IPC_PORT:-3099}
      - NODE_ENV=production
    volumes:
      - ada-runs:/data/runs
      - ada-bank:/data/bank
    networks:
      - ada-internal
    healthcheck:
      test: ["CMD", "node", "-e",
             "require('net').createConnection(3099,'127.0.0.1').on('connect',()=>process.exit(0))"]
      interval: 30s
      timeout: 5s
      retries: 3
      start_period: 10s

  ada-api:
    build:
      context: .
      dockerfile: Dockerfile.api
    container_name: ada-api
    restart: unless-stopped
    depends_on:
      ada-core:
        condition: service_healthy
    environment:
      - ADA_IPC_PORT=${ADA_IPC_PORT:-3099}
      - ADA_API_PORT=${ADA_API_PORT:-3001}
      - ADA_DB_PATH=/data/ada-api.db
      - ADA_JWT_SECRET=${ADA_JWT_SECRET}
      - ADA_CORS_ORIGINS=${ADA_CORS_ORIGINS}
      - ADA_LOG_LEVEL=${ADA_LOG_LEVEL:-info}
      - NODE_ENV=production
    ports:
      - "127.0.0.1:3001:3001"
    volumes:
      - ada-db:/data
    networks:
      - ada-internal
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3001/api/health"]
      interval: 30s
      timeout: 5s
      retries: 3
      start_period: 15s

  ada-ui:
    build:
      context: .
      dockerfile: Dockerfile.ui
    container_name: ada-ui
    restart: unless-stopped
    depends_on:
      ada-api:
        condition: service_healthy
    environment:
      - NEXT_PUBLIC_API_URL=${NEXT_PUBLIC_API_URL}
      - NEXT_PUBLIC_WS_URL=${NEXT_PUBLIC_WS_URL}
      - NODE_ENV=production
    ports:
      - "127.0.0.1:7777:7777"
    networks:
      - ada-internal
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:7777"]
      interval: 30s
      timeout: 5s
      retries: 3
      start_period: 20s

volumes:
  ada-runs:
    driver: local
    driver_opts:
      type: none
      o: bind
      device: /opt/ada-data/runs
  ada-bank:
    driver: local
    driver_opts:
      type: none
      o: bind
      device: /opt/ada-data/bank
  ada-db:
    driver: local
    driver_opts:
      type: none
      o: bind
      device: /opt/ada-data/db

networks:
  ada-internal:
    driver: bridge
    internal: false
```

### Nginx config générée

```nginx
# /etc/nginx/sites-available/ada — généré par ada server init --remote
# SSL géré par certbot (modifie ce fichier automatiquement)

upstream ada_api {
    server 127.0.0.1:3001;
    keepalive 64;
}

upstream ada_ui {
    server 127.0.0.1:7777;
    keepalive 32;
}

server {
    listen 80;
    server_name ada.ton-domaine.com;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name ada.ton-domaine.com;

    # SSL — complété par certbot
    ssl_certificate /etc/letsencrypt/live/ada.ton-domaine.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/ada.ton-domaine.com/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256;
    ssl_prefer_server_ciphers off;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 1d;
    add_header Strict-Transport-Security "max-age=63072000" always;

    # Security headers
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header Referrer-Policy strict-origin-when-cross-origin;

    # WebSocket (ada-api /ws)
    location /ws {
        proxy_pass http://ada_api;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 86400;   # 24h — connexions WS longues
        proxy_send_timeout 86400;
    }

    # REST API (ada-api /api)
    location /api {
        proxy_pass http://ada_api;
        proxy_http_version 1.1;
        proxy_set_header Connection "";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 60;
        proxy_connect_timeout 10;

        # Rate limiting
        limit_req zone=api burst=20 nodelay;
        limit_req_status 429;
    }

    # UI (ada-ui, tout le reste)
    location / {
        proxy_pass http://ada_ui;
        proxy_http_version 1.1;
        proxy_set_header Connection "";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 60;

        # Cache Next.js static assets
        location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff2)$ {
            proxy_pass http://ada_ui;
            expires 1y;
            add_header Cache-Control "public, immutable";
        }
    }

    # Logs
    access_log /var/log/nginx/ada.access.log;
    error_log /var/log/nginx/ada.error.log;
}

# Rate limiting zone (dans http block du nginx.conf principal)
# limit_req_zone $binary_remote_addr zone=api:10m rate=30r/m;
```

---

## Mode hybride (ada-core local, ada-api distant)

Cas d'usage : développeur en local, ada-api sur un serveur partagé d'équipe.

```bash
# Côté client local
export ADA_IPC_MODE=tcp
export ADA_IPC_HOST=mon-serveur.com   # ada-core est local → socket Unix
export ADA_API_URL=https://ada-api.mon-serveur.com

ada server start --core-only
# → Démarre uniquement ada-core en local
# → ada-api et ada-ui restent sur le serveur
# → ada-core push events en IPC TCP vers le serveur

# Note : mode hybride nécessite un tunnel SSH ou VPN
# car le port 3099 ne doit jamais être exposé publiquement
ssh -R 3099:127.0.0.1:3099 user@mon-serveur.com
```

---

## Health checks et monitoring

### Endpoints de santé (ada-api)

```
GET /api/health
→ 200 { status: "ok", ts: "...", uptime: 3600 }
→ 503 { status: "degraded", services: { core: "down", db: "ok" } }

GET /api/health/core
→ 200 { connected: true, socket: ".claude/ada-core.sock", activeRuns: 2 }
→ 503 { connected: false, lastSeen: "2026-05-31T09:55:00Z", retrying: true }

GET /api/health/db
→ 200 { ok: true, path: "/data/ada-api.db", sizeBytes: 2048576, walMode: true }
→ 503 { ok: false, error: "SQLITE_BUSY" }
```

### Monitoring recommandé

```bash
# Uptime monitoring simple (Uptime Kuma, Better Uptime)
# URL à surveiller : https://ada.ton-domaine.com/api/health

# Logs Fastify (ada-api) — format JSON structuré
docker logs ada-api --follow | jq 'select(.level >= 40)'

# Métriques basiques
ada server stats
# → runs today: 12 | tokens: 84,231 | avg duration: 4m23s
# → db size: 2.1 MB | events.ndjson: 8.4 MB
```

---

## Backup et restauration

### Backup

```bash
# Backup automatique quotidien (cron)
# 0 2 * * * /opt/ada/scripts/backup.sh

#!/usr/bin/env bash
# scripts/backup.sh
BACKUP_DIR="/opt/ada-backups/$(date +%Y-%m-%d)"
mkdir -p "$BACKUP_DIR"

# ada-api.db : backup en mode WAL (pas besoin d'arrêt)
sqlite3 /opt/ada-data/db/ada-api.db ".backup '$BACKUP_DIR/ada-api.db'"

# events.ndjson : archive compressée
gzip -c /opt/ada-data/runs/.claude/events.ndjson > "$BACKUP_DIR/events.ndjson.gz"

# Rétention 30 jours
find /opt/ada-backups -type d -mtime +30 -exec rm -rf {} +

echo "Backup done: $BACKUP_DIR"
```

### Restauration

```bash
# Arrêter ada-api
ada server stop ada-api
# ou : docker compose stop ada-api

# Restaurer la DB
cp /opt/ada-backups/2026-05-30/ada-api.db /opt/ada-data/db/ada-api.db

# Supprimer le WAL résiduel
rm -f /opt/ada-data/db/ada-api.db-wal
rm -f /opt/ada-data/db/ada-api.db-shm

# Redémarrer (replay events.ndjson automatique si cursor < taille fichier)
ada server start ada-api
```

### Purge des events.ndjson anciens

```bash
# Purger les événements de plus de 30 jours
ada server prune-events --older-than 30d

# Ce que fait la commande :
#   1. Crée events.ndjson.new avec uniquement les événements récents
#   2. Met à jour events.cursor (offset recalculé)
#   3. renameSync(events.ndjson.new, events.ndjson)
```

---

## Mise à jour

### Mise à jour en local

```bash
# Mise à jour complète (git pull + rebuild + restart)
ada server update

# Ce que fait la commande :
#   1. git fetch + git pull (fast-forward uniquement)
#   2. npm install (si package.json changé)
#   3. tsc build (ada-api)
#   4. next build (ada-ui)
#   5. Migrations DB (drizzle-kit push)
#   6. ada server restart (gracieux : attend fin des runs en cours)
```

### Mise à jour en mode serveur

```bash
# Sur le VPS
cd /opt/ada
git pull origin main

# Rebuild + restart sans downtime (rolling update)
docker compose pull
docker compose up --build -d --no-deps ada-api
# → Attend que le nouveau ada-api soit healthy avant de stopper l'ancien

docker compose up --build -d --no-deps ada-ui
```

### Migrations DB (Drizzle)

Ada-api applique les migrations **automatiquement au démarrage** via un runner séquentiel. La table `schema_migrations` trace les migrations déjà appliquées — chaque fichier n'est exécuté qu'une seule fois, dans l'ordre croissant (0001, 0002, …). Aucune intervention manuelle n'est requise en temps normal.

```bash
# En manuel si nécessaire (hors runner automatique)
cd ada-api
npx drizzle-kit push --config drizzle.config.ts
```

En cas d'échec d'une migration au démarrage, ada-api s'arrête avec une erreur explicite — ne pas ignorer ce signal.

---

## Dépannage

### ada-core ne démarre pas

```bash
ada server logs ada-core --last 50
# Cause fréquente : ANTHROPIC_API_KEY absente ou invalide
# Fix : export ANTHROPIC_API_KEY=sk-ant-... && ada server restart ada-core
```

### ada-api ne se connecte pas à ada-core

```bash
# Vérifier le socket
ls -la .claude/ada-core.sock
# Si absent : ada-core n'a pas démarré ou a crashé

# Vérifier les logs IPC
ada server logs ada-api --filter ipc
```

### ada-ui ne charge pas

```bash
# Vérifier que NEXT_PUBLIC_API_URL est correct
grep NEXT_PUBLIC_API_URL .env.local
# Doit pointer vers ada-api accessible depuis le navigateur
```

### Base de données corrompue

```bash
# Vérifier l'intégrité
sqlite3 ~/.claude-<profile>/ada-api.db "PRAGMA integrity_check;"
# Si retourne autre que "ok" : restaurer depuis le backup
```
