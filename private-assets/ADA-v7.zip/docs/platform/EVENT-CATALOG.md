# Event Catalog — ADA Platform v2

> Contrat immuable entre les 3 services. Extension uniquement par ajout.
> Version catalogue: 1.0 | Date: 2026-05-31

---

## Règles d'évolution

1. Un type d'événement défini ici ne change **jamais** de structure (pas de
   renommage de champ, pas de suppression, pas de changement de type).
2. Des champs **optionnels** peuvent être ajoutés à `payload` dans une version
   mineure du catalogue (1.0 → 1.1). Les consommateurs doivent ignorer les
   champs inconnus.
3. Un nouveau type d'événement peut être ajouté dans une version mineure.
4. Une rupture de contrat (changement type, suppression champ) nécessite une
   version majeure (1.0 → 2.0) et une période de dépréciation de 90 jours.
5. Le champ `catalog` dans chaque message indique la version du catalogue
   utilisée par l'émetteur. Les consommateurs rejettent les messages dont la
   version majeure diffère de la leur.

---

## Canal 1 — Ada-Core → Ada-API (IPC Socket / events.ndjson)

Tous les événements de ce canal suivent `IPCMessage` (voir IPC-PROTOCOL.md).

### `run.started`

Émis immédiatement après l'initialisation du run (meta.json écrit).

| Champ payload | Type | Obligatoire | Description |
|--------------|------|-------------|-------------|
| `runId` | string | oui | Identifiant unique du run |
| `profile` | string | oui | Profil routing (ex: "fullstack", "backend-nestjs") |
| `prompt` | string | oui | Prompt utilisateur (tronqué à 500 chars) |
| `phases` | string[] | oui | Liste ordonnée des phases planifiées |
| `initiatedBy` | string | oui | "cli" ou "ada-ui" |
| `workspaceId` | string | non | Si lancé depuis un workspace ada-ui |

```json
{
  "id": "f47ac10b-58cc-4372-a567-0e02b2c3d479",
  "ts": "2026-05-31T10:00:00.000Z",
  "type": "run.started",
  "catalog": "1.0",
  "payload": {
    "runId": "run-2026-05-31-001",
    "profile": "fullstack",
    "prompt": "Ajouter auth JWT au service notifications",
    "phases": ["spec", "implement", "test", "review"],
    "initiatedBy": "ada-ui",
    "workspaceId": "ws-abc123"
  }
}
```

### `run.phase.started`

Émis au début de l'exécution de chaque phase.

| Champ payload | Type | Obligatoire | Description |
|--------------|------|-------------|-------------|
| `runId` | string | oui | Identifiant du run |
| `phase` | string | oui | Nom de la phase |
| `phaseIndex` | number | oui | Index 0-based dans la liste des phases |
| `agentId` | string | oui | Agent sélectionné par le router |
| `model` | string | oui | Modèle Claude utilisé |
| `estimatedTokens` | number | non | Estimation tokens (Thompson prior) |

```json
{
  "id": "a1b2c3d4-...",
  "ts": "2026-05-31T10:00:05.000Z",
  "type": "run.phase.started",
  "catalog": "1.0",
  "payload": {
    "runId": "run-2026-05-31-001",
    "phase": "spec",
    "phaseIndex": 0,
    "agentId": "agent-tdd-london-swarm",
    "model": "claude-sonnet-4-6",
    "estimatedTokens": 8000
  }
}
```

### `run.phase.log`

Émis pour chaque ligne de log produite par une phase. Peut être fréquent (1/s).

| Champ payload | Type | Obligatoire | Description |
|--------------|------|-------------|-------------|
| `runId` | string | oui | Identifiant du run |
| `phase` | string | oui | Nom de la phase |
| `level` | "info" \| "warn" \| "error" | oui | Niveau de log |
| `message` | string | oui | Contenu du log (max 2000 chars) |
| `seq` | number | oui | Numéro de séquence dans la phase (0-based) |

```json
{
  "id": "b2c3d4e5-...",
  "ts": "2026-05-31T10:00:07.500Z",
  "type": "run.phase.log",
  "catalog": "1.0",
  "payload": {
    "runId": "run-2026-05-31-001",
    "phase": "spec",
    "level": "info",
    "message": "Generating OpenAPI spec for /auth/jwt endpoint...",
    "seq": 3
  }
}
```

### `run.phase.done`

Émis après la fin réussie d'une phase (renameSync effectué).

| Champ payload | Type | Obligatoire | Description |
|--------------|------|-------------|-------------|
| `runId` | string | oui | Identifiant du run |
| `phase` | string | oui | Nom de la phase |
| `phaseIndex` | number | oui | Index 0-based |
| `agentId` | string | oui | Agent ayant exécuté la phase |
| `durationMs` | number | oui | Durée d'exécution en millisecondes |
| `tokensUsed` | number | oui | Tokens consommés |
| `outputPath` | string | oui | Chemin relatif du fichier résultat |
| `score` | number | non | Score qualité 0-1 (si disponible) |

```json
{
  "id": "c3d4e5f6-...",
  "ts": "2026-05-31T10:00:42.831Z",
  "type": "run.phase.done",
  "catalog": "1.0",
  "payload": {
    "runId": "run-2026-05-31-001",
    "phase": "spec",
    "phaseIndex": 0,
    "agentId": "agent-tdd-london-swarm",
    "durationMs": 37831,
    "tokensUsed": 6234,
    "outputPath": ".claude/runs/run-2026-05-31-001/phases/spec.md",
    "score": 0.87
  }
}
```

### `run.done`

Émis quand toutes les phases sont terminées avec succès.

| Champ payload | Type | Obligatoire | Description |
|--------------|------|-------------|-------------|
| `runId` | string | oui | Identifiant du run |
| `profile` | string | oui | Profil utilisé |
| `totalDurationMs` | number | oui | Durée totale du run |
| `totalTokensUsed` | number | oui | Total tokens toutes phases |
| `phasesCompleted` | number | oui | Nombre de phases complétées |
| `outputDir` | string | oui | Répertoire des résultats |

```json
{
  "id": "d4e5f6a7-...",
  "ts": "2026-05-31T10:05:15.000Z",
  "type": "run.done",
  "catalog": "1.0",
  "payload": {
    "runId": "run-2026-05-31-001",
    "profile": "fullstack",
    "totalDurationMs": 315000,
    "totalTokensUsed": 28431,
    "phasesCompleted": 4,
    "outputDir": ".claude/runs/run-2026-05-31-001"
  }
}
```

### `run.cancelled`

Émis quand un run est annulé (SIGTERM ou commande cancel).

| Champ payload | Type | Obligatoire | Description |
|--------------|------|-------------|-------------|
| `runId` | string | oui | Identifiant du run |
| `reason` | string | oui | "user_cancel", "timeout", "error" |
| `lastPhase` | string | non | Dernière phase démarrée |
| `message` | string | non | Message d'erreur si reason="error" |

```json
{
  "id": "e5f6a7b8-...",
  "ts": "2026-05-31T10:02:00.000Z",
  "type": "run.cancelled",
  "catalog": "1.0",
  "payload": {
    "runId": "run-2026-05-31-001",
    "reason": "user_cancel",
    "lastPhase": "implement"
  }
}
```

### `bank.stored`

Émis après qu'une leçon est stockée dans le ReasoningBank.

| Champ payload | Type | Obligatoire | Description |
|--------------|------|-------------|-------------|
| `bankId` | string | oui | ID de la leçon en DB |
| `runId` | string | oui | Run source |
| `phase` | string | oui | Phase source |
| `type` | string | oui | Type de leçon (ex: "pattern", "anti-pattern") |
| `tags` | string[] | oui | Tags pour la récupération |

```json
{
  "id": "f6a7b8c9-...",
  "ts": "2026-05-31T10:05:16.000Z",
  "type": "bank.stored",
  "catalog": "1.0",
  "payload": {
    "bankId": "lesson-001",
    "runId": "run-2026-05-31-001",
    "phase": "review",
    "type": "pattern",
    "tags": ["nestjs", "jwt", "auth"]
  }
}
```

### `router.updated`

Émis après mise à jour des priors Thompson Sampling.

| Champ payload | Type | Obligatoire | Description |
|--------------|------|-------------|-------------|
| `profile` | string | oui | Profil mis à jour |
| `phase` | string | oui | Phase concernée |
| `agentId` | string | oui | Agent mis à jour |
| `newScore` | number | oui | Nouveau score (alpha/(alpha+beta)) |

```json
{
  "id": "a7b8c9d0-...",
  "ts": "2026-05-31T10:05:17.000Z",
  "type": "router.updated",
  "catalog": "1.0",
  "payload": {
    "profile": "fullstack",
    "phase": "implement",
    "agentId": "agent-coder",
    "newScore": 0.73
  }
}
```

### `daemon.worker.started` / `daemon.worker.done`

Émis par le scheduler daemon pour les tâches planifiées.

```json
{
  "id": "b8c9d0e1-...",
  "ts": "2026-05-31T10:10:00.000Z",
  "type": "daemon.worker.started",
  "catalog": "1.0",
  "payload": {
    "workerId": "worker-abc",
    "task": "bank-consolidation",
    "scheduledAt": "2026-05-31T10:10:00.000Z"
  }
}
```

---

## Canal 2 — Ada-API → Ada-UI (WebSocket)

Les événements WebSocket suivent une structure légèrement différente :
le champ `room` indique les clients ciblés.

```typescript
interface WSEvent {
  type: string;
  payload: Record<string, unknown>;
  room?: string;    // si absent : broadcast global
  requestId?: string; // echo de l'id de la commande déclenchante
}
```

### `run.started`

| Champ payload | Type | Description |
|--------------|------|-------------|
| `runId` | string | Identifiant du run |
| `profile` | string | Profil routing |
| `phases` | string[] | Phases planifiées |
| `conversationId` | string | Conversation associée dans ada-api |

Room : `run:{runId}` + `conversation:{conversationId}`

### `phase.started`

| Champ payload | Type | Description |
|--------------|------|-------------|
| `runId` | string | Identifiant du run |
| `phase` | string | Nom de la phase |
| `agentId` | string | Agent sélectionné |
| `model` | string | Modèle utilisé |

Room : `run:{runId}`

### `phase.progress`

Équivalent de `run.phase.log` côté UI. Émis pour chaque log.

| Champ payload | Type | Description |
|--------------|------|-------------|
| `runId` | string | Identifiant du run |
| `phase` | string | Nom de la phase |
| `level` | string | Niveau de log |
| `message` | string | Contenu |
| `seq` | number | Séquence |

Room : `run:{runId}`

### `phase.done`

| Champ payload | Type | Description |
|--------------|------|-------------|
| `runId` | string | Identifiant du run |
| `phase` | string | Nom de la phase |
| `durationMs` | number | Durée |
| `tokensUsed` | number | Tokens |
| `outputUrl` | string | URL REST pour lire le résultat |

Room : `run:{runId}`

### `run.done`

| Champ payload | Type | Description |
|--------------|------|-------------|
| `runId` | string | Identifiant du run |
| `totalDurationMs` | number | Durée totale |
| `totalTokensUsed` | number | Tokens totaux |
| `phasesCompleted` | number | Phases complétées |

Room : `run:{runId}` + `conversation:{conversationId}`

### `run.cancelled`

| Champ payload | Type | Description |
|--------------|------|-------------|
| `runId` | string | Identifiant du run |
| `reason` | string | Raison |
| `message` | string | Message optionnel |

Room : `run:{runId}`

### `message.new`

Nouveau message dans une conversation (réponse assistant ou system).

| Champ payload | Type | Description |
|--------------|------|-------------|
| `conversationId` | string | ID conversation |
| `messageId` | string | ID message |
| `role` | "assistant" \| "system" | Rôle |
| `content` | string | Contenu |
| `runId` | string \| null | Run associé si applicable |

Room : `conversation:{conversationId}`

### `conversation.updated`

| Champ payload | Type | Description |
|--------------|------|-------------|
| `conversationId` | string | ID conversation |
| `title` | string | Nouveau titre |
| `updatedAt` | string | Timestamp ISO 8601 |

Room : `workspace:{workspaceId}`

### `workspace.updated`

| Champ payload | Type | Description |
|--------------|------|-------------|
| `workspaceId` | string | ID workspace |
| `name` | string | Nom du workspace |
| `updatedAt` | string | Timestamp |

Room : `user:{userId}`

### `notification`

Notification générale (erreur, info, warning).

| Champ payload | Type | Description |
|--------------|------|-------------|
| `level` | "info" \| "warn" \| "error" | Niveau |
| `message` | string | Message |
| `action` | object \| null | Action suggérée { label, href } |

Room : broadcast ou `user:{userId}`

### `heartbeat`

Envoyé par ada-api toutes les 30 secondes pour maintenir les connexions WS.

| Champ payload | Type | Description |
|--------------|------|-------------|
| `ts` | string | Timestamp serveur |
| `activeRuns` | number | Runs en cours |

Room : broadcast

---

## Canal 3 — Ada-UI → Ada-API (REST + WebSocket commands)

### `run.spawn` — POST /api/runs

Lance un nouveau run ada-core.

**Body** :
```json
{
  "prompt": "Ajouter auth JWT",
  "profile": "fullstack",
  "conversationId": "conv-abc123",
  "workspaceId": "ws-xyz456",
  "options": {
    "headless": true,
    "maxPhases": 4
  }
}
```

**Réponse 202** :
```json
{
  "runId": "run-2026-05-31-001",
  "status": "starting",
  "wsRoom": "run:run-2026-05-31-001"
}
```

### `run.cancel` — DELETE /api/runs/:runId

Annule un run en cours (SIGTERM au processus ada-core).

**Réponse 200** :
```json
{ "runId": "run-2026-05-31-001", "status": "cancelling" }
```

### `run.retry` — POST /api/runs/:runId/retry

Relance un run depuis la dernière phase échouée.

**Body** :
```json
{
  "fromPhase": "implement",
  "conversationId": "conv-abc123"
}
```

**Réponse 202** :
```json
{
  "runId": "run-2026-05-31-002",
  "retriedFrom": "run-2026-05-31-001",
  "status": "starting"
}
```

### `message.send` — POST /api/conversations/:conversationId/messages

Envoie un message utilisateur dans une conversation.

**Body** :
```json
{
  "role": "user",
  "content": "Peux-tu ajouter des tests pour le cas edge ?",
  "attachments": []
}
```

**Réponse 201** :
```json
{
  "messageId": "msg-001",
  "conversationId": "conv-abc123",
  "role": "user",
  "content": "...",
  "createdAt": "2026-05-31T10:00:00.000Z"
}
```

### `conversation.create` — POST /api/conversations

Crée une nouvelle conversation.

**Body** :
```json
{
  "workspaceId": "ws-xyz456",
  "title": "Auth JWT notifications",
  "profile": "fullstack"
}
```

**Réponse 201** :
```json
{
  "conversationId": "conv-abc123",
  "workspaceId": "ws-xyz456",
  "title": "Auth JWT notifications",
  "createdAt": "2026-05-31T10:00:00.000Z"
}
```

### `workspace.create` — POST /api/workspaces

Crée un nouveau workspace.

**Body** :
```json
{
  "name": "Projet ADA Platform",
  "profile": "fullstack",
  "description": "Workspace pour le dev de ada-api et ada-ui"
}
```

**Réponse 201** :
```json
{
  "workspaceId": "ws-xyz456",
  "name": "Projet ADA Platform",
  "createdAt": "2026-05-31T10:00:00.000Z"
}
```

---

## Types TypeScript partagés

Copier dans `ada-api/src/contracts/events.ts` et `ada-ui/src/contracts/events.ts`.

```typescript
// ============================================================
// ADA Platform v2 — Shared Event Contracts
// Version catalogue: 1.0
// NE PAS MODIFIER les types existants — extension uniquement
// ============================================================

export const CATALOG_VERSION = "1.0" as const;

// ─── IPC Messages (ada-core → ada-api) ─────────────────────

export interface IPCMessage<T = Record<string, unknown>> {
  id: string;
  ts: string;
  type: string;
  catalog?: string;
  payload: T;
}

export interface RunStartedPayload {
  runId: string;
  profile: string;
  prompt: string;
  phases: string[];
  initiatedBy: "cli" | "ada-ui";
  workspaceId?: string;
}

export interface RunPhaseStartedPayload {
  runId: string;
  phase: string;
  phaseIndex: number;
  agentId: string;
  model: string;
  estimatedTokens?: number;
}

export interface RunPhaseLogPayload {
  runId: string;
  phase: string;
  level: "info" | "warn" | "error";
  message: string;
  seq: number;
}

export interface RunPhaseDonePayload {
  runId: string;
  phase: string;
  phaseIndex: number;
  agentId: string;
  durationMs: number;
  tokensUsed: number;
  outputPath: string;
  score?: number;
}

export interface RunDonePayload {
  runId: string;
  profile: string;
  totalDurationMs: number;
  totalTokensUsed: number;
  phasesCompleted: number;
  outputDir: string;
}

export interface RunCancelledPayload {
  runId: string;
  reason: "user_cancel" | "timeout" | "error";
  lastPhase?: string;
  message?: string;
}

export interface BankStoredPayload {
  bankId: string;
  runId: string;
  phase: string;
  type: string;
  tags: string[];
}

export interface RouterUpdatedPayload {
  profile: string;
  phase: string;
  agentId: string;
  newScore: number;
}

// ─── WebSocket Events (ada-api → ada-ui) ───────────────────

export interface WSEvent<T = Record<string, unknown>> {
  type: string;
  payload: T;
  room?: string;
  requestId?: string;
}

export type WSRunStarted = WSEvent<{
  runId: string;
  profile: string;
  phases: string[];
  conversationId: string;
}>;

export type WSPhaseStarted = WSEvent<{
  runId: string;
  phase: string;
  agentId: string;
  model: string;
}>;

export type WSPhaseProgress = WSEvent<{
  runId: string;
  phase: string;
  level: "info" | "warn" | "error";
  message: string;
  seq: number;
}>;

export type WSPhaseDone = WSEvent<{
  runId: string;
  phase: string;
  durationMs: number;
  tokensUsed: number;
  outputUrl: string;
}>;

export type WSRunDone = WSEvent<{
  runId: string;
  totalDurationMs: number;
  totalTokensUsed: number;
  phasesCompleted: number;
}>;

export type WSRunCancelled = WSEvent<{
  runId: string;
  reason: string;
  message?: string;
}>;

export type WSMessageNew = WSEvent<{
  conversationId: string;
  messageId: string;
  role: "assistant" | "system";
  content: string;
  runId: string | null;
}>;

export type WSNotification = WSEvent<{
  level: "info" | "warn" | "error";
  message: string;
  action?: { label: string; href: string } | null;
}>;

export type WSHeartbeat = WSEvent<{
  ts: string;
  activeRuns: number;
}>;

// ─── REST Payloads (ada-ui → ada-api) ──────────────────────

export interface SpawnRunBody {
  prompt: string;
  profile: string;
  conversationId: string;
  workspaceId?: string;
  options?: {
    headless?: boolean;
    maxPhases?: number;
  };
}

export interface SendMessageBody {
  role: "user";
  content: string;
  attachments?: string[];
}

export interface CreateConversationBody {
  workspaceId: string;
  title: string;
  profile: string;
}

export interface CreateWorkspaceBody {
  name: string;
  profile: string;
  description?: string;
}

// ─── IPC Event Type Union ───────────────────────────────────

export type CoreEventType =
  | "run.started"
  | "run.phase.started"
  | "run.phase.log"
  | "run.phase.done"
  | "run.done"
  | "run.cancelled"
  | "bank.stored"
  | "router.updated"
  | "daemon.worker.started"
  | "daemon.worker.done"
  | "sys.hello"
  | "sys.ack"
  | "sys.heartbeat"
  | "sys.ping"
  | "sys.pong";

export type ApiEventType =
  | "run.started"
  | "phase.started"
  | "phase.progress"
  | "phase.done"
  | "run.done"
  | "run.cancelled"
  | "message.new"
  | "conversation.updated"
  | "workspace.updated"
  | "notification"
  | "heartbeat";
```
