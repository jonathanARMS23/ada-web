# IPC Protocol — Ada-Core ↔ Ada-API

> Protocole de communication inter-process entre ada-core et ada-api.
> Version: 1.0 | Date: 2026-05-31

---

## Principe

Ada-core émet des événements **après** chaque write atomique (`renameSync`).
Cette garantie évite toute race condition : quand l'événement arrive dans
ada-api, le fichier est déjà lisible et cohérent sur le filesystem.

```
ada-core                              ada-api
   │                                     │
   │  1. fs.renameSync(tmp, dest)        │
   │     ← garantie atomique POSIX       │
   │                                     │
   │  2. emitIPC(event)                  │
   │  ─────────────────────────────────► │
   │                                     │  3. parse + upsert DB
   │  3b. append events.ndjson           │  4. broadcast WebSocket
   │     ← log de secours               │
```

**Direction** : ada-core → ada-api uniquement sur ce canal (unidirectionnel).

**Direction inverse** (ada-ui → ada-api → ada-core) : spawn de processus CLI
(`child_process.spawn("node", ["run.js", "next", runId, "--headless"])`).
Jamais de write-back sur le socket IPC.

---

## Transport

### Mode local

```
Transport : Unix Domain Socket
Chemin    : .claude/ada-core.sock
            (résolu depuis $ADA_CLAUDE_DIR ou ~/.claude par défaut)
Format    : NDJSON — une ligne JSON par événement, délimiteur \n
Encoding  : UTF-8
```

### Mode serveur

```
Transport : TCP loopback
Adresse   : 127.0.0.1:3099
            (configurable via $ADA_IPC_PORT, jamais exposé en dehors du host)
Format    : identique NDJSON
Encoding  : UTF-8
```

### Sélection automatique par ada-api

```typescript
// ada-api/src/ipc/transport.ts
async function resolveTransport(): Promise<net.Socket> {
  const sockPath = path.join(adaClaudeDir(), "ada-core.sock");

  if (fs.existsSync(sockPath)) {
    // Mode local : Unix socket
    return net.createConnection(sockPath);
  }

  const port = parseInt(process.env.ADA_IPC_PORT ?? "3099");
  // Mode serveur : TCP loopback
  return net.createConnection(port, "127.0.0.1");
}
```

---

## Protocole de connexion

### Handshake initial

À la connexion, ada-api envoie immédiatement un message `HELLO` :

```json
{
  "id": "a1b2c3d4-e5f6-...",
  "ts": "2026-05-31T10:00:00.000Z",
  "type": "sys.hello",
  "payload": {
    "client": "ada-api",
    "version": "2.0.0",
    "catalog": "1.0",
    "cursor_offset": 4821
  }
}
```

Ada-core répond avec `ACK` :

```json
{
  "id": "b2c3d4e5-f6a7-...",
  "ts": "2026-05-31T10:00:00.001Z",
  "type": "sys.ack",
  "payload": {
    "server": "ada-core",
    "version": "2.0.0",
    "catalog": "1.0",
    "cursor_offset_received": 4821
  }
}
```

Le champ `cursor_offset` permet à ada-core de savoir à partir de quel offset
ada-api a déjà traité les événements NDJSON. Si ada-api redémarre, il envoie
son dernier cursor connu. Ada-core peut alors détecter les trous et déclencher
un replay (optionnel en v2, manuel via commande admin).

### Reconnexion automatique

Ada-api est responsable de maintenir la connexion :

```
Tentative 1  → attente 1 000 ms
Tentative 2  → attente 2 000 ms
Tentative 3  → attente 4 000 ms
Tentative 4  → attente 8 000 ms
Tentative 5+ → attente 30 000 ms (plafond)
```

Pendant la reconnexion, le fallback `events.ndjson` est activé automatiquement
(voir section Event Log ci-dessous).

Ada-api log chaque tentative avec le niveau `warn` et envoie un event WebSocket
`notification` aux clients connectés :

```json
{
  "type": "notification",
  "payload": {
    "level": "warn",
    "message": "ada-core IPC disconnected, reconnecting...",
    "retryIn": 4000
  }
}
```

---

## Format des messages

Tous les messages (dans les deux sens, y compris HELLO/ACK et events) suivent
cette structure :

```typescript
interface IPCMessage {
  /** UUID v4 — identifiant unique de cet événement */
  id: string;

  /** Horodatage ISO 8601 avec millisecondes, timezone UTC */
  ts: string;

  /** Type d'événement — voir Event Catalog */
  type: string;

  /** Payload structuré — dépend du type */
  payload: Record<string, unknown>;

  /** Version du catalogue des événements */
  catalog?: string;
}
```

**Exemples concrets** :

```json
{
  "id": "f47ac10b-58cc-4372-a567-0e02b2c3d479",
  "ts": "2026-05-31T10:15:42.831Z",
  "type": "run.phase.done",
  "catalog": "1.0",
  "payload": {
    "runId": "run-2026-05-31-001",
    "phase": "implement",
    "agentId": "agent-coder",
    "durationMs": 12340,
    "tokenUsed": 4821,
    "outputPath": ".claude/runs/run-2026-05-31-001/phases/implement.md"
  }
}
```

```json
{
  "id": "a1b2c3d4-0000-4000-8000-000000000001",
  "ts": "2026-05-31T10:15:30.000Z",
  "type": "run.started",
  "catalog": "1.0",
  "payload": {
    "runId": "run-2026-05-31-001",
    "profile": "fullstack",
    "prompt": "Ajouter auth JWT au service notifications",
    "phases": ["spec", "implement", "test", "review"],
    "initiatedBy": "ada-ui"
  }
}
```

---

## Gestion des erreurs

| Situation | Comportement ada-api |
|-----------|---------------------|
| Ligne JSON malformée | `log.warn("IPC parse error", { raw, error })` · skip la ligne · continuer |
| Payload invalide (champ manquant) | `log.warn("IPC payload invalid", { type, missing })` · skip · continuer |
| `type` inconnu | `log.info("IPC unknown type", { type })` · skip · continuer (forward-compat) |
| Socket close inattendue | Reconnexion backoff · activer fallback NDJSON |
| Socket timeout (>30s sans message) | Envoyer `sys.ping` · si pas de `sys.pong` dans 5s → reconnect |
| Erreur DB upsert | `log.error(...)` · l'événement n'est PAS perdu (cursor non avancé) · retry |

**Principe cardinal** : ada-api ne crash jamais à cause d'un message IPC
malformé. Les erreurs sont loguées et le stream continue.

---

## Heartbeat

Ada-core émet un `sys.heartbeat` toutes les 30 secondes si aucun autre
événement n'a été émis. Cela permet à ada-api de détecter une déconnexion
silencieuse (socket zombie).

```json
{
  "id": "...",
  "ts": "2026-05-31T10:16:00.000Z",
  "type": "sys.heartbeat",
  "payload": {
    "uptime": 1800,
    "activeRuns": 2
  }
}
```

Si ada-api ne reçoit rien pendant 90 secondes, il considère la connexion morte
et déclenche une reconnexion.

---

## Event Log (fallback)

### Écriture par ada-core

```
Fichier     : .claude/events.ndjson
Mode        : append-only, jamais de modification ou suppression
Format      : 1 IPCMessage JSON par ligne, délimiteur \n
Flush       : fsync après chaque événement critique (run.started, run.done)
Rotation    : manuelle via `ada server prune-events --older-than 30d`
```

Chaque événement est écrit dans NDJSON **simultanément** à l'envoi IPC socket,
pas seulement en cas de fallback. Le NDJSON est toujours complet.

### Lecture par ada-api

```
Cursor      : .claude/events.cursor
Format      : JSON { "offset": 4821, "ts": "2026-05-31T..." }
Mise à jour : après chaque batch traité (tous les 100 événements ou 1s)
```

**Séquence de démarrage ada-api** :

```
1. Lire events.cursor → offset = N (ou 0 si absent)
2. Ouvrir events.ndjson en lecture
3. Seek(N) dans le fichier
4. Lire ligne par ligne jusqu'à EOF
   a. parse IPCMessage
   b. db.upsert (INSERT OR IGNORE sur id → idempotent)
   c. cursor += bytesRead
5. Sauvegarder events.cursor { offset: finalOffset }
6. Tenter connexion socket IPC
7. Si socket OK → streaming temps réel (cursor continue d'avancer)
8. Si socket KO → FSWatcher sur events.ndjson (polling toutes les 500ms)
```

**Idempotence** : les événements ont un `id` uuid v4. La DB utilise
`INSERT OR IGNORE` sur `(id)` comme clé primaire. Un replay ne crée jamais
de doublons.

---

## Séquence de démarrage complète

```
Utilisateur        ada server start        ada-core           ada-api
     │                    │                    │                  │
     │  ada server start  │                    │                  │
     │ ─────────────────► │                    │                  │
     │                    │  spawn ada-core     │                  │
     │                    │  --daemon           │                  │
     │                    │ ───────────────────►│                  │
     │                    │                    │ crée socket       │
     │                    │                    │ .ada-core.sock    │
     │                    │  socket ready ✓    │                  │
     │                    │ ◄─────────────────── │                  │
     │                    │                    │                  │
     │                    │  spawn ada-api      │                  │
     │                    │ ──────────────────────────────────────►│
     │                    │                    │                  │ lit cursor
     │                    │                    │                  │ replay NDJSON
     │                    │                    │  net.connect()   │
     │                    │                    │ ◄────────────────│
     │                    │                    │  HELLO {cursor}  │
     │                    │                    │ ◄────────────────│
     │                    │                    │  ACK             │
     │                    │                    │ ─────────────────►│
     │                    │  /api/health 200 ✓ │                  │
     │                    │ ◄──────────────────────────────────────│
     │                    │                    │                  │
     │                    │  spawn ada-ui      │                  │
     │  UI ready :7777    │                    │                  │
     │ ◄───────────────── │                    │                  │
```

---

## Sécurité

- Le socket Unix est créé avec permissions `0600` (lecture/écriture propriétaire uniquement)
- Le TCP mode serveur écoute sur `127.0.0.1` uniquement (loopback, jamais `0.0.0.0`)
- Pas d'authentification sur le canal IPC lui-même (isolation par OS/réseau)
- Les données sensibles (tokens, clés API) ne transitent jamais dans les événements IPC
- Le fichier `events.ndjson` est lisible uniquement par le propriétaire (mode `0600`)
