# SmartRetrieval — Pipeline ACW v2

> Documentation technique du pipeline de recherche sémantique utilisé dans l'Adaptive Context Window (ACW) depuis v7.0.0.

## Vue d'ensemble

L'ACW (Adaptive Context Window) injecte les 5 trajectoires les plus pertinentes dans le prompt avant chaque spawn d'agent. Depuis v7.0.0, la sélection utilise un pipeline de re-ranking en 4 étapes au lieu d'un simple TF-IDF.

```
taskDescription
    │
    1. bank.retrieve(limit=10)      — candidats TF-IDF+BM25 depuis SQLite
    │
    2. expandQuery(maxVariants=3)   — génère 3 reformulations de la requête
    │
    3. searchBM25 × 3               — BM25 scoring par variante
    │
    4. reciprocalRankFusion(k=60)   — fusion des 3 listes + boost recency
    │
    5. maximalMarginalRelevance(λ=0.6, topK=5)  — sélection diverse
    │
    phase.acwContext → prompt agent
```

## Étape 1 — Candidats initiaux

```javascript
// run.js:565
const rawTrajectories = bank.retrieve(taskDescription, { limit: 10 })
// Timeout guard : si > 2s → skip ACW, log warning
```

`bank.retrieve()` applique déjà un pipeline interne :
1. SQLite scan (cap 500 trajectoires — `RETRIEVE_CAP`)
2. HNSW pre-sélection si > 20 candidats et requête > 3 tokens
3. TF-IDF scoring
4. BM25 re-ranking sur les résultats TF-IDF (si ≥ 5 résultats)

## Étape 2 — Expansion de requête

```javascript
// embeddings.js
expandQuery(query, { phase: phaseId, maxVariants: 3 })
// Retourne : [query_original, variant_1, variant_2, variant_3]
```

Génère des variantes sémantiques en :
- Synonymes techniques du domaine (nestjs → express, module, controller)
- Reformulations (imperative/passive voice)
- Tokens de contexte phase (phaseId injecté comme signal)

## Étape 3 — BM25 × 3

```javascript
const summaries = rawTrajectories.map(t => `${t.phase} ${t.agent} ${t.summary}`)
const rankedLists = variants.map(v => searchBM25(v, summaries, { limit: summaries.length }))
```

BM25 (Best Match 25) paramètres : k1=1.5, b=0.75 (standard TREC).

Chaque variante produit un ranking indépendant → 3 listes ranked.

## Étape 4 — Reciprocal Rank Fusion

```javascript
reciprocalRankFusion(rankedLists, 60, { recency: true, tsMap })
// score_RRF(doc) = Σ_i  1 / (k + rank_i(doc))
// k=60 réduit l'impact des rangs extrêmes
```

Options :
- `recency: true` : boost proportionnel à l'âge (1/log(jours+2))
- `tsMap` : Map id→timestamp pour le calcul de recency

## Étape 5 — Maximal Marginal Relevance

```javascript
maximalMarginalRelevance(candidates, queryTokens, { lambda: 0.6, topK: 5 })
// score_MMR = λ × sim(doc, query) - (1-λ) × max_j∈S sim(doc, s_j)
```

λ=0.6 : 60% pertinence, 40% diversité. Évite d'injecter 5 trajectoires quasi-identiques sur le même problème.

## Injection dans le prompt

```javascript
phase.acwContext = {
  trajectories: filtered.map(t => ({ id, verdict, summary, duration })),
  lesson,        // micro-lessons.js si disponible
  summary,       // "Similar past runs: [id1, id2] | avg success: 100% | avg duration: 3min"
  injected: true
}
```

Le contenu est injecté en YAML dans le prompt de l'agent avant spawn.

## Performance

| Métrique | Avant (TF-IDF) | Après (SmartRetrieval) |
|---------|----------------|------------------------|
| Candidats scannés | 5000 (MAX_TRAJECTORIES) | 500 (RETRIEVE_CAP) |
| Requêtes BM25 | 1 | 3 (expand × 3) |
| Diversité résultats | faible | haute (MMR λ=0.6) |
| Timeout guard | aucun | 2s hard cap |

## Fichiers source

| Fichier | Rôle |
|---------|------|
| `coordinator/run.js:522` | Fonction `smartSearch()` + bloc ACW |
| `coordinator/embeddings.js` | `expandQuery`, `searchBM25`, `reciprocalRankFusion`, `maximalMarginalRelevance` |
| `coordinator/bank.js:1692` | `retrieve()` avec HNSW pre-sélection |
