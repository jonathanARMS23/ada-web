# TDD Specifications — ADA Platform v2

## Philosophie

Ces specs définissent le COMPORTEMENT attendu, pas l'implémentation.
Chaque spec est un test qui doit passer avant que la feature soit considérée complète.
Format : GIVEN (contexte) / WHEN (action) / THEN (résultat attendu)

Un test passe quand TOUS ses THEN sont vérifiés sans exception.
Une feature est "done" quand toutes ses specs passent en CI.

## Stack de test

| Couche | Outil | Usage |
|--------|-------|-------|
| Runner | Vitest 1.x | Exécution, coverage, watch mode |
| REST | supertest | Requêtes HTTP sur serveur Fastify en test |
| WebSocket | ws (client) | Tests connexion / messages WS |
| IPC mock | net (Node built-in) | Unix socket mock pour simuler ada-core |
| DB | better-sqlite3 in-memory | `:memory:` par suite, reset entre tests |
| Mocks | vi.mock / vi.spyOn | Isolation des dépendances externes |

## Organisation

### Suites de tests

| Suite | Fichier spec | Fichier test | Priorité | Description |
|-------|-------------|--------------|----------|-------------|
| IPC Consumer | specs/ipc-consumer.spec.md | src/ipc/__tests__/ipc-consumer.test.ts | P0 | Réception events ada-core |
| Auth | specs/auth.spec.md | src/auth/__tests__/auth.test.ts | P0 | JWT + sessions |
| Workspaces | specs/workspaces.spec.md | src/workspaces/__tests__/workspaces.test.ts | P0 | CRUD workspaces |
| Conversations | specs/conversations.spec.md | src/conversations/__tests__/conversations.test.ts | P0 | CRUD + messages |
| Runs | specs/runs.spec.md | src/runs/__tests__/runs.test.ts | P0 | Spawn + suivi runs |
| WebSocket | specs/websocket.spec.md | src/ws/__tests__/websocket.test.ts | P0 | Events temps réel |
| Health | specs/health.spec.md | src/health/__tests__/health.test.ts | P1 | Status services |
| Integration | specs/integration.spec.md | src/__tests__/integration.test.ts | P1 | Flux end-to-end |

### Conventions de nommage

```
SPEC XX — Description courte
  GIVEN  ...
  AND    ...          (conditions supplémentaires)
  WHEN   ...
  THEN   ...
  AND    ...          (assertions supplémentaires)
```

Les specs numérotées `I-XX` appartiennent aux tests d'intégration.
Les specs sont indépendantes : chaque GIVEN recrée un contexte propre.

## Ordre d'implémentation TDD

L'ordre respecte les dépendances entre couches (bottom-up) :

```
1. DB Schema       → migrations Drizzle, vérification colonnes, contraintes FK
2. IPC Consumer    → coeur du système, reception events ada-core
3. Auth            → JWT, sessions, middleware protect
4. Workspaces CRUD → entité racine du modèle métier
5. Conversations   → messages, pagination cursor
6. Runs API        → spawn, statut, annulation
7. WebSocket       → rooms, broadcast, heartbeat
8. Integration     → flux complets cross-couches
```

Chaque étape : écrire le test → voir FAIL → implémenter → voir PASS → refactor.

## Contrats inter-services

### ada-api ↔ ada-core (IPC)

Messages entrants (ada-core → ada-api) :

```typescript
type IPCEvent =
  | { type: "run.started";    runId: string; pipeline: string; payload: Record<string, unknown> }
  | { type: "run.phase.started"; runId: string; phaseId: string }
  | { type: "run.phase.log";  runId: string; phaseId: string; line: string }
  | { type: "run.phase.done"; runId: string; phaseId: string; status: "success" | "failed" }
  | { type: "run.done";       runId: string; status: "completed" | "failed"; totalCost: number; summary: string }
```

Messages sortants (ada-api → ada-core) :

```typescript
type IPCCommand =
  | { type: "hello";    version: string; service: "ada-api" }
  | { type: "run.spawn"; runId: string; pipeline: string; args: string[]; workspaceId: string }
  | { type: "run.cancel"; runId: string }
```

### ada-api ↔ UI (WebSocket)

Messages serveur → client :

```typescript
type WSServerEvent =
  | { type: "connected";        workspaceId: null; ts: string }
  | { type: "workspace.joined"; workspaceId: string }
  | { type: "heartbeat";        ts: string }
  | { type: "message.new";      conversationId: string; message: Message }
  | { type: "phase.progress";   runId: string; phaseId: string; log: string; ts: string }
  | { type: "phase.started";    runId: string; phaseId: string }
  | { type: "run.done";         runId: string; cost: number; summary: string }
  | { type: "run.cancelled";    runId: string }
  | { type: "run.started";      runId: string; pipeline: string }
```

Messages client → serveur :

```typescript
type WSClientMessage =
  | { type: "workspace.join"; payload: { workspaceId: string } }
  | { type: "run.spawn";      payload: { pipeline: string; args: string[]; conversationId: string } }
```

## Variables d'environnement référencées

| Variable | Défaut | Description |
|----------|--------|-------------|
| `ADA_IPC_MODE` | `unix` | Mode IPC : `unix` ou `tcp` |
| `ADA_IPC_SOCKET` | `.claude/ada-core.sock` | Chemin Unix socket |
| `ADA_IPC_PORT` | `3099` | Port TCP fallback |
| `ADA_AUTH_MODE` | `local` | Mode auth : `local` ou `server` |
| `ADA_AUTH_PASSWORD` | — | Password requis si mode `server` |
| `ADA_JWT_SECRET` | auto-généré | Secret de signature JWT |
| `ADA_JWT_TTL` | `7d` | Durée de vie des tokens |
| `ADA_WS_HEARTBEAT_INTERVAL` | `30000` | Intervalle heartbeat WS (ms) |
| `ADA_DB_PATH` | `.ada/ada-api.db` | Chemin SQLite |
| `DATABASE_URL` | — | Override DB (`:memory:` en test) |
