# Spec : Authentification

Service : `src/auth/`
Endpoints : POST /api/auth/token · POST /api/auth/refresh · DELETE /api/auth/session
Middleware : `authMiddleware` appliqué sur toutes les routes /api/** sauf /api/auth/token et /api/health

---

## SUITE : Génération de token

---

SPEC 01 — Mode local : token auto-généré sans password
  GIVEN  ADA_AUTH_MODE=local (valeur par défaut si non défini)
  AND    ADA_JWT_SECRET est défini ou auto-généré au démarrage
  WHEN   POST /api/auth/token avec body vide {}
  THEN   200 avec body :
         { token: "<jwt-string>", expiresAt: "<iso-8601>", tokenType: "Bearer" }
  AND    le token JWT est valide (signature vérifiable avec ADA_JWT_SECRET)
  AND    le payload JWT contient { sub: "local", iat: N, exp: N }
  AND    exp - iat = 604800 secondes (7 jours)
  AND    le hash SHA-256 du token est stocké dans la table sessions avec expires_at correspondant
  AND    Content-Type: application/json dans la réponse

---

SPEC 02 — Mode local : body non vide accepté sans erreur
  GIVEN  ADA_AUTH_MODE=local
  WHEN   POST /api/auth/token avec body { "anything": "ignored" }
  THEN   200 (le body est ignoré en mode local, pas d'erreur 400)

---

SPEC 03 — Mode serveur : token nécessite password — mauvais password
  GIVEN  ADA_AUTH_MODE=server
  AND    ADA_AUTH_PASSWORD="secret-prod-password"
  WHEN   POST /api/auth/token avec { "password": "wrong-password" }
  THEN   401 { error: "INVALID_PASSWORD", message: "Invalid password" }
  AND    aucun token créé en sessions

---

SPEC 04 — Mode serveur : token nécessite password — bon password
  GIVEN  ADA_AUTH_MODE=server
  AND    ADA_AUTH_PASSWORD="secret-prod-password"
  WHEN   POST /api/auth/token avec { "password": "secret-prod-password" }
  THEN   200 avec { token, expiresAt, tokenType: "Bearer" }
  AND    le token est valide 7 jours (configurable via ADA_JWT_TTL)

---

SPEC 05 — Mode serveur : password absent dans body
  GIVEN  ADA_AUTH_MODE=server
  WHEN   POST /api/auth/token avec body vide {}
  THEN   400 { error: "PASSWORD_REQUIRED", message: "Password is required in server mode" }

---

SPEC 06 — ADA_JWT_TTL personnalisé
  GIVEN  ADA_AUTH_MODE=local
  AND    ADA_JWT_TTL=1h
  WHEN   POST /api/auth/token
  THEN   200 avec token
  AND    exp - iat = 3600 secondes
  AND    expiresAt correspond à maintenant + 1 heure (tolérance ±5 secondes)

---

## SUITE : Protection des routes

---

SPEC 07 — Route protégée sans Authorization header → 401
  GIVEN  aucun header Authorization dans la requête
  WHEN   GET /api/workspaces
  THEN   401 { error: "UNAUTHORIZED", message: "Missing or invalid Authorization header" }

---

SPEC 08 — Route protégée avec header malformé → 401
  GIVEN  Authorization: "not-bearer-format"
  WHEN   GET /api/workspaces
  THEN   401 { error: "UNAUTHORIZED" }

---

SPEC 09 — Route protégée avec token invalide (signature incorrecte) → 401
  GIVEN  Authorization: Bearer <token signé avec un secret différent>
  WHEN   GET /api/workspaces
  THEN   401 { error: "INVALID_TOKEN", message: "Token signature invalid" }

---

SPEC 10 — Route protégée avec token expiré → 401
  GIVEN  un token signé avec le bon secret mais exp dans le passé
  WHEN   GET /api/workspaces avec Authorization: Bearer <expired-token>
  THEN   401 { error: "TOKEN_EXPIRED", message: "Token has expired" }

---

SPEC 11 — Route protégée avec token révoqué (absent de sessions) → 401
  GIVEN  un token JWT valide (signature OK, non expiré)
  AND    le hash de ce token n'existe pas en table sessions (supprimé manuellement)
  WHEN   GET /api/workspaces avec ce token
  THEN   401 { error: "TOKEN_REVOKED", message: "Token has been revoked" }

---

SPEC 12 — Route protégée avec token valide → accès accordé
  GIVEN  un token valide retourné par POST /api/auth/token
  AND    le hash est présent en sessions avec expires_at dans le futur
  WHEN   GET /api/workspaces avec Authorization: Bearer <valid-token>
  THEN   200 (la route répond normalement)

---

SPEC 13 — Route /api/health non protégée
  GIVEN  aucun header Authorization
  WHEN   GET /api/health
  THEN   200 (la route health est exclue du middleware auth)

---

SPEC 14 — Route /api/auth/token non protégée
  GIVEN  aucun header Authorization
  WHEN   POST /api/auth/token
  THEN   200 ou 401 selon le mode, pas 401 dû au middleware (la route génère le token sans auth préalable)

---

## SUITE : Refresh token

---

SPEC 15 — Refresh token valide
  GIVEN  un token valide T1 retourné par POST /api/auth/token
  AND    T1 est dans sessions et non expiré
  WHEN   POST /api/auth/refresh avec Authorization: Bearer <T1>
  THEN   200 avec { token: T2, expiresAt: "<nouveau>", tokenType: "Bearer" }
  AND    T2 est différent de T1
  AND    T2 expire 7 jours à partir de maintenant
  AND    le hash de T1 est supprimé de sessions
  AND    le hash de T2 est ajouté à sessions
  AND    une requête ultérieure avec T1 retourne 401 TOKEN_REVOKED

---

SPEC 16 — Refresh avec token expiré → 401
  GIVEN  un token expiré
  WHEN   POST /api/auth/refresh avec ce token
  THEN   401 { error: "TOKEN_EXPIRED" }
  AND    aucun nouveau token créé

---

SPEC 17 — Refresh sans token → 401
  GIVEN  aucun header Authorization
  WHEN   POST /api/auth/refresh
  THEN   401 { error: "UNAUTHORIZED" }

---

## SUITE : Logout / Révocation

---

SPEC 18 — Logout réussi
  GIVEN  un token valide T1
  AND    T1 est en sessions
  WHEN   DELETE /api/auth/session avec Authorization: Bearer <T1>
  THEN   204 (No Content)
  AND    le hash de T1 est supprimé de sessions
  AND    une requête GET /api/workspaces avec T1 retourne 401 TOKEN_REVOKED

---

SPEC 19 — Logout idempotent
  GIVEN  un token T1 déjà supprimé de sessions
  WHEN   DELETE /api/auth/session avec Authorization: Bearer <T1>
  THEN   204 (pas d'erreur 404, opération idempotente)

---

SPEC 20 — Logout sans token → 401
  GIVEN  aucun header Authorization
  WHEN   DELETE /api/auth/session
  THEN   401 { error: "UNAUTHORIZED" }

---

## SUITE : Nettoyage sessions expirées

---

SPEC 21 — Sessions expirées nettoyées automatiquement
  GIVEN  5 sessions dont 3 avec expires_at dans le passé
  WHEN   le job de nettoyage s'exécute (au démarrage ou toutes les heures)
  THEN   les 3 sessions expirées sont supprimées de la table sessions
  AND    les 2 sessions valides restent intactes

---

SPEC 22 — Token d'une session expirée → 401 TOKEN_EXPIRED
  GIVEN  un token JWT non expiré (exp dans le futur)
  AND    mais sessions.expires_at est dans le passé pour ce token (nettoyage pas encore passé)
  WHEN   GET /api/workspaces avec ce token
  THEN   401 (soit TOKEN_EXPIRED si sessions absente après nettoyage, soit TOKEN_REVOKED)
  (Note : le middleware vérifie d'abord la signature JWT puis la présence en sessions)
