# Spec : Conversations et Messages

Service : `src/conversations/`
Endpoints conversations : POST /api/workspaces/:wid/conversations
                          GET /api/workspaces/:wid/conversations
                          GET /api/conversations/:id
                          PATCH /api/conversations/:id
                          DELETE /api/conversations/:id

Endpoints messages : POST /api/conversations/:id/messages
                     GET /api/conversations/:id/messages

Auth : toutes les routes requièrent un token valide

---

## SUITE : Création de conversations

---

SPEC 01 — Créer une conversation avec titre
  GIVEN  workspace "ws-abc" existe
  AND    token valide
  WHEN   POST /api/workspaces/ws-abc/conversations { "title": "Feature stripe billing" }
  THEN   201 avec body :
         { id: "<uuid>", workspaceId: "ws-abc", title: "Feature stripe billing",
           pinned: false, archived: false, runCount: 0,
           createdAt: "<iso>", updatedAt: "<iso>" }
  AND    workspace.updated_at de "ws-abc" est rafraîchi

---

SPEC 02 — Créer une conversation sans titre
  GIVEN  workspace "ws-abc" existe
  WHEN   POST /api/workspaces/ws-abc/conversations {}
  THEN   201 avec { title: null } ou { title: "New conversation" } selon config
  (le titre est optionnel, pas de 400)

---

SPEC 03 — Créer conversation dans workspace inexistant → 404
  WHEN   POST /api/workspaces/inexistant/conversations { "title": "Test" }
  THEN   404 { error: "WORKSPACE_NOT_FOUND" }

---

## SUITE : Lecture de conversations

---

SPEC 04 — Lister conversations d'un workspace — vide
  GIVEN  workspace "ws-abc" sans conversations
  WHEN   GET /api/workspaces/ws-abc/conversations
  THEN   200 { items: [], nextCursor: null, total: 0 }

---

SPEC 05 — Lister conversations avec pagination cursor — première page
  GIVEN  50 conversations dans "ws-abc", triées par updated_at DESC
  WHEN   GET /api/workspaces/ws-abc/conversations?limit=20
  THEN   200 {
           items: [<20 conversations les plus récentes>],
           nextCursor: "<id-de-la-20ème>",
           total: 50,
           hasMore: true
         }
  AND    les items sont triés par updated_at DESC

---

SPEC 06 — Lister conversations — page suivante
  GIVEN  la réponse précédente avec nextCursor="cursor-val"
  WHEN   GET /api/workspaces/ws-abc/conversations?limit=20&cursor=cursor-val
  THEN   200 {
           items: [<conversations 21 à 40>],
           nextCursor: "<id-de-la-40ème>",
           hasMore: true
         }

---

SPEC 07 — Lister conversations — dernière page
  GIVEN  cursor pointant sur la 41ème conversation (9 restantes)
  WHEN   GET /api/workspaces/ws-abc/conversations?limit=20&cursor=<cursor>
  THEN   200 { items: [<9 dernières>], nextCursor: null, hasMore: false }

---

SPEC 08 — Lister conversations — filtre archived=false par défaut
  GIVEN  3 conversations actives et 2 archivées dans "ws-abc"
  WHEN   GET /api/workspaces/ws-abc/conversations
  THEN   200 { items: [<3 conversations actives>], total: 3 }

---

SPEC 09 — Lister conversations — inclure archivées avec ?archived=true
  GIVEN  3 actives et 2 archivées
  WHEN   GET /api/workspaces/ws-abc/conversations?archived=true
  THEN   200 { items: [<5 conversations>], total: 5 }

---

SPEC 10 — Lister conversations — filtre pinned=true
  GIVEN  1 conversation pinned et 4 non-pinned dans "ws-abc"
  WHEN   GET /api/workspaces/ws-abc/conversations?pinned=true
  THEN   200 { items: [<1 conversation pinned>], total: 1 }

---

SPEC 11 — Récupérer une conversation par ID
  GIVEN  conversation "conv-xyz" existe
  WHEN   GET /api/conversations/conv-xyz
  THEN   200 avec le détail complet :
         { id, workspaceId, title, pinned, archived, runCount, messageCount, createdAt, updatedAt }
  AND    messageCount = nombre réel de messages dans cette conversation

---

SPEC 12 — Conversation non trouvée → 404
  WHEN   GET /api/conversations/inexistant
  THEN   404 { error: "CONVERSATION_NOT_FOUND" }

---

## SUITE : Modification de conversations

---

SPEC 13 — Modifier le titre
  GIVEN  conversation "conv-xyz" avec title="Ancien"
  WHEN   PATCH /api/conversations/conv-xyz { "title": "Nouveau" }
  THEN   200 avec { title: "Nouveau" }
  AND    updatedAt est rafraîchi

---

SPEC 14 — Pinner une conversation
  GIVEN  conversation "conv-xyz" avec pinned=false
  WHEN   PATCH /api/conversations/conv-xyz { "pinned": true }
  THEN   200 avec { pinned: true }

---

SPEC 15 — Unpinner une conversation
  GIVEN  conversation "conv-xyz" avec pinned=true
  WHEN   PATCH /api/conversations/conv-xyz { "pinned": false }
  THEN   200 avec { pinned: false }

---

SPEC 16 — Archiver une conversation
  GIVEN  conversation "conv-xyz" avec archived=false
  WHEN   PATCH /api/conversations/conv-xyz { "archived": true }
  THEN   200 avec { archived: true }
  AND    la conversation n'apparaît plus dans GET /api/workspaces/ws-abc/conversations (filtre défaut)
  AND    GET /api/conversations/conv-xyz retourne toujours 200 (accessible par ID direct)

---

SPEC 17 — Désarchiver une conversation
  GIVEN  conversation "conv-xyz" avec archived=true
  WHEN   PATCH /api/conversations/conv-xyz { "archived": false }
  THEN   200 avec { archived: false }
  AND    la conversation réapparaît dans le listing par défaut

---

SPEC 18 — PATCH conversation non trouvée → 404
  WHEN   PATCH /api/conversations/inexistant { "title": "X" }
  THEN   404 { error: "CONVERSATION_NOT_FOUND" }

---

## SUITE : Suppression de conversations

---

SPEC 19 — Supprimer une conversation supprime les messages
  GIVEN  conversation "conv-xyz" avec 10 messages
  WHEN   DELETE /api/conversations/conv-xyz
  THEN   204
  AND    GET /api/conversations/conv-xyz retourne 404
  AND    SELECT COUNT(*) FROM conversations_messages WHERE conversation_id='conv-xyz' = 0

---

SPEC 20 — Supprimer conversation non trouvée → 404
  WHEN   DELETE /api/conversations/inexistant
  THEN   404 { error: "CONVERSATION_NOT_FOUND" }

---

## SUITE : Messages

---

SPEC 21 — Envoyer un message utilisateur
  GIVEN  conversation "conv-xyz" existe
  AND    token valide
  WHEN   POST /api/conversations/conv-xyz/messages
         { "role": "user", "content": "Crée une feature paiement Stripe" }
  THEN   201 avec body :
         { id: "<uuid>", conversationId: "conv-xyz", role: "user",
           content: "Crée une feature paiement Stripe", contentType: "text",
           metadata: null, createdAt: "<iso>" }
  AND    conversations.updated_at de "conv-xyz" est rafraîchi
  AND    WS broadcast vers la room du workspace : { type: "message.new", conversationId: "conv-xyz", message: <le message> }

---

SPEC 22 — Envoyer un message assistant avec metadata
  GIVEN  conversation "conv-xyz" existe
  WHEN   POST /api/conversations/conv-xyz/messages
         { "role": "assistant", "content": "Feature créée.", "contentType": "run_status",
           "metadata": { "runId": "feat-123", "cost": 0.15 } }
  THEN   201 avec { role: "assistant", contentType: "run_status", metadata: { runId: "feat-123", cost: 0.15 } }

---

SPEC 23 — Envoyer message dans conversation inexistante → 404
  WHEN   POST /api/conversations/inexistant/messages { "role": "user", "content": "X" }
  THEN   404 { error: "CONVERSATION_NOT_FOUND" }

---

SPEC 24 — Role invalide → 400
  WHEN   POST /api/conversations/conv-xyz/messages { "role": "robot", "content": "X" }
  THEN   400 { error: "VALIDATION_ERROR", message: "role must be one of: user, assistant, system" }

---

SPEC 25 — Content manquant → 400
  WHEN   POST /api/conversations/conv-xyz/messages { "role": "user" }
  THEN   400 { error: "VALIDATION_ERROR", message: "content is required" }

---

SPEC 26 — Lister messages — vide
  GIVEN  conversation "conv-xyz" sans messages
  WHEN   GET /api/conversations/conv-xyz/messages
  THEN   200 { items: [], nextCursor: null, hasMore: false }

---

SPEC 27 — Lister messages avec pagination cursor — ordre chronologique DESC
  GIVEN  conversation "conv-xyz" avec 100 messages, M1 (le plus ancien) à M100 (le plus récent)
  WHEN   GET /api/conversations/conv-xyz/messages?limit=50
  THEN   200 {
           items: [M100, M99, ..., M51],   // 50 plus récents, du plus récent au plus ancien
           nextCursor: "<id-de-M51>",
           hasMore: true
         }

---

SPEC 28 — Lister messages — page suivante
  GIVEN  nextCursor pointant sur M51
  WHEN   GET /api/conversations/conv-xyz/messages?limit=50&cursor=<cursor>
  THEN   200 {
           items: [M50, M49, ..., M1],
           nextCursor: null,
           hasMore: false
         }

---

SPEC 29 — Lister messages avec filtre contentType
  GIVEN  conversation "conv-xyz" avec 5 messages "text" et 2 messages "run_status"
  WHEN   GET /api/conversations/conv-xyz/messages?contentType=run_status
  THEN   200 { items: [<2 messages run_status>] }

---

SPEC 30 — Messages archivés restent accessibles
  GIVEN  conversation "conv-xyz" avec 5 messages, conversation archivée (archived=true)
  WHEN   GET /api/conversations/conv-xyz/messages
  THEN   200 { items: [<5 messages>] }
  (l'archivage de la conversation n'affecte pas l'accès aux messages par ID direct)

---

## SUITE : Recherche dans les conversations

---

SPEC 31 — Recherche full-text dans les messages d'un workspace
  GIVEN  workspace "ws-abc" avec 3 conversations et des messages divers
  AND    message M1 contient "stripe" dans une conversation
  AND    message M2 contient "stripe" dans une autre conversation
  WHEN   GET /api/workspaces/ws-abc/search?q=stripe
  THEN   200 { items: [<2 résultats>] }
  AND    chaque résultat contient { messageId, conversationId, conversationTitle, content, createdAt }

---

SPEC 32 — Recherche sans résultats
  WHEN   GET /api/workspaces/ws-abc/search?q=motintrouvable
  THEN   200 { items: [], total: 0 }

---

SPEC 33 — Recherche sans paramètre q → 400
  WHEN   GET /api/workspaces/ws-abc/search
  THEN   400 { error: "VALIDATION_ERROR", message: "q parameter is required" }
