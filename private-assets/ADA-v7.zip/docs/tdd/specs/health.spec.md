# Spec : Health Check

Service : `src/health/`
Endpoint : GET /api/health
Auth : route publique (pas de token requis)

---

## SUITE : État nominal

---

SPEC 01 — Health OK complet (tous services up)
  GIVEN  ada-api démarré
  AND    DB SQLite accessible (connexion réussie)
  AND    IPC consumer connecté à ada-core
  AND    2 clients WS connectés dans 1 room
  WHEN   GET /api/health
  THEN   200 avec body :
         {
           status: "ok",
           version: "<semver depuis package.json>",
           uptime: N,           // secondes depuis démarrage
           db: "ok",
           core: "online",
           ws: {
             activeConnections: 2,
             activeRooms: 1
           },
           ts: "<iso-8601>"
         }
  AND    Content-Type: application/json

---

SPEC 02 — Uptime croissant
  GIVEN  ada-api démarré depuis T secondes
  WHEN   GET /api/health
  THEN   uptime >= T (valeur en secondes, entier ou flottant)

---

SPEC 03 — Version correspond à package.json
  GIVEN  package.json contient { "version": "2.0.0" }
  WHEN   GET /api/health
  THEN   { version: "2.0.0" }

---

## SUITE : Mode dégradé

---

SPEC 04 — ada-core offline
  GIVEN  IPC consumer non connecté (ada-core absent)
  WHEN   GET /api/health
  THEN   200 (pas 503 — la route health répond toujours)
  AND    body : { status: "degraded", core: "offline", db: "ok", api: "ok" }

---

SPEC 05 — DB inaccessible
  GIVEN  DB SQLite corrompue ou fichier supprimé
  WHEN   GET /api/health
  THEN   200 avec { status: "degraded", db: "error" }
  AND    body contient { dbError: "<message d'erreur>" }
  (note : réponse 200 pour que les load balancers reçoivent toujours une réponse)

---

SPEC 06 — Tous services down
  GIVEN  DB inaccessible ET IPC non connecté
  WHEN   GET /api/health
  THEN   200 avec { status: "degraded", db: "error", core: "offline" }

---

SPEC 07 — Zéro connexions WS
  GIVEN  aucun client WebSocket connecté
  WHEN   GET /api/health
  THEN   200 avec { ws: { activeConnections: 0, activeRooms: 0 } }

---

## SUITE : Liveness vs Readiness

---

SPEC 08 — Liveness probe (ping minimal)
  WHEN   GET /api/health/live
  THEN   200 { alive: true }
  AND   temps de réponse < 10ms (pas de DB query, pas d'IPC check)

---

SPEC 09 — Readiness probe (vérifie DB)
  GIVEN  DB accessible
  WHEN   GET /api/health/ready
  THEN   200 { ready: true }

---

SPEC 10 — Readiness probe DB inaccessible
  GIVEN  DB SQLite inaccessible
  WHEN   GET /api/health/ready
  THEN   503 { ready: false, reason: "database unavailable" }
