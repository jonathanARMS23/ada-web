# Spec : Tests d'intégration — Flux end-to-end

Ces tests valident des flux complets impliquant plusieurs couches simultanément.
Contexte : ada-api démarré avec DB in-memory, IPC mock (net.Server local), client WS réel.
Isolation : chaque flux démarre avec un contexte propre (DB vide, rooms vides).

---

## FLUX 1 : Lancement complet d'un run depuis l'UI

---

SPEC I-01 — Flux complet feature run (happy path)

  GIVEN  ada-api démarré avec mock IPC connecté
  AND    token valide T1
  AND    workspace "ws-abc" créé via POST /api/workspaces
  AND    conversation "conv-xyz" créée via POST /api/workspaces/ws-abc/conversations
  AND    client WS C1 connecté et inscrit dans room "ws-abc"

  STEP 1 — L'utilisateur envoie un message :
    WHEN   POST /api/conversations/conv-xyz/messages
           { "role": "user", "content": "/feature stripe-billing" }
    THEN   201 { id: "msg-1", role: "user", content: "/feature stripe-billing" }
    AND    C1 reçoit dans les 200ms : { type: "message.new", conversationId: "conv-xyz", message: { id: "msg-1" } }

  STEP 2 — L'UI spawn le run :
    WHEN   POST /api/runs
           { "pipeline": "feature", "args": ["--name", "stripe-billing"], "workspaceId": "ws-abc", "conversationId": "conv-xyz" }
    THEN   202 { runId: "feat-001", status: "starting", pipeline: "feature" }
    AND    run_links créé : { run_id: "feat-001", status: "running" }
    AND    message system ajouté : content="Run feature/stripe-billing démarré"
    AND    C1 reçoit : { type: "run.started", runId: "feat-001", pipeline: "feature" }

  STEP 3 — ada-core émet les événements de progression (via mock IPC) :
    WHEN   mock émet : { type: "run.phase.started", runId: "feat-001", phaseId: "schema" }
    THEN   C1 reçoit : { type: "phase.started", runId: "feat-001", phaseId: "schema" }

    WHEN   mock émet : { type: "run.phase.log", runId: "feat-001", phaseId: "schema", line: "Création table payments..." }
    THEN   C1 reçoit : { type: "phase.progress", runId: "feat-001", phaseId: "schema", log: "Création table payments..." }

    WHEN   mock émet : { type: "run.phase.done", runId: "feat-001", phaseId: "schema", status: "success" }
    THEN   C1 reçoit : { type: "phase.done", runId: "feat-001", phaseId: "schema", status: "success" }

    WHEN   mock émet : { type: "run.phase.started", runId: "feat-001", phaseId: "backend" }
    AND    mock émet 3× : { type: "run.phase.log", runId: "feat-001", phaseId: "backend", line: "..." }
    AND    mock émet : { type: "run.phase.done", runId: "feat-001", phaseId: "backend", status: "success" }
    THEN   C1 reçoit les 5 events dans l'ordre correct

    WHEN   mock émet :
           { type: "run.done", runId: "feat-001", status: "completed", totalCost: 0.18, summary: "Feature stripe-billing livrée." }
    THEN   C1 reçoit dans les 200ms : { type: "run.done", runId: "feat-001", cost: 0.18, summary: "Feature stripe-billing livrée." }
    AND    run_links.status = "completed" en DB
    AND    run_links.total_cost = 0.18 en DB

  STEP 4 — Vérification état final :
    WHEN   GET /api/runs/feat-001
    THEN   200 { status: "completed", totalCost: 0.18, completedAt: "<iso>" }

    WHEN   GET /api/conversations/conv-xyz/messages?limit=50
    THEN   200 avec 3 messages (du plus récent au plus ancien) :
           - role="assistant", contentType="run_status", content="Feature stripe-billing livrée."
           - role="system", content="Run feature/stripe-billing démarré"
           - role="user", content="/feature stripe-billing"

    WHEN   GET /api/workspaces/ws-abc/stats
    THEN   200 { totalRuns: 1, totalCost: 0.18, totalMessages: 3 }

---

SPEC I-02 — Flux avec run échoué

  GIVEN  setup identique à I-01
  AND    run "feat-002" spawné

  WHEN   mock émet { type: "run.phase.started", runId: "feat-002", phaseId: "backend" }
  AND    mock émet { type: "run.phase.done", runId: "feat-002", phaseId: "backend", status: "failed" }
  AND    mock émet { type: "run.done", runId: "feat-002", status: "failed", totalCost: 0.03, summary: "Échec: timeout backend." }

  THEN   run_links.status = "failed" en DB
  AND    message assistant ajouté : contentType="run_status", content="Échec: timeout backend."
  AND    C1 reçoit { type: "run.done", runId: "feat-002", cost: 0.03, summary: "Échec: timeout backend." }

---

SPEC I-03 — Flux avec annulation utilisateur en cours de run

  GIVEN  run "feat-003" en cours (status="running")
  AND    C1 dans room "ws-abc"

  WHEN   DELETE /api/runs/feat-003
  THEN   204
  AND    run_links.status = "cancelled" en DB
  AND    C1 reçoit { type: "run.cancelled", runId: "feat-003" }

  WHEN   mock IPC émet ensuite { type: "run.done", runId: "feat-003", status: "completed", ... }
  (arrivée tardive après annulation)
  THEN   run_links.status reste "cancelled" (statut final, non écrasé)

---

## FLUX 2 : Reprise après crash ada-api

---

SPEC I-04 — Replay events.ndjson après redémarrage

  GIVEN  ada-api instance 1 en cours avec workspace "ws-abc" et run "feat-crash"
  AND    run_links "feat-crash" status="running"
  AND    ada-api instance 1 est stoppée (crash simulé)
  AND   pendant le crash, ada-core a émis 3 événements dans events.ndjson :
        ligne 1 : { type: "run.phase.done", runId: "feat-crash", phaseId: "backend", status: "success" }
        ligne 2 : { type: "run.done", runId: "feat-crash", status: "completed", totalCost: 0.12, summary: "Récupéré." }
        ligne 3 : { type: "run.started", runId: "new-after-crash", pipeline: "review", payload: { workspaceId: "ws-abc" } }
  AND    events.cursor = 0 (début du fichier)

  WHEN   ada-api instance 2 démarre en mode fallback (IPC absent)
  THEN   les 3 événements de events.ndjson sont lus et traités dans l'ordre
  AND    run_links "feat-crash" status = "completed", total_cost = 0.12
  AND    run_links "new-after-crash" créé avec status = "running"
  AND    events.cursor pointe sur l'offset après la ligne 3
  AND    GET /api/runs/feat-crash retourne { status: "completed", totalCost: 0.12 }

---

SPEC I-05 — Replay partiel avec cursor existant

  GIVEN  events.ndjson contient 5 événements (lignes 1-5)
  AND    events.cursor pointe sur l'offset après la ligne 3 (déjà traités)
  WHEN   ada-api démarre en mode fallback
  THEN   seules les lignes 4 et 5 sont traitées
  AND    les événements 1-3 ne sont pas retraités (pas de doublon)

---

## FLUX 3 : Multi-device en temps réel

---

SPEC I-06 — Même conversation ouverte sur browser et mobile

  GIVEN  token T1 valide
  AND    workspace "ws-abc" et conversation "conv-xyz" existent
  AND    client A (browser) connecté WS et dans room "ws-abc"
  AND    client B (mobile) connecté WS et dans room "ws-abc"

  STEP 1 — client A envoie un message :
    WHEN   POST /api/conversations/conv-xyz/messages { "role": "user", "content": "Hello depuis browser" }
    THEN   201
    AND    client A reçoit { type: "message.new", message: { content: "Hello depuis browser" } }
    AND    client B reçoit { type: "message.new", message: { content: "Hello depuis browser" } } dans les 200ms

  STEP 2 — état cohérent pour les deux clients :
    WHEN   GET /api/conversations/conv-xyz/messages (depuis client A)
    AND    GET /api/conversations/conv-xyz/messages (depuis client B)
    THEN   les deux retournent le même tableau de messages (même contenu, même ordre)

  STEP 3 — client B se déconnecte :
    WHEN   client B ferme sa connexion WS
    AND    POST /api/conversations/conv-xyz/messages { "role": "user", "content": "Message 2" }
    THEN   201
    AND    client A reçoit { type: "message.new", message: { content: "Message 2" } }
    AND    client B ne reçoit rien (déconnecté, pas d'erreur côté serveur)

---

SPEC I-07 — Isolation entre workspaces

  GIVEN  client A dans room "ws-abc"
  AND    client B dans room "ws-xyz"
  AND    conversation "conv-abc" dans "ws-abc"
  AND    conversation "conv-xyz" dans "ws-xyz"

  WHEN   POST /api/conversations/conv-abc/messages { "role": "user", "content": "Pour ws-abc" }
  THEN   client A reçoit { type: "message.new", conversationId: "conv-abc" }
  AND    client B NE reçoit PAS ce message

  WHEN   POST /api/conversations/conv-xyz/messages { "role": "user", "content": "Pour ws-xyz" }
  THEN   client B reçoit { type: "message.new", conversationId: "conv-xyz" }
  AND    client A NE reçoit PAS ce message

---

## FLUX 4 : Cycle de vie complet d'un workspace

---

SPEC I-08 — Création → utilisation → archivage → suppression

  STEP 1 — Création :
    WHEN   POST /api/workspaces { "name": "Projet Test" }
    THEN   201 { id: "ws-test", slug: "projet-test" }

  STEP 2 — Utilisation :
    WHEN   POST /api/workspaces/ws-test/conversations { "title": "Sprint 1" }
    AND    POST /api/conversations/<conv>/messages { "role": "user", "content": "Démarrage" }
    THEN   201 pour chaque requête
    AND    GET /api/workspaces/ws-test/stats retourne { totalMessages: 1 }

  STEP 3 — Archivage de la conversation :
    WHEN   PATCH /api/conversations/<conv> { "archived": true }
    THEN   200 { archived: true }
    AND    GET /api/workspaces/ws-test/conversations retourne { items: [], total: 0 }
    AND    GET /api/conversations/<conv>/messages retourne les messages (toujours accessibles)

  STEP 4 — Suppression du workspace :
    WHEN   DELETE /api/workspaces/ws-test
    THEN   204
    AND    GET /api/workspaces/ws-test retourne 404
    AND    GET /api/conversations/<conv> retourne 404 (cascade)
    AND    GET /api/conversations/<conv>/messages retourne 404 (cascade)

---

## FLUX 5 : Authentification complète

---

SPEC I-09 — Cycle token complet : génération → utilisation → refresh → révocation

  STEP 1 — Génération :
    WHEN   POST /api/auth/token
    THEN   200 { token: T1, expiresAt }

  STEP 2 — Utilisation :
    WHEN   GET /api/workspaces avec Authorization: Bearer T1
    THEN   200

  STEP 3 — Refresh :
    WHEN   POST /api/auth/refresh avec Authorization: Bearer T1
    THEN   200 { token: T2, expiresAt }
    AND    T2 ≠ T1
    AND    GET /api/workspaces avec T1 retourne 401 TOKEN_REVOKED

  STEP 4 — Révocation :
    WHEN   DELETE /api/auth/session avec Authorization: Bearer T2
    THEN   204
    AND    GET /api/workspaces avec T2 retourne 401 TOKEN_REVOKED
    AND    GET /api/workspaces sans token retourne 401 UNAUTHORIZED
