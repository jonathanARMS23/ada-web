# Spec : IPC Consumer

Service : `src/ipc/ipc-consumer.ts`
Dépendances testées : connexion socket, parsing NDJSON, persistence DB, broadcast WS
Isolation : ada-core remplacé par un net.Server mock local en test

---

## SUITE : Connexion socket

---

SPEC 01 — Connexion Unix socket réussie
  GIVEN  ada-api démarre avec ADA_IPC_MODE=unix
  AND    un net.Server mock écoute sur /tmp/test-ada-core.sock
  AND    le fichier .claude/ada-core.sock existe (symlink ou fichier)
  WHEN   ada-api initialise l'IPC consumer
  THEN   la connexion est établie dans les 2 secondes
  AND    ada-api émet vers le socket : { type: "hello", version: "1.0", service: "ada-api" }
  AND    le message est encodé en JSON suivi d'un \n (format NDJSON)

---

SPEC 02 — Fallback TCP si Unix socket absent
  GIVEN  ADA_IPC_MODE=unix
  AND    le fichier .claude/ada-core.sock n'existe pas (ou ENOENT à la connexion)
  AND    ADA_IPC_PORT=3099 est configuré
  AND    un net.Server mock écoute sur 127.0.0.1:3099
  WHEN   ada-api initialise l'IPC consumer
  THEN   la tentative Unix socket échoue silencieusement (pas de crash)
  AND    la connexion TCP sur 127.0.0.1:3099 est tentée
  AND    la connexion TCP est établie avec succès

---

SPEC 03 — Fallback events.ndjson si TCP aussi absent
  GIVEN  ADA_IPC_MODE=unix
  AND    .claude/ada-core.sock absent
  AND    TCP 127.0.0.1:3099 absent (connexion refusée)
  AND    events.ndjson existe dans le répertoire de travail
  WHEN   ada-api initialise l'IPC consumer
  THEN   le mode fallback "file" est activé
  AND    ada-api lit events.ndjson depuis le dernier cursor connu
  AND    un log INFO est émis : "IPC: fallback mode active (events.ndjson)"

---

SPEC 04 — Reconnexion automatique après déconnexion
  GIVEN  la connexion IPC est établie
  AND    ADA_IPC_RECONNECT_DELAY=100 (réduit pour le test)
  WHEN   le mock ada-core ferme brutalement le socket (socket.destroy())
  THEN   ada-api détecte l'événement "close" sur le socket
  AND    ada-api tente de reconnecter après 100ms
  AND    si le mock est remonté, la connexion est rétablie
  AND    un message HELLO est renvoyé à la reconnexion
  AND    un log WARN est émis à chaque tentative échouée : "IPC: reconnecting in Xms..."

---

SPEC 05 — Tentatives de reconnexion sans limite
  GIVEN  ada-core reste absent après déconnexion
  AND    ADA_IPC_RECONNECT_DELAY=50 (réduit pour le test)
  WHEN   10 tentatives de reconnexion échouent consécutivement
  THEN   ada-api continue de tenter (pas de stoppage après N erreurs)
  AND   ada-api ne crash pas
  AND   10 logs WARN sont émis (un par tentative)

---

SPEC 06 — Pas de crash si ada-core absent au démarrage
  GIVEN  ada-core n'est pas démarré (socket absent, TCP absent)
  WHEN   ada-api démarre
  THEN   ada-api démarre quand même (mode dégradé)
  AND    /api/health retourne 200 avec { core: "offline", api: "ok" }
  AND    les tentatives de connexion IPC continuent en background
  AND    ada-api n'émet aucune exception non catchée

---

## SUITE : Traitement des événements

---

SPEC 07 — Événement run.started traité correctement
  GIVEN  la connexion IPC est établie
  AND    un workspace "ws-abc" existe en DB
  AND    une conversation "conv-xyz" appartenant à "ws-abc" existe en DB
  WHEN   ada-core émet via le socket :
         { type: "run.started", runId: "feat-123", pipeline: "feature", payload: { conversationId: "conv-xyz", workspaceId: "ws-abc" } }
  THEN   un enregistrement run_links est créé en DB :
         { run_id: "feat-123", pipeline: "feature", status: "running", workspace_id: "ws-abc", conversation_id: "conv-xyz" }
  AND    conversations.updated_at de "conv-xyz" est mis à jour (timestamp actuel)
  AND    un broadcast WS est émis vers la room "ws-abc" :
         { type: "run.started", runId: "feat-123", pipeline: "feature" }

---

SPEC 08 — run.started sans conversationId → run_links créé sans conversation liée
  GIVEN  la connexion IPC est établie
  WHEN   ada-core émet { type: "run.started", runId: "feat-999", pipeline: "review", payload: { workspaceId: "ws-abc" } }
         (pas de conversationId dans payload)
  THEN   run_links créé avec conversation_id = null
  AND    aucune erreur n'est levée

---

SPEC 09 — Événement run.phase.started traité
  GIVEN  la connexion IPC est établie
  AND    run_links "feat-123" existe avec status="running"
  WHEN   ada-core émet { type: "run.phase.started", runId: "feat-123", phaseId: "backend" }
  THEN   WS broadcast vers room workspace concernée :
         { type: "phase.started", runId: "feat-123", phaseId: "backend" }
  AND    aucune écriture DB n'est effectuée (pas de table de phases)

---

SPEC 10 — Événement run.phase.log traité correctement
  GIVEN  la connexion IPC est établie
  AND    run_links "feat-123" existe
  WHEN   ada-core émet { type: "run.phase.log", runId: "feat-123", phaseId: "backend", line: "Écriture de user.service.ts..." }
  THEN   WS broadcast vers room workspace concernée :
         { type: "phase.progress", runId: "feat-123", phaseId: "backend", log: "Écriture de user.service.ts...", ts: "<iso>" }
  AND    le log n'est PAS écrit en DB (volume trop élevé, stockage mémoire uniquement)

---

SPEC 11 — Événement run.done traité correctement
  GIVEN  la connexion IPC est établie
  AND    run_links "feat-123" existe avec status="running", conversation_id="conv-xyz"
  WHEN   ada-core émet :
         { type: "run.done", runId: "feat-123", status: "completed", totalCost: 0.15, summary: "Feature stripe-billing complétée en 3 phases." }
  THEN   run_links mis à jour en DB :
         { status: "completed", total_cost: 0.15, completed_at: "<timestamp>" }
  AND    un message créé dans conversations_messages :
         { conversation_id: "conv-xyz", role: "assistant", content_type: "run_status",
           content: "Feature stripe-billing complétée en 3 phases.", metadata: { runId: "feat-123", cost: 0.15 } }
  AND    conversations.run_count incrémenté de 1 pour "conv-xyz"
  AND    WS broadcast vers room workspace :
         { type: "run.done", runId: "feat-123", cost: 0.15, summary: "Feature stripe-billing complétée en 3 phases." }

---

SPEC 12 — Événement run.done avec status="failed"
  GIVEN  run_links "feat-123" existe avec status="running"
  WHEN   ada-core émet { type: "run.done", runId: "feat-123", status: "failed", totalCost: 0.03, summary: "Échec phase backend : timeout." }
  THEN   run_links.status = "failed"
  AND    run_links.total_cost = 0.03
  AND    message assistant ajouté avec content_type="run_status" et le summary d'échec
  AND    WS broadcast émis identiquement (le status "failed" est inclus dans le broadcast)

---

SPEC 13 — Événement run.phase.done traité
  GIVEN  run_links "feat-123" existe
  WHEN   ada-core émet { type: "run.phase.done", runId: "feat-123", phaseId: "schema", status: "success" }
  THEN   WS broadcast : { type: "phase.done", runId: "feat-123", phaseId: "schema", status: "success" }
  AND    aucune écriture DB (pas de table phases)

---

## SUITE : Robustesse parsing NDJSON

---

SPEC 14 — Message NDJSON partiel (split sur plusieurs chunks TCP) bufferisé sans crash
  GIVEN  la connexion IPC est active
  WHEN   le mock ada-core envoie un message JSON en 2 chunks TCP séparés :
         chunk 1 → '{"type":"run.done","runId":"feat-1'
         chunk 2 → '23","status":"completed","totalCost":0.1,"summary":"ok"}\n'
  THEN   ada-api bufferise les chunks jusqu'à recevoir \n
  AND    traite le message complet comme un seul événement
  AND    run_links est mis à jour correctement
  AND    aucun crash ou exception non catchée

---

SPEC 15 — Plusieurs messages dans un seul chunk TCP
  GIVEN  la connexion IPC est active
  AND    run_links "r1" et "r2" existent
  WHEN   le mock envoie en un seul chunk :
         '{"type":"run.done","runId":"r1","status":"completed","totalCost":0.05,"summary":"s1"}\n{"type":"run.done","runId":"r2","status":"completed","totalCost":0.07,"summary":"s2"}\n'
  THEN   les deux événements sont traités séquentiellement
  AND    run_links "r1" et "r2" sont tous les deux mis à jour

---

SPEC 16 — Message JSON malformé ignoré sans crash
  GIVEN  la connexion IPC est active
  WHEN   ada-core émet une ligne contenant du JSON invalide : 'not-json-at-all\n'
  THEN   ada-api log un WARN contenant la ligne brute
  AND    continue de traiter les messages suivants normalement
  AND    aucun crash

---

SPEC 17 — Message avec type inconnu ignoré
  GIVEN  la connexion IPC est active
  WHEN   ada-core émet { type: "unknown.event", foo: "bar" }
  THEN   ada-api log un WARN : "IPC: unknown event type: unknown.event"
  AND    aucune action effectuée (pas de DB write, pas de WS broadcast)
  AND    aucun crash

---

SPEC 18 — Message avec runId manquant ignoré
  GIVEN  la connexion IPC est active
  WHEN   ada-core émet { type: "run.done" } (sans runId)
  THEN   ada-api log un WARN avec le message brut
  AND    aucune DB write effectuée
  AND    aucun crash

---

## SUITE : Idempotence

---

SPEC 19 — Idempotence sur run.started dupliqué (upsert)
  GIVEN  run_links "feat-123" existe déjà avec status="running"
  WHEN   ada-core réémet { type: "run.started", runId: "feat-123", pipeline: "feature", payload: {} }
  THEN   aucun doublon créé en DB (upsert sur run_id)
  AND    status reste "running"
  AND    aucune erreur de contrainte unique SQL

---

SPEC 20 — Idempotence sur run.done dupliqué
  GIVEN  run_links "feat-123" existe avec status="completed"
  AND    un message assistant "run_status" existe déjà pour ce run
  WHEN   ada-core réémet { type: "run.done", runId: "feat-123", status: "completed", totalCost: 0.15, summary: "..." }
  THEN   run_links n'est pas modifié (status déjà final, completed_at inchangé)
  AND    aucun message dupliqué créé en DB
  AND    WS broadcast émis quand même (les clients WS peuvent avoir été reconnectés)

---

## SUITE : Event Log fallback (mode fichier)

---

SPEC 21 — Lecture events.ndjson depuis cursor existant
  GIVEN  events.ndjson contient 10 lignes JSON valides (événements ada-core)
  AND    events.cursor contient l'offset en bytes correspondant à la fin de la ligne 3
  WHEN   ada-api démarre en mode fallback (IPC non disponible)
  THEN   seuls les événements 4 à 10 sont traités (replay depuis cursor)
  AND    events.cursor est mis à jour après traitement de chaque événement
  AND    events.cursor pointe sur l'offset final après traitement de l'événement 10

---

SPEC 22 — Cursor créé si absent
  GIVEN  events.ndjson existe et contient 5 événements
  AND    events.cursor n'existe pas
  WHEN   ada-api démarre en mode fallback
  THEN   lecture depuis le début de events.ndjson (offset 0)
  AND    les 5 événements sont traités
  AND    events.cursor est créé avec l'offset final

---

SPEC 23 — events.ndjson absent → démarrage sans erreur
  GIVEN  events.ndjson n'existe pas
  AND    events.cursor n'existe pas
  WHEN   ada-api démarre en mode fallback
  THEN   aucun traitement d'événements (rien à lire)
  AND    ada-api ne crash pas
  AND    un log INFO est émis : "IPC fallback: no events.ndjson found, waiting..."

---

SPEC 24 — Surveillance des nouveaux événements en mode fallback (tail)
  GIVEN  ada-api est en mode fallback
  AND    events.ndjson a été entièrement lu (cursor au EOF)
  WHEN   ada-core écrit un nouvel événement en append dans events.ndjson
  THEN   ada-api détecte le nouvel événement dans les 500ms
  AND    l'événement est traité normalement
  AND    events.cursor est mis à jour
