# Spec : Runs API

Service : `src/runs/`
Endpoints : POST /api/runs · GET /api/runs/:id · GET /api/runs · DELETE /api/runs/:id
Auth : toutes les routes requièrent un token valide

Dépendances : IPC Consumer (pour spawner et recevoir les events), WS Gateway (pour broadcaster)
En test : ada-core remplacé par un mock IPC Unix socket + child_process.spawn mocké via vi.mock

---

## SUITE : Spawn d'un run

---

SPEC 01 — Spawner un run avec pipeline et args
  GIVEN  workspace "ws-abc" et conversation "conv-xyz" existent
  AND    ada-core est accessible (IPC connecté, mock en test)
  AND    token valide
  WHEN   POST /api/runs {
           "pipeline": "feature",
           "args": ["--name", "stripe-billing"],
           "workspaceId": "ws-abc",
           "conversationId": "conv-xyz"
         }
  THEN   202 avec body : { runId: "<uuid>", status: "starting", pipeline: "feature" }
  AND    runId est un UUID v4 valide
  AND    un enregistrement run_links est créé en DB :
         { run_id: "<uuid>", pipeline: "feature", status: "running",
           workspace_id: "ws-abc", conversation_id: "conv-xyz", created_at: "<iso>" }
  AND    un message role="system" est ajouté dans "conv-xyz" :
         content: "Run feature/stripe-billing démarré", contentType: "text"
  AND    WS broadcast vers room "ws-abc" : { type: "run.started", runId, pipeline: "feature" }

---

SPEC 02 — Run ID transmis à ada-core comme argument CLI
  GIVEN  IPC connecté
  WHEN   POST /api/runs { "pipeline": "feature", "args": ["--name", "x"], "workspaceId": "ws-abc" }
  THEN   202
  AND    child_process.spawn est appelé avec les arguments incluant --run-id <runId>
  AND    les arguments d'origine sont préservés : ["--name", "x", "--run-id", "<runId>"]
  (le runId permet à ada-core de le réinjecter dans ses events IPC)

---

SPEC 03 — Spawner un run sans conversationId
  GIVEN  workspace "ws-abc" existe
  WHEN   POST /api/runs { "pipeline": "review", "args": [], "workspaceId": "ws-abc" }
  THEN   202 avec { runId, status: "starting" }
  AND    run_links créé avec conversation_id = null
  AND    aucun message system ajouté (pas de conversation cible)

---

SPEC 04 — Pipeline invalide → 400
  GIVEN  IPC connecté
  WHEN   POST /api/runs { "pipeline": "", "workspaceId": "ws-abc" }
  THEN   400 { error: "VALIDATION_ERROR", message: "pipeline is required" }

---

SPEC 05 — WorkspaceId manquant → 400
  WHEN   POST /api/runs { "pipeline": "feature" }
  THEN   400 { error: "VALIDATION_ERROR", message: "workspaceId is required" }

---

SPEC 06 — Workspace inexistant → 404
  WHEN   POST /api/runs { "pipeline": "feature", "workspaceId": "inexistant" }
  THEN   404 { error: "WORKSPACE_NOT_FOUND" }

---

SPEC 07 — ada-core absent → 503
  GIVEN  IPC non connecté (ada-core offline)
  WHEN   POST /api/runs { "pipeline": "feature", "workspaceId": "ws-abc" }
  THEN   503 {
           error: "ADA_CORE_OFFLINE",
           message: "Ada-core is not reachable. Start ada-core and retry."
         }
  AND    aucun run_links créé en DB

---

## SUITE : Lecture de statut

---

SPEC 08 — Récupérer statut d'un run en cours
  GIVEN  run_links "feat-123" avec status="running", pipeline="feature", workspace_id="ws-abc"
  WHEN   GET /api/runs/feat-123
  THEN   200 {
           runId: "feat-123",
           pipeline: "feature",
           status: "running",
           workspaceId: "ws-abc",
           conversationId: "conv-xyz",
           totalCost: null,
           completedAt: null,
           createdAt: "<iso>"
         }

---

SPEC 09 — Récupérer statut d'un run complété
  GIVEN  run_links "feat-123" avec status="completed", total_cost=0.15, completed_at="2026-05-30T12:00:00Z"
  WHEN   GET /api/runs/feat-123
  THEN   200 { status: "completed", totalCost: 0.15, completedAt: "2026-05-30T12:00:00Z" }

---

SPEC 10 — Run non trouvé → 404
  WHEN   GET /api/runs/inexistant
  THEN   404 { error: "RUN_NOT_FOUND" }

---

SPEC 11 — Lister les runs d'un workspace
  GIVEN  3 run_links pour "ws-abc" (2 completed, 1 running)
  WHEN   GET /api/runs?workspaceId=ws-abc
  THEN   200 { items: [<3 runs>], total: 3 }
  AND    triés par created_at DESC

---

SPEC 12 — Lister runs avec filtre status
  GIVEN  3 run_links pour "ws-abc" (2 completed, 1 running)
  WHEN   GET /api/runs?workspaceId=ws-abc&status=running
  THEN   200 { items: [<1 run running>], total: 1 }

---

SPEC 13 — Lister runs avec filtre conversationId
  GIVEN  conversation "conv-xyz" avec 2 runs, workspace avec 5 runs au total
  WHEN   GET /api/runs?conversationId=conv-xyz
  THEN   200 { items: [<2 runs>], total: 2 }

---

## SUITE : Statut en temps réel via events IPC

---

SPEC 14 — Statut phase mis à jour via event IPC run.phase.started
  GIVEN  run_links "feat-123" existe avec status="running"
  WHEN   le mock IPC émet { type: "run.phase.started", runId: "feat-123", phaseId: "backend" }
  THEN   GET /api/runs/feat-123 retourne { status: "running" }
  AND    WS broadcast { type: "phase.started", runId: "feat-123", phaseId: "backend" }
  (note : pas de table phases persistée, le statut est géré en mémoire et via WS)

---

SPEC 15 — run_links.status=completed après run.done
  GIVEN  run_links "feat-123" existe avec status="running"
  WHEN   le mock IPC émet { type: "run.done", runId: "feat-123", status: "completed", totalCost: 0.10, summary: "OK" }
  THEN   GET /api/runs/feat-123 retourne { status: "completed", totalCost: 0.10 }

---

## SUITE : Annulation

---

SPEC 16 — Annuler un run en cours
  GIVEN  run_links "feat-123" avec status="running"
  AND    le process ada-core spawné pour ce run est en cours (pid mocké)
  WHEN   DELETE /api/runs/feat-123
  THEN   204
  AND    le process reçoit SIGTERM (vérifié via spy sur process.kill ou child.kill)
  AND    run_links.status = "cancelled"
  AND    WS broadcast vers room workspace : { type: "run.cancelled", runId: "feat-123" }

---

SPEC 17 — Annuler un run déjà terminé → 204 idempotent
  GIVEN  run_links "feat-123" avec status="completed"
  WHEN   DELETE /api/runs/feat-123
  THEN   204
  AND    run_links.status reste "completed" (pas modifié si statut final)
  AND    aucun SIGTERM envoyé (process déjà terminé)

---

SPEC 18 — Annuler un run déjà annulé → 204 idempotent
  GIVEN  run_links "feat-123" avec status="cancelled"
  WHEN   DELETE /api/runs/feat-123
  THEN   204
  AND    run_links.status reste "cancelled"

---

SPEC 19 — Annuler run non trouvé → 404
  WHEN   DELETE /api/runs/inexistant
  THEN   404 { error: "RUN_NOT_FOUND" }

---

## SUITE : Robustesse et cas limites

---

SPEC 20 — Run orphelin (run_id IPC reçu mais pas en run_links) → ignoré
  GIVEN  aucun run_links "orphan-999" en DB
  WHEN   le mock IPC émet { type: "run.done", runId: "orphan-999", status: "completed", totalCost: 0, summary: "" }
  THEN   aucune DB write effectuée
  AND    un log WARN émis : "IPC: run.done for unknown runId: orphan-999"
  AND    aucun crash

---

SPEC 21 — Deux runs simultanés pour le même workspace
  GIVEN  workspace "ws-abc" avec IPC connecté
  WHEN   POST /api/runs (run A) et POST /api/runs (run B) envoyés en parallèle
  THEN   deux runIds différents retournés
  AND    deux enregistrements run_links distincts en DB
  AND    les deux processus ada-core sont spawnés indépendamment

---

SPEC 22 — args contenant des caractères spéciaux transmis sans injection
  GIVEN  IPC connecté
  WHEN   POST /api/runs { "pipeline": "feature", "args": ["--name", "stripe; rm -rf /"], "workspaceId": "ws-abc" }
  THEN   202
  AND    child_process.spawn appelé avec args comme tableau (pas de shell injection possible)
  AND    spawn est appelé avec tableau d'arguments, pas avec shell: true

---

SPEC 23 — Timeout de spawn : ada-core ne répond pas dans les 30 secondes
  GIVEN  IPC connecté mais mock ada-core ne répond pas après spawn
  AND    ADA_RUN_TIMEOUT=30000
  WHEN   POST /api/runs { "pipeline": "feature", "workspaceId": "ws-abc" }
  AND    30 secondes s'écoulent sans event run.started reçu
  THEN   run_links.status = "failed"
  AND    WS broadcast { type: "run.cancelled", runId, reason: "timeout" }
  AND   un log ERROR émis : "Run <runId> timed out after 30s"
