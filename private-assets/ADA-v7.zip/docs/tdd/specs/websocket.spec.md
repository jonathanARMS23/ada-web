# Spec : WebSocket Gateway

Service : `src/ws/`
URL de connexion : ws://localhost:3001/ws?token=<jwt>
Protocole : JSON over WebSocket (messages encodés en JSON, un objet par message)
Auth : token JWT en query string (pas de cookie, pas de header WS standard)

En test : serveur Fastify démarré sur port aléatoire, client ws (npm) pour les connexions

---

## SUITE : Connexion et authentification

---

SPEC 01 — Connexion avec token valide
  GIVEN  ada-api démarré
  AND    token JWT valide T1 en sessions
  WHEN   WebSocket connect ws://localhost:<port>/ws?token=<T1>
  THEN   handshake HTTP retourne 101 Switching Protocols
  AND    dans les 500ms, client reçoit :
         { type: "connected", workspaceId: null, ts: "<iso-8601>" }

---

SPEC 02 — Connexion sans token → fermeture code 4001
  WHEN   WebSocket connect ws://localhost:<port>/ws (sans query string token)
  THEN   la connexion est fermée avec code 4001
  AND    reason : "UNAUTHORIZED"

---

SPEC 03 — Connexion avec token invalide → fermeture code 4001
  WHEN   WebSocket connect ws://localhost:<port>/ws?token=invalid-jwt
  THEN   la connexion est fermée avec code 4001
  AND    reason : "INVALID_TOKEN"

---

SPEC 04 — Connexion avec token expiré → fermeture code 4001
  WHEN   WebSocket connect ws://localhost:<port>/ws?token=<expired-jwt>
  THEN   la connexion est fermée avec code 4001
  AND    reason : "TOKEN_EXPIRED"

---

SPEC 05 — Connexion avec token révoqué (absent de sessions) → fermeture code 4001
  GIVEN  token JWT valide en signature mais supprimé de sessions
  WHEN   WebSocket connect avec ce token
  THEN   fermeture avec code 4001 et reason : "TOKEN_REVOKED"

---

SPEC 06 — Plusieurs connexions simultanées avec le même token
  GIVEN  token T1 valide
  WHEN   2 clients WebSocket se connectent avec T1
  THEN   les 2 connexions sont acceptées (pas de limite par token)
  AND    chaque client reçoit { type: "connected" }

---

## SUITE : Rooms workspace

---

SPEC 07 — Rejoindre un workspace room
  GIVEN  client WS connecté (message "connected" reçu)
  AND    workspace "ws-abc" existe
  WHEN   client envoie : { "type": "workspace.join", "payload": { "workspaceId": "ws-abc" } }
  THEN   client reçoit : { "type": "workspace.joined", "workspaceId": "ws-abc" }
  AND    le client est inscrit dans la room "ws-abc" (reçoit les broadcasts futurs)

---

SPEC 08 — Rejoindre workspace inexistant → erreur WS
  GIVEN  client WS connecté
  WHEN   client envoie { "type": "workspace.join", "payload": { "workspaceId": "inexistant" } }
  THEN   client reçoit : { "type": "error", "code": "WORKSPACE_NOT_FOUND" }
  AND    le client n'est pas inscrit dans une room

---

SPEC 09 — Changer de workspace room
  GIVEN  client WS dans room "ws-abc"
  WHEN   client envoie { "type": "workspace.join", "payload": { "workspaceId": "ws-xyz" } }
  THEN   client reçoit { "type": "workspace.joined", "workspaceId": "ws-xyz" }
  AND    le client est retiré de room "ws-abc"
  AND    le client est inscrit dans room "ws-xyz"
  AND    les broadcasts vers "ws-abc" ne lui parviennent plus

---

SPEC 10 — Quitter explicitement une room
  GIVEN  client dans room "ws-abc"
  WHEN   client envoie { "type": "workspace.leave" }
  THEN   client reçoit { "type": "workspace.left" }
  AND    le client n'est plus dans aucune room

---

## SUITE : Broadcasting

---

SPEC 11 — Broadcast limité aux membres de la room
  GIVEN  client A dans room "ws-abc"
  AND    client B dans room "ws-xyz"
  AND    client C non inscrit dans aucune room
  WHEN   un événement run.done est émis pour workspace "ws-abc"
  THEN   client A reçoit { type: "run.done", runId: "...", cost: N, summary: "..." }
  AND    client B NE reçoit PAS l'événement
  AND    client C NE reçoit PAS l'événement

---

SPEC 12 — Broadcast vers plusieurs clients dans la même room
  GIVEN  clients A, B, C dans room "ws-abc"
  WHEN   un événement run.done est broadcasté vers "ws-abc"
  THEN   A, B et C reçoivent tous l'événement

---

SPEC 13 — Broadcast message.new
  GIVEN  client A dans room "ws-abc"
  AND    conversation "conv-xyz" appartient à "ws-abc"
  WHEN   POST /api/conversations/conv-xyz/messages { role: "user", content: "Hello" }
  THEN   client A reçoit :
         { type: "message.new", conversationId: "conv-xyz", message: { id, role: "user", content: "Hello", createdAt } }

---

SPEC 14 — Broadcast phase.progress (log temps réel)
  GIVEN  client A dans room "ws-abc"
  AND    run "feat-123" appartient à "ws-abc"
  WHEN   IPC consumer reçoit run.phase.log pour "feat-123"
  THEN   client A reçoit :
         { type: "phase.progress", runId: "feat-123", phaseId: "backend", log: "...", ts: "<iso>" }

---

## SUITE : Heartbeat

---

SPEC 15 — Heartbeat envoyé toutes les 30 secondes
  GIVEN  ADA_WS_HEARTBEAT_INTERVAL=500 (réduit pour le test)
  AND    client WS connecté
  WHEN   500ms s'écoulent
  THEN   client reçoit { type: "heartbeat", ts: "<iso>" }
  WHEN   encore 500ms s'écoulent
  THEN   client reçoit un deuxième { type: "heartbeat" }

---

SPEC 16 — Heartbeat arrêté si client déconnecté
  GIVEN  ADA_WS_HEARTBEAT_INTERVAL=100
  AND    client WS connecté
  WHEN   client ferme sa connexion WebSocket
  AND    300ms s'écoulent
  THEN   aucun heartbeat n'est envoyé (plus de destinataire)
  AND   aucune erreur "send to closed socket" n'est levée

---

## SUITE : Fermeture et nettoyage

---

SPEC 17 — Fermeture propre côté client
  GIVEN  client A dans room "ws-abc"
  AND    client B dans room "ws-abc"
  WHEN   client A ferme sa connexion WebSocket (code 1000)
  THEN   ada-api supprime client A de la room sans erreur
  AND    client B reste inscrit dans la room "ws-abc"
  AND    le broadcast suivant vers "ws-abc" parvient à B mais pas à A (connexion fermée)

---

SPEC 18 — Déconnexion abrupte (réseau coupé) gérée sans crash
  GIVEN  client WS connecté
  WHEN   la connexion TCP est détruite abruptement (socket.destroy() côté client)
  THEN   ada-api détecte l'événement "close" ou "error" sur le socket
  AND    le client est retiré de toutes les rooms
  AND    ada-api ne crash pas

---

SPEC 19 — Nettoyage room vide après dernière déconnexion
  GIVEN  room "ws-abc" avec 1 seul client
  WHEN   ce client se déconnecte
  THEN   la room "ws-abc" est supprimée de la mémoire (Map rooms vide)
  AND    un broadcast ultérieur vers "ws-abc" ne lève pas d'erreur (room absente tolérée)

---

## SUITE : Messages clients → serveur

---

SPEC 20 — Spawn run via WS
  GIVEN  client dans room "ws-abc"
  AND    ada-core IPC connecté
  WHEN   client envoie :
         { "type": "run.spawn", "payload": { "pipeline": "feature", "args": ["--name", "x"], "conversationId": "conv-xyz" } }
  THEN   comportement identique à POST /api/runs (run créé, message system, etc.)
  AND    client reçoit : { type: "run.started", runId: "<uuid>", pipeline: "feature" }

---

SPEC 21 — Spawn run via WS sans être dans une room → erreur
  GIVEN  client WS connecté mais pas dans une room
  WHEN   client envoie { "type": "run.spawn", "payload": { ... } }
  THEN   client reçoit : { "type": "error", "code": "NO_WORKSPACE", "message": "Join a workspace first" }

---

SPEC 22 — Message client de type inconnu → erreur WS
  GIVEN  client WS connecté
  WHEN   client envoie { "type": "unknown.action" }
  THEN   client reçoit : { "type": "error", "code": "UNKNOWN_MESSAGE_TYPE" }
  AND    la connexion reste ouverte

---

SPEC 23 — Message client JSON malformé → fermeture ou erreur
  GIVEN  client WS connecté
  WHEN   client envoie une string non-JSON : "not-json"
  THEN   client reçoit : { "type": "error", "code": "INVALID_JSON" }
  AND    la connexion reste ouverte (pas de fermeture brutale)

---

## SUITE : Métriques et observabilité

---

SPEC 24 — Compteur de connexions actives
  GIVEN  ada-api démarré
  WHEN   GET /api/health
  THEN   la réponse inclut { ws: { activeConnections: N } }
  AND    N correspond au nombre de clients WS actuellement connectés

---

SPEC 25 — Compteur de rooms actives
  GIVEN  3 clients dans 2 rooms différentes
  WHEN   GET /api/health
  THEN   la réponse inclut { ws: { activeRooms: 2, activeConnections: 3 } }
