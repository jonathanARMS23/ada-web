# Spec : Workspaces

Service : `src/workspaces/`
Endpoints : POST /api/workspaces · GET /api/workspaces · GET /api/workspaces/:id
            PATCH /api/workspaces/:id · DELETE /api/workspaces/:id · GET /api/workspaces/:id/stats
Auth : toutes les routes requièrent un token valide (middleware authMiddleware)

---

## SUITE : Création

---

SPEC 01 — Créer un workspace minimal
  GIVEN  auth token valide
  WHEN   POST /api/workspaces { "name": "Mon SaaS" }
  THEN   201 avec body :
         { id: "<uuid>", name: "Mon SaaS", slug: "mon-saas", profile: "claude-pro",
           color: "#6366f1", pinned: false, archived: false, runCount: 0,
           createdAt: "<iso>", updatedAt: "<iso>" }
  AND    id est un UUID v4 valide
  AND    slug est généré depuis name : lowercase, accents supprimés, espaces→tirets
  AND    profile prend la valeur par défaut "claude-pro"
  AND    color prend la valeur par défaut "#6366f1"
  AND    createdAt et updatedAt sont identiques à la création

---

SPEC 02 — Créer un workspace avec tous les champs
  GIVEN  auth token valide
  WHEN   POST /api/workspaces { "name": "Backend API", "profile": "claude-dev", "color": "#10b981" }
  THEN   201 avec { name: "Backend API", slug: "backend-api", profile: "claude-dev", color: "#10b981" }

---

SPEC 03 — Slug auto-généré depuis name avec caractères spéciaux
  GIVEN  auth token valide
  WHEN   POST /api/workspaces { "name": "Projet Éolien & Solaire!" }
  THEN   201 avec { slug: "projet-eolien-solaire" }
  (accents normalisés, caractères non alphanum supprimés, tirets multiples collapsés)

---

SPEC 04 — Slug unique : collision résolue avec suffix numérique
  GIVEN  un workspace avec slug "mon-saas" existe déjà
  WHEN   POST /api/workspaces { "name": "Mon SaaS" }
  THEN   201 avec { slug: "mon-saas-2" }

---

SPEC 05 — Slug unique : plusieurs collisions
  GIVEN  les workspaces "mon-saas", "mon-saas-2", "mon-saas-3" existent
  WHEN   POST /api/workspaces { "name": "Mon SaaS" }
  THEN   201 avec { slug: "mon-saas-4" }

---

SPEC 06 — Nom manquant → 400
  GIVEN  auth token valide
  WHEN   POST /api/workspaces {}
  THEN   400 { error: "VALIDATION_ERROR", message: "name is required", field: "name" }

---

SPEC 07 — Nom trop long → 400
  GIVEN  auth token valide
  WHEN   POST /api/workspaces { "name": "<chaîne de 256 caractères>" }
  THEN   400 { error: "VALIDATION_ERROR", message: "name must not exceed 255 characters" }

---

SPEC 08 — Couleur invalide → 400
  GIVEN  auth token valide
  WHEN   POST /api/workspaces { "name": "Test", "color": "rouge" }
  THEN   400 { error: "VALIDATION_ERROR", message: "color must be a valid hex color (#rrggbb)" }

---

## SUITE : Lecture

---

SPEC 09 — Lister workspaces — résultat vide
  GIVEN  aucun workspace en DB
  WHEN   GET /api/workspaces
  THEN   200 { items: [], total: 0 }

---

SPEC 10 — Lister workspaces — ordre updatedAt DESC
  GIVEN  3 workspaces créés à des instants différents :
         W1 (le plus ancien), W2, W3 (le plus récent)
  WHEN   GET /api/workspaces
  THEN   200 { items: [W3, W2, W1], total: 3 }
  AND    chaque item contient : { id, name, slug, profile, color, pinned, archived, runCount, lastActivity, createdAt, updatedAt }

---

SPEC 11 — Lister workspaces — filtre archived=false par défaut
  GIVEN  2 workspaces actifs et 1 workspace archivé
  WHEN   GET /api/workspaces
  THEN   200 { items: [<2 workspaces actifs>], total: 2 }
  (les workspaces archivés sont exclus par défaut)

---

SPEC 12 — Lister workspaces — inclure archivés avec ?archived=true
  GIVEN  2 workspaces actifs et 1 workspace archivé
  WHEN   GET /api/workspaces?archived=true
  THEN   200 { items: [<3 workspaces>], total: 3 }

---

SPEC 13 — Lister workspaces — filtre pinned=true
  GIVEN  1 workspace pinned et 2 workspaces non-pinned
  WHEN   GET /api/workspaces?pinned=true
  THEN   200 { items: [<1 workspace pinned>], total: 1 }

---

SPEC 14 — lastActivity calculé depuis dernière conversation active
  GIVEN  workspace "ws-abc" avec une conversation dont updated_at = "2026-05-30T10:00:00Z"
  WHEN   GET /api/workspaces
  THEN   l'item "ws-abc" contient { lastActivity: "2026-05-30T10:00:00Z" }

---

SPEC 15 — Récupérer un workspace par ID
  GIVEN  workspace "ws-abc" existe
  WHEN   GET /api/workspaces/ws-abc
  THEN   200 avec le workspace complet (tous les champs de SPEC 10)

---

SPEC 16 — Workspace non trouvé → 404
  WHEN   GET /api/workspaces/inexistant-id
  THEN   404 { error: "WORKSPACE_NOT_FOUND", message: "Workspace not found" }

---

SPEC 17 — Récupérer par slug
  GIVEN  workspace avec slug "mon-saas" existe
  WHEN   GET /api/workspaces/mon-saas
  THEN   200 avec le workspace (lookup par slug si le paramètre n'est pas un UUID)

---

## SUITE : Modification

---

SPEC 18 — Modifier le nom d'un workspace
  GIVEN  workspace "ws-abc" avec name="Ancien Nom"
  WHEN   PATCH /api/workspaces/ws-abc { "name": "Nouveau Nom" }
  THEN   200 avec { name: "Nouveau Nom", slug: "ancien-nom" }
  AND    updatedAt est refreshé (timestamp actuel)
  AND    le slug reste inchangé (le slug est immutable après création)

---

SPEC 19 — Modifier la couleur
  GIVEN  workspace "ws-abc" existe
  WHEN   PATCH /api/workspaces/ws-abc { "color": "#ef4444" }
  THEN   200 avec { color: "#ef4444" }

---

SPEC 20 — Pinner un workspace
  GIVEN  workspace "ws-abc" avec pinned=false
  WHEN   PATCH /api/workspaces/ws-abc { "pinned": true }
  THEN   200 avec { pinned: true }

---

SPEC 21 — PATCH partiel : champs non fournis inchangés
  GIVEN  workspace "ws-abc" avec { name: "N", profile: "claude-pro", color: "#aaa" }
  WHEN   PATCH /api/workspaces/ws-abc { "color": "#bbb" }
  THEN   200 avec { name: "N", profile: "claude-pro", color: "#bbb" }
  (name et profile sont inchangés)

---

SPEC 22 — PATCH workspace non trouvé → 404
  WHEN   PATCH /api/workspaces/inexistant { "name": "X" }
  THEN   404 { error: "WORKSPACE_NOT_FOUND" }

---

SPEC 23 — PATCH avec champs invalides → 400
  WHEN   PATCH /api/workspaces/ws-abc { "color": "not-a-color" }
  THEN   400 { error: "VALIDATION_ERROR" }

---

## SUITE : Suppression

---

SPEC 24 — Supprimer workspace
  GIVEN  workspace "ws-abc" existe
  WHEN   DELETE /api/workspaces/ws-abc
  THEN   204 No Content
  AND    GET /api/workspaces/ws-abc retourne 404

---

SPEC 25 — Suppression en cascade des conversations et messages
  GIVEN  workspace "ws-abc" avec 3 conversations, chaque conversation ayant 5 messages
  WHEN   DELETE /api/workspaces/ws-abc
  THEN   204
  AND    les 3 conversations sont supprimées (CASCADE DB)
  AND    les 15 messages sont supprimés (CASCADE DB)
  AND    SELECT COUNT(*) FROM conversations WHERE workspace_id='ws-abc' = 0
  AND    SELECT COUNT(*) FROM conversations_messages WHERE conversation_id IN (...) = 0

---

SPEC 26 — Suppression nullifie workspace_id dans run_links (SET NULL)
  GIVEN  workspace "ws-abc" avec 2 run_links liés (workspace_id="ws-abc")
  WHEN   DELETE /api/workspaces/ws-abc
  THEN   204
  AND    les 2 run_links ont workspace_id = null (pas supprimés, historique conservé)
  AND    run_links.conversation_id reste inchangé

---

SPEC 27 — Supprimer workspace non trouvé → 404
  WHEN   DELETE /api/workspaces/inexistant
  THEN   404 { error: "WORKSPACE_NOT_FOUND" }

---

## SUITE : Stats

---

SPEC 28 — Stats workspace vide
  GIVEN  workspace "ws-abc" sans conversations ni runs
  WHEN   GET /api/workspaces/ws-abc/stats
  THEN   200 { totalCost: 0, totalRuns: 0, totalMessages: 0, totalTokens: 0,
               conversationCount: 0, lastRunAt: null }

---

SPEC 29 — Stats workspace avec données
  GIVEN  workspace "ws-abc" avec :
         - 2 run_links complétés : total_cost=0.05 + 0.10
         - 3 conversations
         - 15 messages en tout
         - total_tokens=5000 (somme des metadata.tokens des messages)
         - last run_links.completed_at = "2026-05-30T12:00:00Z"
  WHEN   GET /api/workspaces/ws-abc/stats
  THEN   200 {
           totalCost: 0.15,
           totalRuns: 2,
           totalMessages: 15,
           totalTokens: 5000,
           conversationCount: 3,
           lastRunAt: "2026-05-30T12:00:00Z"
         }

---

SPEC 30 — Stats workspace non trouvé → 404
  WHEN   GET /api/workspaces/inexistant/stats
  THEN   404 { error: "WORKSPACE_NOT_FOUND" }
