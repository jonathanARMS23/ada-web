#!/usr/bin/env bash
# =============================================================
# init-project.sh — Initialise la mémoire d'un nouveau projet
#
# Usage : bash init-project.sh <project_name> "<stack>"
# Ex    : bash init-project.sh my-saas "NestJS + Next.js + PostgreSQL"
#         bash init-project.sh api-service "DRF + PostgreSQL"
# =============================================================

set -e

PROJECT="${1:?Usage: init-project.sh <project_name> \"<stack>\"}"
STACK="${2:-À compléter}"
TARGET="${CLAUDE_CONFIG_DIR:-$HOME/.claude-perso}"
PROJECT_DIR="$TARGET/.claude/memory/projects/$PROJECT"

GREEN='\033[0;32m'; CYAN='\033[0;36m'; NC='\033[0m'
ok()  { echo -e "${GREEN}✓${NC} $1"; }
log() { echo -e "${CYAN}→${NC} $1"; }

log "Initialisation du projet : $PROJECT"
log "Stack : $STACK"

# Vérifier que le projet n'existe pas déjà
if [ -d "$PROJECT_DIR" ]; then
  echo "⚠  Le projet '$PROJECT' existe déjà dans $PROJECT_DIR"
  echo "   Utiliser --force pour réinitialiser"
  [ "$3" = "--force" ] || exit 0
fi

mkdir -p "$PROJECT_DIR/archive"

cat > "$PROJECT_DIR/context.md" << CONTEXT
# Context — $(echo "$PROJECT" | tr '[:lower:]' '[:upper:]')

> Mis à jour automatiquement par memory-manager.js.

## Stack
$STACK

## Dernières modifications

## Décisions récentes

## Blockers actifs
CONTEXT
ok "context.md créé"

cat > "$PROJECT_DIR/stories.md" << STORIES
# Sprint — $PROJECT

> Mis à jour par /fetch-sprint.

## En cours

## À faire

## Bloqué
STORIES
ok "stories.md créé"

echo ""
echo -e "${GREEN}✅ Projet '$PROJECT' initialisé dans $PROJECT_DIR${NC}"
echo ""
echo "Démarrer le workspace :"
echo "  dev-ai $PROJECT"
echo ""
echo "Dans Claude Code :"
echo "  /fetch-sprint     # charger le sprint"
echo "  /memory show      # vérifier le contexte"
