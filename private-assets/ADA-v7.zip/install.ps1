#Requires -Version 5.1
<#
.SYNOPSIS
  AI Dev Assistant — installeur local Windows (PowerShell).

.DESCRIPTION
  Équivalent Windows d'install.sh, pour un poste qui a DÉJÀ le code source
  (clone git ou zip fourni). CLI-only par défaut : ada-ui (Next.js) dépend de
  node-pty, un module natif qui exige node-gyp + Visual Studio Build Tools
  ("Desktop development with C++") sur Windows — un point de friction majeur
  qu'on ne veut jamais déclencher sans une décision explicite. Voir -WithUI.

  ORCHESTRATEUR MINCE PAR CONCEPTION : ce script ne réimplémente PAS la
  logique de décision de synchronisation (neuf / à jour / personnalisé par le
  client / déprécié) — il invoque les MÊMES scripts Node déjà utilisés par
  install.sh :
    .claude/scripts/generate-ada-manifest.js   — génère le manifeste ADR-024
    .claude/scripts/manifest-files-for.js      — liste les fichiers d'un sous-arbre
    .claude/scripts/sync-content-dir.js        — applique le plan de sync (mode content/prune)
  Ces trois scripts sont du Node pur, déjà cross-plateforme : ce fichier .ps1
  ne fait que les enchaîner dans le bon ordre et copier les fichiers qu'ils
  désignent — exactement le rôle que joue la branche "sans rsync" d'install.sh
  (_copy_from_list), qui est déjà la voie portable sans dépendance système.

  Format ~/.ada.json IDENTIQUE à celui d'install.sh (mêmes clés : activeProfile,
  sourceDir, uiDir, installedProfiles, installedAt, version) — un profil créé
  par l'un des deux installeurs doit rester lisible par l'autre. La lecture/
  écriture de ce fichier est déléguée à `node -e` avec le MÊME JS que la
  version bash (voir Write-AdaConfig / Merge-SettingsJson plus bas), pour
  garantir un JSON.stringify identique plutôt que de risquer une dérive de
  format en réécrivant la même logique deux fois dans deux langages.

  RÈGLE PROJET : ne jamais hardcoder un nom de profil réel (claude-pro,
  claude-jarvis, …). Le seul nom en dur dans ce script est le même défaut
  neutre "claude-ada" qu'utilise install.sh pour un poste vierge — jamais un
  profil d'une machine ou d'un utilisateur précis.

  PÉRIMÈTRE VOLONTAIREMENT PLUS ÉTROIT QUE install.sh (documenté, pas un oubli) :
    - Pas de détection fine "profils déjà connus vs expansion de périmètre"
      (ADR-024 E1-B) : ce script détecte les profils sur disque et, en mode
      interactif avec plusieurs profils, demande une sélection simple.
    - --with-server (ancien backend Fastify, DÉPRÉCIÉ côté bash, ada-ui ne s'y
      connecte plus) n'est pas porté ici : aucune valeur ajoutée à dupliquer
      un chemin mort.
    - Pas d'intégration Obsidian interactive (setup_obsidian) ni de restauration
      auto de l'UI après rebuild (UI_WAS_RUNNING) : périmètre CLI-only par défaut,
      ces deux à-côtés concernent uniquement ada-ui.
  Le CŒUR fonctionnel (Node >=22, profil ~/.claude-<nom>/, ~/.ada.json au même
  format, CLAUDE.md, manifeste ADR-024, sync coordinator/agents/skills/…,
  settings.json, backend ada-api-nest, CLI ada) est couvert.

.PARAMETER ProfileName
  Installe sur le profil ~/.<nom> (le crée s'il n'existe pas). Équivalent de
  --profile côté install.sh. (Nommé ProfileName et non "Profile" pour ne pas
  masquer la variable automatique $Profile de PowerShell.)

.PARAMETER All
  Installe sur tous les profils ~/.claude-*/ détectés, sans question.

.PARAMETER NonInteractive
  Aucune question (CI, provisioning). Crée ~/.claude-ada si aucun profil n'existe.

.PARAMETER WithUI
  Installe aussi l'interface web ada-ui (Next.js + node-pty). Équivalent :
  $env:ADA_WITH_UI = '1' (mêmes noms de variable que côté install.sh, où
  ADA_WITH_UI=1|true a le même effet que --with-ui).

.PARAMETER DryRun
  Simule l'installation : affiche ce qui serait fait, n'écrit rien nulle part
  (aucun profil, ~/.ada.json, profil PowerShell, build npm inclus).

.PARAMETER Version
  Affiche la version et quitte.

.PARAMETER Help
  Affiche cette aide et quitte.

.EXAMPLE
  .\install.ps1
.EXAMPLE
  .\install.ps1 -ProfileName claude-ada
.EXAMPLE
  .\install.ps1 -NonInteractive
.EXAMPLE
  .\install.ps1 -WithUI
#>
[CmdletBinding()]
param(
  [string]$ProfileName,
  [switch]$All,
  [switch]$NonInteractive,
  [switch]$WithUI,
  [switch]$DryRun,
  [switch]$Version,
  [Alias('h')][switch]$Help
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

# ─── Chemins de base ──────────────────────────────────────────────────────────
$SourceDir  = $PSScriptRoot
$ClaudeDir  = Join-Path $SourceDir '.claude'
$AdaConfig  = Join-Path $HOME '.ada.json'
$VersionFile = Join-Path $SourceDir 'VERSION'
$AdaVersion  = if (Test-Path $VersionFile) { (Get-Content $VersionFile -Raw).Trim() } else { 'inconnue' }

$ManifestFile = Join-Path $ClaudeDir '.ada-manifest.json'
$AppliedManifestName = '.ada-manifest.applied.json'

# Mêmes chemins que MANIFEST_MUTABLE dans install.sh (bash) — fichiers livrés à
# double nature (référence versionnée + état accumulé côté client), exclus du
# sync "system dir" et traités par sync-content-dir.js --mode content.
$ManifestMutable = @(
  'coordinator/pipelines.json',
  'coordinator/witness-history.jsonl',
  'coordinator/witness-fixes.json',
  'coordinator/agent-audit-baseline.json',
  'coordinator/flywheel-baseline.json'
)
$SystemDirs  = @('coordinator', 'hooks', 'workers', 'tests', 'bin', 'docs', 'scripts', 'plugins-examples', 'lib', 'commands')
$ContentDirs = @('agents', 'skills', 'teams', 'benchmarks', 'templates', 'memory', 'archives')

$ProfileNameRe = '^[a-z0-9][a-z0-9-]{0,30}$'
$DEFAULT_PROFILE_NAME = 'claude-ada'  # défaut neutre — jamais un profil réel, voir docstring.

# --with-ui : la variable d'env ADA_WITH_UI (mêmes noms/valeurs que côté bash)
# a le même effet que -WithUI, pour le provisioning non-interactif.
if (-not $WithUI -and ($env:ADA_WITH_UI -eq '1' -or $env:ADA_WITH_UI -eq 'true')) {
  $WithUI = $true
}

function Write-Ok    ($msg) { Write-Host "OK  $msg" -ForegroundColor Green }
function Write-Info2 ($msg) { Write-Host "->  $msg" -ForegroundColor Cyan }
function Write-Warn2 ($msg) { Write-Host "!!  $msg" -ForegroundColor Yellow }
function Write-Err2  ($msg) { Write-Host "x   $msg" -ForegroundColor Red }
function Write-Dry   ($msg) { Write-Host "[dry-run] $msg" -ForegroundColor Cyan }

function Show-Usage {
  @"
AI Dev Assistant — installeur Windows v$AdaVersion

Usage : .\install.ps1 [options]

Options :
  -ProfileName <nom>   Installe sur le profil ~/.<nom> (le crée si absent)
  -All                 Installe sur tous les profils ~/.claude-*/ détectés
  -NonInteractive      Aucune question (CI, provisioning)
  -WithUI              Installe aussi l'interface web ada-ui (Next.js + node-pty).
                        Nécessite Visual Studio Build Tools (workload "Desktop
                        development with C++") pour compiler node-pty.
                        Équivalent : `$env:ADA_WITH_UI = '1'`
  -DryRun              Simule : affiche ce qui serait fait, n'écrit rien
  -Version             Affiche la version et quitte
  -Help                Affiche cette aide

Exemples :
  .\install.ps1                        # interactif, CLI-only
  .\install.ps1 -ProfileName claude-ada
  .\install.ps1 -NonInteractive
  .\install.ps1 -WithUI

Vérifier l'installation ensuite : ada doctor
Documentation client : docs\INSTALL-CLIENT.md
"@
}

if ($Help) { Show-Usage; exit 0 }
if ($Version) { Write-Output $AdaVersion; exit 0 }

# ─── Bannière ─────────────────────────────────────────────────────────────────
function Show-Banner {
  Write-Host ''
  Write-Host '   ___    ____    ___  ' -ForegroundColor Cyan
  Write-Host '  / _ |  / __ \  / _ | ' -ForegroundColor Cyan
  Write-Host ' / __ | / /_/ / / __ | ' -ForegroundColor Cyan
  Write-Host '/_/ |_| \____/ /_/ |_| ' -ForegroundColor Cyan
  Write-Host "AI Dev Assistant — v$AdaVersion" -ForegroundColor White
  Write-Host 'Installeur Windows (PowerShell)' -ForegroundColor Blue
  Write-Host ''
}

# ─── Prérequis ────────────────────────────────────────────────────────────────
# Aucune installation automatique de Node : on informe et on renvoie vers
# nodejs.org, exactement comme install.sh (bash) le fait pour macOS/Linux.
function Test-Prerequisites {
  $nodeCmd = Get-Command node -ErrorAction SilentlyContinue
  if (-not $nodeCmd) {
    Write-Err2 'Node.js introuvable. Installe Node.js >= 22 : https://nodejs.org/'
    exit 1
  }

  $nodeMajor = [int](& node -e "process.stdout.write(String(process.versions.node.split('.')[0]))")
  if ($nodeMajor -lt 22) {
    $current = (& node --version)
    Write-Err2 "Node.js >= 22 requis (version actuelle : $current)"
    Write-Host '   Télécharge la version 22+ : https://nodejs.org/' -ForegroundColor Yellow
    Write-Host '   (ou via nvm-windows : nvm install 22 && nvm use 22)' -ForegroundColor Yellow
    exit 1
  }
  Write-Ok "Node.js $(& node --version)"

  # Dépendances non bloquantes — avertissement seulement, comme côté bash.
  $claudeCmd = Get-Command claude -ErrorAction SilentlyContinue
  if ($claudeCmd) {
    Write-Ok "Claude Code CLI $(& claude --version 2>$null | Select-Object -First 1)"
  } else {
    Write-Warn2 "Claude Code CLI absent — requis pour 'ada launch' et l'exécution des agents"
    Write-Host '   Installe-le : npm i -g @anthropic-ai/claude-code' -ForegroundColor Yellow
  }

  if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    Write-Warn2 'git absent — requis pour les mises à jour (git pull)'
  }
}

# ─── Manifeste de livraison (ADR-024) ─────────────────────────────────────────
# Même garantie que côté bash : sans manifeste, aucune preuve qu'une sync ne
# détruira pas l'état runtime du client — on s'arrête plutôt que de deviner.
function Confirm-Manifest {
  if (Test-Path $ManifestFile) {
    $n = & node -e @"
try {
  const m = JSON.parse(require('fs').readFileSync(process.argv[1], 'utf8'));
  process.stdout.write(String(Object.keys(m.files || {}).length));
} catch { process.stdout.write('0'); }
"@ $ManifestFile
    if ([int]$n -gt 0) {
      Write-Ok "Manifeste de livraison : $n fichiers"
      return
    }
    Write-Warn2 'Manifeste présent mais vide/illisible — régénération…'
  }

  $isGitRepo = $false
  if (Get-Command git -ErrorAction SilentlyContinue) {
    & git -C $SourceDir rev-parse --git-dir *> $null
    $isGitRepo = ($LASTEXITCODE -eq 0)
  }

  if ($isGitRepo) {
    Write-Info2 'Manifeste absent — génération depuis git…'
    if ($DryRun) {
      Write-Warn2 '--dry-run : régénération du manifeste ignorée (écriture désactivée)'
    } else {
      & node (Join-Path $ClaudeDir 'scripts/generate-ada-manifest.js') --root $SourceDir
      if ($LASTEXITCODE -eq 0) { return }
    }
  }

  if (-not $DryRun) {
    Write-Err2 "Manifeste de livraison introuvable : $ManifestFile"
    Write-Host '  Sans lui, l''installeur ne peut pas garantir qu''il ne détruira pas' -ForegroundColor Red
    Write-Host '  les données de tes profils — il s''arrête plutôt que de tenter sa chance.' -ForegroundColor Red
    Write-Host '  Depuis une copie git du dépôt, régénère-le :' -ForegroundColor Red
    Write-Host '    node .claude/scripts/generate-ada-manifest.js' -ForegroundColor White
    Write-Host '  Sinon, retélécharge une archive de release complète.' -ForegroundColor Red
    exit 1
  }
}

# ─── Validation + création d'un répertoire de profil ─────────────────────────
function New-ProfileDir {
  param([Parameter(Mandatory)][string]$RawName)

  if ($RawName -match '[\\/]' -or $RawName -match '\.\.') {
    Write-Err2 "Nom de profil invalide : '$RawName' (chemin interdit)"
    exit 1
  }
  $name = $RawName.TrimStart('.')
  if ($name -notmatch $ProfileNameRe) {
    Write-Err2 "Nom de profil invalide : '$RawName'"
    Write-Host '  Attendu : minuscules, chiffres et tirets (ex: claude-ada)' -ForegroundColor Red
    exit 1
  }

  $dir = Join-Path $HOME ".$name"
  if ($DryRun) {
    Write-Dry "mkdir -p $dir"
  } elseif (-not (Test-Path $dir)) {
    New-Item -ItemType Directory -Path $dir -Force | Out-Null
  }
  return $dir
}

# ─── Détection des profils existants ──────────────────────────────────────────
function Get-DetectedProfiles {
  $profiles = @()
  Get-ChildItem -Path $HOME -Directory -Filter '.claude-*' -Force -ErrorAction SilentlyContinue |
    ForEach-Object { $profiles += $_.FullName }

  # ~/.claude — profil par défaut de Claude Code (même traitement que côté bash :
  # le glob ".claude-*" ne le matche pas, faute de tiret).
  $dotClaude = Join-Path $HOME '.claude'
  if (Test-Path $dotClaude -PathType Container) { $profiles += $dotClaude }

  return $profiles
}

# ─── Écriture ~/.ada.json (délégué à Node — voir docstring en tête de fichier) ─
# Même JS, même JSON.stringify, que le bloc `node -e` inline de write_ada_config
# côté install.sh : garantit un format IDENTIQUE, jamais une réimplémentation
# PowerShell qui pourrait diverger silencieusement.
function Write-AdaConfig {
  param(
    [Parameter(Mandatory)][string[]]$InstalledProfileDirs,
    [string]$ResolvedUiDir
  )

  $activeProfile = (Split-Path -Leaf $InstalledProfileDirs[0]).TrimStart('.')
  if ($activeProfile -notmatch $ProfileNameRe) {
    Write-Err2 "Nom de profil invalide : '$activeProfile'"
    exit 1
  }

  $names = @()
  foreach ($p in $InstalledProfileDirs) {
    $n = (Split-Path -Leaf $p).TrimStart('.')
    if ($n -notmatch $ProfileNameRe) {
      Write-Err2 "Nom de profil invalide : '$n'"
      exit 1
    }
    $names += $n
  }
  $namesJson = ($names | ConvertTo-Json -Compress -AsArray)

  if ($DryRun) {
    Write-Dry "~/.ada.json serait mis à jour (activeProfile bootstrap=$activeProfile, installedProfiles+=$($names -join ', '))"
    return
  }

  $env:ADA_CFG_PATH           = $AdaConfig
  $env:ADA_BOOTSTRAP_PROFILE  = $activeProfile
  $env:ADA_SOURCE_DIR_ENV     = $ClaudeDir
  $env:ADA_UI_DIR_ENV         = if ($ResolvedUiDir) { $ResolvedUiDir } else { '' }
  $env:ADA_NEW_PROFILES_JSON  = $namesJson
  $env:ADA_VERSION_ENV        = $AdaVersion

  & node -e @'
const fs = require('node:fs'), os = require('node:os'), p = require('node:path');
const cfgPath = process.env.ADA_CFG_PATH;
let cfg = {};
try { cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8')); } catch {}
if (!cfg.activeProfile) cfg.activeProfile = process.env.ADA_BOOTSTRAP_PROFILE;
cfg.sourceDir = process.env.ADA_SOURCE_DIR_ENV;
if (process.env.ADA_UI_DIR_ENV) cfg.uiDir = process.env.ADA_UI_DIR_ENV;
const newProfiles = JSON.parse(process.env.ADA_NEW_PROFILES_JSON);
cfg.installedProfiles = [...new Set([...(cfg.installedProfiles ?? []), ...newProfiles])]
  .filter(n => fs.existsSync(p.join(os.homedir(), '.' + n)));
cfg.installedAt = new Date().toISOString();
cfg.version = process.env.ADA_VERSION_ENV;
fs.writeFileSync(cfgPath, JSON.stringify(cfg, null, 2) + '\n');
'@

  Write-Ok '~/.ada.json mis à jour'
}

# ─── .env.local pour ada-ui (ADA_ACTIVE_PROFILE) ──────────────────────────────
function Write-EnvLocal {
  param([Parameter(Mandatory)][string[]]$InstalledProfileDirs)

  $uiDir = Join-Path $SourceDir 'ada-ui'
  if (-not (Test-Path $uiDir -PathType Container)) { return }

  $existingActive = $null
  if (Test-Path $AdaConfig) {
    $existingActive = & node -e @"
try {
  const cfg = JSON.parse(require('fs').readFileSync(process.argv[1], 'utf8'));
  if (cfg.activeProfile) process.stdout.write(String(cfg.activeProfile));
} catch {}
"@ $AdaConfig
  }
  $activeProfile = if ($existingActive) { $existingActive } else { (Split-Path -Leaf $InstalledProfileDirs[0]).TrimStart('.') }
  $activeName = $activeProfile -replace '^claude-', ''

  if ($activeName -notmatch $ProfileNameRe) {
    Write-Warn2 "Impossible d'écrire .env.local : nom de profil invalide '$activeName'"
    return
  }

  $envFile = Join-Path $uiDir '.env.local'
  if ($DryRun) {
    Write-Dry ".env.local serait mis à jour (ADA_ACTIVE_PROFILE=$activeName)"
    return
  }

  # BUG corrigé : Get-Content renvoie un STRING scalaire (pas un tableau à 1
  # élément) quand le fichier n'a qu'une ligne — dans ce cas `$existingLines +
  # "..."` fait de la concaténation de chaînes (pas un append de tableau) et
  # fusionne les deux lignes en une seule, sans retour à la ligne entre elles
  # (vérifié empiriquement : "URL=...api" + "ADA_ACTIVE_PROFILE=..." collés).
  # Le @(...) autour du pipeline force le contexte tableau quel que soit le
  # nombre de lignes (0, 1 ou N).
  $existingLines = @()
  if (Test-Path $envFile) {
    $existingLines = @(Get-Content $envFile | Where-Object { $_ -notmatch '^ADA_ACTIVE_PROFILE=' })
  }
  ($existingLines + "ADA_ACTIVE_PROFILE=$activeName") | Set-Content -Path $envFile
  Write-Ok ".env.local créé (ADA_ACTIVE_PROFILE=$activeName)"
}

# ─── Sync CLAUDE.md avec sauvegarde horodatée (miroir sync_claude_md bash) ────
function Sync-ClaudeMd {
  param([Parameter(Mandatory)][string]$Src, [Parameter(Mandatory)][string]$Dst)

  if (-not (Test-Path $Dst)) {
    if ($DryRun) { Write-Dry 'CLAUDE.md serait copié (nouveau, aucune sauvegarde nécessaire)' }
    else { Copy-Item $Src $Dst -Force; Write-Ok 'CLAUDE.md (nouveau)' }
    return
  }

  $srcBytes = [System.IO.File]::ReadAllBytes($Src)
  $dstBytes = [System.IO.File]::ReadAllBytes($Dst)
  $identical = ($srcBytes.Length -eq $dstBytes.Length) -and (-not (Compare-Object $srcBytes $dstBytes -SyncWindow 0))

  if ($identical) {
    if ($DryRun) { Write-Dry 'CLAUDE.md déjà à jour — rien à faire' }
    else { Write-Ok 'CLAUDE.md (déjà à jour, no-op)' }
    return
  }

  $backup = "$Dst.bak.$(Get-Date -Format 'yyyyMMddHHmmss')"
  if ($DryRun) {
    Write-Dry "CLAUDE.md personnalisé serait sauvegardé -> $(Split-Path -Leaf $backup) puis écrasé"
  } else {
    Copy-Item $Dst $backup -Force
    Copy-Item $Src $Dst -Force
    Write-Ok "CLAUDE.md (personnalisé — sauvegardé -> $(Split-Path -Leaf $backup), puis mis à jour)"
  }
}

# ─── Sync d'un dir SYSTÈME depuis le manifeste (mode replace, sans rsync) ─────
# Reproduit exactement la branche "sans rsync" d'install.sh (_copy_from_list) :
# manifest-files-for.js fait office de --files-from, on copie fichier par
# fichier. Le retrait des fichiers dépréciés est délégué à sync-content-dir.js
# --mode prune, EXACTEMENT comme le fait install.sh.
function Sync-SystemDir {
  param([Parameter(Mandatory)][string]$Name, [Parameter(Mandatory)][string]$ProfileDir)

  $excludeArgs = @()
  foreach ($x in $ManifestMutable) { $excludeArgs += @('--exclude', $x) }

  $filesForJs = Join-Path $ClaudeDir 'scripts/manifest-files-for.js'
  $listOutput = & node $filesForJs $ManifestFile $Name @excludeArgs 2>$null
  $rc = $LASTEXITCODE

  if ($rc -eq 3) {
    Write-Warn2 "$Name/ absent du manifeste — ignoré"
    return
  }
  if ($rc -ne 0) {
    Write-Err2 "$Name/ : manifeste illisible — dir non synchronisé"
    return
  }

  $relPaths = @($listOutput | Where-Object { $_ -and $_.Trim() })

  if ($DryRun) {
    $nNew = 0; $nUpd = 0
    foreach ($rel in $relPaths) {
      $dst = Join-Path $ProfileDir ($rel -replace '/', [IO.Path]::DirectorySeparatorChar)
      if (Test-Path $dst) { $nUpd++ } else { $nNew++ }
    }
    Write-Dry "$Name/ : $nNew nouveau(x) . $nUpd mis à jour"
  } else {
    New-Item -ItemType Directory -Path (Join-Path $ProfileDir $Name) -Force | Out-Null
    foreach ($rel in $relPaths) {
      $relNative = $rel -replace '/', [IO.Path]::DirectorySeparatorChar
      $srcPath = Join-Path $ClaudeDir $relNative
      $dstPath = Join-Path $ProfileDir $relNative
      New-Item -ItemType Directory -Path (Split-Path -Parent $dstPath) -Force | Out-Null
      Copy-Item -Path $srcPath -Destination $dstPath -Force
    }
    Write-Ok "$Name/"
  }

  # Retrait des fichiers dépréciés — même script Node que côté bash.
  $pruneArgs = @(
    '--mode', 'prune', '--prefix', $Name, '--dst', $ProfileDir,
    '--manifest', $ManifestFile,
    '--applied', (Join-Path $ProfileDir $AppliedManifestName),
    '--label', "    -> $Name/ nettoyage"
  )
  if ($DryRun) { $pruneArgs += '--dry-run' }
  & node (Join-Path $ClaudeDir 'scripts/sync-content-dir.js') @pruneArgs
}

# ─── Sync par CHECKSUM (dirs contenu + fichiers MANIFEST_MUTABLE) ─────────────
function Sync-Checksum {
  param([Parameter(Mandatory)][string]$Prefix, [Parameter(Mandatory)][string]$ProfileDir, [string]$Label, [string]$CustomReport)

  $args2 = @(
    '--mode', 'content', '--prefix', $Prefix,
    '--src', $ClaudeDir, '--dst', $ProfileDir,
    '--manifest', $ManifestFile,
    '--applied', (Join-Path $ProfileDir $AppliedManifestName)
  )
  if ($CustomReport) { $args2 += @('--report', $CustomReport, '--report-tag', (Split-Path -Leaf $ProfileDir)) }
  if ($Label) { $args2 += @('--label', $Label) }
  if ($DryRun) { $args2 += '--dry-run' }
  & node (Join-Path $ClaudeDir 'scripts/sync-content-dir.js') @args2
}

# ─── Merge settings.json (même logique JS que merge_settings côté bash) ──────
function Merge-SettingsJson {
  param([Parameter(Mandatory)][string]$SrcSettings, [Parameter(Mandatory)][string]$DstSettings, [Parameter(Mandatory)][string]$ProfileDir)

  $env:ADA_SRC_SETTINGS = $SrcSettings
  $env:ADA_DST_SETTINGS = $DstSettings
  $env:ADA_PROFILE_DIR_ENV = $ProfileDir

  & node -e @'
const fs = require('node:fs');
const src = JSON.parse(fs.readFileSync(process.env.ADA_SRC_SETTINGS, 'utf8'));
let dst = {};
try { dst = JSON.parse(fs.readFileSync(process.env.ADA_DST_SETTINGS, 'utf8')); } catch {}
if (!dst.hooks) dst.hooks = {};
const srcHooks = src.hooks || {};
for (const event of Object.keys(srcHooks)) {
  if (!dst.hooks[event]) { dst.hooks[event] = srcHooks[event]; continue; }
  for (const srcEntry of srcHooks[event]) {
    const exists = dst.hooks[event].some(e => JSON.stringify(e.hooks) === JSON.stringify(srcEntry.hooks));
    if (!exists) dst.hooks[event].push(srcEntry);
  }
}
const srcDeny = Array.isArray(src.permissions && src.permissions.deny) ? src.permissions.deny : [];
if (srcDeny.length) {
  if (!dst.permissions || typeof dst.permissions !== 'object') dst.permissions = {};
  const dstDeny = Array.isArray(dst.permissions.deny) ? dst.permissions.deny : [];
  const seen = new Set(dstDeny);
  const merged = dstDeny.slice();
  for (const rule of srcDeny) { if (!seen.has(rule)) { seen.add(rule); merged.push(rule); } }
  dst.permissions.deny = merged;
}
const conflictLines = [];
for (const topKey of ['env', 'preferences']) {
  const srcFlat = (src[topKey] && typeof src[topKey] === 'object' && !Array.isArray(src[topKey])) ? src[topKey] : {};
  if (Object.keys(srcFlat).length === 0) continue;
  const dstFlat = (dst[topKey] && typeof dst[topKey] === 'object' && !Array.isArray(dst[topKey])) ? dst[topKey] : {};
  for (const k of Object.keys(srcFlat)) {
    if (!(k in dstFlat)) dstFlat[k] = srcFlat[k];
    else if (dstFlat[k] !== srcFlat[k]) conflictLines.push(`${topKey}.${k} : client="${dstFlat[k]}" (conservé) vs ada="${srcFlat[k]}" (ignoré)`);
  }
  dst[topKey] = dstFlat;
}
// Remplacement ${CLAUDE_CONFIG_DIR} -> chemin réel du profil (équivalent du sed
// OSTYPE-branché côté bash — ici un remplacement littéral Node, portable).
const profileDir = process.env.ADA_PROFILE_DIR_ENV;
let out = JSON.stringify(dst, null, 2);
out = out.split('${CLAUDE_CONFIG_DIR}').join(profileDir);
dst = JSON.parse(out);
// Dédoublonnage des hooks (même passe qu'en bash après le sed).
for (const event of Object.keys(dst.hooks || {})) {
  const seen = new Set();
  dst.hooks[event] = dst.hooks[event].filter(e => {
    const k = JSON.stringify(e);
    if (seen.has(k)) return false;
    seen.add(k); return true;
  });
}
fs.writeFileSync(process.env.ADA_DST_SETTINGS, JSON.stringify(dst, null, 2) + '\n');
process.stdout.write(conflictLines.join('\n'));
'@

  Write-Ok 'settings.json mergé (hooks + permissions.deny + env + preferences)'
}

# ─── Installation d'un profil ──────────────────────────────────────────────────
function Install-Profile {
  param([Parameter(Mandatory)][string]$ProfileDir, [string]$CustomReport)

  $profileName = Split-Path -Leaf $ProfileDir
  Write-Host ''
  Write-Host "-- Installation : $profileName --" -ForegroundColor Blue

  if ($DryRun) { Write-Dry "mkdir -p $ProfileDir" }
  else { New-Item -ItemType Directory -Path $ProfileDir -Force | Out-Null }

  foreach ($d in $SystemDirs) {
    if (Test-Path (Join-Path $ClaudeDir $d) -PathType Container) {
      Sync-SystemDir -Name $d -ProfileDir $ProfileDir
    }
  }

  foreach ($mf in $ManifestMutable) {
    if (Test-Path (Join-Path $ClaudeDir $mf)) {
      Sync-Checksum -Prefix $mf -ProfileDir $ProfileDir -Label "  OK $mf" -CustomReport $CustomReport
    }
  }

  # bank-state.json / router-state.json — seed neutre au premier install uniquement.
  foreach ($rsPair in @('bank-state', 'router-state')) {
    $seed = Join-Path $ProfileDir "coordinator/$rsPair.seed.json"
    $live = Join-Path $ProfileDir "coordinator/$rsPair.json"
    if ((Test-Path $seed) -and (-not (Test-Path $live))) {
      if ($DryRun) { Write-Dry "coordinator/$rsPair.json serait créé depuis le seed neutre" }
      else { Copy-Item $seed $live; Write-Ok "coordinator/$rsPair.json (seed neutre)" }
    }
  }

  foreach ($d in $ContentDirs) {
    if (Test-Path (Join-Path $ClaudeDir $d) -PathType Container) {
      Sync-Checksum -Prefix $d -ProfileDir $ProfileDir -Label "  OK $d/" -CustomReport $CustomReport
    }
  }

  if (Test-Path $VersionFile) {
    if ($DryRun) { Write-Dry "VERSION serait écrit ($AdaVersion)" }
    else { Copy-Item $VersionFile (Join-Path $ProfileDir 'VERSION') -Force; Write-Ok "VERSION ($AdaVersion)" }
  }

  $srcClaudeMd = Join-Path $SourceDir 'CLAUDE.md'
  if (Test-Path $srcClaudeMd) {
    Sync-ClaudeMd -Src $srcClaudeMd -Dst (Join-Path $ProfileDir 'CLAUDE.md')
  }

  $srcSettings = Join-Path $ClaudeDir 'settings.json'
  $dstSettings = Join-Path $ProfileDir 'settings.json'
  if (Test-Path $srcSettings) {
    if ($DryRun) {
      if (Test-Path $dstSettings) { Write-Dry 'settings.json serait mergé (hooks + permissions.deny + env + preferences)' }
      else { Write-Dry 'settings.json serait copié' }
    } elseif (Test-Path $dstSettings) {
      Merge-SettingsJson -SrcSettings $srcSettings -DstSettings $dstSettings -ProfileDir $ProfileDir
    } else {
      Copy-Item $srcSettings $dstSettings -Force
      # ${CLAUDE_CONFIG_DIR} doit être résolu même sur une copie simple (premier
      # install) — miroir du sed appliqué côté bash après le `cp` initial.
      $raw = Get-Content $dstSettings -Raw
      Set-Content -Path $dstSettings -Value ($raw.Replace('${CLAUDE_CONFIG_DIR}', $ProfileDir))
      Write-Ok 'settings.json copié'
    }
  }

  $runtimeDirs = @('logs', 'runs', 'memory/global', 'archives/summaries')
  if ($DryRun) {
    Write-Dry "répertoires runtime seraient créés ($($runtimeDirs -join ', '))"
  } else {
    foreach ($rd in $runtimeDirs) {
      New-Item -ItemType Directory -Path (Join-Path $ProfileDir ($rd -replace '/', [IO.Path]::DirectorySeparatorChar)) -Force | Out-Null
    }
    Write-Ok 'répertoires runtime créés'
  }

  if ($DryRun) {
    Write-Dry "$AppliedManifestName ne serait pas mis à jour"
  } else {
    Copy-Item $ManifestFile (Join-Path $ProfileDir $AppliedManifestName) -Force
    Write-Ok "$AppliedManifestName (référence pour la prochaine mise à jour)"
  }
}

# ─── CLI ada — pas de symlink /usr/local/bin sur Windows sans droits admin ────
# Windows n'a pas d'équivalent direct d'un symlink global sans élévation
# (New-Item -ItemType SymbolicLink exige Admin ou le mode développeur activé).
# On reproduit donc directement la branche de repli d'install.sh (alias dans le
# RC du shell quand sudo échoue) plutôt que la branche symlink : une fonction
# PowerShell `ada` ajoutée à $PROFILE.
#
# Pointe vers $ClaudeDir/bin/ada.js (le DÉPÔT SOURCE), pas la copie synchronisée
# dans le profil — comme install_cli() côté bash (ada_bin="$CLAUDE_DIR/bin/ada.js").
# ada.js résout lui-même le profil actif via ~/.ada.json à chaque invocation, il
# n'a pas besoin de tourner depuis l'intérieur du profil.
function Install-AdaCli {
  $adaBin = Join-Path $ClaudeDir 'bin/ada.js'
  if (-not (Test-Path $adaBin)) {
    Write-Warn2 'bin/ada.js introuvable — CLI ada non installé'
    return
  }

  Write-Host ''
  Write-Host 'Installation CLI ada...' -ForegroundColor White

  if ($DryRun) {
    Write-Dry "fonction PowerShell 'ada' serait ajoutée à `$PROFILE -> node `"$adaBin`""
    return
  }

  $funcLine = "function ada { node `"$adaBin`" @args }"
  $profilePath = $PROFILE.CurrentUserAllHosts
  $profileDirPs = Split-Path -Parent $profilePath
  if (-not (Test-Path $profileDirPs)) { New-Item -ItemType Directory -Path $profileDirPs -Force | Out-Null }
  if (-not (Test-Path $profilePath)) { New-Item -ItemType File -Path $profilePath -Force | Out-Null }

  $already = (Get-Content $profilePath -Raw -ErrorAction SilentlyContinue) -like "*$funcLine*"
  if (-not $already) {
    Add-Content -Path $profilePath -Value "`n# ADA CLI`n$funcLine`n"
    Write-Ok "Fonction 'ada' ajoutée à $profilePath — ouvre une nouvelle fenêtre PowerShell (ou : . `$PROFILE)"
  } else {
    Write-Info2 "Fonction 'ada' déjà présente dans $profilePath"
  }
}

# ─── Backend ADA (ada-api-nest) — composant cœur, pas derrière un flag ────────
# ada-api-nest n'a aucune dépendance native (pas de node-gyp) : contrairement à
# ada-ui, rien ne justifie de le mettre derrière -WithUI sur Windows.
function Install-ApiNest {
  $apiDir = Join-Path $SourceDir 'ada-api-nest'
  Write-Host ''
  Write-Host 'Installation du backend ADA (ada-api-nest)...' -ForegroundColor White

  if (-not (Test-Path $apiDir -PathType Container)) {
    Write-Warn2 "ada-api-nest introuvable : $apiDir - backend ignoré (ada-ui restera hors ligne)"
    return
  }
  Write-Info2 "Répertoire : $apiDir"

  if ($DryRun) {
    if (-not (Test-Path (Join-Path $apiDir 'node_modules'))) { Write-Dry 'dépendances npm seraient installées' }
    else { Write-Dry 'dépendances npm déjà présentes' }
    if (-not (Test-Path (Join-Path $apiDir '.env'))) { Write-Dry '.env serait généré (JWT_SECRET aléatoire)' }
    Write-Dry 'build de production ignoré'
    return
  }

  if (-not (Test-Path (Join-Path $apiDir 'node_modules'))) {
    Write-Host '  Installation des dépendances npm...'
    Push-Location $apiDir
    try {
      npm ci --silent 2>$null
      if ($LASTEXITCODE -ne 0) { npm install --silent }
      if ($LASTEXITCODE -ne 0) { throw 'npm install échoué' }
      Write-Ok 'Dépendances installées'
    } catch {
      Write-Warn2 "npm install échoué - relance manuellement : cd $apiDir; npm install"
      Pop-Location
      return
    }
    Pop-Location
  } else {
    Write-Ok 'Dépendances déjà présentes'
  }

  $envFile = Join-Path $apiDir '.env'
  if (-not (Test-Path $envFile)) {
    $bytes = New-Object byte[] 32
    [System.Security.Cryptography.RandomNumberGenerator]::Fill($bytes)
    $jwtSecret = -join ($bytes | ForEach-Object { $_.ToString('x2') })
    @"
# Généré par install.ps1 le $(Get-Date -Format 'yyyy-MM-dd') — voir .env.example pour toutes les options.
JWT_SECRET=$jwtSecret
# Postgres (ADR-017) — optionnel. Sans cette ligne : mode dégradé (persistance
# désactivée, /health: db down), mais l'app démarre et fonctionne normalement.
# DATABASE_URL=postgresql://ada:ada@127.0.0.1:5433/ada
"@ | Set-Content -Path $envFile
    Write-Ok '.env généré (JWT_SECRET aléatoire)'
  } else {
    Write-Ok '.env déjà présent'
  }

  Write-Host '  Compilation du backend (peut prendre 20-40s)...'
  Push-Location $apiDir
  npm run build *> (Join-Path ([System.IO.Path]::GetTempPath()) 'ada-api-nest-build.log')
  if ($LASTEXITCODE -eq 0) { Write-Ok 'Backend compilé en mode production' }
  else { Write-Warn2 "Build échoué - le backend démarrera en mode dev via 'ada start server'. Logs : $(Join-Path ([System.IO.Path]::GetTempPath()) 'ada-api-nest-build.log')" }
  Pop-Location
}

# ─── Interface ADA (ada-ui) — STRICTEMENT opt-in (-WithUI) ────────────────────
function Install-Ui {
  $uiDir = Join-Path $SourceDir 'ada-ui'
  Write-Host ''
  Write-Host "Installation de l'interface ADA..." -ForegroundColor White

  if (-not (Test-Path $uiDir -PathType Container)) {
    Write-Warn2 "ada-ui introuvable : $uiDir - interface ignorée"
    return
  }
  Write-Info2 "Répertoire : $uiDir"
  Write-Warn2 'node-pty (dépendance native d''ada-ui) nécessite Visual Studio Build Tools'
  Write-Host '   (workload "Desktop development with C++") si le paquet n''a pas de binaire' -ForegroundColor Yellow
  Write-Host '   prébuilt pour ta version de Node/Windows. Voir : https://github.com/microsoft/node-pty' -ForegroundColor Yellow

  if ($DryRun) {
    if (-not (Test-Path (Join-Path $uiDir 'node_modules'))) { Write-Dry 'dépendances npm seraient installées' }
    else { Write-Dry 'dépendances npm déjà présentes' }
    Write-Dry 'build de production ignoré'
    return
  }

  if (-not (Test-Path (Join-Path $uiDir 'node_modules'))) {
    Write-Host '  Installation des dépendances npm...'
    Push-Location $uiDir
    npm ci --silent 2>$null
    if ($LASTEXITCODE -ne 0) { npm install --silent }
    if ($LASTEXITCODE -ne 0) {
      Write-Warn2 "npm install échoué - l'interface démarrera en mode dev"
      Pop-Location
      return
    }
    Write-Ok 'Dépendances installées'
    Pop-Location
  } else {
    Write-Ok 'Dépendances déjà présentes'
  }

  Write-Host '  Compilation de l''interface (peut prendre 30-60s)...'
  Push-Location $uiDir
  npm run build *> (Join-Path ([System.IO.Path]::GetTempPath()) 'ada-ui-build.log')
  if ($LASTEXITCODE -eq 0) { Write-Ok 'Interface compilée en mode production' }
  else { Write-Warn2 "Build échoué - l'interface démarrera en mode dev. Logs : $(Join-Path ([System.IO.Path]::GetTempPath()) 'ada-ui-build.log')" }
  Pop-Location
}

# ─── Vérification post-install (doctor.js — Node pur, réutilisé tel quel) ────
function Invoke-Doctor {
  param([Parameter(Mandatory)][string]$ProfileDir)

  $doctor = Join-Path $ProfileDir 'bin/doctor.js'
  Write-Host ''
  Write-Host 'Vérification post-install...' -ForegroundColor White

  if ($DryRun) { Write-Dry 'doctor.js ignoré (rien n''a été installé à vérifier)'; return }

  if (Test-Path $doctor) {
    $env:CLAUDE_CONFIG_DIR = $ProfileDir
    & node $doctor
    if ($LASTEXITCODE -ne 0) { Write-Warn2 'doctor.js a retourné des avertissements' }
  } else {
    Write-Info2 "doctor.js non trouvé dans $ProfileDir/bin/ - étape ignorée"
  }
}

# ─── Résumé final ──────────────────────────────────────────────────────────────
function Show-Summary {
  param([Parameter(Mandatory)][string[]]$Installed)

  if ($DryRun) {
    Write-Host ''
    Write-Host '=======================================' -ForegroundColor Yellow
    Write-Host '  Simulation -DryRun terminée — rien n''a été écrit' -ForegroundColor Yellow
    Write-Host '=======================================' -ForegroundColor Yellow
    Write-Host "Profils qui auraient été installés (v$AdaVersion) :"
    foreach ($p in $Installed) { Write-Host "  - $(Split-Path -Leaf $p)" -ForegroundColor Cyan }
    Write-Host "Relance sans -DryRun pour appliquer ces changements." -ForegroundColor Cyan
    return
  }

  Write-Host ''
  Write-Host '=======================================' -ForegroundColor Green
  Write-Host "  ADA v$AdaVersion installé avec succès !" -ForegroundColor Green
  Write-Host '=======================================' -ForegroundColor Green
  Write-Host 'Profils installés :'
  foreach ($p in $Installed) { Write-Host "  OK $(Split-Path -Leaf $p)" -ForegroundColor Green }
  Write-Host ''
  Write-Host 'Commandes (ouvre une NOUVELLE fenêtre PowerShell pour que ''ada'' soit reconnu) :'
  Write-Host '  ada start server      — démarre les 3 services (control-server + backend + interface)' -ForegroundColor Cyan
  Write-Host '  ada status            — état complet du système' -ForegroundColor Cyan
  Write-Host '  ada profile list      — lister les profils installés' -ForegroundColor Cyan
  Write-Host '  ada launch [dossier]  — lancer Claude sur un projet' -ForegroundColor Cyan
  if (-not $WithUI) {
    Write-Host ''
    Write-Host 'Interface ADA (ada-ui) non installée — installation CLI-only par défaut.' -ForegroundColor Cyan
    Write-Host '  Pour l''installer plus tard : .\install.ps1 -WithUI (ou $env:ADA_WITH_UI = ''1'')' -ForegroundColor Cyan
    Write-Host '  Nécessite Visual Studio Build Tools pour compiler node-pty (module natif).' -ForegroundColor Cyan
  }
  Write-Host ''
  Write-Host "Config : $AdaConfig" -ForegroundColor Yellow
  Write-Host "Source : $SourceDir" -ForegroundColor Yellow
}

# ─── Main ──────────────────────────────────────────────────────────────────────
function Main {
  Show-Banner
  Test-Prerequisites

  if ($DryRun) {
    Write-Host ''
    Write-Warn2 'Mode -DryRun : simulation uniquement, aucune écriture sur le disque.'
  }

  Confirm-Manifest

  $customReport = $null
  if (-not $DryRun) {
    $customReport = Join-Path ([System.IO.Path]::GetTempPath()) "ada-custom-report-$([guid]::NewGuid().ToString('N')).tsv"
    New-Item -ItemType File -Path $customReport -Force | Out-Null
  }

  # ─── Sélection des profils ───────────────────────────────────────────────
  $selected = @()
  if ($ProfileName) {
    $target = Join-Path $HOME ".$($ProfileName.TrimStart('.'))"
    if (-not (Test-Path $target)) {
      $target = New-ProfileDir -RawName $ProfileName
      if ($DryRun) { Write-Dry "Profil qui serait créé : $target" } else { Write-Ok "Profil créé : $target" }
    }
    $selected = @($target)
  } else {
    $detected = Get-DetectedProfiles
    if ($detected.Count -eq 0) {
      Write-Info2 'Aucun profil ~/.claude ou ~/.claude-*/ détecté — première installation.'
      $newName = $DEFAULT_PROFILE_NAME
      if (-not $NonInteractive -and -not $All) {
        $answer = Read-Host "Nom du profil à créer [$DEFAULT_PROFILE_NAME]"
        if ($answer) { $newName = $answer }
      }
      $created = New-ProfileDir -RawName $newName
      Write-Ok "Profil créé : $created"
      $selected = @($created)
    } elseif ($detected.Count -eq 1 -or $All -or $NonInteractive) {
      $selected = $detected
    } else {
      Write-Host ''
      Write-Host 'Profils détectés :' -ForegroundColor White
      for ($i = 0; $i -lt $detected.Count; $i++) { Write-Host "  [$($i+1)] $(Split-Path -Leaf $detected[$i])" }
      $input = Read-Host 'Numéros séparés par des virgules (Entrée = tous)'
      if (-not $input) {
        $selected = $detected
      } else {
        $idx = $input -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ -match '^\d+$' } | ForEach-Object { [int]$_ - 1 }
        $selected = $idx | Where-Object { $_ -ge 0 -and $_ -lt $detected.Count } | ForEach-Object { $detected[$_] }
        if ($selected.Count -eq 0) { $selected = $detected }
      }
    }
  }

  Write-Host ''
  Write-Host "Installation de $($selected.Count) profil(s)..." -ForegroundColor White
  foreach ($p in $selected) { Install-Profile -ProfileDir $p -CustomReport $customReport }

  Install-AdaCli

  $uiDirPath = Join-Path $SourceDir 'ada-ui'
  $resolvedUiDir = if (Test-Path $uiDirPath -PathType Container) { $uiDirPath } else { $null }
  Write-AdaConfig -InstalledProfileDirs $selected -ResolvedUiDir $resolvedUiDir
  Write-EnvLocal -InstalledProfileDirs $selected

  Install-ApiNest

  if ($WithUI) {
    Install-Ui
  } else {
    Write-Host ''
    Write-Info2 "Interface ADA (ada-ui) non installée — installation CLI-only par défaut."
    Write-Host "  Pour l'installer plus tard : .\install.ps1 -WithUI (ou `$env:ADA_WITH_UI = '1')" -ForegroundColor Cyan
  }

  Invoke-Doctor -ProfileDir $selected[0]
  Show-Summary -Installed $selected

  if ($customReport -and (Test-Path $customReport) -and (Get-Item $customReport).Length -gt 0) {
    Write-Host ''
    Write-Host 'Fichiers personnalisés — non écrasés :' -ForegroundColor Yellow
    Get-Content $customReport | Sort-Object -Unique | ForEach-Object {
      $parts = $_ -split "`t"
      if ($parts.Count -ge 3) { Write-Host "  - [$($parts[0])] $($parts[2])" -ForegroundColor Cyan }
    }
  }
  if ($customReport) { Remove-Item $customReport -Force -ErrorAction SilentlyContinue }
}

Main
