#!/usr/bin/env bash
# chmod +x install.sh
set -euo pipefail

# ─── Couleurs ANSI ───────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; BOLD='\033[1m'; RESET='\033[0m'

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CLAUDE_DIR="$SOURCE_DIR/.claude"

# Version — source unique de vérité : fichier VERSION à la racine du dépôt.
# Ne jamais dupliquer le numéro ici (dérive constatée : install.sh 1.0.0 vs
# bin/ada.js 5.0.0 vs README v6/v7.0.1 vs tag git v7.3.0).
if [[ -f "$SOURCE_DIR/VERSION" ]]; then
  ADA_VERSION="$(tr -d '[:space:]' < "$SOURCE_DIR/VERSION")"
else
  ADA_VERSION="inconnue"
fi

# Nom du profil créé quand la machine n'en possède aucun (première installation
# sur un poste vierge). Volontairement neutre — ne jamais hardcoder un profil
# du créateur (claude-pro / claude-jarvis / …).
DEFAULT_PROFILE_NAME="claude-ada"
# Regex de sûreté partagée avec bin/ada.js (getProfileDir) et write_ada_config
PROFILE_NAME_RE='^[a-z0-9][a-z0-9-]{0,30}$'
ADA_CONFIG="$HOME/.ada.json"

# ─── Manifeste de livraison (ADR-024) ────────────────────────────────────────
# Source unique de vérité de « ce qui appartient à ADA » : la liste des fichiers
# trackés par git sous .claude/, avec le sha256 de la version livrée. Généré par
# scripts/generate-ada-manifest.js et COMMITÉ — un client qui installe depuis le
# zip de release n'a pas de .git, il doit trouver le manifeste tout fait.
#
# Ce manifeste remplace deux mécanismes défaillants :
#  - la denylist d'exclusions écrite à la main (avait déjà raté 5 familles de
#    fichiers d'état runtime : memory-*.json, lessons.json, audit.log,
#    coordinator/logs/, sessions d'équipe) ;
#  - le mode `merge` basé sur le mtime (rsync --update), faux par construction
#    puisque le zip de release donne à TOUS les fichiers le mtime de l'instant du
#    build (zip -r sur un checkout CI frais), jamais leur date de commit.
MANIFEST_FILE="$CLAUDE_DIR/.ada-manifest.json"

# Copie du manifeste déposée dans le profil après un sync réussi. Sert de « base »
# de comparaison à la sync suivante : c'est ce qui permet de distinguer
# « fichier non modifié depuis la dernière livraison » (→ mettre à jour) de
# « fichier modifié par le client » (→ ne jamais écraser).
APPLIED_MANIFEST_NAME=".ada-manifest.applied.json"

# Fichiers livrés qui vivent DANS un dir système mais qu'ADA réécrit à l'exécution
# (double nature : donnée de référence livrée + état accumulé côté client). Ils
# sont retirés du sync `replace` et passent par la logique de checksum, sinon une
# mise à jour effacerait l'état du client. Vérifié dans le code :
#   pipelines.json            — personnalisations client (E3-2)
#   witness-history.jsonl     — appendFileSync (coordinator/witness.js:206)
#   witness-fixes.json        — writeFileSync  (coordinator/witness.js:132)
#   agent-audit-baseline.json — saveBaseline() (coordinator/agent-audit.js:267)
#   flywheel-baseline.json    — writeFileSync  (coordinator/flywheel.js:144)
MANIFEST_MUTABLE=(
  coordinator/pipelines.json
  coordinator/witness-history.jsonl
  coordinator/witness-fixes.json
  coordinator/agent-audit-baseline.json
  coordinator/flywheel-baseline.json
)

# Rapport des fichiers personnalisés préservés, agrégé sur tous les profils et
# affiché dans le récapitulatif final. Initialisé par main().
CUSTOM_REPORT=""

UI_DIR=""
NONINTERACTIVE=false
WITH_SERVER=false
# Set by parse_args when --profile is used; skips detect/select_profiles
PROFILES_PRESELECTED=false
# Tracks whether the UI server was running before the install (for auto-restart)
UI_WAS_RUNNING=false
# --dry-run (ADR-024, E2-8) : quand true, AUCUNE écriture nulle part (ni profil,
# ni ~/.ada.json, ni ~/.zshrc, ni build npm) — chaque effet de bord est remplacé
# par un message décrivant ce qui aurait été fait. Détecté avant parse_args (voir
# la pré-lecture dans main()) car ensure_manifest(), qui tourne avant parse_args,
# a lui-même un effet de bord (régénération du manifeste) à respecter.
DRY_RUN=false
# Expansion de périmètre détectée par select_profiles (ADR-024, E1-B) : au
# moins un profil présent sur disque n'était pas dans cfg.installedProfiles.
# Lu par print_install_plan() pour décider si une confirmation explicite est
# nécessaire (voir E1-E) — même quand aucun profil n'est un "premier install".
SCOPE_EXPANDED=false

# ─── Banner ──────────────────────────────────────────────────────────────────
print_banner() {
  echo -e "${CYAN}${BOLD}"
  echo '   ╔═══╗╔═══╗╔═══╗'
  echo '   ║╔═╗║╚╗╔╗║║╔═╗║'
  echo '   ║║─║║─║║║║║║─║║'
  echo '   ║╔═╗║─║║║║║╚═╝║'
  echo '   ║║─║║╔╝╚╝║║╔══╝'
  echo '   ╚╝─╚╝╚═══╝╚╝'
  echo -e "${RESET}${BOLD}   AI Dev Assistant — v${ADA_VERSION}${RESET}"
  echo -e "${BLUE}   Installeur${RESET}"
  echo ""
}

# ─── Prérequis ───────────────────────────────────────────────────────────────
check_prerequisites() {
  if ! command -v node &>/dev/null; then
    echo -e "${RED}✗ Node.js introuvable. Installe Node.js >= 22 : https://nodejs.org${RESET}"
    exit 1
  fi

  local node_major
  node_major=$(node -e "process.stdout.write(String(process.versions.node.split('.')[0]))")
  if [[ "$node_major" -lt 22 ]]; then
    echo -e "${RED}✗ Node.js >= 22 requis (version actuelle : $(node --version))${RESET}"
    echo -e "   Utilise nvm : ${YELLOW}nvm install 22 && nvm use 22${RESET}"
    exit 1
  fi

  echo -e "${GREEN}✓ Node.js $(node --version)${RESET}"

  # ── Dépendances non bloquantes ────────────────────────────────────────────
  # Aucune n'empêche l'installation, mais leur absence casse des commandes
  # précises — mieux vaut le dire à l'installation qu'à la première utilisation.
  if command -v claude &>/dev/null; then
    echo -e "${GREEN}✓ Claude Code CLI $(claude --version 2>/dev/null | head -1)${RESET}"
  else
    echo -e "${YELLOW}⚠ Claude Code CLI absent — requis pour 'ada launch' et l'exécution des agents${RESET}"
    echo -e "  Installe-le : ${BOLD}npm i -g @anthropic-ai/claude-code${RESET}"
  fi

  command -v git   &>/dev/null || echo -e "${YELLOW}⚠ git absent — requis pour les mises à jour (git pull)${RESET}"
  command -v rsync &>/dev/null || echo -e "${YELLOW}⚠ rsync absent — bascule sur un copieur POSIX moins précis${RESET}"
  command -v tmux  &>/dev/null || echo -e "${YELLOW}⚠ tmux absent — requis pour les agents en équipe ('ada team')${RESET}"
}

# ─── Création d'un profil ─────────────────────────────────────────────────────
# Retourne (via stdout) le chemin du profil créé. Valide le nom pour ne jamais
# faire de mkdir sur une entrée arbitraire.
create_profile_dir() {
  local raw="$1"

  # Rejeter explicitement tout ce qui ressemble à un chemin plutôt que de le
  # réécrire en silence ('../evil' ne doit pas devenir discrètement '~/.evil').
  if [[ "$raw" == */* || "$raw" == *".."* ]]; then
    echo -e "${RED}✗ Nom de profil invalide : '$raw' (chemin interdit)${RESET}" >&2
    exit 1
  fi

  local name="${raw#.}"          # tolère '.claude-x' comme 'claude-x'

  if ! [[ "$name" =~ $PROFILE_NAME_RE ]]; then
    echo -e "${RED}✗ Nom de profil invalide : '$raw'${RESET}" >&2
    echo -e "  Attendu : minuscules, chiffres et tirets (ex: claude-ada)" >&2
    exit 1
  fi

  local dir="$HOME/.$name"
  if [[ "$DRY_RUN" == "true" ]]; then
    # Le chemin est quand même retourné (stdout) : le reste du script en a
    # besoin pour simuler la suite. Le message va sur stderr pour ne pas
    # polluer la valeur de retour capturée par `$(...)`.
    echo -e "  ${CYAN}[dry-run] mkdir -p $dir${RESET}" >&2
  else
    mkdir -p "$dir"
  fi
  echo "$dir"
}

# ─── Détection profils Claude ─────────────────────────────────────────────────
detect_profiles() {
  # --profile a déjà fixé PROFILES et SELECTED → ne pas redétecter
  [[ "$PROFILES_PRESELECTED" == "true" ]] && return

  PROFILES=()
  for dir in "$HOME"/.claude-*/; do
    [[ -d "$dir" ]] && PROFILES+=("${dir%/}")
  done

  # ~/.claude — profil Claude Code PAR DÉFAUT (ADR-024, E1-A).
  # Le glob ~/.claude-*/ ci-dessus ne le matche pas (pas de tiret), il était donc
  # totalement invisible à l'installeur alors qu'il contenait déjà un ADA périmé.
  # Décision produit : le traiter comme un profil normal. Ajouté à la liste, il ne
  # la remplace pas — les profils ~/.claude-* détectés au-dessus sont conservés.
  if [[ -d "$HOME/.claude" ]]; then
    PROFILES+=("$HOME/.claude")
  fi

  # Poste vierge : aucun profil Claude Code n'existe. On CRÉE le profil au lieu
  # d'abandonner — c'était le blocage nº1 pour une installation externe
  # (l'installeur exigeait que le client devine 'mkdir ~/.claude-<nom>').
  if [[ ${#PROFILES[@]} -eq 0 ]]; then
    echo -e "${CYAN}ℹ Aucun profil ~/.claude ou ~/.claude-*/ détecté — première installation.${RESET}"

    local new_name="$DEFAULT_PROFILE_NAME"
    if [[ "$NONINTERACTIVE" != "true" ]]; then
      local answer
      read -rp "$(echo -e "${BOLD}Nom du profil à créer [${DEFAULT_PROFILE_NAME}] : ${RESET}")" answer
      [[ -n "$answer" ]] && new_name="$answer"
    fi

    local created; created="$(create_profile_dir "$new_name")"
    echo -e "${GREEN}✓ Profil créé : $created${RESET}"
    PROFILES=("$created")
  fi
}

# ─── Profils connus (~/.ada.json) vs détectés sur disque (ADR-024, E1-B) ─────
# KNOWN       : profils listés dans cfg.installedProfiles ET encore présents
#               sur disque — mapping identique à getProfileDir (ada.js) :
#               basename SANS le point → $HOME/.<item>. Un profil supprimé du
#               disque depuis le dernier install n'apparaît jamais ici (on ne
#               tente jamais de réinstaller ce qui a disparu).
# NEW_ON_DISK : profils détectés sur disque (PROFILES) mais absents de
#               cfg.installedProfiles — une expansion de périmètre potentielle
#               (créé manuellement, par un autre outil, ou un ancien test).
# HAS_CONFIG_PROFILES : true si ~/.ada.json existe avec une liste non vide.
#   Ancien bug (E1-B) : le code ne lisait cfg.installedProfiles QUE pour
#   vérifier qu'il était non-vide, puis sélectionnait TOUS les profils du
#   disque (SELECTED=("${PROFILES[@]}")) — pas cfg.installedProfiles — malgré
#   un message affiché qui prétendait le contraire.
KNOWN=()
NEW_ON_DISK=()
HAS_CONFIG_PROFILES=false

compute_known_new() {
  KNOWN=()
  NEW_ON_DISK=()
  HAS_CONFIG_PROFILES=false

  if [[ -f "$ADA_CONFIG" ]]; then
    local known_names
    known_names="$(node -e "
try {
  const cfg = JSON.parse(require('fs').readFileSync('$ADA_CONFIG','utf8'));
  if (Array.isArray(cfg.installedProfiles) && cfg.installedProfiles.length > 0) {
    process.stdout.write(cfg.installedProfiles.join('\n'));
  }
} catch {}
" 2>/dev/null || true)"

    if [[ -n "$known_names" ]]; then
      HAS_CONFIG_PROFILES=true
      local name candidate p found
      while IFS= read -r name; do
        [[ -z "$name" ]] && continue
        candidate="$HOME/.$name"
        found=false
        for p in ${PROFILES[@]+"${PROFILES[@]}"}; do
          [[ "$p" == "$candidate" ]] && { found=true; break; }
        done
        [[ "$found" == "true" ]] && KNOWN+=("$candidate")
      done <<< "$known_names"
    fi
  fi

  local p k is_known
  for p in ${PROFILES[@]+"${PROFILES[@]}"}; do
    is_known=false
    for k in ${KNOWN[@]+"${KNOWN[@]}"}; do
      [[ "$p" == "$k" ]] && { is_known=true; break; }
    done
    [[ "$is_known" == "false" ]] && NEW_ON_DISK+=("$p")
  done

  # `return 0` explicite : le dernier `[[ ... ]] && …` ci-dessus peut évaluer à
  # faux (is_known=true → rien à ajouter à NEW_ON_DISK) et devenir le statut de
  # sortie de la fonction. Appelée en instruction nue dans select_profiles()
  # sous `set -e`, un statut non nul ferait avorter tout install.sh en silence
  # — piège vérifié empiriquement (reproduit puis corrigé pendant cette passe).
  return 0
}

# Basenames séparés par des virgules — pour les messages d'annonce ci-dessous.
_profile_names() {
  local out="" p
  for p in "$@"; do
    out+="$(basename "$p"), "
  done
  echo -n "${out%, }"
}

# Vrai si $1 figure dans le reste des arguments.
_in_known() {
  local target="$1"; shift
  local k
  for k in "$@"; do
    [[ "$k" == "$target" ]] && return 0
  done
  return 1
}

# ─── Sélection auto ou interactive ───────────────────────────────────────────
select_profiles() {
  # --profile a déjà fixé SELECTED → ne pas re-sélectionner
  [[ "$PROFILES_PRESELECTED" == "true" ]] && return

  local n=${#PROFILES[@]}
  compute_known_new

  # Cas 1 : flag --all ou --non-interactive → tout sélectionner. Déclenchement
  # inchangé (toujours prioritaire dès --all/--non-interactive) — seule
  # l'annonce change (E1-B) : si ~/.ada.json révèle une expansion de périmètre,
  # elle est incluse quand même (l'utilisateur a déjà opté pour l'automatisation
  # totale) mais JAMAIS fondue dans un message générique qui la confondrait
  # avec les profils déjà connus.
  if [[ "$NONINTERACTIVE" == "true" ]]; then
    SELECTED=("${PROFILES[@]}")
    if [[ "$HAS_CONFIG_PROFILES" == "true" && ${#NEW_ON_DISK[@]} -gt 0 ]]; then
      SCOPE_EXPANDED=true
      echo -e "${CYAN}ℹ Mode non-interactif : ${#KNOWN[@]} profil(s) déjà connu(s) de ~/.ada.json ($(_profile_names ${KNOWN[@]+"${KNOWN[@]}"})) + ${#NEW_ON_DISK[@]} nouveau(x) profil(s) ajouté(s) à ce run ($(_profile_names "${NEW_ON_DISK[@]}"))${RESET}"
    else
      echo -e "${CYAN}ℹ Mode non-interactif : ${#SELECTED[@]} profil(s) sélectionné(s)${RESET}"
    fi
    return
  fi

  # Cas 2 : un seul profil → auto-select (inchangé)
  if [[ "$n" -eq 1 ]]; then
    SELECTED=("${PROFILES[0]}")
    echo -e "${GREEN}✓ Profil auto-sélectionné : $(basename "${PROFILES[0]}")${RESET}"
    return
  fi

  # Cas 3 : ~/.ada.json existe avec installedProfiles connus → réutilise
  # EXACTEMENT cette liste (intersectée avec le disque), plus la gestion de
  # l'expansion de périmètre (E1-B).
  if [[ "$HAS_CONFIG_PROFILES" == "true" ]]; then
    if [[ ${#NEW_ON_DISK[@]} -eq 0 ]]; then
      echo -e "${CYAN}ℹ ~/.ada.json existant détecté — réinstallation des ${#KNOWN[@]} profil(s) déjà connu(s) de ~/.ada.json ($(_profile_names "${KNOWN[@]}"))${RESET}"
      SELECTED=("${KNOWN[@]}")
      return
    fi

    # Expansion de périmètre en mode interactif : jamais silencieuse. On ne
    # retourne PAS ici — on tombe dans le Cas 4 (interactif) ci-dessous, avec
    # tous les profils de PROFILES proposés et les connus pré-cochés, pour que
    # l'utilisateur voie et confirme explicitement l'expansion plutôt que de
    # deviner ce qui a changé.
    SCOPE_EXPANDED=true
    echo -e "${YELLOW}⚠ ~/.ada.json connaît ${#KNOWN[@]} profil(s) ($(_profile_names ${KNOWN[@]+"${KNOWN[@]}"})), mais ${#NEW_ON_DISK[@]} profil(s) supplémentaire(s) détecté(s) sur disque ($(_profile_names "${NEW_ON_DISK[@]}")) — confirme ta sélection ci-dessous${RESET}"
  fi

  # Cas 4 : interactive — les profils déjà connus de ~/.ada.json (KNOWN) sont
  # pré-cochés ; les nouveaux (absents de cfg.installedProfiles) ne le sont
  # pas, pour forcer une confirmation explicite plutôt qu'une inclusion devinée.
  local selected_flags=()
  for ((i=0; i<n; i++)); do
    if _in_known "${PROFILES[$i]}" ${KNOWN[@]+"${KNOWN[@]}"}; then
      selected_flags+=(1)
    else
      selected_flags+=(0)
    fi
  done

  while true; do
    echo -e "\n${BOLD}Profils détectés — sélectionne les profils à installer :${RESET}"
    echo -e "  ${CYAN}[numéro]${RESET} toggle  ${CYAN}a${RESET} tout sélectionner  ${CYAN}Entrée${RESET} confirmer\n"

    for ((i=0; i<n; i++)); do
      local name; name=$(basename "${PROFILES[$i]}")
      if [[ "${selected_flags[$i]}" -eq 1 ]]; then
        echo -e "  ${GREEN}[x] $((i+1)). $name${RESET}"
      else
        echo -e "  ${YELLOW}[ ] $((i+1)). $name${RESET}"
      fi
    done

    echo -ne "\n> "
    read -r input

    if [[ -z "$input" ]]; then
      SELECTED=()
      for ((i=0; i<n; i++)); do
        [[ "${selected_flags[$i]}" -eq 1 ]] && SELECTED+=("${PROFILES[$i]}")
      done

      if [[ ${#SELECTED[@]} -eq 0 ]]; then
        echo -e "${RED}Aucun profil sélectionné. Sélectionne au moins un profil.${RESET}"
        continue
      fi
      break

    elif [[ "$input" == "a" || "$input" == "A" ]]; then
      for ((i=0; i<n; i++)); do selected_flags[$i]=1; done

    elif [[ "$input" =~ ^[0-9]+$ ]] && (( input >= 1 && input <= n )); then
      local idx=$((input - 1))
      selected_flags[$idx]=$(( 1 - selected_flags[$idx] ))

    else
      echo -e "${YELLOW}Entrée invalide.${RESET}"
    fi
  done
}

# ─── Annonce de portée (ADR-024, E3-6/E1-G) ──────────────────────────────────
# Deux commandes concurrentes avaient des portées différentes jamais annoncées :
# `ada update`/`ada install` (1 profil, l'actif, via --profile) et
# `bash install.sh` nu (tous les profils connus de ~/.ada.json). Rendue
# explicite ici, dans les deux cas, avant toute détection/sélection.
print_scope_banner() {
  if [[ "$PROFILES_PRESELECTED" == "true" ]]; then
    echo -e "${BOLD}Portée : 1 profil ($(basename "${PROFILES[0]}"))${RESET}"
    return
  fi

  if [[ ! -f "$ADA_CONFIG" ]]; then
    echo -e "${BOLD}Portée : aucun profil connu — première installation${RESET}"
    return
  fi

  local count
  count=$(node -e "
try {
  const cfg = JSON.parse(require('fs').readFileSync('$ADA_CONFIG','utf8'));
  process.stdout.write(String(Array.isArray(cfg.installedProfiles) ? cfg.installedProfiles.length : 0));
} catch { process.stdout.write('0'); }
" 2>/dev/null || echo 0)

  if [[ "$count" -eq 0 ]]; then
    echo -e "${BOLD}Portée : aucun profil connu — première installation${RESET}"
  else
    echo -e "${BOLD}Portée : ${count} profil(s) connu(s) de ~/.ada.json${RESET}"
  fi
}

# ─── Plan d'installation avant toute écriture (ADR-024, E1-E) ────────────────
# Lit $profile_dir/VERSION (déjà écrit par install_profile depuis les passes
# précédentes, jamais lu jusqu'ici avant d'agir) pour distinguer, PAR PROFIL DE
# SELECTED — y compris pour n==1 (Cas 2) — trois états :
#   VERSION absent                    → [premier install]
#   VERSION présent == $ADA_VERSION   → [déjà à jour, vX.Y.Z]
#   VERSION présent != $ADA_VERSION   → [mise à jour vX.Y.Z → vA.B.C]
# Une confirmation explicite (y/N, défaut N) n'est demandée QUE si le plan
# contient au moins un [premier install] ou si select_profiles a détecté une
# expansion de périmètre (SCOPE_EXPANDED) — le cas courant (mise à jour de
# profils déjà connus) ne doit pas gagner de friction supplémentaire. En mode
# non-interactif, le plan est affiché mais jamais bloquant (CI/provisioning).
print_install_plan() {
  local has_first_install=false
  local plan_lines=()
  local p name installed_version status

  for p in "${SELECTED[@]}"; do
    name=$(basename "$p")
    if [[ -f "$p/VERSION" ]]; then
      installed_version="$(tr -d '[:space:]' < "$p/VERSION")"
      if [[ "$installed_version" == "$ADA_VERSION" ]]; then
        status="${GREEN}[déjà à jour, v${installed_version}]${RESET}"
      else
        status="${YELLOW}[mise à jour v${installed_version} → v${ADA_VERSION}]${RESET}"
      fi
    else
      status="${CYAN}[premier install]${RESET}"
      has_first_install=true
    fi
    plan_lines+=("  ${BOLD}${name}${RESET} ${status}")
  done

  echo -e "\n${BOLD}Plan d'installation :${RESET}"
  local line
  for line in ${plan_lines[@]+"${plan_lines[@]}"}; do
    echo -e "$line"
  done

  [[ "$NONINTERACTIVE" == "true" ]] && return 0

  if [[ "$has_first_install" == "true" || "$SCOPE_EXPANDED" == "true" ]]; then
    local reason=""
    [[ "$has_first_install" == "true" ]] && reason="premier install détecté"
    if [[ "$SCOPE_EXPANDED" == "true" ]]; then
      [[ -n "$reason" ]] && reason+=" + "
      reason+="expansion de périmètre"
    fi
    local ans
    read -rp "$(echo -e "${BOLD}Confirmer (${reason}) ? [y/N] ${RESET}")" ans
    if [[ ! "$ans" =~ ^[yY]$ ]]; then
      echo -e "${YELLOW}Installation annulée.${RESET}"
      exit 0
    fi
  fi
}

# ─── Merge settings.json (hooks + permissions.deny + env + preferences) ─────
# hooks            : union dédoublonnée par JSON.stringify des handlers
# permissions.deny : union stricte source+client dédoublonnée par égalité de string.
#                    ADDITIF UNIQUEMENT — une règle deny présente côté client n'est
#                    jamais retirée ; les nouveaux durcissements de la source sont
#                    ajoutés. Propage les mises à jour sécurité aux profils déjà installés.
# permissions.allow: JAMAIS mergé (choix délibéré) — l'allow custom d'un profil ne doit
#                    pas être pollué automatiquement par la source.
# env / preferences (ADR-024, E2-6) : objets plats clé→valeur. Union de clés —
#                    nouvelle clé source → ajoutée ; clé commune même valeur →
#                    rien à faire ; clé commune valeur DIFFÉRENTE → la valeur
#                    CLIENT gagne toujours (personnalisation), jamais écrasée,
#                    mais signalée (pas silencieux) via des lignes CONFLICT sur
#                    stdout que la fonction traduit en avertissement.
merge_settings() {
  local SRC_SETTINGS="$1"
  local DST_SETTINGS="$2"
  local conflicts
  conflicts="$(node -e "
const fs = require('node:fs');
const src = JSON.parse(fs.readFileSync('${SRC_SETTINGS}', 'utf8'));
let dst = {};
try { dst = JSON.parse(fs.readFileSync('${DST_SETTINGS}', 'utf8')); } catch {}
if (!dst.hooks) dst.hooks = {};
const srcHooks = src.hooks || {};
for (const event of Object.keys(srcHooks)) {
  if (!dst.hooks[event]) { dst.hooks[event] = srcHooks[event]; continue; }
  for (const srcEntry of srcHooks[event]) {
    const exists = dst.hooks[event].some(e =>
      JSON.stringify(e.hooks) === JSON.stringify(srcEntry.hooks)
    );
    if (!exists) dst.hooks[event].push(srcEntry);
  }
}
// permissions.deny — union additive, dédoublonnage par valeur (entrées = strings)
const srcDeny = Array.isArray(src.permissions && src.permissions.deny) ? src.permissions.deny : [];
if (srcDeny.length) {
  if (!dst.permissions || typeof dst.permissions !== 'object') dst.permissions = {};
  const dstDeny = Array.isArray(dst.permissions.deny) ? dst.permissions.deny : [];
  const seen = new Set(dstDeny);
  const merged = dstDeny.slice();
  for (const rule of srcDeny) {
    if (!seen.has(rule)) { seen.add(rule); merged.push(rule); }
  }
  dst.permissions.deny = merged;
}
// env / preferences — union additive de clés, valeur CLIENT prioritaire en cas
// de conflit (jamais écrasée). Les conflits sont émis sur stdout (lignes
// CONFLICT<TAB>clé<TAB>sous-clé<TAB>valeur-client<TAB>valeur-ada), seule sortie
// de ce script node — merge_settings (bash) les lit et les affiche.
const conflictLines = [];
for (const topKey of ['env', 'preferences']) {
  const srcFlat = (src[topKey] && typeof src[topKey] === 'object' && !Array.isArray(src[topKey])) ? src[topKey] : {};
  if (Object.keys(srcFlat).length === 0) continue;
  const dstFlat = (dst[topKey] && typeof dst[topKey] === 'object' && !Array.isArray(dst[topKey])) ? dst[topKey] : {};
  for (const k of Object.keys(srcFlat)) {
    if (!(k in dstFlat)) {
      dstFlat[k] = srcFlat[k];
    } else if (dstFlat[k] !== srcFlat[k]) {
      conflictLines.push(['CONFLICT', topKey, k, String(dstFlat[k]), String(srcFlat[k])].join('\t'));
      // valeur client déjà en place dans dstFlat[k] — ne jamais l'écraser.
    }
  }
  dst[topKey] = dstFlat;
}
fs.writeFileSync('${DST_SETTINGS}', JSON.stringify(dst, null, 2) + '\n');
process.stdout.write(conflictLines.join('\n'));
")"

  echo -e "  ${GREEN}✓ settings.json mergé (hooks + permissions.deny + env + preferences)${RESET}"

  if [[ -n "$conflicts" ]]; then
    echo -e "  ${YELLOW}⚠ Conflits env/preferences — valeur CLIENT conservée, ADA ignorée (à réconcilier à la main) :${RESET}"
    local ck topKey subKey clientVal adaVal
    while IFS=$'\t' read -r ck topKey subKey clientVal adaVal; do
      [[ "$ck" != "CONFLICT" ]] && continue
      echo -e "    ${YELLOW}• ${topKey}.${subKey}${RESET} : client=\"${clientVal}\" (conservé) vs ada=\"${adaVal}\" (ignoré)"
    done <<< "$conflicts"
  fi
}

# ─── Sync CLAUDE.md avec sauvegarde horodatée (ADR-024, E2-4) ────────────────
# Comparaison de CONTENU (cmp -s), jamais de mtime — cohérent avec le reste de
# cet ADR (le zip de release donne le même mtime à tout, une comparaison par
# date serait donc systématiquement fausse). 3 cas :
#   1. dst absent            → copie simple, aucune sauvegarde à faire.
#   2. dst identique à src   → no-op idempotent (pas de .bak à chaque `ada
#                               update` répété si le client n'a rien changé).
#   3. dst différent de src  → sauvegarde D'ABORD vers dst.bak.<timestamp>
#                               (format déjà couvert par `*.bak.*` dans
#                               .gitignore — aucune convention .bak préexistante
#                               ailleurs dans le repo, format choisi ici),
#                               PUIS écrasement par la nouvelle version.
# Aucune politique de rétention/purge des .bak.* — décision explicite, hors
# scope de cette passe (voir addendum ADR-024 Axe 2).
sync_claude_md() {
  local src="$1"
  local dst="$2"

  if [[ ! -f "$dst" ]]; then
    if [[ "$DRY_RUN" == "true" ]]; then
      echo -e "  ${CYAN}[dry-run] CLAUDE.md serait copié (nouveau, aucune sauvegarde nécessaire)${RESET}"
    else
      cp "$src" "$dst"
      echo -e "  ${GREEN}✓ CLAUDE.md (nouveau)${RESET}"
    fi
    return 0
  fi

  if cmp -s "$src" "$dst"; then
    if [[ "$DRY_RUN" == "true" ]]; then
      echo -e "  ${CYAN}[dry-run] CLAUDE.md déjà à jour — rien à faire${RESET}"
    else
      echo -e "  ${GREEN}✓ CLAUDE.md (déjà à jour, no-op)${RESET}"
    fi
    return 0
  fi

  local backup="$dst.bak.$(date +%Y%m%d%H%M%S)"
  if [[ "$DRY_RUN" == "true" ]]; then
    echo -e "  ${CYAN}[dry-run] CLAUDE.md personnalisé serait sauvegardé → $(basename "$backup") puis écrasé${RESET}"
  else
    cp "$dst" "$backup"
    cp "$src" "$dst"
    echo -e "  ${GREEN}✓ CLAUDE.md (personnalisé — sauvegardé → $(basename "$backup"), puis mis à jour)${RESET}"
  fi
}

# ─── Manifeste : disponibilité ────────────────────────────────────────────────
# Sans manifeste, aucune garantie de non-destruction n'est possible : on refuse
# d'installer plutôt que de retomber en silence sur l'ancien comportement
# (ADR-024 : « erreur bloquante plutôt qu'une dégradation silencieuse »).
ensure_manifest() {
  if [[ -f "$MANIFEST_FILE" ]]; then
    local n
    n=$(node -e "
try {
  const m = JSON.parse(require('fs').readFileSync(process.argv[1],'utf8'));
  process.stdout.write(String(Object.keys(m.files || {}).length));
} catch { process.stdout.write('0'); }
" "$MANIFEST_FILE" 2>/dev/null || echo 0)
    if [[ "$n" -gt 0 ]]; then
      echo -e "${GREEN}✓ Manifeste de livraison : $n fichiers${RESET}"
      return 0
    fi
    echo -e "${YELLOW}⚠ Manifeste présent mais vide/illisible — régénération…${RESET}"
  fi

  # Installation depuis une copie de travail git : on peut le régénérer.
  if command -v git &>/dev/null && git -C "$SOURCE_DIR" rev-parse --git-dir &>/dev/null 2>&1; then
    echo -e "${CYAN}ℹ Manifeste absent — génération depuis git…${RESET}"
    if [[ "$DRY_RUN" == "true" ]]; then
      # Régénérer le manifeste ÉCRIT dans le dépôt source (.claude/.ada-manifest.json) :
      # un effet de bord au sens de --dry-run, même s'il ne touche aucun profil.
      # Sans lui on ne peut pas simuler la suite — on tombe sur l'erreur bloquante
      # ci-dessous, cohérent avec le comportement hors dry-run (refus plutôt que
      # de deviner).
      echo -e "${YELLOW}⚠ --dry-run : régénération du manifeste ignorée (écriture désactivée)${RESET}"
    elif node "$CLAUDE_DIR/scripts/generate-ada-manifest.js" --root "$SOURCE_DIR"; then
      return 0
    fi
  fi

  echo -e "${RED}✗ Manifeste de livraison introuvable : $MANIFEST_FILE${RESET}"
  echo -e "  Sans lui, l'installeur ne peut pas garantir qu'il ne détruira pas"
  echo -e "  les données de tes profils — il s'arrête plutôt que de tenter sa chance."
  echo -e "  Depuis une copie git du dépôt, régénère-le :"
  echo -e "    ${BOLD}node .claude/scripts/generate-ada-manifest.js${RESET}"
  echo -e "  Sinon, retélécharge une archive de release complète."
  exit 1
}

# ─── Sync d'un dir SYSTÈME depuis le manifeste (mode replace) ────────────────
# Le manifeste sert de --files-from : rsync ne considère QUE les fichiers listés.
# Tout ce qui existe dans le profil sans être dans la liste — l'intégralité de
# l'état runtime du client — est structurellement hors de portée, ni copié ni
# supprimé. Plus aucune liste d'exclusion à tenir à la main.
_sync_system_dir() {
  local name="$1"
  local profile_dir="$2"
  local list rc
  list="$(mktemp "${TMPDIR:-/tmp}/ada-files-from.XXXXXX")"

  # Les fichiers à double nature sortent du replace : ils passent par la logique
  # de checksum plus bas (sinon leur état client serait écrasé).
  local exclude_args=() x
  # NB bash 3.2 (bash système de macOS) : sous `set -u`, expanser un tableau vide
  # via "${arr[@]}" lève « unbound variable ». L'expansion gardée ${arr[@]+...}
  # est la seule forme portable 3.2 → 5.x. Ne pas « simplifier ».
  for x in ${MANIFEST_MUTABLE[@]+"${MANIFEST_MUTABLE[@]}"}; do
    exclude_args+=(--exclude "$x")
  done

  rc=0
  node "$CLAUDE_DIR/scripts/manifest-files-for.js" "$MANIFEST_FILE" "$name" \
    ${exclude_args[@]+"${exclude_args[@]}"} > "$list" || rc=$?

  if [[ "$rc" -eq 3 ]]; then
    echo -e "  ${YELLOW}⚠ $name/ absent du manifeste — ignoré${RESET}"
    rm -f "$list"
    return 0
  fi
  if [[ "$rc" -ne 0 ]]; then
    echo -e "  ${RED}✗ $name/ : manifeste illisible — dir non synchronisé${RESET}"
    rm -f "$list"
    return 1
  fi

  if [[ "$DRY_RUN" != "true" ]]; then
    mkdir -p "$profile_dir/$name"
  fi

  if command -v rsync &>/dev/null; then
    # --checksum est OBLIGATOIRE, pas une optimisation : le quick-check par
    # défaut de rsync (taille + mtime) saute silencieusement un fichier dont le
    # contenu a changé mais dont la taille et le mtime coïncident. Vérifié
    # empiriquement sur ce poste (openrsync, macOS) : sans --checksum un
    # `bench.js` périmé de même taille et même mtime n'était PAS mis à jour ;
    # avec --checksum il l'était. Tout l'ADR-024 repose sur « comparer le
    # contenu, jamais la date » — la commande rsync doit s'y conformer aussi.
    #
    # --delete est conservé pour l'intention, mais ne fait presque rien ici : avec
    # --files-from, rsync ne peut supprimer qu'un fichier lui-même listé (vérifié
    # empiriquement : un fichier du profil hors-liste survit). Le retrait réel des
    # fichiers dépréciés est fait par l'étape `prune` ci-dessous.
    if [[ "$DRY_RUN" == "true" ]]; then
      # NB : `rsync --dry-run --itemize-changes` a été essayé ici, mais openrsync
      # (rsync par défaut sur macOS — déjà la source du bug --checksum documenté
      # plus haut) rapporte systématiquement `>f.......` même pour un fichier
      # totalement absent du profil, au lieu de `>f+++++++++` : vérifié
      # empiriquement sur ce poste (destination totalement inexistante → quand
      # même « mis à jour », jamais « nouveau »). Compter nous-mêmes par simple
      # existence de fichier est portable (n'importe quel rsync) et fiable.
      local n_new=0 n_upd=0 relpath
      while IFS= read -r relpath; do
        [[ -z "$relpath" ]] && continue
        if [[ -f "$profile_dir/$relpath" ]]; then
          n_upd=$((n_upd + 1))
        else
          n_new=$((n_new + 1))
        fi
      done < "$list"
      echo -e "  ${CYAN}[dry-run] $name/ : $n_new nouveau(x) · $n_upd mis à jour${RESET}"
    else
      rsync -a --checksum --delete --files-from="$list" "$CLAUDE_DIR/" "$profile_dir/"
    fi
  else
    if [[ "$DRY_RUN" == "true" ]]; then
      local n_files; n_files=$(wc -l < "$list" | tr -d ' ')
      echo -e "  ${CYAN}[dry-run] $name/ : $n_files fichier(s) seraient copiés (fallback sans rsync)${RESET}"
    else
      _copy_from_list "$list" "$CLAUDE_DIR" "$profile_dir"
    fi
  fi

  rm -f "$list"

  # Retrait des fichiers dépréciés (E3-4) : un fichier livré autrefois puis retiré
  # de la source doit disparaître du profil. Comme le profil EST le runtime
  # (`ada` exécute le code du profil, pas du dépôt), du code mort qui s'accumule
  # est chargeable et donc nuisible. Strictement borné aux fichiers présents dans
  # le manifeste APPLIQUÉ : ADA ne supprime jamais un fichier qu'il n'a pas livré.
  local dr_args=()
  [[ "$DRY_RUN" == "true" ]] && dr_args+=(--dry-run)
  node "$CLAUDE_DIR/scripts/sync-content-dir.js" --mode prune \
    --prefix "$name" --dst "$profile_dir" \
    --manifest "$MANIFEST_FILE" \
    --applied "$profile_dir/$APPLIED_MANIFEST_NAME" \
    --label "    ↳ $name/ nettoyage" \
    ${dr_args[@]+"${dr_args[@]}"} || true
}

# ─── Fallback POSIX sans rsync (ADR-024, E2-3) ───────────────────────────────
# Le `cp -r "$src/." "$dst/"` d'avant n'honorait AUCUNE exclusion : dans un
# contexte sans rsync (image Docker minimale, CI), il écrasait bank.db,
# bank-state.json, pipelines.json et toute la mémoire du client.
#
# Ce remplaçant copie STRICTEMENT les fichiers listés dans le manifeste filtré —
# donc exactement la même allowlist que la branche rsync — et ne supprime RIEN.
# Comportement volontairement merge-safe : moins complet qu'un vrai replace
# (aucun retrait de déprécié, celui-ci est assuré par l'étape `prune` en Node qui
# ne dépend pas de rsync), mais jamais destructeur.
#
# Implémenté en bash plutôt qu'en Node parce que la seule partie non triviale —
# filtrer le manifeste — est déjà faite par manifest-files-for.js ; il ne reste
# qu'un `cp` par ligne, et un 3ᵉ script Node n'apporterait rien.
_copy_from_list() {
  local list="$1"
  local src_root="$2"
  local dst_root="$3"
  local rel
  while IFS= read -r rel; do
    [[ -z "$rel" ]] && continue
    mkdir -p "$dst_root/$(dirname "$rel")"
    cp -p "$src_root/$rel" "$dst_root/$rel"
  done < "$list"
}

# ─── Sync par CHECKSUM d'un sous-arbre livré (dirs contenu + JSON mutables) ──
# Remplace le mode `merge` (rsync --update, mtime) par une comparaison de
# contenu à 3 hashs : livré / livré-la-fois-précédente / présent dans le profil.
# Voir scripts/sync-content-dir.js pour la table de décision complète.
_sync_checksum() {
  local prefix="$1"
  local profile_dir="$2"
  local label="$3"
  local profile_name; profile_name=$(basename "$profile_dir")

  local dr_args=()
  [[ "$DRY_RUN" == "true" ]] && dr_args+=(--dry-run)

  node "$CLAUDE_DIR/scripts/sync-content-dir.js" --mode content \
    --prefix "$prefix" \
    --src "$CLAUDE_DIR" --dst "$profile_dir" \
    --manifest "$MANIFEST_FILE" \
    --applied "$profile_dir/$APPLIED_MANIFEST_NAME" \
    --report "$CUSTOM_REPORT" --report-tag "$profile_name" \
    --label "$label" \
    ${dr_args[@]+"${dr_args[@]}"}
}

# ─── Installation d'un profil ─────────────────────────────────────────────────
install_profile() {
  local profile_dir="$1"
  local profile_name; profile_name=$(basename "$profile_dir")

  echo -e "\n${BOLD}${BLUE}── Installation : $profile_name ──${RESET}"

  if [[ "$DRY_RUN" == "true" ]]; then
    echo -e "  ${CYAN}[dry-run] mkdir -p $profile_dir${RESET}"
  else
    mkdir -p "$profile_dir"
  fi

  # Dirs système — remplacés depuis la source, mais uniquement pour les fichiers
  # listés dans le manifeste. Plus aucune liste d'exclusion à la main : tout ce
  # qui n'est pas tracké par git (bank.db, bank-state.json, router-state.json,
  # graph-state.json, memory-episodic/procedural/semantic.json, lessons.json,
  # audit.log, coordinator/logs/, active-policy.json…) est hors du manifeste,
  # donc hors de portée de rsync — dans les deux sens.
  #
  # La protection s'applique désormais à TOUS les dirs système, pas seulement à
  # `coordinator` comme dans la version précédente.
  local system_dirs=(coordinator hooks workers tests bin docs scripts plugins-examples lib commands)
  for d in "${system_dirs[@]}"; do
    if [[ -d "$CLAUDE_DIR/$d" ]]; then
      _sync_system_dir "$d" "$profile_dir"
      echo -e "  ${GREEN}✓ $d/${RESET}"
    fi
  done

  # Fichiers livrés à double nature vivant dans un dir système : exclus du replace
  # ci-dessus, synchronisés ici par checksum pour ne jamais écraser l'état accumulé
  # côté client (historique witness, baselines, pipelines custom).
  local mf
  for mf in ${MANIFEST_MUTABLE[@]+"${MANIFEST_MUTABLE[@]}"}; do
    if [[ -f "$CLAUDE_DIR/$mf" ]]; then
      _sync_checksum "$mf" "$profile_dir" "  ✓ $mf"
    fi
  done

  # bank-state.json / router-state.json — seed neutre à la première installation
  # uniquement (jamais l'état réel du créateur, jamais un écrasement d'un état client
  # déjà accumulé sur des installs suivantes).
  local rs_pair
  for rs_pair in bank-state router-state; do
    local rs_seed="$profile_dir/coordinator/${rs_pair}.seed.json"
    local rs_live="$profile_dir/coordinator/${rs_pair}.json"
    if [[ -f "$rs_seed" && ! -f "$rs_live" ]]; then
      if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "  ${CYAN}[dry-run] coordinator/${rs_pair}.json serait créé depuis le seed neutre${RESET}"
      else
        cp "$rs_seed" "$rs_live"
        echo -e "  ${GREEN}✓ coordinator/${rs_pair}.json (seed neutre)${RESET}"
      fi
    fi
  done

  # Dirs contenu — sync par CHECKSUM (et non plus par mtime) : ajoute les nouveaux
  # agents/skills/teams, met à jour ceux que le client n'a pas touchés, préserve
  # intégralement ceux qu'il a modifiés, retire ceux qui ont disparu de la source
  # sans avoir été modifiés localement.
  #
  # `teams/` en particulier : les sessions d'équipe vivantes
  # (teams/session-<id>/…) ne sont pas trackées par git, donc absentes du
  # manifeste, donc intouchables. Elles étaient jusqu'ici préservées par accident
  # (le mode merge ne retirait jamais rien) ; elles le sont maintenant par
  # conception, y compris face à un retrait de fichier déprécié (E3-5).
  #
  # `benchmarks templates memory archives` (ADR-024, E3-3/E1-F) : ajoutés ici sans
  # code supplémentaire — la même mécanique checksum protège déjà la cohabitation
  # référence-trackée + état-runtime-gitignoré (déjà vraie pour `teams/` ci-dessus).
  # Concrètement dans `benchmarks/` :
  #   - `benchmarks/results.json` et `benchmarks/.pending.json` sont gitignorés
  #     → absents du manifeste → jamais touchés (même garantie structurelle que
  #     `memory-*.json`/`lessons.json` ailleurs).
  #   - `benchmarks/v2/results-v2.json` est au contraire TRACKÉ par git (le
  #     mainteneur y committe ses propres résultats de référence) ET réécrit par
  #     `coordinator/bench-v2.js` quand un client lance ses propres runs — double
  #     nature comme `pipelines.json`, mais qui n'a PAS besoin d'entrer dans
  #     `MANIFEST_MUTABLE` : passer par le mode `content` (checksum) suffit, un
  #     fichier client divergent de la base appliquée est automatiquement classé
  #     personnalisé et jamais écrasé.
  local content_dirs=(agents skills teams benchmarks templates memory archives)
  for d in "${content_dirs[@]}"; do
    if [[ -d "$CLAUDE_DIR/$d" ]]; then
      _sync_checksum "$d" "$profile_dir" "  ✓ $d/"
    fi
  done

  # VERSION — trace la version réellement installée dans le profil. Permet à
  # `ada version` de détecter une dérive entre le dépôt source et le runtime.
  if [[ -f "$SOURCE_DIR/VERSION" ]]; then
    if [[ "$DRY_RUN" == "true" ]]; then
      echo -e "  ${CYAN}[dry-run] VERSION serait écrit ($ADA_VERSION)${RESET}"
    else
      cp "$SOURCE_DIR/VERSION" "$profile_dir/VERSION"
      echo -e "  ${GREEN}✓ VERSION ($ADA_VERSION)${RESET}"
    fi
  fi

  # CLAUDE.md — copié depuis la racine du repo (pas depuis .claude/). Sauvegarde
  # horodatée si personnalisé (ADR-024, E2-4) — voir sync_claude_md().
  local src_claude_md="$SOURCE_DIR/CLAUDE.md"
  if [[ -f "$src_claude_md" ]]; then
    sync_claude_md "$src_claude_md" "$profile_dir/CLAUDE.md"
  fi

  local src_settings="$CLAUDE_DIR/settings.json"
  local dst_settings="$profile_dir/settings.json"
  if [[ -f "$src_settings" ]]; then
    if [[ "$DRY_RUN" == "true" ]]; then
      if [[ -f "$dst_settings" ]]; then
        echo -e "  ${CYAN}[dry-run] settings.json serait mergé (hooks + permissions.deny + env + preferences)${RESET}"
      else
        echo -e "  ${CYAN}[dry-run] settings.json serait copié${RESET}"
      fi
    else
      if [[ -f "$dst_settings" ]]; then
        merge_settings "$src_settings" "$dst_settings"
      else
        cp "$src_settings" "$dst_settings"
        echo -e "  ${GREEN}✓ settings.json copié${RESET}"
      fi
      if [[ "$OSTYPE" == "darwin"* ]]; then
        sed -i '' "s|\${CLAUDE_CONFIG_DIR}|$profile_dir|g" "$dst_settings"
      else
        sed -i "s|\${CLAUDE_CONFIG_DIR}|$profile_dir|g" "$dst_settings"
      fi
      node -e "
const fs = require('node:fs');
const cfg = JSON.parse(fs.readFileSync('$dst_settings', 'utf8'));
for (const event of Object.keys(cfg.hooks || {})) {
  const seen = new Set();
  cfg.hooks[event] = cfg.hooks[event].filter(e => {
    const k = JSON.stringify(e); if (seen.has(k)) return false; seen.add(k); return true;
  });
}
fs.writeFileSync('$dst_settings', JSON.stringify(cfg, null, 2) + '\n');
"
    fi
  fi

  local runtime_dirs=(logs runs "memory/global" "archives/summaries")
  if [[ "$DRY_RUN" == "true" ]]; then
    echo -e "  ${CYAN}[dry-run] répertoires runtime seraient créés (${runtime_dirs[*]})${RESET}"
  else
    for rd in "${runtime_dirs[@]}"; do
      mkdir -p "$profile_dir/$rd"
    done
    echo -e "  ${GREEN}✓ répertoires runtime créés${RESET}"
  fi

  # pipelines.json — plus de traitement spécial ici. Il est désormais synchronisé
  # par checksum avec les autres fichiers de MANIFEST_MUTABLE (voir plus haut).
  #
  # Avant (ADR-024, E3-2) : « copié seulement si absent » → gelé à jamais sur tout
  # profil déjà installé. Conséquence mesurée : les 4 profils de la machine avaient
  # 0 occurrence de `sideEffect` là où le dépôt en avait 9 — et comme `ada` exécute
  # le code DU PROFIL, le `sideEffect` commité (60e4a67) ne tournait nulle part.
  # La divergence était à l'intérieur des pipelines existants, pas dans l'ajout de
  # nouveaux : un merge « ajouter les pipelines manquants » ne l'aurait pas corrigée.

  # Manifeste appliqué — écrit EN DERNIER, après tous les syncs de ce profil.
  # C'est la base de comparaison de la prochaine mise à jour : sans lui, aucune
  # distinction possible entre « fichier jamais touché » et « fichier personnalisé ».
  if [[ "$DRY_RUN" == "true" ]]; then
    echo -e "  ${CYAN}[dry-run] $APPLIED_MANIFEST_NAME ne serait pas mis à jour${RESET}"
  else
    cp "$MANIFEST_FILE" "$profile_dir/$APPLIED_MANIFEST_NAME"
    echo -e "  ${GREEN}✓ $APPLIED_MANIFEST_NAME (référence pour la prochaine mise à jour)${RESET}"
  fi
}

# ─── CLI ada ─────────────────────────────────────────────────────────────────
install_cli() {
  local ada_bin="$CLAUDE_DIR/bin/ada.js"

  if [[ ! -f "$ada_bin" ]]; then
    echo -e "${YELLOW}⚠ bin/ada.js introuvable — CLI ada non installé${RESET}"
    return
  fi

  echo -e "\n${BOLD}Installation CLI ada…${RESET}"

  if [[ "$DRY_RUN" == "true" ]]; then
    echo -e "  ${CYAN}[dry-run] chmod +x $ada_bin${RESET}"
    echo -e "  ${CYAN}[dry-run] symlink /usr/local/bin/ada → $ada_bin (ou alias shell RC en repli)${RESET}"
    return
  fi

  chmod +x "$ada_bin"

  if sudo ln -sf "$ada_bin" /usr/local/bin/ada 2>/dev/null; then
    echo -e "${GREEN}✓ /usr/local/bin/ada → $ada_bin${RESET}"
  else
    echo -e "${YELLOW}⚠ sudo échoué — ajout de l'alias dans le RC de ton shell${RESET}"
    local alias_line="alias ada='node $ada_bin'"
    local shell_rc=""
    [[ -f "$HOME/.zshrc" ]]  && shell_rc="$HOME/.zshrc"
    [[ -z "$shell_rc" ]] && [[ -f "$HOME/.bashrc" ]] && shell_rc="$HOME/.bashrc"
    if [[ -n "$shell_rc" ]]; then
      if ! grep -qF "$alias_line" "$shell_rc" 2>/dev/null; then
        echo "" >> "$shell_rc"
        echo "# ADA CLI" >> "$shell_rc"
        echo "$alias_line" >> "$shell_rc"
        echo -e "${GREEN}✓ Alias ajouté dans $shell_rc — relance ton shell${RESET}"
      else
        echo -e "${CYAN}ℹ Alias déjà présent dans $shell_rc${RESET}"
      fi
    else
      echo -e "${YELLOW}⚠ Aucun RC trouvé — ajoute manuellement : $alias_line${RESET}"
    fi
  fi
}

# ─── Backend ADA (NestJS — ada-api-nest) ─────────────────────────────────────
# Historique du bug (2026-08-13) : ada-ui parle exclusivement à ada-api-nest
# (port 3010, Bearer JWT) depuis la refonte P0 — mais install.sh n'installait,
# ne construisait ni ne configurait JAMAIS ce service (seul l'ANCIEN ada-api,
# opt-in via --with-server, l'était). Résultat sur toute machine neuve : ada-ui
# démarre mais reste hors ligne, faute de backend réellement démarrable.
# install_api_nest() traite donc ada-api-nest comme un composant CŒUR (comme
# install_ui, PAS derrière un flag) — c'est le vrai backend, plus une option.
#
# Seul champ de env.schema.ts sans défaut ni valeur optionnelle : JWT_SECRET
# (>= 16 car.). Sans .env du tout (machine neuve), l'app validerait l'env au
# boot et crasherait immédiatement. On génère donc un .env minimal si absent —
# DATABASE_URL est volontairement omis (Postgres est optionnel : absence =
# mode dégradé documenté dans .env.example, pas un crash).
install_api_nest() {
  local api_dir="$SOURCE_DIR/ada-api-nest"

  echo -e "\n${BOLD}Installation du backend ADA (ada-api-nest)…${RESET}"

  if [[ ! -d "$api_dir" ]]; then
    echo -e "${YELLOW}⚠ ada-api-nest introuvable : $api_dir — backend ignoré (ada-ui restera hors ligne)${RESET}"
    return
  fi

  echo -e "  ${CYAN}Répertoire : $api_dir${RESET}"

  if [[ "$DRY_RUN" == "true" ]]; then
    if [[ ! -d "$api_dir/node_modules" ]]; then
      echo -e "  ${CYAN}[dry-run] dépendances npm seraient installées${RESET}"
    else
      echo -e "  ${CYAN}[dry-run] dépendances npm déjà présentes${RESET}"
    fi
    if [[ ! -f "$api_dir/.env" ]]; then
      echo -e "  ${CYAN}[dry-run] .env serait généré (JWT_SECRET aléatoire)${RESET}"
    fi
    echo -e "  ${CYAN}[dry-run] build de production ignoré${RESET}"
    return
  fi

  if [[ ! -d "$api_dir/node_modules" ]]; then
    echo -e "  Installation des dépendances npm…"
    if npm --prefix "$api_dir" ci --silent 2>/dev/null || npm --prefix "$api_dir" install --silent 2>/dev/null; then
      echo -e "  ${GREEN}✓ Dépendances installées${RESET}"
    else
      echo -e "  ${YELLOW}⚠ npm install échoué — relance manuellement : cd $api_dir && npm install${RESET}"
      return
    fi
  else
    echo -e "  ${GREEN}✓ Dépendances déjà présentes${RESET}"
  fi

  if [[ ! -f "$api_dir/.env" ]]; then
    local jwt_secret
    jwt_secret="$(openssl rand -hex 32 2>/dev/null || head -c 32 /dev/urandom | od -An -tx1 | tr -d ' \n')"
    if [[ -z "$jwt_secret" ]] || [[ ${#jwt_secret} -lt 16 ]]; then
      echo -e "  ${YELLOW}⚠ Génération JWT_SECRET impossible (ni openssl ni /dev/urandom) — .env non créé${RESET}"
      echo -e "  ${YELLOW}  Copie manuellement : cp $api_dir/.env.example $api_dir/.env${RESET}"
    else
      cat > "$api_dir/.env" <<EOF
# Généré par install.sh le $(date '+%Y-%m-%d') — voir .env.example pour toutes les options.
JWT_SECRET=$jwt_secret
# Postgres (ADR-017) — optionnel. Sans cette ligne : mode dégradé (persistance
# désactivée, /health: db down), mais l'app démarre et fonctionne normalement.
# DATABASE_URL=postgresql://ada:ada@127.0.0.1:5433/ada
EOF
      echo -e "  ${GREEN}✓ .env généré (JWT_SECRET aléatoire)${RESET}"
      echo -e "  ${CYAN}  Persistance Postgres optionnelle : voir $api_dir/.env.example (DATABASE_URL)${RESET}"
    fi
  else
    echo -e "  ${GREEN}✓ .env déjà présent${RESET}"
  fi

  echo -e "  Compilation du backend (peut prendre 20-40s)…"
  local build_log; build_log="$(mktemp /tmp/ada-api-nest-build.XXXXXX.log)"
  if npm --prefix "$api_dir" run build >"$build_log" 2>&1; then
    echo -e "  ${GREEN}✓ Backend compilé en mode production${RESET}"
    rm -f "$build_log"
  else
    echo -e "  ${YELLOW}⚠ Build échoué — le backend démarrera en mode dev (plus lent) via 'ada start server'${RESET}"
    echo -e "  ${YELLOW}  Logs : $build_log${RESET}"
  fi
}

# ─── Interface ADA (Next.js) ─────────────────────────────────────────────────
install_ui() {
  local ui_dir="$SOURCE_DIR/ada-ui"

  echo -e "\n${BOLD}Installation de l'interface ADA…${RESET}"

  if [[ ! -d "$ui_dir" ]]; then
    echo -e "${YELLOW}⚠ ada-ui introuvable : $ui_dir — interface ignorée${RESET}"
    return
  fi

  echo -e "  ${CYAN}Répertoire : $ui_dir${RESET}"

  # Arrêt du serveur en cours — évite de corrompre .next/ pendant le build
  local pid_file="$HOME/.ada-ui.pid"
  if [[ -f "$pid_file" ]]; then
    local pid_content; pid_content=$(cat "$pid_file" 2>/dev/null || true)
    local old_pid; old_pid="${pid_content%%:*}"
    if [[ -n "$old_pid" ]] && [[ "$old_pid" =~ ^[0-9]+$ ]] && kill -0 "$old_pid" 2>/dev/null; then
      if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "  ${CYAN}[dry-run] Serveur ADA UI actif (PID $old_pid) — serait arrêté avant build${RESET}"
      else
        echo -e "  ${CYAN}Serveur ADA UI actif (PID $old_pid) — arrêt avant build…${RESET}"
        kill "$old_pid" 2>/dev/null || true
        sleep 1
        UI_WAS_RUNNING=true
      fi
    fi
    [[ "$DRY_RUN" != "true" ]] && rm -f "$pid_file"
  fi

  if [[ "$DRY_RUN" == "true" ]]; then
    echo -e "  ${CYAN}[dry-run] port 7777 : nettoyage ignoré${RESET}"
    if [[ ! -d "$ui_dir/node_modules" ]]; then
      echo -e "  ${CYAN}[dry-run] dépendances npm seraient installées${RESET}"
    else
      echo -e "  ${CYAN}[dry-run] dépendances npm déjà présentes${RESET}"
    fi
    echo -e "  ${CYAN}[dry-run] build de production ignoré${RESET}"
    UI_DIR="$ui_dir"
    return
  fi

  # Nettoyage port 7777 en dernier recours
  lsof -ti:7777 2>/dev/null | xargs kill -9 2>/dev/null || true

  if [[ ! -d "$ui_dir/node_modules" ]]; then
    echo -e "  Installation des dépendances npm…"
    if npm --prefix "$ui_dir" ci --silent 2>/dev/null || npm --prefix "$ui_dir" install --silent 2>/dev/null; then
      echo -e "  ${GREEN}✓ Dépendances installées${RESET}"
    else
      echo -e "  ${YELLOW}⚠ npm install échoué — l'interface démarrera en mode dev${RESET}"
      return
    fi
  else
    echo -e "  ${GREEN}✓ Dépendances déjà présentes${RESET}"
  fi

  echo -e "  Compilation de l'interface (peut prendre 30-60s)…"
  local build_log; build_log="$(mktemp /tmp/ada-build.XXXXXX.log)"
  if npm --prefix "$ui_dir" run build >"$build_log" 2>&1; then
    echo -e "  ${GREEN}✓ Interface compilée en mode production${RESET}"
    rm -f "$build_log"
  else
    echo -e "  ${YELLOW}⚠ Build échoué — l'interface démarrera en mode dev${RESET}"
    echo -e "  ${YELLOW}  Logs : $build_log${RESET}"
  fi

  UI_DIR="$ui_dir"
}

# ─── Calcul de l'activeProfile effectif (ADR-024, addendum défauts 1 & 2) ────
# Reproduit en LECTURE SEULE (aucune écriture sur $ADA_CONFIG) la logique de
# bootstrap réellement appliquée par write_ada_config()
# (« if (!cfg.activeProfile) cfg.activeProfile = <premier profil de la
# sélection> ») — utilisée par write_env_local() (réel + dry-run) ET par le
# message dry-run de write_ada_config(), pour que les deux affichent/utilisent
# la MÊME valeur plutôt que de la déduire chacune indépendamment de leurs
# propres arguments.
#
# Bug réel corrigé par ce helper (validation réelle contre ~/.claude-jarvis,
# 2026-08-11) : write_env_local() dérivait auparavant ADA_ACTIVE_PROFILE du
# PREMIER profil de la sélection EN COURS (installed_profiles[0]) au lieu du
# vrai profil actif de la machine — un simple `install.sh --profile
# claude-jarvis` (maintenance d'un seul profil parmi plusieurs) redirigeait
# silencieusement l'UI ADA vers `jarvis`, sans rapport avec l'activeProfile
# réel (`ov`) de ~/.ada.json.
#
# $1..$n : profils de la sélection en cours (chemins complets, SELECTED[@]) —
# utilisés SEULEMENT comme repli bootstrap (~/.ada.json absent, ou présent
# mais sans activeProfile encore défini — même condition que le vrai code).
# Sortie stdout (sans retour à la ligne) : le nom de profil (basename, point
# de tête retiré, PAS le préfixe "claude-") qui SERA l'activeProfile après ce
# run, en dry-run comme en réel.
compute_effective_active_profile() {
  local installed_profiles=("$@")
  local bootstrap_name; bootstrap_name=$(basename "${installed_profiles[0]}"); bootstrap_name="${bootstrap_name#.}"

  if [[ -f "$ADA_CONFIG" ]]; then
    local existing
    existing="$(node -e "
try {
  const cfg = JSON.parse(require('fs').readFileSync('$ADA_CONFIG','utf8'));
  if (cfg.activeProfile) process.stdout.write(String(cfg.activeProfile));
} catch {}
" 2>/dev/null || true)"
    if [[ -n "$existing" ]]; then
      echo -n "$existing"
      return 0
    fi
  fi

  echo -n "$bootstrap_name"
}

# ─── Aperçu (lecture seule) du futur ~/.ada.json pour le dry-run ─────────────
# ADR-024, addendum défaut 2 (2026-08-11) : le message dry-run de
# write_ada_config() annonçait auparavant la SEULE sélection en cours comme
# futur `installedProfiles` complet (ex. `installedProfiles=["jarvis"]` alors
# que ~/.ada.json connaît 3 autres profils) — alors que le code réel fait une
# UNION filtrée par existence sur disque (aucun profil existant n'est
# retiré). Ce helper duplique EN LECTURE SEULE exactement cette même logique
# d'union + filtre `fs.existsSync`, pour que le message dry-run annonce la
# vérité plutôt qu'un périmètre qui donnerait l'impression, à tort, que les
# profils déjà connus seraient retirés.
# $1 : JSON array (déjà construit par l'appelant, cf. $names_json) des noms de
# profils de la sélection en cours.
# Sortie stdout, 4 lignes taguées (clé=valeur) :
#   ACTIVE_STATUS=first|existing   (cfg.activeProfile déjà défini ou non)
#   KNOWN_COUNT=<n>                (profils déjà dans cfg.installedProfiles ET toujours sur disque)
#   KNOWN_NAMES=<noms séparés par ", ">
#   NEW_COUNT=<n>                  (profils de la sélection en cours absents de KNOWN)
#   NEW_NAMES=<noms séparés par ", ">
compute_ada_config_preview() {
  local new_names_json="$1"
  node -e "
const fs = require('node:fs'), os = require('node:os'), p = require('node:path');
let cfg = {};
try { cfg = JSON.parse(fs.readFileSync('$ADA_CONFIG','utf8')); } catch {}
const existing = Array.isArray(cfg.installedProfiles) ? cfg.installedProfiles : [];
const newProfiles = ${new_names_json};
const existingOnDisk = existing.filter(n => fs.existsSync(p.join(os.homedir(), '.' + n)));
const added = newProfiles.filter(n => !existingOnDisk.includes(n));
process.stdout.write('ACTIVE_STATUS=' + (cfg.activeProfile ? 'existing' : 'first') + '\n');
process.stdout.write('KNOWN_COUNT=' + existingOnDisk.length + '\n');
process.stdout.write('KNOWN_NAMES=' + existingOnDisk.join(', ') + '\n');
process.stdout.write('NEW_COUNT=' + added.length + '\n');
process.stdout.write('NEW_NAMES=' + added.join(', '));
"
}

# ─── .env.local pour l'interface ─────────────────────────────────────────────
write_env_local() {
  local installed_profiles=("$@")
  local ui_dir="$SOURCE_DIR/ada-ui"
  [[ ! -d "$ui_dir" ]] && return

  local active_profile; active_profile=$(compute_effective_active_profile "${installed_profiles[@]}")
  local active_name="${active_profile#claude-}"

  if ! [[ "$active_name" =~ ^[a-z0-9][a-z0-9-]{0,30}$ ]]; then
    echo -e "${YELLOW}⚠ Impossible d'écrire .env.local : nom de profil invalide '$active_name'${RESET}"
    return
  fi

  local env_file="$ui_dir/.env.local"

  if [[ "$DRY_RUN" == "true" ]]; then
    echo -e "  ${CYAN}[dry-run] .env.local serait mis à jour (ADA_ACTIVE_PROFILE=$active_name)${RESET}"
    return
  fi

  local existing=""
  if [[ -f "$env_file" ]]; then
    existing=$(grep -v '^ADA_ACTIVE_PROFILE=' "$env_file" 2>/dev/null || true)
  fi

  {
    [[ -n "$existing" ]] && echo "$existing"
    echo "ADA_ACTIVE_PROFILE=$active_name"
  } > "$env_file"

  echo -e "  ${GREEN}✓ .env.local créé (ADA_ACTIVE_PROFILE=$active_name)${RESET}"
}

# ─── Config ~/.ada.json ───────────────────────────────────────────────────────
write_ada_config() {
  local installed_profiles=("$@")
  local active_profile; active_profile=$(basename "${installed_profiles[0]}"); active_profile="${active_profile#.}"

  if ! [[ "$active_profile" =~ ^[a-z0-9][a-z0-9-]{0,30}$ ]]; then
    echo -e "${RED}✗ Nom de profil invalide : '$active_profile'${RESET}"
    exit 1
  fi

  local names_json="["
  for p in "${installed_profiles[@]}"; do
    local n; n=$(basename "$p"); n="${n#.}"
    if ! [[ "$n" =~ ^[a-z0-9][a-z0-9-]{0,30}$ ]]; then
      echo -e "${RED}✗ Nom de profil invalide : '$n'${RESET}"
      exit 1
    fi
    names_json+="\"$n\","
  done
  names_json="${names_json%,}]"

  local ui_dir="$SOURCE_DIR/ada-ui"
  local resolved_ui_dir; [[ -d "$ui_dir" ]] && resolved_ui_dir="$ui_dir" || resolved_ui_dir="${UI_DIR:-}"

  if [[ "$DRY_RUN" == "true" ]]; then
    local effective_active; effective_active=$(compute_effective_active_profile "${installed_profiles[@]}")

    local preview; preview="$(compute_ada_config_preview "$names_json")"
    local active_status known_count known_names new_count new_names
    active_status="$(sed -n 's/^ACTIVE_STATUS=//p' <<< "$preview")"
    known_count="$(sed -n 's/^KNOWN_COUNT=//p' <<< "$preview")"
    known_names="$(sed -n 's/^KNOWN_NAMES=//p' <<< "$preview")"
    new_count="$(sed -n 's/^NEW_COUNT=//p' <<< "$preview")"
    new_names="$(sed -n 's/^NEW_NAMES=//p' <<< "$preview")"

    local active_note="inchangé"
    [[ "$active_status" == "first" ]] && active_note="défini pour la première fois"

    echo -e "  ${CYAN}[dry-run] ~/.ada.json serait mis à jour :${RESET}"
    echo -e "  ${CYAN}    activeProfile=$effective_active ($active_note)${RESET}"
    if [[ "$known_count" -gt 0 && "$new_count" -gt 0 ]]; then
      echo -e "  ${CYAN}    installedProfiles : ${known_count} profil(s) déjà connu(s) ($known_names, inchangé(s)) + ${new_count} nouveau(x) profil(s) ajouté(s) à ce run ($new_names)${RESET}"
    elif [[ "$new_count" -gt 0 ]]; then
      echo -e "  ${CYAN}    installedProfiles : ${new_count} nouveau(x) profil(s) ($new_names)${RESET}"
    else
      echo -e "  ${CYAN}    installedProfiles inchangé(s) : ${known_count} profil(s) déjà connu(s) ($known_names)${RESET}"
    fi
    return
  fi

  node -e "
const fs = require('node:fs'), cfg_path = '$ADA_CONFIG';
let cfg = {};
try { cfg = JSON.parse(fs.readFileSync(cfg_path, 'utf8')); } catch {}
if (!cfg.activeProfile) cfg.activeProfile = '$active_profile';
cfg.sourceDir = '$CLAUDE_DIR';
if ('$resolved_ui_dir') cfg.uiDir = '$resolved_ui_dir';
const newProfiles = ${names_json};
const os = require('node:os'), p = require('node:path');
// Union puis élagage : un profil supprimé du disque ne doit pas rester listé
// (sinon 'ada profile list' affiche des profils fantômes et 'ada profile use'
// bascule sur un répertoire inexistant).
cfg.installedProfiles = [...new Set([...(cfg.installedProfiles ?? []), ...newProfiles])]
  .filter(n => fs.existsSync(p.join(os.homedir(), '.' + n)));
cfg.installedAt = new Date().toISOString();
cfg.version = '${ADA_VERSION}';
fs.writeFileSync(cfg_path, JSON.stringify(cfg, null, 2) + '\n');
"
  echo -e "${GREEN}✓ ~/.ada.json mis à jour${RESET}"
}

# ─── Vérification post-install ────────────────────────────────────────────────
run_doctor() {
  local first_profile="$1"
  local doctor="$first_profile/bin/doctor.js"

  echo -e "\n${BOLD}Vérification post-install…${RESET}"

  # doctor.js écrit un fichier test (.doctor-write-test) pour vérifier les
  # permissions — un vrai effet de bord, et de toute façon rien n'a été
  # installé à vérifier en dry-run.
  if [[ "$DRY_RUN" == "true" ]]; then
    echo -e "  ${CYAN}[dry-run] doctor.js ignoré (rien n'a été installé à vérifier)${RESET}"
    return
  fi

  if [[ -f "$doctor" ]]; then
    CLAUDE_CONFIG_DIR="$first_profile" node "$doctor" || echo -e "${YELLOW}⚠ doctor.js a retourné des avertissements${RESET}"
  else
    echo -e "${CYAN}ℹ doctor.js non trouvé dans $first_profile/bin/ — étape ignorée${RESET}"
  fi
}

# ─── Refresh stats-cache (reset mtime) ───────────────────────────────────────
refresh_stats_cache() {
  [[ "$DRY_RUN" == "true" ]] && return 0
  local installed=("$@")
  for profile in "${installed[@]}"; do
    local cache="$profile/stats-cache.json"
    if [[ -f "$cache" ]]; then
      touch "$cache"
    fi
  done
}

# ─── Récapitulatif des personnalisations préservées ──────────────────────────
# Un fichier livré que le client a modifié n'est jamais écrasé — mais il ne doit
# pas non plus être passé sous silence : il reste sur une version antérieure et le
# client doit savoir lesquels reporter à la main s'il veut la nouvelle.
print_customizations() {
  [[ -n "$CUSTOM_REPORT" && -s "$CUSTOM_REPORT" ]] || return 0

  echo -e "\n${BOLD}${YELLOW}Fichiers personnalisés — non écrasés :${RESET}"
  local tag kind path
  while IFS=$'\t' read -r tag kind path; do
    [[ -z "${path:-}" ]] && continue
    if [[ "$kind" == "deprecie-personnalise" ]]; then
      echo -e "  ${YELLOW}⚠${RESET} [$tag] $path"
      echo -e "      ${YELLOW}retiré de la livraison mais modifié localement — conservé, à vérifier${RESET}"
    else
      echo -e "  ${CYAN}•${RESET} [$tag] $path"
    fi
  done < <(sort -u "$CUSTOM_REPORT")

  echo -e "\n  ${CYAN}ℹ Ces fichiers diffèrent de la version livrée : ADA ne les a pas touchés.${RESET}"
  echo -e "  ${CYAN}  Ils restent donc sur leur version locale — reporte les changements à la main${RESET}"
  echo -e "  ${CYAN}  si tu veux la version livrée.${RESET}"
}

# ─── Résumé final ─────────────────────────────────────────────────────────────
print_summary() {
  local installed=("$@")

  if [[ "$DRY_RUN" == "true" ]]; then
    echo -e "\n${YELLOW}${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo -e "${YELLOW}${BOLD}  Simulation --dry-run terminée — rien n'a été écrit${RESET}"
    echo -e "${YELLOW}${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo -e "\n${BOLD}Profils qui auraient été installés (v${ADA_VERSION}) :${RESET}"
    for p in "${installed[@]}"; do
      echo -e "  ${CYAN}•${RESET} $(basename "$p")"
    done
    echo -e "\n  ${CYAN}ℹ Relance sans --dry-run pour appliquer ces changements.${RESET}\n"
    return
  fi

  echo -e "\n${GREEN}${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
  echo -e "${GREEN}${BOLD}  ADA v${ADA_VERSION} installé avec succès !${RESET}"
  echo -e "${GREEN}${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
  echo -e "\n${BOLD}Profils installés :${RESET}"
  for p in "${installed[@]}"; do
    echo -e "  ${GREEN}✓${RESET} $(basename "$p")"
  done
  echo -e ""
  echo -e "${BOLD}Commandes :${RESET}"
  echo -e "  ${CYAN}ada start server${RESET}      — démarre les 3 services (control-server + backend + interface)"
  echo -e "  ${YELLOW}  ada start${RESET} (seul)      — interface SEULE, hors ligne sans le backend : préférer ${CYAN}ada start server${RESET}"
  echo -e "  ${CYAN}ada obsidian init${RESET}     — configurer un vault Obsidian"
  echo -e "  ${CYAN}ada open${RESET}              — ouvre l'interface dans le navigateur"
  echo -e "  ${CYAN}ada stop${RESET}              — arrête les 3 services"
  echo -e ""
  echo -e "${BOLD}Autres commandes :${RESET}"
  echo -e "  ${CYAN}ada status${RESET}            — état complet du système"
  echo -e "  ${CYAN}ada profile list${RESET}      — lister les profils installés"
  echo -e "  ${CYAN}ada profile use <nom>${RESET} — changer de profil actif"
  echo -e "  ${CYAN}ada launch [dossier]${RESET}  — lancer Claude sur un projet"
  echo -e "  ${CYAN}ada provider${RESET}          — afficher le mode fournisseur (claude-code | api)"
  echo -e "\n  Config : ${YELLOW}~/.ada.json${RESET}"
  echo -e "  Source : ${YELLOW}$SOURCE_DIR${RESET}\n"
}

# ─── Configuration Obsidian (optionnelle) ─────────────────────────────────────
setup_obsidian() {
  if [[ "$DRY_RUN" == "true" ]]; then
    echo -e "\n${CYAN}[dry-run] Configuration Obsidian ignorée (aucune invite, aucune écriture)${RESET}"
    return 0
  fi
  [[ "$NONINTERACTIVE" == "true" ]] && return 0

  local has_obsidian=false
  if [[ "$OSTYPE" == "darwin"* ]] && [[ -d "/Applications/Obsidian.app" ]]; then
    has_obsidian=true
  elif command -v obsidian &>/dev/null; then
    has_obsidian=true
  fi
  [[ "$has_obsidian" == false ]] && return 0

  echo -e "\n${CYAN}${BOLD}Obsidian détecté${RESET}"
  local ans
  read -rp "$(echo -e "${BOLD}Configurer un vault Obsidian pour vos profils ? [o/N] ${RESET}")" ans
  [[ "$ans" != [oOyY] ]] && return 0

  if command -v ada &>/dev/null; then
    ada obsidian init --all && echo -e "${GREEN}✓ Vault(s) Obsidian initialisé(s)${RESET}"
  else
    echo -e "${YELLOW}⚠ CLI ada introuvable — lancez manuellement : ada obsidian init${RESET}"
  fi
}

# ─── Parse arguments ──────────────────────────────────────────────────────────
print_usage() {
  cat <<EOF
AI Dev Assistant — installeur v${ADA_VERSION}

Usage : bash install.sh [options]

Options :
  --profile <nom>     Installe sur le profil ~/.<nom> (le crée s'il n'existe pas)
  --all, -a           Installe sur tous les profils ~/.claude-*/ détectés
  --non-interactive   Aucune question (CI, provisioning). Crée ~/.${DEFAULT_PROFILE_NAME}
                      si aucun profil n'existe.
  --with-server       [DÉPRÉCIÉ] Installe aussi les dépendances de l'ancien
                      ada-api (Fastify) — ada-ui ne s'y connecte plus. Le
                      vrai backend (ada-api-nest) est installé sans ce flag.
  --dry-run           Simule l'installation : affiche ce qui serait fait,
                      n'écrit rien nulle part (aucun profil, ~/.ada.json,
                      ~/.zshrc, build npm inclus)
  --version           Affiche la version et quitte
  --help, -h          Affiche cette aide

Exemples :
  bash install.sh                          # interactif, crée un profil au besoin
  bash install.sh --profile claude-ada      # profil nommé, sans question
  bash install.sh --non-interactive         # provisioning automatisé

Vérifier l'installation ensuite : ada doctor
Documentation client : docs/INSTALL-CLIENT.md
EOF
}

parse_args() {
  local SPECIFIC_PROFILE=""
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --all|-a)          NONINTERACTIVE=true ;;
      --non-interactive) NONINTERACTIVE=true ;;
      --with-server)     WITH_SERVER=true ;;
      # Déjà positionné par la pré-lecture dans main() (avant ensure_manifest,
      # qui a lui-même un effet de bord à respecter) — ce case existe pour que
      # parse_args ne le rejette pas comme « option inconnue ».
      --dry-run)         DRY_RUN=true ;;
      --profile)         shift
                         if [[ $# -eq 0 || -z "${1:-}" || "${1:-}" == -* ]]; then
                           echo -e "${RED}✗ --profile attend un nom de profil${RESET}" >&2
                           exit 1
                         fi
                         SPECIFIC_PROFILE="$1" ;;
      --profile=*)       SPECIFIC_PROFILE="${1#--profile=}" ;;
      --version)         echo "$ADA_VERSION"; exit 0 ;;
      --help|-h)         print_usage; exit 0 ;;
      # Un flag inconnu était silencieusement ignoré : le client croyait avoir
      # paramétré l'installation alors qu'il obtenait le comportement par défaut.
      *)                 echo -e "${RED}✗ Option inconnue : $1${RESET}" >&2
                         echo -e "  Voir : ${BOLD}bash install.sh --help${RESET}" >&2
                         exit 1 ;;
    esac
    shift
  done

  if [[ -n "$SPECIFIC_PROFILE" ]]; then
    local target="$HOME/.${SPECIFIC_PROFILE#.}"
    # Tolère un profil existant sans point (ancien comportement)
    [[ ! -d "$target" && -d "$HOME/$SPECIFIC_PROFILE" ]] && target="$HOME/$SPECIFIC_PROFILE"

    if [[ ! -d "$target" ]]; then
      # Crée le profil demandé au lieu d'échouer : --profile est le chemin
      # d'installation nominal côté client, il doit fonctionner sur poste vierge.
      # (create_profile_dir gère elle-même le --dry-run : pas de mkdir réel.)
      target="$(create_profile_dir "$SPECIFIC_PROFILE")"
      if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "${CYAN}[dry-run] Profil qui serait créé : $target${RESET}"
      else
        echo -e "${GREEN}✓ Profil créé : $target${RESET}"
      fi
    fi

    # Pré-sélectionner avant detect_profiles pour ne pas être écrasé
    PROFILES=("$target")
    SELECTED=("$target")
    NONINTERACTIVE=true
    PROFILES_PRESELECTED=true
  fi
}

# ─── Main ─────────────────────────────────────────────────────────────────────
main() {
  # --help / --version doivent répondre sans bannière ni vérification de
  # prérequis (un client sans Node doit pouvoir lire l'aide).
  # --dry-run est aussi détecté ICI, avant ensure_manifest : ensure_manifest a
  # elle-même un effet de bord (régénération du manifeste) et tourne avant
  # parse_args — DRY_RUN doit donc être connu plus tôt que parse_args.
  for arg in "$@"; do
    case "$arg" in
      --help|-h)  print_usage;        exit 0 ;;
      --version)  echo "$ADA_VERSION"; exit 0 ;;
      --dry-run)  DRY_RUN=true ;;
    esac
  done

  print_banner
  check_prerequisites

  if [[ "$DRY_RUN" == "true" ]]; then
    echo -e "\n${YELLOW}${BOLD}🔍 Mode --dry-run : simulation uniquement, aucune écriture sur le disque.${RESET}"
  fi

  # Le manifeste conditionne toute la suite : vérifié avant parse_args, donc
  # avant que --profile ne crée un répertoire de profil qu'on abandonnerait.
  ensure_manifest
  CUSTOM_REPORT="$(mktemp "${TMPDIR:-/tmp}/ada-custom-report.XXXXXX")"

  parse_args "$@"

  print_scope_banner

  detect_profiles
  select_profiles
  print_install_plan

  echo -e "\n${BOLD}Installation de ${#SELECTED[@]} profil(s)…${RESET}"
  for profile in "${SELECTED[@]}"; do
    install_profile "$profile"
  done

  install_cli

  # Écriture des configs AVANT le build
  write_ada_config "${SELECTED[@]}"
  write_env_local "${SELECTED[@]}"

  # --with-server : installer les dépendances de l'ANCIEN ada-api (Fastify).
  # ⚠ DÉPRÉCIÉ (2026-08-13) : ada-ui ne parle plus à ce backend depuis la
  # refonte P0 (voir ada-ui/proxy.ts) — remplacé par ada-api-nest, installé
  # sans condition juste en dessous. Ce bloc est conservé tel quel (pas
  # supprimé) pour qui dépendrait encore explicitement d'ada-api, mais
  # n'apporte plus rien à une installation ada-ui/ada-api-nest normale.
  if [[ "$WITH_SERVER" == "true" ]]; then
    local ada_api_dir="$SOURCE_DIR/ada-api"
    if [[ -d "$ada_api_dir" ]]; then
      if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "\n${CYAN}[dry-run] Dépendances ada-api (DÉPRÉCIÉ) seraient installées (npm install)${RESET}"
      else
        echo -e "\n${YELLOW}⚠ ada-api est déprécié — ada-ui ne s'y connecte plus (voir ada-api-nest ci-dessous)${RESET}"
        echo -e "${BOLD}Installation des dépendances ada-api (déprécié)…${RESET}"
        if npm --prefix "$ada_api_dir" install --silent; then
          echo -e "${GREEN}✓ ada-api : dépendances installées${RESET}"
        else
          echo -e "${YELLOW}⚠ npm install ada-api échoué — relance manuellement${RESET}"
        fi
      fi
    else
      echo -e "${YELLOW}⚠ --with-server : ada-api/ introuvable dans $SOURCE_DIR${RESET}"
    fi
  fi

  # Backend réel — composant cœur, pas derrière un flag (voir install_api_nest).
  install_api_nest

  # Build après les configs
  install_ui

  setup_obsidian

  refresh_stats_cache "${SELECTED[@]}"

  run_doctor "${SELECTED[0]}"

  print_summary "${SELECTED[@]}"
  print_customizations
  [[ -n "$CUSTOM_REPORT" ]] && rm -f "$CUSTOM_REPORT"

  # Auto-restart UI if it was running before the install
  # (UI_WAS_RUNNING reste à false en --dry-run : install_ui() ne tue jamais le
  # serveur en cours dans ce mode. Le garde-fou explicite reste volontaire :
  # une future édition d'install_ui() ne doit pas pouvoir réactiver un restart
  # réel sous --dry-run par effet de bord.)
  if [[ "$DRY_RUN" != "true" ]] && [[ "$UI_WAS_RUNNING" == "true" ]] && command -v ada &>/dev/null; then
    echo -e "${CYAN}Redémarrage de l'interface ADA…${RESET}"
    ada start
  fi
}

main "$@"
