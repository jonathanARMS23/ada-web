#!/usr/bin/env bash
# scripts/ada-api-server.sh — Gestion locale d'ada-api
# Usage: bash scripts/ada-api-server.sh start|stop|status|restart|logs

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
ADA_API_DIR="$PROJECT_DIR/ada-api"
PID_FILE="$HOME/.ada-api.pid"
LOG_FILE="$HOME/.ada-api.log"
PORT="${ADA_API_PORT:-3001}"

# Couleurs
GREEN='\033[0;32m'; RED='\033[0;31m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
ok()   { echo -e "${GREEN}✓${NC} $1"; }
err()  { echo -e "${RED}✗${NC} $1"; }
warn() { echo -e "${YELLOW}⚠${NC}  $1"; }
info() { echo -e "${CYAN}→${NC} $1"; }

is_running() {
  [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null
}

do_start() {
  if is_running; then warn "ada-api déjà en cours (PID $(cat "$PID_FILE"))"; return; fi
  if [ ! -d "$ADA_API_DIR/node_modules" ]; then
    info "Installation des dépendances ada-api..."
    (cd "$ADA_API_DIR" && npm install --silent)
  fi
  info "Démarrage ada-api sur le port $PORT..."
  CORS_ORIGINS="${CORS_ORIGINS:-http://localhost:7777,http://127.0.0.1:7777}"
  (cd "$ADA_API_DIR" && PORT="$PORT" CORS_ORIGINS="$CORS_ORIGINS" nohup node src/server.js >> "$LOG_FILE" 2>&1 &
   echo $! > "$PID_FILE")
  sleep 1
  if is_running; then ok "ada-api démarré (PID $(cat "$PID_FILE"))  →  http://localhost:$PORT"
  else err "Échec du démarrage — voir $LOG_FILE"; fi
}

do_stop() {
  if ! is_running; then warn "ada-api n'est pas en cours"; rm -f "$PID_FILE"; return; fi
  kill "$(cat "$PID_FILE")" 2>/dev/null && rm -f "$PID_FILE"
  ok "ada-api arrêté"
}

do_status() {
  if is_running; then
    ok "ada-api en cours  (PID $(cat "$PID_FILE"))  →  http://localhost:$PORT"
    # Health check rapide
    if command -v curl &>/dev/null; then
      health=$(curl -s "http://localhost:$PORT/api/health" 2>/dev/null)
      [ -n "$health" ] && echo "   Health: $health"
    fi
  else
    warn "ada-api arrêté"
  fi
}

case "${1:-}" in
  start)   do_start   ;;
  stop)    do_stop    ;;
  status)  do_status  ;;
  restart) do_stop; sleep 1; do_start ;;
  logs)    tail -f "$LOG_FILE" ;;
  *)       echo "Usage: $0 start|stop|status|restart|logs"; exit 1 ;;
esac
