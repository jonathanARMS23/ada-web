#!/usr/bin/env bash
# tmux-dev.sh — AI Dev Assistant — 1 pane

set -e

[ -z "$1" ] && { echo "Usage: tmux-dev.sh <project_name>"; exit 1; }

PROJECT="$1"
PROJECT_DIR="${2:-$(pwd)}"
SESSION="ai-dev-${PROJECT}"
CONFIG_DIR="${CLAUDE_CONFIG_DIR:-$HOME/.claude}"
AGENTS_DIR="$CONFIG_DIR/agents"

command -v tmux   >/dev/null 2>&1 || { echo "tmux not installed"; exit 1; }
command -v claude >/dev/null 2>&1 || { echo "claude CLI not found"; exit 1; }
[ -f "$CONFIG_DIR/CLAUDE.md" ] || {
  echo "System not installed in $CONFIG_DIR — run install.sh first"
  exit 1
}

tmux has-session -t "$SESSION" 2>/dev/null && tmux kill-session -t "$SESSION"

# ── Détecter la stack avant de lancer claude ─────────────────
echo "→ Détection de la stack dans : $PROJECT_DIR"
CLAUDE_CONFIG_DIR="$CONFIG_DIR" AI_DEV_PROJECT="$PROJECT" \
  bash "$CONFIG_DIR/detect-stack.sh" "$PROJECT_DIR" 2>/dev/null || true

# Lire le profil détecté
DETECTED_PROFILE=""
[ -f "$CONFIG_DIR/.claude/teams/active-profile.txt" ] && \
  DETECTED_PROFILE=$(cat "$CONFIG_DIR/.claude/teams/active-profile.txt")

echo "→ Profil : ${DETECTED_PROFILE:-auto}"
echo ""

CLAUDE_CMD="export CLAUDE_CONFIG_DIR='$CONFIG_DIR' AI_DEV_PROJECT='$PROJECT' && CLAUDE_CONFIG_DIR='$CONFIG_DIR' command claude"
IDLE_CMD="export CLAUDE_CONFIG_DIR='$CONFIG_DIR' AI_DEV_PROJECT='$PROJECT' && clear"

# ── Session tmux — 1 pane principal ──────────────────────────
tmux new-session -d -s "$SESSION" -x 220 -y 50 -n "main"
tmux set-environment -t "$SESSION" CLAUDE_CONFIG_DIR "$CONFIG_DIR"
tmux set-environment -t "$SESSION" AI_DEV_PROJECT    "$PROJECT"

# ── Pane 0 — ORCHESTRATOR ────────────────────────────────────
tmux select-pane -t "$SESSION:main.0"
tmux send-keys -t "$SESSION:main.0" "export CLAUDE_CONFIG_DIR='$CONFIG_DIR' AI_DEV_PROJECT='$PROJECT'" Enter
tmux send-keys -t "$SESSION:main.0" "clear && echo 'ORCHESTRATOR — $PROJECT'" Enter

# Split droit 35%
tmux split-window -t "$SESSION:main" -h -p 35

# Pane 1 — nestjs
tmux send-keys -t "$SESSION:main.1" "export CLAUDE_CONFIG_DIR='$CONFIG_DIR' AI_DEV_PROJECT='$PROJECT'" Enter
tmux send-keys -t "$SESSION:main.1" "clear && echo 'nestjs'" Enter

tmux split-window -t "$SESSION:main.1" -v -p 67
# Pane 2 — nextjs
tmux send-keys -t "$SESSION:main.2" "export CLAUDE_CONFIG_DIR='$CONFIG_DIR' AI_DEV_PROJECT='$PROJECT'" Enter
tmux send-keys -t "$SESSION:main.2" "clear && echo 'nextjs'" Enter

tmux split-window -t "$SESSION:main.2" -v -p 50
# Pane 3 — db
tmux send-keys -t "$SESSION:main.3" "export CLAUDE_CONFIG_DIR='$CONFIG_DIR' AI_DEV_PROJECT='$PROJECT'" Enter
tmux send-keys -t "$SESSION:main.3" "clear && echo 'db'" Enter

# Bottom row
tmux select-pane -t "$SESSION:main.0"
tmux split-window -t "$SESSION:main.0" -v -p 25

# Pane 4 — devops
tmux send-keys -t "$SESSION:main.4" "export CLAUDE_CONFIG_DIR='$CONFIG_DIR' AI_DEV_PROJECT='$PROJECT'" Enter
tmux send-keys -t "$SESSION:main.4" "clear && echo 'devops'" Enter

tmux split-window -t "$SESSION:main.4" -h -p 67
# Pane 5 — tester
tmux send-keys -t "$SESSION:main.5" "export CLAUDE_CONFIG_DIR='$CONFIG_DIR' AI_DEV_PROJECT='$PROJECT'" Enter
tmux send-keys -t "$SESSION:main.5" "clear && echo 'tester'" Enter

tmux split-window -t "$SESSION:main.5" -h -p 50
# Pane 6 — reviewer
tmux send-keys -t "$SESSION:main.6" "export CLAUDE_CONFIG_DIR='$CONFIG_DIR' AI_DEV_PROJECT='$PROJECT'" Enter
tmux send-keys -t "$SESSION:main.6" "clear && echo 'reviewer'" Enter

# Window 2 — mobile
tmux new-window -t "$SESSION" -n "mobile"
tmux send-keys -t "$SESSION:mobile"   "export CLAUDE_CONFIG_DIR='$CONFIG_DIR' AI_DEV_PROJECT='$PROJECT' && clear && echo 'react-native'" Enter
tmux split-window -t "$SESSION:mobile" -h -p 67
tmux send-keys -t "$SESSION:mobile.1" "export CLAUDE_CONFIG_DIR='$CONFIG_DIR' AI_DEV_PROJECT='$PROJECT' && clear && echo 'android'" Enter
tmux split-window -t "$SESSION:mobile.1" -h -p 50
tmux send-keys -t "$SESSION:mobile.2" "export CLAUDE_CONFIG_DIR='$CONFIG_DIR' AI_DEV_PROJECT='$PROJECT' && clear && echo 'swift'" Enter

# Window 3 — logs
tmux new-window -t "$SESSION" -n "logs"
tmux send-keys -t "$SESSION:logs" "export AI_DEV_PROJECT='$PROJECT' && clear && echo 'logs'" Enter
tmux split-window -t "$SESSION:logs" -h
tmux send-keys -t "$SESSION:logs.1" "clear && echo 'git/docker'" Enter

# ── Focus main ───────────────────────────────────────────────
tmux select-window -t "$SESSION:main"
tmux select-pane   -t "$SESSION:main.0"

tmux select-pane -t "$SESSION:main.0" -T "ORCHESTRATOR"
tmux select-pane -t "$SESSION:main.1" -T "nestjs"
tmux select-pane -t "$SESSION:main.2" -T "nextjs"
tmux select-pane -t "$SESSION:main.3" -T "db"
tmux select-pane -t "$SESSION:main.4" -T "devops"
tmux select-pane -t "$SESSION:main.5" -T "tester"
tmux select-pane -t "$SESSION:main.6" -T "reviewer"

echo "✓ Workspace '$SESSION' prêt"
echo "  Profil détecté : ${DETECTED_PROFILE:-auto}"
echo "  [1] main   — orchestrator + nestjs/nextjs/db + devops/tester/reviewer"
echo "  [2] mobile — react-native / android / swift"
echo "  [3] logs   — monitoring & git"
echo "  Ctrl+a prefix | h/j/k/l navigate | z zoom"
echo ""

tmux attach-session -t "$SESSION"
